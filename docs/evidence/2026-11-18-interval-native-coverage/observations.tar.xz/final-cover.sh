set -eu
s=/dev/shm/hyperinterval-coverage
. "$s/env"
export CARGO_TARGET_DIR="$s/control-target"
repo=$PWD
cd "$s/control"
git restore --worktree -- crates/hyperinterval/tests/boundary_composition.rs crates/hyperinterval/tests/arctangent.rs
for rev in baseline final; do
 if [ "$rev" = final ]; then cp "$repo"/crates/hyperinterval/tests/{arctangent,boundary_composition}.rs crates/hyperinterval/tests/; fi
 log="$s/logs/$rev"
 if python3 crates/hyperinterval/scripts/coverage.py >"$log" 2>&1; then exit 1; fi
 tail -1 "$log" | grep -Fx 'Production coverage is below 100% on the instrumented metrics.' >/dev/null
 out=$(sed -n 's/^Coverage artifacts in //p' "$log")
 cp "$out/summary.json" "$s/logs/$rev.json"
 test -s "$out/uncovered.txt"
done
