from pathlib import Path
import json,subprocess as sp
s=Path(__file__).parent
f=Path('docs/research/interval-size-accounts.json')
original=f.read_text();data=json.loads(original)
q=json.loads((s/'logs/images.json').read_text())
commit=sp.check_output(['git','rev-parse','d8760fc6b'],text=True).strip()
reference='docs/evidence/2026-11-18-interval-native-coverage'
records=[]
for n in ['arctangent','boundary_composition']:
    role='Checks the tight outward unbounded arctangent image across a refinement boundary.' if n=='arctangent' else 'Checks empty integer differences and subsequent hull on all twelve storage widths.'
    name=f'crates/hyperinterval/tests/{n}.rs#release-tests'
    assert all(r.get('artifact')!=name for r in data['accounts'])
    rows=[q[rev][n] for rev in ['fixed','preceding','proposed']]
    metrics={}
    for k,label in [('file','file'),('text','executable_code'),('function_union','sized_named_code')]:
        a,b,c=[r[k] for r in rows]
        cap=32768 if k=='file' else 16384
        inc=max(0,c-b); total=inc+max(0,b-a)
        assert inc<=cap and total<=cap and inc*100<=2*b and total*100<=2*a
        metrics[label]=dict(baseline=a,previous_retained=b,retained=c,incremental_growth_bytes=c-b,
                            incremental_growth_percent=(c-b)*100/b,accepted_positive_growth_bytes=total,
                            remaining_cumulative_bytes=cap-total,remaining_cumulative_percent=2-100*total/a,
                            caps=dict(incremental_bytes=cap,cumulative_bytes=cap,incremental_percent=2,cumulative_percent=2),passes_both_caps=True)
    records.append(dict(artifact=name,role=role,target='x86_64-unknown-linux-gnu',toolchain='Rust 1.95.0',features='hyperinterval --all-features',
        profile='Configured release integration tests; workspace lock. One physical source and target path for all three builds.',
        baseline_commit=data['baseline_commit'],previous_commit=sp.check_output(['git','rev-parse','c09e26a92'],text=True).strip(),source_snapshot=commit,
        baseline_sha256=rows[0]['sha256'],previous_sha256=rows[1]['sha256'],retained_sha256=rows[2]['sha256'],metrics=metrics,
        qualification_capacity_bytes=64*1024**2,required_free_bytes=16*1024**2,remaining_bytes=64*1024**2-rows[-1]['file'],evidence=reference))
    assert records[-1]['remaining_bytes']>=records[-1]['required_free_bytes']
d=dict(id='native-interval-coverage-and-rounding-retry',benefit='Measures the native production denominator and detects a one-grid-unit overestimate at an unbounded arctangent endpoint and incorrect empty integer differences.',sources=['crates/hyperinterval/scripts/coverage.py','crates/hyperinterval/tests/arctangent.rs','crates/hyperinterval/tests/boundary_composition.rs'],production_implementation_changed=False,source_snapshot=commit,evidence=reference)
def append(key,rows,raw):
    start=raw.index('  "'+key+'": [')
    a=raw.index('\n  ]',start)
    extra=json.dumps(rows,indent=2)[2:-2]
    return raw[:a]+',\n'+'\n'.join('  '+line for line in extra.splitlines())+raw[a:]
result=append('accounts',records,append('accepted_changes',[d],original))
data['accounts'].extend(records);data['accepted_changes'].append(d)
assert json.loads(result)==data
f.write_text(result)
