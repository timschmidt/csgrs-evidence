from pathlib import Path
import importlib.util,json,hashlib
mod=Path('crates/hyperinterval/scripts/coverage.py').resolve()
spec=importlib.util.spec_from_file_location('coverage_gate',mod)
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
s=Path(__file__).parent
m=json.loads((s/'logs/pilot.json').read_text()); src={f.relative_to(gate.CRATE).as_posix() for f in (gate.CRATE/'src').rglob('*.rs')}
def calc(files):
 data={'data':[{'files':[dict(filename=str(gate.CRATE/k),summary=v) for k,v in files.items()]}]}
 return gate.summarize(data,src)
files=m['files']
assert calc(files)['production']==m['production']
for name in gate.TEST_MODULES:
 copy=files.copy()
 copy[name]={metric:dict(count=1000,covered=0) for metric in gate.METRICS}
 assert calc(copy)['production']==m['production']
for bad in [{k:v for k,v in files.items() if k!='src/arctangent.rs'},dict(files,**{'src/unexpected.rs':files['src/arctangent.rs']}),{k:{metric:dict(count=0,covered=0) for metric in gate.METRICS} for k in files}]:
 try:calc(bad)
 except ValueError:pass
 else:raise AssertionError("invalid denominator accepted")
print('Measured summary, two test-only exclusions, missing and extra sources, and empty denominator verified.')
