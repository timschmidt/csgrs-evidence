from pathlib import Path
import subprocess as sp,os,shutil,json,re,hashlib
s=Path(__file__).parent;co=s/'images-control';repo=Path.cwd()
if not co.exists():sp.run(['git','worktree','add','--quiet','--detach',co,'c9f1f9ac'],check=True)
rows={}
for rev in ['fixed','preceding','proposed']:
 if rev=='preceding':sp.run(['git','-C',co,'checkout','--quiet','--detach','c09e26a92'],check=True)
 if rev=='proposed':
  for n in ['arctangent','boundary_composition']:
   rel=Path('crates/hyperinterval/tests')/(n+'.rs')
   shutil.copyfile(repo/rel,co/rel)
 cmd=['cargo','test','--locked','--release','--all-features','-p','hyperinterval','--test','arctangent','--test','boundary_composition','--no-run','--message-format=json-render-diagnostics']
 compiled=sp.check_output(cmd,cwd=co,text=True)
 metrics={}
 for line in compiled.splitlines():
  r=json.loads(line)
  if r['reason']!='compiler-artifact' or not r.get('executable'):continue
  n=r['target']['name'];p=Path(r['executable'])
  sp.run([p],check=True,cwd=co,stdout=sp.DEVNULL)
  ranges=[]
  for line in sp.check_output(['readelf','-Ws',p],text=True).splitlines():
   f=line.split()
   if len(f)>=8 and f[3]=='FUNC' and f[6].isdigit() and f[2].isdigit() and int(f[2]):
    a=int(f[1],16);ranges.append((a,a+int(f[2])))
  end=total=0
  for a,b in sorted(ranges):total+=max(0,b-max(a,end));end=max(end,b)
  text=int(re.search(r'^\.text\s+(\d+)',sp.check_output(['size','-A',p],text=True),re.M)[1])
  metrics[n]={'file':p.stat().st_size,'text':text,'function_union':total,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 assert set(metrics)=={'arctangent','boundary_composition'}
 rows[rev]=metrics
(s/'logs/images.json').write_text(json.dumps(rows,indent=2)+'\n')
