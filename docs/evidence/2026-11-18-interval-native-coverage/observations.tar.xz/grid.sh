set -eu
s=/dev/shm/hyperinterval-coverage
. "$s/env"
export RUSTFLAGS="-C instrument-coverage -C link-dead-code=yes -C codegen-units=1"
mkdir -p "$s/grid"
export LLVM_PROFILE_FILE="$s/grid/%p-%m.profraw"
host=x86_64-unknown-linux-gnu
cargo test --locked -p hyperinterval --target "$host" --all-features --test arctangent unbounded_sources_use_certified_limits >"$s/logs/grid" 2>&1
tool="$(rustc --print sysroot)/lib/rustlib/$host/bin"
"$tool/llvm-profdata" merge --failure-mode=any -sparse "$s"/grid/*.profraw -o "$s/grid.profdata"
bin=$(rg -o '/[^ )]+/arctangent-[0-9a-f]+' "$s/logs/grid" | tail -1)
"$tool/llvm-cov" show --show-instantiations=false "$bin" --instr-profile="$s/grid.profdata" "$PWD/crates/hyperinterval/src/arctangent.rs" >"$s/logs/grid-lines"
awk 'NR>=230 && NR<=237' "$s/logs/grid-lines"
