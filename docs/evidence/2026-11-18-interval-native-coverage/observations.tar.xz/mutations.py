from pathlib import Path
import subprocess as sp,shutil
s=Path(__file__).parent
co=s/'control'
for path,target,case,a,b in [
 ('arctangent','arctangent','unbounded_sources_use_certified_limits','working = working.checked_mul(2).ok_or(IntervalError::Overflow)?;', 'return value.regrid(precision, budget);'),
 ('integer_arithmetic','boundary_composition','empty_integer_products','_ => Ok(Self::empty()),','_ => Ok(Self::point(0)),')
]:
 p=co/'crates/hyperinterval/src'/f'{path}.rs'
 before=p.read_text()
 start=before.index('fn half_pi(' if path=='arctangent' else 'pub fn checked_sub(')
 pos=before.index(a,start)
 rel=f'crates/hyperinterval/tests/{target}.rs';test=co/rel
 revised=test.read_bytes()
 try:
    p.write_text(before[:pos]+before[pos:].replace(a,b,1))
    for tag,want in [('old',0),('new',101)]:
        test.write_bytes(sp.check_output(['git','-C',co,'show','HEAD:'+rel]) if tag=='old' else revised)
        name=s/'logs'/f'mutant-{path}-{tag}'
        with name.open('wb') as f:
            r=sp.run(['cargo','test','--locked','--all-features','-p','hyperinterval','--test',target,case],cwd=co,stdout=f,stderr=sp.STDOUT)
        txt=name.read_text()
        assert r.returncode==want and ('1 passed;' if tag=='old' else 'test result: FAILED. 0 passed; 1 failed;') in txt,(name,r.returncode,txt[-1800:])
 finally:
    test.write_bytes(revised);p.write_text(before)
