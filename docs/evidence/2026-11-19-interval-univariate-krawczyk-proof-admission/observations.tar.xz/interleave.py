from pathlib import Path
import ctypes as c,time,random,statistics,json,os,sys
s=Path(os.environ['s']);v=sys.argv[1];cpu=int(sys.argv[2]);os.sched_setaffinity(0,{cpu})
names=['primary',v];libs=[c.CDLL(str(s/'images'/(tag+'-pair.so'))) for tag in names]
funcs=[lib.measure for lib in libs]
for fn in funcs:
 fn.argtypes=[c.c_size_t];fn.restype=c.c_size_t
 assert fn(200)==3200
r=random.Random(20261119);out=[]
for block in range(240):
 order=[0,1,1,0] if r.getrandbits(1) else [1,0,0,1]
 rows=[[],[]]
 for i in order:
  start=time.thread_time_ns()
  n=funcs[i](40)
  elapsed=time.thread_time_ns()-start
  assert n==640
  rows[i].append(elapsed/40)
 out.append([statistics.mean(a) for a in rows])
ratios=[100*(b/a-1) for a,b in out]
resamples=sorted(statistics.median(r.choices(ratios,k=len(ratios))) for _ in range(5000))
result=dict(workload='owning 16-root-row benchmark fixture, fully materialized report and destructor, warmed setup, thread CPU ns; randomized ABBA/BAAB, 40 calls per sub-block',core=cpu,candidate=v,raw=out,median_paired_percent=statistics.median(ratios),bootstrap_95=[resamples[124],resamples[4874]])
(s/(v+'-interleaved-'+str(cpu)+'.json')).write_text(json.dumps(result)+'\n');print(result['median_paired_percent'],result['bootstrap_95'])
