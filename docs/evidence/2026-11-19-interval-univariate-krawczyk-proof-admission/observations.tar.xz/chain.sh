set -eu
cd "$s"
mkdir -p chain-run
for v in primary magnitude; do
 cp "$s/images/$v-successive" chain-run/successive_operations
 SUCCESSIVE_OPERATIONS_RAW="$s/chain-run/rows.tsv" taskset -c 18 ./chain-run/successive_operations '((A-B)-C)+D feedback' > "$s/logs/$v-matched-chain.log"
 mv chain-run/rows.tsv "$s/logs/$v-matched-successive.tsv"
done
