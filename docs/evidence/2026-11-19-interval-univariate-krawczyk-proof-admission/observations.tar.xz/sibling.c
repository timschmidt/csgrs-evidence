#include <stdint.h>
int main(void) {
    volatile uint64_t value = 1;
    for (;;) value = value * UINT64_C(6364136223846793005) + 1;
}
