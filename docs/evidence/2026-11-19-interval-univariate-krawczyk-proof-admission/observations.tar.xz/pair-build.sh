set -eu
cd "$s/bench-src"
for tag in "$@"; do
 git restore -- crates/hypersolve/src/interval.rs
 if test "$tag" != primary; then git apply "$s/$tag.patch"; fi
 CARGO_TARGET_DIR="$s/pair-target" CARGO_BUILD_JOBS=4 cargo +1.95.0 build --offline --release --manifest-path "$s/pair/Cargo.toml" > "$s/logs/pair-$tag" 2>&1
 cp "$s/pair-target/release/libmatched_proof.so" "$s/images/$tag-pair.so"
done
