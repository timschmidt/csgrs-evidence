import os,sys,subprocess,shutil
from pathlib import Path
s=Path(os.environ['s'])
for n,b in [('client','box-coverage-client'),('lifetime','radius-lifetime'),('usable','radius-usable'),('observer','proof-observer'),('stress-life','proof-stress-lifetime')]:
 subprocess.run(['cargo','+1.95.0','build','--release','--locked','--manifest-path',s/n/'Cargo.toml'],check=True)
 shutil.copy2(Path(os.environ['CARGO_TARGET_DIR'])/'release'/b,s/'images'/(sys.argv[1]+'-checked-'+n))
