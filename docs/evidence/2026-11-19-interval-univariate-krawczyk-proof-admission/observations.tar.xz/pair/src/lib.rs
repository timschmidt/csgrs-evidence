use hypersolve::{Constraint, Expr, Problem, SymbolId, VariableBall, certify_univariate_quadratic_krawczyk_box,context_from_problem};
use hyperreal::{Rational,Real};
use hyperlimit::PredicatePolicy;
fn r(v:i64)-> Real { Real::new(Rational::new(v)) }
fn univariate_quadratic_problem(row_count: usize) -> Problem {
    let x = Expr::symbol(SymbolId(0), "x");
    let mut problem = Problem::default();
    problem.add_variable("x", r(3));
    for index in 0..row_count {
        let scale = index as i64 + 1;
        problem.add_constraint(Constraint::equality(
            format!("quadratic {index}"),
            x.clone() * x.clone() * Expr::int(scale) - x.clone() * Expr::int(2 * scale)
                + Expr::int(scale),
        ));
    }
    problem
}

thread_local! {
    static STATE: (hypersolve::ProblemAnalysis<'static>,hypersolve::EvaluationContext) = {
        let problem=Box::leak(Box::new(univariate_quadratic_problem(16)));
        (problem.analyze(),context_from_problem(problem))
    };
}
#[unsafe(no_mangle)]
pub extern "C" fn measure(rounds: usize) -> usize {
    STATE.with(|(analysis,context)| {
        let mut count=0;
        for _ in 0..rounds {
            let report=certify_univariate_quadratic_krawczyk_box(analysis,context,&[VariableBall {symbol:SymbolId(0),radius:r(0)}],PredicatePolicy::APPROXIMATE_512);
            count+=std::hint::black_box(report).examined_rows;
        }
        count
    })
}
