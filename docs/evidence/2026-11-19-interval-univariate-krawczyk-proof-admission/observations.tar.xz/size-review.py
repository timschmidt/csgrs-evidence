from pathlib import Path
import sys,json
s=Path(__file__).resolve().parent
hist=s/'prior/history'
sys.path.insert(0,str(hist));from image_metrics import sizes
sys.path.insert(0,str(hist));from sizes import metrics
accounts={v['target']:v['metrics'] for v in json.loads((hist/'images-multi.json').read_bytes())}
stage=sys.argv[1]; rows=[]
for target,name in [('lifetime','lifetime'),('client','client'),('usable','usable'),('wasm','portable-krawczyk.wasm'),('all-certification','certification')]:
 a,b=[s/'images'/(v+'-'+name) for v in ('primary',stage)]
 if not b.is_file():continue
 if target=='all-certification':
    path=Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json');all_account=next(v for v in json.loads(path.read_bytes())['accounts'] if v['artifact']=='crates/hypersolve/benches/certification.rs')
    old,new=metrics(a),metrics(b)
    for m,k in [('file','file'),('code','text'),('functions','named_text')]:
        h=all_account['metrics'][k];caps=h['caps'];delta=new[m]-old[m]
        rows.append({'target':target,'metric':m,'previous':old[m],'candidate':new[m],'delta':delta,'incremental_pass':max(delta,0)<=min(caps['incremental_bytes'],old[m]*caps['incremental_percent']/100)})
 else:
    old,new=(metrics(x) if target=='wasm' else sizes(x) for x in (a,b))
    for m,h in accounts[target].items():
        p,n=old.get(m,0),new.get(m,0);i=max(n-p,0);caps=h['limits'];f=h['baseline']
        carry=h['cumulative']+max(0,p-h['measured'])
        rows.append(dict(target=target,metric=m,previous=p,candidate=n,delta=n-p,prior_observed=h['measured'],carry=carry,cumulative=carry+i,caps=caps,incremental_pass=i<=caps[0] and 100*i<=p*caps[1],cumulative_pass=carry+i<=caps[2] and 100*(carry+i)<=f*caps[3]))
print('positive incremental violations',[(r['target'],r['metric'],r['delta']) for r in rows if not r['incremental_pass']])
print('historic comparison positive cumulative violations',[(r['target'],r['metric'],r['carry'],r['delta']) for r in rows if r.get('cumulative_pass') is False and r['delta']>0])
print('changes',[(r['target'],r['metric'],r['delta']) for r in rows if r['delta']])
(s/f'{stage}-size.json').write_text(json.dumps(rows,indent=2)+'\n')
