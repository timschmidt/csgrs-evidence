set -eu
target=$1
campaign=$2
a=$3
b=$4
sibling(){
    tr , '\n' < "/sys/devices/system/cpu/cpu$1/topology/thread_siblings_list" | awk -v n="$1" '$1 != n {print $1}'
}
taskset -c "$(sibling "$a")" "$s/sibling" & sa=$!
taskset -c "$(sibling "$b")" "$s/sibling" & sb=$!
trap 'kill "$sa" "$sb" 2>/dev/null || true; wait "$sa" "$sb" 2>/dev/null || true' EXIT
bash "$s/time-variant.sh" "$target" "$campaign" "$a $b"
python3 "$s/timing-review.py" "$campaign" "$target" > "$s/$campaign.json"
