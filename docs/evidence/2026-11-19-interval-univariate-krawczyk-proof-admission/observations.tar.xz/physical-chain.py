import resource,sys,os,csv,json,random,statistics,subprocess
from pathlib import Path
s=Path(os.environ['s']);cpu=int(sys.argv[1]);os.sched_setaffinity(0,{cpu});tag=sys.argv[2];d=s/('physical-chain-'+str(cpu));d.mkdir(exist_ok=True);p=d/'successive_operations';raw=d/'rows.tsv';r=random.Random(2205)
binaries={v:(s/'images'/(v+'-successive')).read_bytes() for v in ('primary','magnitude')}
assert len(binaries['primary'])==len(binaries['magnitude'])
if not p.exists():
 p.write_bytes(binaries['primary'])
 p.chmod(0o755)
assert p.is_file() and not p.is_symlink()
reference=None
def run(v):
 global reference
 raw.unlink(missing_ok=True)
 with p.open('r+b',buffering=0) as f: assert f.write(binaries[v])==len(binaries[v])
 cpu0=resource.getrusage(resource.RUSAGE_CHILDREN)
 subprocess.run(['setarch',os.uname().machine,'-R',p,'((A-B)-C)+D feedback'],env=os.environ|{'SUCCESSIVE_OPERATIONS_RAW':str(raw)},cwd=d,stdout=subprocess.DEVNULL,check=True)
 cpu1=resource.getrusage(resource.RUSAGE_CHILDREN)
 cputime=(cpu1.ru_utime+cpu1.ru_stime-cpu0.ru_utime-cpu0.ru_stime)*1e9
 lines=raw.read_text().splitlines();assert lines[-1]=='# completed'
 rows=list(csv.DictReader((l for l in lines if not l.startswith('#')),delimiter='\t'))
 assert len(rows)==6 and all(k['outcome']=='certified' and k['manifold']=='yes' for k in rows)
 stable=[{k:val for k,val in row.items() if k not in ('step_ns','drop_ns','validation_ns')} for row in rows]
 if reference is None:reference=stable
 assert stable==reference
 return cputime,sum(int(row['step_ns'])+int(row['validation_ns'])+int(row['drop_ns']) for row in rows)
run('primary');run(tag);pairs=[]
for block in range(64):
 order=[0,1,1,0] if r.getrandbits(1) else [1,0,0,1];ns=[[],[]]
 for i in order:ns[i].append(run(['primary',tag][i]))
 pairs.append(ns)
out={'raw':pairs}
for j,key in enumerate(('process_cpu_ns','six_step_wall_ns')):
 ratios=[100*(statistics.mean(t[j] for t in b)/statistics.mean(t[j] for t in a)-1) for a,b in pairs]
 res=sorted(statistics.median(r.choices(ratios,k=len(ratios))) for _ in range(5000))
 out[key]=dict(median=statistics.median(ratios),ci95=[res[124],res[4874]])
(s/(tag+'-chain-same-inode-'+str(cpu)+'.json')).write_text(json.dumps(out)+'\n')
