import textwrap,os
from pathlib import Path
s=Path(os.environ['s'])
x=(s/'prior/inputs/krawczyk_univariate_certainty.rs').read_text()
x=x[x.index('fn quadratic_rows'):]
x=x.replace('fn quadratic_rows', 'fn univariate_rows').replace('= quadratic_rows', '= univariate_rows')
x=x.replace('hidden_positive()', '(crate::test_support::terminal_zero() + Real::from(2).powi_i64(-2048).unwrap())')
x=x.replace('let c = (crate::test_support::terminal_zero() + Real::from(2).powi_i64(-2048).unwrap());', '// The sine addition identity vanishes, leaving a positive residual of exactly 2^-2048.\n    let c = crate::test_support::terminal_zero() + Real::from(2).powi_i64(-2048).unwrap();').replace('std::cmp::Ordering::Equal','Ordering::Equal')
x=x.replace('Status::','QuadraticKrawczykStatus::')
m=s/'matrix-src/crates/hypersolve/src/interval.rs'
original=m.read_text();anchor='mod tests {\n    use super::*;'
assert original.count(anchor)==1
new=original.replace(anchor,anchor+'\n    use crate::{Constraint, Expr, Problem, context_from_problem};\n    use hyperlimit::{Certainty, PredicateOutcome};\n\n'+textwrap.indent(x.strip(),'    '))
(s/'unit-addition.rs').write_text(new)
