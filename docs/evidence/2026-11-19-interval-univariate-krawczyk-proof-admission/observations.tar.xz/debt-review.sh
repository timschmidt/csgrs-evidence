set -eu
cd "$s/src"
export CARGO_TARGET_DIR="$s/debt-target" CARGO_BUILD_JOBS=8
for tag in fixed primary magnitude; do
 git restore -- crates/hypersolve/src/interval.rs
 if test "$tag" = fixed;then git switch -q --detach c9f1f9ac5;else git switch -q --detach 6ec893190;fi
 if test "$tag" = magnitude;then git apply "$s/magnitude.patch";fi
 cargo +1.95.0 build --offline --release --locked --manifest-path "$s/lifetime/Cargo.toml" > "$s/logs/$tag-lifetime-debt-rebuild" 2>&1
 cmp "$CARGO_TARGET_DIR/release/radius-lifetime" "$s/images/$tag-checked-lifetime"
 sha256sum "$CARGO_TARGET_DIR/release/radius-lifetime"
done
