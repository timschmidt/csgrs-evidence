//! A point box and an exact contraction threshold distinguish terminal
//! rounding from a proof about the entire univariate box.
use hyperlimit::{Certainty, PredicateOutcome, PredicatePolicy, compare_reals};
use hyperreal::Real;
use hypersolve::{
    Constraint, Expr, Problem, QuadraticKrawczykStatus as Status, SymbolId, VariableBall,
    certify_univariate_quadratic_krawczyk_box, context_from_problem,
};

fn hidden_positive() -> Real {
    // The sine addition identity leaves exactly 2^-2048.
    (Real::e() + Real::one()).sin()
        - Real::e().sin() * Real::one().cos()
        - Real::e().cos() * Real::one().sin()
        + Real::from(2).powi_i64(-2048).unwrap()
}

fn quadratic_rows(constants: &[Real]) -> Problem {
    let mut problem = Problem::default();
    let x = Expr::anonymous_symbol(problem.add_variable("x", Real::zero()).into());
    for c in constants {
        problem.add_constraint(Constraint::equality(
            "quadratic",
            x.clone() * x.clone() + (x.clone() + Expr::real(c.clone())),
        ));
    }
    problem
}

#[test]
fn a_rootless_point_row_cannot_certify_the_batch() {
    let c = hidden_positive();
    assert!(matches!(
        compare_reals(&c, &Real::zero(), PredicatePolicy::APPROXIMATE_512),
        PredicateOutcome::Decided {
            value: std::cmp::Ordering::Equal,
            certainty: Certainty::Approximate,
            ..
        }
    ));
    // The middle row has residual c > 0 at the only candidate point.
    let problem = quadratic_rows(&[Real::zero(), c, Real::zero()]);
    let analysis = problem.analyze();
    let context = context_from_problem(&problem);
    let bounds = [VariableBall {
        symbol: SymbolId(0),
        radius: Real::zero(),
    }];
    for policy in [PredicatePolicy::APPROXIMATE_512, PredicatePolicy::STRICT] {
        let report =
            certify_univariate_quadratic_krawczyk_box(&analysis, &context, &bounds, policy);
        assert_eq!(report.rows.len(), 3);
        assert_eq!(report.rows[1].status, Status::Undecided);
        assert_eq!((report.examined_rows, report.certified_rows), (3, 2));
        assert!(!report.all_examined_rows_certified());
        for (index, row) in report.rows.iter().enumerate() {
            assert_eq!(row.constraint_index, index);
            if index != 1 {
                assert_eq!(row.status, Status::CertifiedUniqueRoot);
            }
        }
    }
}

#[test]
fn strict_contraction_distinguishes_the_boundary_from_an_unresolved_radius() {
    let p = quadratic_rows(&[Real::zero()]);
    let analysis = p.analyze();
    let context = context_from_problem(&p);
    // For x²+x at zero the derivative variation is 2r and the denominator is 1.
    let half = Real::from(2).powi_i64(-1).unwrap();
    for (radius, expected) in [
        (Real::zero(), Status::CertifiedUniqueRoot),
        (half.clone(), Status::NonContractiveDerivative),
        (half - hidden_positive(), Status::Undecided),
    ] {
        let bounds = [VariableBall {
            symbol: SymbolId(0),
            radius,
        }];
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            let report =
                certify_univariate_quadratic_krawczyk_box(&analysis, &context, &bounds, policy);
            assert_eq!(report.rows[0].status, expected);
            assert_eq!(
                report.certified_rows,
                usize::from(expected == Status::CertifiedUniqueRoot)
            );
        }
    }
}

#[cfg(feature = "dispatch-trace")]
#[test]
fn rational_point_keeps_the_certified_comparison_sequence() {
    use hyperreal::dispatch_trace;
    let p = quadratic_rows(&[Real::zero()]);
    let analysis = p.analyze();
    let context = context_from_problem(&p);
    let bounds = [VariableBall {
        symbol: SymbolId(0),
        radius: Real::zero(),
    }];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        dispatch_trace::reset();
        let report = dispatch_trace::with_recording(|| {
            certify_univariate_quadratic_krawczyk_box(&analysis, &context, &bounds, policy)
        });
        assert!(report.all_examined_rows_certified());
        let trace = dispatch_trace::take_trace();
        let counts: Vec<_> = trace
            .dispatch
            .iter()
            .filter(|e| e.layer == "hyperlimit" && e.operation == "compare_reals")
            .map(|e| (e.path, e.count))
            .collect();
        assert_eq!(counts, [("exact-rational", 4)]);
    }
}
