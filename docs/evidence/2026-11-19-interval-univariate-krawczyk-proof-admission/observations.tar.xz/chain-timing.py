import sys,os,csv,json,random,statistics,subprocess
from pathlib import Path
s=Path(os.environ['s']);cpu=int(sys.argv[1]);os.sched_setaffinity(0,{cpu});d=s/('chain-time-'+str(cpu));d.mkdir(exist_ok=True);p=d/'successive_operations';raw=d/'rows.tsv';r=random.Random(2205)
def run(v):
 raw.unlink(missing_ok=True)
 if p.exists():p.unlink()
 p.symlink_to(s/'images'/(v+'-successive'))
 subprocess.run(['setarch',os.uname().machine,'-R',p,'((A-B)-C)+D feedback'],env=os.environ|{'SUCCESSIVE_OPERATIONS_RAW':str(raw)},cwd=d,stdout=subprocess.DEVNULL,check=True)
 lines=raw.read_text().splitlines();assert lines[-1]=='# completed'
 rows=list(csv.DictReader((l for l in lines if not l.startswith('#')),delimiter='\t'))
 assert len(rows)==6 and all(k['outcome']=='certified' and k['manifold']=='yes' for k in rows)
 return sum(int(row['step_ns'])+int(row['validation_ns'])+int(row['drop_ns']) for row in rows)
run('primary');run('magnitude');pairs=[]
for block in range(32):
 order=[0,1,1,0] if r.getrandbits(1) else [1,0,0,1];ns=[[],[]]
 for i in order:ns[i].append(run(['primary','magnitude'][i]))
 pairs.append(ns)
ratios=[100*(statistics.mean(b)/statistics.mean(a)-1) for a,b in pairs]
res=sorted(statistics.median(r.choices(ratios,k=32)) for _ in range(2000))
(s/('chain-time-'+str(cpu)+'.json')).write_text(json.dumps(dict(raw=pairs,median=statistics.median(ratios),ci95=[res[49],res[1949]]))+'\n')
