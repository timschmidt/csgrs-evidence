set -eu
cd "$s/src"
for tag in fixed primary magnitude; do
 git restore -- crates/hypersolve/src/interval.rs crates/hypersolve/benchmarks.md
 if test "$tag" = fixed;then git switch -q --detach c9f1f9ac5;else git switch -q --detach 6ec893190;fi
 if test "$tag" = magnitude;then git apply "$s/magnitude.patch";fi
 CARGO_BUILD_JOBS=5 CARGO_TARGET_DIR="$s/owner" cargo +1.95.0 build --locked --release --all-features -p hypersolve --bench certification --test smoke --message-format=json-render-diagnostics > "$s/logs/registered-$tag.jsonl" 2> "$s/logs/registered-$tag"
 python3 - "$tag" <<'PY'
import json,os,sys,shutil
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1]
for row in map(json.loads,(s/'logs'/f'registered-{tag}.jsonl').read_text().splitlines()):
 if row.get('executable'):shutil.copy2(row['executable'],s/'images'/(tag+'-registered-'+row['target']['name']))
PY
 # Rebuild instrumented clients in a fresh target directory at identical source and manifest paths.
 CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR="$s/confirm-client" python3 "$s/confirm-clients.py" "$tag"
done
