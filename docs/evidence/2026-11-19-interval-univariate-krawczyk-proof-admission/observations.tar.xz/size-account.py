from pathlib import Path
import os,json,sys,hashlib,subprocess
s=Path(os.environ['s']);hist=s/'prior/history';sys.path.insert(0,str(hist))
from image_metrics import sizes
from sizes import metrics
history={r['target']:r['metrics'] for r in json.loads((hist/'images-multi.json').read_text())}
alpha=json.loads((s/'alpha-registered.json').read_text())
manifest=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
alloc=67108864;reserve=16777216
stages=('fixed','primary','magnitude')
def caps(m):return (1024,.5,4096,1) if m in ('function_union','functions') else (4096,1,16384,2)
def pages(p):
 rows=[]
 for h in [l.split() for l in subprocess.check_output(['readelf','-Wl',p],text=True).splitlines() if l.strip().startswith(('LOAD ','GNU_RELRO '))]:
  k=h[0];addr,n=int(h[2],16),int(h[5],16);rows.append(dict(kind=k,permissions=''.join(h[6:-1]),file=int(h[4],16),memory=n,start=addr//4096,end=(addr+n+4095)//4096,pages=(addr+n+4095)//4096-addr//4096))
 return rows
def account(n,m,f,b,c,carry,lim,absbase=False):
 inc=max(c-b,0);cum=carry+inc
 a,p,k,q=lim
 if absbase:stepbase=cumbase=4096
 else:stepbase=b;cumbase=f
 ic=min(a,(stepbase*p)//100);cc=min(k,(cumbase*q)//100)
 return dict(fixed=f,previous=b,retained=c,delta=c-b,percent_previous=round((c-b)*100/b,5) if b else None,carry=carry,step=inc,cumulative=cum,caps=lim,percentage_reference='4096 B page' if absbase else 'preceding and fixed metric',step_remaining=int(ic-inc),cumulative_remaining=int(cc-cum))
out={};fail=[]
def finish(n,row):
 out[n]=row
 for k,r in row['accounts'].items():
  if r['step_remaining']<0 or r['cumulative_remaining']<0:fail.append((n,k,r['step'],r['carry'],r['step_remaining'],r['cumulative_remaining']))
def baseline_carry(n,m,f,b):
 a=alpha.get(n+'-matched',{}).get('metrics',{}).get(m,{})
 h=history.get({'certification':'certification'}.get(n,n),{}).get(m,{})
 return max(a.get('cumulative_charge',0),h.get('cumulative',0),max(0,b-f))
def native(n,name):
 files=[s/'images'/(st+'-'+name) for st in stages]
 if not all(p.is_file() for p in files):return
 vals=[sizes(p) for p in files];pg=[pages(p) for p in files]
 row=dict(hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files],segments=pg,headroom=alloc-vals[-1]['file'],accounts={})
 assert row['headroom']>=reserve
 for m in sorted(set.union(*(set(v) for v in vals))):
  f,b,c=[v.get(m,0) for v in vals];h=history.get(n,{}).get(m,{});lim=h.get('limits',caps(m));carry=baseline_carry(n,m,f,b)
  special=False
  if m=='.relro_padding' and c>b and n in ('client','usable','lifetime','smoke','certification','observer','stress-life'):
   special=True
   strict=n in ('client','usable','lifetime')
   lim=(256,6.25,512 if strict else 4096,12.5 if strict else 100)
   for p in files[1:]:
    lines=subprocess.check_output(['readelf','-SW',p],text=True).splitlines();assert any('.relro_padding' in line and 'NOBITS' in line for line in lines)
   before,after=pg[1:]
   assert [r['permissions'] for r in before]==[r['permissions'] for r in after]
   assert all('WE' not in r['permissions'] for r in after)
   assert vals[2]['file']<=vals[1]['file'] and vals[2]['.text']<=vals[1]['.text']
   if strict:assert all(a['pages']<=b['pages'] for a,b in zip(after,before)),n
   else:
    assert sum(a['pages'] for a in after if a['kind']=='LOAD')<=sum(b['pages'] for b in before if b['kind']=='LOAD'),n
    assert after[-1]['file']<=before[-1]['file'],n
  if n=='lifetime' and m=='.relro_padding':
   assert c<=f and c<=b and carry<=3208 and vals[2]['file']<=vals[1]['file']
   assert all(a['pages']<=z['pages'] and a['permissions']==z['permissions'] for a,z in zip(pg[2],pg[0]))
   lim=(0,0,3208,78.3203125);special=True
  row['accounts'][m]=account(n,m,f,b,c,carry,lim,special)
 finish(n,row)
for n in ('lifetime','client','usable','observer','stress-life'):native(n,'checked-'+n)
for n in ('smoke','certification'):native(n,'registered-'+n)
for n,orig in [('portable-krawczyk.wasm','wasm'),('stress.wasm','stress.wasm')]:
 fs=[s/'images'/(st+'-'+n) for st in stages];vals=[metrics(p) for p in fs];row=dict(hashes=[v['sha256'] for v in vals],headroom=alloc-vals[-1]['file'],accounts={});assert row['headroom']>=reserve
 for m in ('file','code','functions'):
  f,b,c=[v[m] for v in vals];h=history.get(orig,{}).get(m,{});carry=max(h.get('cumulative',0),max(0,b-f));row['accounts'][m]=account(n,m,f,b,c,carry,h.get('limits',caps(m)))
 finish(n,row)
testref=manifest['univariate_krawczyk_algebraic_replay']['targets']
for suite in ('krawczyk_univariate_algebraic','krawczyk_multivariate_certainty'):
 for p in sorted(s.glob('release-'+suite+'-matrix-*.json')):
  target=p.name.split('-matrix-')[1].removesuffix('.json');tc,target=target.split('-',1);k=('1.99.0' if tc=='stable' else tc)+' '+target
  orig=s/p.name.replace('release-','primary-')
  if not orig.exists():orig=s/orig.name.replace(suite+'-','')
  b,c=[json.loads(q.read_text()) for q in (orig,p)]
  intro='introductory-wasi' if target.startswith('wasm') else 'introductory'
  f=testref[k] if 'univariate' in suite else json.loads((s/(intro+'-'+suite+'-matrix-'+tc+'-'+target+'.json')).read_text())
  name=k+'/'+suite
  row=dict(hashes=[v['sha256'] for v in (f,b,c)],headroom=alloc-c['file'],accounts={});assert row['headroom']>=reserve
  for m in ('file','code','functions'):
   limit=(49152,2,65536,3) if 'univariate' in suite else (4096,1,8192,2)
   carry=max(0,b[m]-f[m])
   if 'multivariate' in suite and tc=='1.95.0' and target.startswith('x86_64') and m=='file':
    initial=next(t['file_bytes'] for t in manifest['new_krawczyk_test_harnesses'] if t['artifact']==suite)
    carry=max(carry,b[m]-initial)
   row['accounts'][m]=account(name,m,f[m],b[m],c[m],carry,limit)
  finish(name,row)
(s/'final-account.json').write_text(json.dumps(out,indent=2)+'\n')
print('targets',len(out),'positive violations',fail)
for n,row in out.items():
 a=row['accounts'];print(n,a['file']['delta'],a['.relro_padding']['delta'] if '.relro_padding' in a else a['code']['delta'],row['headroom'])
