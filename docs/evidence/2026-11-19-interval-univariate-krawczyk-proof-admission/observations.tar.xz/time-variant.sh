set -eu
target=$1
campaign=$2
cpus=$3
for i in 1 2 3 4 5 6 7 8; do
 case $i in 1|4|6|7) first=$target;second=primary;; *) first=primary;second=$target;; esac
 read -r c1 c2 <<< "$cpus"
 for cpu in "$c1" "$c2"; do
    if test "$cpu" = "$c1"; then v=$first;else v=$second;fi
    CRITERION_HOME="$s/$campaign/$cpu/$i-$v" setarch "$(uname -m)" -R taskset -c "$cpu" "$s/images/$v-certification" --bench --noplot --warm-up-time 1 --measurement-time 3 --sample-size 50 'certify_univariate_quadratic_krawczyk_rows$' > "$s/logs/$campaign-$cpu-$i-$v" 2>&1 &
 done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
