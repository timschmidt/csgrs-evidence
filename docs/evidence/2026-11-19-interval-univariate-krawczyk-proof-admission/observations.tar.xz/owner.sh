set -eu
cd "$s/src"
tag=$1
CARGO_TARGET_DIR="$s/owner" cargo +1.95.0 build --locked --release -p hypersolve --all-features --bench certification --test krawczyk_univariate_algebraic --message-format=json-render-diagnostics > "$s/logs/$tag-owner.jsonl" 2>"$s/logs/$tag-owner"
python3 - "$tag" <<'PY'
import os,sys,json,shutil
from pathlib import Path
s=Path(os.environ['s'])
for row in map(json.loads,(s/f'logs/{sys.argv[1]}-owner.jsonl').read_text().splitlines()):
 if row.get('executable'):shutil.copy2(row['executable'],s/'images'/(sys.argv[1]+'-'+row['target']['name']))
PY
