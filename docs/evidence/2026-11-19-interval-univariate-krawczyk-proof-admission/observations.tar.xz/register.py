from pathlib import Path
import json,os,subprocess
s=Path(os.environ['s']);r=Path('/mnt/development/csgrs')
src=subprocess.check_output(['git','-C',r,'rev-parse','HEAD'],text=True).strip()
benefit='Row classification and its division fallback use certified comparisons on univariate quadratic boxes. The public point-box and strict-contraction controls return honest proof outcomes under both policies.'
key='univariate_krawczyk_row_certainty'
evidence='docs/evidence/2026-11-19-interval-univariate-krawczyk-proof-admission'
def append(name,data):
 p=r/'docs/research'/name;x=p.read_text();assert x.endswith('\n}\n') and key not in json.loads(x);block=json.dumps({key:data},indent=2,ensure_ascii=False)[1:-2]
 p.write_text(x[:-3]+','+block+'\n}\n');assert json.loads(p.read_text())[key]==data
a=json.loads((s/'final-account.json').read_text());assert len(a)==17
summary={}
for target,d in a.items():
 file=d['accounts']['file']
 v=dict(file_bytes=file['retained'],file_delta=file['delta'],file_cumulative_charge=file['cumulative'],free_bytes=d['headroom'])
 if '.relro_padding' in d['accounts']:
  m=d['accounts']['.relro_padding'];v['relro_padding_delta']=m['delta'];v['relro_padding_prior_charge']=m['carry'];v['relro_padding_cumulative_charge']=m['cumulative'];v['mapped_pages']=[sum(p['pages'] for p in seg if p['kind']=='LOAD') for seg in d['segments']];v['protected_pages']=[next(p['pages'] for p in seg if p['kind']=='GNU_RELRO') for seg in d['segments']]
 if 'code' in d['accounts']:
  v['code_step']=d['accounts']['code']['step'];v['function_step']=d['accounts']['functions']['step']
 summary[target]=v
append('interval-size-accounts.json',dict(source=src,previous='6ec893190',fixed='c9f1f9ac5',benefit=benefit,evidence=evidence,
 qualification_capacity_bytes=67108864,minimum_free_bytes=16777216,
 original_caps='Defaults for native allocated sections were 4096 bytes and 1% incremental, 16384 bytes and 2% cumulative, with separate function and file limits. All original dispositions are retained in caps.txt and the trial accounts.',
 native_padding_revision='Rust 1.95 Linux SHT_NOBITS .relro_padding only. For each full-report and allocator-usable client, at most 256 bytes incremental and 512 bytes cumulative (6.25% and 12.5% of one 4096-byte page). No additional pages in any PT_LOAD or GNU_RELRO, larger file, or changed permissions. The ordinary lifetime target reserves zero new padding. Its cumulative ceiling of 3208 bytes (78.3203125% of one link page) carries the entire pre-existing same-path fixed-to-control debit. Each retained segment must fit the fixed page count. The cumulative allowance is fully spent. For each of the registered certification benchmark, smoke suite, native trace observer and stress lifetime instrument, at most 256 and 4096 bytes (6.25% and 100% of one link page) with no growth in total load pages, initialized RELRO payload, executable code or final file. Retain all prior debits, including historical increases between fixed and previous. Record each segment separately. Firmware receives no allowance.',
 qualification_test_revision='For the new acceptance cases in krawczyk_univariate_algebraic alone, each of the four final native and WASI qualification images has a 49152-byte and 2% step cap, and a 65536-byte and 3% cumulative cap for file, code and defined-function size. The introductory 442615f77 image anchors each budget. The initial 16 KiB proposal and the separate test/combined library pilots are preserved. Shared fixture extraction left multivariate code and function sizes unchanged.',
 note='final-account.json contains effective byte/percentage caps, allocation flags and positive-only charges by target and metric. The 42 registered release targets have a separate feature-qualified accounting in all-budget-review.json. Nine upstream Hyperlattice interval targets had different features from the registry. A pre-existing positive fixed-to-control debit on a metric is preserved even when the current change allocates zero bytes there.',
 retained_fuzz_comparable=json.loads((s/'fuzz-comparable-accounts.json').read_text()),
 retained_fuzz_scope='The fixed 2026-11-15 driver lacks two replay workloads introduced at 8fa4de4a9. Preserve the measured change between the two suites and the raw historical comparison. Compile the original benchmark sources against fixed, preceding and repaired libraries, and the expanded suite separately against its introduction, preceding and repaired libraries. The standard incremental and cumulative caps hold for each completed suite. No new charge for code or functions in either comparison.',
 targets=summary))
m=json.loads((s/'semantics.json').read_text());append('interval-memory-accounts.json',dict(source=src,previous='6ec893190',fixed='c9f1f9ac5',benefit=benefit,evidence=evidence,scope='Rust 1.95 native Linux, single guarded 2 MiB thread. Full fixture construction, public API call, report materialization and destruction. Sixty ordinary and twelve stress workloads, cold/warm, two watermark patterns. Twenty-four fresh ordinary processes and forty-eight stress processes per version. Twelve processes per version also record glibc usable capacity.',caps='Per workload positive stack growth up to 128 bytes and 1% incremental, 256 bytes and 2% cumulative. Requested peak heap has zero growth allowance. Both peak requested heap and callee stack are limited to 16384 bytes, with 1 MiB reserved thread headroom. Approximate stress cases 7 and 10 use the same input’s previously completed strict contract. Raw same-policy results are retained.',
 ordinary=m['peak']['ordinary'],stress=m['peak']['stress'],minimum_remaining_thread_bytes=2071768,usable_capacity=dict(previous_peak=16536,retained_peak=m['usable_peak'],max_step_per_workload=m['maximum_usable_increment'],live_after_drop=0),accounts='magnitude-lifetime.json and magnitude-stress.json record per-workload fixed references, carried charges, increments and resulting charges. semantics.json records both allocator views.'))
