from pathlib import Path
import json,os,hashlib,subprocess
s=Path(os.environ['s']);j=lambda n:json.loads((s/n).read_text())
assert (s/'logs/checks-1.95.0').read_text().strip()=='1.95.0 checks passed'
assert (s/'logs/checks-stable').read_text().strip()=='stable checks passed'
a=j('final-account.json');assert len(a)==17
assert all(m['step_remaining']>=0 and m['cumulative_remaining']>=0 for r in a.values() for m in r['accounts'].values())
assert all(x['passes'] for n in ['magnitude-lifetime.json','magnitude-stress.json'] for x in j(n))
for v in ['fixed','primary','magnitude']:
 for n in ['client','usable','lifetime','observer','stress-life']:
  assert (s/'images'/(v+'-'+n)).read_bytes()==(s/'images'/(v+'-checked-'+n)).read_bytes()
for n,h in j('final-source-hashes.json').items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==h
assert len((s/'logs/debt-review').read_text().splitlines())==3
for n in (7,17):
 a=j('magnitude-chain-same-inode-'+str(n)+'.json')
 assert all(a[k]['ci95'][0]<=0<=a[k]['ci95'][1] for k in ('process_cpu_ns','six_step_wall_ns'))
assert all(r['change_percent']<0 for r in j('magnitude-confirm.json'))
for n in (3,16):
 assert j('magnitude-interleaved-'+str(n)+'.json')['bootstrap_95'][1]<0
assert '4212 Horner dispatch windows matched' in (s/'logs/wasi-suite').read_text()
print('17 target accounts, 15 rebuilt native client images, three independent debt controls, resource accounts, production/test hashes and cross-target checks verified.')
