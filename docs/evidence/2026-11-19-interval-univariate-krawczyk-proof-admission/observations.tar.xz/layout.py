import json,subprocess,sys,os
from pathlib import Path
s=Path(os.environ['s'])
def segs(p):
 out=[]
 for h in [l.split() for l in subprocess.check_output(['readelf','-Wl',p],text=True).splitlines() if l.strip().startswith(('LOAD ','GNU_RELRO '))]:
  addr,n=int(h[2],16),int(h[5],16)
  out.append(dict(kind=h[0],addr=addr,flags=''.join(h[6:-1]),file_bytes=int(h[4],16),mem_bytes=n,first_page=addr//4096,end_page=(addr+n+4095)//4096,pages=(addr+n+4095)//4096-addr//4096))
 return out
for stage in sys.argv[1:]:
 out={}
 for n in ['lifetime','client','usable','observer','stress-life']:
  out[n]={v:segs(s/'images'/(v+'-'+n)) for v in ['fixed','primary',stage]}
  print(n,[[x['pages'] for x in rows] for rows in out[n].values()])
 (s/(stage+'-layout.json')).write_text(json.dumps(out,indent=2)+'\n')
