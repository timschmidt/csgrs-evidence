import sys,os,json,hashlib,subprocess,struct
from pathlib import Path
s=Path(os.environ['s']);sys.path.insert(0,str(s/'prior/history'));from image_metrics import sizes
def data(p):
 b=p.read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
 start=struct.unpack_from('<Q',b,40)[0];width,count,names=struct.unpack_from('<HHH',b,58)
 sections=[struct.unpack_from('<IIQQQQIIQQ',b,start+i*width) for i in range(count)]
 t=sections[names];strings=b[t[4]:t[4]+t[5]]
 a={}
 for idx,k,flags,addr,off,n,*rest in sections:
  if flags&2 and k!=8:
   name=strings[idx:strings.index(0,idx)].decode();a[name]=hashlib.sha256(b[off:off+n]).hexdigest()
 return dict(file=hashlib.sha256(b).hexdigest(),sections=a,metrics=sizes(p),proof_symbols=[ln for ln in subprocess.check_output(['nm','-C',p],text=True).splitlines() if 'classify_quadratic_krawczyk_row' in ln or 'certify_univariate_quadratic_krawczyk_box' in ln])
a,b=[data(s/'images'/(v+'-successive')) for v in ('primary','magnitude')]
res=dict(previous=a,retained=b,changed_sections=[k for k in a['sections'] if a['sections'][k]!=b['sections'].get(k)])
(s/'downstream-review.json').write_text(json.dumps(res,indent=2)+'\n')
print('equal file',a['file']==b['file'],'sections',res['changed_sections'],'symbol counts',len(a['proof_symbols']),len(b['proof_symbols']))
