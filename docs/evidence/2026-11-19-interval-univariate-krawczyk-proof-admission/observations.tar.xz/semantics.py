from pathlib import Path
import os,json,ast,csv,statistics,hashlib
s=Path(os.environ['s']);l=s/'logs';tag='magnitude'
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def match(a,b):
 assert a.read_bytes()==b.read_bytes(),(a,b)
 return digest(a)
checks={name:match(l/a,l/b) for name,a,b in [('ordinary_reports_and_traces','trace-primary','trace-'+tag),('box_report_and_trace','primary-client-1',tag+'-client-1')]}
for stage in ('primary',tag):
 assert (l/('guest-'+stage)).read_text().split('passed ')[0]=='240 ordered calls in two fresh instances, zero imports, '
checks['wasm_ordinary_calls']=240
def rows(v):
 p=l/(v+'-matched-successive.tsv');x=p.read_text().splitlines();assert x[-1]=='# completed';a=list(csv.DictReader((i for i in x if not i.startswith('#')),delimiter='\t'));assert len(a)==6 and all(i['outcome']=='certified' and i['manifold']=='yes' for i in a);return a
a,b=map(rows,['primary',tag])
cols=[k for k in a[0] if k not in ['step_ns','drop_ns','validation_ns']]
assert [[r[k] for k in cols] for r in a]==[[r[k] for k in cols] for r in b]
def usable(v):
 out={}
 for p in l.glob(v+'-usable-*'):
  if p.suffix:continue
  for x in p.read_text().splitlines():
   i,q,u=x.split('|');out.setdefault(i,[]).append((ast.literal_eval(q),ast.literal_eval(u)))
 assert len(out)==60 and all(len(v)==12 for v in out.values())
 return {k:[[max(a[t][j] for a in v) for j in range(len(v[0][t]))] for t in range(2)] for k,v in out.items()}
u0,u1=usable('primary'),usable(tag)
# For every allocator, the last two entries are the peak and bytes still live after drop.
assert all(u1[i][0][-2] <= u0[i][0][-2] and u1[i][0][-1] == u1[i][1][-1] == 0 for i in u0)
# The existing contract caps peak requested bytes. Record allocator rounding separately per workload.
reg,stress=[json.loads((s/(tag+'-'+n+'.json')).read_text()) for n in ('lifetime','stress')]
assert all(r['passes'] for row in [reg,stress] for r in row)
summary={}
for n,ms in [('ordinary',reg),('stress',stress)]:
 st=[r for r in ms if r['key'][0].lower()=='stack']
 hp=[r for r in ms if r['key'][0].lower()!='stack']
 summary[n]=dict(peak_stack=max(r['candidate'] for r in st),peak_heap=max(r['candidate'][-2] for r in hp),max_stack_step=max(r['increment'] for r in st),max_stack_cumulative=max(r['cumulative'] for r in st))
out=dict(checks=checks,matched_chain_columns=cols,peak=summary,usable_peak=max(v[1][-2] for v in u1.values()),maximum_usable_increment=max(u1[i][1][-2]-u0[i][1][-2] for i in u0),usable_baseline=u0,usable_result=u1,records=dict(ordinary=60,stress=12))
(s/'semantics.json').write_text(json.dumps(out,indent=2)+'\n');print(summary,out['usable_peak'])
