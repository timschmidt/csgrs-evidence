from pathlib import Path
import sys,os,json,subprocess
from concurrent.futures import ThreadPoolExecutor
s=Path(os.environ['s']);tag=sys.argv[1];suite=os.environ.get('SUITE','krawczyk_univariate_algebraic')
sys.path.insert(0,str(s/'prior/history'))
from sizes import metrics
def run(job):
 tc,target=job
 wasi=target.startswith('wasm');dest=s/('matrix-'+tc+'-'+target);log=s/'logs'/(tag+'-'+suite+'-matrix-'+tc+'-'+target)
 env=os.environ|{'CARGO_TARGET_DIR':str(dest),'CARGO_BUILD_JOBS':'3'}
 if wasi:env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/('sysroot-'+tc))
 cmd=['cargo','+'+tc,'test','--locked','--release','-p','hypersolve','--all-features','--target',target,*(['--lib'] if suite=='hypersolve' else ['--test',suite]),'--no-run','--message-format=json-render-diagnostics']
 with Path(str(log)+'.compile').open('w') as err:
  output=subprocess.check_output(cmd,env=env,cwd=s/'matrix-src',stderr=err,text=True)
 p=next(Path(x['executable']) for x in map(json.loads,output.splitlines()) if x.get('executable'))
 with log.open('w') as f:
  run=([s/'node/node',s/'matrix-src/crates/hyperlattice-interval/conformance/run-wasi-test.mjs'] if wasi else [])+[p,*(['interval::tests::'] if suite=='hypersolve' else []),'--test-threads=1']
  result=subprocess.run(run,stdout=f,stderr=subprocess.STDOUT)
  f.flush()
  if tag=='red':
   assert result.returncode and ('2 failed;' in log.read_text() or (wasi and 'a_rootless_point_row' in log.read_text() and 'RuntimeError: unreachable' in log.read_text())),log.read_text()
  else:
   result.check_returncode()
 sizes=metrics(p)
 (s/(tag+'-'+suite+'-matrix-'+tc+'-'+target+'.json')).write_text(json.dumps(sizes)+'\n')
 print(tag,tc,target,sizes,flush=True)
targets=sys.argv[2:] or ['x86_64-unknown-linux-gnu','wasm32-wasip1']
with ThreadPoolExecutor(4) as ex:list(ex.map(run,[(tc,t) for tc in ('1.95.0','stable') for t in targets]))
