import os,json,sys
from pathlib import Path
from record import record
s=Path(os.environ['s']);tag='univariate-krawczyk-proof-admission'
roots=['logs','primary','preceding','fixed','candidate','prior/history','wasi-suite','paired','entry-paired','entry-confirm','borrowed-confirm','magnitude-confirm']
items=set()
for p in s.iterdir():
 if p.is_file() and p.suffix in ('.sh','.py','.rs','.json','.patch','.md','.txt','.c'):items.add(p)
for n in roots:
 for p in (s/n).rglob('*'):
  if p.is_file() and not(p.suffix in ('.html','.svg','.png')):items.add(p)
for n in ['client','portable-krawczyk','stress','lifetime','observer','stress-life','usable','pair']:
 d=s/n
 for p in d.rglob('*'):
  if p.is_file() and p.suffix in ('.rs','.toml','.lock','.cjs'):items.add(p)
for n in ('inputs/krawczyk_univariate_certainty.rs','stress-check.cjs','borrowed.patch','entry.patch','magnitude.patch'):
 items.add(s/'prior'/n)
items.add(s/'env')
for p in sorted(items):
 assert p.is_relative_to(s) and p.stat().st_size<7*1024**2,(p,p.stat().st_size)
 if p.stat().st_size>4 and p.open('rb').read(4) in (b'\x7fELF',b'\x00asm'):raise ValueError(p)
print(json.dumps(record(tag,sorted(items),'Archive univariate Krawczyk proof, resource and client qualification'),indent=2))
