set -eu
tag=$1
bash "$s/build.sh" "$tag" native >"$s/logs/$tag-native" 2>&1 &
a=$!
bash "$s/build.sh" "$tag" wasm >"$s/logs/$tag-wasm" 2>&1 &
b=$!
bash "$s/owner.sh" "$tag" &
c=$!
wait "$a"; wait "$b"; wait "$c"
"$s/images/$tag-observer" > "$s/logs/trace-$tag"
"$s/node/node" "$s/portable-krawczyk/check.cjs" "$s/images/$tag-portable-krawczyk.wasm" repaired > "$s/logs/guest-$tag"
"$s/node/node" "$s/prior/stress-check.cjs" "$s/images/$tag-stress.wasm" row > "$s/logs/stress-guest-$tag"
CARGO_TARGET_DIR="$s/owner" cargo +1.95.0 test --locked --release -p hypersolve --all-features --test krawczyk_univariate_certainty >"$s/logs/$tag-certainty" 2>&1
