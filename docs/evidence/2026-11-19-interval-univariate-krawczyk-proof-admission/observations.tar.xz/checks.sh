set -eu
tc=$1
cd "$s/matrix-src"
export CARGO_BUILD_JOBS=5 CARGO_TARGET_DIR="$s/matrix-$tc-x86_64-unknown-linux-gnu"
cargo +"$tc" fmt --all -- --check > "$s/logs/fmt-$tc" 2>&1
cargo +"$tc" clippy --locked -p hypersolve --all-features --all-targets -- -D warnings > "$s/logs/clippy-$tc" 2>&1
RUSTDOCFLAGS='-D warnings' cargo +"$tc" doc --locked -p hypersolve --all-features --no-deps > "$s/logs/docs-$tc" 2>&1
cargo +"$tc" test --locked --release --target x86_64-unknown-linux-gnu -p hypersolve --all-features --lib --tests > "$s/logs/solver-$tc" 2>&1
cargo +"$tc" test --locked --doc -p hypersolve --all-features > "$s/logs/solver-doc-$tc" 2>&1
if test "$tc" = 1.95.0; then cargo +"$tc" test --locked --release --target x86_64-unknown-linux-gnu -p hyperdynamics --all-features --lib --tests --examples > "$s/logs/dynamics-$tc" 2>&1; fi
printf '%s checks passed\n' "$tc"
