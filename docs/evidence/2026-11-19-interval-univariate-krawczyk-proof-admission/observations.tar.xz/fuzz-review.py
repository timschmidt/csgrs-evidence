from pathlib import Path
import json,os
s=Path(os.environ['s']);a=json.loads((s/'fuzz-budget-measurement.json').read_text());assert len(a)==6
db=json.loads(Path('docs/research/interval-size-accounts.json').read_text())
spec=next(x for x in db['accounts'] if x['artifact']=='crates/hypersolve/benches/retained_fuzz.rs')
assert all(set(row['features'])==set(spec['features']) for row in a.values())
out={}
for v,f in [('old','old-fixed'),('new','new-intro')]:
 b,c=v+'-previous',v+'-retained';metrics={}
 for k,registered in [('file','file'),('code','text'),('functions','named_text')]:
  x,y,z=[a[j]['metrics'][k] for j in (f,b,c)]
  lim=spec['metrics'][registered]['caps']
  prior=max(0,y-x,spec['metrics'][registered]['accepted_positive_growth_bytes'])
  i=max(0,z-y);u=prior+i
  bound=min(lim['incremental_bytes'],int(y*lim['incremental_percent']/100))
  bound2=min(lim['cumulative_bytes'],int(x*lim['cumulative_percent']/100))
  metrics[k]=dict(fixed=x,preceding=y,retained=z,delta=z-y,prior_charge=prior,increment=i,cumulative=u,step_remaining=bound-i,cumulative_remaining=bound2-u,pass_step=i<=bound,pass_cumulative=u<=bound2)
 out[v]=metrics
out['expanded_suite_at_introduction']={k:a['new-intro']['metrics'][k]-a['old-fixed']['metrics'][k] for k in ('file','code','functions')}
(s/'fuzz-comparable-accounts.json').write_text(json.dumps(out,indent=2)+'\n')
print(out)
