//! A zero-radius box contains exactly its center, so a single nonzero residual
//! at that point independently disproves any root certificate for the box.
use hyperlimit::{Certainty, PredicateOutcome, PredicatePolicy, compare_reals};
use hyperreal::Real;
use hypersolve::{
    AffineKrawczykStatus, Constraint, Expr, MultivariateQuadraticKrawczykStatus, Problem,
    QuadraticKrawczykStatus, SymbolId, VariableBall, certify_affine_krawczyk_box,
    certify_multivariate_quadratic_krawczyk_box, certify_univariate_quadratic_krawczyk_box,
    context_from_problem,
};

fn hidden_residual() -> Real {
    // The sine addition identity cancels exactly, leaving 2^-2048.
    (Real::e() + Real::one()).sin()
        - Real::e().sin() * Real::one().cos()
        - Real::e().cos() * Real::one().sin()
        + Real::from(2).powi_i64(-2048).unwrap()
}

fn problem(quadratic: bool, c: Real) -> Problem {
    let mut p = Problem::default();
    p.add_variable("x", Real::zero());
    let x = Expr::anonymous_symbol(SymbolId(0));
    let linear = x.clone() + Expr::real(c);
    let residual = if quadratic {
        x.clone() * x + linear
    } else {
        linear
    };
    p.add_constraint(Constraint::equality("residual", residual));
    p
}

#[test]
fn point_box_cannot_certify_a_nonzero_residual() {
    let c = hidden_residual();
    assert!(matches!(
        compare_reals(&c, &Real::zero(), PredicatePolicy::APPROXIMATE_512),
        PredicateOutcome::Decided {
            value: std::cmp::Ordering::Equal,
            certainty: Certainty::Approximate,
            ..
        }
    ));
    let a = problem(false, c.clone());
    let q = problem(true, c);
    let context = context_from_problem(&a);
    let (a, q) = (a.analyze(), q.analyze());
    let symbol = SymbolId(0);
    let bounds = [VariableBall {
        symbol,
        radius: Real::zero(),
    }];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let affine = certify_affine_krawczyk_box(&a, &context, &bounds, policy);
        let uni = certify_univariate_quadratic_krawczyk_box(&q, &context, &bounds, policy);
        let multi = certify_multivariate_quadratic_krawczyk_box(&q, &context, &bounds, policy);
        assert_eq!(
            (affine.status, uni.rows[0].status.clone(), multi.status),
            (
                AffineKrawczykStatus::UndecidedContainment { symbol },
                QuadraticKrawczykStatus::Undecided,
                MultivariateQuadraticKrawczykStatus::Undecided { symbol }
            )
        );
    }
}

#[test]
fn elimination_preserves_a_nonzero_factor_below_terminal_precision() {
    // The unique root is (1, -c), outside [-1, 1] x {0}.
    let mut problem = Problem::default();
    problem.add_variable("x", Real::zero());
    problem.add_variable("y", Real::zero());
    let x = Expr::anonymous_symbol(SymbolId(0));
    let y = Expr::anonymous_symbol(SymbolId(1));
    problem.add_constraint(Constraint::equality("x=1", x.clone() - Expr::int(1)));
    problem.add_constraint(Constraint::equality(
        "c*x+y=0",
        Expr::real(hidden_residual()) * x + y,
    ));
    let context = context_from_problem(&problem);
    let analysis = problem.analyze();
    let bounds = [
        VariableBall {
            symbol: SymbolId(0),
            radius: Real::one(),
        },
        VariableBall {
            symbol: SymbolId(1),
            radius: Real::zero(),
        },
    ];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        assert_eq!(
            certify_affine_krawczyk_box(&analysis, &context, &bounds, policy).status,
            AffineKrawczykStatus::UndecidedContainment {
                symbol: SymbolId(1)
            },
            "{policy:?}"
        );
    }
}

#[test]
fn point_box_distinguishes_zero_from_a_certified_tiny_residual() {
    let symbol = SymbolId(0);
    let bounds = [VariableBall {
        symbol,
        radius: Real::zero(),
    }];
    for (value, is_zero) in [
        (Real::zero(), true),
        (Real::from(2).powi_i64(-2048).unwrap(), false),
    ] {
        let affine = problem(false, value.clone());
        let quadratic = problem(true, value);
        let context = context_from_problem(&affine);
        let (affine, quadratic) = (affine.analyze(), quadratic.analyze());
        let run = |policy| {
            (
                certify_affine_krawczyk_box(&affine, &context, &bounds, policy),
                certify_univariate_quadratic_krawczyk_box(&quadratic, &context, &bounds, policy),
                certify_multivariate_quadratic_krawczyk_box(&quadratic, &context, &bounds, policy),
            )
        };
        let strict = run(PredicatePolicy::STRICT);
        assert_eq!(strict, run(PredicatePolicy::APPROXIMATE_512));
        let (a, q, m) = strict;
        assert_eq!(q.examined_rows, 1);
        assert_eq!(q.certified_rows, usize::from(is_zero));
        let expected = if is_zero {
            (
                AffineKrawczykStatus::CertifiedUniqueRoot,
                QuadraticKrawczykStatus::CertifiedUniqueRoot,
                MultivariateQuadraticKrawczykStatus::CertifiedUniqueRoot,
            )
        } else {
            (
                AffineKrawczykStatus::RootOutsideBox { symbol },
                QuadraticKrawczykStatus::ImageOutsideBox,
                MultivariateQuadraticKrawczykStatus::ImageOutsideBox { symbol },
            )
        };
        assert_eq!((a.status, q.rows[0].status.clone(), m.status), expected);
    }
}

#[test]
fn strict_contraction_requires_a_certified_order() {
    // For x²+x at zero, the image radius is r² and the derivative variation is 2r.
    // At r = 1/2 - 2^-2048 the image is contained and the map is contractive.
    let problem = problem(true, Real::zero());
    let context = context_from_problem(&problem);
    let analysis = problem.analyze();
    let symbol = SymbolId(0);
    let bounds = [VariableBall {
        symbol,
        radius: Real::from(2).powi_i64(-1).unwrap() - hidden_residual(),
    }];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let uni = certify_univariate_quadratic_krawczyk_box(&analysis, &context, &bounds, policy);
        let multi =
            certify_multivariate_quadratic_krawczyk_box(&analysis, &context, &bounds, policy);
        assert_eq!(
            (uni.rows[0].status.clone(), multi.status),
            (
                QuadraticKrawczykStatus::Undecided,
                MultivariateQuadraticKrawczykStatus::Undecided { symbol }
            ),
            "{policy:?}"
        );
    }
}

#[cfg(feature = "dispatch-trace")]
#[test]
fn exact_point_box_keeps_each_packages_comparison_count() {
    use hyperreal::dispatch_trace;

    fn check<T>(expected: u64, certify: impl FnOnce() -> T) {
        dispatch_trace::reset();
        let _report = dispatch_trace::with_recording(certify);
        let trace = dispatch_trace::take_trace();
        let comparisons: Vec<_> = trace
            .dispatch
            .iter()
            .filter(|entry| entry.layer == "hyperlimit" && entry.operation == "compare_reals")
            .map(|entry| (entry.path, entry.count))
            .collect();
        assert_eq!(comparisons, [("exact-rational", expected)]);
    }

    let a = problem(false, Real::zero());
    let q = problem(true, Real::zero());
    let context = context_from_problem(&a);
    let (a, q) = (a.analyze(), q.analyze());
    let bounds = [VariableBall {
        symbol: SymbolId(0),
        radius: Real::zero(),
    }];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        check(3, || {
            certify_affine_krawczyk_box(&a, &context, &bounds, policy)
        });
        check(4, || {
            certify_univariate_quadratic_krawczyk_box(&q, &context, &bounds, policy)
        });
        check(4, || {
            certify_multivariate_quadratic_krawczyk_box(&q, &context, &bounds, policy)
        });
    }
}
