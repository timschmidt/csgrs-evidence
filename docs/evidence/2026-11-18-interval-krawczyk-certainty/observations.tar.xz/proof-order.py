from pathlib import Path
import re
p=Path('crates/hypersolve/src/interval.rs')
s=p.read_text()
s=s.replace('    let policy = policy.certified_only();\n','')
# All production comparisons in interval.rs feed bounds or certified reports.
t=s.index('#[cfg(test)]\nmod tests')
a=s[:t]
a,n=re.subn(r'compare_reals\(([^;\n]*?), policy(?:\.certified_only\(\))?\)\.value\(\)',r'certified_order(\1, policy)',a)
assert n==15,n
i=a.index('fn validate_variable_balls(')
a=a[:i]+'''// Bounds, pivots and containment verdicts in these reports require a proof of order.
fn certified_order(left: &Real, right: &Real, policy: PredicatePolicy) -> Option<Ordering> {
    compare_reals(left, right, policy.certified_only()).value()
}

'''+a[i:]
p.write_text(a+s[t:])
