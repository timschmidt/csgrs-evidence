set -eu
s=/dev/shm/interval-krawczyk-certainty
b=/dev/shm/interval-box-coverage
cd "$b/wasm-repo"
git apply -R "$s/order.patch"
bash "$s/observe.sh" before > "$s/logs/before-observer-build" 2>&1 &
pid=$!
bash "$s/usable.sh" before > "$s/logs/before-usable-build" 2>&1
wait "$pid"
cmp "$s/logs/before-observer" "$s/logs/order-observer"
python3 "$s/local-proof.py"
. /dev/shm/interval-bisection/env
cargo +1.95.0 fmt -p hypersolve
git diff -- crates/hypersolve/src/interval.rs > "$s/local.patch"
for k in bench wasm lifetime;do bash "$s/measure.sh" local "$k" > "$s/logs/local-$k-build" 2>&1 & done
bash "$s/observe.sh" local > "$s/logs/local-observer-build" 2>&1 &
bash "$s/usable.sh" local > "$s/logs/local-usable-build" 2>&1 &
fail=0
for j in $(jobs -p);do wait "$j" || fail=1;done
test "$fail" -eq 0
cmp "$s/logs/before-observer" "$s/logs/local-observer"
