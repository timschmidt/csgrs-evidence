from pathlib import Path
import sys,json
s=Path(__file__).parent;b=Path('/dev/shm/interval-box-coverage')
base=(s/'analyze.py').read_text()
for v in sys.argv[1:]:
 print(v,flush=True)
 exec(base.replace("['before','candidate']",repr(['before',v])).replace("write('memory.json'","write('memory-"+v+".json'").replace("write('size-'+prog","write('size-"+v+"-'+prog"))
