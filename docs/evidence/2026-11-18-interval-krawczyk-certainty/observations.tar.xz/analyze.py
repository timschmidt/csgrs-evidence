from pathlib import Path
import json,ast,sys
s=Path(__file__).parent
b=Path('/dev/shm/interval-box-coverage')
sys.path.insert(0,str(b))
from image_metrics import sizes
def write(f,x): (s/f).write_text(json.dumps(x,indent=2)+'\n')
def collect(v):
 r={}
 files=list((s/'logs').glob(v+'-life-*'));assert len(files)==24
 for p in files:
  for l in p.read_text().splitlines():
   typ,i,rest=l.split('|',2)
   if typ=='STACK':
    w,pattern,n=rest.split('|');k=(typ,int(i),int(w));data=int(n)
   else:k=(typ,int(i));data=ast.literal_eval(rest)
   r.setdefault(k,[]).append(data)
 return {k:max(vals) if k[0]=='STACK' else tuple(map(max,zip(*vals))) for k,vals in r.items()}
a,c=map(collect,['before','candidate'])
h={(r['workload'],int(r['temperature']=='warm')):r for r in json.loads((b/'memory-rows.json').read_text())}
out=[]
for k,v in a.items():
 n=c[k]
 if k[0]=='STACK':
  old=h[k[1:]];pos=max(0,n-v);cum=pos+old['cumulative_charge_bytes']
  out.append(dict(key=k,base=old['fixed'],previous=v,prior_observed=old['retained'],after=n,prior_charge=old['cumulative_charge_bytes'],charge=pos,cumulative=cum,passes=pos<=128 and pos*100<=v and cum<=256 and cum*100<=2*old['fixed'] and n<=16384))
 else: out.append(dict(key=k,previous=v,after=n,passes=n[-1]==v[-1]==0 and n[-2]<=v[-2]<=16384))
write('memory.json',out)
for typ in ['STACK','HEAP']:
 rows=[r for r in out if r['key'][0]==typ];fail=[r for r in rows if not r['passes']]
 print(typ,len(rows),len(fail),fail[:2])
for prog in ['certification','lifetime']:
 a,c=[sizes(s/'images'/(v+'-'+prog)) for v in ['before','candidate']]
 rows={k:(v,c[k],c[k]-v) for k,v in a.items() if c[k]!=v};write('size-'+prog+'.json',rows); print(prog,rows)
