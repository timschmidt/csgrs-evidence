from pathlib import Path
import ast,hashlib,json,sys
s=Path(__file__).parent
b=Path('/dev/shm/interval-box-coverage')
sys.path.insert(0,str(b))
from image_metrics import sizes
scope={'__file__':str(b/'sizes.py')}
exec((b/'sizes.py').read_text().split('out={}')[0],scope)
wasm=scope['wasm']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,rows): (s/name).write_text(json.dumps(rows,indent=2)+'\n')
def metrics(p):
 return {'file':p.stat().st_size,'code':wasm(p)} if p.suffix=='.wasm' else sizes(p)
def budget(kind,metric):
 if kind=='wasm':return (1024,5,4096,10)
 if metric=='function_union':return (1024,.5,4096,1)
 return (4096,1,16384,2)
def imgs(v):
 rows=[]
 for new,old in [('client','client'),('certification','copy-certification'),('wasm','kraw.wasm'),('lifetime','lifetime'),('usable','usable')]:
  path=lambda v:s/'images'/(v+'.wasm' if new=='wasm' else v+'-'+new)
  if not path(v).exists():continue
  files=[b/'images'/(prefix+'-'+old) for prefix in ['fixed','before','all-radii']]+[path('before'),path(v)]
  hist=[metrics(p) for p in files];result={}
  for k,x in hist[0].items():
   vals=[h[k] for h in hist];d=max(0,vals[-1]-vals[-2]);c=sum(max(0,z-y) for y,z in zip(vals,vals[1:]));bi,pi,bc,pc=budget(new,k)
   result[k]={'baseline':x,'last_retained':vals[2],'previous':vals[-2],'measured':vals[-1],'incremental':d,'cumulative':c,'remaining_cumulative_bytes':bc-c,'remaining_cumulative_percent':pc-100*c/x if x else None,'limits':[bi,pi,bc,pc],'passed':d<=bi and d*100<=pi*vals[-2] and c<=bc and c*100<=pc*x}
  rows.append(dict(target=new,metrics=result,sha256=[digest(p) for p in files],headroom=64*2**20-files[-1].stat().st_size))
 write('images-'+v+'.json',rows)
 for row in rows:print(v,row['target'],'file',row['metrics']['file']['measured']-row['metrics']['file']['previous'],'fails',[(k,r['incremental']) for k,r in row['metrics'].items() if not r['passed']])
def life(v,group):
 out={}
 for p in (s/'logs').glob(v+'-'+group+'-life-*'):
  for l in p.read_text().splitlines():
   a=l.split('|')
   if a[0]=='STACK': k=('stack',int(a[1]),int(a[2]));n=int(a[-1])
   else:k=('heap',int(a[1]));n=ast.literal_eval(a[2])
   out.setdefault(k,[]).append(n)
 return {k:(max(nums) if k[0]=='stack' else tuple(map(max,zip(*nums)))) for k,nums in out.items()}
def stress(v):
 h,p,c=[life(t,'stress') for t in ['fixed','before',v]];rows=[]
 assert len(h)==len(p)==len(c)==36
 for key,n in sorted(c.items()):
  case=key[1]%6
  same=(key[0],case,*key[2:]) if v!='multi' or case in (2,5) else key
  fixed,prev=h[same],p[same]
  if key[0]=='stack':
   d=max(0,n-prev);cum=max(0,prev-fixed)+d
   passes=d<=128 and d*100<=prev and cum<=256 and cum*100<=2*fixed and n<=16384
  else:
   d=max(0,n[-2]-prev[-2]);cum=d+max(0,prev[-2]-fixed[-2]);passes=cum==0 and n[-2]<=16384 and n[-1]==0
  rows.append(dict(key=key,fixed_reference=fixed,previous_reference=prev,previous_same_policy=p[key],candidate=n,incremental_charge=d,cumulative_charge=cum,passes=passes))
 write('stress-memory-'+v+'.json',rows)
 print(v,'stress fails',[(r['key'],r['incremental_charge']) for r in rows if not r['passes']])
if __name__=='__main__':
 for v in sys.argv[1:]:
  imgs(v)
  if (s/'logs'/(v+'-stress-life-24')).exists():stress(v)
