set -eu
s=/dev/shm/interval-krawczyk-certainty
for i in $(seq 25 48);do
 for v in fixed before entry;do
  setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-stress-life" > "$s/logs/$v-stress-life-$i" 2>"$s/logs/$v-stress-guard-$i"
 done
done
