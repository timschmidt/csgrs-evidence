set -eu
s=/dev/shm/interval-krawczyk-certainty
for v in before candidate; do
 for k in wasm lifetime bench; do bash "$s/measure.sh" "$v" "$k" > "$s/logs/$v-$k-build" 2>&1 & done
 fail=0
 for j in $(jobs -p); do wait "$j" || fail=1; done
 test "$fail" -eq 0
 if test "$v" = before; then git -C /dev/shm/interval-box-coverage/wasm-repo apply "$s/proof.patch"; fi
done
