from pathlib import Path
import sys,json,statistics
s=Path(__file__).parent;d=s/('timing-'+sys.argv[1]); groups={}
for run in sorted(d.iterdir()):
 for f in run.glob('*/new/estimates.json'):
  val=json.loads(f.read_text())['median']['point_estimate']
  groups.setdefault(f.parents[1].name,{}).setdefault(run.name.split('-',1)[1],[]).append(val)
o=[]
for name,values in sorted(groups.items()):
 x=values['before'];y=values[sys.argv[1]]
 if len(x)!=2 or len(y)!=2:continue
 row=dict(workload=name,before_ns=x,candidate_ns=y,relative_percent=100*(statistics.mean(y)/statistics.mean(x)-1),paired=[100*(a/b-1) for a,b in zip(y,[x[0],x[1]])])
 o.append(row);print(name,round(row['relative_percent'],2),[round(v,2) for v in row['paired']])
(s/('times-'+sys.argv[1]+'.json')).write_text(json.dumps(o,indent=2)+'\n')
