set -eu
s=/dev/shm/interval-krawczyk-certainty
b=/dev/shm/interval-box-coverage
cd "$b/wasm-repo"
git apply -R "$s/local.patch"
. /dev/shm/interval-bisection/env
for v in proof receipt; do
 python3 "$s/comparisons.py" "$v"
 cargo +1.95.0 fmt -p hypersolve
 git diff -- crates/hypersolve/src/interval.rs > "$s/$v-compare.patch"
 for k in wasm bench lifetime; do bash "$s/measure.sh" "$v" "$k" > "$s/logs/$v-$k-build" 2>&1 & done
 bash "$s/observe.sh" "$v" > "$s/logs/$v-observer-build" 2>&1 &
 bash "$s/usable.sh" "$v" > "$s/logs/$v-usable-build" 2>&1 &
 fail=0
 for j in $(jobs -p); do wait "$j" || fail=1; done; test "$fail" -eq 0
 cmp "$s/logs/before-observer" "$s/logs/$v-observer"
 git apply -R "$s/$v-compare.patch"
done
