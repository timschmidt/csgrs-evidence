from pathlib import Path
import sys
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
cases={'affine':'krawczyk','univariate_quadratic':'quadratic_krawczyk','multivariate_quadratic':'multivariate_quadratic_krawczyk'}
for name in sys.argv[1:]:
 i=s.index('pub fn certify_'+name+'_krawczyk_box(');j=s.index(' {\n',i)+3
 s=s[:j]+'    let policy = policy.certified_only();\n'+s[j:]
 i=s.index('fn validate_'+cases[name]+'_variable_balls(');j=s.index('\n}',i)
 s=s[:i]+s[i:j].replace('policy.certified_only()', 'policy')+s[j:]
p.write_text(s)
