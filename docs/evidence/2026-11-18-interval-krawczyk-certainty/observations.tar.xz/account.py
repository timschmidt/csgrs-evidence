import json,hashlib,ast
from pathlib import Path
s=Path(__file__).parent;root=Path.cwd()
name='certified-multivariate-krawczyk-proof';source=(s/'multi-commit').read_text().strip();prev='471560adebf2d050a50e057f1a142d107ce20aee';evidence='docs/evidence/2026-11-18-interval-krawczyk-certainty'
def read(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=root/'docs/research/interval-size-accounts.json';d=read(p);assert not any(a.get('id')==name for a in d['accepted_changes'])
d['accepted_changes'].append(dict(id=name,benefit='Prevents terminal approximation from supplying multivariate Krawczyk containment, contraction, or inverse evidence.',sources=['crates/hypersolve/src/interval.rs'],production_implementation_changed=True,source_snapshot=source,evidence=evidence))
w=next(r for r in read(s/'images-multi.json') if r['target']=='wasm')
ms={}
for k,r in w['metrics'].items():
 ms[k]=dict(baseline=r['baseline'],previous_retained=r['previous'],retained=r['measured'],incremental_growth_bytes=r['incremental'],incremental_growth_percent=round(100*r['incremental']/r['previous'],6),accepted_positive_growth_bytes=r['cumulative'],remaining_cumulative_bytes=r['remaining_cumulative_bytes'],remaining_cumulative_percent=round(r['remaining_cumulative_percent'],6),caps=d['existing_artifacts']['wasm_final_file_and_code'],passes_both_caps=r['passed'])
d['accounts'].append(dict(artifact='interval-box qualification/kraw.wasm',role='Complete linked solver report client',target='wasm32-unknown-unknown',toolchain='Rust 1.95.0',features='default',profile='release',baseline_commit=d['baseline_commit'],previous_commit=prev,source_snapshot=source,baseline_sha256=w['sha256'][0],previous_sha256=w['sha256'][-2],retained_sha256=w['sha256'][-1],metrics=ms,headroom=f'{w["headroom"]} bytes free within 64 MiB, 16 MiB required.',evidence=evidence))
d['new_krawczyk_test_harnesses']=[]
for f,test,rev in [('primary-oracle','krawczyk_affine_oracle',(s/'oracle-commit').read_text().strip()),('primary-proof-test','krawczyk_multivariate_certainty',source)]:
 image=s/'images'/f;n=image.stat().st_size
 d['new_krawczyk_test_harnesses'].append(dict(artifact=test,target='x86_64-unknown-linux-gnu',toolchain='Rust 1.95.0 release',features='hypersolve --all-features',source_snapshot=rev,file_bytes=n,sha256=sha(image),qualification_capacity_bytes=64*2**20,required_free_bytes=16*2**20,remaining_bytes=64*2**20-n,evidence=evidence))
write(p,d)
p=root/'docs/research/interval-memory-accounts.json';m=read(p);assert not any(a.get('id')==name for a in m['accounts'])
m['status']='Admitted native stack growth is accounted separately for each target, workload and temperature.'
rows=read(s/'memory-multi.json');regs=[];charges=[]
for r in rows:
 if r['key'][0]=='heap'.upper():assert r['passes'];continue
 i,w=r['key'][1:];denom=min(r['prior_observed'],r['previous']);pos=max(0,r['after']-denom);cum=r['prior_charge']+pos
 assert pos<=128 and pos*100<=denom and cum<=256 and cum*100<=2*r['base'] and r['after']<=16384
 info=dict(workload=i,temperature='warm' if w else 'cold',fixed=r['base'],previous_recorded=r['prior_observed'],previous_remeasured=r['previous'],candidate=r['after'],incremental_charge_bytes=pos,cumulative_charge_bytes=cum,remaining_cumulative_bytes=256-cum,remaining_cumulative_percent=round(2-100*cum/r['base'],6))
 regs.append(info)
 if cum:charges.append(info)
write(s/'regular-stack-accounts.json',regs)
def headroom(pattern):return min(int(l.split()[-1]) for p in (s/'logs').glob(pattern) for l in p.read_text().splitlines())
stress=read(s/'stress-memory-multi.json');assert all(r['passes'] for r in stress)
ss=[]
for r in stress:
 if r['key'][0]!='stack':continue
 i,w=r['key'][1:]
 z=dict(workload=i,temperature='warm' if w else 'cold',fixed_completed=r['fixed_reference'],previous_completed=r['previous_reference'],previous_same_policy=r['previous_same_policy'],candidate=r['candidate'],incremental_charge_bytes=r['incremental_charge'],cumulative_charge_bytes=r['cumulative_charge'],remaining_cumulative_bytes=256-r['cumulative_charge'],remaining_cumulative_percent=round(2-100*r['cumulative_charge']/r['fixed_reference'],6))
 ss.append(z)
write(s/'stress-stack-accounts.json',ss)
m['accounts'].append(dict(id=name,source_snapshot=source,previous_commit=prev,baseline_commit=m['baseline_commit'],target='Rust 1.95.0 x86_64-unknown-linux-gnu release, one guarded Linux worker',call_boundary='Construct problem and bounds, execute certificate, inspect result and drop output. Two watermark patterns, cold and warm workers. Allocation counts and traffic are recorded separately from observed live bytes.',stack_caps=dict(incremental_bytes=128,incremental_percent=1,cumulative_bytes=256,cumulative_percent=2,maximum_callee_stack_bytes=16384,thread_capacity_bytes=2097152,required_free_bytes=1048576),heap_caps=dict(incremental_peak_requested_bytes=0,cumulative_peak_requested_bytes=0,maximum_peak_requested_bytes=16384,retained_after_drop_bytes=0),regular_workloads=dict(workload_key='Same 60 keys as certified-variable-radius-domain',processes_per_revision=24,positive_increment_rows=sum(r['incremental_charge_bytes']>0 for r in regs),previous_charge_rule='Carry prior positive charges. Charge any positive difference from either the archived previous maximum or the remeasurement of the same binary.',minimum_observed_free_bytes=headroom('multi-guard-*'),peak_requested_bytes=max(r['after'][-2] for r in rows if r['key'][0]=='HEAP'),peak_stack_bytes=max(r['candidate'] for r in regs),charged_stack_rows=charges,all_rows='regular-stack-accounts.json'),stress_workloads=dict(workload_key='i = 6*policy + case; policies STRICT/APPROXIMATE_512. Cases 0..5 are affine/univariate/multivariate point containment, coupled affine elimination, univariate/multivariate contraction.',processes_per_revision=48,comparison='For corrected cases 8 and 11 use the same input and previously completed STRICT proof. Record the raw prior same-policy result separately. Other keys compare identical policies, including unchanged unsupported proof behavior in the other certifiers.',minimum_observed_free_bytes=headroom('multi-stress-guard-*'),peak_requested_bytes=max(r['candidate'][-2] for r in stress if r['key'][0]=='heap'),peak_stack_bytes=max(r['candidate'] for r in ss),charged_stack_rows=[r for r in ss if r['cumulative_charge_bytes']],all_rows='stress-stack-accounts.json'),evidence=evidence))
write(p,m)
