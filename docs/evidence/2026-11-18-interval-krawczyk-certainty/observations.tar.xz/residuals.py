from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
start=s.index('    let mut residual_values = Vec::with_capacity(variable_count);',s.index('pub fn certify_multivariate_quadratic_krawczyk_box'))
end=s.index('    let mut variables = Vec::with_capacity(variable_count);',start)
a=s[start:end]
i=a.index('    let residual_payloads = rows');a=a[:i]+'\n'
a=a.replace('let mut residual_values','let mut residual_payloads').replace('    let mut remainder_radii = Vec::with_capacity(variable_count);\n','').replace('        residual_values.push(residual);\n','')
a=a.replace('        remainder_radii.push(remainder_radius);','''        residual_payloads.push(MultivariateQuadraticKrawczykResidual {
            constraint_index: *constraint_index,
            residual,
            remainder_radius,
        });''')
s=s[:start]+a+s[end:]
s=s.replace('&inverse[variable_index], &residual_values','&inverse[variable_index], &residual_payloads').replace('&inverse[variable_index], &remainder_radii','&inverse[variable_index], &residual_payloads')
i=s.index('fn negative_matrix_vector_entry(');j=s.index('fn contraction_row_bound',i)
a=s[i:j].replace('values: &[Real]', 'residuals: &[MultivariateQuadraticKrawczykResidual]').replace('zip(values)','zip(residuals)').replace(' * residual.clone()', ' * residual.residual.clone()').replace('(weight, value)', '(weight, residual)').replace(' * value.clone()', ' * residual.remainder_radius.clone()')
s=s[:i]+a+s[j:]
p.write_text(s)
