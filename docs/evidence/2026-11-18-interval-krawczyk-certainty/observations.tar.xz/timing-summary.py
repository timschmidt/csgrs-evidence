from pathlib import Path
import json,statistics
s=Path(__file__).parent
out={}
for folder in ['timing-confirm','crossover','crossover-two','crossover-inverse','crossover-affine','crossover-uni','crossover-multi','timing-confirm-multi']:
 p=s/folder
 rows={}
 for f in sorted(p.rglob('new/estimates.json')):
  ex=f.parents[2]
  key=(ex.parent.name if ex.parent!=p else '2')+' / '+f.parents[1].name
  rev=ex.name.split('-',1)[1]
  rows.setdefault(key,{}).setdefault(rev,[]).append(json.loads(f.read_text())['median']['point_estimate'])
 for key,by_revision in rows.items():
  m={k:statistics.median(v) for k,v in by_revision.items()}; before=m.get('before')
  if before is not None:out[folder+' / '+key]=dict(block_medians=by_revision,median_of_block_medians=m,change_percent={k:100*(t/before-1) for k,t in m.items() if k!='before'})
(s/'repeated-times.json').write_text(json.dumps(out,indent=2)+'\n')
