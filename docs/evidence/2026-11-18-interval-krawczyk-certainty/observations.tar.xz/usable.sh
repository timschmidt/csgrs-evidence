set -eu
b=/dev/shm/interval-box-coverage
s=/dev/shm/interval-krawczyk-certainty
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$b/lifetime-target"
cd "$b/usable"
cargo +1.95.0 build --offline --locked --release
cp "$CARGO_TARGET_DIR/release/radius-usable" "$s/images/$1-usable"
python3 "$b/measure-rss.py" "$s/logs/$1-rss" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$1-usable" > "$s/logs/$1-usable"
