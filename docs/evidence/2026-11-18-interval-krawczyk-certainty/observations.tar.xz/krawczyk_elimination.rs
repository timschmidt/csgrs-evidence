//! The exact root lies inside the box. The reported coordinates must also
//! satisfy the equations used to construct that root.
use hyperlimit::{Certainty, PredicateOutcome, PredicatePolicy, compare_reals};
use hyperreal::Real;
use hypersolve::{
    AffineKrawczykStatus, Constraint, Expr, Problem, SymbolId, VariableBall,
    certify_affine_krawczyk_box, context_from_problem,
};
use std::cmp::Ordering;

#[test]
fn certified_affine_root_keeps_the_nonzero_elimination_factor() {
    // The subtraction is exactly zero by the angle addition identity.
    let c = (Real::e() + Real::one()).sin()
        - Real::e().sin() * Real::one().cos()
        - Real::e().cos() * Real::one().sin()
        + Real::from(2).powi_i64(-2048).unwrap();
    let mut p = Problem::default();
    p.add_variable("x", Real::zero());
    p.add_variable("y", Real::zero());
    let x = Expr::anonymous_symbol(SymbolId(0));
    let y = Expr::anonymous_symbol(SymbolId(1));
    p.add_constraint(Constraint::equality("x=1", x.clone() - Expr::int(1)));
    p.add_constraint(Constraint::equality(
        "c*x+y=0",
        Expr::real(c.clone()) * x + y,
    ));
    let ctx = context_from_problem(&p);
    let a = p.analyze();
    let bounds = [SymbolId(0), SymbolId(1)].map(|symbol| VariableBall {
        symbol,
        radius: Real::one(),
    });
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let r = certify_affine_krawczyk_box(&a, &ctx, &bounds, policy);
        assert_eq!(r.status, AffineKrawczykStatus::CertifiedUniqueRoot);
        assert_eq!(r.steps[0].certified_root, Real::one());
        let residual = &c + &r.steps[1].certified_root;
        assert!(
            matches!(
                compare_reals(&residual, &Real::zero(), PredicatePolicy::STRICT),
                PredicateOutcome::Decided {
                    value: Ordering::Equal,
                    certainty: Certainty::Exact | Certainty::Filtered,
                    ..
                }
            ),
            "{policy:?}"
        );
    }
}
