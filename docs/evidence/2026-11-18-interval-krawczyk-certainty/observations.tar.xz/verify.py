from pathlib import Path
import hashlib,json,subprocess,re
s=Path(__file__).parent
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,message):
 if not ok:raise ValueError(message)
rows=read(s/'images-multi.json')
assert len(rows)==5
for img in rows:
 assert all(r['passed'] for r in img['metrics'].values())
 assert img['headroom']>=16*2**20
assert all(r['passes'] for r in read(s/'memory-multi.json')+read(s/'stress-memory-multi.json'))
sz=read(Path('docs/research/interval-size-accounts.json'))
imgs=sz['new_krawczyk_test_harnesses']
for row,file in zip(imgs,['primary-oracle','primary-proof-test'],strict=True):
 assert row['sha256']==sha(s/'images'/file) and row['remaining_bytes']>=row['required_free_bytes']
acct=read(Path('docs/research/interval-memory-accounts.json'))['accounts'][-1]
for key,f in [('regular_workloads','regular-stack-accounts.json'),('stress_workloads','stress-stack-accounts.json')]:
 a=read(s/f);assert len(a)==(120 if key=='regular_workloads' else 24)
 assert acct[key]['charged_stack_rows']==[r for r in a if r['cumulative_charge_bytes']]
 assert all(r['remaining_cumulative_bytes']>=0 and r['remaining_cumulative_percent']>=0 for r in a)
for suffix,size in [('observer',30),('client-rows',84)]:
 a,b=[(s/'logs'/(p+'-'+suffix)).read_bytes() for p in ['before','multi']]
 assert a==b
 # The box client also records allocation rows.
 n=len(a.splitlines())
 assert n>=size
print('All linked metrics, memory caps, cumulative entries, test image digests, full reports and traces verified.')
for cmd in ['rev-parse HEAD','status --short']:
 print(subprocess.check_output(['git',*cmd.split()],text=True))
