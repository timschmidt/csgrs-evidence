set -eu
s=/dev/shm/interval-krawczyk-certainty
. /dev/shm/interval-bisection/env
tag=$1
cargo +1.95.0 fmt --all -- --check > "$s/logs/$tag-fmt" 2>&1
cargo +1.95.0 test --locked -p hypersolve --lib --tests > "$s/logs/$tag-default-tests" 2>&1
cargo +1.95.0 test --locked -p hypersolve --all-features --lib --tests > "$s/logs/$tag-all-tests" 2>&1
cargo +1.95.0 test --locked -p hypersolve --all-features --doc > "$s/logs/$tag-doctests" 2>&1
cargo +1.95.0 clippy --locked -p hypersolve --all-features --all-targets -- -D warnings > "$s/logs/$tag-clippy" 2>&1
RUSTDOCFLAGS='-D warnings' cargo +1.95.0 doc --locked -p hypersolve --all-features --no-deps > "$s/logs/$tag-doc" 2>&1
cargo +1.95.0 test --locked -p hyperdynamics --all-features --lib --tests > "$s/logs/$tag-downstream" 2>&1
