from pathlib import Path
import re,sys
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
t=s.index('#[cfg(test)]\nmod tests')
a=s[:t]
a,n=re.subn(r'compare_reals\(([^;\n]*?), policy\)\.value\(\)',r'krawczyk_order(\1, policy)',a);assert n==11
i=a.index('fn classify_quadratic_krawczyk_row(');i=a.rfind('\n#[',0,i)+1 if a[i-35:i].strip().endswith(')]') else i
body='compare_reals(left, right, policy.certified_only()).value()'
if sys.argv[1]=='receipt':
 body='''match compare_reals(left, right, policy) {
        hyperlimit::PredicateOutcome::Decided {
            value,
            certainty: hyperlimit::Certainty::Exact | hyperlimit::Certainty::Filtered,
            ..
        } => Some(value),
        _ => None,
    }'''
a=a[:i]+'''// Every ordering used in a Krawczyk proof needs certified evidence.
fn krawczyk_order(left: &Real, right: &Real, policy: PredicatePolicy) -> Option<Ordering> {
    '''+body+'''
}

'''+a[i:]
p.write_text(a+s[t:])
