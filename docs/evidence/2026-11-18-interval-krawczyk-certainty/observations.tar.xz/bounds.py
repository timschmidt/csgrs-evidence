from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
i=s.index('        match compare_reals(&image_radius, radius, policy).value()')
j=s.index('        variables.push(',i)
s=s[:i]+'''        if let Err(status) = check_krawczyk_coordinate_bounds(
            variable.symbol, &image_radius, radius, &contraction_bound, policy,
        ) {
            return multivariate_quadratic_krawczyk_report(
                status, variable_count, rows.len(), residual_payloads, variables,
            );
        }

'''+s[j:]
i=s.index('fn contraction_row_bound(')
s=s[:i]+'''fn check_krawczyk_coordinate_bounds(
    symbol: SymbolId,
    image_radius: &Real,
    radius: &Real,
    contraction_bound: &Real,
    policy: PredicatePolicy,
) -> Result<(), MultivariateQuadraticKrawczykStatus> {
    use MultivariateQuadraticKrawczykStatus as Status;
    match compare_reals(image_radius, radius, policy).value() {
        Some(Ordering::Less | Ordering::Equal) => {}
        Some(Ordering::Greater) => return Err(Status::ImageOutsideBox { symbol }),
        None => return Err(Status::Undecided { symbol }),
    }
    match compare_reals(contraction_bound, &Real::one(), policy).value() {
        Some(Ordering::Less) => Ok(()),
        Some(Ordering::Greater | Ordering::Equal) => Err(Status::NonContractiveDerivative { symbol }),
        None => Err(Status::Undecided { symbol }),
    }
}

'''+s[i:]
p.write_text(s)
