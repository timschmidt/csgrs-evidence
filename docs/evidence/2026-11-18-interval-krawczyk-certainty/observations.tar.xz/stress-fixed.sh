set -eu
s=/dev/shm/interval-krawczyk-certainty
b=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
v=$1
cd "$s/stress"
CARGO_TARGET_DIR="$b/wasm-target" cargo +1.95.0 build --offline --release --target wasm32-unknown-unknown
cp "$b/wasm-target/wasm32-unknown-unknown/release/kraw_stress.wasm" "$s/images/$v-stress.wasm"
node check.cjs "$s/images/$v-stress.wasm" "before" > "$s/logs/$v-stress-wasm"
cd "$s/stress-life"
CARGO_TARGET_DIR="$b/lifetime-target" cargo +1.95.0 build --offline --release
cp "$b/lifetime-target/release/proof-stress-lifetime" "$s/images/$v-stress-life"
for i in $(seq 1 24);do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-stress-life" > "$s/logs/$v-stress-life-$i" 2>"$s/logs/$v-stress-guard-$i";done
