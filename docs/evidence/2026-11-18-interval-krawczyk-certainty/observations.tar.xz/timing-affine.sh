set -eu
s=/dev/shm/interval-krawczyk-certainty
i=0
for v in before affine affine before; do
 i=$((i+1))
 CRITERION_HOME="$s/timing-affine/$i-$v" setarch "$(uname -m)" -R taskset -c 2 "$s/images/$v-certification" --bench --noplot --warm-up-time 0.4 --measurement-time 1 --sample-size 25 'certify_(affine_krawczyk_box|univariate_quadratic_krawczyk_rows|multivariate_quadratic_krawczyk_square)' > "$s/logs/affine-timing-$i-$v" 2>&1
done
