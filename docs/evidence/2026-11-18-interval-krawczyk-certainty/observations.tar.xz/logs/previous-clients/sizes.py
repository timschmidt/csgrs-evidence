from pathlib import Path
import json,sys
from image_metrics import sizes
s=Path(__file__).parent
def wasm(p):
 data=p.read_bytes(); i=8
 def leb():
  nonlocal i
  n=0; shift=0
  while True:
   b=data[i]; i+=1; n|=(b&127)<<shift
   if b<128:return n
   shift+=7
 while i<len(data):
  k=data[i]; i+=1; length=leb()
  if k==10:return length
  i+=length
 raise ValueError('missing code')

out={}
for name in ['client','copy-certification','kraw.wasm']:
 versions=[]
 for v in ['fixed','before','all-radii']:
  p=s/'images'/f'{v}-{name}'
  versions.append({'file':p.stat().st_size,'code':wasm(p)} if name.endswith('wasm') else sizes(p))
 f,c,r=versions
 out[name]={}
 for k in f.keys()|c.keys()|r.keys():
  x,y,z=(row.get(k,0) for row in versions)
  d=max(0,z-y); cumulative=max(0,y-x)+d
  if name.endswith('wasm'): bi,pi,bc,pc=1024,5,4096,10
  elif k=='function_union':bi,pi,bc,pc=1024,.5,4096,1
  else:bi,pi,bc,pc=4096,1,16384,2
  passes=d<=bi and 100*d<=pi*y and cumulative<=bc and 100*cumulative<=pc*x
  out[name][k]=[x,y,z,d,cumulative,passes]
  if x!=z or y!=z: print(name,k,x,y,z,d,cumulative,passes)
(s/'sizes.json').write_text(json.dumps(out,indent=2)+'\n')
