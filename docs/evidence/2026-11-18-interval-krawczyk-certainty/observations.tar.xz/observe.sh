set -eu
s=/dev/shm/interval-krawczyk-certainty
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/observer-target"
cd "$s/observer"
cargo +1.95.0 run --release --offline > "$s/logs/$1-observer" 
