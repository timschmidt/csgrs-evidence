from pathlib import Path
import hashlib,shutil,json,subprocess,sys
s=Path(__file__).parent;b=Path('/dev/shm/interval-box-coverage');out=s/'bundle'
out.mkdir(exist_ok=True)
def cp(p,q):
 q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists() or p.read_bytes()!=q.read_bytes():shutil.copy2(p,q)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p in s.iterdir():
 if p.is_file() and p.name not in {"test-pack.xz","verify.bin"}:cp(p,out/p.name)
for d in ['logs','observer','stress','stress-life','timing','timing-order','timing-entry','timing-confirm','timing-two','timing-pivot','timing-inverse','timing-affine','crossover','crossover-inverse','crossover-two','crossover-affine','crossover-uni','crossover-multi','timing-uni','timing-multi','timing-confirm-multi']:
 for p in (s/d).rglob('*'):
  if p.is_file():cp(p,out/'logs'/p.relative_to(s))
for d in ['client','lifetime','usable','portable-krawczyk']:
 for p in (b/d).rglob('*'):
  if p.is_file():cp(p,out/'logs'/'previous-clients'/p.relative_to(b))
for name in ['image_metrics.py','memory-rows.json','memory-envelope.txt','sizes.py','sizes.json','measure-rss.py','check-wasm-memory.cjs','build-environment.sh']:
 cp(b/name,out/'logs'/'previous-clients'/name)
tags=sys.argv[1:] or ['entry']
images=out/'binary-deltas';images.mkdir(exist_ok=True)
entries={}
for p in sorted((s/'images').iterdir()):
 if not p.is_file():continue
 k=p.name;e={'bytes':p.stat().st_size,'sha256':digest(p)};entries[k]=e
 if k in ['primary-oracle','entry-test','fixed-stress.wasm','fixed-stress-life','primary-proof-test']:
  cp(p,images/k);e['member']='binary-deltas/'+k;continue
 if k.startswith('before-stress'):
  base=s/'images'/k.replace('before','fixed',1)
 elif any(k.startswith(v+'-') or k==v+'.wasm' for v in tags):
  base=s/'images'/('before'+k[k.index('.'):] if k.endswith('.wasm') and '-stress' not in k else 'before-'+k.split('-',1)[1])
 elif k.startswith('before-') or k=='before.wasm':
  prev={'before-client':'all-radii-client','before-certification':'all-radii-copy-certification','before-lifetime':'all-radii-lifetime','before-usable':'all-radii-usable','before.wasm':'all-radii-kraw.wasm'}.get(k)
  if not prev:continue
  base=b/'images'/prev
 else:continue
 if not base.exists():continue
 e['base']=base.name;e['base_sha256']=digest(base)
 if e['base_sha256']==e['sha256']:continue
 dest=images/(k+'.zst')
 subprocess.run(['zstd','--quiet','--force','-12','--patch-from',base,p,'-o',dest],check=True)
 restored=s/'verify.bin'
 subprocess.run(['zstd','--quiet','--force','-d','--patch-from',base,dest,'-o',restored],check=True)
 assert digest(restored)==e['sha256'];restored.unlink()
 e['delta']='binary-deltas/'+dest.name
(out/'images.json').write_text(json.dumps(entries,indent=2)+'\n')
