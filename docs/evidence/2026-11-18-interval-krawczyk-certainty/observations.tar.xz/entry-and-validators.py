from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs')
s=p.read_text()
for n in ['validate_krawczyk_variable_balls','validate_quadratic_krawczyk_variable_balls','validate_multivariate_quadratic_krawczyk_variable_balls']:
 i=s.index('fn '+n+'(');j=s.index('\n}',i)
 t=s[i:j];assert t.count('policy.certified_only()')==1
 s=s[:i]+t.replace('policy.certified_only()','policy')+s[j:]
p.write_text(s)
