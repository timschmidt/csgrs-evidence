from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
i=s.index('        let pivot_tail = matrix[pivot][pivot..].to_vec();');j=s.index('\n    }\n    Ok(())',i)
a=s[i:j].replace('let pivot_tail = matrix[pivot][pivot..].to_vec();','''let (before, pivot_and_after) = matrix.split_at_mut(pivot);
        let (pivot_row, after) = pivot_and_after.split_first_mut().expect("pivot is in the matrix");
        let pivot_tail = &pivot_row[pivot..];''')
a=a.replace('''for row in 0..n {
            if row == pivot {
                continue;
            }
            let factor = matrix[row][pivot].clone();''','''for (index, row) in (0..pivot).zip(before).chain((pivot + 1..n).zip(after)) {
            let factor = row[pivot].clone();''').replace('matrix[row].iter_mut()', 'row.iter_mut()').replace('.zip(&pivot_tail)', '.zip(pivot_tail)').replace('rhs[row]', 'rhs[index]')
s=s[:i]+a+s[j:];p.write_text(s)
