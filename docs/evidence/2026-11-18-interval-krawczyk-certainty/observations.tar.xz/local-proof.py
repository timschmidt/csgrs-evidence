from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs')
s=p.read_text()
for name in ['classify_quadratic_krawczyk_row','gauss_jordan']:
 i=s.index('fn '+name);j=s.index(' {\n',i)+3
 s=s[:j]+'    let policy = policy.certified_only();\n'+s[j:]
for x in ['&displacement, radius','&image_radius, radius','&contraction_bound, &Real::from(1)']:
 src='compare_reals('+x+', policy)'
 assert s.count(src)==1
 s=s.replace(src,src.replace('policy)','policy.certified_only())'))
p.write_text(s)
