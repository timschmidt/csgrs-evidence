module csgrs.local/consumer

go 1.27.0
