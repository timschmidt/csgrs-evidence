# Actual native binding consumers for the cache candidate

The owning invariant is Hypercurve's local circular-support cache. P4,
P17-P20 and P28-P30 require preserved meanings, certainty and typed failures
through affected modeling boundaries. This qualification changes no source,
fixtures, policy or ABI. It executes all 27 existing C, C++ and Python consumer
programs against one freshly built csgrs-ffi shared library, with C/C++ assertions
enabled. Each program must actually run and exit successfully; syntax checks
alone do not substitute for runtime consumption.

Run the csgrs-ffi CI check, test, formatting, strict Clippy, warning-free docs
and three C/C++ header syntax commands. Build the release library with the
unchanged locked dependency graph. Compile each native consumer with the
repository headers, link that exact library, and retain every executable and
raw result. Python consumers use the actual library via CSGRS_LIBRARY. Record
source, tool and library hashes before and after. Compiler caches, Python cache,
logs, outputs and scratch remain on the validation volume.

The host currently has no Go executable on PATH; Go runtime coverage remains
open until a matching real toolchain is available. The native JS wrapper also
requires a consumer-supplied loader which the repository does not ship; its
TypeScript syntax check is separate from the real generated WASM consumer
results. Do not claim these unexecuted native consumers passed.

Keep the existing 1,800-second command wall limit, 8 GiB child address space,
2 GiB host available-memory reserve, 512 MiB active-volume reserve, 64 GiB fresh
volume consumption and 64 MiB aggregate command logs. Run sequentially without
other qualification workloads. Source and test failures remain failures. This
is local source validation, not clean installed-package or release qualification.
