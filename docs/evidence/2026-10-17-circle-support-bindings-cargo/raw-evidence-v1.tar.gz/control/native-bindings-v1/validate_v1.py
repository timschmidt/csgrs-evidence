"""Run the existing FFI workflow and every existing C/C++/Python consumer."""
import gzip
import json
import os
from pathlib import Path
import re
import shutil
import sys
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, reasons, resources, run, sha
W = Path(__file__).resolve().parent
C = V / 'checkout-candidate-v1'
F = C / 'crates/csgrs-ffi'
TARGET = V / 'target-candidate-v1'
O = V / 'native-binding-consumers-v1'
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert not O.exists()
assert not (V / 'native-bindings-protocol-v1.json').exists()
compiler = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
binding_tools = json.loads((V / 'control/binding-tools-preflight-v1.json').read_text())
assert all(sha(p) == h for p,h in compiler['tool_sha256'].items())
assert all(sha(p) == h for p,h in binding_tools['tools_read_only_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.environ['PYTHONPYCACHEPREFIX'] = str(O / 'pycache')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
cargo = str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
cc = shutil.which('cc'); cxx = shutil.which('c++'); python = sys.executable
assert cc and cxx
inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
pins = {p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
def verify():
    for name,digest in pins.items():
        path = C / name
        assert not path.is_symlink() and sha(path) == digest, name
    assert not reasons(resources())
verify()
O.mkdir()
consumer_paths = sorted(p for p in (C / 'tests/ffi').iterdir() if p.suffix in ['.c','.cpp','.py'])
assert len(consumer_paths) == 27
assert all(sum(p.suffix == extension for p in consumer_paths) == 9 for extension in ['.c','.cpp','.py'])
commands = [
    ('ffi-check-v1', [cargo,'check','--locked']),
    ('ffi-tests-v1', [cargo,'test','--locked','--','--test-threads=2']),
    ('ffi-fmt-v1', [cargo,'fmt','--','--check']),
    ('ffi-clippy-v1', [cargo,'clippy','--locked','--all-targets','--','-D','warnings']),
    ('ffi-docs-v1', [cargo,'doc','--locked','--no-deps']),
    ('ffi-header-c-v1', [cc,'-std=c11','-fsyntax-only','-x','c','include/csgrs.h']),
    ('ffi-header-cpp-v1', [cxx,'-std=c++17','-fsyntax-only','-x','c++','include/csgrs.h']),
    ('ffi-wrapper-cpp-v1', [cxx,'-std=c++17','-fsyntax-only','-x','c++','../../bindings/cpp/csgrs.hpp']),
    ('ffi-release-v1', [cargo,'build','--release','--locked'])]
dump(V / 'native-bindings-protocol-v1.json', {
    'helper_sha256':sha(Path(__file__)), 'contract_sha256':sha(W / 'contract-v1.md'),
    'runner_sha256':sha(V / 'control/validation_runner_v2.py'),
    'source_inventory_sha256':sha(V / 'candidate-source-inventory-v1.json.gz'),
    'source':str(C), 'target':str(TARGET), 'output':str(O), 'source_pin_count':len(pins),
    'commands':commands, 'consumer_sources':{str(p):sha(p) for p in consumer_paths},
    'compiler_frontends':{cc:sha(cc),cxx:sha(cxx),python:sha(python)},
    'tool_version_commands':[[cc,'--version'],[cxx,'--version'],[python,'--version']],
    'python_environment':{k:os.environ[k] for k in ['PYTHONPYCACHEPREFIX','PYTHONDONTWRITEBYTECODE']},
    'go_available_on_path':shutil.which('go'), 'native_js_loader_supplied':False,
    'assertions_enabled':True, 'performance_comparison':False, 'wall_limit_seconds_per_command':1800,
    'source_changes':False, 'candidate_admitted':False})
results = {}
for label,argv in [('cc',[cc,'--version']),('cxx',[cxx,'--version']),('python',[python,'--version'])]:
    results['tool-' + label] = run('ffi-tool-' + label + '-v1', argv, C, target=TARGET)
for name,argv in commands:
    verify()
    if name == 'ffi-docs-v1':os.environ['RUSTDOCFLAGS']='-D warnings'
    results[name] = run(name,argv,F,target=TARGET)
    if name == 'ffi-docs-v1':os.environ.pop('RUSTDOCFLAGS')
    if name == 'ffi-tests-v1':
        rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
            (V/'logs'/name/'stdout').read_text(),re.M)
        assert rows and all(row[0]=='ok' and row[2]=='0' and row[5]=='0' for row in rows)
    dump(V/'native-bindings-progress-v1.json',results)
library = TARGET / 'release/libcsgrs_ffi.so'
library_digest = sha(library)
os.environ['CSGRS_LIBRARY'] = str(library)
dump(O/'library.json',{'path':str(library),'sha256':library_digest,'bytes':library.stat().st_size})
consumers = {}
for source in consumer_paths:
    verify()
    assert sha(library)==library_digest
    label = source.stem.replace('_','-') + {'c':'-c','cpp':'-cpp','py':'-python'}[source.suffix[1:]]
    if source.suffix in ['.c','.cpp']:
        executable=O/label
        compiler_path=cc if source.suffix=='.c' else cxx
        standard='-std=c11' if source.suffix=='.c' else '-std=c++17'
        argv=[compiler_path,standard,'-Wall','-Wextra','-Werror','-I'+str(F/'include'),
            '-I'+str(C/'bindings/cpp'),str(source),'-L'+str(library.parent),
            '-Wl,-rpath,'+str(library.parent),'-lcsgrs_ffi','-o',str(executable)]
        results[label+'-compile']=run('ffi-consumer-'+label+'-compile-v1',argv,C,target=TARGET)
        argv=[str(executable)]
    else:
        argv=[python,'-B',str(source)]
    results[label]=run('ffi-consumer-'+label+'-run-v1',argv,C,target=TARGET)
    consumers[label]={'source':str(source),'source_sha256':sha(source),
        'argv':argv,'exit_code':0,'actual_shared_library':str(library),'library_sha256':library_digest}
    if source.suffix!='.py':consumers[label]['executable_sha256']=sha(executable)
    dump(V/'native-bindings-progress-v1.json',{'commands':results,'consumers':consumers})
assert len(consumers)==27
verify()
assert sha(library)==library_digest
tsc=binding_tools['environment_for_future_consumer']['TSC']
results['native-js-types']=run('ffi-native-js-types-v1',[tsc,'--noEmit','--target','ES2020','--strict',
    str(C/'bindings/js/csgrs.ts')],C,target=TARGET)
results['python-syntax']=run('ffi-python-syntax-v1',[python,'-B','-m','py_compile',str(C/'bindings/python/csgrs.py')],C,target=TARGET)
verify()
assert all(sha(p)==h for p,h in binding_tools['tools_read_only_sha256'].items())
dump(V/'native-bindings-result-v1.json',{'complete_for_declared_scope':True,
    'commands':results,'consumer_count':27,'consumers':consumers,'ffi_test_summaries':rows,
    'ffi_ci_checks_passed':True,'actual_c_cpp_python_consumers_passed':True,
    'native_js_syntax_passed':True,'native_js_loader_executed':False,'go_consumers_executed':False,
    'source_unchanged':True,'all_bindings_complete':False,'candidate_admitted':False,
    'external_distribution_complete':False,'full_plan_complete':False})
print(json.dumps({'actual_c_cpp_python_consumers_passed':27,'ffi_ci_checks_passed':True,
    'go_consumers_executed':False,'native_js_loader_executed':False,'candidate_admitted':False}),flush=True)
