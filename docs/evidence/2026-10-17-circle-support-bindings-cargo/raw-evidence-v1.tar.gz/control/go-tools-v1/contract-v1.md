# Isolated Go toolchain for real native consumers

Go was absent from PATH and the common local installation locations during
preflight. Prepare the official Go 1.27.2 Linux amd64 archive, selected from
https://go.dev/dl/?mode=json. Its published SHA-256 is
ecbadb99091a3f46e31f5f934b068b1864eafa7995211b39eaddf76996045fe5
and its declared length is 70,590,635 bytes. Retain the actual download metadata,
archive, extraction proof and tool output. Do not substitute another version or
checksum if this pinned download fails.

Install only in the new validation-volume prefix. Verify archive size and SHA
before extraction; reject traversal, duplicate names, special files, links,
more than 50,000 entries or more than 1 GiB of expanded regular files. Extract
with Python's data filter into an empty directory. Independently compare every
extracted regular file with its archived bytes. Retain exact tool file hashes.

Run telemetry-off and version checks with fresh XDG configuration and caches,
GOENV=off and GOTOOLCHAIN=local. Do not change HOME or any global installation.
No Go consumer is qualified by tool installation; actual consumers remain a
separate step against the exact native library. Keep all previous absence and
unexecuted-consumer records as historical observations.

Run this preparation after the active modeling/circuit qualification terminates.
Use the existing 1,800-second per-command wall limit, 8 GiB address-space cap,
2 GiB host available-memory reserve, 512 MiB active-volume reserve, 64 GiB fresh
volume consumption and 64 MiB aggregate command logs. Retain failed/partial
attempts, never overwrite them, and do not run a second qualification workload
concurrently. All configuration, caches, downloads, scratch and logs stay on
Disk B. External package/release qualification remains separate.
