"""Fetch and verify only the pinned official Go distribution; do not run it."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import urllib.parse
import urllib.request
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
W = Path(__file__).resolve().parent
O = V/'go-tools-v1'
assert not O.exists()
O.mkdir()
selection = json.loads((W/'source-selection-v1.json').read_text())
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def dump(path,value):
    Path(path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
class OfficialRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        parsed = urllib.parse.urlsplit(newurl)
        assert parsed.scheme == 'https' and parsed.hostname in ['go.dev','dl.google.com'],newurl
        return super().redirect_request(req,fp,code,msg,headers,newurl)
opener = urllib.request.build_opener(OfficialRedirects())
def fetch(url,destination,limit):
    with opener.open(url,timeout=60) as response:
        assert response.status == 200
        headers = dict(response.headers)
        final_url = response.url
        total = 0
        with Path(destination).open('xb') as stream:
            while data := response.read(1024*1024):
                total += len(data)
                assert total <= limit,(url,total,limit)
                stream.write(data)
    return {'url':url,'final_url':final_url,'headers':headers,'bytes':total,'sha256':sha(destination)}
metadata = O/'download-metadata.json'
metadata_receipt = fetch(selection['metadata_url'],metadata,2*1024**2)
releases = json.loads(metadata.read_text())
release = next(row for row in releases if row['version'] == selection['version'])
assert release['stable'] is True
package = next(row for row in release['files'] if row['filename'] == selection['filename'])
assert package['sha256'] == selection['sha256'] and package['size'] == selection['bytes']
assert package['os'] == 'linux' and package['arch'] == 'amd64' and package['kind'] == 'archive'
dump(O/'verified-metadata.json',{'release':release['version'],'package':package,'receipt':metadata_receipt,
    'selection_sha256':sha(W/'source-selection-v1.json')})
archive = O/selection['filename']
archive_receipt = fetch('https://go.dev/dl/'+selection['filename'],archive,selection['bytes'])
assert archive_receipt['bytes'] == selection['bytes'] and archive_receipt['sha256'] == selection['sha256']
dump(O/'verified-archive.json',archive_receipt)
install = O/'install'
install.mkdir()
with tarfile.open(archive,'r:gz') as source:
    members = source.getmembers()
    assert len(members) <= 50000
    assert len({row.name for row in members}) == len(members)
    assert sum(row.size for row in members if row.isfile()) <= 1024**3
    for row in members:
        name = PurePosixPath(row.name)
        assert name.parts and name.parts[0] == 'go' and not name.is_absolute() and '..' not in name.parts,row.name
        assert row.isfile() or row.isdir(),(row.name,row.type)
    source.extractall(install,members=members,filter='data')
files = {}
with tarfile.open(archive,'r|gz') as source:
    for row in source:
        if not row.isfile():
            continue
        path = install/row.name
        assert path.is_file() and not path.is_symlink() and path.stat().st_size == row.size
        with source.extractfile(row) as stream:
            digest = hashlib.file_digest(stream,'sha256').hexdigest()
        assert sha(path) == digest,row.name
        files[str(path)] = {'sha256':digest,'bytes':row.size,'mode':path.stat().st_mode & 0o777}
assert len(files) == sum(row.isfile() for row in members)
assert set(files) == {str(p) for p in install.rglob('*') if p.is_file()}
dump(O/'file-inventory-v1.json',files)
dump(O/'extraction-result-v1.json',{'complete':True,'verified_regular_files':len(files),
    'archive_sha256':sha(archive),'tool_path':str(install/'go/bin/go'),
    'tool_sha256':sha(install/'go/bin/go'),'tool_executed':False,'consumer_executed':False,
    'helper_sha256':sha(Path(__file__))})
print(json.dumps({'distribution_verified':True,'verified_regular_files':len(files),
                  'tool_executed':False,'consumer_executed':False}),flush=True)
