"""Install pinned Go locally after other qualification work has terminated."""
import json
import os
from pathlib import Path
import platform
import sys
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W = Path(__file__).resolve().parent
O = V/'go-tools-v1'
assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
assert not O.exists() and not (V/'go-tools-protocol-v1.json').exists()
assert not reasons(resources())
compiler = json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
environment = {'XDG_CONFIG_HOME':str(V/'go-config-v1'),'XDG_CACHE_HOME':str(V/'xdg-cache-v1'),
    'XDG_DATA_HOME':str(V/'go-data-v1'),'GOPATH':str(V/'gopath-v1'),
    'GOCACHE':str(V/'go-cache-v1'),'GOMODCACHE':str(V/'go-modcache-v1'),
    'GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOPROXY':'off','GOSUMDB':'off'}
os.environ.update(environment)
helper = W/'download_extract_v1.py'
go = O/'install/go/bin/go'
commands = [('go-tools-download-extract-v1',[sys.executable,'-B',str(helper)]),
    ('go-tools-telemetry-off-v1',[str(go),'telemetry','off']),
    ('go-tools-version-v1',[str(go),'version']),
    ('go-tools-environment-v1',[str(go),'env','-json','GOVERSION','GOROOT','GOENV','GOTOOLCHAIN','GOTELEMETRY','GOTELEMETRYDIR'])]
dump(V/'go-tools-protocol-v1.json',{'commands':commands,'environment':environment,
    'contract_sha256':sha(W/'contract-v1.md'),'selection_sha256':sha(W/'source-selection-v1.json'),
    'download_helper_sha256':sha(helper),'helper_sha256':sha(Path(__file__)),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),'global_installation_modified':False,
    'wall_limit_seconds_per_command':1800,'consumer_executed':False})
results = {}
for name,argv in commands:
    results[name] = run(name,argv,V,target=V/'target-candidate-v1')
    dump(V/'go-tools-progress-v1.json',results)
assert (V/'logs/go-tools-version-v1/stdout').read_text().strip() == 'go version go1.27.2 linux/amd64'
env = json.loads((V/'logs/go-tools-environment-v1/stdout').read_text())
assert env['GOVERSION'] == 'go1.27.2' and env['GOTELEMETRY'] == 'off'
assert env['GOENV'] == 'off' and env['GOTOOLCHAIN'] == 'local'
assert Path(env['GOTELEMETRYDIR']).is_relative_to(V)
files = json.loads((O/'file-inventory-v1.json').read_text())
assert all(sha(p) == row['sha256'] for p,row in files.items())
dump(V/'go-tools-result-v1.json',{'complete':True,'commands':results,
    'tool':str(go),'tool_sha256':sha(go),'tool_version':'go1.27.2','environment':environment,
    'telemetry_off':True,'files_verified':len(files),'global_installation_modified':False,
    'consumer_executed':False,'external_distribution_qualified':False})
print(json.dumps({'isolated_go_ready':True,'version':'go1.27.2','telemetry_off':True,
                  'consumer_executed':False}),flush=True)
