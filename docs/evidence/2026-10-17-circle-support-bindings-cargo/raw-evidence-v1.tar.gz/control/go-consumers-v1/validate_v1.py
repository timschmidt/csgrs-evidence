"""Run all unchanged Go consumer tests against the tested native library."""
import gzip
import json
import os
from pathlib import Path
import re
import shutil
import sys
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W = Path(__file__).resolve().parent
C = V/'checkout-candidate-v1'
O = V/'go-consumers-v1'
M = Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
assert not O.exists() and not (V/'go-consumers-protocol-v1.json').exists()
assert json.loads((V/'modeling-downstream-result-v1.json').read_text())['complete']
assert json.loads((V/'native-bindings-result-v1.json').read_text())['complete_for_declared_scope']
gotools=json.loads((V/'go-tools-result-v2.json').read_text())
assert gotools['complete'] and gotools['telemetry_off']
assert json.loads((V/'control/spaceless-mount-v1/result.json').read_text())['complete']
assert M.is_dir() and not list(M.iterdir())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ.update(gotools['environment'])
os.environ['CARGO_NET_OFFLINE']='true'
os.environ['GIT_OPTIONAL_LOCKS']='0'
cc=shutil.which('cc'); cxx=shutil.which('c++')
assert cc and cxx
inventory=json.loads(gzip.decompress((V/'candidate-source-inventory-v1.json.gz').read_bytes()))
pins={p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
gofiles=json.loads((V/'go-tools-v1/file-inventory-v1.json').read_text())
def verify():
    assert not reasons(resources())
    for name,digest in pins.items():
        path=C/name
        assert not path.is_symlink() and sha(path)==digest,name
    assert all(sha(p)==row['sha256'] for p,row in gofiles.items())
verify()
O.mkdir()
module=O/'module'
module.mkdir()
copies={}
source_paths=sorted((C/'bindings/go').glob('*.go'))
assert len(source_paths)==7
expected_tests=sorted(name for p in source_paths for name in re.findall(r'^func (Test\w+)\(t \*testing.T\)',p.read_text(),re.M))
assert len(expected_tests)==6
source_paths.append(C/'crates/csgrs-ffi/include/csgrs.h')
for source in source_paths:
    destination=module/source.relative_to(C)
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,destination)
    assert sha(source)==sha(destination)
    copies[str(destination)]={'source':str(source),'sha256':sha(destination),'bytes':destination.stat().st_size}
(module/'go.mod').write_text('module csgrs.local/consumer\n\ngo 1.27.0\n')
library_record=json.loads((V/'native-binding-consumers-v1/library.json').read_text())
source_library=Path(library_record['path'])
assert sha(source_library)==library_record['sha256']
library=O/'lib/libcsgrs_ffi.so'
library.parent.mkdir()
shutil.copy2(source_library,library)
assert sha(library)==library_record['sha256']
copies[str(library)]={'source':str(source_library),'sha256':sha(library),'bytes':library.stat().st_size}
dump(O/'copy-proof-v1.json',copies)
name='go-consumers-runtime-v1'
environment={
    'GOROOT':str(M/'go-tools-v1/install/go'),
    'XDG_CONFIG_HOME':str(M/'go-config-v1'),
    'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),
    'XDG_DATA_HOME':str(M/'go-data-v1'),
    'GOPATH':str(M/'gopath-v1'),
    'GOCACHE':str(M/'go-cache-v1'),
    'GOMODCACHE':str(M/'go-modcache-v1'),
    'GOENV':'off','GOTOOLCHAIN':'local','GOWORK':'off','GOPROXY':'off','GOSUMDB':'off',
    'GO111MODULE':'on','GOFLAGS':'','CGO_ENABLED':'1','GOMAXPROCS':'2',
    'CC':cc,'CXX':cxx,
    'CGO_LDFLAGS':'-L'+str(M/'go-consumers-v1/lib')+' -Wl,-rpath,'+str(M/'go-consumers-v1/lib')+' -lcsgrs_ffi',
    'TMPDIR':str(M/'scratch'/name)}
command=[str(M/'go-tools-v1/install/go/bin/go'),'test','-json','-count=1','-p=2','-work','./bindings/go']
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/',
    '--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),
    '--chdir',str(M/'go-consumers-v1/module')]
for key,value in environment.items(): argv.extend(['--setenv',key,value])
argv.extend(command)
dump(V/'go-consumers-protocol-v1.json',{
    'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),
    'source_inventory_sha256':sha(V/'candidate-source-inventory-v1.json.gz'),
    'go_tool_result_sha256':sha(V/'go-tools-result-v2.json'),
    'source_pins':len(pins),'expected_tests':expected_tests,
    'copies':copies,'module_manifest_sha256':sha(module/'go.mod'),
    'tool_sha256':{cc:sha(cc),cxx:sha(cxx),'/usr/bin/bwrap':sha('/usr/bin/bwrap'),gotools['tool']:sha(gotools['tool'])},
    'command':command,'actual_argv':argv,'environment':environment,
    'wall_limit_seconds':1800,'test_cache_disabled':True,'candidate_admitted':False})
result=run(name,argv,module,target=V/'target-candidate-v1')
events=[json.loads(line) for line in (V/'logs'/name/'stdout').read_text().splitlines()]
assert events and not any(row.get('Action') in ['fail','skip'] for row in events)
passed=sorted(row['Test'] for row in events if row.get('Action')=='pass' and 'Test' in row)
assert passed==expected_tests,(passed,expected_tests)
package_pass=[row for row in events if row.get('Action')=='pass' and 'Test' not in row]
assert len(package_pass)==1 and package_pass[0]['Package']=='csgrs.local/consumer/bindings/go'
verify()
assert sha(source_library)==library_record['sha256']
assert all(sha(p)==row['sha256'] for p,row in copies.items())
dump(V/'go-consumers-result-v1.json',{'complete_for_declared_scope':True,'command':result,
    'tests_passed':passed,'test_count':len(passed),'failures':0,'skips':0,
    'package_pass_event':package_pass[0],'actual_library_sha256':sha(library),
    'copy_proof_sha256':sha(O/'copy-proof-v1.json'),'source_unchanged':True,
    'cache_disabled':True,'candidate_admitted':False,'all_bindings_complete':False,
    'external_distribution_complete':False,'full_plan_complete':False})
print(json.dumps({'actual_go_tests_passed':len(passed),'candidate_admitted':False}),flush=True)
