# Actual Go consumers of the cache candidate

The owning invariant remains Hypercurve's circular-support cache. P4,
P17-P20 and P28-P30 require preserved exact values, supported composition and
visible failure through the existing Go binding. This check changes no
repository source, fixture, policy, representation or ABI.

After the modeling/circuit matrix, FFI validation and isolated Go preparation
have terminated successfully, copy the seven unchanged Go files and public
header into a fresh external module with the same relative layout. Copy the
exact already tested native library, verify each physical copy independently,
and link that library. Run all six existing Go tests with -count=1 so cached
success cannot substitute for execution. Require every named test and its
package to pass, with no failure or skip event. Pin sources, compiler, Go
installation and library before and after execution.

Use the previously verified private bubblewrap bind mount to expose the same
Disk B files through a path without spaces. All Go outputs, temporary files,
module/build caches, configuration and telemetry stay on Disk B. The rest of
the filesystem is read-only. Disable network dependency lookup and toolchain
replacement; use the pinned local Go installation with telemetry off. The
module manifest is validation scaffolding and has no third-party dependency.
Keep -work output and raw JSON events, and record the actual environment.

Retain the existing 1,800-second outer wall limit, 8 GiB process address-space
cap, 2 GiB host available-memory reserve, 512 MiB active-volume reserve, 64 GiB
fresh-volume consumption limit and 64 MiB aggregate log limit. Use two build
workers and GOMAXPROCS=2. Run without another qualification workload. No fixture
or assertion is removed. Any build, runtime, diagnostic or resource failure
remains a failure and is retained. This is a real local consumer check, not
registry installation, a minimum Go version claim, or release qualification.
