"""Verify the installed Go tool with the source-correct GOENV expectation."""
import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent
assert not (V/'go-tools-protocol-v2.json').exists()
assert not (V/'go-tools-result-v2.json').exists()
prior=json.loads((V/'go-tools-attempt-v1-result.json').read_text())
assert not prior['complete'] and prior['parent_exit_code']==1 and not prior['consumer_executed']
original=json.loads((V/'go-tools-protocol-v1.json').read_text())
assert sha(V/'control/go-tools-v1/prepare_v1.py')==original['helper_sha256']
assert sha(V/'control/go-tools-v1/download_extract_v1.py')==original['download_helper_sha256']
assert all(sha(p)==h for p,h in prior['inspected_primary_source_sha256'].items())
for name,result in prior['commands'].items():
    assert result==json.loads((V/'logs'/name/'result.json').read_text())
    assert result['exit_code']==0 and not result['stops']
    assert all(sha(V/'logs'/name/p)==h for p,h in result['output_sha256'].items())
files=json.loads((V/'go-tools-v1/file-inventory-v1.json').read_text())
assert len(files)==15657
assert all(sha(p)==row['sha256'] for p,row in files.items())
assert not reasons(resources())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
environment=original['environment']
os.environ.update(environment)
assert os.environ['GOENV']=='off' and os.environ['GOTOOLCHAIN']=='local'
go=V/'go-tools-v1/install/go/bin/go'
commands=[('go-tools-version-v2',[str(go),'version']),
 ('go-tools-environment-v2',[str(go),'env','-json','GOVERSION','GOROOT','GOENV','GOTOOLCHAIN','GOTELEMETRY','GOTELEMETRYDIR'])]
dump(V/'go-tools-protocol-v2.json',{'commands':commands,'environment':environment,
 'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
 'runner_sha256':sha(V/'control/validation_runner_v2.py'),
 'original_failure_sha256':sha(V/'go-tools-attempt-v1-result.json'),
 'verified_installation_inventory_sha256':sha(V/'go-tools-v1/file-inventory-v1.json'),
 'source_review_sha256':prior['inspected_primary_source_sha256'],
 'expected_goenv_report':'','actual_goenv_environment':'off','consumer_executed':False})
results={}
for name,argv in commands:results[name]=run(name,argv,V,target=V/'target-candidate-v1')
assert (V/'logs/go-tools-version-v2/stdout').read_text().strip()=='go version go1.27.2 linux/amd64'
env=json.loads((V/'logs/go-tools-environment-v2/stdout').read_text())
assert env['GOVERSION']=='go1.27.2' and env['GOTELEMETRY']=='off'
assert env['GOENV']=='' and env['GOTOOLCHAIN']=='local'
assert Path(env['GOROOT'])==go.parent.parent
assert Path(env['GOTELEMETRYDIR']).is_relative_to(V)
assert all(sha(p)==row['sha256'] for p,row in files.items())
dump(V/'go-tools-result-v2.json',{'complete':True,'commands':results,'tool':str(go),
 'tool_sha256':sha(go),'tool_version':'go1.27.2','environment':environment,'observed_environment':env,
 'telemetry_off':True,'files_verified':len(files),'global_installation_modified':False,
 'consumer_executed':False,'external_distribution_qualified':False,
 'original_attempt_failed':True,'correction':'Expect the empty disabled configuration filename reported by Go.'})
print(json.dumps({'isolated_go_ready':True,'files_verified':len(files),'original_attempt_failure_preserved':True}),flush=True)
