from pathlib import Path
import json,gzip,re,itertools
from fractions import Fraction
out=Path(__file__).resolve().parent
rows=json.loads((out/'accounts.json').read_text())
issues=[];n=0
for r in rows:
    m=r['mode'];shape=r['shape'];p=r['policy']
    data=[]
    for l in ['fixed','primary','legacy','direct']:
        prefix=f"{l}-{'default' if m=='default' else 'trace'}-{shape[0]}-{shape[1]}-{p}-{m}-"
        data.append([[list(map(int,re.findall(r'-?\d+',line)))[2:] for line in gzip.decompress((out/(prefix+str(pattern)+'.gz')).read_bytes()).decode().splitlines()[1:]] for pattern in [90,165]])
    for cycle,phase,(kind,index) in itertools.product(range(4),range(5),[('requested',5),('usable',8)]):
        vals=[max(rep[cycle*5+phase][index] for rep in obs) for obs in data]
        assert min(vals)>=0
        for col,l in [(2,'legacy'),(3,'direct')]:
            n+=1
            delta=max(0,vals[col]-vals[1]);hist=max(0,vals[1]-vals[0]);cum=delta+hist
            inc_rem=min(128,Fraction(vals[1],100))-delta;cum_rem=min(128,Fraction(vals[0],100))-cum
            if min(inc_rem,cum_rem)<0:
                issues.append(dict(candidate=l,shape=shape,mode=m,policy=p,cycle=cycle+1,phase=['input','plan','replay','trace','cleanup'][phase],kind=kind,values=vals,incremental_remaining=str(inc_rem),cumulative_remaining=str(cum_rem)))
(out/'phase-audit.json').write_text(json.dumps({'checks':n,'failures':issues},indent=2)+'\n')
print('phase observations',n,'exceeded',len(issues))
