from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
out=Path(__file__).resolve().parent
stage=Path('/dev/shm/interval-axis-cost')
stages={'baseline':stage/'baseline','candidate':out.parent/'inline/path_predicates.image'}
cases=['axis_aligned_line_offset_exact','quadratic_bezier_exact_hodograph','rect_pad_board_edge_clearance_exact','rectangular_additive_bead_schedule','specctra_trace_record_exact_import','specctra_grid_route_text_parse_256']
pattern='^(?:'+'|'.join(cases)+')$'
order=['baseline','candidate','candidate','baseline','candidate','baseline','baseline','candidate']
def save(name,x): (out/name).write_text(json.dumps(x,indent=2)+'\n')
def sha(p): return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert sha(stages['baseline'])==json.loads((stage/'record/baseline.image.json').read_text())['sha256']
assert sha(stages['candidate'])==json.loads((out.parent/'inline/bench-identity.json').read_text())['sha256']
for label,imagepath in stages.items():
    shutil.copy2(imagepath,stage/'workload');(stage/'workload').chmod(0o755)
    cmd=['setarch','x86_64','-R','taskset','-c','0',str(stage/'workload'),'--test']
    with (out/(label+'-smoke.log')).open('w') as f:subprocess.run(cmd,cwd=stage,stdout=f,stderr=f,check=True,timeout=240)
save('protocol.json',dict(order=order,cases=cases,images={k:sha(v) for k,v in stages.items()},criterion='one-second warmup, two-second measurement, 30 samples on CPU 0 with ASLR disabled'))
for i,label in enumerate(order):
    image=stage/'workload'
    shutil.copy2(stages[label],image);image.chmod(0o755)
    home=stage/'criterion-axis-inline'
    if home.exists():shutil.rmtree(home)
    args=['setarch','x86_64','-R','taskset','-c','0','python3',str(stage/'record/warm-exec.py'),str(image),'--bench',pattern,'--warm-up-time','1','--measurement-time','2','--sample-size','30','--save-baseline','sample','--noplot']
    with (out/f'run-{i}.log').open('w') as log:subprocess.run(args,cwd=stage,env=os.environ|{'CRITERION_HOME':str(home)},stdout=log,stderr=log,timeout=600,check=True)
    for name in cases:shutil.copytree(home/name/'sample',out/str(i)/name)
    print(i,label,'finished',flush=True)
results={}
for name in cases:
    values=[json.loads((out/str(i)/name/'estimates.json').read_text())['mean'] for i in range(8)]
    blocks=[]
    for k in (0,4):
        b=[values[i] for i in range(k,k+4) if order[i]=='baseline'];c=[values[i] for i in range(k,k+4) if order[i]=='candidate']
        blocks.append(dict(ratio=statistics.mean(x['point_estimate'] for x in c)/statistics.mean(x['point_estimate'] for x in b),adverse=min(x['confidence_interval']['lower_bound'] for x in c)>max(x['confidence_interval']['upper_bound'] for x in b)))
    results[name]=blocks
save('results.json',results)
