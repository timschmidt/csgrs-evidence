from pathlib import Path
import subprocess,os,json,shutil,re,hashlib
out=Path(__file__).resolve().parent;base=out.parent.parent
area=base/'app';cs=area/'csgrs';app=area/'alumina-interface'
env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(area/'target'),CARGO_BUILD_JOBS='16')
name='exact_diagonal_g1_uses_dense_axis_projection_and_lowers_to_terminal_steps'
file='crates/alumina-interface-core/src/machine_profile.rs'
sources={'primary':('ffbd7b42b','5b532c803af86dd9e3d7a66f3651163fd2f7c68b'),'candidate':('75dd0273eb7b9deddcee80fd98a7626a993a9070','e5af3b4383d33c440d087e0d2b933fccde766b9c')}
for label,(crev,irev) in sources.items():
    for root,rev in [(cs,crev),(app,irev)]:
        assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
        subprocess.run(['git','checkout','--detach',rev],cwd=root,check=True)
    model=app/file
    original=model.read_text()
    head='    #[test]\n    fn '+name+'() {'
    assert original.count(head)==1
    end=original.index('\n    }\n\n    #[test]',original.index(head))
    old=original[original.index(head)+len(head):end];body=old
    for i,needle in enumerate(['        let projection = schedule.limits()', '        let no_dilation =', '        let lowered =', '        assert!(lowered.executor_preflight().segment_count > 0);']):
        assert body.count(needle)==1
        body=body.replace(needle,f'        samples[{i}] = Some(crate::axis_allocation::AllocationStats::snapshot());\n'+needle)
    assert re.sub(r'        samples\[[0-3]\] = Some\(crate::axis_allocation::AllocationStats::snapshot\(\)\);\n','',body)==old
    (out/(label+'-body.sha256')).write_text(hashlib.sha256(old.encode()).hexdigest()+'\n')
    wrapper=head+"""
        use crate::axis_allocation::{AllocationStats, observe};
        fn one(samples: &mut [Option<AllocationStats>; 5]) {
"""+body+"""
        }
        let (rows, _) = observe(|| {
            let mut rows = [[None; 5]; 4];
            for row in &mut rows {
                one(row);
                row[4] = Some(AllocationStats::snapshot());
            }
            rows
        });
        for (i, row) in rows.iter().enumerate() {
            for (j, s) in row.iter().enumerate() {
                let s = s.unwrap();
                println!("AXIS {i} {j} {:?} {:?}", s.values(), s.usable());
            }
        }"""
    model.write_text(original[:original.index(head)]+wrapper+original[end:])
    lib=app/'crates/alumina-interface-core/src/lib.rs';lib.write_text(lib.read_text()+'\n#[cfg(test)]\nmod axis_allocation;\n')
    allocator=lib.with_name('axis_allocation.rs');shutil.copyfile(out.parent/'client/src/allocation.rs',allocator)
    build=['cargo','+1.95.0','test','--release','--locked','--offline','-p','alumina-interface-core','--lib','--no-run','--message-format=json']
    with (out/(label+'.jsonl')).open('w') as f,(out/(label+'.build')).open('w') as e:subprocess.run(build,cwd=app,env=env,stdout=f,stderr=e,check=True,timeout=900)
    rows=map(json.loads,(out/(label+'.jsonl')).read_text().splitlines());exes=[Path(x['executable']) for x in rows if x.get('executable') and x['target']['name']=='alumina_interface_core'];assert len(exes)==1
    exe=exes[0];shutil.copyfile(exe,out/(label+'.image'))
    for i in range(3):
        cmd=['setarch','x86_64','-R','taskset','-c','0',str(exe),'machine_profile::tests::'+name,'--exact','--nocapture','--test-threads=1']
        with (out/f'{label}-{i}.log').open('w') as f:subprocess.run(cmd,cwd=app,env=env,stdout=f,stderr=f,check=True,timeout=90)
        log=(out/f'{label}-{i}.log').read_text();assert '1 passed; 0 failed' in log and log.count('AXIS ')==20
    (out/(label+'.patch')).write_bytes(subprocess.check_output(['git','diff'],cwd=app))
    subprocess.run(['git','restore','--',file,str(lib.relative_to(app))],cwd=app,check=True);allocator.unlink()
    print(label,'application completed',flush=True)
assert (out/'candidate-body.sha256').read_bytes()==(out/'primary-body.sha256').read_bytes()
