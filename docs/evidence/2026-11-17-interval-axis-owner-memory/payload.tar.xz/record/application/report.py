from pathlib import Path
import re,json
p=Path(__file__).resolve().parent
data={}
for l in ['primary','candidate','inline']:
    data[l]=[]
    for i in range(3):
        log=(p/f'{l}-{i}.log').read_text()
        samples=[list(map(int,re.findall(r'-?\d+',line.split('AXIS ')[1]))) for line in log.splitlines() if 'AXIS ' in line]
        assert len(samples)==20 and all(s[:2]==[j//5,j%5] and len(s)==11 for j,s in enumerate(samples))
        assert all(s[6]>=s[7]>=0 and s[9]>=s[10]>=0 for s in samples)
        data[l].append(samples)
result={}
for l,obs in data.items():
    result[l]=dict(identical=obs==data['primary'],replicates_equal=obs[0]==obs[1]==obs[2],requested_peak=max(s[6] for o in obs for s in o),usable_peak=max(s[9] for o in obs for s in o),four_cycle_requested_traffic=max(o[-1][5] for o in obs),four_cycle_usable_traffic=max(o[-1][8] for o in obs),cleanup_requested=[[s[7] for s in o[4::5]] for o in obs],cleanup_usable=[[s[10] for s in o[4::5]] for o in obs])
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
