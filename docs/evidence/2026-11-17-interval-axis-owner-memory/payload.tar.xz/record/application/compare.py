from pathlib import Path
import re,json
out=Path(__file__).resolve().parent
metrics=['allocations','frees','reallocations','requested_traffic','requested_peak','requested_live','usable_traffic','usable_peak','usable_live']
def rows(label,index):
    path=out/f'{label}-{index}.log'
    return [list(map(int,re.findall(r'-?\d+',z.split('AXIS ')[1]))) for z in path.read_text().splitlines() if 'AXIS ' in z]
changes=[]
for label in ['candidate','inline']:
    for i in range(3):
        for a,b in zip(rows('primary',i),rows(label,i),strict=True):
            assert a[:2]==b[:2]
            diffs={key:y-x for key,x,y in zip(metrics,a[2:],b[2:],strict=True) if x!=y}
            if diffs:changes.append(dict(source=label,rep=i+1,cycle=a[0]+1,checkpoint=['schedule','transcript','refused_lowering','accepted_lowering','cleanup'][a[1]],deltas=diffs))
(out/'paired-deltas.json').write_text(json.dumps(changes,indent=2)+'\n')
