from pathlib import Path
import json,sys
here=Path(__file__).resolve().parent
root=here.parent
s=(root/'analyze.py').read_text().replace("p=Path(__file__).resolve().parent","p=Path(__file__).resolve().parent.parent").replace("'legacy'","'inline'")
s=s.replace("gzip.decompress((p/(name+'.gz')).read_bytes())","gzip.decompress(((p/'inline' if name.startswith('inline-') else p)/(name+'.gz')).read_bytes())")
s=s.replace("(p/(name+'.log')).read_text()","((p/'inline' if label=='inline' else p)/(name+'.log')).read_text()")
s=s.replace('(p/name).write_text',"(p/'inline'/name).write_text")
exec(compile(s,'inline-analysis','exec'),{'__file__':str(here/'evaluate.py')})
s=(root/'budget.py').read_text().replace("'legacy'","'inline'")
exec(compile(s,'inline-accounts','exec'),{'__file__':str(here/'evaluate.py')})
s=(root/'phase-audit.py').read_text().replace("'legacy'","'inline'").replace("(out/(prefix+str(pattern)+'.gz'))","((out if l=='inline' else out.parent)/(prefix+str(pattern)+'.gz'))")
exec(compile(s,'inline-phases','exec'),{'__file__':str(here/'evaluate.py')})
