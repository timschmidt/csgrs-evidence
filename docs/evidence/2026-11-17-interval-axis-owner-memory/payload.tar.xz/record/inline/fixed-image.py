import json,subprocess,os,shutil,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
stage=Path('/dev/shm/interval-axis-cost');tree=stage/'csgrs'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
old=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
try:
    subprocess.run(['git','checkout','--detach','c9f1f9ac'],cwd=tree,check=True)
    cmd=json.loads((stage/'record/baseline.image.json').read_text())['command']
    env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':str(stage/'target'),'CARGO_BUILD_JOBS':'16'}
    with (out/'fixed-owner.jsonl').open('w') as f,(out/'fixed-owner.build').open('w') as e:subprocess.run(cmd,env=env,cwd=tree,stdout=f,stderr=e,check=True,timeout=600)
    rows=map(json.loads,(out/'fixed-owner.jsonl').read_text().splitlines());exes=[Path(x['executable']) for x in rows if x.get('executable') and x['target']['name']=='path_predicates'];assert len(exes)==1
    path=exes[0];v={'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'bytes':path.stat().st_size,'identical_to_primary':path.read_bytes()==(stage/'baseline').read_bytes()}
    (out/'fixed-owner.json').write_text(json.dumps(v,indent=2)+'\n')
    if not v['identical_to_primary']:shutil.copyfile(path,out/'fixed-owner.image')
    print(v)
finally:subprocess.run(['git','checkout','--detach',old],cwd=tree,check=True)
