from pathlib import Path
import json,subprocess
out=Path(__file__).resolve().parent
records={}
for name,path in [('baseline',Path('/dev/shm/interval-axis-cost/baseline')),('previous',Path('/dev/shm/interval-axis-cost/candidate')),('inline',out/'path_predicates.image')]:
    ranges={};unsized=0
    for line in subprocess.check_output(['readelf','-Ws',str(path)],text=True).splitlines():
        f=line.split(None,7)
        if len(f)<8 or f[3]!='FUNC' or f[6]=='UND':continue
        n=int(f[2],0);a=int(f[1],16)
        if n:ranges.setdefault(f[6],[]).append((a,a+n))
        else:unsized+=1
    total=0
    for spans in ranges.values():
        end=0
        for a,b in sorted(spans):total+=max(0,b-max(end,a));end=max(end,b)
    sections={q.split()[0]:int(q.split()[1]) for q in subprocess.check_output(['size','-A',str(path)],text=True).splitlines() if q.startswith('.')}
    records[name]=dict(file=path.stat().st_size,text=sections['.text'],function_union=total,unsized=unsized,exception_table=sections['.gcc_except_table'])
(out/'sizes.json').write_text(json.dumps(records,indent=2)+'\n')
print(records)
