from pathlib import Path
import gzip,json,os,subprocess,hashlib,shutil,itertools,time
out=Path(__file__).resolve().parent.parent
client=out/'client';stage=out.parent;tree=stage/'csgrs'
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':str(stage/'target'),'CARGO_BUILD_JOBS':'16'}
variants=[('inline','interval-axis-projection-wrapper-stack')]

def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
out=out/'inline'
image_dir=out/'images';image_dir.mkdir(exist_ok=True)
for label,rev in variants:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
    subprocess.run(['git','checkout','--detach',rev],cwd=tree,check=True)
    owner='hyperdynamics' if label=='direct' else 'hyperpath'
    feature=', features = ["axis-projection"]' if label=='direct' else ''
    m=f"""[package]
name = "axis-consumer"
version = "0.0.0"
edition = "2024"
[workspace]
[features]
direct = []
trace = ["{owner}/dispatch-trace"]
[dependencies]
{owner} = {{ path = "{tree}/crates/{owner}", default-features = false{feature} }}
hyperlimit = {{ path = "{tree}/crates/hyperlimit", default-features = false }}
hyperreal = {{ path = "{tree}/crates/hyperreal", default-features = false }}
"""
    (client/'Cargo.toml').write_text(m)
    subprocess.run(['cargo','+1.95.0','generate-lockfile','--offline'],cwd=client,env=env,check=True)
    for p in ['Cargo.lock','Cargo.toml']:shutil.copyfile(client/p,out/(label+'-'+p))
    for traced in (False,True):
        features=([label] if label=='direct' else [])+(['trace'] if traced else [])
        name=label+('-trace' if traced else '-default')
        cmd=['cargo','+1.95.0','build','--release','--offline','--locked']+(['--features',','.join(features)] if features else [])
        with (out/(name+'.build')).open('w') as f:subprocess.run(cmd,cwd=client,env=env,stdout=f,stderr=f,check=True,timeout=600)
        lint=['cargo','+1.95.0','clippy','--release','--offline','--locked']+(['--features',','.join(features)] if features else [])+['--','-D','warnings']
        with (out/(name+'.lint')).open('w') as f:subprocess.run(lint,cwd=client,env=env,stdout=f,stderr=f,check=True,timeout=600)
        image=stage/'target/release/axis-consumer';shutil.copyfile(image,image_dir/name)
        save(out/(name+'.json'),dict(command=cmd,revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),sha256=hashlib.file_digest(image.open('rb'),'sha256').hexdigest(),bytes=image.stat().st_size))
        for (n,k),policy,mode,action in itertools.product([(1,1),(4,3),(32,8)],['strict','approx'],(['active','passive'] if traced else ['default']),['control','90','165']):
            key=f'{name}-{n}-{k}-{policy}-{mode}-{action}'
            args=['setarch','x86_64','-R','taskset','-c','0',str(image),str(n),str(k),policy,mode,action]
            p=subprocess.run(args,cwd=stage,env=env,capture_output=True,timeout=60)
            (out/(key+'.gz')).write_bytes(gzip.compress(p.stdout,mtime=0))
            (out/(key+'.log')).write_bytes(p.stderr)
            if p.returncode:raise RuntimeError((key,p.returncode,p.stderr[-1000:]))
        print(name,'completed',flush=True)
