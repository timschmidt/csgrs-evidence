import subprocess,os,shutil,json,hashlib
from pathlib import Path
out=Path(__file__).resolve().parent
owner=Path('/dev/shm/interval-axis-memory/csgrs');bench=Path('/dev/shm/interval-axis-cost/csgrs');rev='62bcec291'
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-memory/owner-target','CARGO_BUILD_JOBS':'16'}
def run(label,cmd,tree):
    with (out/(label+'.log')).open('w') as f:subprocess.run(cmd,env=env,cwd=tree,stdout=f,stderr=f,timeout=900,check=True)
args=['cargo','+1.95.0']
assert subprocess.check_output(['git','rev-parse','--short=9','HEAD'],cwd=owner,text=True).strip()==rev
run('owners',args+['test','--locked','--offline','-p','hyperpath','-p','hyperdynamics','--all-features'],owner)
run('clippy',args+['clippy','--locked','--offline','-p','hyperpath','--all-targets','--all-features','--','-D','warnings'],owner)
run('fmt',args+['fmt','-p','hyperpath','--','--check'],owner)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=bench)
subprocess.run(['git','checkout','--detach',rev],cwd=bench,check=True)
env['CARGO_TARGET_DIR']='/dev/shm/interval-axis-cost/target'
command=json.loads(Path('/dev/shm/interval-axis-cost/record/candidate.image.json').read_text())['command']
with (out/'bench.jsonl').open('w') as f,(out/'bench.build').open('w') as e:subprocess.run(command,cwd=bench,env=env,stdout=f,stderr=e,check=True,timeout=900)
rows=map(json.loads,(out/'bench.jsonl').read_text().splitlines())
images=[Path(x['executable']) for x in rows if x.get('executable') and x['target']['name']=='path_predicates'];assert len(images)==1
image=images[0];shutil.copyfile(image,out/'path_predicates.image')
meta=dict(sha256=hashlib.file_digest(image.open('rb'),'sha256').hexdigest(),bytes=image.stat().st_size,identical=image.read_bytes()==Path('/dev/shm/interval-axis-cost/candidate').read_bytes())
(out/'bench.sections').write_bytes(subprocess.check_output(['size','-A',str(image)]))
(out/'bench-identity.json').write_text(json.dumps(meta,indent=2)+'\n');print(meta)
