from pathlib import Path
import json,gzip,statistics,re
p=Path(__file__).resolve().parent
cases=json.loads((p/'timing/results.json').read_text())
assert len(cases)==6
samples=[json.loads(s.read_text()) for s in (p/'timing').glob('[0-7]/*/sample.json')]
assert len(samples)==48 and all(len(s['times'])==30 and len(s['iters'])==30 for s in samples)
smokes=[(p/f'timing/{name}-smoke.log').read_text().count('Success') for name in ['baseline','candidate']]
assert smokes[0]==smokes[1] and min(smokes)>0
t=json.loads((p/'throughput/runtime.json').read_text());assert len(t['summary'])==36
compact={}
for name in ['direct','inline']:
    q=[row for row in t['summary'] if row['source']==name]
    ratios=[r['median'] for r in q]
    compact[name]=dict(min_median=min(ratios),max_median=max(ratios),median_slower=sum(x>1 for x in ratios),six_of_six_slower=[r for r in q if r['slower']==6],six_of_six_faster=[r for r in q if r['slower']==0],paired_slower=sum(r['slower'] for r in q))
v=dict(bench_smokes=smokes,criterion_case_runs=len(samples),criterion_samples=sum(len(s['times']) for s in samples),criterion_iterations=sum(sum(s['iters']) for s in samples),cases=cases,adverse_in_both=[k for k,v in cases.items() if all(b['adverse'] for b in v)],throughput_samples=t['samples'],throughput_iterations=t['iterations'],throughput=compact)
(p/'runtime-summary.json').write_text(json.dumps(v,indent=2)+'\n')
