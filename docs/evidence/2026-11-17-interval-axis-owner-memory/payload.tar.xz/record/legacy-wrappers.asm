
images/legacy-default:     file format elf64-x86-64


Disassembly of section .text:

00000000001124d0 <hyperpath::routing::axis_projection::plan_axis_projected_motion_limits>:
  1124d0:	53                   	push   %rbx
  1124d1:	48 81 ec b0 01 00 00 	sub    $0x1b0,%rsp
  1124d8:	48 89 fb             	mov    %rdi,%rbx
  1124db:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  1124e0:	ff 15 5a 0d 1d 00    	call   *0x1d0d5a(%rip)        # 2e3240 <_DYNAMIC+0x738>
  1124e6:	31 c0                	xor    %eax,%eax
  1124e8:	48 3b 44 24 08       	cmp    0x8(%rsp),%rax
  1124ed:	71 2c                	jno    11251b <hyperpath::routing::axis_projection::plan_axis_projected_motion_limits+0x4b>
  1124ef:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  1124f6:	00 00 80 
  1124f9:	0f b6 4c 24 10       	movzbl 0x10(%rsp),%ecx
  1124fe:	48 8d 15 87 fa fa ff 	lea    -0x50579(%rip),%rdx        # c1f8c <anon.292cb22d73fd98a3b9d6ee470ce4cf6b.0.llvm.13958645719358473670+0xe74>
  112505:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
  112509:	88 4b 08             	mov    %cl,0x8(%rbx)
  11250c:	48 89 03             	mov    %rax,(%rbx)
  11250f:	48 89 d8             	mov    %rbx,%rax
  112512:	48 81 c4 b0 01 00 00 	add    $0x1b0,%rsp
  112519:	5b                   	pop    %rbx
  11251a:	c3                   	ret
  11251b:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  112520:	ba a8 01 00 00       	mov    $0x1a8,%edx
  112525:	48 89 df             	mov    %rbx,%rdi
  112528:	ff 15 3a 08 1d 00    	call   *0x1d083a(%rip)        # 2e2d68 <memcpy@GLIBC_2.14>
  11252e:	48 89 d8             	mov    %rbx,%rax
  112531:	48 81 c4 b0 01 00 00 	add    $0x1b0,%rsp
  112538:	5b                   	pop    %rbx
  112539:	c3                   	ret
  11253a:	cc                   	int3
  11253b:	cc                   	int3
  11253c:	cc                   	int3
  11253d:	cc                   	int3
  11253e:	cc                   	int3
  11253f:	cc                   	int3

0000000000112540 <hyperpath::routing::axis_projection::certify_axis_projected_motion_limits>:
  112540:	53                   	push   %rbx
  112541:	48 81 ec c0 00 00 00 	sub    $0xc0,%rsp
  112548:	48 89 fb             	mov    %rdi,%rbx
  11254b:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
  112552:	00 
  112553:	8b 84 24 e0 00 00 00 	mov    0xe0(%rsp),%eax
  11255a:	89 44 24 10          	mov    %eax,0x10(%rsp)
  11255e:	0f 11 04 24          	movups %xmm0,(%rsp)
  112562:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  112567:	ff 15 db 0c 1d 00    	call   *0x1d0cdb(%rip)        # 2e3248 <_DYNAMIC+0x740>
  11256d:	31 c0                	xor    %eax,%eax
  11256f:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  112574:	71 2c                	jno    1125a2 <hyperpath::routing::axis_projection::certify_axis_projected_motion_limits+0x62>
  112576:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  11257d:	00 00 80 
  112580:	0f b6 4c 24 20       	movzbl 0x20(%rsp),%ecx
  112585:	48 8d 15 00 fa fa ff 	lea    -0x50600(%rip),%rdx        # c1f8c <anon.292cb22d73fd98a3b9d6ee470ce4cf6b.0.llvm.13958645719358473670+0xe74>
  11258c:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
  112590:	88 4b 08             	mov    %cl,0x8(%rbx)
  112593:	48 89 03             	mov    %rax,(%rbx)
  112596:	48 89 d8             	mov    %rbx,%rax
  112599:	48 81 c4 c0 00 00 00 	add    $0xc0,%rsp
  1125a0:	5b                   	pop    %rbx
  1125a1:	c3                   	ret
  1125a2:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  1125a7:	ba a8 00 00 00       	mov    $0xa8,%edx
  1125ac:	48 89 df             	mov    %rbx,%rdi
  1125af:	ff 15 b3 07 1d 00    	call   *0x1d07b3(%rip)        # 2e2d68 <memcpy@GLIBC_2.14>
  1125b5:	48 89 d8             	mov    %rbx,%rax
  1125b8:	48 81 c4 c0 00 00 00 	add    $0xc0,%rsp
  1125bf:	5b                   	pop    %rbx
  1125c0:	c3                   	ret
