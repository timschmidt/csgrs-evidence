from pathlib import Path
import json,shutil,subprocess,os,hashlib
out=Path(__file__).resolve().parent
record=out.parent;root=record.parent
tree=root/'csgrs';client=out/'client'
source=(record/'client/src/main.rs').read_text()
head=source[:source.index('unsafe extern "C"')].replace('mod allocation;','').replace('use allocation::{AllocationStats, observe};','').replace('use std::ffi::c_void;','')
params='''struct Job {
    spans: usize,
    axes: usize,
    policy: PredicatePolicy,
    #[cfg(feature = "trace")]
    active: bool,
    control: bool,
}
'''
cycle=source[source.index('fn cycle('):source.index('extern "C" fn worker')]
cycle=cycle.replace(', row: &mut [Option<AllocationStats>; 5]','')
cycle='\n'.join(x for x in cycle.splitlines() if 'AllocationStats::snapshot()' not in x)
assert 'allocat' not in cycle
cycle=cycle.replace('drop((plan, replay, limits, spans, small));','drop(std::hint::black_box((plan, replay, limits, spans, small)));')
assert 'black_box' in cycle
main='''
fn main() {
    let arg: Vec<_> = std::env::args().collect();
    let mode = &arg[1];
    for (n,k,repetitions) in [(1,1,64),(4,3,8),(32,8,1)] {
        for (tag,policy) in [("strict", PredicatePolicy::STRICT),("approx",PredicatePolicy::APPROXIMATE_512)] {
            if arg.len() > 3 && (n != arg[3].parse::<usize>().unwrap() || tag != arg[4]) { continue; }
            let job = Job { spans:n, axes:k, policy, control:mode=="control",
                #[cfg(feature="trace")] active:arg[2]=="active" };
            if job.control { println!("CASE {n} {k} {tag}"); cycle(&job); continue; }
            let warm = std::time::Instant::now();
            while warm.elapsed().as_millis()<100 { cycle(std::hint::black_box(&job)); }
            for i in 0..30 {
                let start=std::time::Instant::now();
                for _ in 0..repetitions { cycle(std::hint::black_box(&job)); }
                let ns=start.elapsed().as_nanos();
                println!("SAMPLE {n} {k} {tag} {i} {repetitions} {ns}");
            }
        }
    }
}
'''
(client/'src/main.rs').write_text(head+params+cycle+main)
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':str(root/'target'),'CARGO_BUILD_JOBS':'16'}
for label,rev in [('primary','ffbd7b42b'),('inline','62bcec291'),('direct','62bcec291')]:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
    subprocess.run(['git','checkout','--detach',rev],cwd=tree,check=True)
    dep='legacy' if label=='inline' else label
    for n in ['Cargo.toml','Cargo.lock']:shutil.copyfile(record/(dep+'-'+n),client/n)
    for f in ['default','trace']:
        features=([label] if label=='direct' else [])+(['trace'] if f=='trace' else [])
        cmd=['cargo','+1.95.0','build','--locked','--offline','--release']+(['--features',','.join(features)] if features else [])
        with (out/(label+'-'+f+'.build')).open('w') as log:subprocess.run(cmd,cwd=client,env=env,stdout=log,stderr=log,check=True)
        dest=out/(label+'-'+f+'.image');shutil.copy2(root/'target/release/axis-consumer',dest)
        for mode in (['active','passive'] if f=='trace' else ['default']):
            import gzip
            raw=b''
            for n,k in [(1,1),(4,3),(32,8)]:
                for pol in ['strict','approx']:
                    actual=subprocess.check_output([str(dest),'control',mode,str(n),pol],env=env,cwd=out)
                    expected=f'CASE {n} {k} {pol}\n'.encode()+gzip.decompress((record/f'fixed-{f}-{n}-{k}-{pol}-{mode}-control.gz').read_bytes())
                    assert actual==expected,(label,mode,n,k,pol)
                    raw+=actual
            (out/f'{label}-{mode}-output.gz').write_bytes(gzip.compress(raw,mtime=0))
