from pathlib import Path
import hashlib,json,subprocess,shutil,itertools,statistics
out=Path(__file__).resolve().parent
slots=['primary','inline','direct'];orders=list(itertools.permutations(slots))
exe=out.parent.parent/'timed-consumer'
warm='/dev/shm/interval-axis-cost/record/warm-exec.py'
modes=['default','passive','active']
records=[]
for b,order in enumerate(orders):
    for j in range(3):
        mode=modes[(b+j)%3]
        for l in order:
            name=f'{b}-{mode}-{l}'
            image=out/(l+'-'+('default' if mode=='default' else 'trace')+'.image')
            shutil.copy2(image,exe);exe.chmod(0o755)
            result=subprocess.check_output(['setarch','x86_64','-R','taskset','-c','0','python3',warm,str(exe),'time',mode],cwd=exe.parent,text=True,timeout=120)
            (out/(name+'.samples')).write_text(result)
            for row in result.splitlines():
                if row.startswith('SAMPLE '):
                    _,n,k,pol,i,count,ns=row.split()
                    records.append(dict(block=b,mode=mode,source=l,spans=int(n),axes=int(k),policy=pol,sample=int(i),iterations=int(count),ns=int(ns)))
    print('block',b,'complete',flush=True)
assert len(records)==54*180
summary=[]
for n,k in [(1,1),(4,3),(32,8)]:
    for policy,mode,l in itertools.product(['strict','approx'],modes,slots[1:]):
        ratios=[]
        for b in range(6):
            def avg(source):
                subset=[r for r in records if (r['block'],r['spans'],r['axes'],r['policy'],r['mode'],r['source'])==(b,n,k,policy,mode,source)]
                assert len(subset)==30
                return sum(r['ns'] for r in subset)/sum(r['iterations'] for r in subset)
            ratios.append(avg(l)/avg('primary'))
        summary.append(dict(spans=n,axes=k,policy=policy,mode=mode,source=l,ratios=ratios,median=statistics.median(ratios),slower=sum(x>1 for x in ratios)))
(out/'runtime.json').write_text(json.dumps(dict(summary=summary,samples=len(records),iterations=sum(r['iterations'] for r in records)),indent=2)+'\n')
