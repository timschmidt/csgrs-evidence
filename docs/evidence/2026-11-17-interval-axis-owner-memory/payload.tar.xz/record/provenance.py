from pathlib import Path
import os,hashlib,subprocess,json
out=Path(__file__).resolve().parent
def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
def digest(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
parents=Path('/tmp/interval-refactor/cancellation-finish-consumer/consumer')
refs={'fixed':'c9f1f9ac','primary':'ffbd7b42b','legacy':'75dd0273e','inline':'62bcec291'}
revs={k:git('/mnt/development/csgrs','rev-parse',v) for k,v in refs.items()}
for name in ('build.rs','stack.c'): assert (parents/name).read_bytes()==(out/'client'/name).read_bytes()
allocator=(parents/'allocation.rs').read_text().replace('    fn snapshot() -> Self','    pub fn snapshot() -> Self');assert allocator==(out/'client/src/allocation.rs').read_text()
assert allocator==(out/'application/allocator/lib.rs').read_text()
r={'revisions':revs,'interface_primary':git('/mnt/development/alumina-interface','rev-parse','5b532c8'),'interface_candidate':git('/mnt/development/alumina-interface','rev-parse','e5af3b4'),'firmware':git('/mnt/development/alumina-firmware','rev-parse','HEAD'),'allocator_origin':str(parents),'origin_sha256':{n:digest(parents/n) for n in ('allocation.rs','stack.c','build.rs')},'rust':subprocess.check_output(['rustc','+1.95.0','-vV'],text=True),'system':subprocess.check_output(['uname','-a'],text=True),'libc':os.confstr('CS_GNU_LIBC_VERSION'),'flags':{k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'owner_profile':'Cargo release for standalone external client; owner benchmark workspace bench profile','application_profile':'Interface release libtest','queue_plan_sha256':digest(Path('/tmp/interval-refactor/coordinated-ci/quiet-workflow-executed-plan.json'))}
(out/'provenance.json').write_text(json.dumps(r,indent=2)+'\n')
