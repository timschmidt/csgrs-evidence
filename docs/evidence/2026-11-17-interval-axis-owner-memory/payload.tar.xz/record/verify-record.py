from pathlib import Path
import hashlib,json,subprocess,gzip,re
r=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
checks={}
for l in ['fixed','primary','legacy','direct','inline']:
    p=r/'inline' if l=='inline' else r
    for mode in ['default','trace']:
        key=l+'-'+mode
        assert load(p/(key+'.json'))['sha256']==sha(p/'images'/key)
        assert 'warning:' not in (p/(key+'.build')).read_text()
        assert 'Finished' in (p/(key+'.lint')).read_text()
        checks[key]=sha(p/'images'/key)
for d in [r,r/'inline']:
    s=load(d/'summary.json');assert s['domains']==18 and s['full_output_matches']==54 and s['completed_measured_cycles']==576
    assert not s['nonconstant_cleanup_cycles_two_through_four']
for v in ['legacy','direct','inline']:
    d=r/'inline' if v=='inline' else r
    rows=load(d/'budget-summary.json')[v]
    expect=['stack-cum','stack-inc'] if v=='legacy' else []
    assert all(x['failures']==expect for x in rows)
    assert not load(d/'phase-audit.json')['failures']
suite_hits=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', (r/'inline/owners.log').read_text())]
assert sum(suite_hits)==602
assert 'Finished' in (r/'inline/clippy.log').read_text() and (r/'inline/fmt.log').stat().st_size==0
for p in [r/'application/primary-body.sha256',r/'application/inline-body.sha256']:assert p.read_bytes()==(r/'application/candidate-body.sha256').read_bytes()
for l in ['primary','candidate','inline']:
    for i in range(3):
        raw=(r/f'application/{l}-{i}.log').read_text()
        assert '1 passed; 0 failed' in raw and raw.count('AXIS ')==20
app=r/'application';assert (app/'summary.json').is_file()
s=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split()
assert s[0]=='T' and s[19]=='38218939'
for work in [r.parent/'app/csgrs',r.parent/'app/alumina-interface',r.parent/'csgrs']:
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=work)
v=dict(optimized_allocator_image_hashes=checks,owner_tests=sum(suite_hits),fixture_assertions_preserved=True,held_queue=True,total_distinct_controls=90,total_distinct_histories=180,total_distinct_cycles=720,application_processes=9,application_cycles=36)
(r/'audit.json').write_text(json.dumps(v,indent=2)+'\n')
