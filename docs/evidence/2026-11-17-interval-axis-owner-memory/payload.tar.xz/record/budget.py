from pathlib import Path
import json
from fractions import Fraction
out=Path(__file__).resolve().parent
rows=json.loads((out/'accounts.json').read_text())
def cap(name):
    if name in ('allocations','frees','reallocations'):return 0,0
    if name=='stack':return 256,2
    if name.endswith('_peak'):return 256,1
    if name.endswith('_traffic'):return 1024,Fraction(1,2)
    return 128,1
summary={}; ledger=[]
for r in rows:
    for l,col in [('legacy',2),('direct',3)]:
        failures=[];checks={}
        for metric,a in r['accounts'].items():
            v=a['values']
            fixed,primary=v[:2]; assert min(v)>=0
            delta=max(0,v[col]-primary);gross=max(0,primary-fixed)+delta
            absolute,percent=cap(metric)
            imax=min(absolute,primary*Fraction(percent)/100)
            cmax=min(absolute,fixed*Fraction(percent)/100)
            checks[metric]=dict(observations=v,incremental=delta,cumulative=gross,incremental_remaining=str(imax-delta),cumulative_remaining=str(cmax-gross))
            for label,x,m in [('inc',delta,imax),('cum',gross,cmax)]:
                if x>m:failures.append(metric+'-'+label)
        obs=r['observations'][l];stress=r['shape'][0]==32
        pe=16*1024**2 if stress else 4*1024**2
        traffic=256*1024**2 if stress else 32*1024**2
        for o in obs:
            for m in ['requested_peak','usable_peak']:
                if o['metrics'][m]>pe:failures.append(m+'-capacity')
            for m in ['requested_traffic','usable_traffic']:
                if o['metrics'][m]>traffic:failures.append(m+'-capacity')
            if o['headroom']<1024**2:failures.append('stack-reserve')
            for m in ['cleanup','usable_cleanup']:
                if len(set(o[m][1:]))!=1:failures.append(m+'-retention')
        failures=sorted(set(failures))
        summary.setdefault(l,[]).append(dict(shape=r['shape'],policy=r['policy'],mode=r['mode'],failures=failures))
        ledger.append(dict(candidate=l,shape=r['shape'],policy=r['policy'],mode=r['mode'],checks=checks,failures=failures))
(out/'budget-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'budget-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
for l,items in summary.items():
    print(l, sum(not i['failures'] for i in items),'passed of',len(items),'failed tags:',sorted(set(f for i in items for f in i['failures'])))
