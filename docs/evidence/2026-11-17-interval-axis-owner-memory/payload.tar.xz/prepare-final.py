from pathlib import Path
import shutil
base=Path(__file__).resolve().parent
draft=base/'initial-record'
assert not draft.exists()
(base/'record').rename(draft)
out=base/'record';out.mkdir()
shutil.copytree(draft/'client',out/'client')
for n in ['run.py','protocol.txt','analyze.py']:shutil.copy2(draft/n,out/n)
p=out/'client/src/main.rs';s=p.read_text().replace('use allocation::{','use std::ffi::c_void;\nuse allocation::{',1)
s=s.replace('fn(*mut Job), context: *mut Job','fn(*mut c_void), context: *mut c_void').replace('fn worker(ptr: *mut Job)','fn worker(ptr: *mut c_void)').replace('unsafe { &mut *ptr }','unsafe { &mut *ptr.cast::<Job>() }').replace('measure_stack(worker,&mut job,','measure_stack(worker,(&raw mut job).cast(),')
s=s.replace('    active: bool,','    #[cfg(feature = "trace")]\n    active: bool,').replace('        active:args[3]=="active",','        #[cfg(feature = "trace")]\n        active:args[3]=="active",')
p.write_text(s)
p=out/'run.py';s=p.read_text().replace("        image=stage/",'''        lint=['cargo','+1.95.0','clippy','--release','--offline','--locked']+(['--features',','.join(features)] if features else [])+['--','-D','warnings']
        with (out/(name+'.lint')).open('w') as f:subprocess.run(lint,cwd=client,env=env,stdout=f,stderr=f,check=True,timeout=600)
        image=stage/''')
p.write_text(s)
