#![allow(deprecated)] // Exercise legacy callers through the coordinated release.
mod allocation;
use allocation::{AllocationStats, observe};
use axis::{AffineSpanAxisProjection, AxisMotionLimits, certify_axis_projected_motion_limits, plan_axis_projected_motion_limits};
use hyperlimit::PredicatePolicy;
use hyperreal::Real;
#[cfg(feature = "direct")]
use hyperdynamics::axis_projection as axis;
#[cfg(not(feature = "direct"))]
use hyperpath as axis;
#[cfg(feature = "direct")]
use axis::AxisProjectionError as Error;
#[cfg(not(feature = "direct"))]
use axis::RouteCertificationError as Error;

unsafe extern "C" {
    fn measure_stack(callback: extern "C" fn(*mut Job), context: *mut Job, warm: i32, pattern: u8) -> usize;
}

struct Job {
    spans: usize,
    axes: usize,
    policy: PredicatePolicy,
    active: bool,
    control: bool,
    samples: [[Option<AllocationStats>; 5]; 4],
}

fn cycle(job: &Job, row: &mut [Option<AllocationStats>; 5]) {
    #[cfg(feature = "trace")]
    let guard = job.active.then(hyperreal::dispatch_trace::recording_scope);
    let limits: Vec<_> = (0..job.axes).map(|i| AxisMotionLimits {
        maximum_velocity: Real::from(3+i as i32),
        maximum_acceleration: Real::from(4+i as i32),
        maximum_jerk: Real::from(5+i as i32),
    }).collect();
    let small=(Real::one()/Real::from(3)).unwrap();
    let spans: Vec<_> = (0..job.spans).map(|i| AffineSpanAxisProjection {
        absolute_axis_derivatives: (0..job.axes).map(|j| match (i+j)%3 {
            0 => Real::one(), 1=>Real::zero(), _=>small.clone(),
        }).collect()
    }).collect();
    let rejected = plan_axis_projected_motion_limits(&[], &limits, job.policy).unwrap_err();
    assert_eq!(rejected, Error::EmptyAxisProjection);
    row[0]=Some(AllocationStats::snapshot());
    let plan=plan_axis_projected_motion_limits(&spans,&limits,job.policy).unwrap();
    row[1]=Some(AllocationStats::snapshot());
    assert_eq!(plan.maximum_path_feed,Real::from(3));
    assert_eq!(plan.maximum_path_acceleration,Real::from(4));
    assert_eq!(plan.maximum_path_jerk,Real::from(5));
    for at in [plan.feed_bottleneck,plan.acceleration_bottleneck,plan.jerk_bottleneck] {
        assert_eq!((at.span_index,at.axis_index),(0,0));
    }
    assert!(plan.all_satisfied());
    assert_eq!(plan.certification.rows.len(), job.spans*job.axes);
    let replay=certify_axis_projected_motion_limits(&spans,&limits,plan.maximum_path_feed.clone(),
        plan.maximum_path_acceleration.clone(), plan.maximum_path_jerk.clone(),job.policy).unwrap();
    row[2]=Some(AllocationStats::snapshot());
    assert_eq!(plan.certification,replay);
    #[cfg(feature = "trace")]
    let trace=job.active.then(hyperreal::dispatch_trace::take_trace);
    #[cfg(feature = "trace")]
    drop(guard);
    row[3]=Some(AllocationStats::snapshot());
    if job.control {
        println!("OUTPUT {plan:?} {replay:?} {rejected:?}");
        #[cfg(feature = "trace")]
        println!("TRACE {trace:?}");
    }
    #[cfg(feature = "trace")]
    drop(trace);
    drop((plan,replay,limits,spans,small));
    row[4]=Some(AllocationStats::snapshot());
}

extern "C" fn worker(ptr: *mut Job) {
    let job=unsafe { &mut *ptr };
    let (rows,_) = observe(|| {
        let mut rows=[[None;5];4];
        for row in &mut rows {cycle(job,row);}
        rows
    });
    job.samples=rows;
}

fn main(){
    let args:Vec<_>=std::env::args().skip(1).collect();
    let mut job=Job{spans:args[0].parse().unwrap(),axes:args[1].parse().unwrap(),
        policy:if args[2]=="strict" {PredicatePolicy::STRICT} else {PredicatePolicy::APPROXIMATE_512},
        active:args[3]=="active",control:args[4]=="control",samples:[[None;5];4]};
    if job.control {cycle(&job,&mut [None;5]);return}
    let peak=unsafe{ measure_stack(worker,&mut job,0,args[4].parse().unwrap()) };
    println!("STACK {peak}");
    for (i,row) in job.samples.iter().enumerate(){
        for (j,s) in row.iter().enumerate(){
            let s=s.unwrap();
            println!("ROW {i} {j} {:?} {:?}",s.values(),s.usable());
        }
    }
}
