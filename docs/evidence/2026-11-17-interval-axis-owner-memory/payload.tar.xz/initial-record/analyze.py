import gzip,itertools,json,re,hashlib,statistics
from pathlib import Path
p=Path(__file__).resolve().parent
labels=['fixed','primary','legacy','direct']
rows=[];counts={};extrema={}
def load(name):
    return gzip.decompress((p/(name+'.gz')).read_bytes())
def save(name,data):
    (p/name).write_text(json.dumps(data,indent=2)+'\n')
def h(b):return hashlib.sha256(b).hexdigest()
def tagged(name,mode,n,k,policy):
    return f'{name}-'+('default' if mode=='default' else 'trace')+f'-{n}-{k}-{policy}-{mode}'
for (n,k),policy,mode in itertools.product([(1,1),(4,3),(32,8)],['strict','approx'],['default','passive','active']):
    records={};controls={}
    for label in labels:
        key=tagged(label,mode,n,k,policy)
        result=load(key+'-control')
        assert result.startswith(b'OUTPUT PlannedAxisProjectedMotionLimits') and b'EmptyAxisProjection' in result
        controls[label]=h(result)
        # Equal debug transcripts are supplemental to independent bottleneck, output and replay assertions.
        assert result==load(tagged('fixed',mode,n,k,policy)+'-control')
        observations=[]
        for pattern in (90,165):
            name=key+'-'+str(pattern)
            lines=load(name).decode().splitlines()
            assert len(lines)==21
            size,guard,caller,peak,headroom=map(int,re.fullmatch(r'HEADROOM (\d+) (\d+) (\d+) (\d+) (\d+)\n',(p/(name+'.log')).read_text()).groups())
            assert lines[0]==f'STACK {peak}' and headroom==size-guard-caller-peak and peak>0
            states=[]
            for j,line in enumerate(lines[1:]):
                a=list(map(int,re.findall(r'-?\d+',line)))
                assert len(a)==11 and a[:2]==[j//5,j%5]
                states.append(a[2:])
            end=states[-1]
            metrics=dict(stack=peak,allocations=end[0],frees=end[1],reallocations=end[2],requested_traffic=end[3],requested_peak=end[4],requested_after_cleanup=end[5],usable_traffic=end[6],usable_peak=end[7],usable_after_cleanup=end[8])
            for j,stage in enumerate(['input','plan','replay','trace','cleanup']):
                for index,kind in [(5,'requested'),(8,'usable')]:
                    metrics[f'{kind}_{stage}_max']=max(s[index] for s in states[j::5])
            observations.append(dict(metrics=metrics,cleanup=[s[5] for s in states[4::5]],usable_cleanup=[s[8] for s in states[4::5]],headroom=headroom))
        records[label]=observations
    accounts={}
    for name in records['fixed'][0]['metrics']:
        values=[max(o['metrics'][name] for o in records[l]) for l in labels]
        fixed,primary,legacy,direct=values
        historical=max(0,primary-fixed)
        accounts[name]=dict(values=values,primary_minus_fixed=primary-fixed,legacy_minus_primary=legacy-primary,direct_minus_primary=direct-primary,
                            positive_via_primary=[historical+max(0,legacy-primary),historical+max(0,direct-primary)])
    rows.append(dict(shape=[n,k],policy=policy,mode=mode,controls=controls,observations=records,accounts=accounts))
for metric in rows[0]['accounts']:
    counts[metric]={}
    for branch,col in [('legacy',2),('direct',3)]:
        delta=[r['accounts'][metric]['values'][col]-r['accounts'][metric]['values'][1] for r in rows]
        counts[metric][branch]=dict(increased=sum(x>0 for x in delta),equal=delta.count(0),decreased=sum(x<0 for x in delta),min=min(delta),max=max(delta))
    extrema[metric]=max(max(r['accounts'][metric]['values']) for r in rows)
increasing_cleanup=[]
for r in rows:
    for label,obs in r['observations'].items():
        if any(len(set(o['cleanup'][1:]))!=1 or len(set(o['usable_cleanup'][1:]))!=1 for o in obs):
            increasing_cleanup.append([r['shape'],r['policy'],r['mode'],label])
save('accounts.json',rows)
save('summary.json',dict(domains=len(rows),controls=4*len(rows),full_output_matches=3*len(rows),observed_histories=8*len(rows),completed_measured_cycles=32*len(rows),counts=counts,maxima=extrema,minimum_untouched_stack=min(o['headroom'] for r in rows for obs in r['observations'].values() for o in obs),nonconstant_cleanup_cycles_two_through_four=increasing_cleanup))
