from pathlib import Path
import hashlib,subprocess,tarfile,json,io,shutil,importlib.util
root=Path(__file__).resolve().parent
repo=Path('/mnt/development/csgrs-evidence')
record='docs/evidence/2026-11-17-interval-axis-owner-memory'
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
def digest(path):return hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
assert not git('status','--porcelain')
out=root/'archive';out.mkdir()
files=sorted([p for d in ('record','initial-record') for p in (root/d).rglob('*') if p.is_file()]+[root/'prepare-final.py',Path(__file__)])
hashes={f.relative_to(root).as_posix():digest(f) for f in files}
with tarfile.open(out/'payload.tar.xz','w:xz',preset=3) as t:
    for f in files:
        a=tarfile.TarInfo(f.relative_to(root).as_posix());a.size=f.stat().st_size;a.mode=0o755 if f.parent.name=='images' else 0o644
        with f.open('rb') as source:t.addfile(a,source)
with tarfile.open(out/'payload.tar.xz') as t:
    assert {m.name:hashlib.file_digest(t.extractfile(m),'sha256').hexdigest() for m in t}==hashes
(out/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(out/'README.md').write_text('Native affine-axis projection heap and stack measurements. record/ contains the corrected opaque-pointer consumer, frozen workload protocol, exact control outputs, raw four-cycle heap observations and guarded-worker stack measurements, build logs, executable images and workload accounts. initial-record/ preserves the diagnostic builds with two probe warnings. See the primary admission review for the limits of these measurements.\n')
assert shutil.disk_usage(repo).free-3*sum(p.stat().st_size for p in out.iterdir())-20*1024**2>=20*1024**3
shutil.copytree(out,repo/record)
git('add','--sparse','--',record);git('diff','--cached','--check')
assert all(p.startswith(record+'/') for p in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive native axis projection heap and stack observations')
rev=git('rev-parse','HEAD').decode().strip()
for f in out.iterdir():assert git('show',rev+':'+record+'/'+f.name)==f.read_bytes()
spec=importlib.util.spec_from_file_location('manifest','/mnt/development/csgrs/scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(repo),rev);assert len(rows)==2
v=dict(commit=rev,row=rows[1],members=len(files))
(root/'archive.json').write_text(json.dumps(v,indent=2)+'\n');print(v)
