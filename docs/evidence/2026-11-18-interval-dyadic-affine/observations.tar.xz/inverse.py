from pathlib import Path
import subprocess as sp,os,shutil
s=Path(__file__).resolve().parent
co=s/'control';client=s/'inverse-client'
def git(*args):sp.run(['git','-C',co,*args],check=True)
# Cargo crate uses the exact same source path for both builds and the pinned registry.
shutil.copyfile(s/'client/Cargo.lock',client/'Cargo.lock')
sp.run(['cargo','+1.95.0','metadata','--offline','--format-version','1'],cwd=client,stdout=sp.DEVNULL,check=True)
for rev in ['current','candidate-old']:
 if rev=='current':git('apply','-R',str(s/'candidate.patch'))
 else:git('apply',str(s/'candidate.patch'))
 for target,name in [('x86_64-unknown-linux-gnu','inverse'),('wasm32-unknown-unknown','inverse.wasm')]:
    sp.run(['cargo','+1.95.0','build','--locked','--release','--target',target],cwd=client,check=True)
    out=s/rev/name
    shutil.copyfile(Path(os.environ['CARGO_TARGET_DIR'])/target/'release'/name.replace('inverse','dyadic-inverse-client'),out)
    out.chmod(0o755)
    if name=='inverse':sp.run([out],check=True)
    else:sp.run(['node','-e','const m=new WebAssembly.Module(require("fs").readFileSync(process.argv[1]));if(new WebAssembly.Instance(m,{}).exports.main(0,0)!==0)process.exit(1)',out],check=True)
