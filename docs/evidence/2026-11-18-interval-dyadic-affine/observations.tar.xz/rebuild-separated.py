from pathlib import Path
import subprocess as sp,shutil,os
s=Path(__file__).resolve().parent
co=s/'control';client=s/'client'
def run(*args,cwd=client,**kw):
    sp.run(args,cwd=cwd,check=True,**kw)
run('git','apply','-R',str(s/'materialized/candidate.patch'),cwd=co)
for version in ['candidate-old','candidate']:
    if version=='current':run('git','checkout','--quiet','--detach','4c0a21334',cwd=co)
    if version=='candidate-old':run('git','apply',str(s/'candidate.patch'),cwd=co)
    out=s/version;out.mkdir(exist_ok=True)
    for observers,target,artifact in [(False,'x86_64-unknown-linux-gnu','client'),(True,'x86_64-unknown-linux-gnu','memory'),(False,'wasm32-unknown-unknown','client.wasm')]:
        opts=(['affine'] if version=='candidate' else [])+(['observer'] if observers else [])
        run('cargo','+1.95.0','build','--locked','--release','--target',target,'--features',','.join(opts))
        name='dyadic-affine-client'+('.wasm' if artifact.endswith('.wasm') else '')
        shutil.copyfile(Path(os.environ['CARGO_TARGET_DIR'])/target/'release'/name,out/artifact)
        (out/artifact).chmod(0o755)
        if artifact=='client':run(str(out/artifact))
        if artifact=='client.wasm':run('node','-e','const m=new WebAssembly.Module(require("fs").readFileSync(process.argv[1]));for(let i=0;i<2;i++)if(new WebAssembly.Instance(m,{}).exports.main(0,0)!==0)process.exit(1)',str(out/artifact))
