from pathlib import Path
import subprocess as sp,shutil,os
s=Path(__file__).resolve().parent;co=s/'solver'
sp.run(['git','worktree','add','--quiet','--detach',str(co),'c9f1f9ac'],check=True)
for rev in ['fixed','current','candidate-old']:
 if rev=='current':sp.run(['git','-C',co,'checkout','--quiet','--detach','4c0a21334'],check=True)
 if rev=='candidate-old':sp.run(['git','-C',co,'apply',str(s/'candidate.patch')],check=True)
 sp.run(['cargo','+1.95.0','run','--locked','--release','-p','hypersolve','--example','enclosed_program','--features','interval-program'],cwd=co,check=True)
 shutil.copy2(Path(os.environ['CARGO_TARGET_DIR'])/'release/examples/enclosed_program',s/rev/'enclosed_program')
