set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-dyadic-affine
mkdir -p "$s/adjusted-factor"
for r in candidate-old candidate; do mv "$s/$r" "$s/adjusted-factor/$r"; done
cp "$s/candidate.patch" "$s/adjusted-factor/"
cp "$s"/logs/{cost,images.json,memory.json,confirmed-timing,confirmed-timing.json,accounts.json} "$s/adjusted-factor/"
cargo +1.95.0 fmt -p hyperinterval
git diff -- crates/hyperinterval/src >"$s/candidate.patch"
git diff --no-index -- /dev/null crates/hyperinterval/src/dyadic_affine.rs >>"$s/candidate.patch" || test $? -eq 1
sed 's@inline/candidate.patch@adjusted-factor/candidate.patch@' "$s/rebuild.py" >"$s/build-copy.py"
export CARGO_TARGET_DIR="$s/target"
python3 "$s/build-copy.py" >"$s/logs/build-copy" 2>&1
python3 "$s/inverse.py" >"$s/logs/inverse" 2>&1
python3 "$s/extra-inverse.py" >"$s/logs/inverse-fixed" 2>&1
python3 "$s/cost.py" >"$s/logs/cost"
python3 "$s/accounts.py" >"$s/logs/size-gates"
bash "$s/qualify-oracle.sh"
