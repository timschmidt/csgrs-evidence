from pathlib import Path
import subprocess as sp,shutil
s=Path(__file__).resolve().parent;co=s/'control'
p=Path('crates/hyperinterval/tests/dyadic_affine.rs');shutil.copyfile(p,co/p)
p=co/'crates/hyperinterval/src/dyadic_affine.rs';src=p.read_text()
edits={
 'negative-order':('factor.sign() == num_bigint::Sign::Minus','factor.sign() == num_bigint::Sign::Plus'),
 'excluded-grid':(' < shift {',' < 0 {'),
 'translation':('upper += translation;', 'upper -= translation;'),
 'work':('factor.bits()), 2, true)', 'factor.bits()), 1, true)')}
def check(name):
 with (s/'logs'/('mutation-'+name)).open('wb') as f:
  return sp.run(['cargo','+1.95.0','test','--locked','--no-default-features','-p','hyperinterval','--features','dyadic','--test','dyadic_affine'],cwd=co,stdout=f,stderr=sp.STDOUT).returncode
assert check('control')==0
try:
 for tag,(a,b) in edits.items():
    assert src.count(a)==1
    p.write_text(src.replace(a,b))
    assert check(tag)==101 and 'test result: FAILED.' in (s/'logs'/('mutation-'+tag)).read_text(),tag
finally:p.write_text(src)
assert check('restored')==0
