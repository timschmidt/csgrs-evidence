use hyperinterval::{DyadicInterval,DyadicBudget,DomainCoverage};
use std::hint::black_box;
fn main(){
 let r=DyadicInterval::new((-1).into(),1.into(),-2).unwrap();
 let mut b=DyadicBudget::new(8192,u64::MAX);
 for res in [r.asin(-27,&mut b),r.acos(-27,&mut b)]{assert_eq!(black_box(res.unwrap().domain),DomainCoverage::Complete);}
 let positive=DyadicInterval::new(1.into(),2.into(),0).unwrap();
 let p=positive.acosh(-32,&mut b).unwrap().range;
 assert!(black_box(p.contains_point(&0.into(),0,&mut b).unwrap()));
 assert_eq!(black_box(r.atanh(-27,&mut b).unwrap().domain),DomainCoverage::Complete);
}
