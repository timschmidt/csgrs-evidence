use hyperinterval::{DyadicBudget,DyadicInterval,IntervalError};
use num_bigint::BigInt;
use std::hint::black_box;
#[cfg(feature="observer")] mod allocation;
type Case=(DyadicInterval,BigInt,i32,BigInt,i32,DyadicInterval);
fn case(k:usize)->Case {
    let (a,b,e,m,f,n,g,lo,hi,h)=match k{
       0=>(-3,5,1,-3,-1,4,0,-11,13,0),
       1=>(2,7,-3,2,1,3,-3,11,31,-3),
       2=>(-9,-3,2,0,-10,-3,-2,-3,-3,-2),
       3=>(-3,5,4,-5,-3,0,-12,-50,30,0),
       4=>(-5,7,0,3,0,-15,0,-30,6,0),
       _=>(-3,5,0,-3,0,1,0,-14,10,0),
    };
    let mut x=DyadicInterval::new(a.into(),b.into(),e).unwrap();
    let mut expected=DyadicInterval::new(lo.into(),hi.into(),h).unwrap();
    let mut m=BigInt::from(m);
    let mut n=BigInt::from(n);
    if k==5 {
        // m=-(3*2^128+1), n=2^131. Mixed-sign products have asymmetric endpoints.
        m=(m<<128)-1;
        n<<=131;
        expected=DyadicInterval::new(&m*5+&n, &m*(-3)+&n,0).unwrap();
    }
    if k==6{x=DyadicInterval::empty();expected=DyadicInterval::empty();}
    (x,m,f,n,g,expected)
}
fn image(c:&Case,b:&mut DyadicBudget)->Result<DyadicInterval,IntervalError>{
    #[cfg(feature="affine")]
    {c.0.affine((&c.1,c.2),(&c.3,c.4),b)}
    #[cfg(not(feature="affine"))]
    {c.0.mul(&DyadicInterval::point(c.1.clone(),c.2)?,b)?.add(&DyadicInterval::point(c.3.clone(),c.4)?,b)}
}
fn run(c:&Case)->DyadicInterval{
    let mut b=DyadicBudget::new(2048,1_000_000_000);
    let result=black_box(image(black_box(c),&mut b)).unwrap();
    assert_eq!(result,c.5);
    result
}
#[cfg(feature="observer")]
mod observed{
    use super::*;
    use allocation::{AllocationStats,observe};
    use std::ffi::c_void;
    unsafe extern "C"{fn measure_stack(f:extern "C" fn(*mut c_void),c:*mut c_void,w:i32,p:u8)->usize;}
    struct Job{case:usize,stages:[Option<AllocationStats>;3]}
    extern "C" fn worker(ptr:*mut c_void){
        let j=unsafe{&mut *ptr.cast::<Job>()};
        let (_,end)=observe(||{
            let c=case(j.case);
            j.stages[0]=Some(AllocationStats::snapshot());
            let r=run(&c);
            j.stages[1]=Some(AllocationStats::snapshot());
            drop((r,c));
        });
        j.stages[2]=Some(end);
    }
    pub fn main(){
        let a:Vec<String>=std::env::args().collect();
        let mut j=Job{case:a[1].parse().unwrap(),stages:[None;3]};
        let stack=unsafe{measure_stack(worker,(&raw mut j).cast(),a[2].parse().unwrap(),a[3].parse().unwrap())};
        println!("STACK {stack}");for row in j.stages{let v=row.unwrap();println!("ROW {:?} {:?}",v.values(),v.usable());}
    }
}
fn main(){
    #[cfg(feature="observer")]
    observed::main();
    #[cfg(not(feature="observer"))]
    {
        let mut args=std::env::args().skip(1);
        let which=args.next().and_then(|v|v.parse::<usize>().ok());
        let count=args.next().map(|v|v.parse::<u32>().unwrap()).unwrap_or(1);
        for i in 0..7 {
            if which.is_some_and(|k|k!=i){continue}
            let c=case(i);
            for _ in 0..count{drop(black_box(run(&c)));}
        }
    }
}
