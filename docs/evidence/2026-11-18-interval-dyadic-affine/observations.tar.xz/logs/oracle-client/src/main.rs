use hyperinterval::{DyadicBudget, DyadicInterval};
fn main() {
    let mut state=0xf88f3f8a91b502e3_u64;
    let mut word=||{state^=state<<13;state^=state>>7;state^=state<<17;state as i16};
    for _ in 0..32768 {
        let (u,v,m,n)=(i128::from(word()),i128::from(word()),i128::from(word()),i128::from(word()));
        let (e,f,g)=(i32::from(word()%13),i32::from(word()%13),i32::from(word()%13));
        let l=u.min(v);let h=u.max(v);
        let x=DyadicInterval::new(l.into(),h.into(),e).unwrap();
        let grid=(e+f).min(g);
        let image=|i| ((i*m)<<(e+f-grid))+(n<<(g-grid));
        let (left,right):(i128,i128)=(image(l),image(h));
        let expected=DyadicInterval::new(left.min(right).into(),left.max(right).into(),grid).unwrap();
        let mut budget=DyadicBudget::new(256,2_000_000);
        assert_eq!(x.affine((&m.into(),f),(&n.into(),g),&mut budget).unwrap(),expected);
    }
}
