from pathlib import Path
import hashlib,subprocess,re,json
s=Path(__file__).resolve().parent
src=Path('/dev/shm/interval-bisection/size-account.py').read_text()
exec(src[src.index('def wasm('):src.index('path=Path(')])
rows={}
for rev in ['fixed','current','candidate-old']:
    p=s/rev/'enclosed_program'
    rows[rev]={'file':p.stat().st_size,**elf(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/'logs/solver-sections.json').write_text(json.dumps(rows,indent=2)+'\n')
for k,v in rows['candidate-old'].items():
 if not isinstance(v,int):continue
 c=rows['current'][k];f=rows['fixed'][k]
 if v!=c: print(k,'fixed',f,'current',c,'candidate',v,'incremental percent',(100*(v-c)/c if c else None))
