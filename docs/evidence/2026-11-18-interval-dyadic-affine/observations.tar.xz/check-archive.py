from pathlib import Path
import tarfile,json,hashlib,subprocess
repo=Path('../csgrs-evidence')
base=repo/'docs/evidence/2026-11-18-interval-dyadic-affine'
lookup=json.loads((base/'sha256.json').read_text())
with tarfile.open(base/'observations.tar.xz') as t:
 assert {obj.name:hashlib.sha256(t.extractfile(obj).read()).hexdigest() for obj in t}==lookup
print('Verified all',len(lookup),'members.')
