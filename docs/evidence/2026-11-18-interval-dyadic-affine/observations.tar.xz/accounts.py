from pathlib import Path
import subprocess,hashlib,re,json
s=Path(__file__).resolve().parent
src=Path('/dev/shm/interval-bisection/size-account.py').read_text()
exec(src[src.index('def wasm('):src.index("path=Path(")])
caps=json.loads(Path('docs/research/interval-size-accounts.json').read_text())['existing_artifacts']
rows=[]
for name,out,revision in [('composed scalar operations','client','candidate-old'),('native scalar map','client','candidate'),('existing inverse functions','inverse','candidate-old')]:
 for suffix in ['','.wasm']:
    fn=out+suffix
    paths=[s/r/fn for r in ['fixed','current',revision]]
    vals=[dict(file=p.stat().st_size,**({'code':wasm(p)} if suffix else elf(p))) for p in paths]
    growth={}
    for k,y in vals[-1].items():
        f,c=vals[0][k], vals[1][k]
        d=max(0,y-c);cum=d+max(0,c-f)
        if not cum: continue
        typ='wasm_final_file_and_code' if suffix else 'native_monomorphized_text_sum' if k=='defined_function_union' else 'native_final_file_and_allocated_sections'
        cap=caps[typ]
        passed=(d<=cap['incremental_bytes'] and 100*d<=cap['incremental_percent']*c and cum<=cap['cumulative_bytes'] and 100*cum<=cap['cumulative_percent']*f)
        if not passed:print('OVER',name,suffix,k,f,c,y,d,cum)
        growth[k]=dict(fixed=f,previous=c,retained=y,incremental=d,cumulative=cum,cap_schedule=typ,remaining_cumulative_bytes=cap['cumulative_bytes']-cum,remaining_cumulative_percentage_points=cap['cumulative_percent']-100*cum/f)
    rows.append(dict(workload=name,target='wasm32-unknown-unknown' if suffix else 'x86_64-unknown-linux-gnu',sizes=[v['file'] for v in vals],sha256=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths],positive_charges=growth))
(s/'logs/accounts.json').write_text(json.dumps(rows,indent=2)+'\n')
