from pathlib import Path
import struct,hashlib,json
s=Path(__file__).resolve().parent
def allocated(p):
 b=p.read_bytes();a=struct.unpack_from('<Q',b,40)[0];pitch,n,ss=struct.unpack_from('<HHH',b,58)
 es=[struct.unpack_from('<IIQQQQIIQQ',b,a+i*pitch) for i in range(n)]
 _,_,_,_,o,z,*_=es[ss];names=b[o:o+z]
 return {names[i:names.index(0,i)].decode():(addr,z,hashlib.sha256(b[o:o+z] if kind!=8 else bytes(z)).hexdigest()) for i,kind,fl,addr,o,z,*_ in es if fl&2}
out={}
for n in ['client','inverse','time-inverse','enclosed_program']:
 a,b=s/'current'/n,s/'candidate-old'/n
 if not(a.exists() and b.exists()):continue
 left,right=allocated(a),allocated(b)
 out[n]={'different':[k for k in sorted(set(left)|set(right)) if left.get(k)!=right.get(k)],'previous':left,'candidate':right}
 print(n,out[n]['different'])
(s/'logs/loaded.json').write_text(json.dumps(out,indent=2)+'\n')
