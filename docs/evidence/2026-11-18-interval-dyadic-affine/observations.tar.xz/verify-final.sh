set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-dyadic-affine
cargo +1.95.0 test --locked -p hyperinterval --all-targets --all-features >"$s/logs/owner-all" 2>&1
cargo +1.95.0 test --locked -p hyperinterval --all-features --doc >"$s/logs/doctests" 2>&1
cargo +1.95.0 clippy --locked -p hyperinterval --all-targets --all-features -- -D warnings >"$s/logs/clippy" 2>&1
RUSTDOCFLAGS="-D warnings" cargo +1.95.0 doc --locked --no-deps -p hyperinterval --all-features >"$s/logs/doc" 2>&1
cargo +1.95.0 test --locked -p hyperlattice-interval --all-features >"$s/logs/lattice" 2>&1
cargo +1.95.0 test --locked -p hyperinterval --release --all-features --test dyadic_affine >"$s/logs/release" 2>&1
cargo +1.95.0 fmt --all -- --check >"$s/logs/fmt" 2>&1
export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/msrv-target
cargo +1.88.0 check --locked -p hyperinterval --no-default-features --features dyadic >"$s/logs/msrv" 2>&1
for t in thumbv7em-none-eabihf wasm32-unknown-unknown; do
 cargo +1.88.0 build --locked --release --target "$t" -p hyperinterval --no-default-features --features dyadic >"$s/logs/msrv-$t" 2>&1
done
