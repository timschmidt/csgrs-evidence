from pathlib import Path
import time,os,subprocess as sp,json,statistics,itertools
s=Path(__file__).resolve().parent
dest=s/'timed-final'
def sec(cpu,r,case,count):
    exe=s/r/('time-inverse' if case=='inverse' else 'client')
    dest.unlink(missing_ok=True);os.link(exe,dest)
    args=[str(count)] if case=='inverse' else [str(case),str(count)]
    t=time.monotonic_ns()
    sp.run(['setarch','x86_64','-R','taskset','-c',str(cpu),str(dest),*args],cwd=s,check=True)
    return time.monotonic_ns()-t
rows=[]
for cpu in [2,6,10]:
 for case in [*range(7),'inverse']:
    initial=25 if case=='inverse' else 75000
    trial=sec(cpu,'current',case,initial)
    n=min(4_000_000,max(1,round(initial*90_000_000/trial)))
    versions=['current','candidate-old'] if case=='inverse' else ['current','candidate-old','candidate']
    orders=list(itertools.permutations(versions))
    if case=='inverse': orders*=3
    for block,p in enumerate(orders):
        for v in [*p,*reversed(p)]: rows.append(dict(cpu=cpu,k=case,b=block,src=v,n=n,ns=sec(cpu,v,case,n)))
    ratios={}
    for v in versions[1:]:
        rs=[]
        for b in range(len(orders)):
            group=[r for r in rows if (r['cpu'],r['k'],r['b'])==(cpu,case,b)]
            means={w:statistics.mean(r['ns'] for r in group if r['src']==w) for w in [v,'current']}
            rs.append(means[v]/means['current'])
        ratios[v]=[round(statistics.median(rs),4),sum(x>1 for x in rs)]
    print(cpu,case,n,ratios,flush=True)
    (s/'logs/confirmed-timing.json').write_text(json.dumps(rows,separators=(',',':'))+'\n')
