from pathlib import Path
import subprocess as sp,shutil,os
s=Path(__file__).resolve().parent; co=s/'control';app=s/'inverse-client'
p=app/'src/main.rs';original=p.read_text()
def git(*args):sp.run(['git','-C',co,*args],check=True)
def build(t,n,rev):
 sp.run(['cargo','+1.95.0','build','--locked','--release','--target',t],cwd=app,check=True)
 wasm=t.startswith('wasm32')
 src=Path(os.environ['CARGO_TARGET_DIR'])/t/'release'/('dyadic-inverse-client'+('.wasm' if wasm else ''))
 out=s/rev/n;shutil.copyfile(src,out);out.chmod(0o755)
 if not wasm:sp.run([out],check=True)
def timed():
 p.write_text(original.replace('fn main(){','#[inline(never)] fn cycle(){')+'\nfn main(){ for _ in 0..std::env::args().nth(1).and_then(|v|v.parse::<u32>().ok()).unwrap_or(1) {cycle()} }\n')
git('apply','-R',str(s/'candidate.patch'))
git('checkout','--quiet','--detach','c9f1f9ac')
try:
 build('x86_64-unknown-linux-gnu','inverse','fixed');build('wasm32-unknown-unknown','inverse.wasm','fixed')
 git('checkout','--quiet','--detach','4c0a21334')
 timed()
 build('x86_64-unknown-linux-gnu','time-inverse','current')
 git('apply',str(s/'candidate.patch'))
 build('x86_64-unknown-linux-gnu','time-inverse','candidate-old')
finally:p.write_text(original)
