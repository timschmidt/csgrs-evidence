set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-dyadic-affine
export CARGO_TARGET_DIR="$s/oracle-target"
cd "$s/oracle-client"
for tc in 1.88.0 1.95.0; do
 cargo +"$tc" run --locked --release >"$s/logs/oracle-$tc" 2>&1
 cargo +"$tc" build --locked --release --target wasm32-unknown-unknown >>"$s/logs/oracle-$tc" 2>&1
 node -e 'const m=new WebAssembly.Module(require("fs").readFileSync(process.argv[1]));for(let i=0;i<2;i++){if(new WebAssembly.Instance(m,{}).exports.main(0,0)!==0)process.exit(1);console.log("32768 exact images, instance",i+1)}' "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/dyadic-oracle-client.wasm" >>"$s/logs/oracle-$tc"
done
