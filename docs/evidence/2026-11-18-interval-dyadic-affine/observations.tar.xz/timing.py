from pathlib import Path
import os,subprocess as sp,time,statistics,json,itertools
s=Path(__file__).resolve().parent
cpu=2
dest=s/'timed'
if dest.exists():dest.unlink()
def secs(rev,k,n):
    if dest.exists():dest.unlink()
    os.link(s/rev/'client',dest)
    t=time.monotonic_ns()
    sp.run(['setarch','x86_64','-R','taskset','-c',str(cpu),str(dest),str(k),str(n)],cwd=s,check=True)
    return time.monotonic_ns()-t
rows=[]
for k in range(7):
    n=150000
    trial=secs('current',k,n)
    n=min(4000000,max(50000,round(n*65_000_000/trial)))
    vs=['current','candidate','candidate-old']
    for block,p in enumerate(itertools.permutations(vs)):
        for v in [*p,*reversed(p)]:
            ns=secs(v,k,n);rows.append(dict(case=k,block=block,source=v,count=n,ns=ns))
    means={v:statistics.median([r['ns']/n for r in rows if r['case']==k and r['source']==v]) for v in vs}
    print(k,n,means,{v:round(means[v]/means['current'],4) for v in vs},flush=True)
(s/'logs/timing.json').write_text(json.dumps(rows,separators=(',',':'))+'\n')
