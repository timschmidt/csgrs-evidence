from pathlib import Path
import subprocess,json,itertools,re,hashlib
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent
ns={}
src=Path('/dev/shm/interval-bisection/size-account.py').read_text()
exec(src[src.index('def wasm('):src.index("path=Path(")],globals())
images={}
for rev in ('fixed','current','candidate-old','candidate'):
    values={}
    for name in ('client','client.wasm'):
        p=s/rev/name
        values[name]=dict(file=p.stat().st_size,**({'code':wasm(p)} if name.endswith('wasm') else elf(p)))
    images[rev]=values
(s/'logs/images.json').write_text(json.dumps(images,indent=2)+'\n')
caps=json.loads(Path('docs/research/interval-size-accounts.json').read_text())['existing_artifacts']
for rev in ['candidate-old','candidate']:
 for name,ms in images[rev].items():
    for k,y in ms.items():
        cap=caps['wasm_final_file_and_code' if name.endswith('wasm') else 'native_monomorphized_text_sum' if k=='defined_function_union' else 'native_final_file_and_allocated_sections']
        c=images['current'][name][k]; f=images['fixed'][name][k]
        d=max(0,y-c);cum=d+max(0,c-f)
        if d and (d>cap['incremental_bytes'] or d*100>cap['incremental_percent']*c or cum>cap['cumulative_bytes'] or cum*100>cap['cumulative_percent']*f):
            print('SIZE LIMIT',rev,name,k,f,c,y,d,cum)
def one(args):
    rev,k,warm,pattern,rep=args
    raw=subprocess.check_output([str(s/rev/'memory'),str(k),str(warm),str(pattern)],text=True,stderr=subprocess.STDOUT)
    rows=[[int(i) for i in re.findall(r'-?\d+',r)] for r in raw.splitlines() if r.startswith('ROW')]
    head=[int(i) for i in re.search(r'^HEADROOM (.+)$',raw,re.M)[1].split()]
    assert len(rows)==3 and len(head)==5
    return dict(rev=rev,k=k,warm=warm,pattern=pattern,rep=rep,rows=rows,stack=head[3],headroom=head[4])
with ThreadPoolExecutor(max_workers=6) as p:
 mem=list(p.map(one,itertools.product(images,range(7),range(2),(90,165),range(2))))
(s/'logs/memory.json').write_text(json.dumps(mem,separators=(',',':'))+'\n')
for k,warm in itertools.product(range(7),range(2)):
 def peak(fn):
    return [max(fn(r) for r in mem if (r['rev'],r['k'],r['warm'])==(rev,k,warm)) for rev in images]
 print('case',k,'warm',warm,'stack',peak(lambda r:r['stack']),'heap',peak(lambda r:r['rows'][-1][4]),'held',peak(lambda r:r['rows'][1][5]),'alloc',peak(lambda r:r['rows'][-1][0]))
