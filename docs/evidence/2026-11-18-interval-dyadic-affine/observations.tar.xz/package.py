from pathlib import Path
import json,hashlib,shutil
s=Path(__file__).resolve().parent;b=s/'bundle'
b.mkdir(exist_ok=True);(b/'logs').mkdir(exist_ok=True)
for p in list(s.glob('*.py'))+list(s.glob('*.sh'))+list(s.glob('*.patch'))+list(s.glob('*.txt')):
 shutil.copy2(p,b/p.name)
shutil.copy2(Path('/dev/shm/interval-bisection/size-account.py'),b/'size-account-reference.py')
shutil.copy2(Path('/dev/shm/interval-bisection/env'),b/'environment.sh')
for name in ['client','oracle-client','inverse-client']:
 shutil.copytree(s/name,b/'logs'/name,dirs_exist_ok=True)
for p in (s/'logs').iterdir():
 if p.is_file():shutil.copy2(p,b/'logs'/p.name)
for name in ['inline','materialized','separate','wide','scaled','adjusted-factor','reference-copy','copy-ownership']:
 path=s/name;out=b/'logs'/name;out.mkdir(exist_ok=True)
 for p in path.iterdir():
    if p.is_file() and p.name!='enclosed_program':
        shutil.copy2(p,out/p.name)
files={}
for stage in ['fixed','current','candidate-old','candidate',*[str(p.relative_to(s)) for p in s.glob('*/*') if p.name in ['candidate','candidate-old']]]:
 if not (s/stage).is_dir():continue
 for p in (s/stage).iterdir():
    if p.is_file():files[str(p.relative_to(s))]=[p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()]
(b/'image-hashes.json').write_text(json.dumps(files,indent=2)+'\n')
