#![cfg(feature = "flow-noise-evolution")]
use std::sync::Arc;
use hyperdynamics::field::{
    EnclosureBudget, EnclosurePolicy, ExpressionField, FieldDefinition,
    evolution::EvolutionOptions,
    taylor_flow::noise::{FlowNoiseState, evolution::{FlowNoiseEvolutionOptions, FlowNoiseEvolutionStatus}},
};
use hyperinterval::DyadicInterval;
use hyperlattice_interval::BoxN;
use hypersolve::{Expr, SymbolId, expression_program::{ExpressionBudget, ExpressionProgram}};
const T: SymbolId = SymbolId(100);
fn s(i: u32) -> Expr { Expr::anonymous_symbol(SymbolId(i)) }
fn b() -> EnclosureBudget { EnclosureBudget::new(EnclosurePolicy { graph_entries: 100_000_000, graph_work: 1 << 40, scalar_work: 1 << 62, ..EnclosurePolicy::default() }) }
fn field<const N: usize>(outputs: &[Expr]) -> ExpressionField<N> {
    let state: Vec<_> = (0..N as u32).map(SymbolId).collect();
    let mut v = state.clone(); v.push(T);
    let p = ExpressionProgram::compile(outputs, &v, &mut ExpressionBudget::new(100_000, 10_000_000)).unwrap();
    ExpressionField::from_definition(FieldDefinition { source: p.definition().clone(), time: T, state }, &mut b()).unwrap()
}
fn w(x: &DyadicInterval) -> f64 {
    fn f(b: Option<(&impl std::fmt::Display, i32)>) -> f64 { let (m, e) = b.unwrap(); m.to_string().parse::<f64>().unwrap() * 2f64.powi(e) }
    f(x.upper()) - f(x.lower())
}
fn run<const N: usize>(name: &str, f: &ExpressionField<N>, center: [f64; N], radius: i32, end: (i64, i32), step: i32) {
    let p = f.flow_taylor(4, &mut b()).unwrap();
    for cap in [0usize, 1, 2, N, 4 * N, 64] {
        let init = BoxN::new(std::array::from_fn(|i| {
            let c = (center[i] * 1024.0).round() as i64;
            DyadicInterval::new((c * (1i64 << (radius.unsigned_abs() as i64 - 10).max(0)) - 1).into(), (c * (1i64 << (radius.unsigned_abs() as i64 - 10).max(0)) + 1).into(), radius).unwrap()
        })).unwrap();
        let state = Arc::new(FlowNoiseState::new(DyadicInterval::point(0.into(), 0).unwrap(), init, &mut b()).unwrap());
        let t0 = std::time::Instant::now();
        let r = p.integrate_noise(state, DyadicInterval::point(end.0.into(), end.1).unwrap(),
            FlowNoiseEvolutionOptions { maximum_noise: cap, native: EvolutionOptions { maximum_step: Some(DyadicInterval::point(1.into(), step).unwrap()), maximum_steps: 100_000, ..Default::default() }, ..Default::default() }, &mut b());
        let dt = t0.elapsed().as_secs_f64();
        let ok = matches!(r.status(), FlowNoiseEvolutionStatus::Completed);
        let st = r.prefix_end_state().map(|s| s.clone()).unwrap_or(r.initial().clone());
        let widths: Vec<String> = st.enclosure().lanes().unwrap().iter().map(|x| format!("{:.3e}", w(x))).collect();
        let cols = st.columns().map(|c| c.len()).unwrap_or(0);
        println!("{name} cap={cap} ok={ok} t={:?} segs={} cols={cols} time={dt:.2}s widths={widths:?}", r.reached_time().upper(), r.segments().len());
    }
}
#[test]
fn probe() {
    run::<2>("rotation", &field::<2>(&[-s(1), s(0)]), [1.0, 0.0], -16, (4, 0), -3);
    // saddle rotated 45°: x' = y, y' = x has eigenvectors (1,1)/(1,-1)
    run::<2>("saddle", &field::<2>(&[s(1), s(0)]), [1.0, 0.0], -16, (2, 0), -4);
    run::<2>("vdp", &field::<2>(&[s(1), (Expr::int(1) - s(0) * s(0)) * s(1) - s(0)]), [2.0, 0.0], -16, (2, 0), -4);
    run::<2>("lv", &field::<2>(&[s(0) - s(0) * s(1), s(0) * s(1) - s(1)]), [1.5, 1.0], -16, (2, 0), -4);
    run::<3>("lorenz", &field::<3>(&[Expr::int(10) * (s(1) - s(0)), s(0) * (Expr::int(28) - s(2)) - s(1), s(0) * s(1) - Expr::int(8) * s(2) / Expr::int(3)]), [1.0, 1.0, 1.0], -16, (1, -4), -7);
}
