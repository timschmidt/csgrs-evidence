from pathlib import Path
import hashlib,json,os,resource,subprocess,sys,time
s=Path(__file__).parent;rows=[]
for i,variant in enumerate(['buffered','stream','stream','buffered','stream','buffered','buffered','stream']):
 source=s/'buffered.py' if variant=='buffered' else Path('scripts/interval_inventory.py')
 output=s/'measured.tsv'
 if output.exists(): output.unlink()
 start=time.monotonic_ns()
 p=subprocess.Popen(['taskset','-c','3',sys.executable,source,'--workspace','/mnt/development','--output',output],stdout=subprocess.DEVNULL)
 _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status);assert p.returncode==0
 rows.append(dict(position=i,variant=variant,elapsed_ms=(time.monotonic_ns()-start)/1e6,maxrss_kib=usage.ru_maxrss,sha256=hashlib.sha256(output.read_bytes()).hexdigest()))
assert len({x['sha256'] for x in rows})==1
(s/'costs.json').write_text(json.dumps(rows,indent=2)+'\n')
