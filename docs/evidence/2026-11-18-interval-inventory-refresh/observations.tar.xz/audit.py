from pathlib import Path
import csv
p=Path('interval-inventory.tsv')
with p.open(newline='') as f:
 reader=csv.DictReader(f,delimiter='\t');fields=reader.fieldnames;rows=list(reader)
reviews=[]
def review(row,**data):
 assert row['review_status']=='lexical candidate; not yet audited'
 reviews.append({**row,**data,"review_status":'body and selected callers reviewed at 703f86de6; see INTERVAL_REFACTOR_PROGRESS.md, Phase 0 inventory refresh'})
family={78:'DyadicInterval',84:'DyadicInterval',93:'ExtendedInterval<DyadicInterval>',99:'ExtendedInterval<DyadicInterval>',108:'IntervalSet2<DyadicInterval>',127:'IntervalSet2<DyadicInterval>'}
for row in rows:
 name=row['symbol']
 if row['path']=='crates/hyperinterval/src/extended/dyadic_overlap.rs' and name in {'overlaps','disjoint'}:
  carrier=family[int(row['line'])]
  review(row,endpoint_representation=carrier+'; borrowed signed BigInt mantissas with i32 binary exponents',
   semantics=('nonempty' if name=='overlaps' else 'empty')+' intersection of closed real sets; endpoint contact retained; exact bool or typed comparison-budget error',
   allocation='borrows operands; BigInt order alignment can allocate, covered by caller-owned DyadicBudget',
   platform='no_std with alloc and dyadic feature; qualified on native and WASM',
   serialization='query returns Result<bool, IntervalError>; no stored or serialized geometry',
   consumers='dyadic_overlap conformance suite; dyadic query/composition clients in docs/research/interval-dyadic-overlap.md',
   disposition='retain budgeted set query in Hyperinterval; keep extended ray and split-union semantics',
   baseline_tests='cargo test --locked -p hyperinterval --features dyadic --test dyadic_overlap --test dyadic_set_relations',
   baseline_benchmarks='linked finite/ray/split query clients; docs/research/interval-dyadic-overlap.md')
 elif row['path']=='crates/hypersolve/src/interval.rs' and name in ('certify_affine_krawczyk_box','certify_univariate_quadratic_krawczyk_box','certify_multivariate_quadratic_krawczyk_box'):
  multi=name=='certify_multivariate_quadratic_krawczyk_box'
  info={
   'certify_affine_krawczyk_box':('coupled affine Newton displacement and per-variable closed containment','AffineKrawczykReport','krawczyk_affine_oracle','certify_affine_krawczyk_box','affine elimination and containment'),
   'certify_univariate_quadratic_krawczyk_box':('per-row image containment and strict derivative contraction','QuadraticKrawczykReport','interval_box_radius','certify_univariate_quadratic_krawczyk_rows','row containment and contraction'),
   'certify_multivariate_quadratic_krawczyk_box':('coupled quadratic Jacobian inversion, image containment and strict contraction','MultivariateQuadraticKrawczykReport','krawczyk_multivariate_certainty','certify_multivariate_quadratic_krawczyk_square',''),
  }[name]
  review(row,endpoint_representation='EvaluationContext Real centers and VariableBall Real radii; retained exact '+('affine' if name.startswith('certify_affine') else 'quadratic')+' rows',
   semantics=info[0]+'; '+('certified-only comparisons under both policies' if multi else 'STRICT required for proof; APPROXIMATE_512 can issue an incorrect certificate'),
   allocation='owned report and dynamically allocated solver workspace; see docs/research/interval-box-proof-scope.md',
   platform='std; host and wasm32 solver clients',
   serialization=info[1]+' in-memory status and payload; returned directly',
   consumers='hypersolve public facade, certification benchmark and '+info[2]+' integration target',
   disposition='retain Hypersolve proof authority; '+('preserve certified ordering through inversion and both bounds' if multi else 'unresolved terminal-policy gap in '+info[4]),
   baseline_tests='cargo test --locked -p hypersolve --all-features --test '+info[2]+('' if multi else '; terminal regressions at 0dcfb17ba reproduced on 703f86de6'),
   baseline_benchmarks='hypersolve/benches/certification.rs: '+info[3]+'; docs/research/interval-box-proof-scope.md')
assert len(reviews)==9
with p.open('a',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');w.writerows(reviews)
