import collections,csv,hashlib,io,json,re,subprocess,tomllib
from pathlib import Path
s=Path(__file__).parent
base='703f86de6'
read=lambda b:list(csv.DictReader(io.StringIO(b.decode()),delimiter='\t'))
old=read(subprocess.check_output(['git','show',base+':interval-inventory.tsv']))
path=Path('interval-inventory.tsv')
new=read(path.read_bytes())
lex='lexical candidate; not yet audited'
previous=[r for r in old if r['review_status']!=lex]; reviews=[r for r in new if r['review_status']!=lex]
assert reviews[:len(previous)]==previous and len(previous)==230
assert len(reviews)==239 and all(base in r['review_status'] for r in reviews[len(previous):])
roots={x:Path('/mnt/development')/x for x in ['csgrs','alumina-interface','alumina-firmware']}
workspaces={}
for x in roots:
 meta=json.loads((s/(x+'-metadata.json')).read_text())
 workspaces.update({Path(p['manifest_path']):p['name'] for p in meta['packages']})
fresh=[r for r in new if r['review_status']==lex]
scopes=collections.Counter();other_manifests={}
files={};keys=set()
for r in fresh:
 root=roots[r['repository']];p=root/r['path']
 if p not in files:files[p]=p.read_text().splitlines()
 assert re.search(r'\b'+re.escape(r['kind'])+r'\s+'+re.escape(r['symbol'])+r'\b',files[p][int(r['line'])-1]),(p,r['line'],r['symbol'])
 key=(p,r['line'],r['kind'],r['symbol']);assert key not in keys;keys.add(key)
 manifest=next(d/'Cargo.toml' for d in p.parents if (d/'Cargo.toml').is_file())
 if manifest not in workspaces and manifest not in other_manifests:
  result=subprocess.run(['cargo','+1.95.0','metadata','--no-deps','--locked','--offline','--format-version','1','--manifest-path',manifest],capture_output=True)
  if result.returncode==0:
   meta=json.loads(result.stdout)
   other_manifests[manifest]=next(pkg['name'] for pkg in meta['packages'] if Path(pkg['manifest_path'])==manifest)
  else:
   raise AssertionError((manifest,result.stderr.decode()[:1000]))
 owner=workspaces[manifest] if manifest in workspaces else other_manifests[manifest]
 assert owner==r['owner'],(manifest,owner,r['owner'])
 scopes[r['repository']]+=1
print('historical reviews retained intact:',len(previous),'new:',len(reviews)-len(previous))
print('unique live lexical declaration sites:',len(keys),'Rust files:',len(files),'by checkout:',dict(scopes))
print('additional independently resolved package manifests:',{str(p):v for p,v in other_manifests.items()})
print('reviewed file sha256:',hashlib.sha256(path.read_bytes()).hexdigest())
for x in roots:print(x,subprocess.check_output(['git','-C',roots[x],'rev-parse','HEAD']).decode().strip())
