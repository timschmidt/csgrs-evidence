"""Check the complete local admission record before applying any candidate source."""
import gzip,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2');W=Path(__file__).resolve().parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import sha,dump
read=lambda p:json.loads(Path(p).read_text())
assert read(N/'native-aggregation-continuation-v2.json')['complete']
post=read(N/'native-aggregation-postcheck-result-v1.json');assert post['all_integration_targets_accounted_for']
sources={m:N/('native-aggregation-'+m+'-v1') for m in ('baseline','candidate')}
pins={m:json.loads(gzip.decompress((N/('native-aggregation-'+m+'-source-v1.json.gz')).read_bytes())) for m in sources}
for mode,source in sources.items():
    assert all(sha(source/p)==h for p,h in pins[mode].items())
    assert all(not row['fresh'] for row in read(N/('native-aggregation-'+mode+'-artifacts-v1')/'fresh-local-build-v1.json'))
    for row in read(N/('native-aggregation-'+mode+'-artifacts-v1')/'executables-v1.json').values():assert sha(row['executed_copy'])==row['sha256']
prep=read(W/'candidate-preparation-v2.json')
changes={p:pins['candidate'][p] for p in pins['candidate'] if pins['candidate'][p]!=pins['baseline'][p]}
assert changes==prep['candidate_implementation_sha256'] and len(changes)==13
assert pins['baseline']['crates/hyperdrc/tests/native_aggregation.rs']==pins['candidate']['crates/hyperdrc/tests/native_aggregation.rs']
assert pins['baseline']['crates/hyperdrc/tests/kicad_native_aggregation.rs']==pins['candidate']['crates/hyperdrc/tests/kicad_native_aggregation.rs']
focused={m:read(N/('native-aggregation-'+m+'-focused-v1.json')) for m in sources}
assert focused['baseline']['kicad_track_failures']['observations']==focused['candidate']['kicad_track_failures']['observations']
assert (focused['baseline']['native_aggregation']['passed'],focused['baseline']['native_aggregation']['failed'])==(8,5)
assert (focused['candidate']['native_aggregation']['passed'],focused['candidate']['native_aggregation']['failed'])==(13,0)
assert (focused['candidate']['kicad_native_aggregation']['passed'],focused['candidate']['kicad_native_aggregation']['failed'])==(9,3)
gates={m:read(N/('native-aggregation-'+m+'-gates-v1.json')) for m in sources}
assert all(len(rows)==3 and all(r['exit_code']==0 and not r['external_stops'] for r in rows.values()) for rows in gates.values())
quality=read(N/'native-aggregation-candidate-quality-result-v1.json')
suite=read(N/'native-aggregation-candidate-suite-result-v2.json')
circuit=read(N/'native-aggregation-candidate-circuit-result-v1.json')
reports=read(N/'native-aggregation-report-result-v3.json')
assert reports['only_declared_version_migration']
assert all(r['baseline_repeat_equal'] and r['candidate_repeat_equal'] for r in reports['cases'].values())
commands={}
for folder in sorted((N/'logs').glob('aggregation-*')):
    row=read(folder/'result.json');assert row['output_closed'] and not row['stops']
    assert all(sha(folder/p)==h for p,h in row['output_sha256'].items())
    commands[folder.name]=row
failed={name:row['exit_code'] for name,row in commands.items() if row['exit_code']}
expected_failures={'aggregation-baseline-focused-native_aggregation-v1','aggregation-baseline-focused-kicad_native_aggregation-v1',
    'aggregation-candidate-focused-kicad_native_aggregation-v1','aggregation-candidate-suite-library-v1'}
expected_failures.update('aggregation-cwd-'+m+'-'+case+'-readonly-v1' for m in sources for case in ['command-failure','missing-binary'])
assert set(failed)==expected_failures and all(code==101 for code in failed.values()),failed
counts={}
for name,row in commands.items():
    if not (name.startswith('aggregation-candidate-suite-') and name.endswith('-v2') or name.startswith('aggregation-candidate-circuit-')):continue
    out=(N/'logs'/name/'stdout').read_text()
    rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
    if rows:
        assert all(r[0]=='ok' and r[2]=='0' and r[3]=='0' and r[5]=='0' for r in rows),rows
        counts[name]={'passed':sum(int(r[1]) for r in rows),'failed':0,'ignored':0,'summaries':rows}
    assert not re.search(r'(?:Compiling|Checking|Verifying|Packaging) hypervoxel\b',(N/'logs'/name/'stderr').read_text())
assert counts['aggregation-candidate-suite-library-v2']['passed']==1559
usage={}
for case,report in reports['cases'].items():
    for row in report['observations']:
        path=Path(row['process_usage_path']);assert sha(path)==row['process_usage_sha256']
        text=path.read_text()
        usage[str(path)]={'mode':row['mode'],'case':case,
            'max_rss_kib':int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',text)[1]),
            'user_cpu_seconds':float(re.search(r'User time \(seconds\): ([0-9.]+)',text)[1]),
            'system_cpu_seconds':float(re.search(r'System time \(seconds\): ([0-9.]+)',text)[1])}
review={'decision':'retain locally qualified native aggregation repair; public distribution remains open',
    'baseline_revision':prep['revision'],'owning_layer':'HyperDRC native PCB aggregation and retained report/source owners',
    'native_implementation_paths':prep['native_aggregation_implementation_files'],
    'candidate_sha256':changes|{'crates/hyperdrc/tests/native_aggregation.rs':pins['candidate']['crates/hyperdrc/tests/native_aggregation.rs']},
    'focused':focused,'original_project_gates':gates,'quality_commands':quality['commands'],'test_counts':counts,
    'readonly_cwd_failure':read(N/'native-aggregation-cwd-diagnosis-v1.json'),
    'first_full_library_run':{'passed':1557,'failed':2,'ignored':0,'qualified_as_complete_success':False},
    'corrected_full_library_run':{'passed':1559,'failed':0,'ignored':0},
    'readiness_migration':{'from':21,'to':22,'fixture_fields':960,'fixtures':prep['fixture_version_migrations']},
    'complete_reports':reports,'resource_receipts':usage,'commands':commands,
    'two_complete_archives_verified':True,'full_source_and_artifacts_verified':True,
    'source_and_test_assertions_unchanged_during_execution':True,'only_harness_cwd_corrected':True,
    'original_35_file_bundle_restored':False,'cache_index_admitted':False,'exact_kicad_ingress_admitted':False,
    'same_contract_speedup_claimed':False,'internal_memory_work_cancellation_bound_claimed':False,
    'new_binding_abi':False,'public_distribution_complete':False,'hypervoxel_deferred_by_user':True,
    'full_plan_complete':False,'currently_available_history_not_reaudited':True,
    'latest_missing_path_count_observation':921794,'latest_missing_path_observation':'E63',
    'no_push':True}
p=N/'native-aggregation-review-v1.json';assert not p.exists();dump(p,review)
print(json.dumps({'decision':review['decision'],'test_counts':{k:v['passed'] for k,v in counts.items()},
    'native_cases_repaired':5,'all_original_project_gates_passed':True,'only_declared_report_version_changes':True}),flush=True)
