"""Compare complete authored reports across immutable baseline/candidate binaries."""
import decimal,gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;F=N/'native-aggregation-fixtures-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
sources={m:N/('native-aggregation-'+m+'-v1') for m in ('baseline','candidate')}
pins={m:json.loads(gzip.decompress((N/('native-aggregation-'+m+'-source-v1.json.gz')).read_bytes())) for m in sources}
artifacts={m:json.loads((N/('native-aggregation-'+m+'-artifacts-v1')/'executables-v1.json').read_text())['hyperdrc-cli'] for m in sources}
fixtures=json.loads((F/'verification-v1.json').read_text())['fixtures']
def verify():
    for m,s in sources.items():
        assert all(sha(s/p)==h for p,h in pins[m].items())
        assert sha(artifacts[m]['executed_copy'])==artifacts[m]['sha256']
    assert all(sha(row['path'])==row['sha256'] for row in fixtures.values())
verify()
checks=['layer-sanity','board-outline-sanity','min-copper-neck','drill-spacing']
cases=[]
for label in ('cparti','hvp109a'):
    args=['--kicad-pcb',fixtures[label]['path']]
    for check in checks:args+=['--check',check]
    cases.append((label,args+['--min-width','0.0762','--format','json','--allow-findings'],checks))
cases.append(('gerber-outline',['--gerber-dir',str(F/'gerber-outline-smoke'),'--check','layer-sanity','--min-width','0.0762','--format','json','--allow-findings'],['layer-sanity']))
protocol=N/'native-aggregation-report-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'fixtures':fixtures,'binaries':artifacts,'cases':cases,'order':['baseline','candidate','candidate','baseline'],
    'common_cwd':str(F),'output_normalization':False,'independent_geometry_oracle':False,'performance_comparison':False})
def unique(pairs):
    result={}
    for k,v in pairs:
        assert k not in result;result[k]=v
    return result
def reject(value):raise ValueError(value)
reports={};commands={}
for label,args,expected in cases:
    raw=[];parsed=[];observations=[]
    for ordinal,mode in enumerate(['baseline','candidate','candidate','baseline']):
        verify();name='aggregation-reports-'+label+'-'+str(ordinal)+'-'+mode+'-v1'
        argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
            '--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(F),str(F),'--chdir',str(F),
            '--setenv','TMPDIR',str(N/'scratch'/name),str(artifacts[mode]['executed_copy']),*args]
        row=run(name,argv,F);commands[name]=row
        p=N/'logs'/name/'stdout';data=p.read_bytes()
        report=json.loads(data,parse_float=decimal.Decimal,parse_constant=reject,object_pairs_hook=unique)
        assert report['inputs'] and len(report['violations'])==report['violation_count']
        coverage=report['coverage']['checks'];assert [r['check'] for r in coverage]==expected
        assert all(r['status'] in ['passed','failed','not_applicable','uncertain','skipped'] for r in coverage)
        raw.append(data);parsed.append(report)
        observations.append({'mode':mode,'stdout_sha256':sha(p),'bytes':len(data),'violation_count':report['violation_count'],
            'coverage':coverage,'full_report_materialized':True})
        dump(N/'native-aggregation-report-progress-v1.json',{'commands':commands,'case':label,'observations':observations})
    reports[label]={'observations':observations,'all_bytes_equal':all(r==raw[0] for r in raw),
        'all_parsed_reports_equal':all(r==parsed[0] for r in parsed),
        'baseline_repeat_equal':raw[0]==raw[3],'candidate_repeat_equal':raw[1]==raw[2]}
    dump(N/('native-aggregation-report-'+label+'-comparison-v1.json'),reports[label])
verify()
dump(N/'native-aggregation-report-result-v1.json',{'complete_for_declared_scope':True,'commands':commands,'cases':reports,
    'all_report_bytes_equal':all(r['all_bytes_equal'] for r in reports.values()),'performance_comparison':False,
    'independent_geometry_oracle':False,'new_implementation_admitted':False,'public_distribution_complete':False})
print(json.dumps({'cases':{k:{f:r[f] for f in ['all_bytes_equal','all_parsed_reports_equal','baseline_repeat_equal','candidate_repeat_equal']} for k,r in reports.items()}}),flush=True)
