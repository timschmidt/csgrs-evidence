"""Run source-pinned native aggregation checks in a separate target per variant."""
import gzip, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import dump,run,sha,reasons,resources
mode,phase=sys.argv[1:];assert mode in ('baseline','candidate')
assert phase in ('focused','gates','suite','quality','circuit')
S=N/('native-aggregation-'+mode+'-v1');T=N/'targets'/('native-aggregation-'+mode+'-v1')
A=N/('native-aggregation-'+mode+'-artifacts-v1')
inv=N/('native-aggregation-'+mode+'-source-v1.json.gz')
pins=json.loads(gzip.decompress(inv.read_bytes()))
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
verify()
results={}
protocol=N/('native-aggregation-'+mode+'-'+phase+'-protocol-v1.json');assert not protocol.exists()
dump(protocol,{'source_inventory_sha256':sha(inv),'helper_sha256':sha(Path(__file__)),
    'runner_sha256':sha(N/'control/validation_runner_v3.py'),'compiler_sha256':compiler['tool_sha256'],
    'contract_sha256':sha(W/'contract-v1.md'),'mode':mode,'phase':phase,'source_root':str(S),
    'target':str(T),'target_initially_absent':not T.exists(),'private_cli_binding':str(A/'hyperdrc-cli'),
    'hypervoxel_deferred_by_user':True})
def execute(label,args,allow_failure=False,extra_env=None):
    verify();name='aggregation-'+mode+'-'+phase+'-'+label+'-v1'
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(S)]
    if label!='compile' and (A/'hyperdrc-cli').exists():
        argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    env={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),
        'TMPDIR':str(N/'scratch'/name),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
    if extra_env:env.update(extra_env)
    for k,v in env.items():argv+=['--setenv',k,v]
    try:row=run(name,argv+args,S,target=T)
    except RuntimeError:
        row=json.loads((N/'logs'/name/'result.json').read_text())
        results[label]=row;dump(N/('native-aggregation-'+mode+'-'+phase+'-progress-v1.json'),results)
        if row['stops'] or not allow_failure or row['exit_code']!=101:raise
    results[label]=row;dump(N/('native-aggregation-'+mode+'-'+phase+'-progress-v1.json'),results)
    verify()
    return (N/'logs'/name/'stdout').read_text(),(N/'logs'/name/'stderr').read_text(),row

tests=['kicad_track_failures','kicad_native_aggregation','native_aggregation']
focused={};gates={}
if phase=='focused':
    assert not T.exists() and not A.exists();A.mkdir()
    args=[cargo,'test','--release','--locked','-p','hyperdrc','--lib','--no-run','--message-format=json']
    for name in tests:args+=['--test',name]
    stdout,stderr,_=execute('compile',args)
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',stderr)
    artifacts={};local=[]
    for line in stdout.splitlines():
        try:row=json.loads(line)
        except json.JSONDecodeError:continue
        if row.get('reason')!='compiler-artifact':continue
        if row.get('manifest_path','').startswith(str(S)):
            local.append({'manifest_path':row['manifest_path'],'target':row['target']['name'],'fresh':row['fresh']})
        if not row.get('executable'):continue
        name=row['target']['name'];is_test=row.get('profile',{}).get('test')
        if name=='hyperdrc':name='hyperdrc-lib' if is_test else 'hyperdrc-cli'
        if name not in tests+['hyperdrc-lib','hyperdrc-cli']:continue
        path=Path(row['executable']);assert path.is_relative_to(T)
        target=A/name;assert not target.exists();shutil.copy2(path,target)
        artifacts[name]={'compiled_path':str(path),'executed_copy':str(target),'sha256':sha(target),'bytes':target.stat().st_size}
        assert sha(path)==artifacts[name]['sha256']
    assert set(artifacts)==set(tests+['hyperdrc-lib','hyperdrc-cli']),artifacts
    assert local and not any(r['fresh'] for r in local),local
    dump(A/'executables-v1.json',artifacts);dump(A/'fresh-local-build-v1.json',local)
    for name in tests:
        stdout,stderr,row=execute(name,[str(A/name),'--test-threads=1','--nocapture'],True)
        summaries=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout,re.M)
        assert len(summaries)==1 and summaries[0][3:]==('0','0','0'),summaries
        r=summaries[0];focused[name]={'passed':int(r[1]),'failed':int(r[2]),'ignored':int(r[3]),
            'observations':re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED)$',stdout,re.M),'exit_code':row['exit_code']}
    assert focused['kicad_track_failures']['passed']==39 and focused['kicad_track_failures']['failed']==0
    if mode=='baseline':assert focused['native_aggregation']['failed']>=4
    dump(N/('native-aggregation-'+mode+'-focused-v1.json'),focused)
elif phase=='gates':
    for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
        stdout,stderr,row=execute(label,[str(A/'hyperdrc-lib'),'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],True)
        assert 'skipping complex project fixture' not in stdout+stderr
        summaries=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout,re.M)
        assert len(summaries)==1 and sum(map(int,summaries[0][1:3]))==1 and summaries[0][3]=='0'
        gates[label]={'exit_code':row['exit_code'],'process_seconds':row['elapsed_seconds'],'summary':summaries[0],
            'assertion_seconds':re.findall(r'took ([0-9]+(?:\.[0-9]+)?)s(?: of worker time)?',stderr),'external_stops':row['stops']}
        dump(N/('native-aggregation-'+mode+'-gates-v1.json'),gates)
elif phase=='suite':
    execute('library',[str(A/'hyperdrc-lib'),'--test-threads=1','--nocapture'])
    # The archived review target deliberately retains three unrelated ingress failures.
    # Run every other integration target, without modifying its tests or assertions.
    integration=sorted(p.stem for p in (S/'crates/hyperdrc/tests').glob('*.rs') if p.stem!='kicad_native_aggregation')
    args=[cargo,'test','--locked','--release','-p','hyperdrc']
    for name in integration:args+=['--test',name]
    execute('integration',args+['--','--test-threads=1'])
    execute('doctests',[cargo,'test','--locked','--release','-p','hyperdrc','--doc'])
elif phase=='quality':
    execute('format',[cargo,'fmt','--all','--','--check'])
    execute('clippy',[cargo,'clippy','--locked','-p','hyperdrc','--all-targets','--all-features','--','-D','warnings'])
    execute('docs',[cargo,'doc','--locked','-p','hyperdrc','--all-features','--no-deps'],extra_env={'RUSTDOCFLAGS':'-D warnings'})
elif phase=='circuit':
    execute('default',[cargo,'test','--locked','-p','hypercircuit','--','--test-threads=1'])
    execute('all',[cargo,'test','--locked','--release','-p','hypercircuit','--all-features','--','--test-threads=1'])
    execute('clippy',[cargo,'clippy','--locked','-p','hypercircuit','--all-targets','--all-features','--','-D','warnings'])
verify()
for row in json.loads((A/'executables-v1.json').read_text()).values():assert sha(row['executed_copy'])==row['sha256']
summary={'complete_for_declared_scope':True,'mode':mode,'phase':phase,'focused':focused,'gates':gates,
    'commands':results,'source_unchanged':True,'new_implementation_admitted':False,'full_plan_complete':False}
dump(N/('native-aggregation-'+mode+'-'+phase+'-result-v1.json'),summary)
print(json.dumps({'mode':mode,'phase':phase,'focused':focused,'gates':gates}),flush=True)
