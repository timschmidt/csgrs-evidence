use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering};
use hyperdrc::geometry::{empty_profile, polygon_from_points, polygon_to_profile};
use hyperdrc::kicad::{BoardModel, CopperFeature, CopperKind};
use hyperdrc::{PcbRegion, PcbRegionExt, Scalar};

static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
struct Counted;
fn allocated(bytes: usize) {
    let live = LIVE.fetch_add(bytes, Ordering::Relaxed) + bytes;
    PEAK.fetch_max(live, Ordering::Relaxed);
}
unsafe impl GlobalAlloc for Counted {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() { allocated(layout.size()); }
        p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() { allocated(layout.size()); }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
        unsafe { System.dealloc(p, layout); }
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let p = unsafe { System.realloc(p, layout, size) };
        if !p.is_null() {
            LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
            allocated(size);
        }
        p
    }
}
#[global_allocator]
static ALLOCATOR: Counted = Counted;
fn feature(region: PcbRegion) -> CopperFeature {
    CopperFeature { layer: "F.Cu".into(), net: None, kind: CopperKind::Pad,
        region, location: [Scalar::zero(), Scalar::zero()] }
}
fn main() {
    let n: usize = std::env::args().nth(1).unwrap().parse().unwrap();
    assert!([16, 64, 256].contains(&n));
    let original = polygon_to_profile(polygon_from_points(vec![
        [0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]), None);
    let mut region = empty_profile(None);
    let base = LIVE.load(Ordering::Relaxed);
    PEAK.store(base, Ordering::Relaxed);
    let started = std::time::Instant::now();
    for _ in 0..n {
        let board = BoardModel { source: "retained-owner-growth".into(),
            copper: vec![feature(region), feature(original.clone())],
            drills: vec![], board_outline: None, panel_features: None };
        region = board.all_copper().unwrap();
    }
    let native_ns = started.elapsed().as_nanos();
    let native_live = LIVE.load(Ordering::Relaxed);
    let native_peak = PEAK.load(Ordering::Relaxed);
    assert_eq!(hyperlimit::compare_reals(&region.try_area().unwrap(), &Scalar::one(),
        hyperlimit::PredicatePolicy::STRICT).value(), Some(std::cmp::Ordering::Equal));
    assert_eq!(region.classify_xy("0.5".parse().unwrap(), "0.5".parse().unwrap()),
        Ok(hypercurve::RegionPointLocation::Inside));
    let report = region.try_to_multipolygon().unwrap();
    assert_eq!(report.0.len(), n);
    drop(report);
    let report_live = LIVE.load(Ordering::Relaxed);
    let report_peak = PEAK.load(Ordering::Relaxed);
    let completed_ns = started.elapsed().as_nanos();
    drop(region);
    let after_drop_live = LIVE.load(Ordering::Relaxed);
    assert_eq!(original.try_area().unwrap(), Scalar::one());
    println!("{{\"n\":{n},\"base_live_bytes\":{base},\"after_native_live_bytes\":{native_live},\"native_peak_bytes\":{native_peak},\"after_report_live_bytes\":{report_live},\"completed_peak_bytes\":{report_peak},\"after_drop_live_bytes\":{after_drop_live},\"native_ns\":{native_ns},\"completed_ns\":{completed_ns},\"exact_area\":\"1\",\"center_inside\":true,\"report_polygons\":{n}}}");
}
