"""Reproduce converter failures with one variable: runtime working-directory writability."""
import gzip,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2');W=Path(__file__).resolve().parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
roots={m:N/('native-aggregation-'+m+'-v1') for m in ('baseline','candidate')}
pins={m:json.loads(gzip.decompress((N/('native-aggregation-'+m+'-source-v1.json.gz')).read_bytes())) for m in roots}
records={}
for mode,source in roots.items():
    assert all(sha(source/p)==h for p,h in pins[mode].items())
    artifacts=json.loads((N/('native-aggregation-'+mode+'-artifacts-v1')/'executables-v1.json').read_text())
    binary=artifacts['hyperdrc-lib'];assert sha(binary['executed_copy'])==binary['sha256']
    for label,test in [('command-failure','convert_reports_command_failure_as_contextual_error'),('missing-binary','convert_reports_missing_converter_binary')]:
        for permission in ('readonly','writable'):
            name='aggregation-cwd-'+mode+'-'+label+'-'+permission+'-v1';scratch=N/'scratch'/name
            cwd=source if permission=='readonly' else scratch
            argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
                '--bind',str(N),str(N),'--ro-bind',str(source),str(source),'--chdir',str(cwd),'--setenv','TMPDIR',str(scratch),
                '/usr/bin/strace','-f','-e','trace=mkdir,mkdirat,execve','-o',str(scratch/'syscalls.txt'),
                binary['executed_copy'],'conversion::tests::'+test,'--exact','--nocapture','--test-threads=1']
            try:row=run(name,argv,source)
            except RuntimeError:
                row=json.loads((N/'logs'/name/'result.json').read_text())
                assert not row['stops'] and row['exit_code']==101 and permission=='readonly'
            out=(N/'logs'/name/'stdout').read_text();trace=(scratch/'syscalls.txt').read_text()
            if permission=='readonly':
                assert row['exit_code']==101 and '0 passed; 1 failed; 0 ignored;' in out
                assert re.search(r'mkdir\("out",.*EROFS',trace),trace
            else:
                assert row['exit_code']==0 and '1 passed; 0 failed; 0 ignored;' in out
                assert (scratch/'out').is_dir() and 'EROFS' not in trace
                executable='/bin/false' if label=='command-failure' else '/does-not-exist'
                assert 'execve("'+executable+'"' in trace
            records[name]={'command':row,'runtime_cwd':str(cwd),'trace_sha256':sha(scratch/'syscalls.txt'),
                'trace_file':str(scratch/'syscalls.txt'),'expected_outcome':True}
    assert all(sha(source/p)==h for p,h in pins[mode].items())
dump(N/'native-aggregation-cwd-diagnosis-v1.json',{'helper_sha256':sha(Path(__file__)),
    'strace_sha256':sha('/usr/bin/strace'),'records':records,'readonly_failures_reproduced':4,'writable_passes':4,
    'test_source_changes':False,'implementation_changes':False,'source_unchanged':True,
    'cause':'relative out creation fails with EROFS before converter execution in the read-only working directory'})
print(json.dumps({'readonly_failures_reproduced':4,'writable_passes':4,'source_unchanged':True}),flush=True)
