"""Measure retained Rust allocation payloads for identical completed finite workloads."""
import gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
W=Path(__file__).resolve().parent;A=N/'native-aggregation-retention-v1';assert A.is_dir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
source=W/'retention_probe_v1.rs';source_hash=sha(source)
previous=json.loads((A/'progress-v1.json').read_text())
commands=previous['commands'];rows=previous['rows'];library_inputs={}
assert commands['baseline-256']['stops']==['wall_seconds']
rows['baseline'].append({'n':256,'outcome':'external_resource_exhaustion','complete_geometry_result':False})
base_command=commands['baseline-compile']['argv']
for arg in base_command:
    if arg.startswith(('hyperdrc=','hyperlimit=','hypercurve=')):
        name,p=arg.split('=',1);library_inputs.setdefault('baseline',{})[name]={'path':p,'sha256_after_link':sha(p)}
for mode in ['candidate']:
    S=N/('native-aggregation-'+mode+'-v1');T=N/'targets'/('native-aggregation-'+mode+'-v1')
    pins=json.loads(gzip.decompress((N/('native-aggregation-'+mode+'-source-v1.json.gz')).read_bytes()))
    assert all(sha(S/p)==h for p,h in pins.items())
    lines=(N/'logs'/('aggregation-'+mode+'-focused-compile-v1')/'stdout').read_text().splitlines()
    libraries={};searches=set()
    for line in lines:
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
        if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hyperdrc','hyperlimit','hypercurve'] and not r['profile']['test']:
            for p in r['filenames']:
                if p.endswith('.rlib'):libraries[r['target']['name']]=p
    assert set(libraries)=={'hyperdrc','hyperlimit','hypercurve'}
    library_inputs[mode]={k:{'path':p,'sha256':sha(p)} for k,p in libraries.items()}
    binary=A/('retention-'+mode)
    args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
    for path in sorted(searches):args+=['-L',path]
    for name,path in sorted(libraries.items()):args+=['--extern',name+'='+path]
    commands[mode+'-compile']=run('aggregation-retention-'+mode+'-compile-v2',args,S,target=T)
    binary_hash=sha(binary)
    rows[mode]=[]
    for n in [16,64,256]:
        name='aggregation-retention-'+mode+'-'+str(n)+'-v2'
        try:r=run(name,[str(binary),str(n)],S,target=T,wall_seconds=60)
        except RuntimeError:
            r=json.loads((N/'logs'/name/'result.json').read_text())
            commands[mode+'-'+str(n)]=r;dump(A/'progress-v2.json',{'commands':commands,'rows':rows});rows[mode].append({'n':n,'outcome':'external_resource_exhaustion' if r['stops'] else 'failure','complete_geometry_result':False});continue
        commands[mode+'-'+str(n)]=r
        row=json.loads((N/'logs'/name/'stdout').read_text())
        assert row['n']==n and row['exact_area']=='1' and row['center_inside'] and row['report_polygons']==n
        rows[mode].append(row)
        dump(A/'progress-v2.json',{'commands':commands,'rows':rows})
    assert sha(binary)==binary_hash and sha(source)==source_hash
    assert all(sha(S/p)==h for p,h in pins.items())
record={'helper_sha256':sha(Path(__file__)),'probe_sha256':source_hash,'contract_sha256':sha(W/'retention-contract-v1.md'),
    'library_inputs':library_inputs,'commands':commands,'rows':rows,'all_workloads_completed_and_validated':False,'original_baseline_256_timeout_preserved':True,
    'measurement':'requested live and peak Rust allocation payload bytes; not RSS','same_contract_speedup_claimed':False}
dump(A/'result-v2.json',record)
print(json.dumps(rows),flush=True)
