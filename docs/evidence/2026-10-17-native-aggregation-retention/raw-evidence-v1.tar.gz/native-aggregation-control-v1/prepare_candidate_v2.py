"""Apply only the aggregation subset after reproducing the current baseline."""
import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
B=N/'native-aggregation-baseline-v1';S=N/'native-aggregation-candidate-v1'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(args,cwd=O,stdin=None):
    return subprocess.run(GIT+args,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
assert (W/'migration-contract-v1.md').exists()
proof=json.loads((N/'native-aggregation-baseline-focused-result-v1.json').read_text())
assert proof['complete_for_declared_scope'] and proof['focused']['native_aggregation']['failed']>=4
assert proof['focused']['kicad_track_failures']['passed']==39
assert proof['focused']['kicad_native_aggregation']['failed']==4
old=json.loads((W/'baseline-preparation-v2.json').read_text());head=old['revision']
assert git(['rev-parse','HEAD']).decode().strip()==head
pins=json.loads(gzip.decompress(Path(old['source_inventory']).read_bytes()))
assert all(sha(B/p)==h for p,h in pins.items())
assert not S.exists()
git(['worktree','add','--no-checkout','-b','codex/native-aggregation-candidate-20261017',str(S),head])
git(['sparse-checkout','set','--no-cone','--stdin'],S,(W/'sparse-selection-v1.txt').read_bytes())
git(['checkout','codex/native-aggregation-candidate-20261017'],S)
for p,h in pins.items():
    if p.startswith('crates/hyperdrc/tests/') and p.endswith(('kicad_native_aggregation.rs','native_aggregation.rs')):
        assert not (S/p).exists();shutil.copy2(B/p,S/p)
    elif sha(S/p)!=h:
        assert (B/p).read_bytes().replace(b'\r\n',b'\n')==(S/p).read_bytes()
        shutil.copy2(B/p,S/p)
assert all(sha(S/p)==h for p,h in pins.items())
paths=['crates/hyperdrc/src/'+p for p in ['geometry.rs','geometry/region.rs','kicad/model.rs','lib.rs','region/projection.rs']]
A=O/'docs/evidence/2026-10-17-kicad-native-strokes/candidate-changes-v4'
archived={p:sha(A/p) for p in paths}
for p in paths:shutil.copy2(A/p,S/p)
p=S/'crates/hyperdrc/src/lib.rs';s=p.read_text();needle='.map(|source| Self::clone(source))'
assert s.count(needle)==1
p.write_text(s.replace(needle,'.copied()\n                    .cloned()'))
subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',*[str(S/p) for p in paths]],check=True)
native_paths=list(paths)
p=S/'crates/hyperdrc/src/readiness.rs'
s=p.read_text();assert s.count('pub const CHECK_IMPLEMENTATION_VERSION: u32 = 21;')==1
p.write_text(s.replace('pub const CHECK_IMPLEMENTATION_VERSION: u32 = 21;', 'pub const CHECK_IMPLEMENTATION_VERSION: u32 = 22;'))
paths.append(str(p.relative_to(S)))
p=S/'crates/hyperdrc/README.md'
s=p.read_text();s += "\nNative copper aggregation retains checked source owners and their diagnostic\nhistory without requiring finite report coordinates. Readiness implementation\nversion 22 identifies this aggregation and uncertainty-reporting correction.\nFinite report projection remains a separate fallible operation; authored\nreport order is preserved. Existing version 21 readiness artifacts describe\nthe earlier implementation and must be recomputed to claim the new behavior.\n"
p.write_text(s);paths.append(str(p.relative_to(S)))
migrations={}
for p in sorted((S/'crates/hypercircuit/tests/fixtures/easyduino/fast-drc').glob('*.json')):
    raw=p.read_bytes();old=json.loads(raw);expected=json.loads(raw)
    checks=expected['coverage']['checks'];assert checks and all(r['check_version']==21 for r in checks)
    for row in checks:row['check_version']=22
    assert raw.count(b'"check_version": 21')==len(checks)
    new=raw.replace(b'"check_version": 21',b'"check_version": 22');assert json.loads(new)==expected
    migrations[str(p.relative_to(S))]={'before_sha256':sha(p),'changed_check_version_fields':len(checks)}
    p.write_bytes(new);migrations[str(p.relative_to(S))]['after_sha256']=sha(p)
    paths.append(str(p.relative_to(S)))
assert len(migrations)==6
for p in paths:pins[p]=sha(S/p)
assert all(sha(S/p)==h for p,h in pins.items())
assert set(git(['diff','--name-only'],S).decode().splitlines())==set(paths)
assert not git(['diff','--check'],S)
patch=git(['diff','--binary'],S);(W/'candidate-tracked-v2.patch').write_bytes(patch)
inv=N/'native-aggregation-candidate-source-v1.json.gz';assert not inv.exists()
inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'candidate-preparation-v2.json').write_text(json.dumps({'revision':head,'source_root':str(S),
    'source_inventory':str(inv),'source_inventory_sha256':sha(inv),'helper_sha256':sha(Path(__file__)),
    'archived_five_file_sha256':archived,'candidate_implementation_sha256':{p:pins[p] for p in paths},
    'baseline_focused_result_sha256':sha(N/'native-aggregation-baseline-focused-result-v1.json'),
    'patch_sha256':sha(W/'candidate-tracked-v2.patch'),'native_aggregation_implementation_files':native_paths,'readiness_version_before':21,'readiness_version_after':22,
    'fixture_version_migrations':migrations,'migration_contract_sha256':sha(W/'migration-contract-v1.md'),
    'clone_lint_correction':True,'track_ingress_unchanged':True,'cache_proposal_applied':False,
    'unadmitted':True},indent=2,sort_keys=True)+'\n')
print(json.dumps({'candidate_source_files':len(pins),'production_files':len(paths),'revision':head}))
