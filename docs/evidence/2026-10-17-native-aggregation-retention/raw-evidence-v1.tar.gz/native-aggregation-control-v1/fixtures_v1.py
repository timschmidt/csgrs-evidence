"""Verify full original ZIPs and retain independently extracted CLI fixtures."""
import hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
S=N/'native-aggregation-baseline-v1';F=N/'native-aggregation-fixtures-v1';assert not F.exists();F.mkdir()
def sha(p):
    with Path(p).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
old=json.loads((V/'native-fixture-preflight-v1/result.json').read_text())
unzip=Path(shutil.which('unzip')).resolve();assert sha(unzip)==old['unzip_sha256']
records={}
for label,archive_name,member in [('cparti','CPArti FPGA dev board.zip','CPArti FPGA dev board.kicad_pcb'),('hvp109a','HVP109A.zip','HVP109A.kicad_pcb')]:
    p=S/'crates/hyperdrc/docs'/archive_name;prior=old['records']['baseline/'+archive_name]
    assert sha(p)==prior['archive_sha256']
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
        members={}
        for info in z.infolist():
            if info.is_dir():continue
            with z.open(info) as s:members[info.filename]={'bytes':info.file_size,'sha256':hashlib.file_digest(s,'sha256').hexdigest()}
        assert members==prior['members']
        data=z.read(member)
        if label=='cparti':
            gerber='gerbers/CPArti FPGA dev board-Edge_Cuts.gbr'
            folder=F/'gerber-outline-smoke';folder.mkdir();(folder/Path(gerber).name).write_bytes(z.read(gerber))
    run=subprocess.run([str(unzip),'-p',str(p),member],capture_output=True,timeout=120)
    (F/(label+'-unzip.stderr')).write_bytes(run.stderr)
    assert run.returncode==0 and run.stdout==data
    target=F/member;target.write_bytes(data)
    records[label]={'archive':str(p),'archive_sha256':sha(p),'members':members,'path':str(target),
        'sha256':sha(target),'bytes':target.stat().st_size,'independent_extractors_agree':True}
records['gerber-outline']={'path':str(folder/Path(gerber).name),'sha256':sha(folder/Path(gerber).name)}
(F/'verification-v1.json').write_text(json.dumps({'helper_sha256':sha(Path(__file__)),'unzip_sha256':sha(unzip),'complete':True,'fixtures':records},indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete_archives_verified':2,'independent_extractions_agree':True}))
