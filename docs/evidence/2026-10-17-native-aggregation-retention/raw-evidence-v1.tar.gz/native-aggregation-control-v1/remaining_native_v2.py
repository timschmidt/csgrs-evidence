"""Compile remaining native targets with a writable target, then freeze their executables."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');W=Path(__file__).resolve().parent
S=N/'native-aggregation-candidate-v1';T=N/'targets/native-aggregation-candidate-v1'
A=N/'native-aggregation-candidate-integration-artifacts-v1';assert A.is_dir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,reasons,resources
pins=json.loads(gzip.decompress((N/'native-aggregation-candidate-source-v1.json.gz').read_bytes()))
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
lib=N/'logs/aggregation-candidate-suite-library-v2';completed=json.loads((lib/'result.json').read_text())
assert completed['exit_code']==0 and not completed['stops']
assert all(sha(lib/p)==h for p,h in completed['output_sha256'].items())
assert 'test result: ok. 1559 passed; 0 failed; 0 ignored;' in (lib/'stdout').read_text()
failed=N/'logs/aggregation-candidate-suite-integration-v2'
assert 'Device or resource busy (os error 16)' in (failed/'stderr').read_text()
tests=sorted(p.stem for p in (S/'crates/hyperdrc/tests').glob('*.rs') if p.stem!='kicad_native_aggregation')
commands=json.loads((N/'native-aggregation-remaining-progress-v1.json').read_text());counts={}
assert len(commands)==10
for label,row in commands.items():
    folder=N/'logs'/('aggregation-candidate-remaining-'+label+'-v1')
    assert row['exit_code']==0 and not row['stops']
    assert all(sha(folder/name)==h for name,h in row['output_sha256'].items())
    if label!='compile':
        rows=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', (folder/'stdout').read_text(),re.M)
        assert rows;counts[label]=sum(map(int,rows))
assert counts['doctests']==3
artifacts=json.loads((A/'executables-v1.json').read_text())
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
def execute(label,args,binary=False):
    verify();name='aggregation-candidate-remaining-'+label+'-v2';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(scratch if binary else S)]
    if binary:argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),
        'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    commands[label]=run(name,argv+args,S,target=T);verify()
    dump(N/'native-aggregation-remaining-progress-v2.json',commands)
    return (N/'logs'/name/'stdout').read_text(),(N/'logs'/name/'stderr').read_text()
dump(N/'native-aggregation-remaining-protocol-v2.json',{'helper_sha256':sha(Path(__file__)),
    'completed_library_command_sha256':sha(lib/'result.json'),'failed_compile_command_sha256':sha(failed/'result.json'),
    'source_inventory_sha256':sha(N/'native-aggregation-candidate-source-v1.json.gz'),'tests':tests,
    'compile_without_cli_bind':True,'runtime_cli_frozen':True,'runtime_cwd':'private writable scratch',
    'no_application_or_test_source_changes':True,'prior_helper_stop':'doctests emit two successful summary groups, not one','prior_commands_reused_without_rerun':True})
metadata,_=execute('metadata',[cargo,'metadata','--locked','--no-deps','--format-version','1'])
package=next(p for p in json.loads(metadata)['packages'] if p['name']=='hyperdrc')
assert {t['name'] for t in package['targets'] if t['kind']==['test']}==set(tests)|{'kicad_native_aggregation'}
assert {t['name'] for t in package['targets'] if t['kind']==['bin']}=={'hyperdrc'}
assert all(sha(row['executed_copy'])==row['sha256'] for row in artifacts.values());verify()
dump(N/'native-aggregation-remaining-result-v2.json',{'complete_for_declared_scope':True,'commands':commands,
    'test_counts':counts,'retained_library_passes':1559,'total_production_suite_passes':1559+sum(counts.values()),
    'all_integration_targets_accounted_for':True,'separate_archived_review_target_known_ingress_failures':3,
    'artifacts':artifacts,'source_unchanged':True,'full_plan_complete':False})
print(json.dumps({'test_counts':counts,'total_production_suite_passes':1559+sum(counts.values())}),flush=True)
