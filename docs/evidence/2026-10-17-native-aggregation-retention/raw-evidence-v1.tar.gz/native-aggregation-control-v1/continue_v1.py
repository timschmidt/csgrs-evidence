"""Continue qualification only after each required candidate gate succeeds."""
import json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2');W=Path(__file__).resolve().parent
progress=N/'native-aggregation-continuation-v1.json';assert not progress.exists()
state={'steps':[],'implementation_admitted':False}
def save():progress.write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
def stop(reason):
    state.update(complete=False,stopped_at=reason);save();raise SystemExit(reason)
save();deadline=time.monotonic()+1800
p=N/'native-aggregation-candidate-focused-result-v1.json'
while not p.exists():
    if time.monotonic()>deadline:stop('candidate focused result not available within wait contract')
    time.sleep(1)
focused=json.loads(p.read_text())['focused']
assert focused['kicad_track_failures']['passed']==39 and focused['kicad_track_failures']['failed']==0
assert focused['kicad_native_aggregation']['passed']==9 and focused['kicad_native_aggregation']['failed']==3
assert {name for name,outcome in focused['kicad_native_aggregation']['observations'] if outcome=='FAILED'}=={
    'subrange_stroke_composes_without_a_finite_report_ring','superrange_stroke_survives_empty_accumulation_and_native_handoff',
    'failed_report_prefix_is_not_cached_and_native_composition_recovers'}
if (focused['native_aggregation']['passed'],focused['native_aggregation']['failed'])!=(13,0):stop('native semantic acceptance tests failed')
for phase in ['gates','quality','suite','circuit']:
    argv=[sys.executable,'-B',str(W/'validate_v1.py'),'candidate',phase]
    print('Starting '+phase,flush=True);r=subprocess.run(argv,cwd=N)
    state['steps'].append({'phase':phase,'argv':argv,'exit_code':r.returncode});save()
    if r.returncode:stop(phase)
    result=json.loads((N/('native-aggregation-candidate-'+phase+'-result-v1.json')).read_text())
    if phase=='gates' and not all(r['exit_code']==0 for r in result['gates'].values()):stop('original project resource gates')
argv=[sys.executable,'-B',str(W/'reports_v3.py')]
print('Starting complete report comparison',flush=True);r=subprocess.run(argv,cwd=N)
state['steps'].append({'phase':'reports','argv':argv,'exit_code':r.returncode});save()
if r.returncode:stop('reports')
result=json.loads((N/'native-aggregation-report-result-v3.json').read_text())
if not result['only_declared_version_migration']:stop('unreviewed report changes beyond declared version migration')
if not all(r['baseline_repeat_equal'] and r['candidate_repeat_equal'] for r in result['cases'].values()):stop('report determinism')
state.update(complete=True,local_qualification_complete=True,public_distribution_complete=False,implementation_admitted=False);save()
print(json.dumps(state),flush=True)
