"""Verify the native Cargo target matrix and run the CLI test target explicitly."""
import gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');W=Path(__file__).resolve().parent
S=N/'native-aggregation-candidate-v1';T=N/'targets/native-aggregation-candidate-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
assert json.loads((N/'native-aggregation-continuation-v2.json').read_text())['complete']
pins=json.loads(gzip.decompress((N/'native-aggregation-candidate-source-v1.json.gz').read_bytes()))
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
def execute(label,args):
    assert all(sha(S/p)==h for p,h in pins.items())
    name='aggregation-candidate-postcheck-'+label+'-v1'
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(S)]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),
        'TMPDIR':str(N/'scratch'/name),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    result=run(name,argv+[cargo,*args],S,target=T)
    assert all(sha(S/p)==h for p,h in pins.items())
    return result,N/'logs'/name/'stdout'
commands={}
commands['metadata'],out=execute('metadata',['metadata','--locked','--no-deps','--format-version','1'])
package=next(p for p in json.loads(out.read_text())['packages'] if p['name']=='hyperdrc')
tests={t['name'] for t in package['targets'] if t['kind']==['test']}
expected={p.stem for p in (S/'crates/hyperdrc/tests').glob('*.rs')}
assert tests==expected
assert {t['name'] for t in package['targets'] if t['kind']==['bin']}=={'hyperdrc'}
commands['binary'],out=execute('binary',['test','--locked','--release','-p','hyperdrc','--bins','--','--test-threads=1'])
assert 'test result: ok. 0 passed; 0 failed; 0 ignored;' in out.read_text()
dump(N/'native-aggregation-postcheck-result-v1.json',{'helper_sha256':sha(Path(__file__)),
    'commands':commands,'all_integration_targets_accounted_for':True,'integration_targets':sorted(tests),
    'archived_review_target_qualified_separately_with_three_known_ingress_failures':'kicad_native_aggregation',
    'binary_test_target_passed':True,'source_unchanged':True})
print(json.dumps({'all_integration_targets_accounted_for':True,'binary_test_target_passed':True}),flush=True)
