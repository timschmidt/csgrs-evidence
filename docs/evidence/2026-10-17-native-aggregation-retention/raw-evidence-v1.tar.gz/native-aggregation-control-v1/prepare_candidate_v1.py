"""Apply only the aggregation subset after reproducing the current baseline."""
import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
B=N/'native-aggregation-baseline-v1';S=N/'native-aggregation-candidate-v1'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(args,cwd=O,stdin=None):
    return subprocess.run(GIT+args,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
proof=json.loads((N/'native-aggregation-baseline-focused-result-v1.json').read_text())
assert proof['complete_for_declared_scope'] and proof['focused']['native_aggregation']['failed']>=4
assert proof['focused']['kicad_track_failures']['passed']==39
assert proof['focused']['kicad_native_aggregation']['failed']==4
old=json.loads((W/'baseline-preparation-v2.json').read_text());head=old['revision']
assert git(['rev-parse','HEAD']).decode().strip()==head
pins=json.loads(gzip.decompress(Path(old['source_inventory']).read_bytes()))
assert all(sha(B/p)==h for p,h in pins.items())
assert not S.exists()
git(['worktree','add','--no-checkout','-b','codex/native-aggregation-candidate-20261017',str(S),head])
git(['sparse-checkout','set','--no-cone','--stdin'],S,(W/'sparse-selection-v1.txt').read_bytes())
git(['checkout','codex/native-aggregation-candidate-20261017'],S)
for p,h in pins.items():
    if p.startswith('crates/hyperdrc/tests/') and p.endswith(('kicad_native_aggregation.rs','native_aggregation.rs')):
        assert not (S/p).exists();shutil.copy2(B/p,S/p)
    elif sha(S/p)!=h:
        assert (B/p).read_bytes().replace(b'\r\n',b'\n')==(S/p).read_bytes()
        shutil.copy2(B/p,S/p)
assert all(sha(S/p)==h for p,h in pins.items())
paths=['crates/hyperdrc/src/'+p for p in ['geometry.rs','geometry/region.rs','kicad/model.rs','lib.rs','region/projection.rs']]
A=O/'docs/evidence/2026-10-17-kicad-native-strokes/candidate-changes-v4'
archived={p:sha(A/p) for p in paths}
for p in paths:shutil.copy2(A/p,S/p)
p=S/'crates/hyperdrc/src/lib.rs';s=p.read_text();needle='.map(|source| Self::clone(source))'
assert s.count(needle)==1
p.write_text(s.replace(needle,'.copied()\n                    .cloned()'))
subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',*[str(S/p) for p in paths]],check=True)
for p in paths:pins[p]=sha(S/p)
assert all(sha(S/p)==h for p,h in pins.items())
assert set(git(['diff','--name-only'],S).decode().splitlines())==set(paths)
assert not git(['diff','--check'],S)
patch=git(['diff','--binary'],S);(W/'candidate-tracked-v1.patch').write_bytes(patch)
inv=N/'native-aggregation-candidate-source-v1.json.gz';assert not inv.exists()
inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'candidate-preparation-v1.json').write_text(json.dumps({'revision':head,'source_root':str(S),
    'source_inventory':str(inv),'source_inventory_sha256':sha(inv),'helper_sha256':sha(Path(__file__)),
    'archived_five_file_sha256':archived,'candidate_implementation_sha256':{p:pins[p] for p in paths},
    'baseline_focused_result_sha256':sha(N/'native-aggregation-baseline-focused-result-v1.json'),
    'patch_sha256':sha(W/'candidate-tracked-v1.patch'),'only_five_production_files_changed':True,
    'clone_lint_correction':True,'track_ingress_unchanged':True,'cache_proposal_applied':False,
    'unadmitted':True},indent=2,sort_keys=True)+'\n')
print(json.dumps({'candidate_source_files':len(pins),'production_files':len(paths),'revision':head}))
