from pathlib import Path
from statistics import median
import subprocess,json,platform,sys
s=Path(__file__).parent
rev=sys.argv[1]; outdir=s/('timing-'+rev);outdir.mkdir(exist_ok=True)
for cpu in (3,5):
 rows={}
 for i in range(12):
  for v in (['before',rev] if i%2==0 else [rev,'before']):
   raw=subprocess.check_output(['setarch',platform.machine(),'-R','taskset','-c',str(cpu),s/'images'/(v+'-native')],text=True)
   (outdir/f'{cpu}-{i}-{v}').write_text(raw)
   for l in raw.splitlines():
    r=l.split('|')
    if r[0] not in ('WARM','LANES'):continue
    k=r[0]+'|'+r[1];rows.setdefault(k,{}).setdefault(v,[]).append(int(r[4])/int(r[3]))
 out={}
 for k,row in rows.items():
  a,b=row['before'],row[rev];ds=[100*(y/x-1) for x,y in zip(a,b)]
  out[k]=[median(a),median(b),median(ds),sum(y>x for x,y in zip(a,b))]
 (outdir/f'summary-{cpu}.json').write_text(json.dumps(out,indent=2)+'\n')
 print(cpu,[(k,round(x[2],1),x[3]) for k,x in out.items() if x[3]>=10])
