set -eu
s=/dev/shm/interval-finite-inclusion
t=/dev/shm/interval-overlap
d=/dev/shm/interval-directed-overlap
. /dev/shm/interval-bisection/env
one(){
 local v=$1 profile=$2 client query
 if test "$profile" = locked;then client="$d/workspace-client";query="$d/locked-query";else client="$t/probe";query="$t/lifetime";fi
 local out="$s/legacy/$profile";mkdir -p "$out"
 (cd "$client"; export CARGO_TARGET_DIR="$d/$profile-client-target"
 cargo +1.95.0 build --offline --locked --release --features direct
 cp "$CARGO_TARGET_DIR/release/overlap-observer" "$out/$v-native"
 cargo +1.95.0 build --locked --offline --release --target wasm32-unknown-unknown --lib --features direct
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/overlap_observer.wasm" "$out/$v.wasm")
 (cd "$d/$profile-lifetime";export CARGO_TARGET_DIR="$d/$profile-life-target"
 cargo +1.95.0 build --locked --release --features direct --bins --example heap
 for _ in $(seq 12);do "$CARGO_TARGET_DIR/release/overlap-lifetime"; done > "$out/$v-life" 2> "$out/$v-headroom"
 for _ in 1 2 3;do "$CARGO_TARGET_DIR/release/examples/heap";done > "$out/$v-heap")
 (cd "$query";export CARGO_TARGET_DIR="$d/$profile-query-target";cargo +1.95.0 build --locked --release --features direct
 for _ in $(seq 12);do "$CARGO_TARGET_DIR/release/overlap-lifetime";done > "$out/$v-query" 2> "$out/$v-query-headroom")
}
for v in before zero;do
 if test "$v" = zero;then git -C "$t/repo" apply "$s/zero.patch";fi
 one "$v" standalone > "$s/logs/legacy-$v-standalone" 2>&1 & a=$!
 one "$v" locked > "$s/logs/legacy-$v-locked" 2>&1 & b=$!
 wait "$a";wait "$b"
done
