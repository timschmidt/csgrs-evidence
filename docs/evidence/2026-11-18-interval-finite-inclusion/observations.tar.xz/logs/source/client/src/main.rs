use finite_order_client::{fixture,run,lanes};
use std::{hint::black_box,time::Instant};
fn main(){
 for i in 0..15 {let x=fixture(i);let observed=run(&x,i);println!("RESULT|{i}|{}|{}|{}",observed.0,lanes(&x),observed.1);
  for kind in ["WARM","LANES"] {let timer=Instant::now();for _ in 0..2000 {if kind=="LANES"{black_box(lanes(black_box(&x)));}else{black_box(run(black_box(&x),i));}}println!("{kind}|{i}|{}|2000|{}",observed.0,timer.elapsed().as_nanos());}
 }
}
