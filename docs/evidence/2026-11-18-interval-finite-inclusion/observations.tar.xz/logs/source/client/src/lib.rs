use hyperinterval::{DyadicInterval as D,DyadicBudget,IntervalError};
use hyperlattice_interval::IntervalVector;
use num_bigint::BigInt;
use std::hint::black_box;

pub struct Case {a:D,b:D}
pub fn fixture(i:u32)->Case {
 let d=|a:i64,b:i64,e|D::new(a.into(),b.into(),e).unwrap();
 let (a,b)=match i {
  0=>(d(-1,3,0),d(-5,7,0)),1=>(d(1,3,0),d(3,7,0)),2=>(d(-1,3,0),d(5,7,0)),
  3=>(d(-5,7,-5),d(-3,5,-3)),4=>(d(-31,-17,-3),d(-4,-1,0)),5=>(d(3,3,-2),d(-1,2,0)),
  6=>(D::empty(),d(1,1,0)),7=>(d(-1,1,0),D::empty()),8=>(d(0,0,0),d(-1,1,-64)),
  9=>(d(1,3,-64),d(1,3,64)),10=>(d(-1,1,i32::MIN),d(-1,1,i32::MAX)),
  11=>(d(1,1,i32::MIN),d(1,1,i32::MAX)),12=>(d(-1,-1,i32::MAX),d(-1,-1,i32::MIN)),
  13=>(d(1,1,i32::MAX),d(-1,1,i32::MIN)),
  _=>{let n=(BigInt::from(1u8)<<512usize)+3;let a=D::new(&n-2u8,&n+2u8,-512).unwrap();(a,d(-1,2,0))}
 };Case{a,b}
}
fn code(x:Result<bool,IntervalError>)->u8 {match x{Ok(false)=>0,Ok(true)=>1,Err(IntervalError::SizeExhausted)=>2,Err(IntervalError::WorkExhausted)=>3,Err(_)=>panic!("unexpected error")}}
pub fn run(x:&Case, i:u32)->(u32,u64){
 let mut b=DyadicBudget::new(if (10..=13).contains(&i){2}else{2048},4_000_000);
 let z=[code(x.a.subset_of(&x.b,&mut b)),code(x.a.interior_subset_of(&x.b,&mut b)),code(x.a.strictly_left_of(&x.b,&mut b))];
 (u32::from(z[0])+4*u32::from(z[1])+16*u32::from(z[2]),b.remaining_work())
}
pub fn lanes(x:&Case)->u32 {
 let mut q=DyadicBudget::new(2048,4_000_000);
 let a=IntervalVector::new([x.a.clone(),x.a.clone()]).unwrap();let b=IntervalVector::new([x.b.clone(),x.b.clone()]).unwrap();
 let c=|r:Result<bool,_>| match r{Ok(false)=>0,Ok(true)=>1,Err(_)=>2};
 c(a.subset_of(&b,&mut q))+4*c(a.interior_subset_of(&b,&mut q))
}
#[unsafe(no_mangle)]
pub extern "C" fn observe(i:u32)->u32 {let x=fixture(i);black_box(run(&x,i).0+64*lanes(&x))}
