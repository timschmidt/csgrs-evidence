from pathlib import Path
import subprocess,statistics,platform,json
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent
def go(cpu):
 for name in ('locked','standalone'):
  p=s/'legacy'/name
  rows={}
  for i in range(18):
   for v in (['recovery','before'] if i%2 else ['before','recovery']):
    text=subprocess.check_output(['setarch',platform.machine(),'-R','taskset','-c',str(cpu),p/(v+'-native')],text=True)
    (p/f'isolated-recovery-pair-{cpu}-{i}-{v}').write_text(text)
    for line in text.splitlines():
     items=line.split()
     if items[0]=='TIME': rows.setdefault(items[1],{}).setdefault(v,[]).append(int(items[-1]))
  result={k:[statistics.median(100*(y/x-1) for x,y in zip(r['before'],r['recovery'])),sum(y>x for x,y in zip(r['before'],r['recovery']))] for k,r in rows.items()}
  (p/f'isolated-recovery-timing-{cpu}.json').write_text(json.dumps(result))
for cpu in [3,5]:go(cpu)
