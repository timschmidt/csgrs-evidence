
mod allocations;
use std::{hint::black_box,sync::Arc};
use hyperinterval::{DyadicBudget,DyadicInterval};
use hyperreal::Real;
use hypersdf::{Sdf,SdfExpr,SdfProgram,SdfCellLocation,SdfSubdivisionOptions};
use hypersolve::expression_program::ExpressionBudget;
fn graph()->ExpressionBudget {ExpressionBudget::new(1_000_000,100_000_000)}
fn arithmetic()->DyadicBudget {DyadicBudget::new(16384,1_000_000_000_000)}
fn d(a:i64,b:i64,e:i32)->DyadicInterval {DyadicInterval::new(a.into(),b.into(),e).unwrap()}
fn sdf(index: usize){
 let mut matrix=hyperlattice::Matrix4::identity();matrix.0[0][0]=2.into();matrix.0[0][3]=1.into();
 let polynomial=SdfExpr::x().mul_expr(SdfExpr::constant(Real::one()).sub_expr(SdfExpr::x())).offset((Real::from(3)/Real::from(8)).unwrap());
 let sphere=SdfExpr::sphere(hyperlattice::Point3::new(0.into(),0.into(),0.into()),1.into()).affine_transform(matrix).unwrap();
 let (name,expr,cell,depth,records,leaves,unresolved,location) = [
  ("dependency",polynomial,[d(0,1,0),d(0,0,0),d(0,0,0)],3,11,6,0,SdfCellLocation::ConservativeInside),
  ("affine-sphere",sphere,[d(-3,5,0),d(0,0,0),d(0,0,0)],4,23,12,4,SdfCellLocation::Unknown)
 ].into_iter().nth(index).unwrap();
  let source=Arc::new(Sdf::new(expr));let p=SdfProgram::compile(source,&mut graph()).unwrap();
  let options=SdfSubdivisionOptions{precision:-48,max_depth:depth,max_cells:records};
  let mut b=graph();let initial=b.remaining_work();let mut scalar=arithmetic();let cover=p.subdivide(cell.clone(),options,&mut b,&mut scalar).unwrap();println!("REPORT {cover:?}");println!("RECEIPT {:?} {:?}",b.remaining_work(),scalar.remaining_work());let used=initial-b.remaining_work();
  assert_eq!(cover.cells().len(),records);assert_eq!(cover.leaves().count(),leaves);assert_eq!(cover.leaves().filter(|(_,c)|c.unresolved().is_some()).count(),unresolved);assert_eq!(cover.location(),Some(location));
  assert!(used > 0);
  black_box((name,cover));
}
mod reach;
fn main(){sdf(0);sdf(1);reach::reach().unwrap();}
