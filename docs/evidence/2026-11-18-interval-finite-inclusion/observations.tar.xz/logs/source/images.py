from pathlib import Path
from image_metrics import sizes
from wasm_metrics import wasm
import sys,json
s=Path(__file__).parent
v=sys.argv[1]
out={}
for target in ['-native','-broad','.wasm']:
 data=[]
 for ver in ['fixed','before',v]:
  p=s/'images'/(ver+target)
  if not p.exists():break
  data.append(sizes(p) if target!='.wasm' else {'file':p.stat().st_size,'code':wasm(p)})
 if len(data)<3:continue
 out[target]={}
 for k in data[0].keys()|data[1].keys()|data[2].keys():
  a,b,c=[x.get(k,0) for x in data];delta=max(0,c-b);total=max(0,b-a)+delta
  i,pi,j,pj=(512,2,2048,4) if target=='.wasm' else (1024,1,4096,2)
  ok=delta<=i and 100*delta<=pi*b and total<=j and 100*total<=pj*a
  out[target][k]=[a,b,c,delta,total,ok]
  if not ok or k in ['file','code','function_union']:print(target,k,a,b,c,c-b,ok)
(s/(v+'-images.json')).write_text(json.dumps(out,indent=2)+'\n')
