set -eu
s=/dev/shm/interval-finite-inclusion
for v in fixed before borrowed; do
 case "$v" in fixed) git -C "$s/csgrs" switch --detach c9f1f9ac5;;before) git -C "$s/csgrs" switch --detach 68fd84f3a;;borrowed) git -C "$s/csgrs" apply "$s/borrowed.patch";;esac
 for k in native wasm broad replay;do bash "$s/build.sh" "$v" "$k" > "$s/logs/$v-$k-build" 2>&1 & done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
