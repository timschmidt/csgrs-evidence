from pathlib import Path
import json,ast,re
s=Path(__file__).parent
for path in [s,s/'zero-probe']:
 data={}
 for version in ['fixed','before','zero','unified','retained']:
  for family in ['life','broad']:
   rows={}
   for f in (path/'logs').glob(version+'-'+family+'-[0-9]*'):
    for l in f.read_text().splitlines():
     a=l.split('|')
     if a[0]=='STACK':entries={'stack-'+a[2]:int(a[4])}
     elif a[0]=='HEAP':
      vals=ast.literal_eval(a[2]);entries=dict(zip(('allocations','deallocations','reallocations','requested-total','requested-peak','retained'),vals))
     else: continue
     for k,n in entries.items():
      key=(family,a[1],k);rows[key]=max(rows.get(key,0),n)
   for (fam,i,k),n in rows.items():data.setdefault((fam,i,k),{})[version]=n
 for candidate in ['zero','unified','retained']:
  output=[]
  for (fam,i,k),d in sorted(data.items()):
   if candidate not in d:continue
   a,b,c=(d[x] for x in ['fixed','before',candidate]); inc=max(0,c-b);cum=max(0,b-a)+inc
   r=dict(family=fam,case=int(i),metric=k,fixed=a,before=b,observed=c,incremental=inc,cumulative=cum)
   if k.startswith('stack') or k=='requested-peak':
    n,p,m,q=(512,2,1024,3) if k=='requested-peak' else (256,2,512,3)
    r['within_caps']=inc<=n and 100*inc<=b*p and cum<=m and 100*cum<=a*q and c<=2**20
   elif k=='retained':r['within_caps']=c==0
   output.append(r)
  if not output:continue
  (path/(candidate+'-memory.json')).write_text(json.dumps(output,indent=2)+'\n')
  print(path.name,candidate,'failures',[(r['family'],r['case'],r['metric'],r['incremental']) for r in output if r.get('within_caps')==False], 'positive',[(r['family'],r['case'],r['metric'],r['incremental']) for r in output if r.get('within_caps') and r['incremental']])
