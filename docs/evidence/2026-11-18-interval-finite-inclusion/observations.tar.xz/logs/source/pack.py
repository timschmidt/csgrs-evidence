from pathlib import Path
import shutil,hashlib,json,subprocess
s=Path(__file__).parent;b=s/'bundle';b.mkdir(exist_ok=True)
def cp(src,dst):
 dst=b/dst;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
for root,prefix in [(s,Path()),(s/'zero-probe',Path('zero-probe'))]:
 for ext in ['*.py','*.sh','*.json','*.txt','*.patch','*.cjs']:
  for f in root.glob(ext):cp(f,Path('logs')/'source'/prefix/f.name)
 for p in root.glob('logs/*'):
  if p.is_file():cp(p,Path('logs')/prefix/p.name)
 for d in root.glob('timing-*'):
  for p in d.glob('*'):
   if p.is_file():cp(p,Path('timing')/prefix/d.name/p.name)
 for name in ['client','broad','replay','life','usable']:
  for f in (root/name).rglob('*'):
   if f.is_file() and 'target' not in f.relative_to(root/name).parts and (f.name in ['Cargo.lock','Cargo.toml'] or f.suffix in ['.rs','.c']):
    cp(f,Path('logs')/'source'/prefix/f.relative_to(root))
 for f in (root/'images').glob('*.wasm'):cp(f,Path('portable-images')/prefix/f.name)
for p in (s/'corpus').glob('*'):
 if p.is_file():cp(p,Path('logs')/'corpus'/p.name)
for p in (s/'legacy').rglob('*'):
 if p.is_file() and p.read_bytes()[:4] not in (b'\x7fELF',b'\0asm'):cp(p,Path('logs')/'legacy'/p.relative_to(s/'legacy'))
summ={}
for base in [s/'images',s/'legacy',s/'zero-probe'/'images']:
 for p in base.rglob('*'):
  if p.is_file():
   a=p.read_bytes()
   if a[:4] in (b'\x7fELF',b'\0asm'):summ[str(p.relative_to(s))]=[len(a),hashlib.sha256(a).hexdigest()]
(b/'linked-images.json').write_text(json.dumps(summ,indent=2)+'\n')
for v in ['0f50ed48f','63e798155','7cde9d615','ff3632485']:
 (b/(v+'.patch')).write_bytes(subprocess.check_output(['git','diff','68fd84f3a',v,'--','crates']))
