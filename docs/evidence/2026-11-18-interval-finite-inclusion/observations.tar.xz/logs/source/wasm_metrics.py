from pathlib import Path
import json,sys
from image_metrics import sizes
s=Path(__file__).parent
def wasm(p):
 data=p.read_bytes(); i=8
 def leb():
  nonlocal i
  n=0; shift=0
  while True:
   b=data[i]; i+=1; n|=(b&127)<<shift
   if b<128:return n
   shift+=7
 while i<len(data):
  k=data[i]; i+=1; length=leb()
  if k==10:return length
  i+=length
 raise ValueError('missing code')

