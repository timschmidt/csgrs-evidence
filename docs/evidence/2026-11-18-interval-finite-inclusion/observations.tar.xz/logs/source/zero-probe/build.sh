set -eu
s=/dev/shm/interval-finite-inclusion/zero-probe
. /dev/shm/interval-bisection/env
v=$1
case $2 in
 native) cd "$s/client";export CARGO_TARGET_DIR="$s/target-native";cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/finite-order-client" "$s/images/$v-native"
 setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-native" > "$s/logs/$v-native";;
 wasm) cd "$s/client";export CARGO_TARGET_DIR="$s/target-wasm";cargo +1.88.0 build --offline --lib --release --target wasm32-unknown-unknown
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/finite_order_client.wasm" "$s/images/$v.wasm";;
 replay) cd "$s/replay";export CARGO_TARGET_DIR=/dev/shm/interval-bisection/qualification-target;cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/split-lifetime" "$s/images/$v-replay"
 "$s/images/$v-replay" > "$s/logs/$v-replay";;
 broad) cd "$s/broad";export CARGO_TARGET_DIR=/dev/shm/interval-bisection/consumer-target;cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/split-lifetime" "$s/images/$v-broad"
 for i in 0 1 2;do for j in 1 2 3 4;do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-broad" "$i" > "$s/logs/$v-broad-$i-$j" 2>"$s/logs/$v-guard-$i-$j";done;done;;
esac
