const assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{const m=await WebAssembly.compile(fs.readFileSync(process.argv[2]));
assert.equal(WebAssembly.Module.imports(m).length,0);
const row=process.argv[3]==='zero'?[97,81,130,3,97,3,128]:[130,98,130,2,97,18,128];
for(let pass=0;pass<2;pass++){const {exports:e}=await WebAssembly.instantiate(m);
for(let j=0;j<14;j++){let i=j%7,r=e.observe(i);console.log(pass,i,r);assert.equal(r,row[i]);}}})().catch(e=>{console.error(e);process.exit(1)});
