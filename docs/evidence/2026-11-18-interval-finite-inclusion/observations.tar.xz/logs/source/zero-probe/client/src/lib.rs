use hyperinterval::{DyadicBudget as B, DyadicInterval as D, ExtendedInterval as E, IntervalError};
#[unsafe(no_mangle)]
pub extern "C" fn observe(i:u32)->u32 {
 let zero=D::point(0.into(),i32::MAX).unwrap();
 let value=E::from_finite(zero.clone());
 let mut budget=B::new(match i {4=>8,_=>0},match i {3=>0,5=>1,_=>8});
 let decision=match i {
  0|3|4|5=>value.contains_point(&0.into(),i32::MIN,&mut budget),
  1=>zero.compare_singleton(&zero,&mut budget).map(|o|o.is_eq()),
  2=>value.contains_point(&1.into(),i32::MAX,&mut budget),
  _=>E::empty().strictly_left_of(&value,&mut budget),
 };
 let code=match decision{Ok(true)=>1,Ok(false)=>0,Err(IntervalError::SizeExhausted)=>2,Err(IntervalError::WorkExhausted)=>3,Err(_)=>panic!()};
 code+16*budget.remaining_work() as u32
}
