use finite_order_client::observe;
use std::{hint::black_box,time::Instant};
fn main(){for i in 0..7{
 let r=observe(i);println!("RESULT|{i}|{r}");
 let t=Instant::now();
 for _ in 0..10000{black_box(observe(black_box(i)));}
 println!("WARM|{i}|{r}|10000|{}",t.elapsed().as_nanos());
}}
