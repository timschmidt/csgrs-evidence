set -eu
s=/dev/shm/interval-finite-inclusion
z="$s/zero-probe"
go(){
 local v=$1
 for t in native wasm;do bash "$z/build.sh" "$v" "$t" > "$z/logs/$v-$t-build" 2>&1 & done
 bash "$z/measure.sh" "$v" &
 for job in $(jobs -p);do wait "$job"; done
 node "$z/wasm.cjs" "$z/images/$v.wasm" "$v" > "$z/logs/$v-wasm-run"
}
cd "$s/csgrs";git switch --detach c9f1f9ac5
go fixed
git switch --detach 68fd84f3a
go before
test -s "$s/zero.patch"
git apply "$s/zero.patch"
go zero
for t in native wasm broad replay;do bash "$s/build.sh" zero "$t" > "$s/logs/zero-$t-build" 2>&1 & done
bash "$s/measure.sh" zero &
for job in $(jobs -p);do wait "$job";done
