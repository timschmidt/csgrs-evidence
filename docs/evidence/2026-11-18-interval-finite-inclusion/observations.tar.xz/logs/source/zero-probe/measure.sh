set -eu
s=/dev/shm/interval-finite-inclusion/zero-probe
. /dev/shm/interval-bisection/env
v=$1
for k in life usable; do (
 cd "$s/$k";export CARGO_TARGET_DIR="$s/target-$k"
 cargo +1.95.0 build --release --offline
 cp "$CARGO_TARGET_DIR/release/ball-$k" "$s/images/$v-$k"
 if test "$k" = life;then
  for i in $(seq 1 12);do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-life" > "$s/logs/$v-life-$i" 2> "$s/logs/$v-guard-direct-$i";done
 else
  python3 /dev/shm/interval-box-coverage/measure-rss.py "$s/logs/$v-rss" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-usable" > "$s/logs/$v-usable"
 fi
) > "$s/logs/$v-$k-build" 2>&1 & done
fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;exit "$fail"
