from pathlib import Path
import subprocess,statistics,platform,json
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent
def go(cpu):
 for name in ('locked','standalone'):
  p=s/'legacy'/name
  rows={}
  for i in range(18):
   for v in (['zero','before'] if i%2 else ['before','zero']):
    text=subprocess.check_output(['setarch',platform.machine(),'-R','taskset','-c',str(cpu),p/(v+'-native')],text=True)
    (p/f'{cpu}-{i}-{v}').write_text(text)
    for line in text.splitlines():
     items=line.split()
     if items[0]=='TIME': rows.setdefault(items[1],{}).setdefault(v,[]).append(int(items[-1]))
  result={k:[statistics.median(100*(y/x-1) for x,y in zip(r['before'],r['zero'])),sum(y>x for x,y in zip(r['before'],r['zero']))] for k,r in rows.items()}
  (p/f'timing-{cpu}.json').write_text(json.dumps(result))
with ThreadPoolExecutor() as e:list(e.map(go,[3,5]))
