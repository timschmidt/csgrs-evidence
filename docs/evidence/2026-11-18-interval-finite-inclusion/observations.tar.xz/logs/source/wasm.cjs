const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{const m=await WebAssembly.compile(fs.readFileSync(process.argv[2]));assert.deepEqual(WebAssembly.Module.imports(m),[]);
const old=['fixed','before'].includes(process.argv[3]);
const rows=[[5,5],[0,0],[16,0],[5,5],[5,5],[5,5],[5,5],[0,0],[5,5],[16,0],[5,5],[16,0],[16,0],[0,0],[5,5]];
for(let r=0;r<2;r++){const {exports:e}=await WebAssembly.instantiate(m);for(let j=0;j<30;j++){let i=j%15;
const [scalar,box]=old&&i>=10&&i<=13?[42,10]:rows[i];const value=e.observe(i);
console.log(r,i,value,e.memory.buffer.byteLength);assert.equal(value,scalar+64*box);
}}})().catch(e=>{console.error(e);process.exit(1)})
