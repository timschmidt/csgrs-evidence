"""Charge admitted tests only. Preserve positive previous charges and independently compare artifacts."""
from pathlib import Path
import json,re
s=Path(__file__).parent
r=Path('/mnt/development/csgrs')
def read(p):
    return json.loads(p.read_text())
def data(name):
    return read(s/(name+'.json'))
def save(name, row):
    (s/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n')
prior=read(r/'docs/research/interval-memory-accounts.json')['rational_periodic_ingress']['jobs']
intro=dict(source=(s/'admitted-revision').read_text().strip(),preceding=(s/'base').read_text().strip(),evidence='docs/evidence/2026-11-18-interval-monotone-ingress')
size=intro|dict(scope='Release integration executables for generated rational monotone inputs. CI artifact storage per compiler and target. Only preceding periodic fixtures and new test executables change.',file_cap_bytes=4<<20,ci_slot_bytes=64<<20,required_free_slot_bytes=16<<20,targets={})
mem=intro|dict(scope='One compiled release test process with sequential cases, including native startup or Node/WASI instantiation through exit. Full warmed conformance jobs use the existing cumulative account. Production sources are identical to the preceding revision.',single_job_capacity_bytes=256<<20,single_job_reserved_bytes=64<<20,whole_job_capacity_bytes=1<<30,whole_job_reserved_bytes=256<<20,targets={})
for v in ('1.88.0','1.95.0','stable'):
    tests=data('admitted-tests-'+v)
    base=data('previous-periodic-'+v)
    meas=data('conformance-related-'+v)
    peak_by_target={}
    entries={}
    for t,new in tests.items():
        job=new['job']
        assert new['file']<=4<<20 and job['peak']<=192<<20 and job['passes']==(0 if v=='1.88.0' else 3)
        entries[t]={k:new[k] for k in ('file','code','functions','sha256')}
        entries[t].update(remaining_file_allowance_bytes=(4<<20)-new['file'],free_slot_bytes=(64<<20)-new['file'])
        changes={}
        for k in ('file','code','functions'):
            old=base[t][k];current=meas[t][k];delta=max(0,current-old)
            assert delta<=min(4096,old//100),(v,t,k,delta)
            changes[k]=dict(preceding=old,measured=current,incremental_positive_bytes=delta,cumulative_positive_bytes=delta)
        assert meas[t]['file']<=4<<20
        entries[t]['existing_periodic_test']=dict(
            metrics=changes,
            remaining_file_allowance_bytes=(4<<20)-(base[t]['file']+changes['file']['cumulative_positive_bytes']),
            free_slot_bytes=(64<<20)-meas[t]['file'])
        peak_by_target[t]=dict(peak_bytes=job['peak'],remaining_above_reserve_bytes=(192<<20)-job['peak'],passed=job['passes'])
    size['targets'][v]=entries
    report=data('whole-admitted-'+v)
    log=(s/'logs'/('whole-admitted-'+v+'.log')).read_text()
    assert 'memory.max 1073741824' in log and 'memory.swap.max 0' in log
    assert all(re.search(r'^'+key+r' 0$',log,re.M) for key in ('max','oom','oom_kill','oom_group_kill'))
    peak=int(re.search(r'^memory.peak (\d+)$',log,re.M)[1])
    old=prior[v]['cumulative_positive'];step=max(0,peak-prior[v]['whole_warmed_peak'])
    cumulative=old+step
    assert cumulative<=768<<20
    passes=sum(map(len,report['guest'].values()));hosts=len(report['host_required']);replays=len(report['fresh_replays'])
    assert (passes,hosts,replays)==((181,6,5) if v=='1.88.0' else (241,9,5))
    peak_by_target['whole_warmed_job']=dict(peak_bytes=peak,previous_warmed_peak=prior[v]['whole_warmed_peak'],previous_cumulative_positive=old,incremental_positive=step,cumulative_positive=cumulative,remaining_above_reserve=(768<<20)-cumulative,direct_guest_passes=passes,native_required=hosts,fresh_guest_replays=replays)
    mem['targets'][v]=peak_by_target
save('admitted-size-entry',size);save('admitted-memory-entry',mem)
