from pathlib import Path
import sys,subprocess as sp
s=Path(__file__).parent;root=Path('/mnt/development/csgrs');d=s/'speed-src/crates/hyperinterval/src';v=sys.argv[1]
for n in ('arctangent','rational_admission','exponential','logarithm'):
 (d/(n+'.rs')).write_bytes((root/f'crates/hyperinterval/src/{n}.rs').read_bytes())
p=d/'arctangent.rs';t=p.read_text();start=t.index('            crate::rational_admission::reserve_monotone_source');end=t.index('\n        };',start)
fast='''            let (sign, n, d) = x.ratio_parts();
            budget.reserve(n.bits().max(d.bits()), 2, false)?;
            let width = x.reduction_input_bits();
            let (n, d) = if width == 0 {
                (n, d)
            } else {
                budget.reserve(width, 3, true)?;
                (x.numerator(), x.denominator())
            };
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)'''
if v=='copied':
 part=fast
elif v=='replace':
 part=fast.replace('let (n, d) = if width == 0','let (n, d) = if width == 0')
elif v=='prepared':
 part='''            let (sign, n, d) = crate::rational_admission::monotone_parts(x, budget)?;
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)'''
 q=d/'rational_admission.rs';txt=q.read_text()+'''
#[inline]
pub(crate) fn monotone_parts<'a>(x: &'a Rational, budget: &mut DyadicBudget) -> Result<(num_bigint::Sign, &'a num_bigint::BigUint, &'a num_bigint::BigUint), IntervalError> {
    let (sign, n, d) = x.ratio_parts();
    budget.reserve(n.bits().max(d.bits()), 2, false)?;
    let w = x.reduction_input_bits();
    if w == 0 { return Ok((sign,n,d)); }
    budget.reserve(w,3,true)?;
    Ok((sign,x.numerator(),x.denominator()))
}
''';q.write_text(txt)
elif v=='width':
 part=t[start:end]
else:raise ValueError(v)
p.write_text(t[:start]+part+t[end:])
if v in ('width','replace'):
 q=d/'rational_admission.rs';t=q.read_text()
 a=t.index('    let width = ln.bits().max(ld.bits()).max(rn.bits()).max(rd.bits());')
 b=t.index('        let products',a)
 t=t[:a]+'''    let ln_bits = ln.bits();
    let ld_bits = ld.bits();
    let rn_bits = rn.bits();
    let rd_bits = rd.bits();
    let width = ln_bits.max(ld_bits).max(rn_bits).max(rd_bits);
    if width > 64 {
        if first.reduction_input_bits() == 0 && other.reduction_input_bits() == 0 {
            if ln_bits != rn_bits || ld_bits != rd_bits { return Ok(false); }
            // Checking bit lengths is constant time. Comparing stored digits
            // costs at most one linear pass over each coefficient.
            budget.reserve(width,2,false)?;
            return Ok(ln == rn && ld == rd);
        }
'''+t[b:];q.write_text(t)
for n in ('arctangent','rational_admission'):
 (s/f'{v}-{n}.rs').write_bytes((d/(n+'.rs')).read_bytes())
