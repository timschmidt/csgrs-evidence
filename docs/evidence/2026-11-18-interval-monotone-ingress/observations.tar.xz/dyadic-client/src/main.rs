mod allocations;
use hyperinterval::{DyadicBudget,IntervalError,DyadicInterval};
use std::{ffi::c_void,hint::black_box};
#[cfg(not(target_arch="wasm32"))]
unsafe extern "C" {fn measure_stack(cb:unsafe extern "C" fn(*mut c_void),ctx:*mut c_void,warm:i32,pattern:u8)->usize;}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="scope")]
unsafe extern "C" {fn mark(start:u32,pattern:u32)->u32;}
struct Case{iv:DyadicInterval, op:u8, mode:u8, heap:Option<allocations::AllocationStats>}
unsafe extern "C" fn run(ctx:*mut c_void) {
 let c=unsafe{&mut *ctx.cast::<Case>()};
 let h=allocations::once(||{
  let go=|b:&mut DyadicBudget| c.iv.exp(i32::from(c.op) * 8 - 8,b).map(|i|{black_box(i);});
  if c.mode!=0 { assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted));}
  if c.mode!=1 { go(&mut DyadicBudget::new(4096,1<<40)).unwrap(); }
 }); c.heap=Some(h);
}
fn main(){
 let args:Vec<_>=std::env::args().skip(1).collect();
 let shape:u8=args[0].parse().unwrap();let op:u8=args[1].parse().unwrap();
 let mode:u8=args[2].parse().unwrap();let warm:bool=args[3].parse().unwrap();
 let origin:bool=args[4].parse().unwrap();
 let pat=85u8;
 let setup=||{ let (a,b,e) = [(3,3,0),(2,3,0),(0,0,0),(-3,-2,0),(-8,-7,0),(-1,-1,-199)][shape as usize];
 let iv=DyadicInterval::new(a.into(),b.into(),e).unwrap();
 Case{iv,op,mode,heap:None}
 };
 // For complete ownership, include input construction, repeated operation and
 // output/input destruction inside one allocation epoch, without nested counters.
 if origin {
  let h=allocations::once(||{
   let c=setup();
   let invoke=||{
    let go=|b:&mut DyadicBudget|c.iv.exp(i32::from(op) * 8 - 8,b).map(|i|{black_box(i);});
    if mode!=0{assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted))}
    if mode!=1{go(&mut DyadicBudget::new(4096,1<<40)).unwrap()}
   };
   if warm{invoke()}invoke();drop(black_box(c));
  });
  println!("{shape},{op},{mode},{warm},0,0,{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);return;
 }
 let mut c=setup();let ctx=(&mut c as *mut Case).cast();
 #[cfg(not(target_arch="wasm32"))] let stack=unsafe{measure_stack(run,ctx,i32::from(warm),pat)};
 #[cfg(target_arch="wasm32")] let stack=unsafe{if warm{run(ctx)};mark(1,pat.into());run(ctx);mark(0,pat.into()) as usize};
 let h=c.heap.unwrap();
 println!("{shape},{op},{mode},{warm},{pat},{stack},{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);

}
