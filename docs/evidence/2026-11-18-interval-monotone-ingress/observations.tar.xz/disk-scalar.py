"""Prime on disk, then run the maintained scalar job at the same path in its measured cgroup."""
from pathlib import Path
import os,runpy,sys
root=Path('/mnt/development/csgrs')
s=Path(__file__).parent
d=s.parent/'monotone-validation'
mode,v=sys.argv[1:]
driver=root/'crates/hyperinterval/conformance/wasi-tests.py'
output=d/('job-'+v)
assert mode in ('warm','prepare')
if mode=='warm':
    old=d/('prepared-'+v)
    assert (output/'report.json').exists()
    output.rename(old)
mkdir=Path.mkdir
def populate(self,*args,**kwargs):
    res=mkdir(self,*args,**kwargs)
    if self==output:
        if mode=='prepare':
            (d/'gmp'/v).rename(output/'gmp-cache')
        else:
            for name in ('target','gmp-cache'):(old/name).rename(output/name)
        Path.mkdir=mkdir
    return res
Path.mkdir=populate
sdk=d/'sdk/usr'
sys.path.insert(0,str(driver.parent))
sys.argv=[str(driver),'--toolchain',v,'--cc',str(sdk/'bin/clang-18'),'--sysroot',str(sdk),'--output',str(output)]
runpy.run_path(str(driver),run_name='__main__')
