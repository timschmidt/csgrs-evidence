from pathlib import Path
import subprocess as sp,os,json
s=Path(__file__).parent
js=(s/'stack-wasi.mjs').read_text().replace('return reserve-first;','console.error("ROOM",reserve,first,reserve-first);return reserve-first;')
(s/'room.mjs').write_text(js)
for v in ['1.95.0','stable']:
 for folder in ['life','life-clean']:
  target=s/('life-target-'+v);env=os.environ|{'CARGO_TARGET_DIR':str(target),'NODE_NO_WARNINGS':'1'}
  with (s/'logs'/f'room-{v}-{folder}.build').open('w') as log:sp.run(['cargo','+'+v,'build','--release','--locked','--target','wasm32-wasip1'],cwd=s/folder,env=env,stdout=log,stderr=log,check=True)
  cmd=['node',s/'room.mjs',target/'wasm32-wasip1/release/periodic-input-lifetime.wasm']
  args=[[]] if folder=='life' else [[str(k),str(op),str(mode),'false','false'] for k in range(6) for op in range(3) for mode in range(3)]
  rows=[]
  for a in args:
   run=sp.run(cmd+a,env=env,stdout=sp.DEVNULL,stderr=sp.PIPE,text=True,check=True)
   rows.extend([list(map(int,line.split()[1:])) for line in run.stderr.splitlines() if line.startswith('ROOM ')])
  assert len(rows)==(216 if folder=='life' else 54)
  (s/f'room-{v}-{folder}.json').write_text(json.dumps(rows)+'\n')
