from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hyperinterval/tests/periodic_ingress.rs'
old='use hyperreal::Rational;\n#[path = "support/rational_coordinate.rs"]\nmod rational_coordinate;\nuse rational_coordinate::coordinate;'
t=p.read_text();assert old in t
p.write_text(t.replace(old,'include!("support/rational_coordinate.rs");'))
