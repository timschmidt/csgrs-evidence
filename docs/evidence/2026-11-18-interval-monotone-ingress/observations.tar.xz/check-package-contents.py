from pathlib import Path
import tarfile,subprocess,json
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
rev=(s/'admitted-revision').read_text().strip()
def source(p):return subprocess.check_output(['git','show',rev+':'+str(p)],cwd=r)
out={}
for name in ['hyperinterval','hyperreal']:
    p,=(s/'conformance-package-target/package').glob(name+'-*.crate')
    with tarfile.open(p) as archive:
        count=0
        for m in archive:
            rel=Path(m.name).relative_to(m.name.split('/')[0])
            if rel.parts[:1]==('src',) and m.isfile():
                assert archive.extractfile(m).read()==source(Path('crates')/name/rel)
                count+=1
        assert count>10;out[name]=count
for f,d in [('monotone_ingress.rs','monotone.rs'),('support/rational_coordinate.rs','support/rational_coordinate.rs')]:
    assert source(Path('crates/hyperinterval/tests')/f)==(s/'conformance-package-client/tests'/d).read_bytes()
print(json.dumps(dict(source=rev,packaged_source_files=out,identical_qualification_fixture_files=2)))
