set -eu
. /dev/shm/interval-scalar-replay/env
s=/dev/shm/interval-monotone-ingress
stage=$1
trial="$s/pilot-$stage"
mkdir -p "$trial"
git archive --format=tar "$(cat "$s/base")" | tar -x -C "$trial"
python3 "$s/variants.py" "$stage" "$trial"
cp "$s/monotone_ingress.rs" "$trial/crates/hyperinterval/tests/"
cp -r "$s/life" "$trial/client"
sed -i 's|../src/crates|../crates|g' "$trial/client/Cargo.toml"
export CARGO_TARGET_DIR="$trial/target"
cargo +stable build --locked --offline --manifest-path "$trial/client/Cargo.toml" --release --target wasm32-wasip1 > "$s/logs/$stage-pilot-build.log" 2>&1
node "$s/stack-wasi.mjs" "$CARGO_TARGET_DIR/wasm32-wasip1/release/periodic-input-lifetime.wasm" > "$s/life-$stage-stable-wasm32-wasip1.csv" 2>"$s/logs/$stage-pilot-run.log"
