from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import itertools,sys,os,subprocess as sp
s=Path(__file__).parent;stage=sys.argv[1]
def lane(job):
 v,t=job;target=s/('angle-target-'+v);env=os.environ|{'CARGO_TARGET_DIR':str(target),'NODE_NO_WARNINGS':'1'}
 with (s/'logs'/f'angle-{stage}-{v}-{t}.log').open('w') as log:
  sp.run(['cargo','+'+v,'build','--release','--offline','--target',t],cwd=s/'angle-client',env=env,stdout=log,stderr=log,check=True)
  b=target/t/'release/periodic-input-lifetime';cmd=[b] if t.startswith('x86') else ['node',s/'stack-wasi.mjs',b.with_suffix('.wasm')]
  cases=list(itertools.product(range(6),range(2),range(3),['false','true'],['true','false']))
  def trial(case):
   return sp.check_output([*cmd,*map(str,case)],env=env,stderr=log,text=True)
  with ThreadPoolExecutor(3) as pool:data=list(pool.map(trial,cases))
  assert len(data)==144
  (s/f'angle-{stage}-{v}-{t}.csv').write_text(''.join(data))
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,[(v,t) for v in ['stable','1.95.0','1.88.0'] for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']]))
