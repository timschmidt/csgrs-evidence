from pathlib import Path
s=Path(__file__).parent
for n in ['life','life-clean']:
 p=s/n/'src/main.rs';t=p.read_text();start=t.index('0=>c.iv.sin');end=t.index('\n  };',start)
 t=t[:start]+'''0=>c.iv.exp(-8,b).map(|i|{black_box(i);}),1=>c.iv.log(-8,b).map(|i|{black_box(i);}),
   _=>c.iv.atan(-8,b).map(|i|{black_box(i);}),'''+t[end:]
 t=t.replace('0..4','0..3');p.write_text(t)
p=s/'clean.py';p.write_text(p.read_text().replace('range(4)','range(3)').replace('==288','==216'))
p=s/'stack-room.py';p.write_text(p.read_text().replace('range(4)','range(3)').replace('288 if','216 if').replace('else 72','else 54'))
