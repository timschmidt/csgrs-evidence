from pathlib import Path
import sys
s=Path(__file__).parent;v=sys.argv[1];d=s/'src/crates/hyperinterval/src';root=Path('/mnt/development/csgrs/crates/hyperinterval/src')
for n in ('arctangent','rational_admission'):(d/f'{n}.rs').write_bytes((root/f'{n}.rs').read_bytes())
p=d/'arctangent.rs';t=p.read_text()
a=t.index('        if within_zero_cell(');b=t.index('        let point',a)
t=t[:a]+'''        let lower_width = zero_cell_width(a, precision);
        if lower_width != 0 {
            let upper_width = zero_cell_width(b, precision);
            if upper_width != 0 {
                return rational_zero_cells(a, b, lower_width.max(upper_width), precision, budget);
            }
        }
'''+t[b:]
a=t.index('fn within_zero_cell(');b=t.index('\n}',a);t=t[:a]+'''fn zero_cell_width(x: &hyperreal::Rational, precision: i32) -> u64 {
    let (_, n, d) = x.ratio_parts();
    let n = n.bits();
    let d = d.bits();
    if n != 0 && i128::from(n) < i128::from(d) + i128::from(precision) {
        n.max(d)
    } else {
        0
    }'''+t[b:]
a=t.index('fn rational_zero_cells');t=t[:a]+t[a:].replace('    precision: i32,','    width: u64,\n    precision: i32,',1)
a=t.index('    let (_, lower_n',a);b=t.index('    budget.reserve(1, 2',a);t=t[:a]+'    budget.reserve(width, 4, false)?;\n'+t[b:]
p.write_text(t)
p=d/'rational_admission.rs';t=p.read_text()
if v in ('widths','shared','canonical'):
 a=t.index('        let size = |value:');b=t.index('        self.budget.reserve',a)
 t=t[:a]+'''        let bits = stored_width(left)
            .saturating_add(stored_width(right))
            .saturating_add(u64::from(carry));
'''+t[b:]
 a=t.index('// Reserve both coefficient copies')
 t=t[:a]+'''#[inline(never)]
fn stored_width(x: &Rational) -> u64 {
    let (_, n, d) = x.ratio_parts();
    n.bits().max(d.bits())
}

'''+t[a:]
 t=t.replace('    let (_, n, d) = x.ratio_parts();\n    budget.reserve(n.bits().max(d.bits()), 2, false)?;','    budget.reserve(stored_width(x), 2, false)?;')
 a=t.index('    let (ls, ln, ld)');b=t.index('        if first.reduction_input_bits()',a)
 t=t[:a]+'''    if first.sign() != other.sign() {
        return Ok(false);
    }
    let width = stored_width(first).max(stored_width(other));
    if width > 64 {
        let (_, ln, ld) = first.ratio_parts();
        let (_, rn, rd) = other.ratio_parts();
'''+t[b:]
 if v=='shared':
  a=t.index('        let products =');b=t.index('    }\n    Ok(first == other)',a)
  t=t[:a]+'''        return budget.rational().compare(first, other).map(|order| order.is_eq());
'''+t[b:]
 if v=='canonical':
  a=t.index('        let (_, ln, ld)');b=t.index('    }\n    Ok(first == other)',a)
  t=t[:a]+'''        budget.reserve(width,2,false)?;
        let w = other.reduction_input_bits();
        if w != 0 { budget.reserve(w,3,true)?; }
        // The first endpoint was admitted and materialized before equality.
        return Ok(first.numerator() == other.numerator() && first.denominator() == other.denominator());
'''+t[b:]
p.write_text(t)
for n in ('rational_admission','arctangent'):(s/f'{v}-{n}.rs').write_bytes((d/f'{n}.rs').read_bytes())
