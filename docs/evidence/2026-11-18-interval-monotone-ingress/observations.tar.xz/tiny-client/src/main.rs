mod allocations;
use hyperinterval::{DyadicBudget,IntervalError,RationalInterval};
use hyperreal::{Rational,ExactDyadicLine2};
use std::{ffi::c_void,hint::black_box};
#[cfg(not(target_arch="wasm32"))]
unsafe extern "C" {fn measure_stack(cb:unsafe extern "C" fn(*mut c_void),ctx:*mut c_void,warm:i32,pattern:u8)->usize;}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="scope")]
unsafe extern "C" {fn mark(start:u32,pattern:u32)->u32;}
fn coord(span:f64,y:f64)->Rational{
 let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
 let (_,p)=line.intersection_point_f64([0.,y],[span,y]).unwrap();
 p[0].exact_rational_ref().unwrap().clone()
}
struct Case{iv:RationalInterval, op:u8, mode:u8, heap:Option<allocations::AllocationStats>}
unsafe extern "C" fn run(ctx:*mut c_void) {
 let c=unsafe{&mut *ctx.cast::<Case>()};
 let h=allocations::once(||{
  let go=|b:&mut DyadicBudget| match c.op {
   0=>c.iv.exp(-8,b).map(|i|{black_box(i);}),1=>c.iv.log(-8,b).map(|i|{black_box(i);}),
   _=>c.iv.atan(-8,b).map(|i|{black_box(i);}),
  };
  if c.mode!=0 { assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted));}
  if c.mode!=1 { go(&mut DyadicBudget::new(4096,1<<40)).unwrap(); }
 }); c.heap=Some(h);
}
fn main(){
 let args:Vec<_>=std::env::args().skip(1).collect();
 let shape:u8=args[0].parse().unwrap();let op:u8=args[1].parse().unwrap();
 let mode:u8=args[2].parse().unwrap();let warm:bool=args[3].parse().unwrap();
 let origin:bool=args[4].parse().unwrap();
 let pat=85u8;
 let setup=||{
 let d = "202402253307310618352495346718917307049556649764142118356901358027430339567995346891960383701437124495187077864316811911389808737385793476867013399940738509921517424276566361364466907742093216341239767678472745068562007483424692698618103355649159556340810056512358769552333414615230502532186327508646006263307707741093494784";
 let tiny=|sign:i32|format!("{sign}/{d}").parse::<Rational>().unwrap();
 let iv=match shape {
  0=>RationalInterval::point(tiny(1)),
  1=>RationalInterval::new(tiny(1),tiny(1)).unwrap(),
  2=>RationalInterval::new(tiny(-1),tiny(-1)).unwrap(),
  3=>RationalInterval::new(tiny(-1),tiny(1)).unwrap(),
  4=>RationalInterval::new(Rational::zero(),tiny(1)).unwrap(),
  5=>RationalInterval::new(tiny(-1),Rational::fraction(1,128).unwrap()).unwrap(),
  _=>RationalInterval::new(coord(6.,1.0/65536.),coord(10.,1.0/32768.)).unwrap()

 };
 Case{iv,op,mode,heap:None}
 };
 // For complete ownership, include input construction, repeated operation and
 // output/input destruction inside one allocation epoch, without nested counters.
 if origin {
  let h=allocations::once(||{
   let c=setup();
   let invoke=||{
    let go=|b:&mut DyadicBudget|match op{
     0=>c.iv.exp(-8,b).map(|i|{black_box(i);}),1=>c.iv.log(-8,b).map(|i|{black_box(i);}),
     _=>c.iv.atan(-8,b).map(|i|{black_box(i);})};
    if mode!=0{assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted))}
    if mode!=1{go(&mut DyadicBudget::new(4096,1<<40)).unwrap()}
   };
   if warm{invoke()}invoke();drop(black_box(c));
  });
  println!("{shape},{op},{mode},{warm},0,0,{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);return;
 }
 let mut c=setup();let ctx=(&mut c as *mut Case).cast();
 #[cfg(not(target_arch="wasm32"))] let stack=unsafe{measure_stack(run,ctx,i32::from(warm),pat)};
 #[cfg(target_arch="wasm32")] let stack=unsafe{if warm{run(ctx)};mark(1,pat.into());run(ctx);mark(0,pat.into()) as usize};
 let h=c.heap.unwrap();
 println!("{shape},{op},{mode},{warm},{pat},{stack},{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);

}
