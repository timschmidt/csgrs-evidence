set -eu
s=/mnt/development/.interval-refactor-build/monotone-evidence-migration
. "$s/disk-env.sh"
export CARGO_BUILD_JOBS=5
v=$1
python3 "$s/disk-scalar.py" prepare "$v" > "$s/logs/disk-prepare-$v.log" 2>&1
systemd-run --user --scope -q -p MemoryMax=1G -p MemorySwapMax=0 bash "$s/disk-whole.sh" "$v" > "$s/logs/whole-admitted-$v.log" 2>&1
cp "$d/job-$v/report.json" "$s/whole-admitted-$v.json"
