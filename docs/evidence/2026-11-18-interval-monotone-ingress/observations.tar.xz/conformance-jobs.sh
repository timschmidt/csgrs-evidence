set -eu
s=/dev/shm/interval-monotone-ingress
cd /mnt/development/csgrs
. /dev/shm/interval-scalar-replay/env
export CARGO_BUILD_JOBS=2
v=$1
python3 "$s/prepare-conformance.py" "$v" > "$s/logs/prepare-conformance-$v.log" 2>&1
systemd-run --user --scope -q -p MemoryMax=1G -p MemorySwapMax=0 bash "$s/whole-conformance.sh" "$v" > "$s/logs/whole-conformance-$v.log" 2>&1
cp "/dev/shm/interval-scalar-replay/accepted-$v/report.json" "$s/whole-conformance-$v.json"
