import csv,re
from pathlib import Path
p=Path('interval-inventory.tsv');rows=list(csv.DictReader(p.open(),delimiter='\t'));cols=list(rows[0])
for n,op in [('exponential','exp'),('logarithm','log'),('arctangent','atan'),('rational_admission','')]:
 path=f'crates/hyperinterval/src/{n}.rs';lines=Path(path).read_text().splitlines()
 entries=[r for r in rows if r['path']==path]
 for sym in {r['symbol'] for r in entries}:
  group=sorted([r for r in entries if r['symbol']==sym],key=lambda r:int(r['line']))
  pos=[i+1 for i,l in enumerate(lines) if re.match(r'\s*(?:pub(?:\(crate\))? )?(?:struct|fn) '+sym+r'\b',l)]
  assert len(group)==len(pos),(sym,pos)
  for r,i in zip(group,pos):r['line']=str(i)
 if op:
  r=[r for r in entries if r['symbol']==op][1]
  r.update(endpoint_representation='exact rational to outward dyadic',semantics='certified monotone image with budgeted source reduction and singleton comparison',allocation='budgeted bigint stages',platform='rational + dyadic',serialization='no new wire state',consumers='public RationalInterval operation',disposition='retain in owning layer',baseline_tests='hyperinterval/tests/monotone_ingress.rs; hyperinterval/tests/'+n+'.rs',baseline_benchmarks=op+'_cost',review_status='generated and canonical rational endpoints, work cutoffs, domain and composition reviewed')
 else:
  for name,desc in [('reserve_monotone_source','admit endpoint copies and possible normalization before canonical access'),('same_monotone_source','budget singleton decisions on canonical or generated rational endpoints')]:
   line=next(i+1 for i,l in enumerate(lines)if l.startswith('pub(crate) fn '+name+'('))
   r=entries[-1].copy();r.update(symbol=name,line=str(line),semantics=desc,endpoint_representation='stored rational magnitudes',allocation='borrowed admission; possible admitted comparison products',platform='rational + dyadic',visibility='pub(crate)',serialization='no wire state',consumers='RationalInterval exp, log, atan',disposition='retain in owning layer',baseline_tests='hyperinterval/tests/monotone_ingress.rs',baseline_benchmarks='exp_cost; log_cost; atan_cost',review_status='represented width, shared storage and work accounting reviewed');rows.insert(rows.index(entries[-1])+1,r);entries.append(r)
with p.open('w',newline='')as f:
 w=csv.DictWriter(f,cols,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
