from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,os,subprocess as sp
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs')
sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
def lane(v):
 common=['--release','--locked','-p','hyperinterval'];features=['--all-features'] if v!='1.88.0' else ['--no-default-features','--features','integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace']
 rows={}
 for target in ('native','wasm32-wasip1'):
  env=os.environ|dict(CARGO_TARGET_DIR='/dev/shm/interval-scalar-replay/lint-'+v,CARGO_BUILD_JOBS='4')
  platforms=[]
  if target!='native':
   platforms=['--target',target]
   env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-'+v+'/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
  full=common+platforms+features
  cmd=['cargo','+'+v,'test',*full,'--test','monotone_ingress','--no-run','--message-format=json-render-diagnostics']
  with (s/'logs'/f'complete-{v}-{target}.build').open('w') as log:
   rows_json=sp.check_output(cmd,cwd=repo,env=env,stderr=log,text=True)
   [binary]=[Path(x['executable']) for x in map(json.loads,rows_json.splitlines()) if x.get('executable')]
   rows[target]=metrics(binary)
   assert rows[target]['file']<=4*2**20
   sp.run(['cargo','+'+v,'clippy',*full,'--all-targets' if target=='native' else '--tests','--','-D','warnings'],cwd=repo,env=env,stdout=log,stderr=log,check=True)
  out=sp.check_output(['systemd-run','--user','--scope','-q','-p','MemoryMax=256M','-p','MemorySwapMax=0','--','python3',str(s/'complete-job.py'),v,target,str(binary)],env=env,text=True)
  rows[target]['job']=json.loads(out)
  if target=='native':
   with (s/'logs'/f'complete-{v}-owner.log').open('w') as log:
    for args in (['test',*full,'--all-targets'],['test',*common,'--no-default-features'],['test',*full,'--doc'],['doc',*full,'--no-deps'],['check',*full,'--examples','--benches']):
     sp.run(['cargo','+'+v,*args],env=env|{'RUSTDOCFLAGS':'-D warnings'},cwd=repo,stdout=log,stderr=log,check=True)
 (s/f'complete-tests-{v}.json').write_text(json.dumps(rows,indent=2)+'\n')
with ThreadPoolExecutor(3) as pool:list(pool.map(lane,('1.88.0','1.95.0','stable')))
