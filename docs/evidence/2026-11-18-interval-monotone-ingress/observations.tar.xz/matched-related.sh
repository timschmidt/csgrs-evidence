set -eu
s=/dev/shm/interval-monotone-ingress
. /dev/shm/interval-scalar-replay/env
cd "$s/related-src"
python3 "$s/matched-related.py" samebase
git -C /mnt/development/csgrs archive b34e822ad crates/hyperinterval/tests | tar -xmC "$s/related-src"
python3 "$s/matched-related.py" sametest
