set -eu
s=/dev/shm/interval-monotone-ingress
if test "$1" = stable; then
 . /dev/shm/interval-scalar-replay/env
 export CARGO_TARGET_DIR=/dev/shm/interval-fixed-hull/coverage
else
 . /dev/shm/interval-fixed-hull/env
 export RUSTUP_HOME=/dev/shm/interval-flow-coverage/rustup RUSTUP_TOOLCHAIN=nightly RUSTFLAGS=-Zcoverage-options=branch CARGO_TARGET_DIR=/dev/shm/interval-phase-neighbors/nightly-target
 export PATH="$RUSTUP_HOME/toolchains/nightly-x86_64-unknown-linux-gnu/bin:$PATH"
fi
export CARGO_BUILD_JOBS=4
if ! python3 scripts/interval_coverage.py > "$s/logs/complete-coverage-$1.log" 2>&1; then
 rg -q '^Production coverage is below 100% on the instrumented metrics.$' "$s/logs/complete-coverage-$1.log"
fi
dir=$(sed -n 's/^Coverage artifacts in //p' "$s/logs/complete-coverage-$1.log")
cp "$dir/summary.json" "$s/complete-coverage-$1.json"
