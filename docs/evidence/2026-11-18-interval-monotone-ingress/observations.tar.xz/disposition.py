from pathlib import Path
import json
s=Path(__file__).parent
vrs=('1.95.0','stable')
def read(n):return json.loads((s/(n+'.json')).read_text())
results={}
for v in vrs:
    control=read('base-'+v)
    admitted=read('conformance-'+v)
    assert admitted==control
    for variant in ('retained','reuse','widths','shared','canonical'):
        failures=[]
        for target,files in read(variant+'-'+v).items():
            for name,new in files.items():
                for metric in ('file','code','functions'):
                    old=control[target][name][metric];delta=new[metric]-old
                    cap=min(4096,old//100)
                    if delta>cap:
                        failures.append([target,name,metric,delta,cap])
        results.setdefault(variant,{})[v]=failures
assert all(any(t.values())for t in results.values())
assert all(not s['failures'] for d in read('retained-memory-summary').values()for s in d.values())
(s/'review-disposition.json').write_text(json.dumps(dict(unchanged_linked_hashes=24,rejected_size_growth=results),indent=2)+'\n')
