from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import itertools,os,shutil,subprocess as sp,sys
s=Path(__file__).parent;stage=sys.argv[1];pilot=s/('pilot-'+stage);folder=pilot/'clean-client'
shutil.copytree(s/'life-clean',folder,dirs_exist_ok=True)
p=folder/'Cargo.toml';p.write_text(p.read_text().replace('../src/crates','../crates'))
env=os.environ|{'CARGO_TARGET_DIR':str(pilot/'clean-target'),'NODE_NO_WARNINGS':'1'}
with (s/'logs'/f'{stage}-pilot-clean-build.log').open('w')as log:
 sp.run(['cargo','+stable','build','--release','--offline','--locked','--target','wasm32-wasip1'],cwd=folder,env=env,stdout=log,stderr=log,check=True)
b=pilot/'clean-target/wasm32-wasip1/release/periodic-input-lifetime.wasm'
cases=list(itertools.product(range(6),range(3),range(3),['false','true'],['true','false']))
def run(k):
 return sp.check_output(['node',s/'stack-wasi.mjs',b,*map(str,k)],env=env,text=True)
with ThreadPoolExecutor(3)as pool:data=list(pool.map(run,cases))
(s/f'clean-pilot-{stage}.csv').write_text(''.join(data))
