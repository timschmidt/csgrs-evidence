from pathlib import Path
import sys
s=Path(__file__).parent;v=sys.argv[1];d=s/('pilot-'+v)/'crates/hyperinterval/src'
for n in ('exponential','logarithm','rational_admission'):(d/f'{n}.rs').write_bytes((Path('crates/hyperinterval/src')/(n+'.rs')).read_bytes())
t=(s/'grid-arctangent.rs').read_text();i=t.index('            let (sign, numerator, denominator)');j=t.index('\n        };',i)
t=t[:i]+'''            if admit_atan_source(x, precision, budget)? {
                return cell_at_zero(x.is_negative(), precision);
            }
            endpoint(
                &BigInt::from_biguint(x.sign(), x.numerator().clone()),
                &BigInt::from(x.denominator().clone()),
                0,
                precision,
                budget,
            )'''+t[j:]
i=t.index('impl ExtendedInterval<DyadicInterval>');attr={'probe':'#[inline(never)]','boolean':'','inline_cell':'#[inline(never)]'}[v]
t=t[:i]+'''// Admit the endpoint and report whether its signed cell is already proved.
/// The strict bit-length inequality proves |x| < 2^precision without a GCD.
#[cfg(feature = "rational")]
'''+attr+'''
fn admit_atan_source(x: &hyperreal::Rational, precision: i32, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
    let (_, n, d) = x.ratio_parts();
    let n_bits = n.bits();
    let d_bits = d.bits();
    budget.reserve(n_bits.max(d_bits), 2, false)?;
    if n_bits != 0 && i128::from(n_bits) < i128::from(d_bits) + i128::from(precision) {
        budget.reserve(1, 2, false)?;
        return Ok(true);
    }
    let width = x.reduction_input_bits();
    if width != 0 { budget.reserve(width, 3, true)?; }
    Ok(false)
}

'''+t[i:]
if v=='inline_cell':t=t.replace('fn cell_at_zero','#[inline(never)]\nfn cell_at_zero')
(d/'arctangent.rs').write_text(t)
(s/(v+'-arctangent.rs')).write_text(t)
