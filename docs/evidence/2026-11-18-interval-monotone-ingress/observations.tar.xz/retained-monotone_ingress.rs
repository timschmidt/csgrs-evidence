//! Monotone elementary images, generated endpoints and resource admission.
#![cfg(feature = "dyadic")]

#[test]
fn scalar_tail_completes_exp_one_inside_the_work_allowance() {
    use hyperinterval::{DyadicBudget, DyadicInterval};
    // The certified Taylor tail only needs scalar doubling. Directed MPFR
    // gives these adjacent 2^-16 grid points for exp(1).
    assert_eq!(
        DyadicInterval::point(1.into(), 0)
            .unwrap()
            .exp(-16, &mut DyadicBudget::new(16_384, 69_533))
            .unwrap()
            .range,
        DyadicInterval::new(178_145.into(), 178_146.into(), -16).unwrap()
    );
}

#[cfg(feature = "rational")]
#[path = "support/rational_coordinate.rs"]
mod rational_coordinate;

#[cfg(feature = "rational")]
mod rational {
    use super::rational_coordinate::coordinate;
    use hyperinterval::{
        DomainCoverage, DyadicBudget, DyadicInterval, ExtendedInterval, IntervalError,
        RangeEnclosure, RationalInterval,
    };
    use hyperreal::Rational;

    #[derive(Debug, Clone, Copy)]
    enum Operation {
        Exp,
        Log,
        Atan,
    }

    impl Operation {
        fn image(
            self,
            input: &RationalInterval,
            budget: &mut DyadicBudget,
        ) -> Result<RangeEnclosure<ExtendedInterval<DyadicInterval>>, IntervalError> {
            let result = match self {
                Self::Exp => input.exp(-8, budget)?,
                Self::Log => return input.log(-8, budget),
                Self::Atan => input.atan(-8, budget)?,
            };
            Ok(RangeEnclosure {
                range: ExtendedInterval::from_finite(result.range),
                domain: result.domain,
            })
        }
    }

    #[test]
    fn generated_endpoints_match_directed_cells_and_the_exact_work_cutoff() {
        use Operation::*;
        // Directed 512-bit MPFR at grid 2^-8, using monotonicity on [2,3].
        for (op, point, range) in [
            (Exp, (5141, 5142), (1891, 5142)),
            (Log, (281, 282), (177, 282)),
            (Atan, (319, 320), (283, 320)),
        ] {
            for (left, right, (lo, hi)) in [
                (coordinate(6., 3.), coordinate(10., 3.), point),
                (
                    Rational::from(3),
                    coordinate(281_474_976_710_662., 3.),
                    point,
                ),
                (coordinate(10., 2.), coordinate(6., 3.), range),
            ] {
                let input = RationalInterval::new(left, right).unwrap();
                let mut budget = DyadicBudget::new(4096, 1 << 40);
                let image = op.image(&input, &mut budget).unwrap();
                let work = (1 << 40) - budget.remaining_work();
                assert_eq!(image.domain, DomainCoverage::Complete);
                assert_eq!(
                    image.range.as_finite().unwrap(),
                    &DyadicInterval::new(lo.into(), hi.into(), -8).unwrap()
                );
                assert_eq!(
                    op.image(&input, &mut DyadicBudget::new(4096, work - 1)),
                    Err(IntervalError::WorkExhausted)
                );
                let mut exact = DyadicBudget::new(4096, work);
                assert_eq!(op.image(&input, &mut exact).unwrap(), image);
                assert_eq!(exact.remaining_work(), 0);
            }
        }
    }

    #[test]
    fn denial_on_a_cold_source_precedes_reduction_and_preserves_a_retry() {
        use Operation::*;
        for op in [Exp, Log, Atan] {
            for y in [2., 3.] {
                let x = coordinate(281_474_976_710_662., y);
                let bits = x.reduction_input_bits();
                assert!(bits > 64);
                let input = RationalInterval::point(x);
                let reductions = 3 * bits * bits;
                for (limit, units, remaining, error) in [
                    (0, 100, 100, IntervalError::SizeExhausted),
                    (bits - 1, 1 << 30, 1 << 30, IntervalError::SizeExhausted),
                    (
                        bits,
                        2 * bits - 1,
                        2 * bits - 1,
                        IntervalError::WorkExhausted,
                    ),
                    (
                        bits,
                        2 * bits + reductions - 1,
                        reductions - 1,
                        IntervalError::WorkExhausted,
                    ),
                ] {
                    let mut budget = DyadicBudget::new(limit, units);
                    let run = || op.image(&input, &mut budget);
                    #[cfg(feature = "dispatch-trace")]
                    let result = {
                        use hyperreal::dispatch_trace;
                        dispatch_trace::reset();
                        let result = dispatch_trace::with_recording(run);
                        assert!(dispatch_trace::take_trace().dispatch.is_empty(), "{op:?}");
                        result
                    };
                    #[cfg(not(feature = "dispatch-trace"))]
                    let result = {
                        let mut run = run;
                        run()
                    };
                    assert_eq!(result, Err(error));
                    assert_eq!(budget.remaining_work(), remaining);
                }
                let retry = || {
                    op.image(&input, &mut DyadicBudget::new(4096, 1 << 40))
                        .unwrap()
                };
                #[cfg(feature = "dispatch-trace")]
                {
                    use hyperreal::dispatch_trace;
                    for expected in [1, 0] {
                        dispatch_trace::reset();
                        let image = dispatch_trace::with_recording(retry);
                        assert_eq!(image.domain, DomainCoverage::Complete);
                        assert_eq!(
                            dispatch_trace::take_trace().path_count(
                                "rational",
                                "canonicalization",
                                "lazy-internal-coordinate"
                            ),
                            expected
                        );
                    }
                }
                #[cfg(not(feature = "dispatch-trace"))]
                assert_eq!(retry().domain, DomainCoverage::Complete);
            }
        }
    }

    #[test]
    fn logarithm_leaves_excluded_generated_bounds_untouched() {
        let invalid = RationalInterval::point(coordinate(6., -3.));
        let partial =
            RationalInterval::new(coordinate(281_474_976_710_662., -3.), Rational::from(1))
                .unwrap();
        let mut zero = DyadicBudget::new(0, 0);
        assert_eq!(invalid.log(-8, &mut zero), Err(IntervalError::EmptyDomain));
        let mut small = DyadicBudget::new(32, 1 << 20);
        let image = partial.log(-8, &mut small).unwrap();
        assert_eq!(image.domain, DomainCoverage::Partial);
        assert_eq!(
            image.range,
            ExtendedInterval::below(DyadicInterval::point(0.into(), 0).unwrap()).unwrap()
        );
    }

    #[cfg(feature = "dispatch-trace")]
    #[test]
    fn a_refused_second_endpoint_cannot_multiply_unadmitted_coefficients() {
        use hyperreal::dispatch_trace;
        use num_bigint::BigInt;
        let denominator = (BigInt::from(1) << 1024u32) + 1;
        for op in [Operation::Exp, Operation::Log, Operation::Atan] {
            // All three endpoints have the same sign and leading binary exponent.
            // A comparison by products would inspect the far side of the budget.
            let numerator: BigInt =
                &denominator * 3 + if matches!(op, Operation::Log) { -1 } else { 1 };
            let near_three = format!("{numerator}/{denominator}")
                .parse::<Rational>()
                .unwrap();
            let input = if matches!(op, Operation::Log) {
                RationalInterval::new(near_three, Rational::from(3))
            } else {
                RationalInterval::new(Rational::from(3), near_three)
            }
            .unwrap();
            let mut budget = DyadicBudget::new(256, 1 << 40);
            dispatch_trace::reset();
            let result = dispatch_trace::with_recording(|| op.image(&input, &mut budget));
            let count = dispatch_trace::take_trace().path_count(
                "rational",
                "comparison",
                "biguint-cross-product",
            );
            assert_eq!(result, Err(IntervalError::SizeExhausted));
            assert_eq!(count, 0, "{op:?}");
        }
    }

    #[test]
    fn tiny_atan_uses_the_signed_grid_cell_for_independent_endpoints() {
        use num_bigint::BigInt;
        let denominator = BigInt::from(1) << 1074u32;
        let tiny = |n: i32| format!("{n}/{denominator}").parse::<Rational>().unwrap();
        for (a, b, lo, hi) in [(1, 1, 0, 1), (-1, -1, -1, 0), (-1, 1, -1, 1)] {
            let input = RationalInterval::new(tiny(a), tiny(b)).unwrap();
            // Four linear stages at 1,075 bits and two units for the grid.
            assert_eq!(
                input.atan(-16, &mut DyadicBudget::new(1074, 4302)),
                Err(IntervalError::SizeExhausted)
            );
            assert_eq!(
                input.atan(-16, &mut DyadicBudget::new(1075, 4301)),
                Err(IntervalError::WorkExhausted)
            );
            let mut exact = DyadicBudget::new(1075, 4302);
            let image = input.atan(-16, &mut exact).unwrap();
            assert_eq!(exact.remaining_work(), 0);
            assert_eq!(image.domain, DomainCoverage::Complete);
            assert_eq!(
                image.range,
                DyadicInterval::new(lo.into(), hi.into(), -16).unwrap()
            );
        }
        let mixed = RationalInterval::new(tiny(-1), Rational::fraction(1, 128).unwrap()).unwrap();
        assert_eq!(
            mixed
                .atan(-8, &mut DyadicBudget::new(4096, 1 << 40))
                .unwrap()
                .range,
            DyadicInterval::new((-1).into(), 2.into(), -8).unwrap()
        );
    }

    #[test]
    fn materialized_outward_images_reenter_the_elementary_kernels() {
        let source = RationalInterval::new(coordinate(10., 2.), coordinate(6., 3.)).unwrap();
        let mut budget = DyadicBudget::new(4096, 1 << 40);
        let exp = source.exp(-8, &mut budget).unwrap();
        let log = source.log(-8, &mut budget).unwrap();
        let atan = source.atan(-8, &mut budget).unwrap();
        for receipt in [exp.domain, log.domain, atan.domain] {
            assert_eq!(receipt, DomainCoverage::Complete);
        }
        // Directed MPFR on the retained grid endpoints after each first operation.
        let log_exp = exp.range.log(-8, &mut budget).unwrap();
        let exp_log = log.range.as_finite().unwrap().exp(-8, &mut budget).unwrap();
        let atan_atan = atan.range.atan(-8, &mut budget).unwrap();
        for (image, receipt, lo, hi) in [
            (log_exp.range.as_finite().unwrap(), log_exp.domain, 511, 769),
            (&exp_log.range, exp_log.domain, 511, 771),
            (&atan_atan.range, atan_atan.domain, 213, 230),
        ] {
            assert_eq!(receipt, DomainCoverage::Complete);
            assert_eq!(
                image,
                &DyadicInterval::new(lo.into(), hi.into(), -8).unwrap()
            );
        }

        // Exp is positive, but this outward grid enclosure includes zero.
        let negative = RationalInterval::new(coordinate(6., -8.), coordinate(10., -7.)).unwrap();
        let tiny = negative.exp(-8, &mut budget).unwrap();
        assert_eq!(tiny.domain, DomainCoverage::Complete);
        assert_eq!(
            tiny.range,
            DyadicInterval::new(0.into(), 1.into(), -8).unwrap()
        );
        let result = tiny.range.log(-8, &mut budget).unwrap();
        assert_eq!(result.domain, DomainCoverage::Partial);
        assert_eq!(
            result.range,
            ExtendedInterval::below(DyadicInterval::point((-1419).into(), -8).unwrap()).unwrap()
        );
    }
}
