from pathlib import Path
import subprocess as sp,sys
s=Path(__file__).parent
stage=sys.argv[1];src=Path(sys.argv[2]);root=Path('/mnt/development/csgrs');d=src/'crates/hyperinterval/src'
base=(s/'base').read_text().strip()
def original(name):return sp.check_output(['git','-C',root,'show',base+':crates/hyperinterval/src/'+name+'.rs'],text=True)
ref=(s/'src/crates/hyperinterval/src/rational_admission.rs').read_text()
eq=ref[ref.index('// Both inputs stay live,'):];eq=eq.replace('pub(crate) fn same_monotone_source','#[inline(never)]\npub(crate) fn same_monotone_source')
guard='''
pub(crate) fn reserve_monotone_source(x: &Rational, budget: &mut DyadicBudget) -> Result<(), IntervalError> {
    let (_, n, d) = x.ratio_parts();
    budget.reserve(n.bits().max(d.bits()), 2, false)?;
    let width = x.reduction_input_bits();
    if width != 0 {
        budget.reserve(width, 3, true)?;
    }
    Ok(())
}
'''
(d/'rational_admission.rs').write_text(original('rational_admission')+'\n'+('' if stage=='raw' else guard)+eq)
for name,first,second in [('exponential','a','b'),('arctangent','a','b'),('logarithm','b','a')]:
 p=d/(name+'.rs');orig=original(name);i=orig.index('impl crate::RationalInterval');pos=orig.index('        let point = ',i);end=orig.index('\n        };',pos)+len('\n        };')
 t=orig[:pos]; old=orig[pos:end]
 pos_guard=old.index('            budget.reserve(');rest=old.index('            endpoint(',pos_guard)
 if stage=='raw':
  v=old[:pos_guard]+'''            let (sign, n, d) = x.ratio_parts();
            budget.reserve(n.bits().max(d.bits()), 2, false)?;
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)
        };'''
 elif stage=='direct':
  v=old[:pos_guard]+'''            crate::rational_admission::reserve_monotone_source(x, budget)?;
'''+old[rest:]
 else:
  ty='RangeEnclosure<DyadicInterval>' if name=='exponential' else 'Image'
  t+=f'''        crate::rational_admission::reserve_monotone_source({first}, budget)?;
        rational_image(a, b, precision, budget)
    }}
}}

#[cfg(feature = "rational")]
#[inline(never)]
fn rational_image(a: &hyperreal::Rational, b: &hyperreal::Rational, precision: i32, budget: &mut DyadicBudget) -> Result<{ty}, IntervalError> {{
'''
  v=old[:pos_guard]+old[rest:]
 tail=orig[end:]
 tail=tail.replace('if a == b {',f'if crate::rational_admission::same_monotone_source({first}, {second}, budget)? {{',1)
 if stage=='outer':
  boundary=tail.index('\n    }\n}');tail=tail[:boundary]+tail[boundary:].replace('\n    }\n}','\n}',1)
  idx=tail.index(f'point({second}, budget)?')
  start=tail.rfind('\n',0,idx)
  tail=tail[:start]+f'\n        crate::rational_admission::reserve_monotone_source({second}, budget)?;'+tail[start:]
 p.write_text(t+v+tail)
