from pathlib import Path
import json,subprocess as sp
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
def run(*a):return sp.check_output(a,cwd=r,text=True)
for v in ('1.88.0','1.95.0','stable'):
    assert (s/('whole-admitted-'+v+'.json')).is_file()
result=json.loads(run('python3',str(s/'archive.py')))
(s/'archive-result').write_text(json.dumps(result)+'\n')
row=result['row'].split('\t')
assert row[0]==result['record'] and row[1]=='2'
p=r/'INTERVAL_REFACTOR_PROGRESS.md'
with p.open('a') as f:
    f.write((s/'progress-section.md').read_text())
    f.write(f"\nEvidence commit `{result['commit']}` contains {result['members']:,} files\nunder `{result['record']}` with digest\n`{row[3]}`. [Evidence index](docs/evidence-archive.tsv)\n")
print(json.dumps(result))
