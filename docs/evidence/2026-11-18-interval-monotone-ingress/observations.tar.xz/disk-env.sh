d=/mnt/development/.interval-refactor-build/monotone-validation
export TMPDIR="$d/tmp" CARGO_HOME="$d/cargo-home" RUSTUP_HOME="$d/rustup" CARGO_TARGET_DIR="$d/target" RUSTUP_TOOLCHAIN=stable
export PATH="$d/node/bin:$d/sdk/usr/bin:$PATH"
export LD_LIBRARY_PATH="$d/sdk/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1 CARGO_CACHE_AUTO_CLEAN_FREQUENCY=never
