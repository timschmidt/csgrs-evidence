from pathlib import Path
import subprocess as sp,sys
s=Path(__file__).parent
stage=sys.argv[1];src=Path(sys.argv[2]);root=Path('/mnt/development/csgrs');d=src/'crates/hyperinterval/src'
base=(s/'base').read_text().strip()
def original(name):return sp.check_output(['git','-C',root,'show',base+':crates/hyperinterval/src/'+name+'.rs'],text=True)
ref=(s/'pilot-direct/crates/hyperinterval/src/rational_admission.rs').read_text()
eq=ref[ref.index('// Both inputs stay live,'):];eq=eq.replace('#[inline(never)]\n','');eq=eq.replace('pub(crate) fn same_monotone_source','#[inline(never)]\npub(crate) fn same_monotone_source')
guard='''
pub(crate) fn reserve_monotone_source(x: &Rational, budget: &mut DyadicBudget) -> Result<(), IntervalError> {
    let (_, n, d) = x.ratio_parts();
    budget.reserve(n.bits().max(d.bits()), 2, false)?;
    let width = x.reduction_input_bits();
    if width != 0 {
        budget.reserve(width, 3, true)?;
    }
    Ok(())
}
'''
if stage in ('deferred','deferred_fast'):
 guard='''
#[inline]
pub(crate) fn admit_monotone_reduction(x: &Rational, budget: &mut DyadicBudget) -> Result<(), IntervalError> {
    let width = x.reduction_input_bits();
    if width == 0 { return Ok(()); }
    budget.reserve(width, 3, true)
}
'''
if stage=='flat':
 guard='\n#[inline(always)]'+guard
elif stage in ('split','fast'):
 guard='\n#[inline(never)]'+guard
(d/'rational_admission.rs').write_text(original('rational_admission')+'\n'+('' if stage=='raw' else guard)+eq)
for name,first,second in [('exponential','a','b'),('arctangent','a','b'),('logarithm','b','a')]:
 p=d/(name+'.rs');orig=original(name);i=orig.index('impl crate::RationalInterval');pos=orig.index('        let point = ',i);end=orig.index('\n        };',pos)+len('\n        };')
 t=orig[:pos]; old=orig[pos:end]
 pos_guard=old.index('            budget.reserve(');rest=old.index('            endpoint(',pos_guard)
 if stage=='raw':
  v=old[:pos_guard]+'''            let (sign, n, d) = x.ratio_parts();
            budget.reserve(n.bits().max(d.bits()), 2, false)?;
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)
        };'''
 elif stage in ('deferred','deferred_fast'):
  v=old[:pos_guard]+'''            crate::rational_admission::admit_monotone_reduction(x, budget)?;
'''+old[pos_guard:]
  if stage=='deferred_fast':
   v=v[:pos_guard]+'''            crate::rational_admission::admit_monotone_reduction(x, budget)?;
            let (sign, n, d) = if x.reduction_input_bits() == 0 {
                x.ratio_parts()
            } else {
                (x.sign(), x.numerator(), x.denominator())
            };
            budget.reserve(n.bits().max(d.bits()), 2, false)?;
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)
        };'''
 elif stage in ('direct','scalar','scalar_zero','scalar_borrow','lazyone','borrow','series','divisor','finish','tail','tail_borrow','flat','split','fast'):
  v=old[:pos_guard]+'''            crate::rational_admission::reserve_monotone_source(x, budget)?;
'''+old[rest:]
  if stage=='fast':
   k=v.index('            endpoint(');v=v[:k]+'''            let (sign, n, d) = if x.reduction_input_bits() == 0 {
                x.ratio_parts()
            } else {
                (x.sign(), x.numerator(), x.denominator())
            };
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)
        };'''
 else:
  ty='RangeEnclosure<DyadicInterval>' if name=='exponential' else 'Image'
  t+=f'''        crate::rational_admission::reserve_monotone_source({first}, budget)?;
        rational_image(a, b, precision, budget)
    }}
}}

#[cfg(feature = "rational")]
#[inline(never)]
fn rational_image(a: &hyperreal::Rational, b: &hyperreal::Rational, precision: i32, budget: &mut DyadicBudget) -> Result<{ty}, IntervalError> {{
'''
  v=old[:pos_guard]+old[rest:]
 tail=orig[end:]
 tail=tail.replace('if a == b {',f'if crate::rational_admission::same_monotone_source({first}, {second}, budget)? {{',1)
 if stage=='outer':
  boundary=tail.index('\n    }\n}');tail=tail[:boundary]+tail[boundary:].replace('\n    }\n}','\n}',1)
  idx=tail.index(f'point({second}, budget)?')
  start=tail.rfind('\n',0,idx)
  tail=tail[:start]+f'\n        crate::rational_admission::reserve_monotone_source({second}, budget)?;'+tail[start:]
 p.write_text(t+v+tail)

if stage in ('scalar_zero','scalar_borrow','lazyone','borrow','series','divisor','finish','tail','tail_borrow'):
 p=d/'exponential.rs';t=p.read_text()
 t=t.replace('    let one = DyadicInterval::point(BigInt::one(), 0)?;\n    if n.is_zero() {','    if n.is_zero() {',1).replace('            Ok(one)\n','            DyadicInterval::point(BigInt::one(), 0)\n',1)
 if stage in ('borrow','tail_borrow','scalar_borrow'):
  t=t.replace('    let magnitude = n.abs();','    let positive;\n    let magnitude = if negative { positive = -n; &positive } else { n };',1).replace('at_least_integer(&magnitude,','at_least_integer(magnitude,',1).replace('scaled_quotient(&magnitude,','scaled_quotient(magnitude,',1)
 p.write_text(t)

if stage in ('tail','tail_borrow'):
 p=d/'exponential.rs';t=p.read_text()
 start=t.index('fn small_exp(')
 def move(decl):
  global t
  line=next(l for l in t[start:].splitlines(keepends=True) if l.strip().startswith('let '+decl+' ='))
  t=t[:start]+t[start:].replace(line,'',1).replace('            return sum.add', '        '+line+'            return sum.add',1)
 for name in ['two','zero']:move(name)
 p.write_text(t)

if stage in ('series','divisor','finish'):
 p=d/'exponential.rs';t=p.read_text()
 if stage=='series':t=t.replace('fn small_exp(', '#[inline(never)]\nfn small_exp(')
 elif stage=='divisor':
  t=t.replace('        let divisor = DyadicInterval::point(BigInt::from(k), 0)?;\n        term = term.mul(argument, budget)?.div(&divisor, working, budget)?;', '        let product = term.mul(argument, budget)?;\n        let divisor = DyadicInterval::point(BigInt::from(k), 0)?;\n        term = product.div(&divisor, working, budget)?;')
 elif stage=='finish':
  marker='            return sum.add(&term.mul(&two, budget)?.hull(&zero, budget)?, budget);'
  assert marker in t
  start=t.index('fn small_exp(')
  two=next(l for l in t[start:].splitlines(keepends=True) if l.strip().startswith('let two ='))
  zero=next(l for l in t[start:].splitlines(keepends=True) if l.strip().startswith('let zero ='))
  t=t[:start]+t[start:].replace(two,'',1).replace(zero,'',1).replace(marker,'            return enclose_tail(&sum, &term, budget);')
  t+='\n#[inline(never)]\nfn enclose_tail(sum: &DyadicInterval, term: &DyadicInterval, budget: &mut DyadicBudget) -> Result<DyadicInterval, IntervalError> {\n'+two+zero+'    sum.add(&term.mul(&two, budget)?.hull(&zero, budget)?, budget)\n}\n'
 p.write_text(t)

if stage in ('scalar','scalar_zero','scalar_borrow'):
 p=d/'exponential.rs';t=p.read_text()
 t=t.replace('    let two = DyadicInterval::point(BigInt::from(2), 0)?;\n','').replace('term.mul(&two, budget)?','term.scale((&BigInt::one(), 1), budget)?')
 p.write_text(t)
