from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,sys,json,subprocess as sp,shutil
s=Path(__file__).parent;root=s/'src';stage=sys.argv[1];sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
def lane(v):
 out={}
 for target in ('native','wasm32-wasip1'):
  env=os.environ|dict(CARGO_TARGET_DIR='/dev/shm/interval-scalar-replay/target-'+v,CARGO_BUILD_JOBS='5')
  cmd=['cargo','+'+v,'build','--release','--locked','--all-features','-p','hyperinterval','--example','exp_cost','--example','log_cost','--example','atan_cost','--test','exponential','--test','logarithm','--test','arctangent','--message-format=json-render-diagnostics']
  if target!='native':
   cmd+=['--target',target];env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-'+v+'/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
  data=sp.check_output(cmd,cwd=root,env=env,text=True)
  out[target]={}
  for x in map(json.loads,data.splitlines()):
   if x.get('executable'):
    n=x['target']['name'];p=Path(x['executable']);out[target][n]=metrics(p)
    if target=='native' and n.endswith('_cost'):
     outpath=s/(stage+'-'+v+'-'+n);tmp=outpath.with_suffix('.new');shutil.copy2(p,tmp);tmp.replace(outpath)
  assert len(out[target])==6
 (s/f'{stage}-{v}.json').write_text(json.dumps(out,indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(lane,['1.95.0','stable']))
