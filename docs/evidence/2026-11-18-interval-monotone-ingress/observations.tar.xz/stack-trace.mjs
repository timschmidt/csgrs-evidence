import {readFile} from 'node:fs/promises';
import {WASI} from 'node:wasi';
const [binary,...args]=process.argv.slice(2);
const wasi=new WASI({version:'preview1',args:[binary,...args],env:{},returnOnExit:true});
Error.stackTraceLimit=40;
let inst,start,min,stack,active;
const mark=(on)=>{
 if(on){active=true;min=start=inst.exports.__stack_pointer.value;return 0;}
 active=false;
 console.error(JSON.stringify({used:start-min,stack}));
 return start-min;
};
const tick=sp=>{if(active&&sp<min){min=sp;stack=new Error().stack.split('\n').slice(2);}};
({instance:inst}=await WebAssembly.instantiate(await readFile(binary),{wasi_snapshot_preview1:wasi.wasiImport,scope:{mark,tick}}));
process.exitCode=wasi.start(inst);
