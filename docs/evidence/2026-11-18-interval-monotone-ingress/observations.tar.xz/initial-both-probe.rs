use hyperreal::{dispatch_trace as trace, ExactDyadicLine2};
use hyperinterval::{DyadicBudget,RationalInterval,IntervalError};
fn main() {
    for name in ["exp","log","atan"] {
        let span=281_474_976_710_662.;
        let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
        let (_,p)=line.intersection_point_f64([0.,3.],[span,3.]).unwrap();
        let v=p[0].exact_rational_ref().unwrap();
        let bits=v.reduction_input_bits();
        let input=RationalInterval::point(v.clone());
        let mut b=DyadicBudget::new(0,100);
        trace::reset();
        let err=trace::with_recording(||match name {
            "exp"=>input.exp(-8,&mut b).unwrap_err(),
            "atan"=>input.atan(-8,&mut b).unwrap_err(),
            _=>input.log(-8,&mut b).unwrap_err(),
        });
        assert_eq!(err,IntervalError::SizeExhausted);
        let n=trace::take_trace().path_count("rational","canonicalization","lazy-internal-coordinate");
        println!("{name} stored_bits={bits} remaining_work={} canonicalizations={n}",b.remaining_work());
    }

    let d=num_bigint::BigInt::from(3).pow(650);
    for op in ["exp","log","atan"] {
        let n:num_bigint::BigInt=&d*3+if op=="log" {-1} else {1};
        let near=format!("{n}/{d}").parse::<hyperreal::Rational>().unwrap();
        let input=if op=="log" {RationalInterval::new(near,3.into())}else{RationalInterval::new(3.into(),near)}.unwrap();
        let mut b=DyadicBudget::new(256,1<<40);trace::reset();
        let res=trace::with_recording(||match op {
            "exp"=>input.exp(-8,&mut b).unwrap_err(),"log"=>input.log(-8,&mut b).unwrap_err(),_=>input.atan(-8,&mut b).unwrap_err(),
        });
        let cnt=trace::take_trace().path_count("rational","comparison","biguint-cross-product");
        println!("{op} denied-second={res:?} cross_products={cnt}");
    }
}
