import json,subprocess as sp
from pathlib import Path
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs')
def run(*a):sp.run(a,cwd=repo,check=True)
def load(n):return json.loads((s/(n+'.json')).read_text())
run('python3',str(s/'conformance-register.py'))
m=load('admitted-memory-entry')
peaks=[t['whole_warmed_job']['peak_bytes'] for t in m['targets'].values()]
charges=[t['whole_warmed_job']['cumulative_positive'] for t in m['targets'].values()]
progress=s/'progress-section.md'
assert 'Measured complete scalar jobs' not in progress.read_text()
with progress.open('a') as p:
    p.write(f'\nMeasured complete scalar jobs executed 181 guest cases on Rust 1.88 and\n241 each on 1.95 and 1.99. The respective native case counts were 6, 9\nand 9, with five additional fresh guest replays in each lane. The warmed\njobs peaked at {peaks[0]:,}, {peaks[1]:,} and {peaks[2]:,} bytes\nunder the 1 GiB swap-disabled limit. All limit and OOM counters were zero.\nAfter carrying forward prior positive charges, the smallest remaining\nheadroom above the 256 MiB reserve was {(768<<20)-max(charges):,} bytes.\nThis qualifies the warmed Linux/WASI jobs. Cold builds and physical\nembedded targets require separate qualification.\n')
for kind in ('size','memory'):
    run('python3',str(s/'append-account.py'),f'docs/research/interval-{kind}-accounts.json','monotone_composition_qualification',str(s/('admitted-'+kind+'-entry.json')))
