use hyperinterval::{RationalInterval,DyadicBudget,DyadicInterval};
use hyperreal::Rational;
use num_bigint::BigInt;
fn main(){
 let d=BigInt::from(1)<<1074u32;
 let tiny=|n:i32|format!("{n}/{d}").parse::<Rational>().unwrap();
 for (a,b) in [(1,1),(-1,-1),(-1,1)] {
  let iv=RationalInterval::new(tiny(a),tiny(b)).unwrap();
  let mut budget=DyadicBudget::new(1075,1<<32);
  let result=iv.atan(-16,&mut budget).unwrap();
  assert!(result.range.bounds().is_some());
  println!("{a} {b} cost {}",(1u64<<32)-budget.remaining_work());
 }
 let t=DyadicInterval::point(1.into(),0).unwrap().exp(-16,&mut DyadicBudget::new(16384,69533)).unwrap();
 assert!(t.range.bounds().is_some());
}
