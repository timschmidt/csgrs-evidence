set -eu
s=/mnt/development/.interval-refactor-build/monotone-evidence-migration
. "$s/disk-env.sh"
export CARGO_BUILD_JOBS=1
group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
printf 'memory.max '; cat "$group/memory.max"
printf 'memory.swap.max '; cat "$group/memory.swap.max"
date -u +%s.%N
python3 "$s/disk-scalar.py" warm "$1"
date -u +%s.%N
printf 'memory.peak '; cat "$group/memory.peak"
cat "$group/memory.events"
