from pathlib import Path
import json,re
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
def rd(path):return json.loads(path.read_text())
def j(n):return rd(s/(n+'.json'))
def dump(n,x):(s/(n+'.json')).write_text(json.dumps(x,indent=1)+'\n')
vrs=['1.88.0','1.95.0','stable'];releases=vrs[1:]
record='docs/evidence/2026-11-18-interval-monotone-ingress'
ident=dict(source=(s/'accepted-revision').read_text().strip(),preceding=(s/'base').read_text().strip(),fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',evidence=record)
sm=j('retained-size-summary');sd=j('retained-size-details');mm=j('retained-memory-summary');md=j('retained-memory-details')
for v in releases:
 for t,names in sd[v].items():
  assert len(names)==6
  assert all(min(row[6:])>=0 for q in names.values()for row in q.values())
prior=rd(r/'docs/research/interval-memory-accounts.json')['rational_periodic_ingress']['jobs']
z=ident|dict(scope='Six existing release consumers per target: exp_cost, log_cost, atan_cost and the exponential, logarithm and arctangent test executables. Positive growth is charged per workload for final file, executable code and union of named functions or guest bodies. All rows are in retained-size-details.json.',absolute_incremental_bytes=4096,relative_incremental_percent=1,absolute_cumulative_bytes=8192,relative_cumulative_percent=2,ci_slot_bytes=64*2**20,required_free_slot_bytes=16*2**20,targets=sm,new_test_file_cap_bytes=4*2**20,new_tests={},related_periodic_test={})
m=ident|dict(scope='Rational and dyadic exponential, logarithm and arctangent. Per-call and fresh-process complete ownership, cold, warm, denial and retry; includes standalone dyadic-only calls and 1075-bit near-zero arctangent sources. One caller per target. Positive baseline drift is carried forward per workload. retained-memory-details.json contains the unrounded accounts.',metrics=['stack','peak requested heap','retained requested heap'],absolute_incremental_bytes=[128,64,32],relative_incremental_percent=2,absolute_cumulative_bytes=[256,128,64],relative_cumulative_percent=4,required_stack_reserve_bytes=256*1024,targets={},new_test_capacity_bytes=256*2**20,new_test_reserve_bytes=64*2**20,whole_scalar_capacity_bytes=2**30,whole_scalar_reserve_bytes=2**28,jobs={})
for v in vrs:
 m['targets'][v]={}
 for t,ms in mm[v].items():
  rest=md[v][t];expect={'angle','dyadic'} if v=='1.88.0' else {'tiny','overall','angle','dyadic','life','clean'}
  assert {k.split('/')[0]for k in rest}==expect
  assert not ms['failures'],(v,t,ms['failures'][:1])
  ms=ms.copy();ms.pop('failures')
  mx=max(row[2]for k,row in rest.items() if k.endswith('/stack'))
  if t.startswith('x86'):free=2*2**20-4096-mx
  else:
   rooms=[j(f'retained-room-{name}-{v}') for name in expect-{'life','clean'}];free=min(row[-2]for client in rooms for row in client)
   if v in releases:
    for name in ['life','life-clean']:free=min(free,min(row[1]for row in j(f'retained-room-{v}-{name}')))
  assert free>=256*1024
  ms.update(max_observed_stack_bytes=mx,minimum_stack_headroom_bytes=free);m['targets'][v][t]=ms
 new=j('accepted-tests-'+v);z['new_tests'][v]={};peaks={}
 for t,d in new.items():
  assert d['job']['passes']==(1 if v=='1.88.0'else 7) and d['file']<=4*2**20 and d['job']['peak']+64*2**20<=256*2**20
  z['new_tests'][v][t]=dict(file=d['file'],code=d['code'],functions=d['functions'],remaining_file_cap=4*2**20-d['file'],free_slot=64*2**20-d['file']);peaks[t]=d['job']['peak']
 rel=j('accepted-scalar-related-'+v);old=rd(Path('/dev/shm/interval-periodic-ingress')/('complete-tests-'+v+'.json'))
 z['related_periodic_test'][v]={}
 for t,y in rel.items():
  q={}
  for metric in ['file','code','functions']:
   x=old[t][metric];delta=max(0,y[metric]-x)
   assert delta<=min(4096,x//100) and y['file']<=4*2**20,(v,t,metric,delta)
   q[metric]=dict(preceding=x,candidate=y[metric],positive_step=delta)
  z['related_periodic_test'][v][t]=q
 log=(s/'logs'/('whole-accepted-'+v+'.log')).read_text();assert '\nmax 0\n' in log and 'oom_kill 0' in log and 'memory.swap.max 0' in log
 peak=int(re.search(r'^memory.peak (\d+)',log,re.M)[1]);old=prior[v]['cumulative_positive'];charge=old+max(0,peak-prior[v]['whole_warmed_peak']);assert charge+2**28<=2**30
 rep=j('whole-accepted-'+v);assert len(rep['fresh_replays'])==5
 m['jobs'][v]=dict(compiled_test_peaks=peaks,whole_warmed_peak=peak,previous_warmed_peak=prior[v]['whole_warmed_peak'],previous_cumulative_positive=old,incremental_positive=charge-old,cumulative_positive=charge,remaining_above_reserve=2**30-2**28-charge,direct_guest_passes=sum(map(len,rep['guest'].values())),native_required=len(rep['host_required']),fresh_guest_replays=len(rep['fresh_replays']))
dump('registered-size',z);dump('registered-memory',m)
