from pathlib import Path
import sys,subprocess as sp
s=Path(__file__).parent;v=sys.argv[1];d=s/('pilot-'+v)/'crates/hyperinterval/src';root=Path.cwd()
for n in ('exponential','logarithm','rational_admission'):(d/f'{n}.rs').write_bytes((root/f'crates/hyperinterval/src/{n}.rs').read_bytes())
t=sp.check_output(['git','show','a2cda58a3:crates/hyperinterval/src/arctangent.rs'],text=True)
i=t.index('impl crate::RationalInterval');pos=t.index('        let point =',i);end=t.index('\n    }\n}',pos)
orig=t[pos:end];src=t[:pos]+'''        if within_zero_cell(a, precision) && within_zero_cell(b, precision) {
            return rational_zero_cells(a, b, precision, budget);
        }
''';suf=t[end+len('\n    }\n}'):]
mark='#[cfg(feature = "rational")]\n'
if v=='range_inline':
 src+=orig+'\n    }\n}\n'
else:
 src+='''        rational_atan(a, b, precision, budget)
    }
}
'''+mark+'''#[inline(never)]
fn rational_atan(a: &hyperreal::Rational, b: &hyperreal::Rational, precision: i32, budget: &mut DyadicBudget) -> Result<Image, IntervalError> {
'''+orig+'\n}\n'
src+='\n'+mark+('' if v=='range_inline' else '#[inline(never)]\n')+'''fn within_zero_cell(x: &hyperreal::Rational, precision: i32) -> bool {
    let (_, n, d) = x.ratio_parts();
    n.bits() != 0 && i128::from(n.bits()) < i128::from(d.bits()) + i128::from(precision)
}

'''+mark+'''#[inline(never)]
fn rational_zero_cells(a: &hyperreal::Rational, b: &hyperreal::Rational, precision: i32, budget: &mut DyadicBudget) -> Result<Image,IntervalError> {
    let (_,an,ad)=a.ratio_parts();
    let (_,bn,bd)=b.ratio_parts();
    budget.reserve(an.bits().max(ad.bits()).max(bn.bits()).max(bd.bits()),4,false)?;
    budget.reserve(1,2,false)?;
    let lo = if a.is_negative() { -1 } else { 0 };
    let hi = if b.is_positive() { 1 } else { 0 };
    complete(DyadicInterval::new(lo.into(),hi.into(),precision)?)
}
''';t=src+suf
if v=='range_cold':
 t=t.replace('fn within_zero_cell','fn within_zero_cell').replace('#[inline(never)]\nfn rational_zero_cells','#[cold]\n#[inline(never)]\nfn rational_zero_cells')
(d/'arctangent.rs').write_text(t);(s/(v+'-arctangent.rs')).write_text(t)
