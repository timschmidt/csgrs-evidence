from pathlib import Path
p=Path('crates/hyperinterval/src/arctangent.rs');t=p.read_text()
a=t.index('            crate::rational_admission::reserve_monotone_source');b=t.index('\n        };',a)
t=t[:a]+'''            let (sign, numerator, denominator) = x.ratio_parts();
            let n_bits = numerator.bits();
            let d_bits = denominator.bits();
            budget.reserve(n_bits.max(d_bits), 2, false)?;
            // |x| < 2^precision follows from the stored bit lengths here.
            // Since 0 < |atan(x)| < |x|, its grid cell is exact for either
            // sign, including for a fraction with a common factor.
            if n_bits != 0 && i128::from(n_bits) < i128::from(d_bits) + i128::from(precision) {
                budget.reserve(1, 2, false)?;
                return cell_at_zero(x.is_negative(), precision);
            }
            let width = x.reduction_input_bits();
            let (n, d) = if width == 0 {
                (numerator, denominator)
            } else {
                budget.reserve(width, 3, true)?;
                (x.numerator(), x.denominator())
            };
            endpoint(&BigInt::from_biguint(sign, n.clone()), &BigInt::from(d.clone()), 0, precision, budget)'''+t[b:]
old='''        return if negative {
            DyadicInterval::new((-1).into(), BigInt::zero(), precision)
        } else {
            DyadicInterval::new(BigInt::zero(), BigInt::one(), precision)
        };'''
assert old in t;t=t.replace(old,'        return cell_at_zero(negative, precision);',1)
i=t.index('fn endpoint(');t=t[:i]+'''// Tight grid enclosure when a nonzero angle is within one cell of zero.
fn cell_at_zero(negative: bool, precision: i32) -> Result<DyadicInterval, IntervalError> {
    if negative {
        DyadicInterval::new((-1).into(), BigInt::zero(), precision)
    } else {
        DyadicInterval::new(BigInt::zero(), BigInt::one(), precision)
    }
}

'''+t[i:]
t=t.replace('    /// Stored fractions and singleton comparisons follow the budget in [`Self::exp`].','''    /// Stored fractions and singleton comparisons follow the budget in [`Self::exp`].
    /// When stored widths prove that a nonzero magnitude is below one grid
    /// unit, two additional linear units admit its signed cell directly.''')
p.write_text(t)
