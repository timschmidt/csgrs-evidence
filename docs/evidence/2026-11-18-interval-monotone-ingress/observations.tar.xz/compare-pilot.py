from pathlib import Path
import csv,sys,json
s=Path(__file__).parent
for p in sorted(s.glob('life-*-stable-wasm32-wasip1.csv')):
 def rd(f):
  d={}
  for x in csv.reader(f.open()):
   k=tuple(x[:4]);v=list(map(int,[x[5],x[10],x[11]]));d[k]=list(map(max,zip(v,d.get(k,v))))
  return d
 a=rd(s/'life-base-stable-wasm32-wasip1.csv');b=rd(p)
 if len(a)!=108 or len(b)!=108:continue
 rows=[(k,i,b[k][i]-v[i],v[i])for k,v in a.items()for i in range(3)]
 bad=[row for row in rows if row[2]>min([128,64,32][row[1]],int(row[3]*.02))]
 print(p.name,'bad',len(bad),'peaks',[max(q[2]for q in rows if q[1]==i)for i in range(3)],'worst',sorted(bad,key=lambda r:r[2],reverse=True)[:2])
