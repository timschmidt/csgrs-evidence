from pathlib import Path
from collections import Counter
import csv,json,sys,statistics
s=Path(__file__).parent
def read(p):
 rows={}
 for row in csv.reader(p.open()):
  k=','.join(row[:4])+(',ownership' if row[4]=='0' else ',operation')
  values=[int(row[i])for i in (5,10,11)]
  rows[k]=list(map(max,zip(values,rows.get(k,values))))
 return rows
def val(f,a,b,inc,cum):
 step=max(0,b-a);previous=max(0,a-f);charge=previous+step
 cap=min(inc,a*2//100);total=min(cum,f*4//100)
 return [f,a,b,previous,step,charge,cap-step,total-charge]
def dump(n,x):(s/n).write_text(json.dumps(x,indent=1)+'\n')
def file(n):return json.loads((s/n).read_text())
stage=sys.argv[1];summary={};details={}
for version in ['1.88.0','1.95.0','stable']:
 summary[version]={};details[version]={}
 for system in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
  out={};details[version][system]=out;rows=[];violations=[]
  for client in ((['dyadic','angle'] if version=='1.88.0' else ['life','clean','overall','dyadic','angle','tiny']) if stage=='retained' else (['dyadic'] if version=='1.88.0' else ['life','clean','overall','dyadic'])):
   stem=client if stage=='final' else (client if stage in ('base','fixed') else client)
   names=[s/f'{client}-{n}-{version}-{system}.csv'for n in ('fixed','base',stage)]
   if not all(p.exists()for p in names):continue
   fixed,base,current=map(read,names);assert set(fixed)==set(base)==set(current)
   for k,y in current.items():
    if client=='clean' and k.endswith('ownership'):continue
    for i,(metric,inc,cum)in enumerate([('stack',128,256),('peak_heap',64,128),('retained_heap',32,64)]):
     if i==0 and k.endswith('ownership'):continue
     q=val(fixed[k][i],base[k][i],y[i],inc,cum)
     label=f'{client}/{k}/{metric}';out[label]=q;rows.append((i,q))
     if min(q[6:])<0:violations.append([label,q])
  if rows:
   summary[version][system]=dict(metrics=['stack','peak_heap','retained_heap'],rows=len(rows),max_step=[max(q[4]for i,q in rows if i==n)for n in range(3)],max_cumulative=[max(q[5]for i,q in rows if i==n)for n in range(3)],minimum_remainder=[min(q[7]for i,q in rows if i==n)for n in range(3)],failures=violations)
dump(stage+'-memory-details.json',details);dump(stage+'-memory-summary.json',summary)
print('lifetime',[(v,t,d['max_step'],len(d['failures']))for v,rows in summary.items()for t,d in rows.items()])
size={};sd={}
for v in ['1.95.0','stable']:
 f,a,b=[file(n+'-'+v+'.json')for n in ('fixed','base',stage)]
 size[v]={};sd[v]={}
 for t in a:
  out={};sd[v][t]=out
  for n,ys in b[t].items():
   out[n]={}
   for m in ('file','code','functions'):
    f0,x,y=f[t][n][m],a[t][n][m],ys[m];prev=max(0,x-f0);step=max(0,y-x);charge=prev+step
    out[n][m]=[f0,x,y,prev,step,charge,min(4096,x//100)-step,min(8192,f0*2//100)-charge]
   assert 64*2**20-ys['file']>=16*2**20
  size[v][t]=dict(max_step={m:max(x[m][4]for x in out.values())for m in ('file','code','functions')},minimum_free_slot=64*2**20-max(x['file']for x in b[t].values()),min_cumulative={m:min(x[m][7]for x in out.values())for m in ('file','code','functions')})
dump(stage+'-size-summary.json',size);dump(stage+'-size-details.json',sd)
def loadtim(p):
 d={}
 for r in csv.DictReader(p.open()):
  k='/'.join(r[v]for v in ('backend','case','precision'));d.setdefault(k,[]).append((int(r['elapsed_ns']),int(r['completed_images']),int(r['work_units_per_image'])))
 assert all(len(v)==20 for v in d.values());return d
rt={}
for label in [stage,'control','direct']:
 for suite in ('exp_cost','log_cost','atan_cost'):
  cores=sorted(s.glob(f'full-{label}-*-base-{suite}.csv'))
  if len(cores)!=2:continue
  ratios={};work={}
  for p in cores:
   a,b=loadtim(p),loadtim(p.with_name(p.name.replace('-base-','-final-')));assert set(a)==set(b)
   for k in a:
    assert all(x[1]==y[1]for x,y in zip(a[k],b[k]))
    shifts={y[2]-x[2]for x,y in zip(a[k],b[k])};assert len(shifts)==1
    delta=shifts.pop()
    if delta:work[k]=delta
    ratios.setdefault(k,[]).append(statistics.median(y[0]/x[0]for x,y in zip(a[k],b[k])))
  rt[label+'/'+suite]=dict(cases=len(ratios),median_by_core=[statistics.median(x[k]for x in ratios.values())for k in (0,1)],above_3_percent_both={k:v for k,v in ratios.items()if min(v)>1.03},work_changes=work,ratios=ratios)
dump(stage+'-runtime-review.json',rt)
