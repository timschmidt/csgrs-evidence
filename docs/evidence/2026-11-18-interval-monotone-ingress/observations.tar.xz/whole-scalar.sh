set -eu
s=/dev/shm/interval-scalar-replay
. "$s/env"
export CARGO_BUILD_JOBS=1
group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
printf 'memory.max '; cat "$group/memory.max"
printf 'memory.swap.max '; cat "$group/memory.swap.max"
date -u +%s.%N
python3 /dev/shm/interval-monotone-ingress/warm-scalar.py "$1"
date -u +%s.%N
printf 'memory.peak '; cat "$group/memory.peak"
cat "$group/memory.events"
