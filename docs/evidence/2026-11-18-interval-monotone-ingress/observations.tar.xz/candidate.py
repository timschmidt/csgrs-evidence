from pathlib import Path
import sys
s=Path(__file__).parent;p=Path(sys.argv[1])/'crates/hyperinterval/src'
q=p/'rational_admission.rs'
q.write_text(q.read_text()+'''
// Monotone elementary functions consume one endpoint at a time. A later
// endpoint is admitted only if its value is needed by the function domain.
pub(crate) fn monotone_source(
    value: &Rational,
    budget: &mut DyadicBudget,
) -> Result<(num_bigint::BigInt, num_bigint::BigInt), IntervalError> {
    let (_, n, d) = value.ratio_parts();
    budget.reserve(n.bits().max(d.bits()), 2, false)?;
    let width = value.reduction_input_bits();
    if width != 0 {
        budget.reserve(width, 3, true)?;
    }
    Ok(crate::trigonometry::signed_rational_source(value))
}

// Both inputs stay live, so shared storage proves equality. For two small
// fractions, Hyperreal's word products fit in u128; larger reduced fractions
// have unique signed coefficients. Distinct unreduced encodings may require
// cross products. Admit those products before asking Hyperreal for equality.
pub(crate) fn same_monotone_source(
    first: &Rational,
    other: &Rational,
    budget: &mut DyadicBudget,
) -> Result<bool, IntervalError> {
    if first.storage_identity() == other.storage_identity() {
        return Ok(true);
    }
    let (ls, ln, ld) = first.ratio_parts();
    let (rs, rn, rd) = other.ratio_parts();
    if ls != rs {
        return Ok(false);
    }
    let width = ln.bits().max(ld.bits()).max(rn.bits()).max(rd.bits());
    if width > 64 {
        if first.reduction_input_bits() == 0 && other.reduction_input_bits() == 0 {
            budget.reserve(width, 2, false)?;
            return Ok(ln == rn && ld == rd);
        }
        let products = ln.bits().saturating_add(rd.bits()).max(rn.bits().saturating_add(ld.bits()));
        budget.reserve(products, 2, true)?;
    }
    Ok(first == other)
}
''')
for name,first,second in [('exponential','a','b'),('arctangent','a','b'),('logarithm','b','a')]:
 q=p/(name+'.rs');src=q.read_text();index=src.index('impl crate::RationalInterval')
 start=src.index('            budget.reserve(x.numerator()',index);end=src.index('\n        };',start)
 src=src[:start]+'''            let (n, d) = crate::rational_admission::monotone_source(x, budget)?;
            endpoint(&n, &d, 0, precision, budget)'''+src[end:]
 pos=src.index('if a == b {',start);src=src[:pos]+src[pos:].replace('if a == b {',f'if crate::rational_admission::same_monotone_source({first}, {second}, budget)? {{',1)
 q.write_text(src)
