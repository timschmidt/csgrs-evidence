#include <mpfr.h>
#include <stdio.h>
#include <stdlib.h>

typedef int (*operation)(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
static void endpoint(mpfr_ptr out, mpfr_srcptr arg, operation op, int upper, unsigned int scale) {
    mpfr_t lo, hi;
    mpfr_inits2(512, lo, hi, (mpfr_ptr)0);
    op(lo, arg, MPFR_RNDD);
    op(hi, arg, MPFR_RNDU);
    mpfr_mul_2ui(lo, lo, scale, MPFR_RNDD);
    mpfr_mul_2ui(hi, hi, scale, MPFR_RNDU);
    if (upper) { mpfr_ceil(lo, lo); mpfr_ceil(hi, hi); }
    else { mpfr_floor(lo, lo); mpfr_floor(hi, hi); }
    if (!mpfr_equal_p(lo,hi)) abort();
    mpfr_set(out, lo, MPFR_RNDN);
    mpfr_clears(lo, hi, (mpfr_ptr)0);
}
int main(void) {
    operation ops[] = { mpfr_exp, mpfr_log, mpfr_atan };
    mpfr_t x,lo,hi;
    mpfr_inits2(512,x,lo,hi,(mpfr_ptr)0);
    for (long i=2;i<=3;i++) for(int j=0;j<3;j++){
        mpfr_set_si(x,i,MPFR_RNDN);
        endpoint(lo,x,ops[j],0,8);
        endpoint(hi,x,ops[j],1,8);
        mpfr_printf("%ld %d %.0Rf %.0Rf\n",i,j,lo,hi);
    }

    long boundaries[][3]={{1891,5142,1},{177,282,0},{283,320,2},{0,1,1}};
    for(int j=0;j<4;j++){
        if(boundaries[j][0]){
            mpfr_set_si_2exp(x,boundaries[j][0],-8,MPFR_RNDN);
            endpoint(lo,x,ops[boundaries[j][2]],0,8);
        }
        mpfr_set_si_2exp(x,boundaries[j][1],-8,MPFR_RNDN);
        endpoint(hi,x,ops[boundaries[j][2]],1,8);
        if(boundaries[j][0]) mpfr_printf("chain %d %.0Rf %.0Rf\n",j,lo,hi);
        else mpfr_printf("chain %d -infinity %.0Rf\n",j,hi);
    }
    for(long i=-8;i<=-7;i++){
        mpfr_set_si(x,i,MPFR_RNDN);
        endpoint(lo,x,mpfr_exp,0,8); endpoint(hi,x,mpfr_exp,1,8);
        mpfr_printf("negative %ld %.0Rf %.0Rf\n",i,lo,hi);
    }
    mpfr_set_si(x,1,MPFR_RNDN); endpoint(lo,x,mpfr_exp,0,16); endpoint(hi,x,mpfr_exp,1,16);
    mpfr_printf("exp one grid -16 %.0Rf %.0Rf\n",lo,hi);
    mpfr_clears(x,lo,hi,(mpfr_ptr)0);
}
