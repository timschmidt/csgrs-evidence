from pathlib import Path
s=Path(__file__).parent
t=(s/'artifacts.py').read_text().replace("root=s/'src'","root=Path('/mnt/development/csgrs')").replace("'--example','exp_cost','--example','log_cost','--example','atan_cost','--test','exponential','--test','logarithm','--test','arctangent'","'--test','periodic_ingress'").replace('==6','==1')
exec(compile(t,__file__,'exec'))
