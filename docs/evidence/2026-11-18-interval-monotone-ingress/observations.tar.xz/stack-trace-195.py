from pathlib import Path
import subprocess as sp,sys
s=Path(__file__).parent;stage=sys.argv[1]
module=s/('pilot-'+stage)/'clean-target-195/wasm32-wasip1/release/periodic-input-lifetime.wasm';wat=s/(stage+'-195-debug.wat')
sp.run(['wasm-dis','--all-features',module,'-o',wat],check=True)
t=wat.read_text();i=t.index(' (import ');t=t[:i]+' (import "scope" "tick" (func $tick (param i32)))\n'+t[i:]
assert '(global.set $__stack_pointer' in t
t=t.replace('(global.set $__stack_pointer','(call $set_sp')
i=t.rindex(')');t=t[:i]+''' (func $set_sp (param $v i32)
  (global.set $__stack_pointer (local.get $v))
  (call $tick (local.get $v))
 )
'''+t[i:];wat.write_text(t)
binary=s/(stage+'-195-debug.wasm');sp.run(['wasm-as','--all-features','-g',wat,'-o',binary],check=True)
