from pathlib import Path
import csv,json
s=Path(__file__).parent
def read(p):
 out={}
 for r in csv.reader(p.open()):
  key=tuple(r[:4])+('ownership' if r[4]=='0' else 'op',)
  vals=[int(r[i])for i in (5,10,11)]
  out[key]=list(map(max,zip(vals,out.get(key,vals))))
 return out
def review(a,b):
 rows=[(i,k,y[i]-a[k][i],a[k][i]) for k,y in b.items()for i in range(3)]
 bad=[r for r in rows if r[2]>min([128,64,32][r[0]],r[3]*.02)]
 return dict(max_step=[max(r[2]for r in rows if r[0]==i)for i in range(3)],failures=len(bad),worst=sorted(bad,key=lambda r:r[2],reverse=True)[:1])
result={}
for p in sorted(s.glob('clean-pilot-*.csv')):
 base=read(s/'clean-base-stable-wasm32-wasip1.csv');b=read(p)
 if len(b)==216:result[p.stem]=review(base,b)
for p in sorted(s.glob('life-*-stable-wasm32-wasip1.csv')):
 base=read(s/'life-base-stable-wasm32-wasip1.csv');b=read(p)
 if len(b)==108:result[p.stem]=review(base,b)
print(json.dumps(result,indent=1))
