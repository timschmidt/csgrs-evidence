from pathlib import Path
import os,sys,json,subprocess as sp
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent;root=Path('/mnt/development/csgrs')
sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
def lane(v):
 opts=['--all-features'] if v!='1.88.0' else ['--no-default-features','--features','integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace']
 result={}
 for target in ['native','wasm32-wasip1']:
  env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-scalar-replay/lint-'+v}
  platform=[]
  if target!='native':
   platform=['--target',target]
   env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-'+v+'/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
  with (s/'logs'/f'conformance-related-{v}-{target}.log').open('w')as log:
   data=sp.check_output(['cargo','+'+v,'test','--locked','--release','--no-run','-p','hyperinterval','--test','periodic_ingress',*opts,*platform,'--message-format=json-render-diagnostics'],cwd=root,env=env,stderr=log,text=True)
  b,=[Path(r['executable'])for r in map(json.loads,data.splitlines())if r.get('executable')];result[target]=metrics(b)
 (s/f'conformance-related-{v}.json').write_text(json.dumps(result,indent=1)+'\n')
with ThreadPoolExecutor(3)as pool:list(pool.map(lane,['1.88.0','1.95.0','stable']))
