import importlib.util,json
from pathlib import Path
s=Path(__file__).parent
spec=importlib.util.spec_from_file_location('writer',s/'width-record.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.s=s
items=set()
for pattern in ('*.md','base','*-revision','*.txt','*.py','*.rs','*.sh','*.c','*.mjs','*.csv','*.json','logs/*','corpus-*/*','trial-src/*','published-client/tests/*.rs','published-client/tests/support/*'):
 items.update(p for p in s.glob(pattern)if p.is_file())
for folder in ('life','life-clean','overall-client','dyadic-client','angle-client','probe','complete-package-client','scalar-package-client','accepted-package-client','conformance-package-client','tiny-client'):
 for p in (s/folder).rglob('*'):
  if p.is_file() and ('target' not in p.relative_to(s/folder).parts) and (p.suffix in ('.rs','.toml','.lock','.c') or p.name=='Cargo.lock'):items.add(p)
assert not any(p.stat().st_size>12*1024**2 for p in items)
print(json.dumps(m.record('monotone-ingress',items,'Archive monotone rational ingress, exact signed cells and lifecycle comparisons')))
