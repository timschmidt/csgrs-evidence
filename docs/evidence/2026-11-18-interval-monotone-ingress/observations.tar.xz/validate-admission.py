"""Reject mixed revisions, incomplete validations and substituted comparison results."""
import subprocess as sp
from pathlib import Path
import json
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs')
rev=(s/'admitted-revision').read_text().strip()
base=(s/'base').read_text().strip()
names=sp.check_output(['git','diff','--name-only',base,rev],cwd=repo,text=True).splitlines()
assert set(names)=={'crates/hyperinterval/tests/'+f for f in ('periodic_ingress.rs','monotone_ingress.rs','support/rational_coordinate.rs')}
r={'revision':rev,'unchanged_existing_consumer_sha256_count':0,'related_tests':{}}
for v in ('1.88.0','1.95.0','stable'):
    def j(stem):return json.loads((s/(stem+'-'+v+'.json')).read_text())
    if v!='1.88.0':
        assert j('conformance')==j('base')
        r['unchanged_existing_consumer_sha256_count']+=12
        assert 'test result: ok. 3 passed; 0 failed' in (s/'logs'/('conformance-packaged-'+v+'.log')).read_text()
    rel=j('conformance-related');assert rel==j('sameinclude-related');basefile=j('samebase-related')
    r['related_tests'][v]={}
    for target,p in rel.items():
        assert all(basefile[target][k]==p[k] for k in ('code','functions'))
        r['related_tests'][v][target]=p['file']-basefile[target]['file']
    assert all(0<=x<=64 for x in r['related_tests'][v].values())
assert 'Ran 6 tests' in (s/'logs/admitted-inventory.log').read_text()
assert 'OK' in (s/'logs/admitted-inventory.log').read_text()
for n in (9,15):
    assert f'test result: ok. {n} passed; 0 failed;' in (s/'logs/conformance-downstream.log').read_text()
for v in ('stable','nightly'):
    text=(s/'logs'/('conformance-coverage-'+v+'.log')).read_text()
    assert 'Production coverage is below 100%' in text
    assert 'branches: 987/1009' in text if v=='nightly' else 'lines: 4940/4973' in text
print(json.dumps(r,indent=2))
