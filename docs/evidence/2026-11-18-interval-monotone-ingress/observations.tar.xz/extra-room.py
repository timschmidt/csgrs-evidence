from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import csv,subprocess as sp,sys,os,time,json
s=Path(__file__).parent
def client(pair):
 name,v=pair;target=s/(name+'-target-'+v);b=target/'wasm32-wasip1/release/periodic-input-lifetime.wasm'
 rows=s/f'{name}-retained-{v}-wasm32-wasip1.csv'
 end=time.monotonic()+600
 while not rows.is_file():
  assert time.monotonic()<end;time.sleep(2)
 cases=[r[:4]for r in csv.reader(rows.open())if r[4]=='85'];assert cases
 def go(case):
  cmd=['node',s/'room.mjs',b,*case,'false']
  out=sp.run(cmd,env=os.environ|{'NODE_NO_WARNINGS':'1'},stdout=sp.DEVNULL,stderr=sp.PIPE,text=True,check=True)
  vals=[list(map(int,r.split()[1:]))for r in out.stderr.splitlines()if r.startswith('ROOM ')];assert len(vals)==1
  return case+vals[0]
 with ThreadPoolExecutor(2)as pool:d=list(pool.map(go,cases))
 (s/f'retained-room-{name}-{v}.json').write_text(json.dumps(d)+'\n')
with ThreadPoolExecutor(4)as pool:list(pool.map(client,[(n,v)for n in ['dyadic','angle','overall','tiny'] for v in (['1.88.0','1.95.0','stable']if n in ('dyadic','angle')else ['1.95.0','stable'])]))
