"""Observe malformed deserialization before deciding whether the candidate adds masking."""
import json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/explicit-affine-cargo-control-v1')
sys.path.insert(0,str(W))
from affine_cargo_harness_v1 import Harness,N,O,U,compiler,sha,dump,file_state
assert json.loads((N/'affine-cargo-scalar-v1/result-v1.json').read_text())['passed']
active=N/'logs/affine-cargo-downstream-v2-hypercurve-test-52-hypercurve'
assert not (active/'result.json').exists()
process=json.loads((active/'process.json').read_text())
assert b'hypercurve-build--hypercurve-lib-tests' in (Path('/proc')/str(process['pid'])/'cmdline').read_bytes()
h=Harness('malformed-serde-v1')
source=Path('/tmp/affine-malformed-serde-probe-v1.rs');source_hash=sha(source)
original=json.loads((N/'affine-cargo-serialization-v2/result-v1.json').read_text())['libraries']
preserved=json.loads((W/'serialization-input-preservation-v1.json').read_text())['libraries']
build=U/'malformed-serde-probe-build-v1';assert not build.exists();build.mkdir()
dump(h.R/'probe-protocol-v1.json',{
 'driver_sha256':sha(Path(__file__)),'source_sha256':source_hash,
 'libraries':preserved,'dependency_directories':{k:str(Path(v['path']).parent) for k,v in original.items()},
 'purpose':'Determine whether malformed JSON can construct an undefined scalar and whether explicit affine subtraction changes its observable failure. This is a diagnostic, not a claim that malformed values belong to the valid-real input domain.',
 'owning_boundary':'Real deserialization and validation of scalar representation invariants.',
 'properties':['P3','P6','P26'],'runtime_tests_unchanged':True,'production_source_changed':False,
 'concurrent_qualification':{'other_command':active.name,'other_process':process,'maximum_validation_children':2,'one_focused_child_at_a_time':True,'native_workload_gates_and_performance_measurements_not_running':True,'no_timing_claim':True},
})
outputs={}
for variant,library in preserved.items():
 assert sha(source)==source_hash and sha(library['copy'])==library['sha256']==original[variant]['sha256']
 program=build/variant
 h.execute(variant+'-compile',[
  compiler['additional_environment']['RUSTC'],'--crate-name','malformed_serde_probe',
  '--edition=2024','-C','opt-level=3','-D','warnings',source,
  '--extern','hyperreal='+library['copy'],'-L','dependency='+str(Path(original[variant]['path']).parent),
  '-o',program,
 ],limit=60)
 frozen=h.A/variant;digest=sha(program);shutil.copy2(program,frozen);assert sha(frozen)==digest
 h.states[str(frozen)]=file_state(frozen)
 h.artifacts[variant]={'copy':str(frozen),'compiled_path':str(program),'sha256':digest,'bytes':frozen.stat().st_size,'features':original[variant]['features'],'target':{'name':'malformed_serde_probe','kind':['bin']},'profile':{'test':False},'direct_probe_build':True,'cargo_fresh':False}
 dump(h.A/'executables-v1.json',h.artifacts)
 out,err,_=h.execute(variant+'-observe',[frozen],binary=True,limit=60)
 assert sha(frozen)==digest and sha(source)==source_hash
 lines=out.splitlines();assert len(lines)==4
 outputs[variant]={'stdout':out,'stderr':err}
h.verify()
dump(h.R/'result-v1.json',{'diagnostic_completed':True,'outputs':outputs,'commands':h.commands,'admission_decision_pending':True,'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False})
print(json.dumps(outputs),flush=True)
