"""Validate actual main without scalar overlays after exact candidate integration."""
import json,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/explicit-affine-cargo-control-v1')
sys.path.insert(0,str(W))
from affine_main_harness_v1 import Harness,N,O,U,cargo,rustfmt,sha,dump,rows
integration=json.loads((W/'main-source-integration-v1.json').read_text())
assert all(sha(O/p)==v['after_sha256'] for p,v in integration['changes'].items())
expected=json.loads((N/'sign-cache-publication-main-v3/result-v1.json').read_text())['packages']
for label in ['hyperreal-default','hyperreal-all']:expected[label]['parent_test_passed']+=6
h=Harness('main-v1')
protocol=json.loads((h.R/'protocol-v1.json').read_text())
assert protocol['source_overlays']=={} and protocol['scalar_source_overlays_used'] is False
summaries={};parents={};packages={};native_gates={}
gate_names=[
 'zz_complex_project_performance_tests::gerber_package_completes_smoke_check_suite',
 'zz_complex_project_performance_tests::kicad_board_completes_smoke_check_suite',
 'zz_complex_project_performance_tests::min_copper_neck_width_completes_on_copper_layers',
]
def gate_completed(out,gate):
 found=list(re.finditer(r'^test '+re.escape(gate)+r' \.\.\. ',out,re.M))
 assert len(found)==1,(gate,len(found))
 match=found[0];following=re.search(r'^test ',out[match.end():],re.M)
 end=match.end()+following.start() if following else len(out)
 last_line=out[match.start():end].strip().splitlines()[-1]
 assert last_line=='ok' or last_line=='test '+gate+' ... ok',(gate,last_line)
dump(h.R/'driver-protocol-v1.json',{
 'driver_sha256':sha(Path(__file__)),'source_integration_sha256':sha(W/'main-source-integration-v1.json'),
 'source_pins_sha256':sha(W/'main-source-pins-v2.json.gz'),
 'actual_main_without_scalar_overlays':True,'expected_packages':expected,
 'original_test_bodies_fixtures_policies_and_ignores_preserved':True,
 'native_gate_names':gate_names,'native_limits':{'kicad_worker_cpu_seconds':120,'gerber_wall_seconds':120,'copper_check_wall_seconds':60},
})
def progress():
 dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages,'native_gates':native_gates})
def run_package(package,flags,label):
 print('MAIN_PACKAGE_START '+label,flush=True)
 keys=h.build(label+'-build',['test','--release','--locked','-p',package,'--tests']+flags)
 h.bind_programs(keys);dump(h.R/(label+'-runtime-bindings-v1.json'),h.runtime_bindings)
 for ordinal,key in enumerate(keys):
  artifact=h.artifacts[key]
  if not artifact['profile']['test']:continue
  name=label+'-test-'+str(ordinal)+'-'+artifact['target']['name']
  result,out,err,_=h.test(name,key)
  assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
  assert 'skipping complex project fixture' not in out+err
  summaries[name]=result;parents[name]=result[-1]
  if package=='hyperdrc' and artifact['target']['kind']==['lib']:
   for gate in gate_names:
    gate_completed(out,gate);native_gates[gate]={'passed':True,'command':name}
  progress()
 out,_,_=h.execute(label+'-doctests',[cargo,'test','--release','--locked','-p',package,'--doc']+flags+['--','--test-threads=1'])
 result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
 summaries[label+'-doctests']=result
 packages[label]={
  'test_binaries':sum(h.artifacts[k]['profile']['test'] for k in keys),
  'parent_test_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith(label+'-test-')),
  'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith(label+'-test-')),
  'doctests_passed':sum(int(r[1]) for r in result),
 }
 assert packages[label]==expected[label],(label,packages[label],expected[label])
 progress();print('MAIN_PACKAGE_PASSED '+json.dumps({label:packages[label]}),flush=True)
for label,flags in [('hyperreal-default',[]),('hyperreal-all',['--all-features'])]:
 run_package('hyperreal',flags,label)
keys=h.build('hyperreal-debug',['test','--locked','-p','hyperreal','--lib'])
assert len(keys)==1
result,_,_,_=h.test('hyperreal-debug-library',keys[0])
assert result==[('ok','823','0','0','0','0')]
summaries['hyperreal-debug-library']=result;progress()
for package,flags in [
 ('hyperdrc',[]),('hyperlimit',['--all-features']),('hypercurve',['--all-features']),
 ('hypermesh',['--all-features']),('csgrs',[]),('hypercircuit',['--all-features']),
]:run_package(package,flags,package)
assert len(native_gates)==3
for package in ['hyperreal','hyperdrc','hyperlimit','hypercurve','hypermesh','csgrs','hypercircuit']:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
h.execute('hyperreal-default-clippy',[cargo,'clippy','--release','--locked','-p','hyperreal','--all-targets','--','-D','warnings'])
h.execute('workspace-fmt',[cargo,'fmt','--all','--','--check'])
h.execute('included-fmt',[rustfmt,'--edition','2024','--check','--config-path',O/'crates/.rustfmt.toml','--config','max_width=100,skip_children=true',O/'crates/hyperreal/src/real/explicit_affine_tests.rs',O/'crates/hyperreal/src/real/mod.rs'],limit=60)
h.verify()
dump(h.R/'result-v1.json',{
 'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,
 'native_gates':native_gates,'commands':h.commands,'artifacts':h.artifacts,
 'source_integration_sha256':sha(W/'main-source-integration-v1.json'),
 'source_pins_sha256':sha(W/'main-source-pins-v2.json.gz'),
 'actual_main_without_scalar_overlays':True,'original_native_workload_limits_unchanged':True,
 'hypervoxel_excluded':True,'runtime_admission_record_pending':True,'full_plan_complete':False,
})
print(json.dumps({'actual_main_passed':True,'packages':packages,'native_gates_passed':3}),flush=True)
