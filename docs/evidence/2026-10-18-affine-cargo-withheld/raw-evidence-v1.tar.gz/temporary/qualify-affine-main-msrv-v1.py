"""Recheck actual scalar and immediate-consumer source at Rust 1.95."""
import ast,json,os,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
O=N.parent/'csgrs';W=N/'explicit-affine-cargo-control-v1'
assert json.loads((N/'affine-cargo-main-v1/result-v1.json').read_text())['passed']
source=W/'affine_main_harness_v1.py';helper=W/'affine_main_msrv_harness_v1.py'
assert not helper.exists()
text=source.read_text()
old="self.target=U/'target'";new="self.target=U/'target-msrv-v1'"
assert text.count(old)==1
text=text.replace(old,new);ast.parse(text);helper.write_text(text)
sys.path.insert(0,str(W))
from affine_main_msrv_harness_v1 import Harness,sha,dump
h=Harness('main-msrv-v1')
assert h.target.is_dir()
tools=json.loads((O/'docs/evidence/2026-10-17-in-scope-msrv/review-v1.json').read_text())['tool_sha256']
assert all(sha(p)==v for p,v in tools.items())
root=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
os.environ.update(RUSTC=str(root/'rustc'),RUSTDOC=str(root/'rustdoc'),RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
dump(h.R/'compiler-v1.json',{
 'driver_sha256':sha(Path(__file__)),'compiler':'1.95.0','tools_sha256':tools,
 'environment':{k:os.environ[k] for k in ['RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN']},
 'runtime_tests_rerun':False,'clippy_on_msrv_run':False,
 'derived_harness':{'original_sha256':sha(source),'derived_sha256':sha(helper),'only_substitution':[old,new]},
 'target':str(h.target),'reuses_open_msrv_target':True,
 'actual_main_without_scalar_overlays':True,
})
for label,flags in [('all',['--all-features']),('minimal',['--no-default-features'])]:
 h.execute(label,[root/'cargo','check','--locked','-p','hyperreal','-p','hyperlimit','-p','hypercurve','--all-targets']+flags)
 print('MAIN_MSRV_PASSED '+label,flush=True)
h.verify()
assert all(sha(p)==v for p,v in tools.items())
dump(h.R/'result-v1.json',{
 'passed':True,'commands':h.commands,'compiler':'1.95.0','all_targets':True,
 'features':['all','no-default'],'tools_sha256':tools,'runtime_tests_rerun':False,
 'clippy_on_msrv_run':False,'actual_main_without_scalar_overlays':True,
 'source_integration_sha256':sha(W/'main-source-integration-v1.json'),
 'runtime_admission_record_pending':True,'full_plan_complete':False,
})
