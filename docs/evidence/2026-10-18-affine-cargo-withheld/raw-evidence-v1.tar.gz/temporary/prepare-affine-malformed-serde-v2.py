"""Keep the failed launch and give rustc conventionally named frozen inputs."""
import ast
from pathlib import Path
source=Path('/tmp/probe-affine-malformed-serde-v1.py')
dest=Path('/tmp/probe-affine-malformed-serde-v2.py')
assert not dest.exists()
text=source.read_text()
assert text.count("Harness('malformed-serde-v1')")==1
text=text.replace("Harness('malformed-serde-v1')","Harness('malformed-serde-v2')")
assert text.count("malformed-serde-probe-build-v1")==1
text=text.replace("malformed-serde-probe-build-v1","malformed-serde-probe-build-v2")
anchor="dump(h.R/'probe-protocol-v1.json',{\n"
assert text.count(anchor)==1
text=text.replace(anchor,"""frozen_inputs={}
for variant,library in preserved.items():
 original_copy=Path(library['copy']);assert sha(original_copy)==library['sha256']
 folder=h.A/'library-inputs'/variant;folder.mkdir(parents=True)
 copy=folder/Path(library['original_path']).name
 shutil.copy2(original_copy,copy);assert sha(copy)==sha(original_copy)==library['sha256']
 frozen_inputs[variant]=dict(library,copy=str(copy),prior_frozen_copy=str(original_copy))
preserved=frozen_inputs
dump(h.R/'probe-setup-correction-v1.json',{
 'prior_helper_sha256':sha('/tmp/probe-affine-malformed-serde-v1.py'),
 'prior_failed_command_sha256':sha(N/'logs/affine-cargo-malformed-serde-v1-baseline-compile/result.json'),
 'cause':'rustc requires an extern rlib basename starting with lib; the independently preserved baseline-lib name was rejected before linking or execution.',
 'correction':'Copy identical bytes into per-variant subdirectories with the original libhyperreal basename. Keep both original frozen copies and the failed launch.',
 'runtime_probe_source_unchanged':True,'prior_runtime_execution':False,
})
"""+anchor)
ast.parse(text);dest.write_text(text)
print(dest)
