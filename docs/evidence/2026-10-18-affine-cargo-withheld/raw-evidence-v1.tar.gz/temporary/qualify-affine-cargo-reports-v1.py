"""Compare complete native reports with the qualified current-main CLI."""
import decimal,gzip,json,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/explicit-affine-cargo-control-v1')
sys.path.insert(0,str(W))
from affine_cargo_harness_v1 import Harness,N,O,U,sha,dump
assert json.loads((W/'malformed-serde-review-v1.json').read_text())['new_failure_masking'] is False
assert json.loads((N/'affine-cargo-downstream-v2/result-v1.json').read_text())['passed']
h=Harness('reports-v1')
baseline_manifest=Path('/tmp/csgrs-sign-cache-validation-20261018-v1/main-v3-artifacts/executables-v1.json')
candidate_manifest=U/'frozen/downstream-v2/executables-v1.json'
def cli(manifest):
 items=json.loads(manifest.read_text())
 found=[v for k,v in items.items() if k.startswith('hyperdrc-build--') and v['target']['kind']==['bin'] and not v['profile']['test']]
 assert len(found)==1
 return found[0]
artifacts={'baseline':cli(baseline_manifest),'candidate':cli(candidate_manifest)}
assert artifacts['baseline']['features']==artifacts['candidate']['features']
old_pins=N/'sign-cache-publication-control-v1/main-source-pins-v3.json.gz'
new_pins=W/'main-source-pins-v1.json.gz'
assert json.loads(gzip.decompress(old_pins.read_bytes()))==json.loads(gzip.decompress(new_pins.read_bytes()))
F=N/'native-aggregation-fixtures-v1'
fixtures=json.loads((F/'verification-v1.json').read_text())['fixtures']
checks=['layer-sanity','board-outline-sanity','min-copper-neck','drill-spacing']
cases=[]
for label in ['cparti','hvp109a']:
 args=['--kicad-pcb',fixtures[label]['path']]
 for check in checks:args+=['--check',check]
 cases.append((label,args+['--min-width','0.0762','--format','json','--allow-findings'],checks))
cases.append(('gerber-outline',['--gerber-dir',str(F/'gerber-outline-smoke'),'--check','layer-sanity','--min-width','0.0762','--format','json','--allow-findings'],['layer-sanity']))
def verify():
 h.verify()
 assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
 assert all(sha(v['path'])==v['sha256'] for v in fixtures.values())
verify()
dump(h.R/'report-protocol-v1.json',{
 'helper_sha256':sha(Path(__file__)),
 'baseline_manifest_sha256':sha(baseline_manifest),
 'candidate_manifest_sha256':sha(candidate_manifest),
 'baseline_qualification_sha256':sha(N/'sign-cache-publication-main-v3/result-v1.json'),
 'baseline_admission_checkpoint_sha256':sha(O/'docs/evidence/2026-10-18-sign-cache-publication/checkpoint-v1.json'),
 'common_original_main_source_pins_sha256':sha(new_pins),
 'candidate_source_preparation_sha256':sha(W/'preparation-v2.json'),
 'fixtures':fixtures,'binaries':artifacts,'cases':cases,
 'order':['baseline','candidate','candidate','baseline'],'common_cwd':str(F),
 'normalization':False,'independent_geometry_oracle':False,'performance_claim':False,
 'time_tool_sha256':sha('/usr/bin/time'),
 'contract':'Preserve complete native report bytes, parsed values, coverage and version for the original full-resolution fixtures; record both AB and BA repeats, with 1800 seconds and the unchanged resource limits per process.',
})
def unique(pairs):
 result={}
 for k,v in pairs:assert k not in result;result[k]=v
 return result
def reject(value):raise ValueError(value)
reports={}
for label,args,expected in cases:
 raw=[];parsed=[];observations=[]
 for ordinal,mode in enumerate(['baseline','candidate','candidate','baseline']):
  verify();command=label+'-'+str(ordinal)+'-'+mode
  name='affine-cargo-'+h.phase+'-'+command
  scratch=U/'scratch'/name
  _,_,_=h.execute(command,['/usr/bin/env','-C',F,'/usr/bin/time','-v','-o',scratch/'process-usage.txt',artifacts[mode]['copy'],*args],binary=True)
  p=N/'logs'/name/'stdout';data=p.read_bytes()
  report=json.loads(data,parse_float=decimal.Decimal,parse_constant=reject,object_pairs_hook=unique)
  assert report['inputs'] and len(report['violations'])==report['violation_count']
  coverage=report['coverage']['checks']
  assert [r['check'] for r in coverage]==expected
  assert all(r['status'] in ['passed','failed','not_applicable','uncertain','skipped'] for r in coverage)
  assert all(r['check_version']==22 for r in coverage)
  raw.append(data);parsed.append(report)
  observations.append({'mode':mode,'stdout_sha256':sha(p),'bytes':len(data),'violation_count':report['violation_count'],'coverage':coverage,'full_report_materialized':True,'process_usage_path':str(scratch/'process-usage.txt'),'process_usage_sha256':sha(scratch/'process-usage.txt')})
  dump(h.R/'reports-progress-v1.json',{'commands':h.commands,'case':label,'observations':observations})
  verify()
  print('REPORT_COMPLETED '+label+' '+mode+' '+str(ordinal),flush=True)
 reports[label]={'observations':observations,'all_bytes_equal':all(r==raw[0] for r in raw),'all_parsed_reports_equal':all(r==parsed[0] for r in parsed),'baseline_repeat_equal':raw[0]==raw[3],'candidate_repeat_equal':raw[1]==raw[2]}
 dump(h.R/(label+'-comparison-v1.json'),reports[label])
verify()
result={'complete_for_declared_scope':True,'commands':h.commands,'cases':reports,'all_report_bytes_equal':all(r['all_bytes_equal'] for r in reports.values()),'all_parsed_reports_equal':all(r['all_parsed_reports_equal'] for r in reports.values()),'performance_claim':False,'independent_geometry_oracle':False,'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False}
dump(h.R/'result-v1.json',result)
print(json.dumps({'all_report_bytes_equal':result['all_report_bytes_equal'],'all_parsed_reports_equal':result['all_parsed_reports_equal']}),flush=True)
assert result['all_report_bytes_equal'] and result['all_parsed_reports_equal']
