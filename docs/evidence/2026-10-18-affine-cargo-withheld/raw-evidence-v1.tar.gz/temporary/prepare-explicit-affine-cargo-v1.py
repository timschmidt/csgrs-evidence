"""Prepare a fresh Cargo qualification target and an explicit storage-only migration."""
import ast,gzip,hashlib,json,os,re,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
P=N/'sign-cache-publication-control-v1'
OLD=N/'explicit-affine-control-v1'
W=N/'explicit-affine-cargo-control-v1'
U=Path('/tmp/csgrs-explicit-affine-cargo-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
BASE='0179a1b68621d48e1b5087d64d64493e0c3819c5'
sys.path.insert(0,str(P))
from validation_runner_v4_local import resources,reasons,sha
def dump(p,v):
    assert not Path(p).exists(),p
    Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=O).decode().strip()==BASE
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
assert not W.exists() and not U.exists()
assert not reasons(resources())
E=O/'docs/evidence/2026-10-18-explicit-affine-subtraction'
checkpoint=json.loads((E/'checkpoint-v1.json').read_text())
assert all(sha(O/p)==h for p,h in checkpoint['evidence_files_sha256'].items())
physical=json.loads(gzip.decompress((E/'artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
assert len(physical)==596 and all(sha(p)==h for p,h in physical.items())
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
assert all(sha(O/p)==h for p,h in pins.items())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
W.mkdir();U.mkdir()
for name in ['target','cargo-home','gmp-cache','xdg-cache','scratch','frozen']:
    (U/name).mkdir()
for name in ['index','cache','src']:(U/'cargo-home/registry'/name).mkdir(parents=True,exist_ok=True)
(U/'cargo-home/config.toml').write_text('[net]\noffline = true\n[cache]\nauto-clean-frequency = "never"\n')
old_contract=json.loads((P/'tmp-contract-v3.json').read_text())
assert old_contract['initial_free_bytes']==67482746880 and old_contract['net_consumption_limit_bytes']==12*1024**3
contract={
    'path':str(U),'initial_free_bytes':old_contract['initial_free_bytes'],
    'old_net_consumption_limit_bytes':old_contract['net_consumption_limit_bytes'],
    'net_consumption_limit_bytes':24*1024**3,
    'minimum_post_allowance_free_bytes':old_contract['initial_free_bytes']-24*1024**3,
    'storage_baseline_reset':False,
    'previous_contract':str(P/'tmp-contract-v3.json'),'previous_contract_sha256':sha(P/'tmp-contract-v3.json'),
    'authorization':'User authorized /tmp validation. The earlier 12 GiB cap was agent-selected; this changes retained build-artifact storage only.',
    'reason':'Preserve all closed targets while creating a fresh complete Cargo target, frozen executable copies and subsequent main-source qualification artifacts.',
    'unchanged_limits':{'root_gib':16,'disk_b_gib':72,'log_mib':96,'child_address_space_gib':8,'jobs':2,'full_suite_or_compile_seconds':1800,'focused_seconds':60,'reserve_mib':512},
    'physical_capacity_precheck':resources(),'temporary_artifacts_volatile':True,
}
dump(W/'tmp-contract-v1.json',contract)
(W/'storage-migration-v1.md').write_text("""# Temporary validation-artifact storage migration

The user already authorized /tmp validation. Its previous 12 GiB retained
artifact cap was an agent-selected containment setting. Raise that allowance
explicitly to 24 GiB against the original 67,482,746,880-byte free-space
baseline; the new floor is 41,712,943,104 bytes. Do not reset the counter.

The fresh Cargo target, immutable executable copies, native cache copy and
later actual-main qualification must fit this allowance. Existing closed
targets and evidence remain untouched. Current physical capacity and host
memory are checked before and throughout execution.

Disk B remains capped at the user's approved 72 GiB. Root consumption remains
16 GiB and cumulative logs 96 MiB. Workloads, resolutions, policies, original
CPU/wall gates, 1800-second compile/suite limits, 60-second focused limits,
8-GiB per-child address space, two jobs, cancellation and reserves are unchanged.
This is a storage-only migration and provides no correctness, completion or
speedup evidence.
""")
runner=r'''"""Use the original baselines with an explicit 24-GiB temporary-artifact cap."""
import json,sys
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'sign-cache-publication-control-v1'))
import validation_runner_v4_local as inherited
import validation_runner_v3 as base
contract=json.loads((W/'tmp-contract-v1.json').read_text())
assert contract['initial_free_bytes']==67482746880 and contract['storage_baseline_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
    result=[r for r in previous_reasons(sample) if r!='tmp_net_consumption_12_gib']
    if contract['initial_free_bytes']-sample['tmp_free_bytes']>contract['net_consumption_limit_bytes']:
        result.append('tmp_net_consumption_24_gib')
    return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
'''
ast.parse(runner);(W/'validation_runner_v1.py').write_text(runner)
registry={}
for name in ['index','cache','src']:
    root=V/'cargo-home-v1/registry'/name
    assert root.is_dir()
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(),p
        if p.is_file():registry[str(p)]=sha(p)
(W/'registry-inputs-v1.json.gz').write_bytes(gzip.compress((json.dumps(registry,sort_keys=True)+'\n').encode(),mtime=0))
gmp={}
for p in sorted((V/'gmp-cache-v1').rglob('*')):
    assert not p.is_symlink(),p
    dest=U/'gmp-cache'/p.relative_to(V/'gmp-cache-v1')
    if p.is_dir():dest.mkdir(exist_ok=True)
    elif p.is_file():
        h=sha(p);shutil.copy2(p,dest);assert sha(dest)==sha(p)==h
        gmp[str(p)]={'copied_path':str(dest),'sha256':h}
dump(W/'native-cache-copy-v1.json',gmp)
shutil.copytree(O/'crates/hyperreal/src/real',W/'real')
rustfmt=Path(compiler['additional_environment']['RUSTC']).with_name('rustfmt')
def formatted(text):
    result=subprocess.run([str(rustfmt),'--edition','2024','--config-path',str(O/'crates/.rustfmt.toml'),'--config','max_width=100','--emit','stdout'],input=text,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,cwd=O)
    assert not result.stderr,result.stderr
    return result.stdout
tests=(OLD/'explicit_affine_tests_v1.rs').read_text()
test_formatted=formatted(tests)
def formatting_tokens(text):
    return re.sub(r',(?=[)\]])','', ''.join(text.split()))
assert formatting_tokens(tests)==formatting_tokens(test_formatted)
(W/'real/explicit_affine_tests.rs').write_text(test_formatted)
module=(O/'crates/hyperreal/src/real/mod.rs').read_text()
needle='#[cfg(test)]\nmod immediate_equality_tests;'
assert module.count(needle)==1
module=module.replace(needle,'#[cfg(test)]\nmod explicit_affine_tests;\n\n'+needle)
(W/'real/mod.rs').write_text(module)
shutil.copy2(OLD/'add_sub_explicit_v1.rs',W/'real/arithmetic/add_sub.rs')
algebra=(OLD/'algebra_explicit_v1.rs').read_text()
start=algebra.index('    // Prove only cancellation of the symbolic terms.')
end=algebra.index('    /// Add some other number to this number.',start)
block=algebra[start:end]
fmt=formatted('impl Computable {\n'+block+'}\n')
assert fmt.startswith('impl Computable {\n') and fmt.endswith('}\n')
body=fmt[len('impl Computable {\n'):-2]+'\n'
assert formatting_tokens(body)==formatting_tokens(block)
(W/'algebra_explicit_v2.rs').write_text(algebra[:start]+body+algebra[end:])
overlay_pins={str(p):sha(p) for p in (W/'real').rglob('*') if p.is_file()}
overlay_pins[str(W/'algebra_explicit_v2.rs')]=sha(W/'algebra_explicit_v2.rs')
changes={}
for p in sorted((W/'real').rglob('*')):
    if not p.is_file():continue
    rel='crates/hyperreal/src/real/'+str(p.relative_to(W/'real'))
    if not (O/rel).exists() or sha(O/rel)!=sha(p):changes[rel]={'candidate':str(p),'sha256':sha(p)}
changes['crates/hyperreal/src/computable/node/algebra.rs']={'candidate':str(W/'algebra_explicit_v2.rs'),'sha256':sha(W/'algebra_explicit_v2.rs')}
assert set(changes)=={'crates/hyperreal/src/real/mod.rs','crates/hyperreal/src/real/arithmetic/add_sub.rs','crates/hyperreal/src/real/explicit_affine_tests.rs','crates/hyperreal/src/computable/node/algebra.rs'}
(W/'main-source-pins-v1.json.gz').write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'contract-v1.md').write_text("""# Explicit affine subtraction Cargo qualification

Parent: 0179a1b68621d48e1b5087d64d64493e0c3819c5.
Continue E76's exact affine subtraction domain at Hyperreal, under P1-P5,
P7-P9, P17-P20 and P35-P39. The baseline failures, six new assertions, all
original tests and both rejected constructor prototypes remain preserved.

The candidate has two production-file differences. New tests use a normal
module. Pinned rustfmt changes only whitespace and trailing separators in the new
helper/test text.
Verify the complete overlaid real module tree and all unchanged main inputs.
The production worktree remains unchanged during isolated qualification.

Use a new empty Cargo target and private writable Cargo bookkeeping. Bind
the retained registry index, archives and source directories read-only.
Copy the small native GMP cache independently; keep all previous targets
read-only. Disable automatic Cargo cache cleanup and use offline locked builds.
Record Cargo freshness, features and copied executable hashes. Freeze executed
binaries before later feature builds can replace an unversioned output.

Run scalar default/all-feature/debug tests, docs and strict Clippy. Qualify
Hyperlimit, Hypercurve, Hypermesh, CSGRS, HyperDRC and Hypercircuit through
their original complete target suites and original full native CPU/wall gates.
Keep all original fixture geometry, test bodies, policies and ignore markers.
Run compiler-floor checks and full report replay with the qualified baseline.
Review JSON/CBOR reader compatibility and explicit rational-carrier migration;
this is a representation improvement, not merely a performance-only claim.

Only after acceptance may the exact candidate be applied to main. Then verify
the actual source without overlays and rerun affected local/downstream checks.
An evidence update is not implementation admission. Distribution and the full
properties plan stay open until separately proved. Hypervoxel remains excluded.

Use the explicit temporary-artifact storage migration in storage-migration-v1.md.
Every original workload, time, memory, job, root, Disk B and log limit remains.
Scratch data goes in the new temporary root. No push or publication is planned.
""")
assert all(sha(O/p)==h for p,h in pins.items())
dump(W/'preparation-v1.json',{'parent_revision':BASE,'helper_sha256':sha(Path(__file__)),'previous_checkpoint_sha256':sha(E/'checkpoint-v1.json'),'previous_closed_physical_files_verified':len(physical),'registry_inputs_sha256':sha(W/'registry-inputs-v1.json.gz'),'registry_file_count':len(registry),'native_cache_copy_sha256':sha(W/'native-cache-copy-v1.json'),'main_source_pins_sha256':sha(W/'main-source-pins-v1.json.gz'),'overlay_sha256':overlay_pins,'changes':changes,'format_tool_sha256':sha(rustfmt),'formatter_changes_limited_to_whitespace_and_trailing_commas':True,'storage_contract_sha256':sha(W/'tmp-contract-v1.json'),'compiler_protocol_sha256':sha(V/'cargo-preparation-protocol-v1.json'),'production_source_changed':False,'target_initially_empty':True,'resources':resources()})
print(json.dumps({'prepared':True,'changes':list(changes),'registry_files':len(registry),'tmp_allowance_gib':24,'disk_b_allowance_gib':72,'production_source_changed':False}),flush=True)
