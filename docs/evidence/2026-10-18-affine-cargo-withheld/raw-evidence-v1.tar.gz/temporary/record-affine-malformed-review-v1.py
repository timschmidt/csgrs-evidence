"""Record a decisive failure-visibility blocker without modifying production."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'explicit-affine-cargo-control-v1'
sys.path.insert(0,str(W))
from validation_runner_v1 import sha,dump,resources,reasons
path=N/'affine-cargo-malformed-serde-v2/result-v1.json'
result=json.loads(path.read_text())
assert result['diagnostic_completed']
before=result['outputs']['baseline']['stdout']
after=result['outputs']['candidate']['stdout']
assert 'negative-square-root/affine-difference\tpanic\n' in before
assert 'negative-square-root/affine-difference\tdecoded;exact=Some(Rational { sign: Minus, numerator: 1, denominator: 1 });interval=Some([Rational { sign: Minus, numerator: 1, denominator: 1 }, Rational { sign: Minus, numerator: 1, denominator: 1 }])\n' in after
for text in [before,after]:
 assert 'missing-irrational-payload/decode-and-refine\tpanic\n' in text
 assert 'missing-irrational-payload/affine-difference\tpanic\n' in text
assert not reasons(resources())
review={
 'diagnostic_sha256':sha(path),'new_failure_masking':True,
 'decision':'Withhold the explicit affine subtraction candidate. Passing valid-input suites do not override the newly reproduced invalid-input failure masking.',
 'source_revision':'0179a1b68621d48e1b5087d64d64493e0c3819c5',
 'owners':{'invalid_representation_ingress':'Hyperreal Real deserialization','candidate_proof':'Hyperreal explicit affine subtraction'},
 'properties':['P3','P6','P19','P26','P35','P39'],
 'independent_oracle':'No real number has square -1; malformed serialized sqrt(-1) cannot be certified as a real-valued operand. An Irrational class without its required payload is structurally invalid.',
 'baseline_observation':'JSON-to-refinement and JSON-to-affine-subtraction pipelines panic for both malformed inputs.',
 'candidate_observation':'The negative-square-root affine-subtraction pipeline instead returns exact rational -1 with a singleton certified interval. The missing-payload pipelines still panic.',
 'valid_domain_corpus_results_retained':True,
 'required_acceptance':'Malformed JSON and CBOR must be rejected as typed failures at their owning boundary before a scalar can enter a downstream pipeline. Preserve valid representation round trips, the complete existing corpus, and explicit uncertainty/resource contracts. Reproduce and validate the repaired boundary before revisiting affine admission.',
 'remaining_prepared_report_msrv_and_main_integration_work_withheld':True,
 'candidate_admitted':False,'production_source_changed':False,
 'runtime_admitted':False,'performance_speedup_claimed':False,
 'hypervoxel_excluded':True,'full_plan_complete':False,
}
destination=W/'malformed-serde-review-v1.json'
assert not destination.exists();dump(destination,review)
print(json.dumps({'new_failure_masking':True,'candidate_admitted':False,'production_source_changed':False}),flush=True)
