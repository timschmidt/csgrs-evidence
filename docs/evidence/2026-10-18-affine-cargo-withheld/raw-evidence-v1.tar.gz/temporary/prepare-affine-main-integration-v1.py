"""Apply the fully qualified candidate and prepare actual-source validation."""
import ast,difflib,gzip,hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'explicit-affine-cargo-control-v1'
sys.path.insert(0,str(W))
from validation_runner_v1 import resources,reasons
BASE='0179a1b68621d48e1b5087d64d64493e0c3819c5'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(GIT+list(args),cwd=O)
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,value):
 assert not p.exists(),p
 p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','HEAD','--name-only') and not git('diff','--cached','--name-only')
assert not reasons(resources())
preservation=read(W/'serialization-input-preservation-v1.json')
assert all(sha(v['copy'])==v['sha256'] for v in preservation['libraries'].values())
boundary_review=read(W/'malformed-serde-review-v1.json')
assert boundary_review['diagnostic_sha256']==sha(N/'affine-cargo-malformed-serde-v2/result-v1.json')
assert boundary_review['new_failure_masking'] is False
results={name:N/path for name,path in {
 'scalar':'affine-cargo-scalar-v1/result-v1.json',
 'downstream':'affine-cargo-downstream-v2/result-v1.json',
 'serialization':'affine-cargo-serialization-v2/result-v1.json',
 'msrv':'affine-cargo-msrv-v1/result-v1.json',
 'reports':'affine-cargo-reports-v1/result-v1.json',
}.items()}
for name,path in results.items():
 result=read(path)
 if name=='reports':assert result['all_report_bytes_equal'] and result['all_parsed_reports_equal']
 else:assert result['passed']
pins=json.loads(gzip.decompress((W/'main-source-pins-v1.json.gz').read_bytes()))
assert len(pins)==2654 and all(sha(O/p)==v for p,v in pins.items())
assert sha(O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py')=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
preparation=read(W/'preparation-v2.json')
assert all(sha(p)==v for p,v in preparation['overlay_sha256'].items())
changes={
 'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_explicit_v2.rs',
 'crates/hyperreal/src/real/arithmetic/add_sub.rs':W/'real/arithmetic/add_sub.rs',
 'crates/hyperreal/src/real/mod.rs':W/'real/mod.rs',
 'crates/hyperreal/src/real/explicit_affine_tests.rs':W/'real/explicit_affine_tests.rs',
}
for p in changes:
 if p not in pins:assert not (O/p).exists(),p
readme_path='crates/hyperreal/README.md'
assert readme_path in pins
readme=(O/readme_path).read_text()
anchor='Long `Real` iterator sums are combined through a streaming balanced tree once\n'
assert readme.count(anchor)==1
readme=readme.replace(anchor,'''Explicit subtraction keeps recognized affine cancellations in the rational
carrier. For example, `(sin(7) + 100) - (sin(7) + 101)` exposes exact rational
`-1` immediately. The shared affine recognizer proves that the symbolic terms
match before subtracting their rational offsets. Its conservative traversal
and scale limits leave unmatched forms in the existing computable fallback.
Ordinary additions preserve their shared operands and approximation caches.

'''+anchor)
anchor='Serialization records expression structure, not transient caches or abort\nsignals.\n'
assert readme.count(anchor)==1
readme=readme.replace(anchor,anchor+'''
The unreleased affine-subtraction change can produce the existing rational
`One` carrier where an earlier version retained an equivalent computable tree.
The represented value is preserved, while immediate rational facts, `Display`,
raw JSON/CBOR and hashes of those bytes can change. The wire schema is unchanged;
both reader versions accept the qualification corpus and prove the same exact
rational values. Regenerate representation-based snapshots for new results and
retain the producing source version when replay requires byte identity.
A rational certificate establishes the value of the scalar expression; it
does not certify upstream geometric intent or source accuracy.
''')
before_root=W/'main-source-before-v1'
assert not before_root.exists();before_root.mkdir()
record={};patches=[]
def save_change(relative,after,qualified_source=None):
 dest=O/relative;before=dest.read_bytes() if dest.exists() else None
 assert before!=after
 if before is not None:
  saved=before_root/relative;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(before)
 record[relative]={'before_sha256':hashlib.sha256(before).hexdigest() if before is not None else None,'after_sha256':hashlib.sha256(after).hexdigest(),'qualified_source':str(qualified_source) if qualified_source else None}
 patches.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
 dest.write_bytes(after);pins[relative]=sha(dest)
for relative,source in changes.items():save_change(relative,source.read_bytes(),source)
save_change(readme_path,readme.encode())
assert len(pins)==2655
pinfile=W/'main-source-pins-v2.json.gz';assert not pinfile.exists()
pinfile.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
patchfile=W/'main-source-integration-v1.patch';assert not patchfile.exists();patchfile.write_text(''.join(patches))
dump(W/'main-source-integration-v1.json',{
 'parent_revision':BASE,'driver_sha256':sha(Path(__file__)),
 'isolated_qualification_sha256':{k:sha(v) for k,v in results.items()},
 'changes':record,'source_pins_sha256':sha(pinfile),'source_patch_sha256':sha(patchfile),
 'serialization_input_preservation_sha256':sha(W/'serialization-input-preservation-v1.json'),
 'malformed_serde_review_sha256':sha(W/'malformed-serde-review-v1.json'),
 'candidate_rust_bytes_unchanged':True,'actual_main_validation_pending':True,
 'runtime_admitted':False,'full_plan_complete':False,'hypervoxel_excluded':True,
})
source=W/'affine_cargo_harness_v1.py';dest=W/'affine_main_harness_v1.py'
assert not dest.exists();text=source.read_text()
def replace(old,new):
 global text
 assert text.count(old)==1,old
 text=text.replace(old,new)
replace('main-source-pins-v1.json.gz','main-source-pins-v2.json.gz')
replace("'source_overlays':{str(O/'crates/hyperreal/src/real'):str(W/'real'),str(O/'crates/hyperreal/src/computable/node/algebra.rs'):str(W/'algebra_explicit_v2.rs')},","'source_overlays':{},'scalar_source_overlays_used':False,'main_source_integration_sha256':sha(W/'main-source-integration-v1.json'),")
replace("'production_source_changed':False","'production_source_changed':True")
replace("        argv+=['--ro-bind',str(W/'real'),str(O/'crates/hyperreal/src/real'),'--ro-bind',str(W/'algebra_explicit_v2.rs'),str(O/'crates/hyperreal/src/computable/node/algebra.rs')]\n","")
ast.parse(text);dest.write_text(text)
assert all(sha(O/p)==v for p,v in pins.items())
assert all(sha(v['copy'])==v['sha256'] for v in preservation['libraries'].values())
assert not reasons(resources())
assert not git('diff','--check')
print(json.dumps({'qualified_candidate_applied':True,'changed_paths':sorted(record),'actual_main_validation_pending':True}),flush=True)
