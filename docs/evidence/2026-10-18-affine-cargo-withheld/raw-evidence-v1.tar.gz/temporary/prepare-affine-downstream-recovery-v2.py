"""Preserve the completed suite and fix only recognition of printed test output."""
import ast
from pathlib import Path
source=Path('/tmp/qualify-affine-cargo-downstream-v1.py')
dest=Path('/tmp/qualify-affine-cargo-downstream-v2.py')
assert not dest.exists()
text=source.read_text()
def replace(old,new):
 global text
 assert text.count(old)==1,old
 text=text.replace(old,new)
replace("h=Harness('downstream-v1')","h=Harness('downstream-v2')")
replace("dump(h.R/'driver-protocol-v1.json',{",'''def gate_completed(out,gate):
 pattern=r'^test '+re.escape(gate)+r' \\.\\.\\. '
 found=list(re.finditer(pattern,out,re.M))
 assert len(found)==1,(gate,len(found))
 match=found[0]
 following=re.search(r'^test ',out[match.end():],re.M)
 end=match.end()+following.start() if following else len(out)
 segment=out[match.start():end].strip()
 last_line=segment.splitlines()[-1]
 assert last_line=='ok' or last_line=='test '+gate+' ... ok',(gate,last_line)
 return segment
dump(h.R/'driver-protocol-v1.json',{''')
replace("assert re.search(r'^test '+re.escape(gate)+r' \\.\\.\\. ok$',out,re.M),gate","gate_completed(out,gate)")
replace("for package,flags in [\n ('hyperdrc',[]),('hyperlimit',['--all-features']),",'''def recover_completed_hyperdrc():
 old=N/'affine-cargo-downstream-v1'
 old_protocol=json.loads((old/'protocol-v1.json').read_text())
 assert old_protocol['preparation_sha256']==sha(W/'preparation-v2.json')
 commands=json.loads((old/'progress-v1.json').read_text())
 artifacts=json.loads((U/'frozen/downstream-v1/executables-v1.json').read_text())
 assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
 assert len(commands)==11 and all(v['exit_code']==0 and not v['stops'] and v['output_closed'] for v in commands.values())
 for label,command in commands.items():
  folder=N/'logs'/('affine-cargo-downstream-v1-'+label)
  assert all(sha(folder/p)==digest for p,digest in command['output_sha256'].items())
  if '-test-' not in label:continue
  out=(folder/'stdout').read_text();err=(folder/'stderr').read_text()
  result=rows(out)
  assert result and all(r[0]=='ok' and r[2]=='0' for r in result)
  assert 'skipping complex project fixture' not in out+err
  summaries[label]=result;parents[label]=result[-1]
  if any(v['target']['kind']==['lib'] and v['copy'] in command['argv'] for v in artifacts.values()):
   for gate in gate_names:
    gate_completed(out,gate)
    native_gates[gate]={'passed':True,'command':label,'inherited_log_directory':str(folder)}
 assert len(native_gates)==3
 assert sum(int(r[1]) for r in parents.values())==1667
 assert all(r[3]=='0' for r in parents.values())
 h.commands.update(commands);h.artifacts.update(artifacts)
 dump(h.A/'executables-v1.json',h.artifacts)
 h.bind_programs(list(artifacts))
 dump(h.R/'reused-completed-hyperdrc-v1.json',{
  'prior_driver_sha256':sha('/tmp/qualify-affine-cargo-downstream-v1.py'),
  'prior_progress_sha256':sha(old/'progress-v1.json'),
  'prior_manifest_sha256':sha(U/'frozen/downstream-v1/executables-v1.json'),
  'all_completed_outputs_and_binaries_rehashed':True,
  'compiled_or_tested_again':False,
  'cause':'The driver required a same-line ok even though nocapture prints native reports between the test name and the harness ok. All 1667 tests and all three gates passed; source, assertions, fixtures and limits are unchanged.',
  'corrected_gate_parser':'Require exactly one named test start and an explicit final ok before the next test. Also require all parent summaries to pass with zero failures and zero ignores.',
  'commands':commands,'native_gates':native_gates,
 })
 out,_,_=h.execute('hyperdrc-doctests',[cargo,'test','--release','--locked','-p','hyperdrc','--doc','--','--test-threads=1'])
 result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result)
 summaries['hyperdrc-doctests']=result
 packages['hyperdrc']={
  'test_binaries':sum(v['profile']['test'] for v in artifacts.values()),
  'parent_test_passed':sum(int(r[1]) for r in parents.values()),
  'parent_ignored':sum(int(r[3]) for r in parents.values()),
  'doctests_passed':sum(int(r[1]) for r in result),
 }
 assert packages['hyperdrc']==baseline['packages']['hyperdrc']
 dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages,'native_gates':native_gates})
 print('PACKAGE_PASSED '+json.dumps({'hyperdrc':packages['hyperdrc'],'runtime_reused_after_output_verification':True}),flush=True)
recover_completed_hyperdrc()
for package,flags in [
 ('hyperlimit',['--all-features']),''')
ast.parse(text)
dest.write_text(text)
print(dest)
