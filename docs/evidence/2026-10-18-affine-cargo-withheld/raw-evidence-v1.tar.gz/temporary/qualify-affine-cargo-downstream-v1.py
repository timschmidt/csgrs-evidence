"""Qualify the isolated exact affine subtraction through six complete consumers."""
import json,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/explicit-affine-cargo-control-v1')
sys.path.insert(0,str(W))
from affine_cargo_harness_v1 import Harness,N,O,U,cargo,sha,dump,rows
assert json.loads((N/'affine-cargo-scalar-v1/result-v1.json').read_text())['passed']
assert json.loads((N/'affine-cargo-serialization-v2/result-v1.json').read_text())['passed']
baseline=json.loads((N/'sign-cache-publication-main-v3/result-v1.json').read_text())
assert baseline['passed']
h=Harness('downstream-v1')
summaries={};parents={};packages={};native_gates={}
gate_names=[
 'zz_complex_project_performance_tests::gerber_package_completes_smoke_check_suite',
 'zz_complex_project_performance_tests::kicad_board_completes_smoke_check_suite',
 'zz_complex_project_performance_tests::min_copper_neck_width_completes_on_copper_layers',
]
dump(h.R/'driver-protocol-v1.json',{
 'helper_sha256':sha(Path(__file__)),
 'baseline_result_sha256':sha(N/'sign-cache-publication-main-v3/result-v1.json'),
 'expected_packages':{p:baseline['packages'][p] for p in ['hyperdrc','hyperlimit','hypercurve','hypermesh','csgrs','hypercircuit']},
 'native_gate_names':gate_names,
 'native_limits':{'kicad_worker_cpu_seconds':120,'gerber_wall_seconds':120,'copper_check_wall_seconds':60},
 'original_test_bodies_policies_fixtures_and_ignores_unchanged':True,
 'source_contract_sha256':sha(W/'contract-v1.md'),
})
def run_package(package,flags):
 print('PACKAGE_START '+package,flush=True)
 keys=h.build(package+'-build',['test','--release','--locked','-p',package,'--tests']+flags)
 h.bind_programs(keys)
 dump(h.R/(package+'-runtime-bindings-v1.json'),h.runtime_bindings)
 for ordinal,key in enumerate(keys):
  artifact=h.artifacts[key]
  if not artifact['profile']['test']:continue
  name=package+'-test-'+str(ordinal)+'-'+artifact['target']['name']
  result,out,err,_=h.test(name,key)
  assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
  assert 'skipping complex project fixture' not in out+err
  summaries[name]=result;parents[name]=result[-1]
  if package=='hyperdrc' and artifact['target']['kind']==['lib']:
   for gate in gate_names:
    assert re.search(r'^test '+re.escape(gate)+r' \.\.\. ok$',out,re.M),gate
    native_gates[gate]={'passed':True,'command':name}
  dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages,'native_gates':native_gates})
 out,_,_=h.execute(package+'-doctests',[cargo,'test','--release','--locked','-p',package,'--doc']+flags+['--','--test-threads=1'])
 result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
 summaries[package+'-doctests']=result
 package_result={
  'test_binaries':sum(h.artifacts[k]['profile']['test'] for k in keys),
  'parent_test_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith(package+'-test-')),
  'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith(package+'-test-')),
  'doctests_passed':sum(int(r[1]) for r in result),
 }
 assert package_result==baseline['packages'][package],(package,package_result,baseline['packages'][package])
 packages[package]=package_result
 dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages,'native_gates':native_gates})
 print('PACKAGE_PASSED '+json.dumps({package:package_result}),flush=True)
for package,flags in [
 ('hyperdrc',[]),('hyperlimit',['--all-features']),
 ('hypercurve',['--all-features']),('hypermesh',['--all-features']),
 ('csgrs',[]),('hypercircuit',['--all-features']),
]:run_package(package,flags)
assert len(native_gates)==3
for package in packages:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
 print('LINT_DOCS_PASSED '+package,flush=True)
h.verify()
dump(h.R/'result-v1.json',{
 'passed':True,'packages':packages,'summaries':summaries,
 'parent_summaries':parents,'native_gates':native_gates,
 'commands':h.commands,'artifacts':h.artifacts,
 'original_native_workload_limits_unchanged':True,
 'production_source_changed':False,'runtime_admitted':False,
 'hypervoxel_excluded':True,'full_plan_complete':False,
})
print(json.dumps({'downstream_passed':True,'packages':packages,'native_gates_passed':3}),flush=True)
