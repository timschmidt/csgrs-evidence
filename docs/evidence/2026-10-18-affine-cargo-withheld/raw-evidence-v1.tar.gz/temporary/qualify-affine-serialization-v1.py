"""Compare exact affine serialization and read both producers with both versions."""
import gzip,json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
sys.path.insert(0,str(N/'explicit-affine-cargo-control-v1'))
from affine_cargo_harness_v1 import Harness,W,O,U,compiler,sha,dump,file_state
assert json.loads((N/'affine-cargo-scalar-v1/result-v1.json').read_text())['passed']
h=Harness('serialization-v1')
source=W/'serialization_probe_v1.rs';source_hash=sha(source)
old=json.loads(gzip.decompress((O/'docs/evidence/2026-10-18-sign-cache-publication/artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
logs={
    'baseline':N/'logs/sign-cache-publication-main-v3-hyperreal-all-build/stdout',
    'candidate':N/'logs/affine-cargo-scalar-v1-all-build/stdout',
}
libs={}
for variant,log in logs.items():
    if variant=='baseline':assert sha(log)==old[str(log)]
    matches=[]
    for line in log.read_text().splitlines():
        if not line.startswith('{'):continue
        row=json.loads(line);target=row.get('target',{})
        if row.get('reason')=='compiler-artifact' and target.get('name')=='hyperreal' and target.get('kind')==['lib']:
            files=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
            if files:matches.append((row,files))
    assert len(matches)==1 and len(matches[0][1])==1
    row,files=matches[0];p=files[0]
    if variant=='baseline':assert sha(p)==old[str(p)]
    libs[variant]={'path':str(p),'sha256':sha(p),'features':row['features'],'cargo_log_sha256':sha(log)}
assert libs['baseline']['features']==libs['candidate']['features']
dump(h.R/'library-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'probe_source_sha256':source_hash,'contract_sha256':sha(W/'serialization-contract-v1.md'),'libraries':libs,'baseline_source_still_matches_main':True,'no_timing_claim':True})
outputs={}
build=U/'serialization-probe-build-v1';assert not build.exists();build.mkdir()
for variant,lib in libs.items():
    assert sha(source)==source_hash and sha(lib['path'])==lib['sha256']
    p=build/variant
    args=[compiler['additional_environment']['RUSTC'],'--crate-name','serialization_probe','--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+lib['path'],'-L','dependency='+str(Path(lib['path']).parent),'-o',p]
    h.execute(variant+'-compile',args,limit=60)
    copy=h.A/variant;digest=sha(p);shutil.copy2(p,copy);assert sha(copy)==digest
    h.states[str(copy)]=file_state(copy)
    h.artifacts[variant]={'copy':str(copy),'compiled_path':str(p),'sha256':digest,'bytes':copy.stat().st_size,'features':lib['features'],'target':{'name':'serialization_probe','kind':['bin']},'profile':{'test':False},'cargo_fresh':False,'direct_probe_build':True}
    dump(h.A/'executables-v1.json',h.artifacts)
    out,_,_=h.execute(variant+'-emit',[copy,'emit'],binary=True,limit=60)
    assert sha(copy)==digest and sha(source)==source_hash
    rows={}
    for line in out.splitlines():
        kind,label,*rest=line.split('\t')
        assert kind in {'JSON','CBOR','DISPLAY','FACT'}
        assert label not in rows.setdefault(kind,{})
        rows[kind][label]='\t'.join(rest)
    assert set(rows)=={'JSON','CBOR','DISPLAY','FACT'} and all(len(v)==18 for v in rows.values())
    outputs[variant]=rows
read_results={}
for reader in ['baseline','candidate']:
    for producer in ['baseline','candidate']:
        data=N/'logs'/('affine-cargo-serialization-v1-'+producer+'-emit')/'stdout'
        binary=h.artifacts[reader]
        assert sha(binary['copy'])==binary['sha256']
        out,_,_=h.execute(reader+'-read-'+producer,[binary['copy'],'read',data],binary=True,limit=60)
        rows=out.splitlines()
        assert len(rows)==36 and all(line.startswith('READ\t') and line.endswith('\tok') for line in rows)
        assert sha(binary['copy'])==binary['sha256']
        read_results[reader+'/'+producer]={'proved_values':len(rows),'input_sha256':sha(data)}
changes={}
for kind in outputs['baseline']:
    before=outputs['baseline'][kind];after=outputs['candidate'][kind]
    assert set(before)==set(after)
    changes[kind]={key:{'baseline':before[key],'candidate':after[key]} for key in before if before[key]!=after[key]}
assert all(v=='true' for v in outputs['candidate']['FACT'].values())
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'recipes':18,'cache_warming_serialization_identity_passed':True,'cross_version_readers':read_results,'changed_values':changes,'outputs':outputs,'libraries':libs,'commands':h.commands,'intentional_rational_carrier_migration':True,'new_wire_schema':False,'independent_rational_oracles':True,'raw_scalar_serialization_identity_claimed':False,'full_native_report_compatibility_pending':True,'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False})
print(json.dumps({'serialization_compatible_for_recipes':18,'cross_reader_values_proved':sum(v['proved_values'] for v in read_results.values()),'changed_rows':{k:len(v) for k,v in changes.items()},'runtime_admitted':False}),flush=True)
