"""Write the fresh-target Cargo harness without changing production source."""
import ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'explicit-affine-cargo-control-v1'
harness=r'''"""Fresh Cargo target, read-only source/registry, independently frozen executables."""
import gzip,json,os,re,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
U=Path('/tmp/csgrs-explicit-affine-cargo-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
from validation_runner_v1 import run,dump,sha,resources,reasons
prep=json.loads((W/'preparation-v2.json').read_text())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE']='true'
os.environ['CARGO_CACHE_AUTO_CLEAN_FREQUENCY']='never'
os.environ['RUSTDOCFLAGS']='-D warnings'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
rustfmt=str(Path(cargo).with_name('rustfmt'))
pins=json.loads(gzip.decompress((W/'main-source-pins-v1.json.gz').read_bytes()))
def rows(text):
    return re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',text,re.M)
def file_state(path):
    st=Path(path).stat()
    return st.st_size,st.st_mtime_ns,st.st_ctime_ns
class Harness:
    def __init__(self,phase):
        self.phase=phase;self.R=N/('affine-cargo-'+phase)
        self.A=U/'frozen'/phase;self.target=U/'target'
        assert not self.R.exists() and not self.A.exists()
        self.R.mkdir();self.A.mkdir()
        self.commands={};self.artifacts={};self.runtime_bindings={};self.states={}
        for manifest in (U/'frozen').glob('*/executables-v1.json'):
            for item in json.loads(manifest.read_text()).values():
                assert sha(item['copy'])==item['sha256']
                self.states[item['copy']]=file_state(item['copy'])
        self.verify()
        dump(self.R/'protocol-v1.json',{
            'helper_sha256':sha(Path(__file__)),'phase':phase,
            'contract_sha256':sha(W/'contract-v1.md'),
            'preparation_sha256':sha(W/'preparation-v2.json'),
            'temporary_storage_contract_sha256':sha(W/'tmp-contract-v1.json'),
            'registry_input_inventory_sha256':sha(W/'registry-inputs-v1.json.gz'),
            'registry_mounts_read_only':True,'cargo_bookkeeping_private':True,
            'source_overlays':{str(O/'crates/hyperreal/src/real'):str(W/'real'),str(O/'crates/hyperreal/src/computable/node/algebra.rs'):str(W/'algebra_explicit_v2.rs')},
            'source_root':str(O),'target':str(self.target),
            'production_source_changed':False,'tmp_allowance_gib':24,'disk_b_allowance_gib':72,
            'frozen_copy_policy':'Hash each copy when created and each executed binary before/after use. All frozen outputs are mounted read-only for every command; verify all physical hashes at closure.',
            'inherited_frozen_copies':list(self.states)})
    def verify(self):
        assert all(sha(O/p)==h for p,h in pins.items())
        assert all(sha(p)==h for p,h in prep['overlay_sha256'].items())
        assert all(file_state(p)==st for p,st in self.states.items())
        stops=reasons(resources())
        if stops:raise RuntimeError(stops)
    def execute(self,label,args,*,binary=False,limit=1800,allow_failure=False):
        self.verify();name='affine-cargo-'+self.phase+'-'+label
        scratch=U/'scratch'/name;assert not scratch.exists();scratch.mkdir()
        argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(U),str(U),'--ro-bind',str(U/'frozen'),str(U/'frozen'),'--chdir',str(scratch if binary else O)]
        for kind in ['index','cache','src']:
            argv+=['--ro-bind',str(V/'cargo-home-v1/registry'/kind),str(U/'cargo-home/registry'/kind)]
        argv+=['--ro-bind',str(W/'real'),str(O/'crates/hyperreal/src/real'),'--ro-bind',str(W/'algebra_explicit_v2.rs'),str(O/'crates/hyperreal/src/computable/node/algebra.rs)]
        if binary:
            for dest,src in self.runtime_bindings.items():argv+=['--ro-bind',str(src),str(dest)]
        for key,value in {
            'CARGO_HOME':str(U/'cargo-home'),'CARGO_TARGET_DIR':str(self.target),
            'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(U/'xdg-cache'),
            'GMP_MPFR_SYS_CACHE':str(U/'gmp-cache'),'CARGO_BUILD_JOBS':'2',
            'CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true',
            'CARGO_CACHE_AUTO_CLEAN_FREQUENCY':'never',
        }.items():argv+=['--setenv',key,value]
        try:r=run(name,argv+list(map(str,args)),O,target=self.target,wall_seconds=limit)
        except RuntimeError:
            r=json.loads((N/'logs'/name/'result.json').read_text())
            self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands)
            if r['stops'] or not allow_failure or r['exit_code']!=101:raise
        self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands);self.verify()
        out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
        assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M),err[-3000:]
        return out,err,r
    def build(self,label,args):
        out,_,_=self.execute(label,[cargo]+args+['--no-run','--message-format=json'])
        found=[]
        for line in out.splitlines():
            if not line.startswith('{'):continue
            item=json.loads(line)
            if item.get('reason')!='compiler-artifact' or not item.get('executable'):continue
            name=item['target']['name']+'-'+item['target']['kind'][0]+('-tests' if item['profile']['test'] else '-program')
            key=label+'--'+name;assert key not in self.artifacts
            p=Path(item['executable']);copy=self.A/key;assert not copy.exists()
            needed=((p.stat().st_size+4095)//4096)*4096+65536
            contract=json.loads((W/'tmp-contract-v1.json').read_text())
            assert resources()['tmp_free_bytes']-needed>=contract['minimum_post_allowance_free_bytes'],str(p)
            h=sha(p);shutil.copy2(p,copy);assert sha(copy)==sha(p)==h
            self.states[str(copy)]=file_state(copy)
            self.artifacts[key]={'copy':str(copy),'compiled_path':str(p),'sha256':h,'bytes':copy.stat().st_size,'features':item['features'],'target':item['target'],'profile':item['profile'],'cargo_fresh':item['fresh']}
            found.append(key)
        assert found
        dump(self.A/'executables-v1.json',self.artifacts);self.verify()
        return found
    def bind_programs(self,keys):
        self.runtime_bindings={item['compiled_path']:item['copy'] for key in keys if not (item:=self.artifacts[key])['profile']['test']}
    def test(self,label,key,filters=None,*,allow_failure=False,limit=1800):
        item=self.artifacts[key];assert sha(item['copy'])==item['sha256']
        out,err,r=self.execute(label,[item['copy']]+list(filters or [])+['--nocapture','--test-threads=1'],binary=True,allow_failure=allow_failure,limit=limit)
        assert sha(item['copy'])==item['sha256']
        return rows(out),out,err,r
'''
ast.parse(harness)
p=W/'affine_cargo_harness_v1.py';assert not p.exists();p.write_text(harness)
scalar=r'''"""Run scalar Cargo configurations against the formatted isolated candidate."""
import json
from affine_cargo_harness_v1 import Harness,W,N,O,U,cargo,rustfmt,sha,dump,rows
h=Harness('scalar-v1');summaries={};parents={};packages={}
for name,flags in [('default',[]),('all',['--all-features'])]:
    keys=h.build(name+'-build',['test','--release','--locked','-p','hyperreal','--tests']+flags)
    h.bind_programs(keys)
    for ordinal,key in enumerate(keys):
        item=h.artifacts[key]
        if not item['profile']['test']:continue
        label=name+'-test-'+str(ordinal)+'-'+item['target']['name']
        result,out,err,_=h.test(label,key)
        assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
        summaries[label]=result;parents[label]=result[-1]
    out,_,_=h.execute(name+'-doctests',[cargo,'test','--release','--locked','-p','hyperreal','--doc']+flags+['--','--test-threads=1'])
    result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
    summaries[name+'-doctests']=result
    h.execute(name+'-clippy',[cargo,'clippy','--release','--locked','-p','hyperreal','--all-targets']+flags+['--','-D','warnings'])
    packages[name]={'parent_tests_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith(name+'-test-')),'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith(name+'-test-')),'doctests_passed':sum(int(r[1]) for r in result)}
    dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parents':parents,'packages':packages})
keys=h.build('debug-build',['test','--locked','-p','hyperreal','--lib']);assert len(keys)==1
result,_,_,_=h.test('debug-library',keys[0])
assert result==[('ok','823','0','0','0','0')],result
summaries['debug-library']=result
h.execute('docs',[cargo,'doc','--release','--locked','-p','hyperreal','--all-features','--no-deps'])
h.execute('workspace-fmt',[cargo,'fmt','--all','--','--check'])
h.execute('new-tests-fmt',[rustfmt,'--edition','2024','--check','--config-path',O/'crates/.rustfmt.toml','--config','max_width=100,skip_children=true',W/'real/explicit_affine_tests.rs',W/'real/mod.rs'],limit=60)
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,'commands':h.commands,'artifacts':h.artifacts,'initially_empty_target':str(h.target),'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False,'storage_baselines_reset':False,'tmp_allowance_gib':24})
print(json.dumps({'scalar_cargo_passed':True,'packages':packages,'runtime_admitted':False}),flush=True)
'''
ast.parse(scalar)
p=W/'qualify_scalar_v1.py';assert not p.exists();p.write_text(scalar)
print('Prepared fresh-target Cargo harness and complete scalar phase.')
