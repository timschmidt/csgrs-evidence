"""Retain direct compiler inputs before future changes reuse the open Cargo target."""
import hashlib,json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'explicit-affine-cargo-control-v1'
sys.path.insert(0,str(W))
from validation_runner_v1 import sha,resources,reasons
U=Path('/tmp/csgrs-explicit-affine-cargo-20261018-v1')
R=U/'frozen/serialization-inputs-v1'
assert not R.exists()
result=N/'affine-cargo-serialization-v2/result-v1.json'
libraries=json.loads(result.read_text())['libraries']
assert all(sha(v['path'])==v['sha256'] for v in libraries.values())
assert not reasons(resources())
R.mkdir()
frozen={}
for variant,lib in libraries.items():
 source=Path(lib['path']);copy=R/(variant+'-'+source.name)
 before=source.stat()
 shutil.copy2(source,copy)
 assert sha(source)==sha(copy)==lib['sha256']
 after=source.stat()
 assert (before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_size,after.st_mtime_ns,after.st_ctime_ns)
 frozen[variant]={'original_path':str(source),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'independent_physical_copy':True}
record={'driver_sha256':sha(Path(__file__)),'qualification_result_sha256':sha(result),'libraries':frozen,'prior_input_hashes_match_before_copy':True,'original_target_remains_open':True,'prior_results_not_rewritten':True,'purpose':'Preserve each explicitly pinned direct-compiler input before subsequent source integration can replace Cargo outputs. All executed probe binaries already have frozen copies.'}
p=W/'serialization-input-preservation-v1.json'
assert not p.exists();p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
assert not reasons(resources())
print(json.dumps({'frozen_libraries':2,'all_input_hashes_preserved':True}),flush=True)
