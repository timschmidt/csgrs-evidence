"""Replay actual-main reports against the preserved complete baseline reports."""
import decimal,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/explicit-affine-cargo-control-v1')
sys.path.insert(0,str(W))
from affine_main_harness_v1 import Harness,N,O,U,sha,dump
assert json.loads((N/'affine-cargo-main-v1/result-v1.json').read_text())['passed']
prior=json.loads((N/'affine-cargo-reports-v1/result-v1.json').read_text())
assert prior['all_report_bytes_equal'] and prior['all_parsed_reports_equal']
protocol=json.loads((N/'affine-cargo-reports-v1/report-protocol-v1.json').read_text())
manifest=U/'frozen/main-v1/executables-v1.json'
artifacts=json.loads(manifest.read_text())
found=[v for k,v in artifacts.items() if k.startswith('hyperdrc-build--') and v['target']['kind']==['bin'] and not v['profile']['test']]
assert len(found)==1
binary=found[0]
h=Harness('main-reports-v1')
F=N/'native-aggregation-fixtures-v1'
fixtures=protocol['fixtures']
def verify():
 h.verify()
 assert sha(binary['copy'])==binary['sha256']
 assert all(sha(v['path'])==v['sha256'] for v in fixtures.values())
def unique(pairs):
 result={}
 for k,v in pairs:assert k not in result;result[k]=v
 return result
def reject(value):raise ValueError(value)
def parse(data):return json.loads(data,parse_float=decimal.Decimal,parse_constant=reject,object_pairs_hook=unique)
verify()
dump(h.R/'report-protocol-v1.json',{
 'driver_sha256':sha(Path(__file__)),'prior_report_result_sha256':sha(N/'affine-cargo-reports-v1/result-v1.json'),
 'prior_report_protocol_sha256':sha(N/'affine-cargo-reports-v1/report-protocol-v1.json'),
 'main_manifest_sha256':sha(manifest),'binary':binary,'fixtures':fixtures,
 'cases':protocol['cases'],'repeats_per_case':2,'common_cwd':str(F),
 'normalization':False,'performance_claim':False,'independent_geometry_oracle':False,
 'actual_main_without_scalar_overlays':True,'source_integration_sha256':sha(W/'main-source-integration-v1.json'),
})
comparisons={}
for label,args,checks in protocol['cases']:
 baseline=N/'logs'/('affine-cargo-reports-v1-'+label+'-0-baseline')/'stdout'
 assert sha(baseline)==prior['cases'][label]['observations'][0]['stdout_sha256']
 expected=baseline.read_bytes();expected_parsed=parse(expected)
 observations=[]
 for ordinal in range(2):
  verify();command=label+'-'+str(ordinal)
  name='affine-cargo-'+h.phase+'-'+command;scratch=U/'scratch'/name
  h.execute(command,['/usr/bin/env','-C',F,'/usr/bin/time','-v','-o',scratch/'process-usage.txt',binary['copy'],*args],binary=True)
  stdout=N/'logs'/name/'stdout';data=stdout.read_bytes();report=parse(data)
  coverage=report['coverage']['checks']
  assert report['inputs'] and len(report['violations'])==report['violation_count']
  assert [r['check'] for r in coverage]==checks and all(r['check_version']==22 for r in coverage)
  row={'stdout_sha256':sha(stdout),'bytes':len(data),'full_report_materialized':True,'violation_count':report['violation_count'],'raw_bytes_equal':data==expected,'parsed_values_equal':report==expected_parsed,'process_usage_path':str(scratch/'process-usage.txt'),'process_usage_sha256':sha(scratch/'process-usage.txt')}
  observations.append(row)
  dump(h.R/(command+'-comparison-v1.json'),row)
  assert row['raw_bytes_equal'] and row['parsed_values_equal']
  verify();print('MAIN_REPORT_PASSED '+command,flush=True)
 comparisons[label]=observations
verify()
dump(h.R/'result-v1.json',{
 'passed':True,'commands':h.commands,'comparisons':comparisons,
 'all_report_bytes_equal':True,'all_parsed_reports_equal':True,
 'actual_main_without_scalar_overlays':True,'source_integration_sha256':sha(W/'main-source-integration-v1.json'),
 'performance_claim':False,'independent_geometry_oracle':False,
 'runtime_admission_record_pending':True,'full_plan_complete':False,
})
