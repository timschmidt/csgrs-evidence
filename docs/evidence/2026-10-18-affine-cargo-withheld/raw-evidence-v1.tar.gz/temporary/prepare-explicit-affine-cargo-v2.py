"""Finish the stopped preparation after reviewing rustfmt's expression blocks."""
import ast,difflib,gzip,json,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'explicit-affine-cargo-control-v1';OLD=N/'explicit-affine-control-v1';P=N/'sign-cache-publication-control-v1'
U=Path('/tmp/csgrs-explicit-affine-cargo-20261018-v1');V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(W))
from validation_runner_v1 import resources,reasons,sha
def dump(p,v):
    assert not Path(p).exists(),p
    Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert not reasons(resources()) and not (W/'preparation-v1.json').exists()
assert not any((U/'target').iterdir())
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
assert all(sha(O/p)==h for p,h in pins.items())
registry=json.loads(gzip.decompress((W/'registry-inputs-v1.json.gz').read_bytes()))
assert all(sha(p)==h for p,h in registry.items())
gmp=json.loads((W/'native-cache-copy-v1.json').read_text())
assert all(sha(p)==sha(v['copied_path'])==v['sha256'] for p,v in gmp.items())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
rustfmt=Path(compiler['additional_environment']['RUSTC']).with_name('rustfmt')
def fmt(s):
    r=subprocess.run([str(rustfmt),'--edition','2024','--config-path',str(O/'crates/.rustfmt.toml'),'--config','max_width=100','--emit','stdout'],input=s,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=O,check=True)
    assert not r.stderr
    return r.stdout
assert (W/'real/explicit_affine_tests.rs').read_text()==fmt((OLD/'explicit_affine_tests_v1.rs').read_text())
assert (W/'real/arithmetic/add_sub.rs').read_bytes()==(OLD/'add_sub_explicit_v1.rs').read_bytes()
module=(O/'crates/hyperreal/src/real/mod.rs').read_text().replace('#[cfg(test)]\nmod immediate_equality_tests;','#[cfg(test)]\nmod explicit_affine_tests;\n\n#[cfg(test)]\nmod immediate_equality_tests;')
assert (W/'real/mod.rs').read_text()==module
algebra=(OLD/'algebra_explicit_v1.rs').read_text();start=algebra.index('    // Prove only cancellation of the symbolic terms.');end=algebra.index('    /// Add some other number to this number.',start)
block=algebra[start:end];formatted=fmt('impl Computable {\n'+block+'}\n')
assert formatted==fmt(formatted)
body=formatted[len('impl Computable {\n'):-2]+'\n'
p=W/'helper-format-v2.patch';assert not p.exists()
p.write_text(''.join(difflib.unified_diff(block.splitlines(True),body.splitlines(True),fromfile='E76 helper',tofile='rustfmt helper')))
assert not (W/'algebra_explicit_v2.rs').exists()
(W/'algebra_explicit_v2.rs').write_text(algebra[:start]+body+algebra[end:])
dump(W/'preparation-failure-v1.json',{'failed_helper':'/tmp/prepare-explicit-affine-cargo-v1.py','failed_helper_sha256':sha('/tmp/prepare-explicit-affine-cargo-v1.py'),'exit_code':1,'assertion':'formatting_tokens(body)==formatting_tokens(block)','reason':'Pinned rustfmt wraps two tuple-valued match arms in expression blocks; the guard only allowed whitespace and trailing commas.','reviewed_format_diff_sha256':sha(W/'helper-format-v2.patch'),'cargo_commands_started':0,'tests_run':0,'acceptance_tests_changed':False,'existing_preparation_and_storage_contract_preserved':True})
original=ast.parse(Path('/tmp/prepare-explicit-affine-cargo-v1.py').read_text())
contracts=[]
for node in ast.walk(original):
    if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='write_text':
        target=node.func.value
        if isinstance(target,ast.BinOp) and isinstance(target.right,ast.Constant) and target.right.value=='contract-v1.md':
            contracts.append(ast.literal_eval(node.args[0]))
assert len(contracts)==1 and not (W/'contract-v1.md').exists()
contract=contracts[0].replace('Pinned rustfmt changes only whitespace and trailing separators in the new\nhelper/test text.','Pinned rustfmt formats the new helper/test text. Its expression-block changes\nare reviewed in helper-format-v2.patch; every acceptance test remains intact.')
(W/'contract-v1.md').write_text(contract)
(W/'main-source-pins-v1.json.gz').write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
overlay_pins={str(p):sha(p) for p in (W/'real').rglob('*') if p.is_file()}
overlay_pins[str(W/'algebra_explicit_v2.rs')]=sha(W/'algebra_explicit_v2.rs')
changes={}
for p in sorted((W/'real').rglob('*')):
    if not p.is_file():continue
    rel='crates/hyperreal/src/real/'+str(p.relative_to(W/'real'))
    if not (O/rel).exists() or sha(O/rel)!=sha(p):changes[rel]={'candidate':str(p),'sha256':sha(p)}
changes['crates/hyperreal/src/computable/node/algebra.rs']={'candidate':str(W/'algebra_explicit_v2.rs'),'sha256':sha(W/'algebra_explicit_v2.rs')}
assert set(changes)=={'crates/hyperreal/src/real/mod.rs','crates/hyperreal/src/real/arithmetic/add_sub.rs','crates/hyperreal/src/real/explicit_affine_tests.rs','crates/hyperreal/src/computable/node/algebra.rs'}
E=O/'docs/evidence/2026-10-18-explicit-affine-subtraction'
assert not reasons(resources())
dump(W/'preparation-v2.json',{'parent_revision':'0179a1b68621d48e1b5087d64d64493e0c3819c5','helper_sha256':sha(Path(__file__)),'previous_checkpoint_sha256':sha(E/'checkpoint-v1.json'),'registry_inputs_sha256':sha(W/'registry-inputs-v1.json.gz'),'registry_file_count':len(registry),'native_cache_copy_sha256':sha(W/'native-cache-copy-v1.json'),'main_source_pins_sha256':sha(W/'main-source-pins-v1.json.gz'),'overlay_sha256':overlay_pins,'changes':changes,'format_tool_sha256':sha(rustfmt),'reviewed_format_diff_sha256':sha(W/'helper-format-v2.patch'),'previous_preparation_stop_sha256':sha(W/'preparation-failure-v1.json'),'storage_contract_sha256':sha(W/'tmp-contract-v1.json'),'compiler_protocol_sha256':sha(V/'cargo-preparation-protocol-v1.json'),'production_source_changed':False,'target_initially_empty':True,'resources':resources()})
print(json.dumps({'prepared':True,'registry_files':len(registry),'candidate_changes':list(changes),'tmp_allowance_gib':24,'production_source_changed':False}),flush=True)
