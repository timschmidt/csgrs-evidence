"""Run scalar Cargo configurations against the formatted isolated candidate."""
import json
from affine_cargo_harness_v1 import Harness,W,N,O,U,cargo,rustfmt,sha,dump,rows
h=Harness('scalar-v1');summaries={};parents={};packages={}
for name,flags in [('default',[]),('all',['--all-features'])]:
    keys=h.build(name+'-build',['test','--release','--locked','-p','hyperreal','--tests']+flags)
    h.bind_programs(keys)
    for ordinal,key in enumerate(keys):
        item=h.artifacts[key]
        if not item['profile']['test']:continue
        label=name+'-test-'+str(ordinal)+'-'+item['target']['name']
        result,out,err,_=h.test(label,key)
        assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
        summaries[label]=result;parents[label]=result[-1]
    out,_,_=h.execute(name+'-doctests',[cargo,'test','--release','--locked','-p','hyperreal','--doc']+flags+['--','--test-threads=1'])
    result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
    summaries[name+'-doctests']=result
    h.execute(name+'-clippy',[cargo,'clippy','--release','--locked','-p','hyperreal','--all-targets']+flags+['--','-D','warnings'])
    packages[name]={'parent_tests_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith(name+'-test-')),'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith(name+'-test-')),'doctests_passed':sum(int(r[1]) for r in result)}
    dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parents':parents,'packages':packages})
keys=h.build('debug-build',['test','--locked','-p','hyperreal','--lib']);assert len(keys)==1
result,_,_,_=h.test('debug-library',keys[0])
assert result==[('ok','823','0','0','0','0')],result
summaries['debug-library']=result
h.execute('docs',[cargo,'doc','--release','--locked','-p','hyperreal','--all-features','--no-deps'])
h.execute('workspace-fmt',[cargo,'fmt','--all','--','--check'])
h.execute('new-tests-fmt',[rustfmt,'--edition','2024','--check','--config-path',O/'crates/.rustfmt.toml','--config','max_width=100,skip_children=true',W/'real/explicit_affine_tests.rs',W/'real/mod.rs'],limit=60)
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,'commands':h.commands,'artifacts':h.artifacts,'initially_empty_target':str(h.target),'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False,'storage_baselines_reset':False,'tmp_allowance_gib':24})
print(json.dumps({'scalar_cargo_passed':True,'packages':packages,'runtime_admitted':False}),flush=True)
