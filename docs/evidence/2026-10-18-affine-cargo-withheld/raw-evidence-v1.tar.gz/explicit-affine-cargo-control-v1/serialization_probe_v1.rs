use hyperreal::{Rational, Real};
use std::fmt::Write as _;

fn check(value: &Real, n: i64, d: i64) {
    let expected = Rational::fraction(59 * n, 56 * d).unwrap();
    assert_eq!(value.exact_rational_normal_form(), Some(expected));
}

fn emit() {
    for (family, base) in [
        ("sqrt2", Real::from(2).sqrt().unwrap()),
        ("sin7", Real::from(7).sin()),
        ("pi", Real::pi()),
    ] {
        for (n, d) in [(1_i64, 1_i64), (-1, 1), (-3, 1), (7, 11), (-1, 1024), (1024, 1)] {
            let scale = Real::new(Rational::fraction(n, d).unwrap());
            let left = (&base + Real::new(Rational::fraction(5, 8).unwrap())) * &scale;
            let right = (&base + Real::new(Rational::fraction(-3, 7).unwrap())) * &scale;
            let value = left - right;
            let json = value.to_json();
            let cbor = value.to_bytes();
            check(&value, n, d);
            value.certified_rational_interval(-128).unwrap();
            assert_eq!(value.to_json(), json, "warming changed JSON");
            assert_eq!(value.to_bytes(), cbor, "warming changed CBOR");
            let id = format!("{family}/{n}/{d}");
            println!("JSON\t{id}\t{n}\t{d}\t{json}");
            let mut hex = String::new();
            for byte in cbor {
                write!(&mut hex, "{byte:02x}").unwrap();
            }
            println!("CBOR\t{id}\t{n}\t{d}\t{hex}");
            println!("FACT\t{id}\t{}", value.exact_rational().is_some());
            println!("DISPLAY\t{id}\t{value}");
        }
    }
}

fn read(path: &str) {
    let input = std::fs::read_to_string(path).unwrap();
    let mut checked = 0;
    for line in input.lines() {
        let parts: Vec<_> = line.splitn(5, '\t').collect();
        if parts[0] != "JSON" && parts[0] != "CBOR" {
            continue;
        }
        assert_eq!(parts.len(), 5);
        let n = parts[2].parse().unwrap();
        let d = parts[3].parse().unwrap();
        let value = if parts[0] == "JSON" {
            Real::from_json(parts[4]).unwrap()
        } else {
            assert_eq!(parts[4].len() % 2, 0);
            let bytes: Vec<u8> = (0..parts[4].len())
                .step_by(2)
                .map(|i| u8::from_str_radix(&parts[4][i..i + 2], 16).unwrap())
                .collect();
            Real::from_bytes(&bytes).unwrap()
        };
        check(&value, n, d);
        println!("READ\t{}\t{}\tok", parts[0], parts[1]);
        checked += 1;
    }
    assert_eq!(checked, 36);
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    match args.get(1).map(String::as_str) {
        Some("emit") => emit(),
        Some("read") => read(&args[2]),
        _ => panic!("expected emit or read <file>"),
    }
}
