mod allocations;
use std::{ffi::c_void,hint::black_box};
unsafe extern "C" {fn measure_stack(callback: extern "C" fn(*mut c_void), context:*mut c_void, warm:i32,pattern:u8)->usize;}
extern "C" fn run(ptr:*mut c_void){
 let i=ptr.addr() as u32;
 black_box(ball_client::ball_verdict(i));
}
fn main(){
 for i in 0..20 {
 let ptr=std::ptr::without_provenance_mut(i);
 for warm in [0,1] {for pattern in [0x55,0xaa] {
 let peak=unsafe{measure_stack(run,ptr,warm,pattern)};
 println!("STACK|{i}|{warm}|{pattern}|{peak}");
 }}
 let v=allocations::measure(2,||run(ptr));
 println!("HEAP|{i}|{:?}",(v.allocations,v.deallocations,v.reallocations,v.allocated_bytes,v.peak_live_bytes,v.live_bytes));
 assert_eq!(v.live_bytes,0);
 }
}
