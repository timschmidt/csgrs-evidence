mod allocation;
use std::{ffi::c_void,hint::black_box};
extern "C" fn run(ptr:*mut c_void){
 let i=ptr.addr() as u32;
 black_box(ball_client::ball_verdict(i));
}
fn main(){
 for i in 0..20 {
  let ptr=std::ptr::without_provenance_mut(i);
  for _ in 0..8 {run(ptr);}
  let (_,v)=allocation::observe(||{run(ptr);run(ptr);});
  println!("{}|{:?}|{:?}",i,v.values(),v.usable());assert_eq!(v.usable().2,0);
 }
}
