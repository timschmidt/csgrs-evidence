use hyperinterval::{RealBall,BallRelation};
use hyperreal::{Rational,Real};
pub fn fixture(case:u32) -> (RealBall,Real,i32) {
 let r=|n,d| Rational::fraction(n,d).unwrap();
 match case {
 0..=3 => {
   let b=RealBall::new(Real::from(2),r(1,2)).unwrap();
   let q=match case {0=>r(2,1),1=>r(5,2),2=>r(3,1),_=>r(-1,1)};
   (b,Real::from(q),-16)
 }
 4..=11 => {
   let b=RealBall::new(Real::from(-1),Rational::one()).unwrap().affine(&r(-1,3),&Real::from(r(1,3)));
   let q=match case {4=>r(1,3),5=>r(1,1),6=>r(997,3000),7=>r(1003,3000),8=>r(1001,1000),9=>r(999,1000),10=>r(1,3),_=>r(1,1)};
   (b,Real::from(q),if case<10 {0}else{-128})
 }
 12..=17 => {
  let center=Real::from(2).sqrt().unwrap();let q=if case==12 {center.clone()}else if case==13||case==16{Real::zero()}else{Real::from(r(7,5))};
  (RealBall::new(center,if case<=13{r(1,3)}else{Rational::zero()}).unwrap(),q,if case==14{0}else{-64})
 }
 _ => {
  let shift=Real::from(2).powi_i64(256).unwrap();let b=RealBall::new(shift.clone(),r(1,3)).unwrap();
  (b,shift+Real::from(if case==18 {r(1,3)}else{r(-1,3)}),-32)
 }
 }
}
pub fn observe(b:&RealBall,q:&Real,p:i32)->u32 {
 match b.classify_point(q,p).unwrap(){BallRelation::Contained=>1,BallRelation::Excluded=>2,BallRelation::Unresolved=>3}
}
#[unsafe(no_mangle)]
pub extern "C" fn ball_verdict(case:u32)->u32 {let (b,q,p)=fixture(case);observe(&b,&q,p)}
