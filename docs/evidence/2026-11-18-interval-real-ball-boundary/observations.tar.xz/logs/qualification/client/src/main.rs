use std::{hint::black_box,time::Instant};
fn main(){
 for i in 0..20 {
  let (b,q,p)=ball_client::fixture(i);
  let verdict=ball_client::observe(&b,&q,p);
  #[cfg(feature="trace")] {
   hyperreal::dispatch_trace::reset();let outcome=hyperreal::dispatch_trace::with_recording(||ball_client::observe(&b,&q,p));
   assert_eq!(verdict,outcome);println!("TRACE|{i}|{verdict}|{:?}",hyperreal::dispatch_trace::take_trace());
  }
  let reps=2000;
  let t=Instant::now();for _ in 0..reps {black_box(ball_client::observe(black_box(&b),black_box(&q),p));}
  println!("WARM|{i}|{verdict}|{reps}|{}",t.elapsed().as_nanos());
  let t=Instant::now();for _ in 0..reps {black_box(ball_client::ball_verdict(black_box(i)));}
  println!("FRESH|{i}|{verdict}|{reps}|{}",t.elapsed().as_nanos());
 }
}
