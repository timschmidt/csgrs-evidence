use hyperinterval::RealBall;
use hyperreal::{Real,Rational};
use std::sync::{Arc,atomic::{AtomicBool,Ordering}};
#[test]
fn signal_transport() {
    for warm in [false,true] {
        for reverse in [false,true] {
            for center in [0,7] {
                let mut root = Real::from(2).sqrt().unwrap();
                let shift = Real::from(Rational::fraction(center,5).unwrap());
                let radius=Rational::fraction(1,4).unwrap();
                if warm { assert!(root.certified_rational_interval(-64).is_some()); }
                let sig=Arc::new(AtomicBool::new(true)); root.abort(sig.clone());
                assert!(root.certified_rational_interval(-64).is_none());
                let (point,c)=if reverse{(&shift,&root)}else{(&root,&shift)};
                let ball=RealBall::new(c.clone(),radius).unwrap();
                let displacement=point-c;
                let active=displacement.certified_rational_interval(-64);
                let verdict=ball.classify_point(point,-64);
                sig.store(false,Ordering::Relaxed);
                let recheck=ball.classify_point(point,-64);
                println!("warm={warm},reverse={reverse},center={center}, displacement={active:?}, verdict={verdict:?}, retry={recheck:?}");
            }
        }
    }
}
