from pathlib import Path
from statistics import median
import subprocess,platform,json
s=Path(__file__).parent
for i in range(18):
 for v in (['before','fallback'] if i%2==0 else ['fallback','before']):
  (s/'timing2'/f'{i}-{v}').write_bytes(subprocess.check_output(['setarch',platform.machine(),'-R','taskset','-c','5',s/'images'/f'{v}-native']))
values={}
for p in (s/'timing2').iterdir():
 i,v=p.name.split('-')
 for l in p.read_text().splitlines():
  kind,idx,verdict,reps,ns=l.split('|');k=(kind,idx)
  values.setdefault(k,{}).setdefault(v,{})[int(i)]=int(ns)/int(reps)
out={}
for k,r in values.items():
 a,b=r['before'],r['fallback'];delta=[100*(b[i]/a[i]-1) for i in a]
 out['|'.join(k)]={'before':median(a.values()),'fallback':median(b.values()),'median_paired_pct':median(delta),'slower_pairs':sum(x>0 for x in delta)}
(s/'timing2-summary.json').write_text(json.dumps(out,indent=2)+'\n')
