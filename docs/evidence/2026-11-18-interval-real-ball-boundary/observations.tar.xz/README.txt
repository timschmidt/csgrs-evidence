Phase 3 public real-ball membership and composed enclosure review, 2026-11-18 UTC
Fixed program c9f1f9ac5. Primary comparison d36d2b5c8. Retained tests 7584d3163.
Fallback and three maintained failing or missing witnesses live on 4f05060aa.
The direct and late patches each apply independently to the primary.
Set up the working directory as /dev/shm/interval-real-ball-boundary and clone a detached
csgrs subdirectory at the desired revision. Restore the three Cargo packages from
logs/qualification to the working directory. Put the Rust 1.95.0 offline environment,
shared owner Cargo target and RSS helper at the locations in build.sh, or adjust those
paths to local equivalents. Use bash build.sh VERSION KIND for native, trace, test,
life, usable and wasm. In fixed/before cases the WASM oracle expects the old outcomes.
Each executable is freshly linked from the same consumer source. All six images per
revision are hashed. portable-images includes all five WASM modules plus before and
fallback native timing clients. build output JSON contains temporary paths.
Run metrics.py after building all images and collecting the raw logs. For fresh timing,
run timing.py and timing2.py on pinned CPUs 3 and 5 respectively. Timing outputs are
stored under timing/first and timing/second here. Each independently alternates order
for 18 paired processes and each case has 2000 calls per measurement. The observer's
FRESH includes construction, query, and drop. WARM reuses the inputs.
Case order and independent expected results are in client/src/lib.rs and check.cjs.
Cases 15 and 17 repeat the same symbolic contract. No firmware deployment is claimed.
Peak stack is measured from the outer call boundary in a guarded worker, with two paint
patterns and 16 process repetitions. Absolute headroom includes the guard and prelude.
Raw traces include exact dispatch counters and rational counters, separate from timing.
A comparison over changed outcomes is a raw resource observation, not same-work speed.
Initially the fixed usable invocation lacked /usr/bin/time. fixed-usable-retry and
fixed-rss record its successful replacement with the same Python observer as the others.
