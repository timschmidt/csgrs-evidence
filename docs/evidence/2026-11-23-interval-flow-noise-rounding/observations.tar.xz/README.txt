Correlated flow endpoint rounding (csgrs 43842984e) and relative column cutoff (the following commit), against 0fb217b13.
noise_probe.rs: focused probe (temporary example, not committed). Arguments are noise caps; ROUND=1 enables
  round_coefficients and CUT=k sets column_cutoff_bits. Wall-clock seconds on one 40-core host; probe-final.txt
  ran while size builds compiled, so its timings are indicative only.
probe1.txt: exact coefficients at caps 0..64 (pre-change behavior). probe-round.txt: rounding. probe-cut.txt: rounding plus
  cutoffs 16, 32 and 48. probe-final.txt: the committed candidate in all three modes.
nr-round.json / nr-cut.json: hyperdynamics artifact sizes, rounding against main and cutoff against rounding, Rust 1.100.0,
  all features, default profiles, one path and target directory (collect-nr.sh); quick.sh measured intermediate variants.
noise-validate.log: local Hyperdynamics workflow commands on stable.
