//! Temporary probe: endpoint width and cost across fixed noise-column caps.
use hyperdynamics::field::{
    EnclosureBudget, EnclosurePolicy, ExpressionField, FieldDefinition,
    evolution::EvolutionOptions,
    taylor_flow::noise::{
        FlowNoiseState,
        evolution::{FlowNoiseEvolutionOptions, FlowNoiseEvolutionStatus},
    },
};
use hyperinterval::DyadicInterval;
use hyperlattice_interval::BoxN;
use hypersolve::{
    Expr, SymbolId,
    expression_program::{ExpressionBudget, ExpressionProgram},
};
use std::{sync::Arc, time::Instant};

fn d(lo: i64, hi: i64, e: i32) -> DyadicInterval {
    DyadicInterval::new(lo.into(), hi.into(), e).unwrap()
}
fn f<B: std::fmt::Display>(v: Option<(&B, i32)>) -> f64 {
    let (m, e) = v.unwrap();
    m.to_string().parse::<f64>().unwrap() * 2f64.powi(e)
}
fn widths<const N: usize>(b: &BoxN<DyadicInterval, N>) -> Vec<f64> {
    b.lanes()
        .unwrap()
        .iter()
        .map(|i| f(i.upper()) - f(i.lower()))
        .collect()
}
fn field<const N: usize>(rhs: impl Fn(&[Expr], &Expr) -> Vec<Expr>) -> ExpressionField<N> {
    let time = SymbolId(1);
    let state: Vec<SymbolId> = (0..N).map(|i| SymbolId(10 + i as u32)).collect();
    let vars: Vec<Expr> = state.iter().map(|s| Expr::anonymous_symbol(*s)).collect();
    let mut inputs = state.clone();
    inputs.push(time);
    let source = ExpressionProgram::compile(
        &rhs(&vars, &Expr::anonymous_symbol(time)),
        &inputs,
        &mut ExpressionBudget::new(1_000_000, 10_000_000),
    )
    .unwrap();
    ExpressionField::from_definition(
        FieldDefinition {
            source: source.definition().clone(),
            time,
            state,
        },
        &mut EnclosureBudget::new(EnclosurePolicy::default()),
    )
    .unwrap()
}
fn run<const N: usize>(
    name: &str,
    field: &ExpressionField<N>,
    initial: [DyadicInterval; N],
    end: DyadicInterval,
    order: usize,
    step: DyadicInterval,
    caps: &[usize],
) {
    for &cap in caps {
        let mut budget = EnclosureBudget::new(EnclosurePolicy::default());
        let program = field.flow_taylor(order, &mut budget).unwrap();
        let state = Arc::new(
            FlowNoiseState::new(d(0, 0, 0), BoxN::new(initial.clone()).unwrap(), &mut budget)
                .unwrap(),
        );
        let start = Instant::now();
        let report = program.integrate_noise(
            state,
            end.clone(),
            FlowNoiseEvolutionOptions {
                maximum_noise: cap,
                round_coefficients: std::env::var("ROUND").is_ok(),
                column_cutoff_bits: std::env::var("CUT").ok().map(|v| v.parse().unwrap()),
                native: EvolutionOptions {
                    maximum_step: Some(step.clone()),
                    maximum_steps: 4096,
                    ..Default::default()
                },
            },
            &mut budget,
        );
        let elapsed = start.elapsed().as_secs_f64();
        let ok = matches!(report.status(), FlowNoiseEvolutionStatus::Completed);
        if !ok {
            let msg = format!("{:?}", report.status());
            println!("  status: {}", &msg[..msg.len().min(400)]);
        }
        if std::env::var("SHOW").is_ok() {
            for (i, seg) in report.segments().enumerate() {
                if let Some(e) = seg.end_state() {
                    let c = format!("{:?}", e.center());
                    let cols = format!("{:?}", e.columns());
                    println!(
                        "  seg {i} center_dbg_len={} columns_dbg_len={} residual={:?}",
                        c.len(),
                        cols.len(),
                        e.residual().map(|r| r
                            .iter()
                            .map(|x| format!("{:?}", x).len())
                            .collect::<Vec<_>>())
                    );
                    if i == 0 {
                        println!("  center0={}", &c[..c.len().min(600)]);
                    }
                }
            }
        }
        let last = report.end_state().or(report.prefix_end_state()).unwrap();
        let cols: Vec<usize> = report
            .segments()
            .map(|s| {
                s.end_state()
                    .and_then(|e| e.columns())
                    .map_or(0, |c| c.len())
            })
            .collect();
        println!(
            "{name:12} cap={cap:3} ok={ok} segs={:4} maxcols={:3} t={:?} secs={elapsed:.3} widths={:?}",
            report.segments().len(),
            cols.iter().max().unwrap_or(&0),
            f(last.time().lower()),
            widths(last.enclosure())
                .iter()
                .map(|w| format!("{w:.3e}"))
                .collect::<Vec<_>>()
        );
    }
}
fn main() {
    let caps: Vec<usize> = std::env::args()
        .skip(1)
        .map(|a| a.parse().unwrap())
        .collect();
    // Rotation: the classic wrapping-effect case.
    let rot = field::<2>(|v, _| vec![v[1].clone(), Expr::int(-1) * v[0].clone()]);
    run(
        "rotation",
        &rot,
        [d(1023, 1025, -10), d(-1, 1, -10)],
        d(8, 8, 0),
        6,
        d(1, 1, -3),
        &caps,
    );
    // Van der Pol, mu = 1.
    let vdp = field::<2>(|v, _| {
        vec![
            v[1].clone(),
            (Expr::int(1) - v[0].clone() * v[0].clone()) * v[1].clone() - v[0].clone(),
        ]
    });
    run(
        "vanderpol",
        &vdp,
        [d(1399, 1401, -10), d(2399, 2401, -10)],
        d(4, 4, 0),
        6,
        d(1, 1, -4),
        &caps,
    );
    // Lotka-Volterra.
    let lv = field::<2>(|v, _| {
        vec![
            v[0].clone() * (Expr::int(2) - v[1].clone()),
            v[1].clone() * (v[0].clone() - Expr::int(1)),
        ]
    });
    run(
        "lotka",
        &lv,
        [d(1023, 1025, -10), d(511, 513, -9)],
        d(6, 6, 0),
        6,
        d(1, 1, -4),
        &caps,
    );
    // Two coupled linear oscillators (4D).
    let co = field::<4>(|v, _| {
        vec![
            v[1].clone(),
            Expr::int(-2) * v[0].clone() + v[2].clone(),
            v[3].clone(),
            v[0].clone() - Expr::int(2) * v[2].clone(),
        ]
    });
    run(
        "coupled4",
        &co,
        [
            d(1023, 1025, -10),
            d(-1, 1, -10),
            d(-1, 1, -10),
            d(1023, 1025, -10),
        ],
        d(6, 6, 0),
        6,
        d(1, 1, -3),
        &caps,
    );
    // Lorenz (sigma 10, rho 28, beta 8/3), short horizon.
    let lz = field::<3>(|v, _| {
        vec![
            Expr::int(10) * (v[1].clone() - v[0].clone()),
            v[0].clone() * (Expr::int(28) - v[2].clone()) - v[1].clone(),
            v[0].clone() * v[1].clone() - (Expr::int(8) / Expr::int(3)) * v[2].clone(),
        ]
    });
    run(
        "lorenz",
        &lz,
        [
            d(15359, 15361, -10),
            d(15359, 15361, -10),
            d(36863, 36865, -10),
        ],
        d(1, 1, 0),
        6,
        d(1, 1, -7),
        &caps,
    );
}
