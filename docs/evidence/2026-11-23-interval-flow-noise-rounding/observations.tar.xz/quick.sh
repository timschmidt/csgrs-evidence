#!/bin/bash
# quick.sh REV : build hyperdynamics flow_noise and flow_noise_evolution examples at REV in .rc-wt, compare with base
set -e; cd /mnt/development/.rc-wt; git checkout -q --detach $1; export CARGO_TARGET_DIR=/mnt/development/.rc-target
cargo build --locked -q --release -p hyperdynamics --all-features --example flow_noise --example coordinates 2>&1 | grep -E "^error" || true
python3 - <<PY
exec(open('/tmp/claude-1000/-mnt-development/374ec7d8-3b58-4db7-a419-a5fe884f8bb0/scratchpad/be/prev/sizes.py').read().split('d=Path(sys.argv[1])')[0])
from pathlib import Path
for n in ['flow_noise','coordinates']:
    a=sizes(Path(f'/mnt/development/.nr-bins/example.hyperdynamics.{n}.x-base')); c=sizes(Path(f'/mnt/development/.rc-target/release/examples/{n}'))
    print('$1',n,{k:c[k]-a[k] for k in a})
PY
