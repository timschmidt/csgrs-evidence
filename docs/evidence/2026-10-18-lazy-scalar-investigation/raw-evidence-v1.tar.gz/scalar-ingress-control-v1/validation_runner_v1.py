"""Use the original baselines with an explicit 24-GiB temporary-artifact cap."""
import json,sys
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'sign-cache-publication-control-v1'))
import validation_runner_v4_local as inherited
import validation_runner_v3 as base
contract=json.loads((W/'tmp-contract-v1.json').read_text())
assert contract['initial_free_bytes']==67482746880 and contract['storage_baseline_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
    result=[r for r in previous_reasons(sample) if r!='tmp_net_consumption_12_gib']
    if contract['initial_free_bytes']-sample['tmp_free_bytes']>contract['net_consumption_limit_bytes']:
        result.append('tmp_net_consumption_24_gib')
    return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
