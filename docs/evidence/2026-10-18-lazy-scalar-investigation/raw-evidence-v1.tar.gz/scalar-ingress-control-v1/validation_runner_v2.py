"""Storage-only 24-to-32 GiB migration; all original baselines retained."""
import json,sys
from pathlib import Path
W=Path(__file__).resolve().parent
import validation_runner_v1 as inherited
import validation_runner_v3 as base
contract=json.loads((W/'tmp-contract-v2.json').read_text())
assert contract['initial_free_bytes']==67482746880 and contract['storage_baseline_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
    result=[r for r in previous_reasons(sample) if r!='tmp_net_consumption_24_gib']
    if contract['initial_free_bytes']-sample['tmp_free_bytes']>contract['net_consumption_limit_bytes']:
        result.append('tmp_net_consumption_32_gib')
    return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
