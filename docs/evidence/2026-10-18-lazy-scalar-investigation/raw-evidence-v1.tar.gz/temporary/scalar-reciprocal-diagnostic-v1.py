import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,N,U,compiler,sha,dump
h=Harness('reciprocal-diagnostic-v1',W/'source-pins-v4.json.gz')
lib=json.loads((N/'real-serde-payload-boundary-v2/result-v1.json').read_text())['libraries']['repair']
assert sha(lib['frozen_copy'])==lib['sha256']
src=Path('/tmp/scalar-reciprocal-probe-v1.rs');binary=U/'probes/scalar-reciprocal-v1'
h.execute('compile',[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',src,'--extern','hyperreal='+lib['frozen_copy'],'-L','dependency='+lib['deps'],'-o',binary],limit=60)
out,err,r=h.execute('run',[binary],binary=True,limit=60)
dump(h.R/'result-v1.json',{'source_sha256':sha(src),'binary_sha256':sha(binary),'library':lib,'stdout':out,'stderr':err,'commands':h.commands})
print(out,flush=True)
