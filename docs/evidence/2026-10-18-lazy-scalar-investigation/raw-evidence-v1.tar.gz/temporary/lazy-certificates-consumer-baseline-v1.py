import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,dump
h=Harness('lazy-consumer-baseline-v1',W/'source-pins-v3.json.gz')
keys=h.build('build',['test','--locked','--offline','--release','-p','hyperlimit','--features','serde','--test','lazy_scalar_certificates'])
assert len(keys)==1
rows,_,_,_=h.test('run',keys[0],allow_failure=True,limit=60)
dump(h.R/'result-v1.json',{'summary':rows,'commands':h.commands,'production_source_changed':False})
assert rows==[('FAILED','0','1','0','0','0')],rows
print(json.dumps({'strict_consumer_regression_reproduced':True}),flush=True)
