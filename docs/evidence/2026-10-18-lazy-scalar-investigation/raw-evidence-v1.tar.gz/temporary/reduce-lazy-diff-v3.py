"""Restore unrelated rustfmt edits in include!-owned source files."""
from pathlib import Path
import subprocess,re
root=Path('crates/hyperreal/src/real')
changed=subprocess.check_output(['git','diff','--name-only','--',str(root)]).decode().splitlines()
updated={}
for name in changed:
 p=Path(name);base=subprocess.check_output(['git','show','HEAD:'+name]).decode().replace('AtomicPrimitiveApproxCache','RealCaches');current=p.read_text()
 if p.name=='classification.rs':
  base=base.replace('/// Lock-free cache for lossy primitive conversions.','/// Per-value caches for primitive conversions and a lazily reconstructed graph.')
  base=base.replace("/// can represent the empty and overflow states without increasing `Real`'s\n/// layout. A tagged negative-NaN range carries cached finite `f32` values;","/// can represent the primitive empty and overflow states in one atomic word.\n/// A tagged negative-NaN range carries cached finite `f32` values;")
  base=base.replace('pub(super) struct RealCaches(std::sync::atomic::AtomicU64);',current[current.index('pub(super) struct RealCaches {'):current.index('\nimpl RealCaches {')].strip())
  lo=base.index('impl RealCaches {');hi=base.index('impl Default for RealCaches {');body=base[lo:hi].replace('self.0','self.primitive')
  body=body.replace('Self(std::sync::atomic::AtomicU64::new(Self::encode(value)))','Self {\n            primitive: std::sync::atomic::AtomicU64::new(Self::encode(value)),\n            computable: std::sync::OnceLock::new(),\n        }')
  base=base[:lo]+body+base[hi:]
  clone=current[current.index('impl Clone for RealCaches {'):current.index('impl std::fmt::Debug for RealCaches {')]
  base=base.replace('impl std::fmt::Debug for RealCaches {',clone+'impl std::fmt::Debug for RealCaches {')
 elif p.name=='representation.rs':
  base=base.replace('primitive_approx_cache: RealCaches::new(\n                self.primitive_approx_cache.get(),\n            ),','primitive_approx_cache: self.primitive_approx_cache.clone(),')
  lo=base.index('    fn computable_ref(');hi=base.index('    pub(super) fn abort_signal(')
  base=base[:lo]+current[current.index('    fn computable_ref('):current.index('    pub(super) fn abort_signal(')]+base[hi:]
  base+='\n'+current[current.index('#[cfg(test)]\nmod computable_access_tests {'):]
 elif p.name=='quadratic_tower_sign.rs':
  base=base.replace('let payload = self.computable_ref().clone();','let payload = self.computable_clone();')
 else:
  # Apart from the intended private type rename, rustfmt changed whitespace
  # and trailing list commas. No test assertions or expressions changed.
  reference=Path('/tmp/csgrs-scalar-ingress-20261018-v1/probes/format-reference-v1')/p.name
  reference.parent.mkdir(exist_ok=True)
  assert not reference.exists();reference.write_text(base)
  subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config-path','crates/.rustfmt.toml','--config','skip_children=true',str(reference)],check=True)
  assert reference.read_text()==current,name
 updated[p]=base
for p,s in updated.items():p.write_text(s)
print('Restored unrelated formatting; retained the cache implementation.',flush=True)
