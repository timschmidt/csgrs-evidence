"""Reproduce certificate/domain failures separately under the retained limits."""
import gzip,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'scalar-ingress-control-v1'
sys.path.insert(0,str(W))
from cargo_harness_v1 import Harness,compiler,sha,dump,U
h=Harness('diagnostics-v1',W/'source-pins-v1.json.gz')
lib=json.loads((N/'real-serde-payload-boundary-v2/result-v1.json').read_text())['libraries']['repair']
assert sha(lib['frozen_copy'])==lib['sha256']
inputs={str(p):sha(p) for p in sorted(Path(lib['deps']).iterdir()) if p.is_file()}
source=Path('/tmp/scalar-ingress-probe-v1.rs');source_sha=sha(source)
binary=U/'probes/scalar-ingress-v1'
h.execute('compile',[compiler['additional_environment']['RUSTC'],'--crate-name','scalar_ingress_probe','--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+lib['frozen_copy'],'-L','dependency='+lib['deps'],'-o',binary],limit=60)
digest=sha(binary)
cases=['valid-pi','pi-negative-payload','pi-zero-payload','one-negative-payload','exp-zero','sqrt-zero','sqrt-negative','sqrt-square','ln-one','sin-pi-zero','opaque-negative-root','opaque-inverse-zero','opaque-zero-times-negative-root']
observations={}
for case in cases:
 out,err,r=h.execute(case,[binary,case],binary=True,limit=60)
 observations[case]={'stdout':out,'stderr':err}
 assert sha(binary)==digest and sha(source)==source_sha
assert all(sha(p)==v for p,v in inputs.items())
assert sha(lib['frozen_copy'])==lib['sha256']
(h.R/'dependency-inputs-v1.json.gz').write_bytes(gzip.compress((json.dumps(inputs,sort_keys=True)+'\n').encode(),mtime=0))
dump(h.R/'result-v1.json',{'revision':'0fa83aea7aae9d57a578da0cf28299f12ca75409','source_sha256':source_sha,'binary_sha256':digest,'library':lib,'dependency_inputs':len(inputs),'observations':observations,'commands':h.commands,'production_source_changed':False,'affine_admitted':False})
print(json.dumps(observations,indent=2),flush=True)
