use hyperreal::{Rational,Real};
fn fraction(numerator: i64, denominator: u64) -> Real {
    Real::from(Rational::fraction(numerator, denominator).unwrap())
}

// Every named certificate, constructed through the public API. Bounds follow
// from 3 < pi < 22/7, 8/3 < e < 11/4, 7/5 < sqrt(2) < 3/2,
// monotonicity, and the defining power/logarithm identities.
fn certificates() -> Vec<(&'static str, Real, i64, i64)> {
    let pi = Real::pi();
    let e = Real::e();
    let pi_squared = &pi * &pi;
    let sqrt_two = Real::from(2).sqrt().unwrap();
    let ln_two = Real::from(2).ln().unwrap();
    let ln_three = Real::from(3).ln().unwrap();
    vec![
        ("One", fraction(3, 2), 1, 2),
        ("Pi", pi.clone(), 3, 4),
        ("PiPow", pi_squared.clone(), 9, 10),
        ("PiInv", pi.clone().inverse().unwrap(), 0, 1),
        ("PiExp", &pi * &e, 8, 9),
        ("PiInvExp", (&e / &pi).unwrap(), 0, 1),
        ("PiSqrt", &pi * &sqrt_two, 4, 5),
        ("ConstProduct", &pi_squared * &e, 24, 28),
        ("ConstOffset", &pi - Real::from(3), 0, 1),
        ("ConstProductSqrt", &(&pi_squared * &e) * &sqrt_two, 33, 42),
        ("Sqrt", sqrt_two, 1, 2),
        ("Exp", Real::from(2).exp().unwrap(), 7, 8),
        ("Ln", ln_three.clone(), 1, 2),
        ("LnAffine", (Real::from(2) * &e).ln().unwrap(), 1, 2),
        ("LnProduct", &ln_two * &ln_three, 0, 2),
        ("Log10", Real::from(2).log10().unwrap(), 0, 1),
        ("Log2", Real::from(3).log2().unwrap(), 1, 2),
        ("Pow10", fraction(1, 3).exp10().unwrap(), 2, 3),
        ("Pow2", fraction(1, 3).exp2().unwrap(), 1, 2),
        ("SinPi", fraction(1, 5).sin_pi(), 0, 1),
        ("TanPi", fraction(1, 5).tan_pi().unwrap(), 0, 1),
    ]
}


fn main() {
    for (name,value,_,_) in certificates() {
        let product=&value*value.inverse_ref().unwrap();
        println!("{name}\tequality={:?}\tnormal={:?}",product.certified_eq_until(&Real::one(),-128),product.exact_rational_normal_form());
    }
}
