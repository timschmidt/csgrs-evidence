import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,N,U,compiler,sha,dump
h=Harness('owned-fold-diagnostic-v1',W/'source-pins-v7.json.gz')
lib=json.loads((N/'real-serde-payload-boundary-v2/result-v1.json').read_text())['libraries']['repair']
assert sha(lib['frozen_copy'])==lib['sha256']
source=Path('/tmp/lazy-owned-fold-probe-v1.rs');binary=U/'probes/lazy-owned-fold-v1'
h.execute('compile',[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+lib['frozen_copy'],'-L','dependency='+lib['deps'],'-o',binary],limit=60)
out,err,_=h.execute('run',[binary],binary=True,limit=60)
dump(h.R/'result-v1.json',{'library':lib,'source_sha256':sha(source),'binary_sha256':sha(binary),'stdout':out,'stderr':err,'commands':h.commands,'compared_revision':'0fa83aea7aae9d57a578da0cf28299f12ca75409'})
print(out,flush=True)
