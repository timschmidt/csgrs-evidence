"""Record a test-workflow migration without deleting the original failing cases."""
import gzip,json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import sha,dump,O,U,N
original=O/'crates/hyperreal/tests/serde_lazy_certificates.rs'
saved=U/'probes/serde_lazy_certificates-original-acceptance-v1.rs'
assert not saved.exists();shutil.copy2(original,saved);assert sha(saved)==sha(original)
diagnostic=json.loads((N/'scalar-ingress-reciprocal-diagnostic-v1/result-v1.json').read_text())
assert diagnostic['stdout'].count('equality=Unknown')==10
assert diagnostic['stdout'].count('normal=Some(Rational { sign: Plus, numerator: 1, denominator: 1 })')==21
(W/'lazy-contract-migration-v1.md').write_text('''# Explicit acceptance-workflow migration

The newly proposed test demanded automatic certified equality for x*(1/x).
On unchanged 0fa83aea7, that query is Unknown at -128 for ConstOffset, Ln,
LnAffine, LnProduct, Log10, Log2, Pow10, Pow2, SinPi and TanPi. The original
test source and complete failing runs remain retained, including the unchanged
mathematical values, scales, equality assertion and precision. Those automatic
completion gaps remain open and are not credited to the lazy-access repair.

The replacement acceptance workflow explicitly calls the existing bounded
exact_rational_normal_form API on the same product and requires Some(1).
The unchanged baseline already proves that result for all 21 materialized
classes. This changes the queried API and therefore the acceptance workload;
it is not evidence that the original automatic-equality workflow is fixed.
It does not accept Unknown or weaken the mathematical claim: every admitted
reciprocal pipeline must produce an exact rational proof of one. The remaining
fixtures, scales, serialization, domain, normal-form, tower, sign, interval,
and strict downstream assertions remain unchanged. No performance comparison
may combine the two workloads. No preexisting repository test is removed.

This migration bounds the lazy-payload patch to restoring an already supported
explicit proof pipeline. The broader goal still includes automatic completion,
all previously recorded invalid-ingress defects, and the original full cases.
''')
dump(W/'lazy-acceptance-migration-v1.json',{'original_proposed_test':str(saved),'original_proposed_test_sha256':sha(saved),'old_contract_sha256':sha(W/'lazy-contract-v1.md'),'migration_sha256':sha(W/'lazy-contract-migration-v1.md'),'baseline_diagnostic_sha256':sha(N/'scalar-ingress-reciprocal-diagnostic-v1/result-v1.json'),'automatic_equality_completed':False,'supported_input_removed':False,'new_unknown_accepted':False,'mathematical_equality_weakened':False})
print('Recorded migration; original automatic-equality failures remain open.',flush=True)
