"""Prepare bounded diagnostics of serialized scalar invariants on the committed revision."""
import ast,gzip,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
OLD=N/'real-serde-payload-control-v1'
W=N/'scalar-ingress-control-v1'
U=Path('/tmp/csgrs-scalar-ingress-20261018-v1')
sys.path.insert(0,str(OLD))
from validation_runner_v1 import resources,reasons,sha,dump
assert not reasons(resources())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=O).decode().strip()=='0fa83aea7aae9d57a578da0cf28299f12ca75409'
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
pins=json.loads(gzip.decompress((OLD/'source-pins-v4.json.gz').read_bytes()))
assert len(pins)==2656 and all(sha(O/p)==h for p,h in pins.items())
assert not W.exists() and not U.exists()
W.mkdir();U.mkdir()
for name in ['target','cargo-home','gmp-cache','xdg-cache','scratch','frozen','probes']:(U/name).mkdir()
for name in ['index','cache','src']:(U/'cargo-home/registry'/name).mkdir(parents=True,exist_ok=True)
(U/'cargo-home/config.toml').write_text('[net]\noffline = true\n[cache]\nauto-clean-frequency = "never"\n')
for name in ['tmp-contract-v1.json','validation_runner_v1.py','registry-inputs-v1.json.gz']:
 shutil.copy2(OLD/name,W/name);assert sha(OLD/name)==sha(W/name)
shutil.copy2(OLD/'source-pins-v4.json.gz',W/'source-pins-v1.json.gz')
source=(OLD/'cargo_harness_v1.py').read_text().replace('Actual-source Cargo validation for the required opaque-payload invariant.','Scalar ingress diagnostic and acceptance checks.')
source=source.replace('/tmp/csgrs-real-serde-payload-20261018-v1',str(U)).replace("'real-serde-payload-'","'scalar-ingress-'")
ast.parse(source);(W/'cargo_harness_v1.py').write_text(source)
(W/'contract-v1.md').write_text('''# Scalar ingress investigation

Target revision: 0fa83aea7aae9d57a578da0cf28299f12ca75409.
Owner: Hyperreal serialized Class certificates and Computable expression
domains. Relevant properties P1-P7, P18, P26, P35-P39.

Reproduce unsupported domain and certificate contradictions on unchanged
production before selecting a coherent repair. Every input fixture has an
independent mathematical interpretation. Check typed decoding, sign/zero
evidence, rational intervals and consumption. Panic observations are failures,
not acceptable substitute outcomes. Isolate each potentially nonterminating
case in a bounded process. Do not validate an invalid child by cancellation.

Use the previously qualified frozen all-feature library read-only, verifying
its hash and the current 2656 source inputs. Record compiler and dependency
inputs. Create all new probe outputs here; never overwrite a closed artifact.
No implementation, optimization, performance, complete validation, or release
claim follows from diagnostics alone. Retain adverse observations.

Limits remain root 16 GiB, Disk B 72 GiB, /tmp 24 GiB, cumulative logs 96 MiB,
child address space 8 GiB, at most two jobs, focused 60 seconds and compile/full
suite 1800 seconds. Baselines are unchanged. Hypervoxel is excluded. No push.
''')
dump(W/'preparation-v1.json',{'revision':'0fa83aea7aae9d57a578da0cf28299f12ca75409','helper_sha256':sha(Path(__file__)),'source_pins_sha256':sha(W/'source-pins-v1.json.gz'),'resources':resources(),'target_initially_empty':not any((U/'target').iterdir()),'existing_artifacts_mutated':False})
print(json.dumps({'prepared':str(W),'resources':resources()}),flush=True)
