import ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
old=N/'real-serde-payload-control-v1';W=N/'scalar-ingress-control-v1'
s=(old/'scalar_v2.py').read_text().replace('cargo_harness_v1','cargo_harness_v2').replace("'scalar-v2'","'scalar-v1'").replace('source-pins-v4.json.gz','source-pins-v7.json.gz').replace("'817'","'819'").replace("'tmp_allowance_gib':24","'tmp_allowance_gib':32")
s=s.replace("O/'crates/hyperreal/tests/serde_payload.rs',O/'crates/hypercurve/tests/svg_scalar_failures.rs'","O/'crates/hyperreal/tests/serde_lazy_certificates.rs',O/'crates/hyperlimit/tests/lazy_scalar_certificates.rs'")
s=s.replace('against the actual required-payload repair','against retained lazy reconstruction')
ast.parse(s);p=W/'scalar_v1.py';assert not p.exists();p.write_text(s)
s=(old/'consumers_v2.py').read_text().replace('cargo_harness_v1','cargo_harness_v2').replace("'consumers-v2'","'consumers-v1'").replace('source-pins-v4.json.gz','source-pins-v7.json.gz').replace('real-serde-payload-scalar-v2','scalar-ingress-scalar-v1')
ast.parse(s);p=W/'consumers_v1.py';assert not p.exists();p.write_text(s)
s=(old/'msrv_v2.py').read_text().replace('real-serde-payload-control-v1','scalar-ingress-control-v1').replace('csgrs-real-serde-payload-20261018-v1','csgrs-scalar-ingress-20261018-v1').replace('real-serde-payload-consumers-v2','scalar-ingress-consumers-v1').replace('cargo_harness_v1.py','cargo_harness_v2.py').replace('target-msrv-v2','target-msrv-v1').replace('payload_msrv_harness_v2','lazy_msrv_harness_v1').replace("'msrv-v2'","'msrv-v1'").replace('source-pins-v4.json.gz','source-pins-v7.json.gz')
ast.parse(s);p=W/'msrv_v1.py';assert not p.exists();p.write_text(s)
print('Prepared full scalar, affected consumer and compiler-floor checks.',flush=True)
