"""Reproduce lazy-certificate regressions before production edits."""
import gzip,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2');W=N/'scalar-ingress-control-v1'
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,sha,dump,O
pins=json.loads(gzip.decompress((W/'source-pins-v1.json.gz').read_bytes()))
assert all(sha(O/p)==h for p,h in pins.items())
for p in ['crates/hyperreal/tests/serde_lazy_certificates.rs','crates/hyperlimit/tests/lazy_scalar_certificates.rs']:pins[p]=sha(O/p)
pf=W/'source-pins-v3.json.gz';assert not pf.exists();pf.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
h=Harness('lazy-baseline-v2',pf)
keys=h.build('build',['test','--locked','--offline','-p','hyperreal','--release','--features','serde','--test','serde_lazy_certificates'])
assert len(keys)==1
rows,out,err,r=h.test('run',keys[0],allow_failure=True,limit=60)
dump(h.R/'result-v1.json',{'summary':rows,'commands':h.commands,'production_source_changed':False,'helper_sha256':sha(Path(__file__))})
assert rows==[('FAILED','1','3','0','0','0')],rows
print(json.dumps({'valid_control_passed':1,'lazy_regressions':3}),flush=True)
