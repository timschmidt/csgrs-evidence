"""Preserve and reject the costly cache candidate before the owned-fold repair."""
import difflib,gzip,hashlib,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=N/'scalar-ingress-control-v1';U=Path('/tmp/csgrs-scalar-ingress-20261018-v1')
sys.path.insert(0,str(W))
from validation_runner_v2 import sha,dump,resources,reasons
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(GIT+list(args),cwd=O)
assert git('rev-parse','HEAD').decode().strip()=='0fa83aea7aae9d57a578da0cf28299f12ca75409'
assert not git('diff','--cached','--name-only') and not reasons(resources())
pins=json.loads(gzip.decompress((W/'source-pins-v7.json.gz').read_bytes()))
assert all(sha(O/p)==v for p,v in pins.items())
tracked=git('diff','HEAD','--name-only').decode().splitlines()
assert len(tracked)==13 and all(p.startswith('crates/hyperreal/') for p in tracked)
added=['crates/hyperreal/tests/serde_lazy_certificates.rs','crates/hyperlimit/tests/lazy_scalar_certificates.rs']
protected='docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py'
assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())==set(added+[protected])
assert sha(O/protected)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
folder=U/'rejected-cache-source-v1';assert not folder.exists();folder.mkdir()
patch=[];snapshot={}
for name in sorted(tracked+added):
 source=O/name;dest=folder/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest);assert sha(dest)==pins[name]
 snapshot[name]={'copy':str(dest),'sha256':sha(dest)}
 before=git('show','HEAD:'+name).decode() if name in tracked else ''
 patch.extend(difflib.unified_diff(before.splitlines(True),source.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(W/'rejected-cache-candidate-v1.patch').write_text(''.join(patch))
dump(W/'rejected-cache-snapshot-v1.json',snapshot)
for name in tracked:(O/name).write_bytes(git('show','HEAD:'+name))
for name in added:
 assert sha(O/name)==snapshot[name]['sha256'];(O/name).unlink()
base=json.loads(gzip.decompress((W/'source-pins-v1.json.gz').read_bytes()))
assert len(base)==2656 and all(sha(O/p)==v for p,v in base.items())
assert not git('diff','HEAD','--name-only')
dump(W/'candidate-disposition-v1.json',{'decision':'rejected','source_snapshot':str(W/'rejected-cache-snapshot-v1.json'),'patch_sha256':sha(W/'rejected-cache-candidate-v1.patch'),'source_restored_to':'0fa83aea7aae9d57a578da0cf28299f12ca75409','source_inputs_verified':len(base),'reason':['Matched instrumented probes add one 32-byte allocation per cold primitive conversion and per cached clone; median loop costs regress materially in all four rows.','The warmed graph still loses usable proof through scaling/division/same-class addition.','The owned-fold implementation independently substitutes one for a missing symbolic payload; the cache prototype does not fix that mathematical-value defect.'],'preserved_original_acceptance_workflow':True,'new_runtime_admitted':False,'prepared_consumer_and_msrv_scripts_executed':False,'scalar_candidate_qualification':'936 default, 1055 all-feature tests; 819 debug units; strict Clippy, docs, formatting passed. These results do not override failed composition/cost acceptance.','next':'Repair owned scalar folding by consuming the existing certificate fallback, with independent value bounds, while retaining every unresolved lazy-payload and invalid-ingress case.','resources':resources()})
print(json.dumps({'candidate_rejected':True,'snapshot_files':len(snapshot),'production_restored':True}),flush=True)
