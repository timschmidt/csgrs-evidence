"""Declare lazy-certificate acceptance and an explicit storage-only migration."""
import ast,gzip,json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'scalar-ingress-control-v1';U=Path('/tmp/csgrs-scalar-ingress-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(W))
from validation_runner_v1 import sha,dump,resources,reasons
assert not reasons(resources())
assert not (W/'lazy-contract-v1.md').exists()
(W/'lazy-contract-v1.md').write_text('''# Consumable lazy symbolic certificates

Owner: Hyperreal Real's shared access to an optional Computable payload.
Properties P3, P6, P18, P26, P35-P39. Baseline 0fa83aea7.
The initial diagnostic reproduced a panic for an otherwise valid Pi with a
missing lazy payload: enclosure succeeded, but certified_sign_until(0) failed.
The same unconditional access also serves normal forms and tower operations.

Domain: every valid named Class certificate, with absent or null lazy payload,
and rational outer scales including zero, positive and negative. Irrational
still requires its graph. Use public construction recipes for all 21 named
classes and assert the actual serialized tag. Do not admit forged parameters
or inconsistent graphs by treating them as valid controls.

Restore the existing payload fallback at the shared access layer: borrow an
existing graph and construct from the retained certificate only when missing.
Do not eagerly rewrite serialized fields, discard caches on existing graphs,
duplicate certificate formulas or change mathematical policies. Preserve
serialized bytes across queries. Normal-form and tower consumers must use
the same shared access; borrowed graphs must stay borrowed.

Missing acceptance tests: all named classes through JSON and CBOR with null
and absent payloads; exact signs under signed scaling; independent rational
bounds; follow-on inversion and square-root construction; algebraic normal
forms and tower proofs; repeated queries and serialization. Add an affected
strict Hyperlimit consumer regression with independently known orientation.
Run these tests first on unchanged production, then after the repair. Run
full scalar default/all-feature suites, debug units, strict lint, docs,
formatting, affected Hyperlimit and SVG consumers, and compiler-floor checks.

The separate arbitrary-graph domain and forged-certificate defects remain
open and must remain visible in the evidence. Affine cancellation stays
withheld. No claim of complete scalar ingress validation or performance gain.

Existing graph access should add no clone/allocation. Missing-payload
materialization uses the existing certificate constructor and its costs;
precision limits do not bound this work. External containment remains 8 GiB
per child, two jobs, 60 seconds per focused run, 1800 per build/full suite,
96 MiB cumulative logs. Root 16 GiB and Disk B 72 GiB stay fixed. A separately
recorded /tmp 24-to-32 GiB storage-only migration preserves the original
baseline and all closed artifacts. Hypervoxel excluded; no push.
''')
old=json.loads((W/'tmp-contract-v1.json').read_text())
contract={**old,'path':str(U),'old_net_consumption_limit_bytes':24*1024**3,'net_consumption_limit_bytes':32*1024**3,'minimum_post_allowance_free_bytes':old['initial_free_bytes']-32*1024**3,'previous_contract':str(W/'tmp-contract-v1.json'),'previous_contract_sha256':sha(W/'tmp-contract-v1.json'),'reason':'Preserve all closed targets while validating consumable lazy certificates in a new Cargo target. Storage only; tests, source, precision and other containment are unchanged.','physical_capacity_precheck':resources(),'authorization':'User authorized /tmp validation. The 24 GiB ceiling was agent-selected; increasing it to 32 GiB retains the original baseline and prior artifacts.'}
dump(W/'tmp-contract-v2.json',contract)
runner='''"""Storage-only 24-to-32 GiB migration; all original baselines retained."""
import json,sys
from pathlib import Path
W=Path(__file__).resolve().parent
import validation_runner_v1 as inherited
import validation_runner_v3 as base
contract=json.loads((W/'tmp-contract-v2.json').read_text())
assert contract['initial_free_bytes']==67482746880 and contract['storage_baseline_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
    result=[r for r in previous_reasons(sample) if r!='tmp_net_consumption_24_gib']
    if contract['initial_free_bytes']-sample['tmp_free_bytes']>contract['net_consumption_limit_bytes']:
        result.append('tmp_net_consumption_32_gib')
    return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
'''
ast.parse(runner);(W/'validation_runner_v2.py').write_text(runner)
harness=(W/'cargo_harness_v1.py').read_text().replace('from validation_runner_v1 import','from validation_runner_v2 import').replace('tmp-contract-v1.json','tmp-contract-v2.json').replace("'contract-v1.md'","'lazy-contract-v1.md'").replace("'tmp_allowance_gib':24","'tmp_allowance_gib':32")
ast.parse(harness);(W/'cargo_harness_v2.py').write_text(harness)
registry=json.loads(gzip.decompress((W/'registry-inputs-v1.json.gz').read_bytes()))
assert len(registry)==48478 and all(sha(p)==h for p,h in registry.items())
gmp={}
for p in sorted((V/'gmp-cache-v1').rglob('*')):
 assert not p.is_symlink()
 dest=U/'gmp-cache'/p.relative_to(V/'gmp-cache-v1')
 if p.is_dir():dest.mkdir(exist_ok=True)
 elif p.is_file():
  assert not dest.exists();digest=sha(p);shutil.copy2(p,dest);assert sha(dest)==sha(p)==digest;gmp[str(p)]={'copy':str(dest),'sha256':digest}
dump(W/'native-cache-copy-v1.json',gmp)
dump(W/'lazy-preparation-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'lazy-contract-v1.md'),'tmp_contract_sha256':sha(W/'tmp-contract-v2.json'),'registry_inputs_verified':len(registry),'target_initially_empty':not any((U/'target').iterdir()),'resources':resources()})
print(json.dumps({'prepared':True,'tmp_allowance_gib':32,'registry_inputs_verified':len(registry),'resources':resources()}),flush=True)
