use hyperreal::{Rational, Real};

fn main() {
    let materialized = Real::from(Rational::fraction(1, 5).unwrap()).sin_pi();
    let wire = materialized.to_json();
    let prefix = wire.split_once(",\"computable\":").unwrap().0;
    let value = Real::from_json(&format!("{prefix},\"computable\":null}}")).unwrap();
    value.certified_rational_interval(-64).unwrap();
    println!("warmed-source\t{:?}", (&value * value.inverse_ref().unwrap()).exact_rational_normal_form());
    for (name, result) in [
        ("scale", &value * Real::from(2)),
        ("divide", (&value / Real::from(2)).unwrap()),
        ("add", &value + &value),
    ] {
        println!("{name}\t{:?}", (&result * result.inverse_ref().unwrap()).exact_rational_normal_form());
    }
}
