"""Check the shared payload fallback and affected strict consumer."""
import gzip,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,sha,dump,O
old=json.loads(gzip.decompress((W/'source-pins-v5.json.gz').read_bytes()))
changes=['crates/hyperreal/src/real/arithmetic/representation.rs','crates/hyperreal/src/real/arithmetic/quadratic_tower_sign.rs','crates/hyperreal/README.md']
assert all(sha(O/p)==h for p,h in old.items() if p not in changes)
pins={p:sha(O/p) for p in old}
pf=W/'source-pins-v6.json.gz';assert not pf.exists();pf.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
h=Harness('lazy-focused-v1',pf);summaries={}
for package,target,count in [('hyperreal','serde_lazy_certificates',4),('hyperlimit','lazy_scalar_certificates',1)]:
 keys=h.build(package+'-build',['test','--locked','--offline','--release','-p',package,'--features','serde','--test',target]);assert len(keys)==1
 rows,_,_,_=h.test(package+'-run',keys[0],limit=60)
 assert rows==[('ok',str(count),'0','0','0','0')],rows
 summaries[package]=rows
dump(h.R/'result-v1.json',{'passed':True,'summaries':summaries,'commands':h.commands,'source_pins_sha256':sha(pf),'contract_migration_sha256':sha(W/'lazy-contract-migration-v1.md')})
print(json.dumps({'focused_passed':True,'summaries':summaries}),flush=True)
