use hyperreal::Real;
use std::io::Write;
use std::panic::{AssertUnwindSafe, catch_unwind};

fn rational(value: i64) -> String {
    let numerator = if value == 0 { "[]".into() } else { format!("[{}]", value.unsigned_abs()) };
    format!(r#"{{"sign":{},"numerator":{},"denominator":[1]}}"#, value.signum(), numerator)
}

fn integer(value: i64) -> String {
    let magnitude = if value == 0 { "[]".into() } else { format!("[{}]", value.unsigned_abs()) };
    format!(r#"{{"internal":{{"Int":[{},{}]}}}}"#, value.signum(), magnitude)
}

fn main() {
    let case = std::env::args().nth(1).expect("case name");
    let (class, graph, interval) = match case.as_str() {
        "valid-pi" => ("\"Pi\"".into(), "null".into(), true),
        "pi-negative-payload" => ("\"Pi\"".into(), integer(-7), true),
        "pi-zero-payload" => ("\"Pi\"".into(), integer(0), true),
        "one-negative-payload" => ("\"One\"".into(), integer(-7), true),
        "exp-zero" => (format!(r#"{{"Exp":{}}}"#, rational(0)), "null".into(), true),
        "sqrt-zero" => (format!(r#"{{"Sqrt":{}}}"#, rational(0)), "null".into(), true),
        "sqrt-negative" => (format!(r#"{{"Sqrt":{}}}"#, rational(-1)), "null".into(), true),
        "sqrt-square" => (format!(r#"{{"Sqrt":{}}}"#, rational(4)), "null".into(), true),
        "ln-one" => (format!(r#"{{"Ln":{}}}"#, rational(1)), "null".into(), true),
        "sin-pi-zero" => (format!(r#"{{"SinPi":{}}}"#, rational(0)), "null".into(), true),
        "opaque-negative-root" => ("\"Irrational\"".into(), format!(r#"{{"internal":{{"Sqrt":{}}}}}"#, integer(-1)), true),
        "opaque-inverse-zero" => ("\"Irrational\"".into(), format!(r#"{{"internal":{{"Inverse":{}}}}}"#, integer(0)), false),
        "opaque-zero-times-negative-root" => ("\"Irrational\"".into(), format!(r#"{{"internal":{{"Multiply":[{},{{"internal":{{"Sqrt":{}}}}}]}}}}"#, integer(0), integer(-1)), true),
        _ => panic!("unknown case"),
    };
    let json = format!(r#"{{"rational":{},"class":{},"computable":{}}}"#, rational(1), class, graph);
    println!("fixture\t{json}");
    let value = match Real::from_json(json) {
        Ok(value) => { println!("decode\tOk"); value },
        Err(error) => { println!("decode\t{error:?}"); return },
    };
    println!("zero\t{:?}", catch_unwind(AssertUnwindSafe(|| value.zero_status())));
    std::io::stdout().flush().unwrap();
    if interval {
        println!("sign\t{:?}", catch_unwind(AssertUnwindSafe(|| value.certified_sign_until(0))));
        println!("interval\t{:?}", catch_unwind(AssertUnwindSafe(|| value.certified_rational_interval(-16))));
    }
}
