use hyperreal::Real;

fn main() {
    let json = r#"{"rational":{"sign":1,"numerator":[1],"denominator":[1]},"class":"Pi","computable":null}"#;
    let input = Real::from_json(json).unwrap();
    let output = input.exp().unwrap();
    println!("pi-exp\t{:?}", output.certified_rational_interval(-32));
    let input = Real::from_json(json).unwrap();
    let output = input.asinh().unwrap();
    println!("pi-asinh\t{:?}", output.certified_rational_interval(-32));
}
