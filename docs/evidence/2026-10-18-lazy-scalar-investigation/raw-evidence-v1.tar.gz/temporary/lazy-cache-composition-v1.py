import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,N,U,compiler,sha,dump
h=Harness('cache-composition-v1',W/'source-pins-v7.json.gz')
lib=json.loads((N/'scalar-ingress-cache-cost-v2/result-v1.json').read_text())['libraries']['candidate']
assert sha(lib['probe_library'])==lib['sha256']
outputs={}
for label,source in [('composition','/tmp/lazy-cache-composition-probe-v1.rs'),('owned-fold','/tmp/lazy-owned-fold-probe-v1.rs')]:
 binary=U/'probes'/('cache-'+label+'-v1')
 h.execute(label+'-compile',[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+lib['probe_library'],'-L','dependency='+lib['deps'],'-o',binary],limit=60)
 out,err,_=h.execute(label+'-run',[binary],binary=True,limit=60)
 outputs[label]={'stdout':out,'stderr':err,'source_sha256':sha(source),'binary_sha256':sha(binary)}
dump(h.R/'result-v1.json',{'library':lib,'outputs':outputs,'commands':h.commands,'cache_candidate_admitted':False})
print(json.dumps(outputs,indent=2),flush=True)
