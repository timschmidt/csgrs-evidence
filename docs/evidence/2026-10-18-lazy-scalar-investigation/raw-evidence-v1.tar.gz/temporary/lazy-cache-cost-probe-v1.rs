use hyperreal::{Rational, Real};
use std::alloc::{GlobalAlloc, Layout, System};
use std::hint::black_box;
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::time::Instant;

struct Counted;
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
static FREES: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

unsafe impl GlobalAlloc for Counted {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            ALLOCS.fetch_add(1, Relaxed);
            BYTES.fetch_add(layout.size(), Relaxed);
            let live = LIVE.fetch_add(layout.size(), Relaxed) + layout.size();
            PEAK.fetch_max(live, Relaxed);
        }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        FREES.fetch_add(1, Relaxed);
        LIVE.fetch_sub(layout.size(), Relaxed);
        unsafe { System.dealloc(pointer, layout) };
    }
}

#[global_allocator]
static ALLOCATOR: Counted = Counted;

const COUNT: usize = 1_000_000;

fn measure(name: &str, mut operation: impl FnMut() -> u64, expected: u64) {
    let before = LIVE.load(Relaxed);
    PEAK.store(before, Relaxed);
    ALLOCS.store(0, Relaxed);
    FREES.store(0, Relaxed);
    BYTES.store(0, Relaxed);
    let start = Instant::now();
    let mut checksum = 0_u64;
    for _ in 0..COUNT {
        checksum = checksum.wrapping_add(black_box(operation()));
    }
    let elapsed = start.elapsed().as_nanos();
    let allocs = ALLOCS.load(Relaxed);
    let frees = FREES.load(Relaxed);
    let bytes = BYTES.load(Relaxed);
    let retained = LIVE.load(Relaxed) as i128 - before as i128;
    let peak = PEAK.load(Relaxed) - before;
    assert_eq!(checksum, expected.wrapping_mul(COUNT as u64));
    println!("{name}\t{COUNT}\t{elapsed}\t{allocs}\t{frees}\t{bytes}\t{retained}\t{peak}\t{checksum}");
}

fn main() {
    println!("layout\t{}", std::mem::size_of::<Real>());
    let value = Real::from(Rational::fraction(15, 4).unwrap());
    let wire = value.to_json();
    measure("exact-clone", || {
        let copy = black_box(&value).clone();
        assert_eq!(copy.exact_rational_ref(), value.exact_rational_ref());
        1
    }, 1);
    measure("primitive-cold", || {
        let copy = black_box(&value).clone();
        copy.to_f64_lossy().unwrap().to_bits()
    }, 3.75_f64.to_bits());
    assert_eq!(value.to_json(), wire);
    assert_eq!(value.to_f64_lossy(), Some(3.75));
    measure("primitive-warm", || {
        black_box(&value).to_f64_lossy().unwrap().to_bits()
    }, 3.75_f64.to_bits());
    measure("primitive-warm-clone", || {
        black_box(&value).clone().to_f64_lossy().unwrap().to_bits()
    }, 3.75_f64.to_bits());
    assert_eq!(value.to_json(), wire);
    println!("completed\tcertified-dyadic-input\texact-binary64-output\tunchanged-wire");
}
