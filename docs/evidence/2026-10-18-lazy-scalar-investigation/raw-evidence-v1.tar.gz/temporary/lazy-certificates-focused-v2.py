"""Validate retained reconstruction, preserving the failed ephemeral candidate."""
import gzip,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,sha,dump,O
old=json.loads(gzip.decompress((W/'source-pins-v6.json.gz').read_bytes()))
allowed={'crates/hyperreal/README.md','crates/hyperreal/src/real/convert.rs'}
allowed.update('crates/hyperreal/src/real/arithmetic/'+n+'.rs' for n in ['classification','representation','quadratic_tower_sign','add_sub','linear_algebra','elementary_functions','inversion','mul_div','format_parse','canonical_constants','facts'])
assert all(sha(O/p)==v for p,v in old.items() if p not in allowed)
pins={p:sha(O/p) for p in old}
pf=W/'source-pins-v7.json.gz';assert not pf.exists();pf.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'retained-reconstruction-v1.md').write_text('''# Retained reconstruction

The first candidate used a temporary Cow fallback. It removed the original
panic but failed the unchanged explicit normal-form workflow for lazy SinPi:
an enclosure warmed a temporary graph that the subsequent inverse could not
reuse. That candidate and its 2-pass/2-fail result are retained.

The second candidate stores one reconstructed graph per Real in a OnceLock,
beside its existing primitive cache, renamed RealCaches. Existing materialized
graphs remain borrowed. Borrowed, cloned and consuming access share the same
graph; cloning a cache shares its immutable node and retained proofs. Serde
still skips this cache, so a null/missing optional payload keeps its wire form.
The cache is owned by the Real, has no global key or eviction, and drops with
its owner. OnceLock synchronizes initialization. At most one entry is retained;
this is not a byte limit. The graph can grow with its certificate and refinement.
No new internal total-work/cancellation bound is claimed; external containment
stays fixed. Inline layout and retained graph costs must be reported, not called
an optimization. The common native constructor edits only rename the private
cache type; no mathematical formulas or policies change.
''')
h=Harness('lazy-focused-v2',pf);summaries={}
for package,target,count in [('hyperreal','serde_lazy_certificates',4),('hyperlimit','lazy_scalar_certificates',1)]:
 keys=h.build(package+'-build',['test','--locked','--offline','--release','-p',package,'--features','serde','--test',target]);assert len(keys)==1
 rows,_,_,_=h.test(package+'-run',keys[0],limit=60)
 assert rows==[('ok',str(count),'0','0','0','0')],rows
 summaries[package]=rows
dump(h.R/'result-v1.json',{'passed':True,'summaries':summaries,'commands':h.commands,'source_pins_sha256':sha(pf),'contract_migration_sha256':sha(W/'lazy-contract-migration-v1.md')})
print(json.dumps({'focused_passed':True,'summaries':summaries}),flush=True)
