"""Matched, instrumented allocation probes; this is not a corpus speedup claim."""
import gzip,json,shutil,statistics,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/scalar-ingress-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v2 import Harness,N,O,U,cargo,compiler,sha,dump
h=Harness('cache-cost-v2',W/'source-pins-v7.json.gz')
dump(h.R/'contract-v1.json',{'kind':'matched instrumented allocation probes','source_sha256':sha('/tmp/lazy-cache-cost-probe-v1.rs'),'iterations_per_row':1000000,'rounds':5,'order_per_round':['baseline','candidate','candidate','baseline'],'workloads':['exact-clone','primitive-cold','primitive-warm','primitive-warm-clone'],'input':'exact Rational(15/4)','assertions':['exact f64 bits for 3.75','exact clone equality','unchanged serialized input before/after'],'timing':'entire loop including checksum, allocator accounting and drop; excludes input construction and final printing','no_general_speedup_claim':True,'features':'all features on both libraries','runtime_limit_per_process_seconds':60})
out,_,_=h.execute('all-library',[cargo,'build','--release','--locked','--offline','-p','hyperreal','--all-features','--message-format=json'])
libs={'baseline':json.loads((N/'real-serde-payload-boundary-v2/result-v1.json').read_text())['libraries']['repair']}
for line in out.splitlines():
 if line.startswith('{'):
  row=json.loads(line)
  if row.get('reason')=='compiler-artifact' and row['target']['name']=='hyperreal' and row['target']['kind']==['lib']:
   paths=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
   if paths:
    assert len(paths)==1;p=paths[0];libs['candidate']={'frozen_copy':str(p),'deps':str(p.parent if p.parent.name=='deps' else p.parent/'deps'),'sha256':sha(p),'features':row['features']}
assert libs['candidate']['features']==libs['baseline']['features']
binaries={};dep_inputs={};source=Path('/tmp/lazy-cache-cost-probe-v1.rs')
for variant,lib in libs.items():
 assert sha(lib['frozen_copy'])==lib['sha256']
 folder=h.A/variant;folder.mkdir();copy=folder/Path(lib['frozen_copy']).name;shutil.copy2(lib['frozen_copy'],copy);assert sha(copy)==lib['sha256']
 lib['probe_library']=str(copy)
 for p in Path(lib['deps']).iterdir():
  if p.is_file() and p.suffix in ['.rlib','.rmeta','.so']:dep_inputs[str(p)]=sha(p)
 binary=U/'probes'/('cache-cost-'+variant+'-v2')
 h.execute(variant+'-compile',[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+str(copy),'-L','dependency='+lib['deps'],'-o',binary],limit=60)
 frozen=folder/'probe';shutil.copy2(binary,frozen);assert sha(frozen)==sha(binary);binaries[variant]={'path':str(frozen),'sha256':sha(frozen)}
samples=[]
for round in range(5):
 for ordinal,variant in enumerate(['baseline','candidate','candidate','baseline']):
  binary=binaries[variant];assert sha(binary['path'])==binary['sha256']
  out,err,r=h.execute(f'round-{round}-{ordinal}-{variant}',[binary['path']],binary=True,limit=60)
  assert not err and out.splitlines()[-1]=='completed\tcertified-dyadic-input\texact-binary64-output\tunchanged-wire'
  rows=[]
  for line in out.splitlines()[1:-1]:
   fields=line.split('\t');assert len(fields)==9
   rows.append(dict(zip(['case','iterations','elapsed_ns','allocations','deallocations','allocated_bytes','retained_bytes','peak_additional_bytes','checksum'],[fields[0]]+[int(x) for x in fields[1:]])))
  samples.append({'round':round,'ordinal':ordinal,'variant':variant,'layout_bytes':int(out.splitlines()[0].split('\t')[1]),'rows':rows})
assert all(sha(p)==v for p,v in dep_inputs.items())
for v,b in binaries.items():assert sha(b['path'])==b['sha256']
(h.R/'dependency-inputs-v1.json.gz').write_bytes(gzip.compress((json.dumps(dep_inputs,sort_keys=True)+'\n').encode(),mtime=0))
dump(h.R/'result-v1.json',{'passed':True,'samples':samples,'libraries':libs,'binaries':binaries,'commands':h.commands,'source_sha256':sha(source),'instrumented_timing_only':True,'no_general_speedup_claim':True})
print(json.dumps({'samples':len(samples),'layouts':{v:next(x['layout_bytes'] for x in samples if x['variant']==v) for v in libs}}),flush=True)
