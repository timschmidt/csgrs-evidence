from pathlib import Path
import re
s=Path(__file__).resolve().parent;txt=(s/'measure-final.py').read_text()
txt=txt.replace("  env=os.environ.copy()","  if kind=='asan':continue\n  env=os.environ.copy()")
txt=txt.replace("(s/'image-sizes.json').write_text(json.dumps(r,indent=2))","""(s/'verified-release-images.json').write_text(json.dumps(r,indent=2))
old=json.loads((s/'image-sizes.json').read_text())
assert all(d==old[n] for n,d in r.items()),[(n,d,old[n]) for n,d in r.items() if d!=old[n]]""")
txt=txt.replace("s/f'image-{tag}-{kind}.log'","s/f'verified-{tag}-{kind}.log'")
exec(compile(txt,str(s/'verify-images.py'),'exec'))
