from pathlib import Path
import json
s=Path(__file__).resolve().parent
size=json.loads((s/'image-sizes.json').read_text())
account={'fixed_interface':'abfb182eb79dda1edec2bbd7316f3b7a1f6e6973','source_interface':(s/'source-revision').read_text().strip(),'evidence':'docs/evidence/2026-11-19-interval-machine-travel-uncertainty','scope':'First size registration for these unshipped Linux conformance tools. Each target shares its fixed baseline across future charges. The campaign process limit is 1536 MiB per worker. It does not describe firmware memory or flash.','metrics':['final ELF bytes','allocated .text bytes','nonoverlapping defined text-function bytes'],'targets':{}}
for name,vs in size.items():
 base,last=vs['before'],vs['after']
 if name=='alumina_interface_fuzz':
  assert base==last
  continue
 asan=name in ['machine_profile','machine_lowering']
 inc,ip,cum,cp,slot,reserve=(262144,5,524288,10,128*2**20,32*2**20) if asan else (32768,2,65536,4,64*2**20,16*2**20)
 obj={'incremental_cap_bytes_percent':[inc,ip],'cumulative_cap_bytes_percent':[cum,cp],'slot_and_required_reserve_bytes':[slot,reserve],'free_slot_bytes':slot-last['file'],'metrics':{}};assert obj['free_slot_bytes']>=reserve
 for m in ['file','code','functions']:
  b,a=base[m],last[m];d=a-b;p=max(d,0);step=min(inc,b*ip//100);total=min(cum,b*cp//100);assert p<=step<=total
  obj['metrics'][m]={'before':b,'after':a,'delta':d,'delta_percent':round(100*d/b,4),'positive_charge':p,'remaining_cumulative_bytes':total-p}
 account['targets'][name]=obj
(s/'account.json').write_text(json.dumps(account,indent=2)+'\n')
f=s.parent/'csgrs/docs/research/interval-size-accounts.json';old=f.read_text();a=json.loads(old);key='machine_travel_qualification'
assert key not in a
end=old.rfind('}');new=old[:end].rstrip()+',\n'+json.dumps({key:account},indent=2)[2:-2]+'\n}\n';assert json.loads(new)==a|{key:account};f.write_text(new)
