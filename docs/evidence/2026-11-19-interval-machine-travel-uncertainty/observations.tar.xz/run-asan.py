from pathlib import Path
import hashlib,json,os,subprocess,sys,time
s=Path(__file__).resolve().parent;r=s.parent/'alumina-interface/fuzz'
for target in ['machine_profile','machine_lowering']:
 dest=s/(target+'-final-work');dest.mkdir(exist_ok=True);assert not list(dest.iterdir())
 exe=s/'asan/x86_64-unknown-linux-gnu/debug'/target
 size=json.loads((s/'image-sizes.json').read_text())[target]['after']
 assert hashlib.file_digest(exe.open('rb'),'sha256').hexdigest()==size['sha256']
 cmd=[str(exe),str(dest),str(s/(target+'-new')),str(r/'seeds'/target),'-max_len=64','-seed=20261119','-max_total_time=45','-runs=4096','-timeout=10','-rss_limit_mb=1536','-artifact_prefix='+str(s)+'/']
 with (s/(target+'-final-asan.log')).open('w') as f:
  proc=subprocess.Popen(cmd,cwd=r,stdout=f,stderr=subprocess.STDOUT);_,status,usage=os.wait4(proc.pid,0);proc.returncode=os.waitstatus_to_exitcode(status);assert proc.returncode==0
 (s/(target+'-rss.log')).write_text(json.dumps({'command':cmd,'maxrss_KiB':usage.ru_maxrss,'user_s':usage.ru_utime,'system_s':usage.ru_stime,'ASAN_OPTIONS':os.environ['ASAN_OPTIONS']})+'\n')
