from pathlib import Path
import collections,hashlib,json,subprocess as sp
s=Path(__file__).resolve().parent
for n in ['machine_profile','machine_lowering']:
 (s/(n+'-new')).mkdir(exist_ok=True);(s/(n+'-work')).mkdir(exist_ok=True)
def save(target,inputs):
 out=s/(target+'-new')
 for d in inputs:
  data=bytes(d);(out/hashlib.sha256(data).hexdigest()).write_bytes(data)
save('machine_profile',([32,axis,15,3,1,0,0,0,0,0,code] for axis in range(2) for code in range(256)))
save('machine_lowering',([32,axis,15,6,1,budget,0,0,0,0,code] for axis in range(2) for budget in [0,1] for code in [0,1,63,127,128,129,135,136,137]))
