from pathlib import Path
import json, shutil, statistics, subprocess as p, time
s=Path(__file__).resolve().parent;r=s.parent/'alumina-interface';rows={}
def run(tag,target,where):
 t=time.monotonic_ns();out=p.check_output([s/('replay-'+tag),target,where]).decode().strip();return out,(time.monotonic_ns()-t)/1e6
for target in ['machine_profile','machine_lowering']:
 group=s/'legacy'/target;group.mkdir(exist_ok=True,parents=True)
 singles=s/'single';singles.mkdir(exist_ok=True)
 paths=p.check_output(['git','-C',r,'ls-tree','-r','--name-only','abfb182','--','fuzz/seeds/'+target]).decode().splitlines()
 rec={};rows[target]=rec
 for path in paths:
  data=p.check_output(['git','-C',r,'show','abfb182:'+path]);assert (r/path).read_bytes()==data
  (group/Path(path).name).write_bytes(data);(singles/'input').write_bytes(data)
  before=run('before',target,singles)[0];after=run('after',target,singles)[0];assert before==after
  rec.setdefault('unchanged_outcomes',{})[Path(path).name]=after
 observed=run('after',target,group)[0];rec['legacy_counts']=observed
 for tag in ['before','after']:rec[tag+'_ms']=[]
 for i in range(51):
  for tag in (['before','after'] if i%2==0 else ['after','before']):
   out,dt=run(tag,target,group);assert out==observed;rec[tag+'_ms'].append(dt)
 rec['medians_ms']=[round(statistics.median(rec[tag+'_ms']),3) for tag in ['before','after']]
 for n,where in [('new',s/(target+'-new')),('retained',r/'fuzz/seeds'/target)]:
  rec[n+'_counts']=run('after',target,where)[0]
 print(target,len(paths),rec['medians_ms'],rec['new_counts'],flush=True)
(s/'replays.json').write_text(json.dumps(rows,indent=2)+'\n')
