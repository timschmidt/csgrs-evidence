from pathlib import Path
import os,subprocess as p,shutil
s=Path(__file__).resolve().parent;r=s/'workspace/alumina-interface';f=r/'crates/alumina-interface-core/src/machine_profile.rs';orig=p.check_output(['git','-C',r,'show','HEAD:'+str(f.relative_to(r))]).decode(); assert f.read_text()==orig
env=os.environ|{'CARGO_TARGET_DIR':str(s/'mutant')}; lower='lower: numerator_lower / &travel_metres_per_output_turn.upper';upper='upper: numerator_upper / &travel_metres_per_output_turn.lower';mm='upper: &self.upper / divisor,'
def check(name,opts,changes,status):
 t=orig
 for a,b in changes:
  assert t.count(a)==1;t=t.replace(a,b)
 f.write_text(t)
 with (s/(name+'.log')).open('w') as log:
  result=p.run(['cargo','+1.95.0','test','--release','--locked','--test','reachability',*opts],cwd=r/'fuzz',env=env,stdout=log,stderr=p.STDOUT)
 assert result.returncode==status
 if status: assert 'assertion `left == right` failed' in (s/(name+'.log')).read_text()
for n in ['fuzz/src/lib.rs','fuzz/tests/reachability.rs']:
 p.run(['git','-C',r,'restore','--',n],check=True)
try:
 check('legacy-mm-mutant',[],[(mm,mm.replace('.upper','.nominal'))],0)
 for n in ['fuzz/src/lib.rs','fuzz/tests/reachability.rs']:shutil.copyfile(s.parent/'alumina-interface'/n,r/n)
 for name,a,b in [('lower',lower,lower.replace('.upper','.nominal')),('upper',upper,upper.replace('.lower','.nominal')),('mm',mm,mm.replace('.upper','.nominal'))]:
  check('final-mutant-'+name,['one_eighth_travel_uncertainty_selects_opposite_density_endpoints'],[(a,b)],101)
 check('final-mutation-restored',[],[],0)
finally:f.write_text(orig)
