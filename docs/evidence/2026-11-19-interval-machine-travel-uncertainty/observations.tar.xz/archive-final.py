from pathlib import Path
import json,subprocess as sp,re
from record import record
s=Path(__file__).resolve().parent;r=s.parent/'alumina-interface';source=(s/'source-revision').read_text().strip()
def read(n):return (s/n).read_text()
names='''accepted-final.log account.json account.py asan-final-build.log replays-first.json replay-paired.py replay-paired.log paired-cpu.txt cross-checkout-cache-failure.log shared-target-old-test.log verified-release-images.json verify-images.py verified-before-release.log verified-after-release.log release-size-verify.log caps.txt clippy-final.log corpus.py current-accepted.log docs-final.log final-mutation-restored.log final-mutant-lower.log final-mutant-upper.log final-mutant-mm.log first-image.json format-final.log host.log image-after-asan.log image-after-release.log image-before-asan.log image-before-release.log image-sizes.json image-summary.log legacy-mm-mutant.log measure-final.py mutate-final.py mutant-old.log pinned-accepted.log record.py red.log replay-final.log replay-final.py replays.json revisions.log run-asan.py second-image.json source.patch source-revision toolchains.log conditions.txt lockfiles.json archive-final.py'''.split()
for n in ['pinned-accepted.log','current-accepted.log','accepted-final.log','final-mutation-restored.log']:
 assert 'test result: ok. 10 passed' in read(n)
for n,c in [('pinned-accepted.log',147),('current-accepted.log',251)]:
 assert re.search(rf'825 (?:transform cases|full transform outputs) and {c} range (?:cases|checks) passed in each of two fresh instances',read(n)) and '4369 measurement cases passed in each of two fresh instances' in read(n)
assert '5 passed' in read('legacy-mm-mutant.log') and '5 passed' in read('mutant-old.log')
assert all('assertion `left == right` failed' in read('final-mutant-'+m+'.log') for m in ['lower','upper','mm'])
assert 'Finished' in read('clippy-final.log') and 'Finished' in read('docs-final.log')
items=[s/n for n in names]
for t in ['machine_profile','machine_lowering']:
 for suffix in ['final-asan.log','rss.log','saved-generated-final.log','seeds-final.log']:
  items.append(s/(t+'-'+suffix))
 assert 'Done ' in read(t+'-final-asan.log')
 items.extend((s/(t+'-final-work')).glob('*'))
for rel in sp.check_output(['git','-C',r,'diff','--name-only','abfb182',source]).decode().splitlines():
 if '/seeds/' in rel:
  p=s/'source-seeds'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((r/rel).read_bytes());items.append(p)
result=record('machine-travel-uncertainty',items,'Archive exact machine travel profile and replay qualification')
(s/'archive-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
