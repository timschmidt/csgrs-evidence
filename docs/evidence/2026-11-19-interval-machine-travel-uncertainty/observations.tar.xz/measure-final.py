from pathlib import Path
import hashlib,json,os,re,subprocess as sp,shutil
s=Path(__file__).resolve().parent;src=s.parent/'alumina-interface';p=s/'tool-image'
def metrics(path):
 text=sp.check_output(['size','-A',path],text=True);code=int(re.search(r'^\.text\s+(\d+)',text,re.M)[1])
 ranges=[]
 for line in sp.check_output(['nm','-S','--defined-only','--radix=d',path],text=True).splitlines():
  fields=line.split(maxsplit=3)
  if len(fields)==4 and fields[2] in ('T','t'):
   addr,size=map(int,fields[:2]);ranges.append((addr,addr+size))
 end=span=0
 for lo,hi in sorted(ranges):
  span+=max(0,hi-max(end,lo));end=max(hi,end)
 return dict(file=path.stat().st_size,code=code,functions=span,sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest())
# Keep one path for the measured package across both builds and use the very
# same dependencies as the normal entry point, including absolute manifest paths.
shutil.copytree(src/'fuzz',p,dirs_exist_ok=True,ignore=shutil.ignore_patterns('target','corpus','artifacts'))
manifest=p/'Cargo.toml';current=manifest.read_text()
manifest.write_text(re.sub(r'path = "(\.\./[^"]+)"',lambda m:'path = "'+str((src/'fuzz'/m[1]).resolve())+'"',current))
r={}
for tag in ['before','after']:
 for name in ['src/lib.rs','tests/reachability.rs']:
  file=src/'fuzz'/name;(p/name).write_bytes(file.read_bytes() if tag=='after' else sp.check_output(['git','-C',src,'show','abfb182:fuzz/'+name]))
 for kind,features,args in [('release',[],['--release','--lib','--tests','--example','replay_corpus']),('asan',['--features','fuzzing'],['--target','x86_64-unknown-linux-gnu','--bins'])]:
  env=os.environ.copy()
  if kind=='asan':env.update(CARGO_TARGET_DIR=str(s/'asan'),CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',RUSTFLAGS='-Zsanitizer=address -Cpasses=sancov-module -Cllvm-args=-sanitizer-coverage-level=3 -Cllvm-args=-sanitizer-coverage-inline-8bit-counters -Cllvm-args=-sanitizer-coverage-pc-table')
  cmd=['cargo','+nightly' if kind=='asan' else '+1.95.0','build','--locked','--message-format=json',*args,*features]
  with (s/f'image-{tag}-{kind}.log').open('w') as f:out=sp.check_output(cmd,cwd=p,env=env,stderr=f,text=True)
  for row in map(json.loads,out.splitlines()):
   exe=row.get('executable')
   if not exe:continue
   n=row['target']['name'];r.setdefault(n,{})[tag]=metrics(Path(exe))
   if n=='replay_corpus':shutil.copy2(exe,s/('replay-'+tag))
(s/'image-sizes.json').write_text(json.dumps(r,indent=2))
for n,rows in r.items():
 f=rows['before'];v=rows['after'];is_asan=n in ['machine_lowering','machine_profile']
 if n=='alumina_interface_fuzz':
  print(n,f['file'],v['file'],'new workload',flush=True)
  continue
 print(n,[(m,v[m]-f[m]) for m in ['file','code','functions']],flush=True)
