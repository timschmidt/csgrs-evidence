use hyperinterval::RationalInterval as I;
use hyperreal::Rational as R;
mod operation;
use operation::image;

fn main() {
    let first: R = "340282366920938463463374607431768211457".parse().unwrap();
    let endpoints = [-(first.clone()), R::fraction(-3,7).unwrap(), R::zero(), R::fraction(11,5).unwrap(), first];
    let factors = [endpoints[0].clone(),R::fraction(-7,3).unwrap(),R::zero(),R::fraction(17,13).unwrap(),endpoints[4].clone()];
    for (i,a) in endpoints.iter().enumerate() {
        for b in &endpoints[i..] {
            let input=I::new(a.clone(),b.clone()).unwrap();
            exercise(&input,&factors);
        }
    }
    exercise(&I::empty(),&factors);
}
fn exercise(input:&I,factors:&[R]) {
    for f in factors {
        for _ in 0..2 {
            #[cfg(feature="trace")]
            {
                use hyperreal::dispatch_trace as trace;
                trace::reset();trace::reset_rational_stats();
                let result=trace::with_recording(|| image(input,f));
                println!("{:?} {}",trace::take_trace(),serde_json::to_string(&result).unwrap());
            }
            #[cfg(not(feature="trace"))]
            {
                let scaled=image(input,f);
                let bytes=serde_json::to_vec(&scaled).unwrap();
                let replay:I=serde_json::from_slice(&bytes).unwrap();
                assert_eq!(scaled,replay);
                println!("{}",serde_json::to_string(&(bytes,replay.affine(&R::new(-1),&R::new(3)))).unwrap());
            }
        }
    }
}
