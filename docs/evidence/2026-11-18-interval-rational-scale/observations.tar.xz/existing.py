from pathlib import Path
import json,os,subprocess,shutil,sys
d=Path(__file__).resolve().parent;w=d/'shipped-src'
r=Path('/mnt/development/csgrs')
if not w.exists():
 w.mkdir()
 with subprocess.Popen(['git','-C',r,'archive','19d0bf698'],stdout=subprocess.PIPE) as c:
    subprocess.run(['tar','xf','-','-m','-C',w],stdin=c.stdout,check=True);assert c.wait()==0
for stage in sys.argv[1:]:
 src=r/'crates/hyperinterval/src/rational.rs'
 if stage!='preceding':shutil.copyfile(src,w/src.relative_to(r))
 env=os.environ|{'CARGO_TARGET_DIR':str(d/'existing-target')}
 for name,flags in [('rational_power_cost',['-p','hyperinterval','--features','rational','--example','rational_power_cost']),('enclosed_program',['-p','hypersolve','--all-features','--example','enclosed_program']),('rational',['-p','hyperinterval','--features','rational,serde,dispatch-trace','--test','rational'])]:
    dest=d/stage;dest.mkdir(exist_ok=True)
    args=['cargo','+1.95.0','build','--locked','--release','--message-format=json-render-diagnostics',*flags]
    with (dest/f'existing-{name}.log').open('w') as log:
        raw=subprocess.check_output(args,cwd=w,env=env,stderr=log,text=True)
    exe=next(j['executable'] for l in raw.splitlines() if (j:=json.loads(l)).get('executable'))
    p=dest/(name+'.elf');shutil.copy2(exe,p)
    if name!='rational_power_cost':
        with (dest/(name+'.output')).open('w') as out:subprocess.run([p],stdout=out,stderr=subprocess.STDOUT,check=True)
