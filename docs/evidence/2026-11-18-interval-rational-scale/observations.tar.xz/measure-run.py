from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,subprocess,sys,statistics,random,math
d=Path(__file__).resolve().parent
stage=sys.argv[1] if len(sys.argv)>1 else 'candidate'
pairs=[('fixed','control'),('preceding','control'),(stage,'control'),(stage,'direct')]
keys=[a+'-'+b for a,b in pairs]
out=d/('resources' if stage=='candidate' else 'resources-'+stage);out.mkdir(exist_ok=True)
def memory(i):
 for stage,variant in (pairs if i%2==0 else pairs[::-1]):
    stem=f'{stage}-{variant}'
    src=d/stage/(variant+'-measure')
    p=out/f'{i}-{stem}.tsv'
    with p.open('w') as f:subprocess.run(['taskset','-c',str(i+1),src],stdout=f,check=True)
with ThreadPoolExecutor(4) as ex:list(ex.map(memory,range(8)))
data={}
for key in keys:
 m={}
 for i in range(8):
    rows=(out/f'{i}-{key}.tsv').read_text().splitlines()
    assert len(rows)==128
    for line in rows:
        rep,case,warm,pattern,*nums=line.split('\t')
        m.setdefault(case+'/'+warm,[]).append(tuple(map(int,nums)))
 assert len(m)==16 and all(len(rs)==64 for rs in m.values())
 data[key]={k:list(map(max,zip(*v))) for k,v in m.items()}
summary={}
for k in data[keys[0]]:
 vals={key:data[key][k] for key in keys}
 fixed,before,same,new=vals.values()
 summary[k]=dict(maxima=vals,implementation_deltas=[a-b for a,b in zip(new,before)],prior_deltas=[a-b for a,b in zip(before,fixed)],unchanged_path_deltas=[a-b for a,b in zip(same,before)])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for k,v in summary.items():print(k,v['implementation_deltas'],v['unchanged_path_deltas'])
