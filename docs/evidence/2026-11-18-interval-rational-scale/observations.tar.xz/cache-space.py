from pathlib import Path
import hashlib,json,os,shutil,tarfile,subprocess
d=Path(__file__).resolve().parent
root=Path('/mnt/development/.interval-refactor-build/horner-current')
files=[]
for ln in (d/'old-registry-cache-dry.log').read_text().splitlines():
 if ln.startswith('/'):
    p=Path(ln)
    assert p.is_relative_to(root) and set(p.relative_to(root).parts)&{'.fingerprint','deps','build'},ln
    if p.is_file():files.append(p)
files=list(dict.fromkeys(files))
assert files
def digest(f):return hashlib.file_digest(f,'sha256').hexdigest()
before={}
tar=d/'registry-intermediates.tar.gz'
with tarfile.open(tar,'w:gz',compresslevel=3,dereference=True) as t:
 for p in files:
    name=str(p.relative_to(root))
    with p.open('rb') as f:before[name]=digest(f)
    t.add(p,arcname=name,recursive=False)
with tarfile.open(tar,'r:gz') as t:assert {m.name:digest(t.extractfile(m)) for m in t}==before
dest=root/'registry-intermediates-2026-11-18.tar.gz'
assert not dest.exists()
usage=shutil.disk_usage(root).free
subprocess.run(['cargo','+stable','clean','--target-dir',root,'-p','wide','-p','criterion','-p','zerocopy','-p','syn','-p','simba','-p','regex-automata','-p','nalgebra'],check=True)
assert shutil.disk_usage(root).free-tar.stat().st_size>=20*1024**3
shutil.copy2(tar,dest)
with tar.open('rb') as f,dest.open('rb') as g:assert digest(f)==digest(g)
print(json.dumps(dict(archive=str(dest),files=len(files),before_free=usage,after_free=shutil.disk_usage(root).free,archive_bytes=dest.stat().st_size)))
