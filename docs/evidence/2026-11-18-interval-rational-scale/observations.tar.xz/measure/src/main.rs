mod allocations;
mod operation;
use hyperinterval::RationalInterval as I;
use hyperreal::Rational as R;
use std::{ffi::{c_int,c_void},hint::black_box,time::Instant};
use operation::image;
unsafe extern "C" { fn measure_stack(cb:unsafe extern "C" fn(*mut c_void),p:*mut c_void,warm:c_int,marker:u8)->usize; }
struct Case {name:&'static str,input:I,factor:R,expected:I,h:Option<allocations::AllocationStats>}
fn cases()->Vec<Case>{
 let wide:R="340282366920938463463374607431768211457".parse().unwrap();
 let giant:R="1e300".parse().unwrap();
 let frac=|a,b|R::fraction(a,b).unwrap();
 let pair=|a,b|I::new(a,b).unwrap();
 let mut v=vec![];
 let mut add=|name,input,factor,expected|v.push(Case{name,input,factor,expected,h:None});
 add("empty",I::empty(),wide.clone(),I::empty());
 add("zero",pair(frac(-11,3),frac(7,3)),R::zero(),I::point(R::zero()));
 add("point",I::point(frac(1,3)),frac(-5,7),I::point(frac(-5,21)));
 add("positive",pair(frac(2,3),frac(5,3)),frac(11,7),pair(frac(22,21),frac(55,21)));
 add("negative",pair(frac(-7,3),frac(-2,3)),frac(-11,7),pair(frac(22,21),frac(77,21)));
 add("crossing",pair(frac(-7,3),frac(11,3)),frac(-5,7),pair(frac(-55,21),frac(5,3)));
 add("wide",pair(R::new(-3)/&wide,R::new(11)/&wide),-&wide/R::new(7),pair(frac(-11,7),frac(3,7)));
 add("giant",pair(R::new(-3)/&giant,R::new(11)/&giant),-&giant/R::new(7),pair(frac(-11,7),frac(3,7)));
 v
}
unsafe extern "C" fn complete(p:*mut c_void){
 let c=unsafe {&mut *p.cast::<Case>()};
 c.h=Some(allocations::once(||{
    let answer=image(black_box(&c.input),black_box(&c.factor));
    assert_eq!(answer,c.expected);
    drop(black_box(answer));
 }));
}
unsafe extern "C" fn noop(_: *mut c_void) {}
fn main(){
 let mut v=cases();
 if let Some(n)=std::env::args().nth(1){
    let loops:usize=n.parse().unwrap();
    for c in &v{
        assert_eq!(image(&c.input,&c.factor),c.expected);
        let start=Instant::now();
        for _ in 0..loops{drop(black_box(image(black_box(&c.input),black_box(&c.factor))));}
        println!("{}\t{}\t{}",c.name,loops,start.elapsed().as_nanos());
    }
 }else{
    for marker in [0xa5,0x5a] { eprintln!("noop\t{marker}\t{}",unsafe {measure_stack(noop,std::ptr::null_mut(),0,marker)}); }
    for rep in 0..4{
        for warm in [0,1] { for pattern in [0xa5,0x5a] {for c in &mut v{
          let stack=unsafe{measure_stack(complete,(c as *mut Case).cast(),warm,pattern)};
          assert!(stack>512 && stack<2097152-4096);
          let h=c.h.take().unwrap();
          println!("{rep}\t{}\t{warm}\t{pattern}\t{stack}\t{}\t{}\t{}\t{}\t{}\t{}",c.name,h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);
        }}}
    }
 }
}
