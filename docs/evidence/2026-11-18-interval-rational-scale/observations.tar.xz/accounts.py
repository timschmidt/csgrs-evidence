import hashlib,json
from pathlib import Path
from sizes import metrics
d=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
p=r/'docs/research/interval-size-accounts.json'
s=json.loads(p.read_text())
assert 'borrowed_rational_scalar' not in s
rows={}
for name,v in json.loads((d/'layout-size-review.json').read_text()).items():
    assert not v['failed']
    vals=v['measured']
    row={}
    for metric in ('file','code','functions'):
        fixed,preceding,existing,direct=(vals[k][metric] for k in ('fixed-control','preceding-control','layout-control','layout-direct'))
        prior=max(0,preceding-fixed)
        for after in (existing,direct):
            inc=max(0,after-preceding);cum=prior+inc
            assert inc<=4096 and 100*inc<=preceding and cum<=8192 and 100*cum<=2*fixed
        row[metric]=dict(fixed=fixed,preceding=preceding,retained_singleton=existing,retained_scale=direct,
            singleton_charge_bytes=prior+max(0,existing-preceding),scale_charge_bytes=prior+max(0,direct-preceding),
            remaining_singleton_bytes=8192-prior-max(0,existing-preceding),remaining_scale_bytes=8192-prior-max(0,direct-preceding))
    rows[name]=row
harness={}
for pth in sorted([*d.glob('test-wasi-*.wasm'),*d.glob('test-native-*.elf')]):
    m=metrics(pth)
    assert m['file']<=16*1024**2
    harness[pth.name]={'file_bytes':m['file'],'capacity_headroom_bytes':20*1024**2-m['file']}
s['borrowed_rational_scalar']={
    'source_revision':(d/'source-revision').read_text().strip(), 'fixed_revision':s['baseline_commit'],
    'preceding_revision':'19d0bf698', 'evidence':'docs/evidence/2026-11-18-interval-rational-scale',
    'operation':'RationalInterval::scale, exact image of empty or ordered finite rational endpoints by a borrowed rational factor',
    'scope':'Rust 1.99.0 paired native and WASI release consumers. The singleton and direct API are separate completed clients. Each positive delta is charged against its preceding build and fixed baseline. The metadata-bearing WASI file grew even though the executable code shrank.',
    'bounds':{'incremental_bytes':4096,'incremental_percent_of_preceding':1,'cumulative_bytes':8192,'cumulative_percent_of_fixed':2,'capacity_bytes':32*1024**2,'minimum_headroom_bytes':4*1024**2},
    'metrics':'Native code is .text and functions is the union of text-symbol address ranges. WASI code is the code section and functions is the sum of function body payload sizes.',
    'clients':rows, 'new_test_executable':{'max_file_bytes':16*1024**2,'capacity_bytes':20*1024**2,'minimum_headroom_bytes':4*1024**2,'features':'rational,serde,dispatch-trace','measurements':harness},
    'existing_release_consumers':{n:m['delta'] for n,m in json.loads((d/'layout-existing.json').read_text()).items()},
    'firmware':'Alumina clock and FOC enable integer and fixed respectively. Rational requires std and is absent from both normal firmware dependency feature graphs.'}
p.write_text(json.dumps(s,indent=2,ensure_ascii=False)+'\n')
