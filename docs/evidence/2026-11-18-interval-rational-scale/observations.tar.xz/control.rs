use hyperinterval::RationalInterval as I;
use hyperreal::Rational as R;
pub fn image(x:&I,f:&R)->I { x.mul(&I::point(f.clone())) }
