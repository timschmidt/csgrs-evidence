from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-rational-scale'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p):files[str(p.relative_to(d))]=p.read_bytes()
for p in d.iterdir():
 if p.is_file() and (p.suffix in ('.log','.py','.rs','.sh','.tsv','.json','.md','.patch','.txt') or p.name in ('env','scope','layout-scope','source-revision')):
    if p.name in ('client-metadata.json','measure-metadata.json','first-rational.rs'):continue
    add(p)
for kind in ('client','measure'):
 for p in (d/kind).rglob('*'):
    if p.is_file() and p.suffix in ('.rs','.toml','.lock','.c'):add(p)
for stage in ['fixed','preceding','candidate','layout']:
 for p in (d/stage).iterdir():
    if p.suffix in ('.log','.output','.rows','.stderr'):add(p)
    if p.suffix in ('.bin','.elf') or p.name.endswith('-measure'):files[str(p.relative_to(d))+'.sha256']=h(p.read_bytes()).encode()
for sub in ['resources','resources-layout','censored-resources',*[p.name for p in d.glob('time-*-?')]]:
 for p in (d/sub).iterdir():
    if p.is_file():add(p)
for sub in ['final-wasi','admitted-wasi']:
 for p in (d/sub).iterdir():
    if p.is_file() and p.suffix in ('.txt','.log','.json'):add(p)
assert (d/'admitted-wasi/report.json').is_file()
assert '2 passed; 1 failed;' in (d/'mutant.log').read_text()
assert all('3 passed; 0 failed;' in (d/f'run-{t}-{v}.log').read_text() for t in ('wasi','native') for v in ('stable','1.95.0'))
assert (d/'source-revision').read_text().strip()==git(r,'rev-parse','HEAD').decode().strip()
assert not any(x['failed'] for x in json.loads((d/'layout-size-review.json').read_text()).values())
assert not any(any(n>0 for n in v['implementation_deltas']) for v in json.loads((d/'resources-layout/summary.json').read_text()).values())
assert all(v['ci95'][1]<1 for i in (0,1) for v in json.loads((d/f'time-layout-{i}/review.json').read_text()).values())
sha={k:h(v) for k,v in sorted(files.items())}
dest=d/'record';dest.mkdir(exist_ok=True)
with tarfile.open(dest/'observations.tar.xz','w:xz') as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(dest/'observations.tar.xz','r|xz') as t:assert {m.name:h(t.extractfile(m).read()) for m in t}==sha
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(sha,indent=1).encode()))
total=sum(p.stat().st_size for p in dest.iterdir())
assert shutil.disk_usage(e).free-(e/'.git/index').stat().st_size-3*total-1048576>20*1024**3
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(dest,e/record);git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive native and WASI qualification for exact rational scalar scaling')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in dest.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOTS={record:False};row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
print(rev,row,'members',len(sha))
