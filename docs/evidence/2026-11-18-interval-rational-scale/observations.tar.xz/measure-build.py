from pathlib import Path
import subprocess,sys,os,shutil
d=Path(__file__).resolve().parent
stage=sys.argv[1]
env=os.environ|{'CC':'cc','CARGO_TARGET_DIR':str(d/'measure-target')}
for flavor in ['control','direct'] if stage in ('candidate','layout') else ['control']:
 shutil.copyfile(d/(flavor+'.rs'),d/'measure/src/operation.rs')
 with (d/stage/(flavor+'-measure-build.log')).open('w') as err:
  subprocess.run(['cargo','+stable','build','--offline','--locked','--release','--manifest-path',d/'measure/Cargo.toml'],check=True,env=env,stderr=err)
 shutil.copy2(d/'measure-target/release/rational-scale-measure',d/stage/(flavor+'-measure'))
