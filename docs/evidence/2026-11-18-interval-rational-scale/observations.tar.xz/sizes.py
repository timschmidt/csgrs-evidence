from pathlib import Path
import hashlib,io,json,re,subprocess,sys
d=Path(__file__).resolve().parent
def leb(f):
 n=k=0
 while True:
    b=f.read(1)[0];n|=(b&127)<<k
    if b<128:return n
    k+=7
def metrics(p):
 raw=p.read_bytes()
 v={'file':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if raw[:4]==b'\x00asm':
    f=io.BytesIO(raw);f.read(8)
    while kind:=f.read(1):
        size=leb(f);block=io.BytesIO(f.read(size))
        if kind==b'\x0a':
            v['code']=size
            count=leb(block);body_sum=0
            for _ in range(count):
                n=leb(block);body_sum+=n;assert len(block.read(n))==n
            assert block.read()==b'';v['functions']=body_sum
 else:
    v['code']=int(re.search(r'^\.text\s+(\d+)',subprocess.check_output(['size','-A',p],text=True),re.M)[1])
    ranges=[]
    for ln in subprocess.check_output(['nm','-S','--radix=d','--defined-only',p],text=True).splitlines():
        x=ln.split(maxsplit=3)
        if len(x)==4 and x[2] in ('t','T'):ranges.append((int(x[0]),int(x[0])+int(x[1])))
    hi=total=0
    for a,b in sorted(ranges):
        total+=max(0,b-max(hi,a));hi=max(b,hi)
    v['functions']=total
 return v
def review(stage):
 groups={}
 for target in ('x86_64-unknown-linux-gnu','wasm32-wasip1'):
  for trace in ('','-trace'):
    name=target+trace
    vs={}
    for stage_,flavor in [('fixed','control'),('preceding','control'),(stage,'control'),(stage,'direct')]:
        label=stage_+'-'+flavor;stem=flavor+'-'+name
        vs[label]=metrics(next((d/stage_).glob(stem+'.*bin')))
        rows=(d/stage_/(stem+'.rows')).read_bytes()
        assert len(rows.splitlines())==160 and rows==(d/'fixed'/('control-x86_64-unknown-linux-gnu'+trace+'.rows')).read_bytes()
    delta={};charges={}
    for k in ('file','code','functions'):
        a,b,c=[vs[t][k] for t in ['fixed-control','preceding-control',stage+'-direct']]
        delta[k]=c-b;charges[k]=max(0,c-b)+max(0,b-a)
    failed=[k for k in delta if delta[k]>4096 or delta[k]*100>vs['preceding-control'][k] or charges[k]>8192 or charges[k]*100>2*vs['fixed-control'][k]]
    assert all(v['file']+4194304<=33554432 for v in vs.values())
    groups[name]=dict(measured=vs,delta=delta,charges=charges,failed=failed)
    print(name,delta,failed)
 (d/(stage+'-size-review.json')).write_text(json.dumps(groups,indent=2)+'\n')
def main():
 stage=sys.argv[1];review(stage)
 if all((d/stage/(k+'.elf')).exists() for k in ('enclosed_program','rational_power_cost','rational')):
    old={}
    for f in ('enclosed_program','rational_power_cost','rational'):
        a,b=[metrics(d/s/(f+'.elf')) for s in ('preceding',stage)]
        delta={k:b[k]-a[k] for k in ('file','code','functions')}
        old[f]=dict(previous=a,current=b,delta=delta)
        print(f,delta)
    (d/(stage+'-existing.json')).write_text(json.dumps(old,indent=2)+'\n')
if __name__=='__main__':main()
