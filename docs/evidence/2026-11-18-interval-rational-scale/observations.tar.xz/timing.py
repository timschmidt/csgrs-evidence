from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import statistics,math,random,json,subprocess,sys
d=Path(__file__).resolve().parent
stage=sys.argv[1];round_number=int(sys.argv[2]);out=d/f'time-{stage}-{round_number}';out.mkdir()
cpu=[1,3,5,7,11,13,15,17]
def block(i):
 group=[]
 for t,variant in enumerate((['old','new','new','old'] if (i+round_number)%2==0 else ['new','old','old','new'])):
    binary=d/('preceding/control-measure' if variant=='old' else f'{stage}/direct-measure')
    cmd=['taskset','-c',str(cpu[(i+3*round_number)%8]),str(binary),'2200000']
    raw=subprocess.check_output(cmd,text=True,timeout=90)
    (out/f'{i}-{t}-{variant}.tsv').write_text(raw)
    rows={k:int(ns)/int(n) for k,n,ns in (ln.split('\t') for ln in raw.splitlines())}
    assert len(rows)==8
    group.append((variant,rows))
 return group
with ThreadPoolExecutor(8) as pool:blocks=list(pool.map(block,range(8)))
summary={}
rng=random.Random(20261118+round_number)
for name in blocks[0][0][1]:
 diffs=[statistics.mean(math.log(row[name]) for v,row in g if v=='new')-statistics.mean(math.log(row[name]) for v,row in g if v=='old') for g in blocks]
 boot=sorted(math.exp(statistics.mean(rng.choices(diffs,k=8))) for _ in range(10000))
 summary[name]=dict(ratio=math.exp(statistics.mean(diffs)),ci95=[boot[250],boot[9749]],paired_log_ratios=diffs)
(out/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:round(v['ratio'],4) for k,v in summary.items()})
