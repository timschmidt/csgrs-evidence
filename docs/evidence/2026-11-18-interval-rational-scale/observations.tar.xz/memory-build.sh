set -eu
d=/dev/shm/interval-rational-scale
. /dev/shm/interval-horner-readmission/env
for stage in fixed preceding candidate; do
 if [ "$stage" != candidate ]; then
  rev=c9f1f9ac5
  if [ "$stage" = preceding ]; then mv "$d/mem-src" "$d/mem-fixed"; rev=19d0bf698; fi
  mkdir "$d/mem-src"; git archive "$rev" | tar xf - -m -C "$d/mem-src"
 else cp crates/hyperinterval/src/rational.rs "$d/mem-src/crates/hyperinterval/src/rational.rs"; fi
 mkdir -p "$d/$stage"
 python3 "$d/measure-build.py" "$stage"
done
