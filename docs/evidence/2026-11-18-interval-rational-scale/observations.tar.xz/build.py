from pathlib import Path
import json,os,shutil,subprocess,sys
d=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
def run(stage):
  src=d/'src';dest=d/stage;dest.mkdir(exist_ok=True)
  if stage=='preceding':
    shutil.rmtree(src);src.mkdir()
    with subprocess.Popen(['git','-C',r,'archive','19d0bf698'],stdout=subprocess.PIPE) as p:
        subprocess.run(['tar','xf','-','-m','-C',src],stdin=p.stdout,check=True);assert p.wait()==0
  if stage in ('candidate','layout'):shutil.copyfile(r/'crates/hyperinterval/src/rational.rs',src/'crates/hyperinterval/src/rational.rs')
  for consumer in ['control','direct'] if stage in ('candidate','layout') else ['control']:
    shutil.copyfile(d/f'{consumer}.rs',d/'client/src/operation.rs')
    for target in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
      for trace in [False,True]:
        stem=f'{consumer}-{target}'+('-trace' if trace else '')
        cmd=['cargo','+stable','build','--manifest-path',str(d/'client/Cargo.toml'),'--locked','--release','--target',target,'--message-format=json-render-diagnostics']
        if trace:cmd+=['--features','trace']
        with (dest/(stem+'.log')).open('w') as log:
          raw=subprocess.check_output(cmd,cwd=d,text=True,stderr=log)
        exe=next(Path(j['executable']) for l in raw.splitlines() if (j:=json.loads(l)).get('executable'))
        output=dest/(stem+exe.suffix+'.bin');shutil.copyfile(exe,output);output.chmod(0o755)
        c=[str(output)] if target.startswith('x86') else ['node',str(r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),str(output)]
        with (dest/(stem+'.rows')).open('w') as out,(dest/(stem+'.stderr')).open('w') as err:subprocess.run(c,stdout=out,stderr=err,check=True)
  print(stage,flush=True)
for stage in sys.argv[1:]:run(stage)
