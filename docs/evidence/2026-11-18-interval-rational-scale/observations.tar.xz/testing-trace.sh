set -eu
d=/dev/shm/interval-rational-scale
v=$1
. /dev/shm/interval-horner-readmission/env
export CARGO_TARGET_DIR="$d/test-$v"
cargo "+$v" test --locked --release -p hyperinterval --features rational,serde,dispatch-trace --test rational_scale --no-run --message-format=json-render-diagnostics >"$d/harness-native-$v.jsonl" 2>"$d/harness-native-$v.log"
f=$(python3 -c 'import sys,json;print(next(r["executable"] for x in open(sys.argv[1]) if (r:=json.loads(x)).get("executable")))' "$d/harness-native-$v.jsonl")
cp "$f" "$d/test-native-$v.elf"
"$f" >"$d/run-native-$v.log"
. "$d/env"
export CARGO_TARGET_DIR="$d/test-$v"
cargo "+$v" test --locked --release -p hyperinterval --target wasm32-wasip1 --features rational,serde,dispatch-trace --test rational_scale --no-run --message-format=json-render-diagnostics >"$d/harness-wasi-$v.jsonl" 2>"$d/harness-wasi-$v.log"
f=$(python3 -c 'import sys,json;print(next(r["executable"] for x in open(sys.argv[1]) if (r:=json.loads(x)).get("executable")))' "$d/harness-wasi-$v.jsonl")
cp "$f" "$d/test-wasi-$v.wasm"
node crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$f" --test-threads=1 >"$d/run-wasi-$v.log" 2>&1
