#[cfg(test)]
mod affine_difference_tests {
    use super::*;

    #[test]
    fn shared_affine_difference_is_a_rational_leaf() {
        let bases = [
            Computable::sqrt_rational(Rational::new(2)),
            Computable::pi(),
            Computable::one().sin(),
        ];
        for base in bases {
            for scale in [Rational::one(), Rational::new(-3), Rational::fraction(7, 11).unwrap()] {
                for reverse_left in [false, true] {
                    for reverse_right in [false, true] {
                        let a = Rational::fraction(5, 8).unwrap();
                        let b = Rational::fraction(-3, 7).unwrap();
                        let affine = |offset: &Rational, reverse| {
                            let offset = Computable::rational(offset.clone());
                            let sum = if reverse { offset.add(base.clone()) } else { base.clone().add(offset) };
                            sum.multiply_rational(scale.clone())
                        };
                        let left = affine(&a, reverse_left);
                        let right = affine(&b, reverse_right);
                        let result = left.add(right.negate());
                        assert_eq!(result.exact_rational(), Some((&a - &b) * &scale));
                        assert!(result.cached().is_none());
                    }
                }
            }
        }
    }

    #[test]
    fn a_bare_shared_base_cancels_an_unequal_offset() {
        let base = Computable::one().sin();
        let offset = Rational::fraction(7, 11).unwrap();
        let affine = base.clone().add(Computable::rational(offset.clone()));
        let forward = base.clone().add(affine.clone().negate());
        let reverse = affine.add(base.negate());
        assert_eq!(forward.exact_rational(), Some(-offset.clone()));
        assert_eq!(reverse.exact_rational(), Some(offset));
        assert!(forward.cached().is_none() && reverse.cached().is_none());
    }

    #[test]
    fn cancellation_preserves_the_operands_approximation_caches() {
        let base = Computable::sqrt_rational(Rational::new(2));
        let left = base.clone().add(Computable::rational(Rational::new(100)));
        let right = base.add(Computable::rational(Rational::new(101)));
        left.approx(-32);
        right.approx(-64);
        let left_before = left.cached();
        let right_before = right.cached();
        let result = left.clone().add(right.clone().negate());
        assert_eq!(result.exact_rational(), Some(Rational::new(-1)));
        assert_eq!(left.cached(), left_before);
        assert_eq!(right.cached(), right_before);
        assert!(result.cached().is_none());
    }

    #[test]
    fn unequal_bases_are_not_cancelled() {
        let left = Computable::sqrt_rational(Rational::new(2))
            .add(Computable::rational(Rational::new(100)));
        let right = Computable::sqrt_rational(Rational::new(3))
            .add(Computable::rational(Rational::new(101)));
        let result = left.add(right.negate());
        assert!(result.exact_rational().is_none());
        assert_eq!(result.sign_until(-512), Some(RealSign::Negative));
    }
}
