use hyperreal::Real;
use std::cmp::Ordering;

fn check(base: Real) {
    // The shared, defined real cancels independently of its representation.
    let left = Real::from(100) + &base;
    let right = Real::from(101) + &base;
    let result = left.certified_cmp_until(&right, 0);
    assert_eq!(result.ordering(), Some(Ordering::Less), "{result:?}");
    let opposite = right.certified_cmp_until(&left, 0);
    assert_eq!(opposite.ordering(), Some(Ordering::Greater), "{opposite:?}");
}

#[test]
fn shared_quadratic_offset_order() { check(Real::from(2).sqrt().unwrap()); }
#[test]
fn shared_sine_offset_order() { check(Real::from(2).sin()); }
#[test]
fn shared_cosine_offset_order() { check(Real::from(2).cos()); }
#[test]
fn shared_atan_offset_order() { check(Real::from(2).atan().unwrap()); }
#[test]
fn shared_mixed_offset_order() {
    check(Real::from(2).sin() * Real::from(3).cos() + Real::from(5).sqrt().unwrap());
}
#[test]
fn different_bases_are_not_cancelled() {
    let left = Real::from(100) + Real::from(2).sqrt().unwrap();
    let right = Real::from(101) + Real::from(3).sqrt().unwrap();
    // sqrt(2) < sqrt(3), so the left value is strictly smaller.
    assert_eq!(left.certified_cmp_until(&right, 0).ordering(), Some(Ordering::Less));
}
