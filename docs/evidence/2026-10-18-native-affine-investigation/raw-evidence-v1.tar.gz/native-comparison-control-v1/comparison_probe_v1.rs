use hypercurve::{LineSeg2, Point2};
use hyperreal::{dispatch_trace, Real};
use std::cmp::Ordering;
use std::hint::black_box;

fn scalar(text: &str) -> Real {
    text.parse().unwrap()
}

fn trace(name: &str, phase: &str) {
    let snapshot = dispatch_trace::take_trace();
    println!("SUMMARY,{name},{phase},{:?}", snapshot.correlation_summary());
    for row in snapshot.dispatch {
        println!("TRACE,{name},{phase},{},{},{},{}", row.layer, row.operation, row.path, row.count);
    }
}

fn compare(name: &str, left: Real, right: Real, expected: Ordering) {
    println!("INPUT,{name},{left:?},{right:?},{expected:?}");
    for (phase, count) in [("first", 1), ("repeated", 8)] {
        dispatch_trace::reset();
        dispatch_trace::with_recording(|| {
            for _ in 0..count {
                let observed = black_box(&left).certified_cmp_until(black_box(&right), 0);
                assert_eq!(observed.ordering(), Some(expected), "{name}/{phase}: {observed:?}");
            }
        });
        println!("RESULT,{name},{phase},{count},{expected:?}");
        trace(name, phase);
    }
    // Retain the difference explicitly as a diagnostic control. This does not
    // propose a cache or count a different workload as a speedup.
    let difference = &left - &right;
    dispatch_trace::reset();
    dispatch_trace::with_recording(|| {
        for _ in 0..8 {
            assert_eq!(difference.certified_cmp_until(&Real::zero(), 0).ordering(), Some(expected));
        }
    });
    println!("RESULT,{name},retained_difference,8,{expected:?}");
    trace(name, "retained_difference");
}

fn offset_case(name: &str, origin: &str, dx: i32, dy: i32, radius: &str) {
    let x = scalar(origin);
    let y = Real::from(100);
    let line = LineSeg2::try_new(
        Point2::new(x.clone(), y.clone()),
        Point2::new(&x + Real::from(dx), &y + Real::from(dy)),
    ).unwrap();
    let radius = scalar(radius);
    let left = line.offset_left(radius.clone()).unwrap();
    let right = line.offset_left(-radius).unwrap();
    // For positive radius, the left normal is (-dy, dx)/sqrt(dx²+dy²).
    // Equal displacement cancels along each parallel; these order oracles
    // depend only on the exact authored integer direction, not another kernel.
    compare(&format!("{name}/normal_x"), left.start().x().clone(), right.start().x().clone(), (-dy).cmp(&0));
    compare(&format!("{name}/normal_y"), left.start().y().clone(), right.start().y().clone(), dx.cmp(&0));
    compare(&format!("{name}/parallel_x"), left.start().x().clone(), left.end().x().clone(), 0.cmp(&dx));
    compare(&format!("{name}/parallel_y"), left.start().y().clone(), left.end().y().clone(), 0.cmp(&dy));
}

fn main() {
    for (name, origin, dx, dy, radius) in [
        ("axis", "100", 2, 0, "0.1"),
        ("rational_direction", "100", 3, 4, "0.1"),
        ("quadratic_direction", "100", 1, 1, "0.1"),
        ("other_quadratic", "100", 2, 3, "0.1"),
        ("large_translation", "1e20", 1, 1, "0.1"),
        ("tiny_width", "100", 1, 1, "1e-400"),
    ] {
        offset_case(name, origin, dx, dy, radius);
    }
    // A common positive symbolic factor preserves rational coefficient order.
    for (name, base) in [
        ("sqrt2_scale", Real::from(2).sqrt().unwrap()),
        ("pi_scale", Real::pi()),
        ("offset_sqrt2_scale", Real::one() + Real::from(2).sqrt().unwrap()),
    ] {
        compare(name, &base * Real::from(2), &base * Real::from(3), Ordering::Less);
    }
}
