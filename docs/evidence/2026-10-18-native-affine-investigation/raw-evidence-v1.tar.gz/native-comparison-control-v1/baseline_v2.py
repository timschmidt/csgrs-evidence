"""Reproduce exact-track regressions on the committed sign-cache correction."""
import gzip,json,os,re,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
P=N/'sign-cache-publication-control-v1'
U=Path('/tmp/csgrs-sign-cache-validation-20261018-v1')
A=Path('/tmp/csgrs-native-comparison-20261018-v2')
R=N/'native-comparison-baseline-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
BASE='a62636b985186ff9041f6013b2f840adb3d391b9'
sys.path.insert(0,str(P));sys.path.insert(0,str(O/'docs/evidence/2026-10-17-resume-integration'))
from validation_runner_v4_local import run,dump,sha,resources,reasons
from load_expectations_v2 import load
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
os.environ['GIT_OPTIONAL_LOCKS']='0'
assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()==BASE
assert not subprocess.check_output(GIT+['diff','HEAD','--name-only'],cwd=O)
assert not A.exists() and not R.exists();A.mkdir();R.mkdir()
checkpoint=json.loads((O/'docs/evidence/2026-10-18-sign-cache-publication/checkpoint-v1.json').read_text())
assert all(sha(O/p)==h for p,h in checkpoint['evidence_files_sha256'].items())
expected,missing=load(O/checkpoint['artifact_expectations'],allow_unqualified=True)
assert (len(expected),len(missing))==(1446834,921794)
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
assert sha(P/'main-source-pins-v3.json.gz')==expected[str(P/'main-source-pins-v3.json.gz')]
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
log=N/'logs/sign-cache-publication-main-v3-hypercircuit-build/stdout'
assert sha(log)==expected[str(log)]
libraries={}
for line in log.read_text().splitlines():
 if not line.startswith('{'):continue
 row=json.loads(line);target=row.get('target',{})
 if row.get('reason')!='compiler-artifact' or target.get('name') not in ['hyperdrc','hypercurve','hyperlimit','hyperreal'] or 'lib' not in target['kind']:continue
 paths=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
 if not paths:continue
 assert len(paths)==1
 p=paths[0];assert sha(p)==expected[str(p)]
 libraries[target['name']]={'path':str(p),'sha256':sha(p),'features':row['features']}
assert len(libraries)==4
deps=Path(libraries['hyperdrc']['path']).parent
dependency_pins={str(p):expected[str(p)] for p in deps.iterdir() if p.is_file() and p.suffix in {'.rlib','.rmeta','.so','.a'}}
old=json.loads((N/'exact-track-inline-baseline-v1/protocol-v1.json').read_text())
tests={Path(p).stem:Path(p) for p in old['archived_test_sources_sha256']}
assert len(tests)==2
for p in tests.values():assert sha(p)==expected[str(p)]==old['archived_test_sources_sha256'][str(p)]
manifest=U/'main-v3-artifacts/executables-v1.json';assert sha(manifest)==expected[str(manifest)]
artifacts=json.loads(manifest.read_text());controls=[v for v in artifacts.values() if v['target']['name']=='kicad_track_failures']
assert len(controls)==1
control=controls[0];assert sha(control['copy'])==expected[control['copy']]==control['sha256']
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in dependency_pins.items())
 assert all(sha(p)==expected[str(p)] for p in tests.values())
 assert sha(control['copy'])==control['sha256']
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'parent_revision':BASE,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v2.md'),'libraries':libraries,'read_only_dependency_inputs_sha256':dependency_pins,'archived_test_sources_sha256':{str(p):sha(p) for p in tests.values()},'existing_control':control,'compiler_sha256':compiler['tool_sha256'],'main_source_pins_sha256':sha(P/'main-source-pins-v3.json.gz'),'old_history_reaudited':False,'historical_missing_paths':len(missing),'all_storage_baselines_unchanged':True,'resource_runner_sha256':sha(P/'validation_runner_v4_local.py'),'artifact_directory':str(A)})
commands={};summaries={}
def execute(label,args,allow_failure=False):
 verify();name='native-comparison-baseline-'+label+'-v2';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
 try:r=run(name,argv+list(map(str,args)),O,wall_seconds=60)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text())
  if r['stops'] or not allow_failure or r['exit_code']!=101:raise
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 return (N/'logs'/name/'stdout').read_text()
def rows(text):return re.findall(r'^test result: (w+). (d+) passed; (d+) failed; (d+) ignored; (d+) measured; (d+) filtered out;',text,re.M)
for name,source in tests.items():
 binary=A/name
 args=[compiler['additional_environment']['RUSTC'],'--test','--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(deps)]
 for crate,row in libraries.items():args+=['--extern',crate+'='+row['path']]
 execute(name+'-compile',args)
 summaries[name]=rows(execute(name,[binary,'--nocapture','--test-threads=1'],allow_failure=True))
 assert len(summaries[name])==1
summaries['existing_source_failures']=rows(execute('source-failures',[control['copy'],'--test-threads=1']))
assert summaries['existing_source_failures']==[('ok','39','0','0','0','0')]
verify()
dump(R/'result-v1.json',{'summaries':summaries,'commands':commands,'libraries':libraries,'source_revision':BASE,'source_unchanged':True,'binaries':{p.name:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in A.iterdir() if p.is_file()},'exact_importer_admitted':False,'full_plan_complete':False})
print(json.dumps({'summaries':summaries,'source_unchanged':True}),flush=True)
