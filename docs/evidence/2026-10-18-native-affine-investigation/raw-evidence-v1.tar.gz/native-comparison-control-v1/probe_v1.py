"""Run the recorded public comparison shapes on the qualified main libraries."""
import gzip,json,os,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
baseline=json.loads((N/'native-comparison-baseline-v3/protocol-v1.json').read_text())
result=json.loads((N/'native-comparison-baseline-v3/result-v1.json').read_text())
assert result['source_revision']=='a62636b985186ff9041f6013b2f840adb3d391b9' and result['source_unchanged']
libraries=baseline['libraries'];deps=Path(libraries['hyperreal']['path']).parent
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
A=Path('/tmp/csgrs-native-comparison-probe-20261018-v1');R=N/'native-comparison-probe-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir()
source=W/'comparison_probe_v1.rs';source_sha=sha(source);binary=A/'comparison_probe'
def verify():
 assert sha(source)==source_sha and all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in baseline['read_only_dependency_inputs_sha256'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'source_sha256':source_sha,'contract_sha256':sha(W/'comparison-probe-contract-v1.md'),'baseline_protocol_sha256':sha(N/'native-comparison-baseline-v3/protocol-v1.json'),'libraries':libraries,'read_only_dependency_inputs_sha256':baseline['read_only_dependency_inputs_sha256'],'source_revision':result['source_revision'],'no_production_source_changes':True})
commands={}
def execute(label,args):
 verify();name='native-comparison-probe-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
 r=run(name,argv+list(map(str,args)),O,wall_seconds=60);commands[label]=r;dump(R/'progress-v1.json',commands);verify()
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',source,'-o',binary,'-L','dependency='+str(deps)]
for crate in ['hyperreal','hypercurve']:args+=['--extern',crate+'='+libraries[crate]['path']]
execute('compile',args);digest=sha(binary);execute('run',[binary]);assert sha(binary)==digest
out=(N/'logs/native-comparison-probe-run-v1/stdout').read_text();rows=[line for line in out.splitlines() if line.startswith('RESULT,')]
assert len(rows)==81
dump(R/'result-v1.json',{'passed':True,'result_rows':len(rows),'coordinate_pairs':24,'common_factor_controls':3,'source_revision':result['source_revision'],'commands':commands,'binary':{'path':str(binary),'sha256':digest,'bytes':binary.stat().st_size},'speedup_claimed':False,'implementation_selected':False})
print(json.dumps({'passed':True,'result_rows':len(rows),'source_changed':False}),flush=True)
