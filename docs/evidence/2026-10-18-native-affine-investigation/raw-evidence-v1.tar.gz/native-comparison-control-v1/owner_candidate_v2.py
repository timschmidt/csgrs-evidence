"""Compile the unchanged scalar implementation with missing owner acceptance tests."""
import gzip,json,os,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
E=O/'docs/evidence/2026-10-18-sign-cache-publication'
expected=json.loads(gzip.decompress((E/'artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
baseline=json.loads((N/'native-comparison-baseline-v3/protocol-v1.json').read_text())
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
log=N/'logs/sign-cache-publication-main-v3-hyperreal-default-build/stdout';assert sha(log)==expected[str(log)]
libraries={}
for line in log.read_text().splitlines():
 if not line.startswith('{'):continue
 row=json.loads(line);target=row.get('target',{})
 if row.get('reason')!='compiler-artifact' or target.get('name') not in ['num','proptest','rug','serde_json','toml']:continue
 choices=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
 if choices:
  assert len(choices)==1
  p=choices[0];assert sha(p)==expected[str(p)];libraries[target['name']]=str(p)
assert len(libraries)==5
deps=Path(libraries['num']).parent
A=Path('/tmp/csgrs-affine-owner-candidate-20261018-v2');R=N/'affine-owner-candidate-v2'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir();(A/'scratch').mkdir()
binary=A/'hyperreal-owner-tests'
overlays={O/'crates/hyperreal/src/computable/node.rs':W/'node_affine_tests_v1.rs',O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_affine_v2.rs'}
inputs={str(p):sha(p) for p in [W/'node_affine_tests_v1.rs',W/'affine_difference_tests_v1.rs',W/'algebra_affine_v2.rs']}
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in inputs.items())
 assert all(sha(p)==h for p,h in baseline['read_only_dependency_inputs_sha256'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'owner_contract_sha256':sha(W/'affine-candidate-contract-v1.md'),'added_test_inputs_sha256':inputs,'overlays':{str(p):str(v) for p,v in overlays.items()},'baseline_runtime_source_sha256':sha(O/'crates/hyperreal/src/computable/node/algebra.rs'),'candidate_runtime_source_sha256':sha(W/'algebra_affine_v2.rs'),'verified_dependencies':libraries,'dependency_pins':baseline['read_only_dependency_inputs_sha256'],'source_revision':'a62636b985186ff9041f6013b2f840adb3d391b9','direct_rustc_test_build':True,'features':['dispatch-trace'],'production_source_changed':False})
commands={}
def execute(label,args,limit,allow_failure=False):
 verify();name='affine-owner-candidate-'+label+'-v2';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(A/'scratch')]
 for dest,source in overlays.items():argv+=['--ro-bind',str(source),str(dest)]
 try:r=run(name,argv+list(map(str,args)),O,wall_seconds=limit)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text())
  assert allow_failure and r['exit_code']==101 and not r['stops'],r
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
args=[compiler['additional_environment']['RUSTC'],'--test','--crate-name','hyperreal','--edition=2024','--cfg','feature="dispatch-trace"','-C','opt-level=3','-D','warnings',O/'crates/hyperreal/src/lib.rs','-o',binary,'-L','dependency='+str(deps)]
for crate,path in libraries.items():args+=['--extern',crate+'='+path]
execute('compile',args,1800);digest=sha(binary)
execute('tests',[binary,'affine_difference_tests::','--nocapture','--test-threads=1'],60)
assert sha(binary)==digest
out=(N/'logs/affine-owner-candidate-tests-v2/stdout').read_text()
rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
assert rows==[('ok','4','0','0','0','849')]
execute('complete-unit-suite',[binary,'--nocapture','--test-threads=1'],1800)
full_out=(N/'logs/affine-owner-candidate-complete-unit-suite-v2/stdout').read_text()
full_rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',full_out,re.M)
assert full_rows and all(r[0]=='ok' and r[2]=='0' for r in full_rows)
dump(R/'result-v1.json',{'summary':rows,'complete_unit_summaries':full_rows,'commands':commands,'binary':{'path':str(binary),'sha256':digest,'bytes':binary.stat().st_size},'main_source_changed':False,'isolated_runtime_source_changed':True,'candidate_prepared':True,'candidate_integrated':False,'runtime_admitted':False})
print(json.dumps({'summary':rows,'main_source_changed':False,'isolated_runtime_source_changed':True}),flush=True)
