"""Prepare zero-refinement acceptance cases for shared affine cancellation."""
import ast,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1'
source=r'''use hyperreal::Real;
use std::cmp::Ordering;

fn check(base: Real) {
    // The shared, defined real cancels independently of its representation.
    let left = Real::from(100) + &base;
    let right = Real::from(101) + &base;
    let result = left.certified_cmp_until(&right, 0);
    assert_eq!(result.ordering(), Some(Ordering::Less), "{result:?}");
    let opposite = right.certified_cmp_until(&left, 0);
    assert_eq!(opposite.ordering(), Some(Ordering::Greater), "{opposite:?}");
}

#[test]
fn shared_quadratic_offset_order() { check(Real::from(2).sqrt().unwrap()); }
#[test]
fn shared_sine_offset_order() { check(Real::from(2).sin()); }
#[test]
fn shared_cosine_offset_order() { check(Real::from(2).cos()); }
#[test]
fn shared_atan_offset_order() { check(Real::from(2).atan().unwrap()); }
#[test]
fn shared_mixed_offset_order() {
    check(Real::from(2).sin() * Real::from(3).cos() + Real::from(5).sqrt().unwrap());
}
#[test]
fn different_bases_are_not_cancelled() {
    let left = Real::from(100) + Real::from(2).sqrt().unwrap();
    let right = Real::from(101) + Real::from(3).sqrt().unwrap();
    // sqrt(2) < sqrt(3), so the left value is strictly smaller.
    assert_eq!(left.certified_cmp_until(&right, 0).ordering(), Some(Ordering::Less));
}
'''
p=W/'affine_reproduction_v1.rs';assert not p.exists();p.write_text(source)
contract=W/'affine-reproduction-contract-v1.md';assert not contract.exists()
contract.write_text('''# Shared affine cancellation acceptance domain

Owning layer: Hyperreal scalar construction. For one defined retained real u
and exact rational a,b, (a+u)-(b+u)=a-b. Recognizing this identity must not require
numeric approximation of u or reconstruct a quadratic normal form on every
comparison. The existing bounded rational-offset recognizer supplies the domain;
its traversal and scale bounds must remain unchanged. Nonmatching bases must
continue through the existing exact/Unknown paths.

Before implementation, run independent zero-refinement order checks using
sqrt(2), sin(2), cos(2), atan(2), and a mixed transcendental/algebraic base. The
shared base cancels by the additive group identity; a separate unequal-base
control uses sqrt(2)<sqrt(3). Unknown is an honest current outcome, but it does
not satisfy this explicitly proposed supported identity. No existing Unknown
case is relabeled wrong, and no new answer is accepted without that identity.

Use the unchanged source and compatible qualified libraries, original 60-second
focused cap, and all inherited storage/memory containment. Preserve failures.
This probe alone does not select or admit a runtime change or an optimization.
''')
old=(W/'probe_v1.py').read_text()
code=old.replace("A=Path('/tmp/csgrs-native-comparison-probe-20261018-v1');R=N/'native-comparison-probe-v1'", "A=Path('/tmp/csgrs-native-affine-reproduction-20261018-v1');R=N/'native-affine-reproduction-v1'")
code=code.replace("source=W/'comparison_probe_v1.rs'", "source=W/'affine_reproduction_v1.rs'")
code=code.replace("sha(W/'comparison-probe-contract-v1.md')", "sha(W/'affine-reproduction-contract-v1.md')")
code=code.replace("name='native-comparison-probe-'+label+'-v1'", "name='native-affine-reproduction-'+label+'-v1'")
code=code.replace("r=run(name,argv+list(map(str,args)),O,wall_seconds=60);commands[label]=r;dump(R/'progress-v1.json',commands);verify()", "try:r=run(name,argv+list(map(str,args)),O,wall_seconds=60)\n except RuntimeError:\n  r=json.loads((N/'logs'/name/'result.json').read_text())\n  assert label=='run' and r['exit_code']==101 and not r['stops'],r\n commands[label]=r;dump(R/'progress-v1.json',commands);verify()")
code=code.replace("[compiler['additional_environment']['RUSTC'],'--edition=2024'", "[compiler['additional_environment']['RUSTC'],'--test','--edition=2024'")
start=code.index("execute('compile',args)")
code=code[:start]+'''execute('compile',args);digest=sha(binary);execute('run',[binary,'--nocapture','--test-threads=1']);assert sha(binary)==digest
out=(N/'logs/native-affine-reproduction-run-v1/stdout').read_text()
import re
rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
assert len(rows)==1
dump(R/'result-v1.json',{'summary':rows,'source_revision':result['source_revision'],'commands':commands,'binary':{'path':str(binary),'sha256':digest,'bytes':binary.stat().st_size},'speedup_claimed':False,'implementation_selected':False})
print(json.dumps({'summary':rows,'source_changed':False}),flush=True)
'''
ast.parse(code);p=W/'affine_reproduction_v1.py';assert not p.exists();p.write_text(code)
print(json.dumps({'prepared':str(p)}))
