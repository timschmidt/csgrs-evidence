"""Select the final compatible library configuration without rebuilding it."""
import ast,hashlib,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
contract=W/'contract-v2.md';assert not contract.exists()
contract.write_text('''# Compatible retained library selection

All scope, semantic tests, resource baselines and gates in contract-v1 remain.
The first standalone link failed before runtime. Compiler lookup diagnostics
identify a CSGRS metadata hash mismatch: the default HyperDRC library requests
86bede360d81db86ccfd38b6b6508037, while the retained unversioned libcsgrs.rlib
contains f14f3da60d9b0e96615fb26b4d6d11dc. Later feature-matrix builds reuse that
output filename. The independently frozen test executables remain unchanged;
this does not invalidate their executed results.

Select the coherent libraries from the final actual-main Hypercircuit all-feature
build instead. Hyperreal additionally enables dispatch-trace; the public geometry
test bodies and policies are unchanged. Verify and record the feature lists,
source identities, library hashes and compiler outcome. This is a linking
configuration correction, not a workload reduction or a production change.
Retain the failed compile and the metadata diagnostic. A successful compilation
and execution are still required; compatibility is not assumed from filenames.
''')
old=W/'baseline_v1.py';code=old.read_text()
code=code.replace("A=Path('/tmp/csgrs-native-comparison-20261018-v1')", "A=Path('/tmp/csgrs-native-comparison-20261018-v2')")
code=code.replace("R=N/'native-comparison-baseline-v1'", "R=N/'native-comparison-baseline-v2'")
code=code.replace("log=N/'logs/sign-cache-publication-main-v3-hyperdrc-build/stdout'", "log=N/'logs/sign-cache-publication-main-v3-hypercircuit-build/stdout'")
code=code.replace("sha(W/'contract-v1.md')", "sha(W/'contract-v2.md')")
code=code.replace("name='native-comparison-baseline-'+label+'-v1'", "name='native-comparison-baseline-'+label+'-v2'")
assert code!=old.read_text();ast.parse(code)
new=W/'baseline_v2.py';assert not new.exists();new.write_text(code)
review={'first_helper_sha256':sha(old),'second_helper_sha256':sha(new),'compiler_diagnostic_sha256':sha(N/'logs/native-comparison-link-diagnostic-v1/stderr'),'first_failed_command_sha256':sha(N/'logs/native-comparison-baseline-kicad_native_aggregation-compile-v1/result.json'),'change':'Select the final Hypercircuit build library cohort; preserve all test bodies, policies, baseline counters and resource limits.','contract_sha256':sha(contract),'runtime_tests_started_before_this_correction':False}
out=W/'link-setup-review-v1.json';assert not out.exists();out.write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
print(json.dumps(review))
