"""Correct the summary reader and continue after the completed aggregation test."""
import ast,hashlib,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
old=W/'baseline_v2.py';code=old.read_text()
code=code.replace("A=Path('/tmp/csgrs-native-comparison-20261018-v2')", "A=Path('/tmp/csgrs-native-comparison-20261018-v3')")
code=code.replace("R=N/'native-comparison-baseline-v2'", "R=N/'native-comparison-baseline-v3'")
code=code.replace("name='native-comparison-baseline-'+label+'-v2'", "name='native-comparison-baseline-'+label+'-v3'")
bad="def rows(text):return re.findall(r'^test result: (w+). (d+) passed; (d+) failed; (d+) ignored; (d+) measured; (d+) filtered out;',text,re.M)"
good="def rows(text):return re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',text,re.M)"
assert code.count(bad)==1;code=code.replace(bad,good)
reuse='''for name,source in tests.items():
 if name=='kicad_native_aggregation':
  for label in [name+'-compile',name]:
   folder=N/'logs'/('native-comparison-baseline-'+label+'-v2')
   record=json.loads((folder/'result.json').read_text());assert not record['stops'] and record['output_closed']
   assert all(sha(folder/p)==h for p,h in record['output_sha256'].items())
   commands[label]={'reused_completed_command':record,'original_result_sha256':sha(folder/'result.json'),'rerun_here':False}
  summaries[name]=rows((N/'logs/native-comparison-baseline-kicad_native_aggregation-v2/stdout').read_text())
  assert summaries[name]==[('FAILED','9','3','0','0','0')]
  dump(R/'progress-v1.json',commands)
  continue
'''
assert code.count('for name,source in tests.items():')==1
code=code.replace('for name,source in tests.items():',reuse.rstrip())
code=code.replace("'source_unchanged':True,'binaries':", "'source_unchanged':True,'aggregation_reused_from':'native-comparison-baseline-v2','aggregation_binary_sha256':sha(Path('/tmp/csgrs-native-comparison-20261018-v2/kicad_native_aggregation')),'binaries':")
ast.parse(code);new=W/'baseline_v3.py';assert not new.exists();new.write_text(code)
record={'failed_reader_sha256':sha(old),'corrected_reader_sha256':sha(new),'reason':'Backslashes were lost while generating the original regular expression. The underlying test ran and reported nine passed and three failed. No test or diagnostic was changed.','completed_aggregation_result_sha256':sha(N/'logs/native-comparison-baseline-kicad_native_aggregation-v2/result.json'),'completed_aggregation_output_sha256':sha(N/'logs/native-comparison-baseline-kicad_native_aggregation-v2/stdout'),'completed_aggregation_binary_sha256':sha(Path('/tmp/csgrs-native-comparison-20261018-v2/kicad_native_aggregation')),'completed_command_reused_not_rerun':True,'remaining_tests':'Ten archived native-stroke tests and 39 existing typed-failure controls.'}
p=W/'reader-correction-v1.json';assert not p.exists();p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record))
