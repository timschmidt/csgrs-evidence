"""Prepare public scalar probes for exact native offset comparisons."""
import ast,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1'
source=r'''use hypercurve::{LineSeg2, Point2};
use hyperreal::{dispatch_trace, Real};
use std::cmp::Ordering;
use std::hint::black_box;

fn scalar(text: &str) -> Real {
    text.parse().unwrap()
}

fn trace(name: &str, phase: &str) {
    let snapshot = dispatch_trace::take_trace();
    println!("SUMMARY,{name},{phase},{:?}", snapshot.correlation_summary());
    for row in snapshot.counts {
        println!("TRACE,{name},{phase},{},{},{},{}", row.layer, row.operation, row.path, row.count);
    }
}

fn compare(name: &str, left: Real, right: Real, expected: Ordering) {
    println!("INPUT,{name},{left:?},{right:?},{expected:?}");
    for (phase, count) in [("first", 1), ("repeated", 8)] {
        dispatch_trace::reset();
        dispatch_trace::with_recording(|| {
            for _ in 0..count {
                let observed = black_box(&left).certified_cmp_until(black_box(&right), 0);
                assert_eq!(observed.ordering(), Some(expected), "{name}/{phase}: {observed:?}");
            }
        });
        println!("RESULT,{name},{phase},{count},{expected:?}");
        trace(name, phase);
    }
    // Retain the difference explicitly as a diagnostic control. This does not
    // propose a cache or count a different workload as a speedup.
    let difference = &left - &right;
    dispatch_trace::reset();
    dispatch_trace::with_recording(|| {
        for _ in 0..8 {
            assert_eq!(difference.certified_cmp_until(&Real::zero(), 0).ordering(), Some(expected));
        }
    });
    println!("RESULT,{name},retained_difference,8,{expected:?}");
    trace(name, "retained_difference");
}

fn offset_case(name: &str, origin: &str, dx: i32, dy: i32, radius: &str) {
    let x = scalar(origin);
    let y = Real::from(100);
    let line = LineSeg2::try_new(
        Point2::new(x.clone(), y.clone()),
        Point2::new(&x + Real::from(dx), &y + Real::from(dy)),
    ).unwrap();
    let radius = scalar(radius);
    let left = line.offset_left(radius.clone()).unwrap();
    let right = line.offset_left(-radius).unwrap();
    // For positive radius, the left normal is (-dy, dx)/sqrt(dx²+dy²).
    // Equal displacement cancels along each parallel; these order oracles
    // depend only on the exact authored integer direction, not another kernel.
    compare(&format!("{name}/normal_x"), left.start().x().clone(), right.start().x().clone(), (-dy).cmp(&0));
    compare(&format!("{name}/normal_y"), left.start().y().clone(), right.start().y().clone(), dx.cmp(&0));
    compare(&format!("{name}/parallel_x"), left.start().x().clone(), left.end().x().clone(), 0.cmp(&dx));
    compare(&format!("{name}/parallel_y"), left.start().y().clone(), left.end().y().clone(), 0.cmp(&dy));
}

fn main() {
    for (name, origin, dx, dy, radius) in [
        ("axis", "100", 2, 0, "0.1"),
        ("rational_direction", "100", 3, 4, "0.1"),
        ("quadratic_direction", "100", 1, 1, "0.1"),
        ("other_quadratic", "100", 2, 3, "0.1"),
        ("large_translation", "1e20", 1, 1, "0.1"),
        ("tiny_width", "100", 1, 1, "1e-400"),
    ] {
        offset_case(name, origin, dx, dy, radius);
    }
    // A common positive symbolic factor preserves rational coefficient order.
    for (name, base) in [
        ("sqrt2_scale", Real::from(2).sqrt().unwrap()),
        ("pi_scale", Real::pi()),
        ("offset_sqrt2_scale", Real::one() + Real::from(2).sqrt().unwrap()),
    ] {
        compare(name, &base * Real::from(2), &base * Real::from(3), Ordering::Less);
    }
}
'''
p=W/'comparison_probe_v1.rs';assert not p.exists();p.write_text(source)
(W/'comparison-probe-contract-v1.md').write_text('''# Public native comparison probe

The unchanged native line-offset constructor supplies six direction/scale
fixtures: axis-aligned, 3-4-5, sqrt(2), sqrt(13), 1e20 translation and 1e-400
width. Each contributes four coordinate orders. Positive radius gives normal
(-dy, dx)/sqrt(dx^2+dy^2); shared offsets cancel along each parallel. These are
independent exact order oracles. Three positive common-factor controls use
sqrt(2), pi and 1+sqrt(2) with rational coefficients 2 and 3.

For each pair, record the first and eight repeated zero-refinement certified
comparisons. A separately identified retained-difference control asks eight
orders after explicitly constructing that difference outside its trace window.
It is a different diagnostic workload, not a proposed cache or a speedup claim.
Record all dispatch entries, rational counters and returned certified orders.
Trace counters are neither allocation counts nor complete normal-form call
counts. No latency or application-performance conclusion follows from them.

Use the compatible actual-main libraries already selected in contract-v2 and
the unchanged original 60-second focused-command containment. No production
source, test policy, prior fixture or retained artifact is changed.
''')
code=r'''"""Run the recorded public comparison shapes on the qualified main libraries."""
import gzip,json,os,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
baseline=json.loads((N/'native-comparison-baseline-v3/protocol-v1.json').read_text())
result=json.loads((N/'native-comparison-baseline-v3/result-v1.json').read_text())
assert result['source_revision']=='a62636b985186ff9041f6013b2f840adb3d391b9' and result['source_unchanged']
libraries=baseline['libraries'];deps=Path(libraries['hyperreal']['path']).parent
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
A=Path('/tmp/csgrs-native-comparison-probe-20261018-v1');R=N/'native-comparison-probe-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir()
source=W/'comparison_probe_v1.rs';source_sha=sha(source);binary=A/'comparison_probe'
def verify():
 assert sha(source)==source_sha and all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in baseline['read_only_dependency_inputs_sha256'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'source_sha256':source_sha,'contract_sha256':sha(W/'comparison-probe-contract-v1.md'),'baseline_protocol_sha256':sha(N/'native-comparison-baseline-v3/protocol-v1.json'),'libraries':libraries,'read_only_dependency_inputs_sha256':baseline['read_only_dependency_inputs_sha256'],'source_revision':result['source_revision'],'no_production_source_changes':True})
commands={}
def execute(label,args):
 verify();name='native-comparison-probe-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
 r=run(name,argv+list(map(str,args)),O,wall_seconds=60);commands[label]=r;dump(R/'progress-v1.json',commands);verify()
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',source,'-o',binary,'-L','dependency='+str(deps)]
for crate in ['hyperreal','hypercurve']:args+=['--extern',crate+'='+libraries[crate]['path']]
execute('compile',args);digest=sha(binary);execute('run',[binary]);assert sha(binary)==digest
out=(N/'logs/native-comparison-probe-run-v1/stdout').read_text();rows=[line for line in out.splitlines() if line.startswith('RESULT,')]
assert len(rows)==81
dump(R/'result-v1.json',{'passed':True,'result_rows':len(rows),'coordinate_pairs':24,'common_factor_controls':3,'source_revision':result['source_revision'],'commands':commands,'binary':{'path':str(binary),'sha256':digest,'bytes':binary.stat().st_size},'speedup_claimed':False,'implementation_selected':False})
print(json.dumps({'passed':True,'result_rows':len(rows),'source_changed':False}),flush=True)
'''
ast.parse(code);p=W/'probe_v1.py';assert not p.exists();p.write_text(code)
print(json.dumps({'probe_source':str(W/'comparison_probe_v1.rs'),'driver':str(p)}))
