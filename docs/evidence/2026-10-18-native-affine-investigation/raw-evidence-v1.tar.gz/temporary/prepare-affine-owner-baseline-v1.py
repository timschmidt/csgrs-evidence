"""Freeze owner-level cancellation tests before preparing an implementation."""
import ast,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1';O=N.parent/'csgrs'
tests=r'''#[cfg(test)]
mod affine_difference_tests {
    use super::*;

    #[test]
    fn shared_affine_difference_is_a_rational_leaf() {
        let bases = [
            Computable::sqrt_rational(Rational::new(2)),
            Computable::pi(),
            Computable::one().sin(),
        ];
        for base in bases {
            for scale in [Rational::one(), Rational::new(-3), Rational::fraction(7, 11).unwrap()] {
                for reverse_left in [false, true] {
                    for reverse_right in [false, true] {
                        let a = Rational::fraction(5, 8).unwrap();
                        let b = Rational::fraction(-3, 7).unwrap();
                        let affine = |offset: &Rational, reverse| {
                            let offset = Computable::rational(offset.clone());
                            let sum = if reverse { offset.add(base.clone()) } else { base.clone().add(offset) };
                            sum.multiply_rational(scale.clone())
                        };
                        let left = affine(&a, reverse_left);
                        let right = affine(&b, reverse_right);
                        let result = left.add(right.negate());
                        assert_eq!(result.exact_rational(), Some((&a - &b) * &scale));
                        assert!(result.cached().is_none());
                    }
                }
            }
        }
    }

    #[test]
    fn a_bare_shared_base_cancels_an_unequal_offset() {
        let base = Computable::one().sin();
        let offset = Rational::fraction(7, 11).unwrap();
        let affine = base.clone().add(Computable::rational(offset.clone()));
        let forward = base.clone().add(affine.clone().negate());
        let reverse = affine.add(base.negate());
        assert_eq!(forward.exact_rational(), Some(-offset.clone()));
        assert_eq!(reverse.exact_rational(), Some(offset));
        assert!(forward.cached().is_none() && reverse.cached().is_none());
    }

    #[test]
    fn cancellation_preserves_the_operands_approximation_caches() {
        let base = Computable::sqrt_rational(Rational::new(2));
        let left = base.clone().add(Computable::rational(Rational::new(100)));
        let right = base.add(Computable::rational(Rational::new(101)));
        left.approx(-32);
        right.approx(-64);
        let left_before = left.cached();
        let right_before = right.cached();
        let result = left.clone().add(right.clone().negate());
        assert_eq!(result.exact_rational(), Some(Rational::new(-1)));
        assert_eq!(left.cached(), left_before);
        assert_eq!(right.cached(), right_before);
        assert!(result.cached().is_none());
    }

    #[test]
    fn unequal_bases_are_not_cancelled() {
        let left = Computable::sqrt_rational(Rational::new(2))
            .add(Computable::rational(Rational::new(100)));
        let right = Computable::sqrt_rational(Rational::new(3))
            .add(Computable::rational(Rational::new(101)));
        let result = left.add(right.negate());
        assert!(result.exact_rational().is_none());
        assert_eq!(result.sign_until(-512), Some(RealSign::Negative));
    }
}
'''
p=W/'affine_difference_tests_v1.rs';assert not p.exists();p.write_text(tests)
node=(O/'crates/hyperreal/src/computable/node.rs').read_text()
p=W/'node_affine_tests_v1.rs';assert not p.exists()
p.write_text(node+'\ninclude!("'+str(W/'affine_difference_tests_v1.rs')+'");\n')
p=W/'affine-owner-contract-v1.md';assert not p.exists()
p.write_text('''# Rational affine-difference construction

Owner: Hyperreal Computable::add and its bounded rational-offset recognizer.
Properties P1-P5, P19-P20 and P35-P37. For the same structurally identified
defined base u and coefficient s, (s*u+a)-(s*u+b)=a-b. A bare base is the
coefficient-one, offset-zero case. Construction should retain the exact
rational leaf instead of asking later callers to rediscover this identity.

The public probe establishes that the shared-base orders already complete;
this proposed change targets repeated proof construction and resource cost.
Its unrelated unequal-radical zero-refinement assertion remains failed and
is not an admission gate for shared-base cancellation. The new unequal-base
owner control requires no rational collapse and retains the ordinary -512
refinement check; it does not replace or erase that earlier observation.

Before changing runtime code, compile the actual scalar crate with four added
owner tests. Three require rational-leaf retention across shared bases, unequal
offsets, scaling, reversed sums, bare bases and existing operand caches. The
fourth rejects cancellation of distinct bases. Existing tests are unchanged.
The ordinary additive identity supplies the independent expected rationals.

Keep the recognizer's existing depth/work and scale bounds, decline paths,
source identity and approximation caches. No persistent cache or geometry
adapter shortcut is proposed. A candidate must be compared against the exact
baseline tests and actual native comparison shapes before broader admission.
The original native full-board/copper-neck and downstream gates remain required.

A direct full scalar test-crate compile uses the original 1800-second build
cap; focused test execution uses 60 seconds. Both retain 8 GiB child address
space and all existing storage baselines. Verified read-only dependencies are
reused. New compiler temporaries and executables stay in a fresh /tmp directory.
This is isolated qualification, not a production-source edit or runtime admission.
''')
driver=r'''"""Compile the unchanged scalar implementation with missing owner acceptance tests."""
import gzip,json,os,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
E=O/'docs/evidence/2026-10-18-sign-cache-publication'
expected=json.loads(gzip.decompress((E/'artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
baseline=json.loads((N/'native-comparison-baseline-v3/protocol-v1.json').read_text())
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
log=N/'logs/sign-cache-publication-main-v3-hyperreal-default-build/stdout';assert sha(log)==expected[str(log)]
libraries={}
for line in log.read_text().splitlines():
 if not line.startswith('{'):continue
 row=json.loads(line);target=row.get('target',{})
 if row.get('reason')!='compiler-artifact' or target.get('name') not in ['num','proptest','rug','serde_json','toml']:continue
 choices=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
 if choices:
  assert len(choices)==1
  p=choices[0];assert sha(p)==expected[str(p)];libraries[target['name']]=str(p)
assert len(libraries)==5
deps=Path(libraries['num']).parent
A=Path('/tmp/csgrs-affine-owner-baseline-20261018-v1');R=N/'affine-owner-baseline-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir();(A/'scratch').mkdir()
binary=A/'hyperreal-owner-tests'
overlays={O/'crates/hyperreal/src/computable/node.rs':W/'node_affine_tests_v1.rs'}
inputs={str(p):sha(p) for p in [W/'node_affine_tests_v1.rs',W/'affine_difference_tests_v1.rs']}
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in inputs.items())
 assert all(sha(p)==h for p,h in baseline['read_only_dependency_inputs_sha256'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'owner_contract_sha256':sha(W/'affine-owner-contract-v1.md'),'added_test_inputs_sha256':inputs,'overlays':{str(p):str(v) for p,v in overlays.items()},'runtime_source_sha256':sha(O/'crates/hyperreal/src/computable/node/algebra.rs'),'verified_dependencies':libraries,'dependency_pins':baseline['read_only_dependency_inputs_sha256'],'source_revision':'a62636b985186ff9041f6013b2f840adb3d391b9','direct_rustc_test_build':True,'features':['dispatch-trace'],'production_source_changed':False})
commands={}
def execute(label,args,limit,allow_failure=False):
 verify();name='affine-owner-baseline-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(A/'scratch')]
 for dest,source in overlays.items():argv+=['--ro-bind',str(source),str(dest)]
 try:r=run(name,argv+list(map(str,args)),O,wall_seconds=limit)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text())
  assert allow_failure and r['exit_code']==101 and not r['stops'],r
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
args=[compiler['additional_environment']['RUSTC'],'--test','--crate-name','hyperreal','--edition=2024','--cfg','feature="dispatch-trace"','-C','opt-level=3','-D','warnings',O/'crates/hyperreal/src/lib.rs','-o',binary,'-L','dependency='+str(deps)]
for crate,path in libraries.items():args+=['--extern',crate+'='+path]
execute('compile',args,1800);digest=sha(binary)
execute('tests',[binary,'affine_difference_tests::','--nocapture','--test-threads=1'],60,True)
assert sha(binary)==digest
out=(N/'logs/affine-owner-baseline-tests-v1/stdout').read_text()
rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
assert len(rows)==1
dump(R/'result-v1.json',{'summary':rows,'commands':commands,'binary':{'path':str(binary),'sha256':digest,'bytes':binary.stat().st_size},'runtime_source_changed':False,'candidate_prepared':False})
print(json.dumps({'summary':rows,'runtime_source_changed':False}),flush=True)
'''
ast.parse(driver);p=W/'owner_baseline_v1.py';assert not p.exists();p.write_text(driver)
print(json.dumps({'prepared':str(p),'tests':4,'runtime_changed':False}))
