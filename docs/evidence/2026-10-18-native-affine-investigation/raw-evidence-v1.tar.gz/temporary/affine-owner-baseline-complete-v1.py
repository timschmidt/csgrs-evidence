"""Confirm the broad regression is absent from the unchanged owner baseline."""
import gzip,json,os,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
O=N.parent/'csgrs';W=N/'native-comparison-control-v1';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha
r=json.loads((N/'affine-owner-baseline-v1/result-v1.json').read_text())
p=json.loads((N/'affine-owner-baseline-v1/protocol-v1.json').read_text())
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
assert all(sha(O/path)==h for path,h in pins.items())
assert all(sha(path)==h for path,h in p['added_test_inputs_sha256'].items())
assert sha(r['binary']['path'])==r['binary']['sha256']
name='affine-owner-baseline-complete-v1';scratch=N/'scratch'/name
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
for dest,source in p['overlays'].items():argv+=['--ro-bind',source,dest]
try:command=run(name,argv+[r['binary']['path'],'--nocapture','--test-threads=1'],O,wall_seconds=1800)
except RuntimeError:
 command=json.loads((N/'logs'/name/'result.json').read_text())
 assert command['exit_code']==101 and not command['stops']
out=(N/'logs'/name/'stdout').read_text()
rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
assert rows==[('FAILED','850','3','0','0','0')],rows
failed=[line for line in out.splitlines() if line.startswith('test ') and line.endswith(' ... FAILED')]
assert len(failed)==3 and all('affine_difference_tests::' in line for line in failed),failed
assert 'test computable::node::tests::affine_offsets_preserve_shared_bases_through_exact_scaling ... ok' in out
assert all(sha(O/path)==h for path,h in pins.items()) and sha(r['binary']['path'])==r['binary']['sha256']
R=N/'affine-owner-baseline-complete-v1';assert not R.exists();R.mkdir()
dump(R/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'summary':rows,'failures':failed,'original_affine_preservation_test_passed':True,'existing_tests_passed':849,'new_positive_control_passed':1,'new_acceptance_failures':3,'command':command,'production_source_changed':False,'constructor_wide_candidate_rejected':True})
print(json.dumps({'summary':rows,'original_tests_passed':849,'candidate_rejected':True}),flush=True)
