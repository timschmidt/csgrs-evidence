"""Correct a draft trace-field spelling before the probe's first compilation."""
import hashlib,json
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/native-comparison-control-v1')
p=W/'comparison_probe_v1.rs';old=p.read_bytes();assert old.count(b'snapshot.counts')==1
new=old.replace(b'snapshot.counts',b'snapshot.dispatch');p.write_bytes(new)
q=W/'probe-draft-field-correction-v1.json';assert not q.exists()
q.write_text(json.dumps({'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'correct_field':'TraceSnapshot.dispatch','probe_executed_before_correction':False},indent=2)+'\n')
