"""Retain the compiler's explanation for the standalone link failure."""
import json,os,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha
old=N/'logs/native-comparison-baseline-kicad_native_aggregation-compile-v1'
record=json.loads((old/'result.json').read_text())
name='native-comparison-link-diagnostic-v1';scratch=N/'scratch'/name
old_scratch=N/'scratch'/old.name
argv=[arg.replace(str(old_scratch),str(scratch)) for arg in record['argv']]
output=Path('/tmp/csgrs-native-comparison-20261018-v1/aggregation-link-diagnostic-v1')
assert not output.exists();argv[argv.index('-o')+1]=str(output)
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['RUSTC_LOG']='rustc_metadata::locator=info'
try:r=run(name,argv,O,wall_seconds=60)
except RuntimeError:
 r=json.loads((N/'logs'/name/'result.json').read_text())
 assert not r['stops'] and r['exit_code']==1,r
folder=N/'native-comparison-link-diagnostic-v1';assert not folder.exists();folder.mkdir()
dump(folder/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'prior_result_sha256':sha(old/'result.json'),'compiler_log_environment':os.environ['RUSTC_LOG'],'command':r,'runtime_tests_executed':False})
for line in (N/'logs'/name/'stderr').read_text().splitlines():
 if any(s in line.lower() for s in ['reject','incompat','mismatch','could not','can\'t find','no library','metadata version']):print(line)
