"""Prepare an isolated rational affine-difference constructor candidate."""
import ast,difflib,hashlib,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1';O=N.parent/'csgrs'
baseline=json.loads((N/'affine-owner-baseline-v1/result-v1.json').read_text())
assert baseline['summary']==[['FAILED','1','3','0','0','849']]
source=O/'crates/hyperreal/src/computable/node/algebra.rs';old=source.read_text()
start=old.index('        fn affine_offset_eq(')
end=old.index('\n        fn commuted_add_pair_eq',start)
replacement='''        fn affine_offset_difference(left: &Computable, right: &Computable) -> Option<Rational> {
            let left_parts = left.rational_offset_parts(&mut 8);
            let right_parts = right.rational_offset_parts(&mut 8);
            let (left, left_scale, left_offset, right, right_scale, right_offset) =
                match (left_parts, right_parts) {
                    (Some((left, left_scale, left_offset)), Some((right, right_scale, right_offset))) =>
                        (left, left_scale, left_offset, right, right_scale, right_offset),
                    (Some((base, scale, offset)), None) =>
                        (base, scale, offset, right, Rational::one(), Rational::zero()),
                    (None, Some((base, scale, offset))) =>
                        (left, Rational::one(), Rational::zero(), base, scale, offset),
                    _ => return None,
                };
            let same_scaled_base = if left_scale == right_scale {
                Computable::internal_structural_eq(left, right)
            } else {
                Computable::internal_structural_eq(
                    &left.clone().multiply_rational(left_scale),
                    &right.clone().multiply_rational(right_scale),
                )
            };
            // The common exact term cancels independently of its representation.
            // Retain the rational remainder so later comparisons can reuse it.
            same_scaled_base.then(|| left_offset - right_offset)
        }
'''
new=old[:start]+replacement+old[end:]
before='''        if cancelled_pair.is_some_and(|(left, right)| affine_offset_eq(left, right)) {
            crate::trace_dispatch!("computable", "add", "affine-offset-cancellation");
            return Self::zero();
        }'''
after='''        if let Some(difference) =
            cancelled_pair.and_then(|(left, right)| affine_offset_difference(left, right))
        {
            crate::trace_dispatch!("computable", "add", "affine-offset-cancellation");
            return Self::rational(difference);
        }'''
assert new.count(before)==1;new=new.replace(before,after)
candidate=W/'algebra_affine_v1.rs';assert not candidate.exists();candidate.write_text(new)
patch=W/'algebra_affine_v1.patch';assert not patch.exists()
patch.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/crates/hyperreal/src/computable/node/algebra.rs',tofile='b/crates/hyperreal/src/computable/node/algebra.rs')))
contract=W/'affine-candidate-contract-v1.md';assert not contract.exists()
contract.write_text('''# Isolated affine-difference candidate

The unchanged owner baseline reports three failures and one positive control.
Change only the existing affine cancellation helper in Computable::add: after
the same bounded offset decomposition and scaled-base structural comparison,
return the rational offset difference instead of requiring equal offsets.
Keep the original eight-visit recognizers and scale guards. No new retained
cache, lower precision, approximate terminal or caller-specific rule is added.

Run exactly the same four owner tests, then the complete scalar unit suite in
the same direct compiler configuration. All other source and existing tests
remain byte-identical. Compile into a new directory and preserve the baseline
binary and raw failures. Reproduce the native coordinate probe against a
coherent candidate dependency build before deciding whether to advance.

The intended representation change is explicit: these exact rational
differences become rational Computable leaves. Mathematical values and prior
certified facts must agree. Any exposed serialization consequence, performance
tradeoff or broader resource regression needs separate review before admission.
This isolated candidate is not integrated into the working source or admitted.
Original full native workloads, report contracts and downstream checks remain.
''')
driver=(W/'owner_baseline_v1.py').read_text()
driver=driver.replace("A=Path('/tmp/csgrs-affine-owner-baseline-20261018-v1');R=N/'affine-owner-baseline-v1'", "A=Path('/tmp/csgrs-affine-owner-candidate-20261018-v1');R=N/'affine-owner-candidate-v1'")
driver=driver.replace("overlays={O/'crates/hyperreal/src/computable/node.rs':W/'node_affine_tests_v1.rs'}", "overlays={O/'crates/hyperreal/src/computable/node.rs':W/'node_affine_tests_v1.rs',O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_affine_v1.rs'}")
driver=driver.replace("W/'node_affine_tests_v1.rs',W/'affine_difference_tests_v1.rs'", "W/'node_affine_tests_v1.rs',W/'affine_difference_tests_v1.rs',W/'algebra_affine_v1.rs'")
driver=driver.replace("sha(W/'affine-owner-contract-v1.md')", "sha(W/'affine-candidate-contract-v1.md')")
driver=driver.replace("'runtime_source_sha256':sha(O/'crates/hyperreal/src/computable/node/algebra.rs')", "'baseline_runtime_source_sha256':sha(O/'crates/hyperreal/src/computable/node/algebra.rs'),'candidate_runtime_source_sha256':sha(W/'algebra_affine_v1.rs')")
driver=driver.replace("name='affine-owner-baseline-'+label+'-v1'", "name='affine-owner-candidate-'+label+'-v1'")
driver=driver.replace("execute('tests',[binary,'affine_difference_tests::','--nocapture','--test-threads=1'],60,True)", "execute('tests',[binary,'affine_difference_tests::','--nocapture','--test-threads=1'],60)")
driver=driver.replace("N/'logs/affine-owner-baseline-tests-v1/stdout'", "N/'logs/affine-owner-candidate-tests-v1/stdout'")
driver=driver.replace("assert len(rows)==1", "assert rows==[('ok','4','0','0','0','849')]\nexecute('complete-unit-suite',[binary,'--nocapture','--test-threads=1'],1800)\nfull_out=(N/'logs/affine-owner-candidate-complete-unit-suite-v1/stdout').read_text()\nfull_rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',full_out,re.M)\nassert full_rows and all(r[0]=='ok' and r[2]=='0' for r in full_rows)")
driver=driver.replace("'summary':rows,'commands':commands", "'summary':rows,'complete_unit_summaries':full_rows,'commands':commands")
driver=driver.replace("'candidate_prepared':False", "'candidate_prepared':True,'candidate_integrated':False,'runtime_admitted':False")
ast.parse(driver);p=W/'owner_candidate_v1.py';assert not p.exists();p.write_text(driver)
print(json.dumps({'candidate':str(candidate),'patch':str(patch),'production_source_changed':False}))
