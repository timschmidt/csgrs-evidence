"""Handle the existing negative-factor representation without weakening tests."""
import ast,difflib,hashlib,json
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'native-comparison-control-v1';O=N.parent/'csgrs'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
old=(W/'algebra_affine_v1.rs').read_text()
new=old.replace('fn affine_offset_difference(left: &Computable, right: &Computable) -> Option<Rational> {',
'''fn affine_offset_difference(
            left: &Computable,
            right: &Computable,
            subtract_right: bool,
        ) -> Option<Rational> {''')
new=new.replace('let (left, left_scale, left_offset, right, right_scale, right_offset) =',
'''let (left, left_scale, left_offset, right, mut right_scale, mut right_offset) =''')
needle='''            let same_scaled_base = if left_scale == right_scale {'''
replacement='''            if !subtract_right {
                right_scale = -right_scale;
                right_offset = -right_offset;
            }
            let same_scaled_base = if left_scale == right_scale {'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
needle='''        fn commuted_add_pair_eq(left: &Computable, right: &Computable) -> bool {'''
replacement='''        fn has_negative_rational_factor(value: &Computable) -> bool {
            match &value.internal.approximation {
                Approximation::Multiply(left, right) => {
                    left.exact_rational().is_some_and(|scale| scale.sign() == Sign::Minus)
                        || right.exact_rational().is_some_and(|scale| scale.sign() == Sign::Minus)
                }
                _ => false,
            }
        }

        fn commuted_add_pair_eq(left: &Computable, right: &Computable) -> bool {'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
new=new.replace('cancelled_pair.and_then(|(left, right)| affine_offset_difference(left, right))',
'''cancelled_pair.and_then(|(left, right)| affine_offset_difference(left, right, true))''')
needle='''        if matches!(left_exact.as_ref(), Some(r) if r.sign() == Sign::NoSign) {'''
replacement='''        // Negation folds a negative rational product into a positive product.
        // Recognize the resulting opposite affine terms without rebuilding a
        // negation node or changing the ordinary-sum representation.
        if cancelled_pair.is_none()
            && (has_negative_rational_factor(&self) || has_negative_rational_factor(&other))
            && let Some(difference) = affine_offset_difference(&self, &other, false)
        {
            crate::trace_dispatch!("computable", "add", "affine-offset-cancellation");
            return Self::rational(difference);
        }

        if matches!(left_exact.as_ref(), Some(r) if r.sign() == Sign::NoSign) {'''
assert new.count(needle)==1;new=new.replace(needle,replacement)
p=W/'algebra_affine_v2.rs';assert not p.exists();p.write_text(new)
original=(O/'crates/hyperreal/src/computable/node/algebra.rs').read_text()
p=W/'algebra_affine_v2.patch';assert not p.exists()
p.write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='a/crates/hyperreal/src/computable/node/algebra.rs',tofile='b/crates/hyperreal/src/computable/node/algebra.rs')))
driver=(W/'owner_candidate_v1.py').read_text()
driver=driver.replace("csgrs-affine-owner-candidate-20261018-v1", "csgrs-affine-owner-candidate-20261018-v2")
driver=driver.replace("R=N/'affine-owner-candidate-v1'", "R=N/'affine-owner-candidate-v2'")
driver=driver.replace("algebra_affine_v1.rs", "algebra_affine_v2.rs")
driver=driver.replace("name='affine-owner-candidate-'+label+'-v1'", "name='affine-owner-candidate-'+label+'-v2'")
driver=driver.replace("logs/affine-owner-candidate-tests-v1", "logs/affine-owner-candidate-tests-v2")
driver=driver.replace("logs/affine-owner-candidate-complete-unit-suite-v1", "logs/affine-owner-candidate-complete-unit-suite-v2")
ast.parse(driver);p=W/'owner_candidate_v2.py';assert not p.exists();p.write_text(driver)
review={'first_candidate_sha256':sha(W/'algebra_affine_v1.rs'),'second_candidate_sha256':sha(W/'algebra_affine_v2.rs'),'unchanged_tests_sha256':sha(W/'affine_difference_tests_v1.rs'),'failed_first_test_result_sha256':sha(N/'logs/affine-owner-candidate-tests-v1/result.json'),'reason':'Negative multiplication factors can absorb a subsequent negation. The existing explicit-Negate gate misses that representation. The second candidate recognizes that shape through the same bounded affine helper.','recognition_budget_unchanged':True,'production_source_changed':False,'additional_sum_inspection_requires_cost_qualification':True}
p=W/'affine-candidate-v2-review.json';assert not p.exists();p.write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
print(json.dumps(review))
