"""Execute the unchanged affected root and circuit validation configurations."""
import gzip
import json
import os
from pathlib import Path
import re
import sys
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, reasons, resources, run, sha
W = Path(__file__).resolve().parent
C = V / 'checkout-candidate-v1'
TARGET = V / 'target-candidate-v1'
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert not (V / 'modeling-downstream-protocol-v1.json').exists()
compiler = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p) == h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
cargo = str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
pins = {p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
def verify():
    for name, digest in pins.items():
        path = C / name
        assert not path.is_symlink() and sha(path) == digest, name
    assert not reasons(resources())
commands = [
    ('modeling-check-minimal-v1', ['check', '--locked', '--no-default-features'], False),
    ('modeling-check-default-v1', ['check', '--locked'], False),
    ('modeling-check-all-v1', ['check', '--locked', '--all-features'], False),
    ('modeling-clippy-v1', ['clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings'], False),
    ('modeling-tests-default-v1', ['test', '--locked', '--', '--test-threads=2'], True),
    ('modeling-tests-all-v1', ['test', '--locked', '--all-features', '--', '--test-threads=2'], True),
    ('modeling-docs-v1', ['doc', '--locked', '--no-deps', '--all-features'], False),
    ('circuit-tests-default-v1', ['test', '--locked', '-p', 'hypercircuit', '--', '--test-threads=2'], True),
    ('circuit-tests-all-v1', ['test', '--release', '--locked', '-p', 'hypercircuit', '--all-features', '--', '--test-threads=2'], True),
    ('circuit-clippy-all-v1', ['clippy', '--locked', '-p', 'hypercircuit', '--all-targets', '--all-features', '--', '-D', 'warnings'], False)]
verify()
dump(V / 'modeling-downstream-protocol-v1.json', {
    'helper_sha256':sha(Path(__file__)), 'contract_sha256':sha(W / 'contract-v1.md'),
    'runner_sha256':sha(V / 'control/validation_runner_v2.py'),
    'source_inventory_sha256':sha(V / 'candidate-source-inventory-v1.json.gz'),
    'source':str(C), 'target':str(TARGET), 'source_pin_count':len(pins),
    'commands':[[name, [cargo, *args], test] for name,args,test in commands],
    'test_threads':2, 'wall_limit_seconds_per_command':1800,
    'performance_comparison':False, 'source_changes':False, 'candidate_admitted':False})
results = {}
summaries = {}
for name, args, is_test in commands:
    verify()
    if name == 'modeling-docs-v1': os.environ['RUSTDOCFLAGS'] = '-D warnings'
    results[name] = run(name, [cargo, *args], C, target=TARGET)
    if name == 'modeling-docs-v1': os.environ.pop('RUSTDOCFLAGS')
    if is_test:
        stdout = (V / 'logs' / name / 'stdout').read_text()
        rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout, re.M)
        assert rows and all(row[0] == 'ok' and row[2] == '0' and row[5] == '0' for row in rows)
        summaries[name] = {'rows':rows, 'passed':sum(int(row[1]) for row in rows),
            'failed':0, 'ignored':sum(int(row[3]) for row in rows)}
    verify()
    dump(V / 'modeling-downstream-progress-v1.json', {'commands':results, 'test_summaries':summaries})
dump(V / 'modeling-downstream-result-v1.json', {
    'complete':True, 'commands':results, 'test_summaries':summaries, 'source_unchanged':True,
    'root_ci_feature_configurations_passed':True, 'circuit_default_and_all_features_passed':True,
    'all_workspace_ci_passed':False, 'all_bindings_complete':False,
    'external_distribution_complete':False, 'candidate_admitted':False, 'full_plan_complete':False})
print(json.dumps({'modeling_and_circuit_complete':True,
    'test_counts':{k:{field:row[field] for field in ['passed','failed','ignored']} for k,row in summaries.items()},
    'candidate_admitted':False}), flush=True)
