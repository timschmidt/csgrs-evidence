# Modeling and circuit qualification for the cache-only candidate

The owning invariant remains Hypercurve's exact circular-support cache. P4,
P17-P20, P25-P30 and P36 require that current modeling and circuit consumers
preserve exact meaning, evidence and visible failure. No source, policy,
fixture or output contract is changed by this validation.

Use the root CI's no-default/default/all-feature check configurations, strict
all-target/all-feature Clippy, and both complete default and all-feature debug
test commands. The only local test scheduling difference is two workers for
containment. Run warnings-as-errors documentation. Hypercircuit's default
workspace-CI tests do not activate its curve dependency, so also run complete
all-feature release tests and strict all-target/all-feature Clippy to exercise
layout, geometry, DRC and interchange consumers. Record each scope separately.

Use the existing open candidate target and locked offline dependencies. Verify
all materialized non-comparison source and fixture inputs before and after
commands. Preserve every failure, ignored test count and raw terminal summary.
Every command retains the external 1,800-second wall limit, 8 GiB child address
space, 2 GiB host available-memory reserve, 512 MiB volume reserve, 64 GiB fresh
volume consumption limit and 64 MiB aggregate command logs. No measured native
gate or other qualification workload runs concurrently.

These are local consumer checks, not proof of the entire infinite domain, all
workspace CI configurations, default CI worker scheduling, installed packages,
all bindings or release readiness. A passing suite cannot by itself admit the
optimization without the remaining artifact and cost evidence.
