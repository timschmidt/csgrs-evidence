set -eu
s=/dev/shm/interval-budget-receipt
stage=$1
root=$2
. /dev/shm/interval-horner-readmission/env
export CARGO_TARGET_DIR="$s/fast-target-$3"
v=$3
for t in wasm32-wasip1 x86_64-unknown-linux-gnu; do
  cargo "+$v" build --locked --release --manifest-path "$root/client/Cargo.toml" --target "$t" > "$s/logs/$stage-$v-$t-public.build" 2>&1
  p="$CARGO_TARGET_DIR/$t/release/receipt-boundaries"
  if test "$t" = wasm32-wasip1; then
    /dev/shm/interval-dynamics-wasi/v24.22.3/bin/node /mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$p.wasm" > "$s/logs/$stage-$v-$t-public.run" 2>&1
  else
    "$p" > "$s/logs/$stage-$v-$t-public.run"
  fi
done
