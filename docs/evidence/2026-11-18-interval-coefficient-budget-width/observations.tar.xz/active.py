from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
for name,args,params in [('consume','kind: WorkKind, amount: usize','kind, amount'),('observe_coefficient_bits','bits: u64','bits')]:
 a=s.index('    STACK.with_borrow_mut',s.index('pub fn '+name+'('))
 s=s[:a]+f'    {name}_active({params})\n}}\n\n#[inline(never)]\nfn {name}_active({args}) -> Result<(), BudgetExceeded> {{\n'+s[a:]
p.write_text(s)
