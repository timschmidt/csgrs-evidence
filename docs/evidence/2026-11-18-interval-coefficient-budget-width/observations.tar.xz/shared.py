from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/work_budget.rs';s=p.read_text();assert 'pub limit: u64' in s
s=s.replace('    exhausted: Option<BudgetExceeded>,\n','')
a=s.index('// The outermost cancelled scope');b=s.index('std::thread_local!',a)
s=s[:a]+'''struct BudgetStack {
    frames: Vec<Frame>,
    // A denied request exhausts a suffix. Until its first frame exits, every
    // operation and every new child observes the same receipt.
    failure: Option<(usize, BudgetExceeded)>,
}

impl BudgetStack {
    fn exhaustion(&self) -> Option<BudgetExceeded> {
        self.failure.map(|(_, error)| error)
    }

    fn observe_cancellation(&mut self, requested: usize) -> Option<BudgetExceeded> {
        if let Some(error) = self.exhaustion() {
            return Some(error);
        }
        let index = self.frames.iter().position(|frame| {
            frame.cancellation.as_ref().is_some_and(CancellationToken::is_cancelled)
        })?;
        let error = BudgetExceeded::cancelled(requested);
        self.failure = Some((index, error));
        Some(error)
    }

    fn pop(&mut self) -> (WorkUsage, Option<BudgetExceeded>) {
        let frame = self.frames.pop().expect("a budget scope owns its frame");
        let error = self.exhaustion();
        if self.failure.is_some_and(|(index, _)| index == self.frames.len()) {
            self.failure = None;
        }
        ACTIVE.with(|active| active.set(!self.frames.is_empty()));
        (frame.usage, error)
    }
}

'''+s[b:]
s=s.replace('static FRAMES: RefCell<Vec<Frame>> = const { RefCell::new(Vec::new()) };','static STACK: RefCell<BudgetStack> = const { RefCell::new(BudgetStack { frames: Vec::new(), failure: None }) };')
a=s.index('    FRAMES.with_borrow_mut',s.index('pub fn exhaustion()'));b=s.index('\n}',a)
s=s[:a]+'''    STACK.with_borrow_mut(|stack| stack.observe_cancellation(0))'''+s[b:]
s=s.replace('''    FRAMES.with_borrow_mut(|frames| {
        if let Some(error) = frames.last().and_then(|frame| frame.exhausted) {
            return Err(error);
        }
        if let Some(error) = observe_cancellation(frames, ''','''    STACK.with_borrow_mut(|stack| {
        if let Some(error) = stack.observe_cancellation(''')
s=s.replace('for index in 0..frames.len() {\n            let (limit, used) = frames[index].available(kind);','for (index, frame) in stack.frames.iter().enumerate() {\n            let (limit, used) = frame.available(kind);').replace('''                for frame in &mut frames[index..] {
                    frame.exhausted = Some(error);
                }''','''                stack.failure = Some((index, error));''').replace('for frame in frames {','for frame in &mut stack.frames {')
s=s.replace('let Some(index) = frames\n','let Some(index) = stack.frames\n').replace('let limit = frames[index]','let limit = stack.frames[index]')
a=s.index('        for frame in &mut frames[index..]');b=s.index('\n    })',a);s=s[:a]+'''        stack.failure = Some((index, error));
        Err(error)'''+s[b:]
a=s.index('        fn finish(mut self) -> Frame');b=s.index('\n    let scope = Scope(true);',a);s=s[:a]+'''        fn finish(mut self) -> (WorkUsage, Option<BudgetExceeded>) {
            self.0 = false;
            STACK.with_borrow_mut(BudgetStack::pop)
        }
    }

    impl Drop for Scope {
        fn drop(&mut self) {
            if self.0 {
                STACK.with_borrow_mut(BudgetStack::pop);
            }
        }
    }

    STACK.with_borrow_mut(|stack| {
        stack.frames.push(Frame {
            budget,
            usage: WorkUsage::default(),
            cancellation,
            max_coefficient_bits,
        });
        ACTIVE.with(|active| active.set(true));
    });'''+s[b:]
s=s.replace('let frame = scope.finish();','let (usage, exhausted) = scope.finish();').replace('match frame.exhausted {','match exhausted {').replace('usage: frame.usage,','usage,')
assert 'FRAMES' not in s and 'frame.exhausted' not in s and 'observe_cancellation(0)' in s
p.write_text(s)
