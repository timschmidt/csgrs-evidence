from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,sys
s=Path(__file__).resolve().parent;tag=sys.argv[1];runner='/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs';node='/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node'
def run(v):
 env=os.environ|{'CARGO_TARGET_DIR':str(s/f'fast-target-{v}')}
 for t in ['wasm32-wasip1','x86_64-unknown-linux-gnu']:
  build=['cargo','+'+v,'build','--release','--locked','--manifest-path',str(s/'client/Cargo.toml'),'--bin','lifetime','--target',t]
  with (s/'logs'/f'{tag}-{v}-{t}.lifetime-build').open('w') as log:subprocess.run(build,env=env,stdout=log,stderr=log,check=True)
  p=Path(env['CARGO_TARGET_DIR'])/t/'release/lifetime'; cmd=[str(p)] if t.startswith('x86') else [node,runner,str(p)+'.wasm']
  rows=[]
  for depth in [1,4,32]:
   for mode in ['success','deny','cancel','wide']:
    got=subprocess.run([*cmd,str(depth),mode],capture_output=True,text=True)
    if tag=='control' and mode=='wide' and t.startswith('wasm'):
     assert got.returncode and '4294967295' in got.stderr
     continue
    assert got.returncode==0,(got.stdout,got.stderr)
    for line in got.stdout.splitlines():
     parts=line.split();assert len(parts)==11,parts
     rows.append({'state':parts[0],'depth':int(parts[1]),'mode':parts[2],**dict(zip(('alloc','free','realloc','traffic','peak','retained','error_size','outcome_size'),map(int,parts[3:])))})
  (s/f'{tag}-{v}-{t}-lifetime.json').write_text(json.dumps(rows,indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(run,['stable','1.95.0']))
