from pathlib import Path
import sys,json
s=Path(__file__).resolve().parent
tags=sys.argv[1:] or ['wide','shared','outlined']
results={}
for stage in tags:
 records={}
 for v in ('stable','1.95.0'):
  for t in ('wasm32-wasip1','x86_64-unknown-linux-gnu'):
   key=v+'-'+t
   def read(tag,suffix):return json.loads((s/f'{tag}-{key}{suffix}.json').read_text())
   c,b=read(stage,''),read('control','');assert c.keys()==b.keys()
   delta={n:{k:c[n][k]-u[k] for k in ('file','code','functions')} for n,u in b.items()}
   big=[(n,k,m) for n,row in delta.items() for k,m in row.items() if m>min(4096,b[n][k]//100)]
   old=read('control','-lifetime');new=read(stage,'-lifetime');extra=[]
   for i in old:
    j=next(x for x in new if all(i[k]==x[k] for k in ('state','mode','depth')))
    for k in ('alloc','realloc','peak','retained'):
     d=j[k]-i[k];maxinc=min(128,max(0,i[k])//20) if k in ('peak','retained') else 0
     if d>maxinc:extra.append([i['mode'],i['state'],i['depth'],k,i[k],j[k],maxinc])
   records[key]={'linked_deltas':delta,'incremental_size_failures':big,'ordinary_incremental_memory_failures':extra}
   a=[(x['depth'],x['peak'],x['retained']) for x in new if x['state']=='cold' and x['mode']=='success']
   print(stage,key,'size',big,'memory failures',len(extra),'success heap',a)
 results[stage]=records
(s/'review.json').write_text(json.dumps(results,indent=2)+'\n')
