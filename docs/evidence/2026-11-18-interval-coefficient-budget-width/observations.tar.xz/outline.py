from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
a=s.index('fn enter<T>(');b=s.index('    struct Scope(bool);',a);c=s.index('    STACK.with_borrow_mut(|stack| {\n        stack.frames.push',b);d=s.index('    let value = operation();',c);e=s.index('\n#[cfg(test)]',d)
decl=s[a:b];scope=s[b:c];begin=s[c:d]
scope='\n'.join(line[4:] if line else '' for line in scope.split('\n'))
scope=scope.replace('    fn finish(mut self)', '    #[inline(never)]\n    fn finish(mut self)')
scope=scope.replace('impl Scope {','''impl Scope {
    #[inline(never)]
    fn push(budget: WorkBudget, cancellation: Option<CancellationToken>, max_coefficient_bits: Option<u64>) -> Self {
        STACK.with_borrow_mut(|stack| {
            stack.frames.push(Frame { budget, usage: WorkUsage::default(), cancellation, max_coefficient_bits });
            ACTIVE.with(|active| active.set(true));
        });
        Self(true)
    }

''')
s=s[:a]+scope+'\n'+decl+'    let scope = Scope::push(budget, cancellation, max_coefficient_bits);\n'+s[d:]
p.write_text(s)
