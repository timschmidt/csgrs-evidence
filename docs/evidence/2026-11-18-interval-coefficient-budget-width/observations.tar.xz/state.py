from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
a=s.index('struct Frame {');b=s.index('    fn spend',a)
s=s[:a]+'''struct Limits {
    budget: WorkBudget,
    max_coefficient_bits: Option<u64>,
}

struct Frame {
    // A failed scope can only replay its first receipt. Its limits cannot be
    // consumed again, including while unwinding through nested scopes.
    limits: Result<Limits, BudgetExceeded>,
    usage: WorkUsage,
    cancellation: Option<CancellationToken>,
}

impl Frame {
    fn failure(&self) -> Option<BudgetExceeded> {
        self.limits.as_ref().err().copied()
    }

    fn available(&self, kind: WorkKind) -> Result<(usize, usize), BudgetExceeded> {
        let budget = self.limits.as_ref().map_err(|error| *error)?.budget;
        Ok(match kind {
            WorkKind::RootRefinement => (budget.refinements, self.usage.refinements),
            WorkKind::AlgebraicPromotion => (budget.promotions, self.usage.promotions),
            WorkKind::Cancellation | WorkKind::CoefficientGrowth => (0, 0),
        })
    }

'''+s[b:]
s=s.replace('frame.exhausted.get_or_insert(error);','frame.limits = Err(error);').replace('frame.exhausted = Some(error);','frame.limits = Err(error);').replace('.and_then(|frame| frame.exhausted)','.and_then(Frame::failure)').replace('frames[index].available(kind);','frames[index].available(kind)?;')
a=s.index('        let Some(index) = frames\n',s.index('pub fn observe_coefficient_bits'));b=s.index('        let error = BudgetExceeded',a)
s=s[:a]+'''        let Some((index, limit)) = frames.iter().enumerate().find_map(|(index, frame)| {
            let limit = frame.limits.as_ref().ok()?.max_coefficient_bits?;
            (bits > limit).then_some((index, limit))
        }) else {
            return Ok(());
        };
'''+s[b:]
s=s.replace('''        let exhausted = frames.last().and_then(Frame::failure);
        frames.push(Frame {
            budget,
            usage: WorkUsage::default(),
            exhausted,
            cancellation,
            max_coefficient_bits,
        });''','''        let limits = match frames.last().and_then(Frame::failure) {
            Some(error) => Err(error),
            None => Ok(Limits { budget, max_coefficient_bits }),
        };
        frames.push(Frame { limits, usage: WorkUsage::default(), cancellation });''').replace('match frame.exhausted {','match frame.failure() {')
assert 'frame.exhausted' not in s and 'let limits = match' in s
p.write_text(s)
