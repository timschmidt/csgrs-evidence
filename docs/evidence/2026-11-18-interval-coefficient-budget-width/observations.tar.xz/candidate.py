from pathlib import Path
import sys
s=Path(__file__).resolve().parent;root=Path(sys.argv[1]);p=root/'crates/hypersolve/src/work_budget.rs'
t=p.read_text().replace('pub limit: usize,','pub limit: u64,').replace('pub requested: usize,','pub requested: u64,').replace('            requested,\n','            requested: requested as u64,\n').replace('                    limit,\n','                    limit: limit as u64,\n').replace('requested: amount,','requested: amount as u64,').replace('limit: usize::try_from(limit).unwrap_or(usize::MAX),','limit,').replace('requested: usize::try_from(bits).unwrap_or(usize::MAX),','requested: bits,')
p.write_text(t)
for file,old,new in [('crates/hyperbrep/tests/work_budget.rs','denied.limit, single.usage.refinements','denied.limit, single.usage.refinements as u64'),('crates/hypersolve/tests/trivariate_arithmetic.rs','exceeded.limit, promotions','exceeded.limit, promotions as u64')]:
 p=root/file;text=p.read_text();assert old in text;p.write_text(text.replace(old,new))
