set -eu
s=/dev/shm/interval-lattice-coverage
root=/mnt/development/csgrs
. "$s/env"
cd "$s/control"
git diff > "$s/control-collector.patch"
git restore scripts/interval_coverage.py
fixed=c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb
git switch --detach "$fixed"
python3 "$s/size.py" fixed > "$s/fixed-build.log" 2>&1
git switch --detach "$(cat "$s/previous")"
file=crates/hyperlattice-interval/src/affine/translated.rs
sed -i '/if self.is_empty() {/{n;s/return IntervalVector::empty();/return Ok(translation.hull(translation, context)?);/;}' "$file"
git diff -- "$file" > "$s/mutation.patch"
test -s "$s/mutation.patch"
export CARGO_TARGET_DIR="$s/mutation-target"
cargo test --locked -p hyperlattice-interval --lib --tests --all-features > "$s/mutation-old-suite.log" 2>&1
cp "$root/crates/hyperlattice-interval/tests/centered_affine.rs" crates/hyperlattice-interval/tests/
if cargo test --locked -p hyperlattice-interval --all-features --test centered_affine > "$s/mutation-new-suite.log" 2>&1; then exit 1; fi
rg -q 'translated_replay_revalidates_and_preserves_cancellation .* FAILED' "$s/mutation-new-suite.log"
git restore "$file"
. "$s/env"
cp "$root"/crates/hyperlattice-interval/src/{lib.rs,array_construction_tests.rs} crates/hyperlattice-interval/src/
python3 "$s/size.py" final > "$s/final-build.log" 2>&1
