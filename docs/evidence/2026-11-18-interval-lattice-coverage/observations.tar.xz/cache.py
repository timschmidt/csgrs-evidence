from pathlib import Path
import shutil
s=Path(__file__).parent
d=s/'cargo-home/registry';old=Path('/home/tim/.cargo/registry');idx='index.crates.io-1949cf8c6b5b557f'
shutil.copytree(old/'index'/idx,d/'index'/idx,dirs_exist_ok=True)
for k in ['src','cache']:
 dest=d/k/idx;dest.mkdir(parents=True,exist_ok=True)
 for p in (old/k/idx).iterdir():
    f=dest/p.name
    if not f.exists():f.symlink_to(p.resolve())
