from pathlib import Path
import ast, json, re, subprocess, textwrap
s=Path('/dev/shm/interval-lattice-coverage')
root=Path('/mnt/development/csgrs')
def readjson(name):return json.loads((s/(name+'.json')).read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True)
prev=(s/'previous').read_text().strip()
final=(s/'source-revision').read_text().strip()
old=git('show',prev+':crates/hyperlattice-interval/src/lib.rs')
new=git('show',final+':crates/hyperlattice-interval/src/tests.rs')
assert textwrap.dedent(old.split('mod array_construction_tests {\n')[1].rsplit('\n}',1)[0])+'\n'==new
p='scripts/interval_coverage.py'
a,b=[ast.parse(git('show',r+':'+p)) for r in (prev,final)]
row=next(x for x in b.body if isinstance(x,ast.Assign) and x.targets[0].id=='TEST_MODULES')
i=next(i for i,k in enumerate(row.value.keys) if k.value=='hyperlattice-interval')
del row.value.keys[i],row.value.values[i]
assert ast.dump(a)==ast.dump(b)
for ver in ('1.95.0','nightly'):
    a,b=[readjson(k+'-'+ver) for k in ('separated','admitted')]
    assert b['excluded_test_modules']==['src/tests.rs']
    assert len(b['objects'])==24 and len(b['files'])==15
    for m,gain in {'functions':2,'lines':10,'branches':int(ver=='nightly'),'regions':6 if ver=='nightly' else 8}.items():
        assert a['production'][m]['count']==b['production'][m]['count']
        assert b['production'][m]['covered']-a['production'][m]['covered']==gain
    f=b['files']['src/affine/translated.rs']
    assert all(f[m]['count']==f[m]['covered'] for m in ['functions','lines','branches'])
for name in ['base','preceding','accepted']:
    assert 'FAILED' not in (s/('matched-test-'+name+'.log')).read_text()
aa,bb,cc=[readjson(k+'-linked') for k in ['base','preceding','accepted']]
assert bb['fixed_affine']['sha256']==cc['fixed_affine']['sha256']
for k in bb:
    assert cc[k]['file']<=bb[k]['file']
    for m in ['named_text']:
        assert cc[k][m]==bb[k][m]
    assert cc[k]['sections']['.text']['bytes']==bb[k]['sections']['.text']['bytes']
    assert cc[k]['file']<=48*1024**2
    for m,v in cc[k]['sections'].items():
        previous=bb[k]['sections'][m]['bytes'];fixed=aa[k]['sections'][m]['bytes']
        increase=v['bytes']-previous
        if increase>0:
            assert (k,m,increase)==('hyperlattice_interval','.rodata',16)
            assert increase<=4096 and increase<=0.01*previous
            assert v['bytes']-fixed<=16384 and v['bytes']-fixed<=0.02*fixed
assert 'left: IntervalVector' in (s/'mutation-release.log').read_text()
for m in ['domain','enclosure']:
    assert 'test result: FAILED' in (s/('mutation-'+m+'-new.log')).read_text()
    assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(s/('mutation-'+m+'-old.log')).read_text())))==93
print('Verified test-body identity, unchanged collector logic, two coverage pairs, three linked stages, source-domain, projection and empty-image mutation controls.')
