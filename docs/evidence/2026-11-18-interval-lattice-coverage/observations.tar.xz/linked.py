import hashlib,json,pathlib,subprocess,sys
s=pathlib.Path('/dev/shm/interval-lattice-coverage')
seen={}
def run(cmd):return subprocess.check_output(cmd,cwd=s/'control',text=True)
for selection in [['test','--lib','--test','centered_affine','--no-run'],['build','--example','fixed_affine']]:
    for l in run(['cargo',*selection,'-p','hyperlattice-interval','--locked','--release','--all-features','--message-format=json-render-diagnostics']).splitlines():
        r=json.loads(l)
        if not r.get('executable'):continue
        path=pathlib.Path(r['executable'])
        parts=run(['objdump','-h',path]).splitlines(); data=path.read_bytes()
        sizes={}
        for i,line in enumerate(parts[:-1]):
            fields=line.split()
            if fields and fields[0].isdigit() and 'ALLOC' in parts[i+1]:
                length=int(fields[2],16);offset=int(fields[5],16)
                sizes[fields[1]]={'bytes':length,'sha256':hashlib.sha256(data[offset:offset+length]).hexdigest() if 'CONTENTS' in parts[i+1] else None}
        symbols=[line.split() for line in run(['nm','-S','--defined-only',path]).splitlines()]
        seen[r['target']['name']]={'sha256':hashlib.sha256(data).hexdigest(),'file':len(data),'named_text':sum(int(f[1],16) for f in symbols if len(f)>=4 and f[2] in ('t','T')),'sections':sizes}
(s/(sys.argv[1]+'-linked.json')).write_text(json.dumps(seen,indent=2)+'\n')
