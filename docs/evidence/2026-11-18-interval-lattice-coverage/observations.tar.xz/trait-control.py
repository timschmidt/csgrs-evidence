import pathlib,subprocess
s=pathlib.Path('/dev/shm/interval-lattice-coverage')
c=s/'control'
r=pathlib.Path('/mnt/development/csgrs')
p=pathlib.Path('crates/hyperlattice-interval/src/affine/translated.rs')
test=pathlib.Path('crates/hyperlattice-interval/tests/centered_affine.rs')
prod=(c/p).read_text()
for tag,old,new in [('domain','        self.parameter_domain()','        self.center.as_ref().unwrap_or(&self.parameters)'),('enclosure','        self.enclosure(context)','        self.parameters.hull(&self.parameters, context)')]:
    assert prod.count(old)==1
    (c/p).write_text(prod.replace(old,new))
    (s/('mutation-'+tag+'.patch')).write_bytes(subprocess.check_output(['git','diff','--',str(p)],cwd=c))
    try:
        for stage in ('old','new'):
            if stage=='old':subprocess.run(['git','restore',str(test)],cwd=c,check=True)
            else:(c/test).write_bytes((r/test).read_bytes())
            with (s/('mutation-'+tag+'-'+stage+'.log')).open('w') as log:
                rc=subprocess.run(['cargo','test','--locked','-p','hyperlattice-interval','--all-features',*(['--lib','--tests'] if stage=='old' else ['--test','centered_affine'])],cwd=c,stdout=log,stderr=subprocess.STDOUT).returncode
            assert (rc==0)==(stage=='old'),(tag,stage,rc)
    finally:(c/p).write_text(prod)
