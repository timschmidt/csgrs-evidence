set -eu
s=/dev/shm/interval-lattice-coverage
. "$s/env"
stage=$1
compiler=$2
checkout=$3
export CARGO_TARGET_DIR="$s/cov-$(basename "$checkout")-$compiler"
if [ "$compiler" = nightly ]; then export RUSTUP_HOME=/dev/shm/interval-flow-coverage/rustup RUSTUP_TOOLCHAIN=nightly RUSTFLAGS=-Zcoverage-options=branch; fi
cd "$checkout"
rc=0
python3 scripts/interval_coverage.py --package hyperlattice-interval > "$s/$stage-$compiler.log" 2>&1 || rc=$?
test "$rc" -eq 1
rg -q 'Production coverage is below 100%' "$s/$stage-$compiler.log"
dir=$(sed -n 's/^Coverage artifacts in //p' "$s/$stage-$compiler.log" | head -1)
cp "$dir/summary.json" "$s/$stage-$compiler.json"
cp "$dir/uncovered.txt" "$s/$stage-$compiler.txt"
