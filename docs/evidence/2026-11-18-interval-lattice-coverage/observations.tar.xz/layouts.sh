set -eu
s=/dev/shm/interval-lattice-coverage
cd "$s/control"
. "$s/env"
d=crates/hyperlattice-interval/src
cp "$s/original-module.rs" "$d/tests.rs"
sed -i '/^mod array_construction_tests;/i #[path = "tests.rs"]' "$d/lib.rs"
python3 "$s/linked.py" short-path
sed -i '/^#\[path = "tests.rs"\]/d;s/^mod array_construction_tests;/mod tests;/' "$d/lib.rs"
python3 "$s/linked.py" standard-module
