set -eu
s=/dev/shm/interval-lattice-coverage
root=/mnt/development/csgrs
cd "$s/control"
. "$s/env"
python3 "$s/linked.py" retained
git restore crates/hyperlattice-interval/{src/lib.rs,tests/centered_affine.rs}
rm crates/hyperlattice-interval/src/array_construction_tests.rs
python3 "$s/linked.py" previous
git switch --detach c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb
python3 "$s/linked.py" fixed
git switch --detach "$(cat "$s/previous")"
cp "$root"/crates/hyperlattice-interval/src/{lib.rs,array_construction_tests.rs} crates/hyperlattice-interval/src/
cp "$root/scripts/interval_coverage.py" scripts/interval_coverage.py
bash "$s/cover.sh" separated 1.95.0 "$PWD"
