set -eu
s=/dev/shm/interval-lattice-coverage
root=/mnt/development/csgrs
. "$s/env"
export CARGO_TARGET_DIR="$s/matched-target"
cd "$s/control"
d=crates/hyperlattice-interval
git restore "$d/src/lib.rs" "$d/tests/centered_affine.rs" scripts/interval_coverage.py
rm -f "$d/src/tests.rs" "$d/src/array_construction_tests.rs"
for stage in base preceding accepted; do
 case $stage in
 base) git switch --detach c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb ;;
 preceding) git switch --detach "$(cat "$s/previous")";;
 accepted) cp "$root/$d/src/"{lib.rs,tests.rs} "$d/src/"
           cp "$root/$d/tests/centered_affine.rs" "$d/tests/"
           cp "$root/scripts/interval_coverage.py" scripts/interval_coverage.py ;;
 esac
 cargo clean -p hyperlattice-interval --release > "$s/matched-clean-$stage.log" 2>&1
 python3 "$s/linked.py" "$stage" > "$s/matched-build-$stage.log" 2>&1
 cargo test --locked --release -p hyperlattice-interval --all-features --test centered_affine --lib > "$s/matched-test-$stage.log" 2>&1
 cargo run --locked --release -p hyperlattice-interval --all-features --example fixed_affine > "$s/matched-output-$stage.log" 2>&1
done
file="$d/src/affine/translated.rs"
git apply "$s/mutation.patch"
if cargo test --locked --release -p hyperlattice-interval --all-features --test centered_affine > "$s/mutation-release.log" 2>&1; then exit 1; fi
rg -q 'translated_replay_revalidates_and_preserves_cancellation .* FAILED' "$s/mutation-release.log"
git restore "$file"
