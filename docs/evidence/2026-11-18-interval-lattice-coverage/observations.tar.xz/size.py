import json, os, pathlib, hashlib, subprocess, sys
s = pathlib.Path('/dev/shm/interval-lattice-coverage')
stage = sys.argv[1]
cmd=['cargo','test','--release','--locked','-p','hyperlattice-interval','--all-features','--lib']
if (s/'control/crates/hyperlattice-interval/tests/centered_affine.rs').exists():
    cmd += ['--test','centered_affine']
cmd += ['--no-run','--message-format=json-render-diagnostics']
rows=subprocess.check_output(cmd,cwd=s/'control',text=True)
out={}
for line in rows.splitlines():
    row=json.loads(line)
    if row['reason']!='compiler-artifact' or not row.get('executable'): continue
    p=pathlib.Path(row['executable'])
    sections=subprocess.check_output(['size','-A',str(p)],text=True).splitlines()
    out[row['target']['name']]={'file':p.stat().st_size,'text':next(int(l.split()[1]) for l in sections if l.startswith('.text ')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(s/(stage+'-size.json')).write_text(json.dumps(out,indent=2)+'\n')
