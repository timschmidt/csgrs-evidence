from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess,tarfile
s=Path(__file__).parent
root=Path('/mnt/development/csgrs')
other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-lattice-coverage'
def git(r,*args):return subprocess.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
files={}
for p in s.iterdir():
    if p.is_file() and (p.suffix in ('.sh','.py','.rs','.log','.json','.patch') or p.name in ['scope','previous','source-revision','env','reproduce.txt','admitted-1.95.0.txt','admitted-nightly.txt']):
        files[p.name]=p.read_bytes()
for abi in ['bare','p1']:
    for p in (s/('wasm-'+abi)).iterdir():
        if p.suffix=='.log' or p.name in ['report.json','commands.json']:files[str(p.relative_to(s))]=p.read_bytes()
    assert 'wasm-'+abi+'/report.json' in files
assert files['source-revision'].decode().strip()==git(root,'rev-parse','HEAD').decode().strip()
assert 'Verified test-body identity' in files['verified.log'].decode()
files['rustc.txt']=subprocess.check_output(['rustc','+1.95.0','-vV'])
digests={k:hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())}
archive=s/'record';archive.mkdir(exist_ok=True)
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
    for name,b in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:
    assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record)
git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive interval lattice coverage, mutation controls and linked comparisons')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
(s/'evidence-revision').write_text(rev+'\n')
print(rev,rows[1])
