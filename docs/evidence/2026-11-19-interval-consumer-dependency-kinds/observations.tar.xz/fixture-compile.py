from pathlib import Path
import subprocess as sp,json
s=Path(__file__).resolve().parent
for name in ['directdev','buildonly','featureonly','normal']:
 root=s/name
 if name=='buildonly':(root/'build.rs').write_text('fn main() {}\n')
 out=sp.check_output(['cargo','check','--manifest-path',root/'Cargo.toml','--locked','--offline','--target','wasm32-unknown-unknown','--message-format=json'],cwd=root,text=True)
 rows=[x for x in map(json.loads,out.splitlines()) if x.get('reason')=='compiler-artifact' and x['target']['name']=='hyperinterval']
 guest=any('/wasm32-unknown-unknown/' in str(p) for row in rows for p in row['filenames'])
 print(name,'target artifact:',guest,'artifacts:',[str(Path(p).relative_to(s)) for row in rows for p in row['filenames']])
 assert guest==(name=='normal')
