from pathlib import Path
import sys,os,subprocess as sp,statistics,time,json
s=Path(__file__).resolve().parent;repo=s.parent/'alumina-interface';legacy=s/'before-audit.py'
# Give the archived script its real sibling root without writing into the checkout.
legacy.write_bytes(sp.check_output(['git','-C',repo,'show','96dd1b4fb4eb2a7039dd2f9d698ab313a6b9df8a:scripts/audit-sibling-sources.py']))
runner='import runpy,sys; from pathlib import Path; x=runpy.run_path(sys.argv.pop(1)); x["main"].__globals__["ROOT"]=Path.cwd(); x["main"]()'
paths={'before':legacy,'after':repo/'scripts/audit-sibling-sources.py'}
samples={k:[] for k in paths}
for i in range(5):
 for label in (list(paths) if i%2==0 else list(reversed(paths))):
  t=time.monotonic();r=sp.check_output([sys.executable,'-B','-c',runner,str(paths[label]),'--coordinated'],cwd=repo,text=True);samples[label].append(time.monotonic()-t);assert len(r.splitlines())==9
(s/'timings.json').write_text(json.dumps(samples,indent=2));print({k:statistics.median(v) for k,v in samples.items()})
