from pathlib import Path
import json,subprocess as sp,re,hashlib
s=Path(__file__).resolve().parent
def read(name):return (s/name).read_text()
def sections(name):
 raw=read(name)
 tests=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',raw)))
 assert tests>0 and 'test result: FAILED' not in raw
 wasm=[line for line in raw.splitlines() if 'in each of two fresh instances' in line]
 assert len(wasm)==2
 return {'native_tests':tests,'wasm':wasm}
r={k:sections(k+'-consumers.log') for k in ['current','pinned']}
assert 'unchanged lockfile:' in read('real-control.log')
for n in ['current-full','pinned-full','msrv-full','pinned-msrv','check-fetch']:
 log=read(n+'.log');assert 'license inventories accepted' in log and len(re.findall(r'verified \d+ local package paths and versions',log))==9
for c in ['stable','1.95.0','1.88.0']:
 assert re.search(r'Ran 4 tests.*\n\nOK\n',read('final-tests-'+c+'.log'))
assert read('change.patch')==sp.check_output(['git','-C',s.parent/'alumina-interface','diff','96dd1b4fb4eb2a7039dd2f9d698ab313a6b9df8a',read('source-revision').strip(),'--','scripts'],text=True)
(s/'receipts.json').write_text(json.dumps(r,indent=2)+'\n')
print(r)
