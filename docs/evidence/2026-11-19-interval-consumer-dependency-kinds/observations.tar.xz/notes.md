# Coordinated sibling dependency audit

The release workload is the Alumina Interface source policy, the two standalone
interval consumers, their linked guests and embedded check. revisions.txt gives
Interface, CSGRS and firmware in that order, first current, then the deployment
pins. source-revision identifies the audited script change. Only the two Python
audit files differ from Interface 96dd1b4. The check runs separately for all
nine package/target pairs, including the fuzzing and measurement trace feature
selections. check-locks.py compares all seven lockfiles per stack to their Git
blobs. Tests do not regenerate these production lockfiles.

reproduce.py probes the original checker with standalone path-only packages.
In a fresh scratch directory run it against the Interface predecessor. Each
crate is named for its dependency configuration. fixtures-compile.log records
Cargo's actual artifact paths when compiling those fixtures for bare Wasm.
A build script's library is emitted into the host directory. A normal library
is emitted into the wasm32-unknown-unknown directory. Test-only and
test-feature-only relationships do not compile the required library there.

real-control.py changes the dependency kind of interval-foc-conformance in the
disposable deployment-pinned FOC guest manifest. All seven lockfiles stay
identical. The original audit accepts the change; the revised audit refuses the
named required packages. The script restores the original manifest on exit.
restored.log records the clean positive control after the mutation.

Current and deployment-pinned checkouts use the same audit scripts and
independent locked release configurations. The consumer runner executes the
native FOC and measurement tests, the Cortex-M FOC compile, and the linked
bare Wasm FOC and measurement programs. Each JavaScript runner invokes two
new Wasm instances. The Cargo target graph is evidence about dependency
selection. The numerical conformance runs supply the execution evidence.
Hosted deployment and physical hardware runs are outside this local replay.

The final five paired, alternating-order audit runs use warmed local caches
and report wall time in seconds. They include Cargo's nine target dependency
queries and all metadata checks. They do not benchmark the deployed kernels.
Toolchain-specific FOC graph checks on Rust 1.88 are in foc-msrv.log.
