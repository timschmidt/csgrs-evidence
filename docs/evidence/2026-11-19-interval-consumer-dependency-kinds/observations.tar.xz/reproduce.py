from pathlib import Path
import importlib.util,subprocess as sp,os
s=Path(__file__).resolve().parent
p=s.parent/'alumina-interface/scripts/audit-sibling-sources.py'
spec=importlib.util.spec_from_file_location('audit',p);audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
def pkg(name,deps):
 d=s/name;d.mkdir();(d/'src').mkdir();(d/'src/lib.rs').touch();(d/'Cargo.toml').write_text(f'[package]\nname="{name}"\nversion="1.0.0"\nedition="2021"\n[workspace]\nresolver="2"\n'+deps)
 return d
h=pkg('hyperinterval','')
helper=pkg('helper','[dependencies]\nhyperinterval={path="../hyperinterval",optional=true}\n')
for name,deps in [('directdev','[dev-dependencies]\nhyperinterval={path="../hyperinterval"}'),('buildonly','[build-dependencies]\nhyperinterval={path="../hyperinterval"}'),('featureonly','[dependencies]\nhelper={path="../helper"}\n[dev-dependencies]\nhelper={path="../helper",features=["hyperinterval"]}'),('normal','[dependencies]\nhyperinterval={path="../hyperinterval"}')]:
 c=pkg(name,deps);sp.run(['cargo','generate-lockfile','--offline'],cwd=c,check=True)
 owners=audit.workspace_packages([c,h,helper]);g=audit.metadata(c,'--filter-platform','wasm32-unknown-unknown')
 try:out=audit.check_graph(g,owners,{'hyperinterval'})
 except ValueError as e:out=str(e)
 tree=sp.check_output(['cargo','tree','--locked','--offline','--target','wasm32-unknown-unknown','--edges','normal,no-proc-macro','--prefix','none','--format','{p}'],text=True,cwd=c)
 print(name,'old audit',out,'normal target packages:',[x.split()[0] for x in tree.splitlines()])
