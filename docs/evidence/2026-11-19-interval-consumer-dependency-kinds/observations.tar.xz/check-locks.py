from pathlib import Path
import hashlib,json,subprocess as sp
s=Path(__file__).resolve().parent
paths={'alumina-interface':['Cargo.lock','fuzz/Cargo.lock'],'csgrs':['crates/hyperlattice-interval/conformance/alumina-foc/Cargo.lock','crates/hyperlattice-interval/conformance/alumina-foc/wasm/Cargo.lock','crates/hyperinterval/conformance/alumina-measurements/Cargo.lock','crates/hyperinterval/conformance/alumina-measurements/wasm/Cargo.lock'],'alumina-firmware':['Cargo.lock']}
out={}
for label,root in [('current',s.parent),('deploy',s/'ci')]:
 out[label]={}
 for repo,names in paths.items():
  for name in names:
   raw=(root/repo/name).read_bytes()
   assert sp.check_output(['git','-C',root/repo,'show','HEAD:'+name])==raw
   out[label][repo+'/'+name]=hashlib.sha256(raw).hexdigest()
(s/'lockfiles.json').write_text(json.dumps(out,indent=2)+'\n')
