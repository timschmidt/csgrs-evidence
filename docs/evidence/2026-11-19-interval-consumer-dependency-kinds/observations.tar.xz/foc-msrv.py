import importlib.util,os
from pathlib import Path
s=Path(__file__).resolve().parent
for root in [s.parent,s/'ci']:
 interface=root/'alumina-interface';cs=root/'csgrs';fw=root/'alumina-firmware';foc=cs/'crates/hyperlattice-interval/conformance/alumina-foc';guest=foc/'wasm'
 spec=importlib.util.spec_from_file_location('audit',interface/'scripts/audit-sibling-sources.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
 os.environ['RUSTUP_TOOLCHAIN']='stable';owners=audit.workspace_packages([fw,cs,foc,guest])
 os.environ['RUSTUP_TOOLCHAIN']='1.88.0'
 required={'alumina-foc','hyperinterval','hyperlattice-interval'}
 for path,target in [(foc,'x86_64-unknown-linux-gnu'),(foc,'thumbv7em-none-eabihf'),(guest,'wasm32-unknown-unknown')]:
  n=audit.check_target(path,target,owners,required|({'interval-foc-conformance'} if path==guest else set()))
  print(root.name,target,n)
