from pathlib import Path
import json
from record import record
s=Path(__file__).resolve().parent
items=[s/n for n in ['notes.md','foc-msrv.py','foc-msrv.log','archive.py','record.py','qualify.py','check-locks.py','fixture-compile.py','reproduce.py','real-control.py','audit-timing.py','change.patch','env','source-revision','revisions.txt','versions.txt','receipts.json','lockfiles.json','timings.json','timings.log','current-full.log','pinned-full.log','pinned-msrv.log','msrv-full.log','check-fetch.log','restored.log','pinned-tests.log','pinned-consumers.log','current-consumers.log','fixtures-compile.log','real-control.log','witness.log','before.log','final-tests-1.88.0.log','final-tests-1.95.0.log','final-tests-stable.log']]
result=record('consumer-dependency-kinds',items,'Record linked interval consumer and Cargo dependency-kind qualification')
(s/'archive-receipt.json').write_text(json.dumps(result));print(result)
