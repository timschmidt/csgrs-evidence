from pathlib import Path
import subprocess as sp,os,hashlib
s=Path(__file__).resolve().parent;repo=s/'ci/alumina-interface';foc=s/'ci/csgrs/crates/hyperlattice-interval/conformance/alumina-foc/wasm'
p=foc/'Cargo.toml';lock=foc/'Cargo.lock';old=p.read_text();lockbytes=lock.read_bytes()
legacy=repo/'scripts/baseline-audit.py'
assert not legacy.exists()
legacy.write_bytes(sp.check_output(['git','-C',repo,'show','HEAD:scripts/audit-sibling-sources.py']))
def run(script):
 r=sp.run(['python3','-B',script,'--coordinated'],cwd=repo,stdout=sp.PIPE,stderr=sp.STDOUT,text=True)
 print(r.stdout,end='');return r
try:
 direct='interval-foc-conformance = { path = ".." }'
 assert old.count(direct)==1 and '[dev-dependencies]' not in old
 p.write_text(old.replace(direct+'\n','').replace('[profile.release]','[dev-dependencies]\n'+direct+'\n\n[profile.release]'))
 before=run(legacy);assert before.returncode==0
 after=run(repo/'scripts/audit-sibling-sources.py')
 assert after.returncode!=0 and 'missing required workspace packages:' in after.stdout and 'interval-foc-conformance' in after.stdout.split('missing required workspace packages:')[-1]
 assert lock.read_bytes()==lockbytes
 print('unchanged lockfile:',hashlib.sha256(lockbytes).hexdigest())
finally:p.write_text(old);legacy.unlink()
