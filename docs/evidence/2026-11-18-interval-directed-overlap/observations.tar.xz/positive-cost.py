from pathlib import Path
import subprocess, concurrent.futures
s=Path(__file__).parent;t=Path('/dev/shm/interval-overlap/builds');out=s/'positive-costs';out.mkdir(exist_ok=True)
def observe(k,c):
 for i,n in enumerate(['directed-current','known-positive','known-positive','directed-current']):
  (out/f'{k}-{i}-{n}').write_bytes(subprocess.check_output(['taskset','-c',str(c),t/(n+'-'+k)]))
with concurrent.futures.ThreadPoolExecutor() as pool:
 fs=[pool.submit(observe,k,c) for k,c in [('order_cost',2),('division_cost',6),('tangent_cost',10),('fractional_power_cost',16)]]
 for f in fs:f.result()
