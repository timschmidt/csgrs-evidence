set -eu
s=/dev/shm/interval-directed-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/arrangement-target"
cargo +1.95.0 test --locked --release -p hyperinterval --no-default-features --features dyadic --test dyadic_set_relations --no-run --message-format=json > "$s/logs/$1-set-image.jsonl" 2> "$s/logs/$1-set-build"
python3 - "$1" <<'PY'
from pathlib import Path
import json,sys,shutil,subprocess
s=Path('/dev/shm/interval-directed-overlap');n=sys.argv[1]
img=next(v['executable'] for l in (s/'logs'/(n+'-set-image.jsonl')).read_text().splitlines() if (v:=json.loads(l)).get('executable'))
shutil.copy2(img,s/(n+'-set'));(s/'logs'/(n+'-set')).write_bytes(subprocess.check_output([img]))
PY
