use hyperinterval::{DyadicInterval, ExtendedInterval as E};

fn d(a: i64, b: i64) -> DyadicInterval {
    DyadicInterval::new(a.into(), b.into(), 0).unwrap()
}

pub fn components() -> Vec<(E<DyadicInterval>, u16)> {
    // These eleven cells alternate endpoints and open intervals. The first
    // and last represent the unbounded exterior cells.
    let mask = |lo: i32, hi: i32| -> u16 {
        (-5..=5).fold(0, |bits, k| (bits << 1) | u16::from(lo <= k && k <= hi))
    };
    let mut palette = vec![(E::empty(), 0), (E::entire(), mask(-5, 5))];
    for a in -2..=2 {
        let point = || d(a.into(), a.into());
        palette.push((E::above(point()).unwrap(), mask(2 * a, 5)));
        palette.push((E::below(point()).unwrap(), mask(-5, 2 * a)));
        for b in a..=2 {
            palette.push((E::from_finite(d(a.into(), b.into())), mask(2 * a, 2 * b)));
        }
    }
    palette
}
