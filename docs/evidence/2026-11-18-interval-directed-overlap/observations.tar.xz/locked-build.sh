set -eu
s=/dev/shm/interval-directed-overlap; t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/workspace-client-target"
build(){
 n=$1;shift
 (cd "$s/workspace-client"; cargo +1.95.0 build --release --locked --offline "$@"; cargo +1.95.0 build --release --lib --locked --offline --target wasm32-unknown-unknown "$@"; cargo +1.95.0 run --locked --release --example wide "$@") > "$s/logs/$n-build" 2>&1
 cp "$CARGO_TARGET_DIR/release/overlap-observer" "$t/builds/$n-native"
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/overlap_observer.wasm" "$t/builds/$n.wasm"
}
cd "$t/repo"
build workspace-bounds --features direct
git apply -R "$s/directed-bounds.patch"
build workspace-current
git switch --detach c9f1f9ac5
build workspace-fixed
git switch --detach aa92b60c0
git apply "$s/directed-bounds.patch"
python3 "$s/bench.py" workspace-bounds workspace-current > "$s/logs/workspace-timing"
node "$s/workspace-client/check.cjs" "$t/builds/workspace-current.wasm" "$t/builds/workspace-bounds.wasm" > "$s/logs/workspace-wasm"
