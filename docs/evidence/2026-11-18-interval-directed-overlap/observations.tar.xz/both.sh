set -eu
s=/dev/shm/interval-directed-overlap; t=/dev/shm/interval-overlap
bash "$s/build-state.sh" "$1"
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/workspace-client-target"
(cd "$s/workspace-client"
cargo +1.95.0 build --release --offline --locked --features direct
cargo +1.95.0 build --release --offline --locked --lib --target wasm32-unknown-unknown --features direct) > "$s/logs/workspace-$1-build" 2>&1
cp "$CARGO_TARGET_DIR/release/overlap-observer" "$t/builds/workspace-$1-native"
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/overlap_observer.wasm" "$t/builds/workspace-$1.wasm"
python3 "$s/bench.py" workspace-"$1" workspace-current > "$s/logs/workspace-$1-timing"
node "$s/workspace-client/check.cjs" "$t/builds/workspace-current.wasm" "$t/builds/workspace-$1.wasm" > "$s/logs/workspace-$1-wasm"
