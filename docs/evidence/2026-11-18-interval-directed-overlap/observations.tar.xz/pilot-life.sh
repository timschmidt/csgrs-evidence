set -eu
s=/dev/shm/interval-directed-overlap
. /dev/shm/interval-bisection/env
for d in standalone locked; do
 export CARGO_TARGET_DIR="$s/$d-life-target"
 (cd "$s/$d-lifetime" && cargo +1.95.0 build --locked --release --example division --bin overlap-lifetime --features direct) > "$s/logs/$1-$d-pilot-build" 2>&1
 "$CARGO_TARGET_DIR/release/examples/division" > "$s/logs/$1-$d-pilot-division" 2> "$s/logs/$1-$d-pilot-division-headroom"
 "$CARGO_TARGET_DIR/release/overlap-lifetime" > "$s/logs/$1-$d-pilot-life" 2> "$s/logs/$1-$d-pilot-life-headroom"
done
