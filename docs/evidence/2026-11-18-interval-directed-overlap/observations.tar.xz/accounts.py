from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,'/dev/shm/interval-overlap')
from metrics import sizes,wasm
s=Path(__file__).parent;t=Path('/dev/shm/interval-overlap/builds')
names=['fixed','current','bounds']
paths={};raw={};accounts=[];ledger=json.loads(Path('docs/research/interval-size-accounts.json').read_text());caps=ledger['existing_artifacts']
for prefix,tail,art in [
 ('directed','-native','dyadic-overlap qualification/native'),
 ('directed','.wasm','dyadic-overlap qualification/portable.wasm'),
 ('workspace','-native','dyadic-overlap qualification/workspace-native'),
 ('workspace','.wasm','dyadic-overlap qualification/workspace.wasm'),
 *[('directed','-'+n,'crates/hyperinterval/conformance/'+n+'.rs') for n in ['order_cost','division_cost','fractional_power_cost','tangent_cost']],
 ('directed','-set','crates/hyperinterval/tests/dyadic_set_relations.rs#release-tests')]:
 paths[art]=[(s if tail=='-set' else t)/(prefix+'-'+n+tail) for n in names]
for art,ps in paths.items():
 if not all(p.is_file() for p in ps):continue
 iswasm=art.endswith('.wasm')
 vals=[dict(file=p.stat().st_size,code=wasm(p)) if iswasm else sizes(p) for p in ps]
 target='wasm32-unknown-unknown' if iswasm else 'x86_64-unknown-linux-gnu'
 assert not any(a['artifact']==art and a['target']==target for a in ledger['accounts'])
 rows={}
 for k in sorted(set().union(*vals)):
  x,y,z=[v.get(k,0) for v in vals]
  c=caps['wasm_final_file_and_code' if iswasm else 'native_monomorphized_text_sum' if k=='function_union' else 'native_final_file_and_allocated_sections']
  prior=max(0,y-x);inc=max(0,z-y);cum=prior+inc
  passed=inc<=c['incremental_bytes'] and 100*inc<=c['incremental_percent']*y and cum<=c['cumulative_bytes'] and 100*cum<=c['cumulative_percent']*x
  if not passed: print('FAIL',art,k,x,y,z,inc,cum)
  rows[k]=dict(baseline=x,previous_retained=y,retained=z,prior_positive_growth_bytes=prior,incremental_growth_bytes=inc,incremental_growth_percent=round(100*inc/y,6) if y else 0,accepted_positive_growth_bytes=cum,remaining_cumulative_bytes=c['cumulative_bytes']-cum,remaining_cumulative_percent=round(c['cumulative_percent']-100*cum/x,6) if x else None,caps=c,passes_both_caps=passed)
 raw[art]=rows
 thumb=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 features=('dyadic (workspace lock)' if 'workspace' in art or '-set' in ps[0].name else 'dyadic (standalone client lock)') if 'qualification' in art or '-set' in ps[0].name else 'integer,fixed,rational,dyadic,float-enclosure'
 accounts.append(dict(artifact=art,role='Existing closed-set qualification test' if '-set' in ps[0].name else 'Completed mixed interval query client' if 'qualification' in art else 'Existing completed-workload cost executable',target=target,toolchain='Rust 1.95.0',features=features,profile='release',baseline_commit=ledger['baseline_commit'],previous_commit='aa92b60c0',baseline_sha256=thumb(ps[0]),previous_sha256=thumb(ps[1]),retained_sha256=thumb(ps[2]),metrics={k:r for k,r in rows.items() if r['accepted_positive_growth_bytes']},headroom=f'{64*2**20-ps[2].stat().st_size} bytes free within 64 MiB qualification allowance, 16 MiB required.',evidence='docs/evidence/2026-11-18-interval-directed-overlap'))
 assert ps[2].stat().st_size+16*2**20<=64*2**20
(s/'all-size-rows.json').write_text(json.dumps(raw,indent=2)+'\n')
(s/'new-accounts.json').write_text(json.dumps(accounts,indent=2)+'\n')
