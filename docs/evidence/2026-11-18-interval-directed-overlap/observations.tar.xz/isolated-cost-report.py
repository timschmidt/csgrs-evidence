from pathlib import Path
import csv,json,statistics,collections
s=Path(__file__).parent;d=s/'owner-costs';summary={}
for k in ['order_cost','division_cost','tangent_cost','fractional_power_cost']:
 raw=[list(csv.DictReader(p.open())) for p in sorted(d.glob(k+'-*'))];assert len(raw)==4
 ref=[{k:v for k,v in a.items() if k!='elapsed_ns'} for a in raw[0]]
 assert all([{k:v for k,v in a.items() if k!='elapsed_ns'} for a in r]==ref for r in raw)
 groups=collections.defaultdict(lambda:[[],[],[],[]])
 for i,r in enumerate(raw):
  for z in r:
   key=tuple((a,v) for a,v in z.items() if a not in ['elapsed_ns','sample'])
   groups[key][i].append(int(z['elapsed_ns']))
 by_group=[]
 for key,ds in groups.items():
  a=[statistics.median(x) for x in ds];before=statistics.median(a[::3]);after=statistics.median(a[1:3]);by_group.append(dict(group=dict(key),medians=a,ratio=after/before))
 ratios=[r['ratio'] for r in by_group];print(k,len(ref),len(groups),min(ratios),statistics.median(ratios),max(ratios))
 for r in sorted(by_group,key=lambda z:-z['ratio'])[:3]:print(' ',r)
 summary[k]=dict(rows=len(ref),by_group=by_group)
(s/'isolated-costs.json').write_text(json.dumps(summary,indent=2)+'\n')
