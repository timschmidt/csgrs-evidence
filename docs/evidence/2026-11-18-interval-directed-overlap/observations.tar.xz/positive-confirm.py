from pathlib import Path
import csv,subprocess,statistics,collections,json
s=Path(__file__).parent;t=Path('/dev/shm/interval-overlap/builds');import sys
cpu=sys.argv[1];p=s/('positive-confirm-'+cpu);p.mkdir(exist_ok=True);summary={}
for k in ['division_cost']:
 samples=collections.defaultdict(list)
 for i in range(10):
  local={}
  for v in (['directed-current','known-positive'] if i%2==0 else ['known-positive','directed-current']):
   name=p/f'{k}-{i}-{v}';name.write_bytes(subprocess.check_output(['taskset','-c',cpu,t/(v+'-'+k)],stderr=subprocess.DEVNULL));rs=list(csv.DictReader(name.open()))
   local[v]={}
   for row in rs:
    key=tuple((c,value) for c,value in row.items() if c not in ['sample','elapsed_ns'])
    local[v].setdefault(key,[]).append(int(row['elapsed_ns']))
  assert local['directed-current'].keys()==local['known-positive'].keys()
  for key,vv in local['known-positive'].items():samples[key].append(statistics.median(vv)/statistics.median(local['directed-current'][key]))
 rows=[dict(case=dict(key),ratios=v,median=statistics.median(v)) for key,v in samples.items()];summary[k]=rows;print(k,sorted([r['median'] for r in rows]))
(s/('positive-confirmation-'+cpu+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
