from pathlib import Path
import csv,subprocess,statistics,collections,json
s=Path(__file__).parent;t=Path('/dev/shm/interval-overlap/builds');p=s/'cost-confirm';p.mkdir(exist_ok=True);summary={}
for k in ['order_cost','division_cost']:
 samples=collections.defaultdict(list)
 for i in range(12):
  local={}
  for v in (['directed-current','empty-scan'] if i%2==0 else ['empty-scan','directed-current']):
   name=p/f'{k}-{i}-{v}';name.write_bytes(subprocess.check_output(['taskset','-c','18',t/(v+'-'+k)],stderr=subprocess.DEVNULL));rs=list(csv.DictReader(name.open()))
   local[v]={}
   for row in rs:
    key=tuple((c,value) for c,value in row.items() if c not in ['sample','elapsed_ns'])
    local[v].setdefault(key,[]).append(int(row['elapsed_ns']))
  assert local['directed-current'].keys()==local['empty-scan'].keys()
  for key,vv in local['empty-scan'].items():samples[key].append(statistics.median(vv)/statistics.median(local['directed-current'][key]))
 rows=[dict(case=dict(key),ratios=v,median=statistics.median(v)) for key,v in samples.items()];summary[k]=rows;print(k,sorted([r['median'] for r in rows]))
(s/'cost-confirmation.json').write_text(json.dumps(summary,indent=2)+'\n')
