from pathlib import Path
import subprocess,shutil,hashlib,json
s=Path(__file__).parent;t=Path('/dev/shm/interval-overlap');p=s/'package';p.mkdir(exist_ok=True)
def copy(x,y):y.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(x,y)
def same(x):copy(x,p/x.relative_to(s))
for x in s.iterdir():
 if x.is_file() and (x.suffix in ['.json','.py','.rs','.sh','.patch','.txt'] or x.name in ['scope','source-revision']):same(x)
for dirname in ['logs','confirmation','positive-memory','isolated-memory','owner-costs','normalized-costs','positive-costs','corpus','cost-confirm','workspace-client','standalone-lifetime','locked-lifetime','locked-query']:
 d=s/dirname
 if d.is_dir():shutil.copytree(d,p/dirname,dirs_exist_ok=True)
for d in s.iterdir():
 if d.is_dir() and d.name.startswith(('timing-','division-confirm-','positive-confirm-','isolated-confirm-')):shutil.copytree(d,p/d.name,dirs_exist_ok=True)
for n in ['probe','lifetime']:
 shutil.copytree(t/n,p/'controls'/n,dirs_exist_ok=True)
for n in ['env','toolchains.txt','metrics.py','image_metrics.py','probe-build.sh','build-only.sh']:copy(t/n,p/'controls'/n)
copy(Path('/dev/shm/interval-box-coverage/measure-rss.py'),p/'controls/measure-rss.py')
prefix=[x.stem for x in s.glob('*.patch')]
prefix+=['directed-fixed','directed-current','workspace-fixed','workspace-current','workspace-bounds','directed-bounds']
prefix+=['workspace-'+v for v in prefix]
index={};out=p/'images';out.mkdir(exist_ok=True)
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
def record(src,key,base=None):
 if key in index:return
 if base is None:
  copy(src,out/key);patch=key
 else:
  patch=key+'.zst';ref=out/base
  subprocess.run(['zstd','-q','-f','-10','--patch-from',ref,src,'-o',out/patch],check=True)
  v=s/'image-verify';subprocess.run(['zstd','-q','-d','-f','--patch-from',ref,out/patch,'-o',v],check=True);assert sha(v)==sha(src)
 index[key]={'size':src.stat().st_size,'sha256':sha(src),'file':patch,'base':base}
for tail in ['-native','.wasm','-order_cost','-division_cost','-tangent_cost','-fractional_power_cost']:
 root='directed-current'+tail;record(t/'builds'/root,root)
 for k in sorted(set(prefix)):
  key=k+tail;f=t/'builds'/key
  if f.is_file(): record(f,key,root)
for f in s.glob('*-set'):
 if f.is_file():record(f,f.name,'directed-current-set' if 'directed-current-set' in index and f.name!='directed-current-set' else None)
for n in ['isolated-dyadic_overlap','isolated-dyadic_set_relations','dyadic_set_relations','untouched-arrangement-image','retained-overlap-test']:
 if (s/n).is_file():record(s/n,n,'directed-current-set')
for v in prefix:
 for ext in ['-metrics.json','-build']:
  f=t/'logs'/(v+ext)
  if f.is_file():copy(f,p/'cost-builds'/f.name)
(p/'image-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(len(index),'replayable native/WASM images')
