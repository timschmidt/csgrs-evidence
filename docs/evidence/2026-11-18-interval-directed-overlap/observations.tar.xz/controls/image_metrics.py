import sys,subprocess,re,json
from pathlib import Path
def sizes(p):
 s={'file':p.stat().st_size}
 for l in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
  m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',l)
  if m and 'A' in m[3]:s[m[1]]=int(m[2],16)
 ranges=[]
 for l in subprocess.check_output(['readelf','-Ws',p],text=True).splitlines():
  r=l.split()
  if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit() and int(r[2]):
   a=int(r[1],16); ranges.append((a,a+int(r[2])))
 end=total=0
 for a,b in sorted(ranges):
  total+=max(0,b-max(a,end)); end=max(b,end)
 return s|{'function_union':total}
if __name__=='__main__':
 a,b=map(lambda f:sizes(Path(f)),sys.argv[1:])
 print(json.dumps({k:{'before':a.get(k,0),'after':v,'delta':v-a.get(k,0),'incremental_pass':v-a.get(k,0)<=(1024 if k=='function_union' else 4096) and 100*(v-a.get(k,0))<=a.get(k,0)*(.5 if k=='function_union' else 1)} for k,v in b.items()},indent=2))
