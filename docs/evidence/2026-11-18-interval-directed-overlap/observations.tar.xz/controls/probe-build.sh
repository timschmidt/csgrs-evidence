set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$t/probe-target"
cd "$t/probe"
v=$1;shift
cargo +1.95.0 build --offline --release "$@"
cp "$CARGO_TARGET_DIR/release/overlap-observer" "$t/builds/$v-native"
cargo +1.95.0 build --offline --release --lib --target wasm32-unknown-unknown "$@"
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/overlap_observer.wasm" "$t/builds/$v.wasm"
