use overlap_observer::Input;
use hyperinterval::DyadicBudget;
use std::hint::black_box;
mod allocations;
fn main(){
 for (label,i) in [
 ("different-grid",Input::make(0,1,3,0,2,3,1,0)),
 ("touch",Input::make(0,1,3,1,6,7,0,0)),
 ("extreme",Input::make(0,1,1,i32::MIN,1,1,i32::MAX,0)),
 ("rays",Input::make(1,-2,-1,0,1,2,0,7)),
 ("unions",Input::make(2,-2,-1,0,1,2,0,37))]{
 let run=||{let mut b=DyadicBudget::new(128,4096);let r=black_box(&i).compare(&mut b).unwrap();black_box((r,b.remaining_work()))};
 let v=allocations::measure(128,run);println!("RESULT {label} {:?} HEAP {:?}",run(),(v.allocations,v.deallocations,v.reallocations,v.allocated_bytes,v.peak_live_bytes,v.live_bytes));
 assert_eq!(v.live_bytes,0);
 let start=std::time::Instant::now();for _ in 0..100000{black_box(run());}println!("TIME {label} {}",start.elapsed().as_nanos());
 }
}
