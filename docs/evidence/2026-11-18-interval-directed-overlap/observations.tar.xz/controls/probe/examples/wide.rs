use hyperinterval::{DyadicBudget, DyadicInterval as D};
use overlap_observer::Input;
use std::hint::black_box;
#[path = "../src/allocations.rs"]
mod allocations;
fn main() {
    let one = D::point(1.into(), 0).unwrap();
    let high = (one.lower().unwrap().0 << 2048_usize) + 1_u8;
    let left = D::new(high.clone(), &high + 4_u8, 5).unwrap();
    for (name, lo, hi, expected) in [("touch", 4_u8, 6_u8, true), ("apart", 6, 8, false)] {
        let x = Input::Finite(left.clone(), D::new(&high + lo, &high + hi, 5).unwrap());
        let run = || {
            let mut budget = DyadicBudget::new(4096, 100000);
            assert_eq!(black_box(&x).compare(&mut budget), Ok(expected));
            black_box(budget.remaining_work())
        };
        let s = allocations::measure(128, run);
        assert_eq!(s.live_bytes, 0);
        println!("{name} remaining={} alloc={} realloc={} dealloc={} bytes={} peak={} retained={}",run(),s.allocations,s.reallocations,s.deallocations,s.allocated_bytes,s.peak_live_bytes,s.live_bytes);
    }
}
