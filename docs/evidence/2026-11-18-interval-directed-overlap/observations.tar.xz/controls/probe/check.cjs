const fs=require('node:fs'), assert=require('node:assert/strict');
function ext(lo,hi,s) {return [[lo,hi],[lo,Infinity],[-Infinity,hi],[-Infinity,Infinity],null][s%5];}
function common(a,b){return !!(a&&b&&a[0]<=b[1]&&b[0]<=a[1]);}
(async()=>{
 const modules=await Promise.all(process.argv.slice(2).map(p=>WebAssembly.compile(fs.readFileSync(p))));
 let n=0, reduced=0, saved=0;
 for(let run=0;run<2;run++){
  const instances=[];
  for(const m of modules){assert.deepEqual(WebAssembly.Module.imports(m),[]);instances.push((await WebAssembly.instantiate(m)).exports);}
  for(const e of [-2,0,2])for(const f of [-1,0,1])for(const [a,b] of [[-3,-1],[-1,1],[0,0],[1,3]])for(const [c,d] of [[-2,0],[0,1],[1,1]])for(let k=0;k<3;k++)for(const shape of k===2?[0,7,33,71,156,211,312,403,504,624]:k===1?Array.from({length:25},(_,i)=>i):[0]){
   const x=[a*2**e,b*2**e],y=[c*2**f,d*2**f];
   let u=[x],v=[y];if(k!==0){u=[ext(...x,shape)];v=[ext(...y,Math.floor(shape/5))];}
   if(k===2){u.push(ext(...y,Math.floor(shape/25)));v.push(ext(...x,Math.floor(shape/125)));}
   const truth=Number(u.some(i=>v.some(j=>common(i,j))));
   const out=instances.map(z=>z.overlap(k,a,b,e,c,d,f,shape,128,4096));
   for (const z of out) { assert.equal(z%8,truth);assert.ok(z<=out[0]); }
   if(out[1]<out[0]) { reduced++;saved+=(out[0]-out[1])/8; }
   n++;
  }
  for(const z of instances){
   assert.equal(z.overlap(0,1,1,-2147483648,1,1,2147483647,0,1,1),8);
   assert.equal(z.overlap(0,1,1,2147483647,1,1,-2147483648,0,1,1),11);
   assert.equal(z.overlap(0,1,1,2147483647,1,1,-2147483648,0,1,2),16);
  }
  console.log('final linear memory',instances.map(z=>z.memory.buffer.byteLength));
 }
 console.log(n,'matched independent geometry; fewer work units on',reduced,'cases;',saved,'total units saved; extreme and retry controls passed');
})().catch(e=>{console.error(e);process.exit(1)});
