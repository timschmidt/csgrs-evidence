import os,sys
from pathlib import Path
pid=os.fork()
if pid==0:os.execvp(sys.argv[2],sys.argv[2:])
_,status,resources=os.wait4(pid,0)
Path(sys.argv[1]).write_text(str(resources.ru_maxrss)+' KiB process high water\n')
sys.exit(os.waitstatus_to_exitcode(status))
