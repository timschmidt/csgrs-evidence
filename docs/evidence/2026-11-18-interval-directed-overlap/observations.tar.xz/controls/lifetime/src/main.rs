use hyperinterval::{DyadicBudget as B, DyadicInterval as D, IntervalError};
use overlap_observer::Input;
use std::{ffi::c_void, hint::black_box};
extern "C" { fn measure_stack(f: extern "C" fn(*mut c_void), p:*mut c_void, warm:i32, pattern:u8)->usize; }
struct Case { data:Input, expected:bool, retry:bool }
extern "C" fn run(raw:*mut c_void) {
    let c=unsafe {&*(raw as *const Case)};
    if c.retry {
        assert_eq!(black_box(&c.data).compare(&mut B::new(1,1)),Err(IntervalError::WorkExhausted));
    }
    let mut budget=B::new(4096,100000);
    assert_eq!(black_box(&c.data).compare(&mut budget),Ok(c.expected));
    black_box(budget.remaining_work());
}
fn main() {
    let one=D::point(1.into(),0).unwrap();
    let high=(one.lower().unwrap().0 << 2048_usize)+1_u8;
    let v=Input::Finite(D::new(high.clone(),&high+4_u8,5).unwrap(),D::new(&high+4_u8,&high+6_u8,5).unwrap());
    for (name,data,expected,retry) in [
        ("different",Input::make(0,1,3,0,2,3,1,0),false,false),
        ("touch",Input::make(0,1,3,1,6,7,0,0),true,false),
        ("extreme",Input::make(0,1,1,i32::MIN,1,1,i32::MAX,0),false,false),
        ("retry",Input::make(0,1,1,i32::MAX,1,1,i32::MIN,0),false,true),
        ("rays",Input::make(1,-2,-1,0,1,2,0,7),false,false),
        ("unions",Input::make(2,-2,-1,0,1,2,0,37),true,false),
        ("wide",v,true,false)] {
        let mut c=Case{data,expected,retry};
        for warm in [0,1] {for pattern in [0x5a,0xa5] {
            let height=unsafe{measure_stack(run,(&mut c as *mut Case).cast(),warm,pattern)};
            println!("{name} {warm} {pattern} {height}");
        }}
    }
}
