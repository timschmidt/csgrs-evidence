import sys,json
from pathlib import Path
from image_metrics import sizes
s=Path(__file__).parent;t=s/'builds'
def wasm(p):
 data=p.read_bytes();i=8
 def leb():
  nonlocal i
  n=shift=0
  while True:
   b=data[i];i+=1;n|=(b&127)<<shift
   if b<128:return n
   shift+=7
 while i<len(data):
  k=data[i];i+=1;l=leb()
  if k==10:return l
  i+=l
 raise ValueError
if __name__=='__main__':
 diff={}
 for p in t.glob(sys.argv[1]+'*'):
  v=sys.argv[1];suffix=p.name[len(v):];ref=t/('current'+suffix)
  if not ref.is_file():continue
  if suffix=='.wasm':a={'file':ref.stat().st_size,'code':wasm(ref)};b={'file':p.stat().st_size,'code':wasm(p)}
  else:a,b=sizes(ref),sizes(p)
  diff[suffix]={k:[x,b.get(k,0),b.get(k,0)-x] for k,x in a.items()}
  fails=[]
  for k,(x,y,d) in diff[suffix].items():
   abs_cap,pct_cap=((1024,5) if suffix=='.wasm' else (1024,.5) if k=='function_union' else (4096,1))
   if d>abs_cap or 100*d>x*pct_cap:fails.append((k,d))
  print(p.name,'file',b['file']-a['file'],'fail',fails)
 (s/'logs'/(sys.argv[1]+'-metrics.json')).write_text(json.dumps(diff,indent=2)+'\n')
