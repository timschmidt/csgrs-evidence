import sys,statistics,subprocess
from pathlib import Path
t=Path('/dev/shm/interval-overlap');s=Path(__file__).parent
v=sys.argv[1];ref=sys.argv[2] if len(sys.argv)>2 else 'current'
out=s/('timing-'+v);out.mkdir(exist_ok=True)
for cpu in (4,14,24):
 for i in range(10):
  for n in ([ref,v] if i%2==0 else [v,ref]):
   (out/f'{cpu}-{i}-{n}').write_bytes(subprocess.check_output(['taskset','-c',str(cpu),t/'builds'/(n+'-native')]))
 for case in ['different-grid','touch','extreme','rays','unions']:
  def med(n):
   return statistics.median(int(line.split()[-1]) for f in out.glob(f'{cpu}-*-{n}') for line in f.read_text().splitlines() if line.startswith('TIME '+case+' '))
  print(cpu,case,int(med(ref)),int(med(v)),round(med(v)/med(ref),3))
