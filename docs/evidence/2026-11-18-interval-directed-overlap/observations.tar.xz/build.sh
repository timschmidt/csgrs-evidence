set -eu
t=/dev/shm/interval-overlap
s=/dev/shm/interval-directed-overlap
cp crates/hyperinterval/src/{dyadic_order.rs,dyadic_overlap.rs} "$t/repo/crates/hyperinterval/src/"
git diff HEAD -- crates/hyperinterval/src > "$s/$1.patch"
bash "$t/probe-build.sh" "$1" --features direct > "$s/logs/$1-probe" 2>&1
bash "$t/build-only.sh" "$1"
python3 "$t/metrics.py" "$1" > "$s/logs/$1-size"
python3 "$s/bench.py" "$1" > "$s/logs/$1-timing"
node "$t/probe/check.cjs" "$t/builds/current.wasm" "$t/builds/$1.wasm" > "$s/logs/$1-wasm"
