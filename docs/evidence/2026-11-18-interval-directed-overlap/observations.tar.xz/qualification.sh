set -eu
t=/dev/shm/interval-overlap
s=/dev/shm/interval-directed-overlap
. /dev/shm/interval-bisection/env
measure(){
 label=$1;shift
 export CARGO_TARGET_DIR="$t/lifetime-target"
 (cd "$t/lifetime" && cargo +1.95.0 build --release --offline "$@") > "$s/logs/$label-life-build" 2>&1
 cp "$CARGO_TARGET_DIR/release/overlap-lifetime" "$t/builds/$label-life"
 for i in 1 2 3; do "$t/builds/$label-life"; done > "$s/logs/$label-stack" 2> "$s/logs/$label-headroom"
 export CARGO_TARGET_DIR="$t/probe-target"
 (cd "$t/probe" && cargo +1.95.0 run --release --offline --example wide "$@") > "$s/logs/$label-wide" 2>&1
}
measure directed-bounds --features direct
git -C "$t/repo" apply -R "$s/directed-bounds.patch"
measure directed-current
bash "$t/probe-build.sh" directed-current > "$s/logs/directed-current-probe" 2>&1
bash "$t/build-only.sh" directed-current
git -C "$t/repo" switch --detach c9f1f9ac5
measure directed-fixed
bash "$t/probe-build.sh" directed-fixed > "$s/logs/directed-fixed-probe" 2>&1
bash "$t/build-only.sh" directed-fixed
git -C "$t/repo" switch --detach aa92b60c0
git -C "$t/repo" apply "$s/directed-bounds.patch"
