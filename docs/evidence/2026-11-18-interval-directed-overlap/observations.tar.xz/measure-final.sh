set -eu
s=/dev/shm/interval-directed-overlap; t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
measure(){
 n=$1;shift
 for d in standalone locked; do
  export CARGO_TARGET_DIR="$s/$d-life-target"
  (cd "$s/$d-lifetime" && cargo +1.95.0 build --release --offline "$@") > "$s/logs/$d-$n-build" 2>&1
  for i in 1 2 3; do "$CARGO_TARGET_DIR/release/overlap-lifetime"; done > "$s/logs/$d-$n-lifetime" 2> "$s/logs/$d-$n-capacity"
 done
 export CARGO_TARGET_DIR="$t/lifetime-target"
 (cd "$t/lifetime" && cargo +1.95.0 build --locked --offline --release "$@") > "$s/logs/query-$n-build" 2>&1
 for i in 1 2 3; do "$CARGO_TARGET_DIR/release/overlap-lifetime"; done > "$s/logs/query-$n-stack" 2> "$s/logs/query-$n-headroom"
}
cd "$t/repo"
measure final --features direct
git apply -R "$s/normalized-pair.patch"
measure current
git switch --detach c9f1f9ac5
measure fixed
git switch --detach aa92b60c0
git apply "$s/normalized-pair.patch"
