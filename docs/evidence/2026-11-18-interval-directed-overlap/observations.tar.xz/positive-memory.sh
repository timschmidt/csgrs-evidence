set -eu
s=/dev/shm/interval-directed-overlap; t=/dev/shm/interval-overlap; dest="$s/positive-memory"
. /dev/shm/interval-bisection/env
measure() {
 n=$1;shift
 for d in standalone locked; do
  export CARGO_TARGET_DIR="$s/$d-life-target"
  (cd "$s/$d-lifetime" && cargo +1.95.0 build --locked --offline --release --bins --example heap --example division "$@") > "$dest/$d-$n-build" 2>&1
  for i in $(seq 1 12); do 
    python3 /dev/shm/interval-box-coverage/measure-rss.py "$dest/$d-$n-rss-$i" "$CARGO_TARGET_DIR/release/overlap-lifetime"
  done > "$dest/$d-$n-lifetime" 2> "$dest/$d-$n-capacity"
  for i in 1 2 3; do "$CARGO_TARGET_DIR/release/examples/heap"; done > "$dest/$d-$n-heap"
  for i in $(seq 1 12); do "$CARGO_TARGET_DIR/release/examples/division"; done > "$dest/division-$d-$n-results" 2> "$dest/division-$d-$n-headroom"
  if [ "$d" = locked ]; then q="$s/locked-query"; else q="$t/lifetime"; fi
  export CARGO_TARGET_DIR="$s/$d-query-target"
  (cd "$q" && cargo +1.95.0 build --locked --offline --release "$@") > "$dest/query-$d-$n-build" 2>&1
  for i in $(seq 1 12); do "$CARGO_TARGET_DIR/release/overlap-lifetime"; done > "$dest/query-$d-$n-stack" 2> "$dest/query-$d-$n-headroom"
 done
}
cd "$t/repo"
measure final --features direct
git apply -R "$s/known-positive.patch"
measure current
git switch --detach c9f1f9ac5
measure fixed
git switch --detach aa92b60c0
git apply "$s/known-positive.patch"
