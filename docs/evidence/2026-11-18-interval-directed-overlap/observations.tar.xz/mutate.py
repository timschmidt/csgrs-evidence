from pathlib import Path
import sys
p=Path('crates/hyperinterval/src/extended/dyadic_overlap.rs');s=p.read_text()
a,b={'contact':('?.is_lt()', '?.is_le()'),'direction':('(a, b, Relation::Before),','(a, b, Relation::After),'),'ray':('return Ok(Relation::Intersects);','return Ok(Relation::After);')}[sys.argv[1]]
assert s.count(a)==1;p.write_text(s.replace(a,b))
