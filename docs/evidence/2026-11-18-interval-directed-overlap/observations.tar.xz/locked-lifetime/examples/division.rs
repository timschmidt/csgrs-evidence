use hyperinterval::{DomainCoverage as Coverage,DyadicBudget as B,DyadicInterval as D,ExtendedInterval as E,IntervalSet2 as S};
use std::{hint::black_box,ffi::c_void};
#[path="../src/usable.rs"]
mod usable;
extern "C"{fn measure_stack(f:extern "C" fn(*mut c_void),p:*mut c_void,warm:i32,pattern:u8)->usize;}
struct Case{left:E<D>,right:E<D>,expected:S<D>,coverage:Coverage}
extern "C" fn run(ptr:*mut c_void){
 let c=unsafe{&*(ptr as *const Case)};
 let mut w=B::new(4096,1_000_000);
 let result=black_box(&c.left).div(black_box(&c.right),-16,&mut w).unwrap();
 assert_eq!(result.domain,c.coverage);assert_eq!(result.range,c.expected);
 black_box(w.remaining_work());
}
fn main(){
 let f=|a:i64,b:i64|E::from_finite(D::new(a.into(),b.into(),0).unwrap());
 let pt=|n:i64|D::point(n.into(),0).unwrap();
 let ray=|n:i64|E::above(pt(n)).unwrap();
 let one=S::from_interval;
 let split=S::new(E::below(pt(-1)).unwrap(),ray(1),&mut B::new(4096,1_000_000)).unwrap();
 for (name,left,right,expected,coverage) in [
  ("positive",f(1,2),f(1,2),one(E::from_finite(D::new(1.into(),4.into(),-1).unwrap())),Coverage::Complete),
  ("unbounded-denominator",f(1,2),ray(1),one(f(0,2)),Coverage::Complete),
  ("entire-numerator",E::entire(),f(1,2),one(E::entire()),Coverage::Complete),
  ("negative",f(2,2),f(-2,-1),one(f(-2,-1)),Coverage::Complete),
  ("touch-zero",f(1,2),f(0,1),one(ray(1)),Coverage::Partial),
  ("split",f(1,2),f(-1,1),split,Coverage::Partial),
 ]{
  let mut c=Case{left,right,expected,coverage};let ptr=(&mut c as *mut Case).cast();
  for warm in [0,1]{
   if warm==1{for _ in 0..8{run(ptr);}}
   let (_,v)=usable::observe(||run(ptr));println!("{}|{}|{:?}|{:?}",name,warm,v.values(),v.usable());assert_eq!(v.usable().2,0);
  }
  for warm in [0,1]{for pat in [0x5a,0xa5]{let h=unsafe{measure_stack(run,ptr,warm,pat)};println!("STACK {name} {warm} {pat} {h}");}}
 }
}
