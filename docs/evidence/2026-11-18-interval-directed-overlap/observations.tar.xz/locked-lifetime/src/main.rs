use hyperinterval::{DyadicBudget as B, DyadicInterval as D, ExtendedInterval as E, IntervalError, IntervalSet2 as S};
use std::{ffi::c_void,hint::black_box};
mod allocations;
extern "C" {fn measure_stack(f:extern "C" fn(*mut c_void),p:*mut c_void,warm:i32,pattern:u8)->usize;}
type Pair=(E<D>,E<D>);
struct Case {a:Pair,b:Pair,overlap:bool,retry:bool}
fn query(a:&S<D>,b:&S<D>,work:&mut B)->Result<bool,IntervalError> {
    #[cfg(feature="direct")]
    {a.overlaps(b,work)}
    #[cfg(not(feature="direct"))]
    {for x in a.components(){for y in b.components(){
        if !x.strictly_left_of(y,work)? && !y.strictly_left_of(x,work)? {return Ok(true)}
    }}Ok(false)}
}
fn finish(c:&Case, mut w:B)->Result<(bool,u64),IntervalError>{
    let a=S::new(c.a.0.clone(),c.a.1.clone(),&mut w)?;
    let b=S::new(c.b.0.clone(),c.b.1.clone(),&mut w)?;
    let hit=query(&a,&b,&mut w)?;
    Ok((hit,w.remaining_work()))
}
extern "C" fn run(raw:*mut c_void) {
    let c=unsafe{&*(raw as *const Case)};
    if c.retry {assert_eq!(finish(c,B::new(4096,0)),Err(IntervalError::WorkExhausted));}
    let (answer,remaining)=finish(black_box(c),B::new(4096,1000000)).unwrap();
    assert_eq!(answer,c.overlap);black_box(remaining);
}
fn main(){
    let point=|n:i32|D::point(n.into(),0).unwrap();
    let p=|n|E::from_finite(point(n));
    let wide=(point(1).lower().unwrap().0 << 2048_usize)+1_u8;
    let w=|i:u8|E::from_finite(D::point(&wide+i,1).unwrap());
    for (name,a,b,overlap,retry) in [
        ("empty",(E::empty(),E::empty()),(E::entire(),E::empty()),false,false),
        ("gap",(E::above(point(1)).unwrap(),E::below(point(-1)).unwrap()),(p(0),E::empty()),false,true),
        ("touch",(p(0),E::above(point(0)).unwrap()),(p(0),E::below(point(0)).unwrap()),true,true),
        ("interleaved",(p(3),p(-3)),(p(3),p(1)),true,true),
        ("separated",(p(-3),p(-5)),(p(1),p(3)),false,true),
        ("wide",(w(2),w(0)),(w(4),w(2)),true,true),
    ]{
        let mut case=Case{a,b,overlap,retry};let ptr=(&mut case as *mut Case).cast();
        for warm in [0,1]{for pat in [0x5a,0xa5]{let h=unsafe{measure_stack(run,ptr,warm,pat)};println!("STACK {name} {warm} {pat} {h}");}}
        let stats=allocations::measure(64,||run(ptr));
        println!("HEAP {name} {} {} {} {} {} {}",stats.allocations,stats.reallocations,stats.deallocations,stats.allocated_bytes,stats.peak_live_bytes,stats.live_bytes);
        assert_eq!(stats.live_bytes,0);
    }
}
