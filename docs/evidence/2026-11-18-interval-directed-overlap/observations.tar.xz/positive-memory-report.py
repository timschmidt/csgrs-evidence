from pathlib import Path
import ast,json
s=Path(__file__).parent;p=s/'positive-memory';states=['fixed','current','final'];obs={};rows=[];capacity={}
for lock in ['standalone','locked']:
 for mode in ['composition','query','division']:
  packed=[]
  for n in states:
   if mode=='composition':
    ls=(p/f'{lock}-{n}-lifetime').read_text().splitlines()
    heads=p/f'{lock}-{n}-capacity'
    usable=(p/f'{lock}-{n}-heap').read_text().splitlines()
   elif mode=='division':
    mix=(p/f'division-{lock}-{n}-results').read_text().splitlines()
    ls=[l for l in mix if l.startswith('STACK ')]
    usable=[l for l in mix if '|' in l]
    heads=p/f'division-{lock}-{n}-headroom'
   else:
    ls=['STACK '+l for l in (p/f'query-{lock}-{n}-stack').read_text().splitlines()]
    heads=p/f'query-{lock}-{n}-headroom'
    usable=[]
   m={}
   def record(k,val):m[k]=max(m.get(k,0),val)
   for l in ls:
    w=l.split()
    if w[0]=='STACK': record((w[1]+'-'+['cold','warm'][int(w[2])],'stack'),int(w[4]))
    else:
     for k,x in zip(['allocations','reallocations','deallocations','requested_traffic','requested_peak','requested_retained'],w[2:]):record((w[1]+'-64-calls',k),int(x))
   for l in usable:
    a,b,requested,actual=l.split('|')
    for k,x in zip(['allocations','deallocations','reallocations','requested_traffic','requested_peak','requested_retained'],ast.literal_eval(requested)):record((a+'-'+['cold','warm'][int(b)],k),x)
    for k,x in zip(['usable_traffic','usable_peak','usable_retained'],ast.literal_eval(actual)):record((a+'-'+['cold','warm'][int(b)],k),x)
   packed.append(m)
   cap=min(int(l.split()[-1]) for l in heads.read_text().splitlines());capacity[f'{lock}-{mode}-{n}']=cap;assert cap>=1536*1024
  for k in packed[0]:
   a,b,c=[m[k] for m in packed];inc=max(0,c-b);prior=max(0,b-a);total=prior+inc
   ip=1 if mode=='query' else 2;cp=2*ip
   limit_i=min(128,int(b*ip/100));limit_c=min(256,int(a*cp/100))
   if k[1]!='stack':limit_i=limit_c=0
   ok=inc<=limit_i and total<=limit_c
   if not ok:print('FAIL',lock,mode,k,a,b,c,inc,total)
   rows.append(dict(lock=lock,mode=mode,workload=k[0],metric=k[1],fixed=a,before=b,retained=c,prior_charge=prior,incremental_charge=inc,cumulative_charge=total,remaining_incremental=limit_i-inc,remaining_cumulative=limit_c-total,passes=ok))
(s/'positive-memory-confirmed.json').write_text(json.dumps({'headroom':capacity,'rows':rows},indent=2)+'\n')
print('charges',[(r['lock'],r['mode'],r['workload'],r['metric'],r['incremental_charge'],r['cumulative_charge']) for r in rows if r['cumulative_charge']]);print('minimum headroom',min(capacity.values()),len(rows),'rows')
