from pathlib import Path
import os,hashlib,json,subprocess,collections
from metrics import metrics
s=Path(os.environ['s'])
def read(f): return json.loads(f.read_text())
out={}
for phase in ('shared','remainder','allaffine','admitted','final'):
 current={}
 for f in sorted(s.glob(f'fit-{phase}-*.json')):
  target=f.stem.removeprefix('fit-'+phase+'-')
  b=read(s/('fit-baseline-'+target+'.json'));a=read(f)
  for name,new in a.items():
   old=b[name]
   v={n:new[n]-old[n] for n in ['file','code','functions']}
   v['equal_sha256']=new['sha256']==old['sha256']
   if 'sections' in new:v['allocated_section_deltas']={k:new['sections'].get(k,0)-old['sections'].get(k,0) for k in old['sections'].keys()|new['sections'].keys() if new['sections'].get(k,0)!=old['sections'].get(k,0)}
   current.setdefault(target,{})[name]=v
 out[phase]=current
(s/'delta.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
sizes={f.stem.removeprefix('final-'):read(f)['conic_box_certificates'] for f in s.glob('final-*.json') if f.stem.endswith(('-native','-wasi'))}
sizes['nightly-linux-asan']=metrics(s/'fuzz-build/x86_64-unknown-linux-gnu/release/conic_box_certificates')
for row in sizes.values():row['headroom_bytes']=64*1024**2-row['file'];assert row['headroom_bytes']>=16*1024**2
(s/'new-harness-sizes.json').write_text(json.dumps(sizes,indent=2)+'\n')
cut={}
for phase in ['baseline','affine']:
 rows=[l.split() for l in (s/f'logs/{phase}-axial').read_text().splitlines() if l.startswith('CASE ')]
 cut[phase]={'zero_target':dict(collections.Counter(l[-1] for l in rows if l[1]=='0')),'nonzero_target':dict(collections.Counter(l[-1] for l in rows if l[1]!='0'))}
(s/'axial-comparison.json').write_text(json.dumps(cut,indent=2)+'\n')
print({t:r['file'] for t,r in sizes.items()})
