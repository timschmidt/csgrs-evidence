from pathlib import Path
import json,os,sys,subprocess
from metrics import metrics
s=Path(os.environ['s']); phase,tc=sys.argv[1:]
targets={'trial':['quadratic_affine_box','interval_quadratic_extrema','smoke','interval_box_radius'],'admitted':['conic_box_certificates','interval_quadratic_extrema','interval_box_radius','smoke'],'mutation':['conic_box_certificates']}[phase]
td=s/('family-target' if tc=='stable' else 'family-bench-'+tc)
env=os.environ|{'CARGO_TARGET_DIR':str(td),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':f'--sysroot {s}/sysroot-{tc}'}
for arch in ('native','wasi'):
 stem=f'{phase}-{tc}-{arch}'
 cmd=['cargo','+'+tc,'build','--release','--locked','--all-features','-p','hypersolve','--message-format=json-render-diagnostics']
 for t in targets:cmd+=['--test',t]
 if arch=='wasi':cmd+=['--target','wasm32-wasip1']
 with (s/f'logs/{stem}.jsonl').open('w') as out,(s/f'logs/{stem}.build').open('w') as err:subprocess.run(cmd,env=env,cwd=s/'tree',stdout=out,stderr=err,check=True)
 bins={r['target']['name']:r['executable'] for l in (s/f'logs/{stem}.jsonl').read_text().splitlines() if (r:=json.loads(l)).get('executable')}
 assert set(bins)==set(targets)
 result={}
 for name,bin in bins.items():
  cmd=[bin] if arch=='native' else [s/'node/node','--no-warnings',s/'tree/crates/hyperlattice-interval/conformance/run-wasi-test.mjs',bin]
  # smoke includes subprocess replay through a dedicated runner; the focused
  # owner cases selected here only require the ordinary test runner on WASI.
  if arch=='wasi' and name=='smoke':cmd+=['interval_candidate']
  p=subprocess.run(cmd,cwd=s/'tree',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  (s/f'logs/{stem}-{name}.out').write_text(p.stdout)
  p.check_returncode()
  result[name]=metrics(Path(bin))
 (s/f'{stem}.json').write_text(json.dumps(result,indent=2)+'\n')
