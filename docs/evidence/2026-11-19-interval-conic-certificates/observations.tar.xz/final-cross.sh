set -eu
while ! test -s "$s/fit-final-stable-wasi.json" || ! test -s "$s/fit-final-1.95.0-wasi.json"; do
 if rg -q 'Traceback|error:' "$s/logs"/final-campaign-*; then exit 1; fi
 sleep 2
done
cd "$s/tree"
git apply "$s/cross-term.patch"
if cargo +1.95.0 test --locked --release --all-features -p hypersolve --test conic_box_certificates retained_fuzz_inputs_replay_under_both_policies >"$s/logs/final-cross-term" 2>&1; then exit 1; fi
rg -q 'invalid box sign' "$s/logs/final-cross-term"
git restore -- crates/hypersolve/src/interval.rs
