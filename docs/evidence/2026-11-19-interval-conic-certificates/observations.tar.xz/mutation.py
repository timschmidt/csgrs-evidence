from pathlib import Path
import os,subprocess,shutil
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs/crates/hypersolve/tests')
deps=s/'oracle/release/deps'
def lib(name):
 entries=list(deps.glob('lib'+name+'-*.rlib'));assert len(entries)==1,entries
 return str(entries[0])
for name,remove in [('no-interior','    visit(b * e - 2 * c * d, b * d - 2 * a * e, 4 * a * c - b * b);'),('no-edge','        visit(2 * c * x, -(b * x + e), 2 * c);')]:
 dest=s/'mutants'/name
 dest.mkdir(exist_ok=True)
 (dest/'support').mkdir(exist_ok=True)
 if not (dest/'fixtures').exists(): (dest/'fixtures').symlink_to(root/'fixtures')
 for f in ('conic_box_certificates.rs','support/conic_box.rs'):shutil.copy(root/f,dest/f)
 p=dest/'support/conic_box.rs';old=p.read_text();assert remove in old;p.write_text(old.replace(remove,''))
 cmd=['rustc','+1.95.0','--test','--edition','2024',str(dest/'conic_box_certificates.rs'),'-L','dependency='+str(deps),'-C','opt-level=3','-o',str(dest/'test')]
 for crate in ['hyperlimit','hyperreal','hypersolve']:cmd+=['--extern',crate+'='+lib(crate)]
 subprocess.run(cmd,check=True)
 result=subprocess.run([dest/'test','critical_points_include'],stdout=subprocess.PIPE,text=True)
 (s/f'logs/mutant-{name}').write_text(result.stdout)
 assert result.returncode==101 and 'left: (1, 1)' in result.stdout,result
