set -eu
while ! rg -q '^test result: FAILED' "$s/logs/omitted-cross-term" 2>/dev/null || ! git -C "$s/tree" diff --quiet -- crates/hypersolve/src/interval.rs; do
 if rg -q 'Traceback|error: test failed' "$s/logs/qualify-primary" "$s/logs/cross-mut-driver" 2>/dev/null; then exit 1; fi
 sleep 2
done
git -C "$s/tree" switch -q --detach 88f2e5d5b
for tc in 1.95.0 stable; do (
 python3 "$s/final-wave.py" final "$tc"
 python3 "$s/fit.py" "$tc" final
) >"$s/logs/final-campaign-$tc" 2>&1 & done
wait
for tc in 1.95.0 stable; do test -s "$s/fit-final-$tc-wasi.json"; done
