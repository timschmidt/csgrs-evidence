set -eu
while ! test -s "$s/affine-1.95.0-wasi.json" || ! rg -q '^test result: ok' "$s/logs/affine-axial"; do
 if rg -q 'Traceback|error: test failed|^error\[' "$s/logs/affine-wave-old" "$s/logs/affine-axial"; then exit 1; fi
 sleep 2
done
git -C "$s/tree" switch -q --detach 5c865512e
test "$(git -C "$s/tree" diff --name-only)" = ""
for tc in 1.95.0 stable; do (
 python3 "$s/wave.py" admitted "$tc"
 python3 "$s/fit.py" "$tc" admitted
) > "$s/logs/admitted-campaign-$tc" 2>&1 & done
wait
for tc in 1.95.0 stable; do test -s "$s/fit-admitted-$tc-wasi.json"; done
cd "$s/tree"
cargo +1.95.0 test --locked --release -p hyperpath --all-features --test temporary_axial -- --nocapture >"$s/logs/baseline-axial" 2>&1
