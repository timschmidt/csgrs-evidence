set -eu
while ! test -s "$s/wasip1-full/report.json"; do
 if rg -q 'Traceback|error:|Failed |failed WASI |Missing |unequal inventories' "$s/logs/final-wasi-solver"; then exit 1; fi
 sleep 3
done
cd /mnt/development/csgrs
export CARGO_TARGET_DIR="$s/oracle" HYPERSOLVE_SKIP_BENCHMARK_REPORTS=1
cargo +1.95.0 test --locked --release --all-features -p hypersolve --lib --tests -- --test-threads=1 > "$s/logs/final-native-solver" 2>&1
