from pathlib import Path
import subprocess,os,json
s=Path(os.environ['s']); repo=Path('/mnt/development/csgrs')
def read(f):return json.loads((s/f).read_text())
def rev(k):return subprocess.check_output(['git','-C',repo,'rev-parse',k],text=True).strip()
summary=read('delta.json')
assert all(len(summary[phase])==4 for phase in ['shared','remainder','allaffine','final'])
assert all(img['equal_sha256'] for tc in summary['final'].values() for img in tc.values()),summary['final']
sizes=read('new-harness-sizes.json');assert len(sizes)==5
acct={
 'source':rev('88f2e5d5b'),'previous':rev('dba6a5604'),
 'evidence':'docs/evidence/2026-11-19-interval-conic-certificates',
 'scope':'New Hypersolve conic oracle integration test and opt-in standalone ASan target. The existing extrema executable, smoke test, representation test and certification benchmark have identical SHA-256 hashes at each of the four compiler/target combinations.',
 'capacity_per_new_qualification_executable_bytes':67108864,'required_free_per_executable_bytes':16777216,
 'existing_executable_charge_bytes':0,'firmware':'Test-only native and hosted WASI targets. No firmware image links the harness.',
 'new_images':sizes,
 'review_trials': {
 k:{'source':rev(commit),'rust_1_95_owner_benchmark_file_code_function_deltas_bytes':{
 target:[summary[phase]['1.95.0-'+target]['certification'][v] for v in ('file','code','functions')] for target in ('native','wasi')},'production_charge_bytes':0}
 for k,phase,commit in [('shared_quadratic_rows','shared','f2eae56c3'),('shared_quadratic_remainder','remainder','8f5150b98'),('all_affine_system','allaffine','d28dbeaf5')]
 },
}
p=repo/'docs/research/interval-size-accounts.json'
old=p.read_text().rstrip()
key='conic_box_certificate_qualification'
assert key not in json.loads(old)
entry=json.dumps({key:acct},indent=2,ensure_ascii=False)
p.write_text(old[:-1].rstrip()+',\n'+entry.split('\n',1)[1]+'\n')
assert json.loads(p.read_text())[key]==acct
