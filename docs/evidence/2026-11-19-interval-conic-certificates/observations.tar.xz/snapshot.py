import os,subprocess,json,hashlib,tarfile,lzma,io
from pathlib import Path
s=Path(os.environ['s']);repo=Path('/mnt/development/csgrs')
record=repo.parent/'csgrs-evidence/docs/evidence/2026-11-19-interval-conic-certificates'
record.mkdir(exist_ok=True)
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
for label,rev in [('shared','f2eae56c3'),('remainder','8f5150b98'),('allaffine','d28dbeaf5'),('conic','88f2e5d5b')]:
 (s/f'{label}.patch').write_bytes(git('diff','--binary','dba6a5604',rev))
files=set()
def add(p):
 if p.is_file() and not p.is_symlink():files.add(p)
for pattern in ('*.py','*.sh','*.patch','*.rs','*.json','*.txt','*.md','logs/*','wasip1-full/*','final-corpus/*'):
 for f in s.glob(pattern):add(f)
for label in ['mutant-no-edge','mutant-no-interior']:assert (s/'logs'/label) in files
for name in ['g1_replay.rs','admission.txt','cross-term.patch','logs/zizmor','logs/final-native-solver','logs/final-asan','logs/final-cross-term','wasip1-full/report.json','new-harness-sizes.json','delta.json']:assert s/name in files,name
hashes={}
with tarfile.open(record/'observations.tar.xz','w:xz',preset=6) as archive:
 for f in sorted(files):
  name=f.relative_to(s).as_posix()
  data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));hashes[name]=hashlib.sha256(data).hexdigest()
(record/'members.sha256.json.xz').write_bytes(lzma.compress(json.dumps(hashes,indent=2,sort_keys=True).encode()+b'\n'))
print(len(hashes),sum(p.stat().st_size for p in record.iterdir()))
