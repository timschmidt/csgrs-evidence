use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::g1_join_problem;
use hypersolve::{IntervalBoxCertificationPackage as P, IntervalBoxCertificationStatus as S, VariableBall, certify_interval_box_candidate, context_from_problem};

#[test]
fn axial_reports() {
    let axial = |x: i32| Point2::new(x.into(), 0.into());
    for target in [-3,0,2] {
        let join = g1_join_problem(axial(0),axial(0),axial(0),axial(target));
        let analysis = join.problem.analyze();
        let mut ctx = context_from_problem(&join.problem);
        for center in [-3,-1,0,1,3] {
            ctx.bind(join.tangent_x_symbol,center.into());
            for radius in [0,2] {
                let ends = [target*(center-radius),target*(center+radius)];
                let expected = if *ends.iter().min().unwrap()>0 {S::Certified} else if *ends.iter().max().unwrap()<=0 {S::Violation} else {S::Unknown};
                let balls=[VariableBall{symbol:join.tangent_x_symbol, radius:radius.into()}];
                for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
                    for pkg in [P::Affine,P::UnivariateQuadratic,P::MultivariateQuadratic] {
                        let r=certify_interval_box_candidate(&analysis,&ctx,&balls,pkg,policy);
                        println!("CASE {target} {center} {radius} {pkg:?} {:?} {expected:?} {}",r.status,r.status==expected);
                        assert_eq!(r.package,pkg);
                        assert_eq!(r.variable_balls,balls);
                    }
                }
            }
        }
    }
}
