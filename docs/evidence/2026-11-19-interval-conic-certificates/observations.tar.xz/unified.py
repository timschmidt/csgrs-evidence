from pathlib import Path
base=Path(__file__).resolve().parent
where=base/"tree/crates/hypersolve/src"
src=(where/"interval.rs").read_text()
cer=(where/"certification.rs").read_text()
u=src.index('pub fn certify_quadratic_interval_candidate(')
m=src.index('pub fn certify_multivariate_quadratic_interval_candidate(')
end=src.index('fn validate_variable_balls(',m)
def body(start):
 return src.index('    let radius_by_symbol =',start)
udoc=src.index('/// Certify a candidate using multivariate quadratic interval enclosures.',u)
def call(uni):
 return '''    certify_quadratic_rows(analysis, context, variable_balls, policy, QuadraticRows::'''+uni+''')
}

'''
validate=src[body(m):src.index('    let mut residual_balls',body(m))]
uni=src[src.index('            let variable_radius',u):src.index('            residual_balls.push',u)]
multi=src[src.index('            let mut gradients',m):src.index('            residual_balls.push',m)]
import textwrap
def helper(name,ty,s):
 return f'''fn {name}(
    quadratic: &crate::{ty},
    context: &EvaluationContext,
    radius_by_symbol: &HashMap<SymbolId, Real>,
) -> Result<Real, QuadraticIntervalError> {{
'''+textwrap.indent(textwrap.dedent(s),'    ')+'''    Ok(radius)
}

'''
driver='''#[derive(Clone, Copy)]
enum QuadraticRows {
    Univariate,
    Multivariate,
}

fn certify_quadratic_rows(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    variable_balls: &[VariableBall],
    policy: PredicatePolicy,
    package: QuadraticRows,
) -> Result<crate::CandidateCertificationReport, QuadraticIntervalError> {
'''+validate+'''    let mut balls = Vec::new();
    for (active_row, (index, _)) in analysis.problem().constraints.iter().enumerate()
        .filter(|(_, constraint)| constraint.active).enumerate()
    {
        let radius = if let Some(affine) = &analysis.affine_residuals()[index] {
            if radius_by_symbol.is_empty() || affine.is_constant() {
                continue;
            }
            let radius = affine_box_radius(analysis, affine, &radius_by_symbol);
            if radius.definitely_zero() {
                continue;
            }
            radius
        } else {
            match package {
                QuadraticRows::Univariate => {
                    let Some(form) = &analysis.univariate_quadratic_residuals()[index] else { continue };
                    univariate_box_radius(form, context, &radius_by_symbol)?
                }
                QuadraticRows::Multivariate => {
                    let Some(form) = &analysis.quadratic_residuals()[index] else { continue };
                    multivariate_box_radius(form, context, &radius_by_symbol)?
                }
            }
        };
        balls.push(CandidateResidualBall { active_row, radius });
    }
    if balls.is_empty() {
        return Ok(certify_candidate(analysis, context));
    }
    Ok(crate::certification::certify_residual_balls(
        analysis, context, &balls, policy, true,
    ))
}

'''
src=src[:body(u)]+call('Univariate')+src[udoc:body(m)]+call('Multivariate')+driver+helper('univariate_box_radius','UnivariateQuadraticResidual',uni)+helper('multivariate_box_radius','QuadraticResidual',multi)+src[end:]
aff=src.index('            let mut radius = Real::zero();',src.index('pub fn certify_affine_interval_candidate'))
push=src.index('            residual_balls.push',aff)
loop=src[aff:push]
src=src[:aff]+'            let radius = affine_box_radius(analysis, affine, &radius_by_symbol);\n'+src[push:]
doc=src.index('/// Certify a candidate interval box and retain the proof payload.')
src=src[:doc]+'''fn affine_box_radius(
    analysis: &ProblemAnalysis<'_>,
    affine: &crate::AffineResidual,
    radius_by_symbol: &HashMap<SymbolId, Real>,
) -> Real {
'''+textwrap.indent(textwrap.dedent(loop),'    ')+'''    radius
}

'''+src[doc:]
src=src.replace("In particular, both quadratic packages\n/// currently do this for varying affine rows. When consuming a whole-box verdict,","For example, neither quadratic\n/// package encloses a cubic residual. When consuming a whole-box verdict,")
src=src.replace("/// ball-sign filter as affine interval replay. Missing variable radii are","/// ball-sign filter as affine interval replay. Varying affine rows use their\n/// exact projected radius and require certified whole-ball evidence. Missing variable radii are")
src=src.replace('/// This extends [`certify_quadratic_interval_candidate`] from single-symbol','/// Varying affine rows use the same linear enclosure as the univariate package.\n/// This extends [`certify_quadratic_interval_candidate`] from single-symbol')
idx=cer.index('    let mut report = certify_candidate(analysis, context);',cer.index('pub fn certify_candidate_with_residual_balls'))
cer=cer[:idx]+'''    certify_residual_balls(analysis, context, balls, policy, false)
}

pub(crate) fn certify_residual_balls(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    balls: &[CandidateResidualBall],
    policy: PredicatePolicy,
    certify_affine_rows: bool,
) -> CandidateCertificationReport {
'''+cer[idx:]
cer=cer.replace('        let status = match classify_ball_sign(center, &ball.radius, policy) {','''        let row_policy = if certify_affine_rows && analysis.affine_residuals()[row.constraint_index].is_some() {
            policy.certified_only()
        } else {
            policy
        };
        let status = match classify_ball_sign(center, &ball.radius, row_policy) {''')
(base/'interval.rs').write_text(src)
(base/'certification.rs').write_text(cer)
