from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import os,json,hashlib
root=Path(os.environ['s'])
def inspect(raw):
 signed=lambda a: int.from_bytes(bytes([a]),'little',signed=True)
 small=lambda v: (abs(v)%9)*(1 if v>=0 else -1)
 a,b,c,d,e,f,*rest=map(signed,raw);mode=raw[-1]
 if (mode>>2)&3 in (1,2): f=1048576*(1 if ((mode>>2)&3)==1 else -1)
 x0,x1=sorted(map(small,rest[0:2]));y0,y1=sorted(map(small,rest[2:4]))
 def q(x,y):return a*x*x+b*x*y+c*y*y+d*x+e*y+f
 vals=[q(x,y) for x in (x0,x1) for y in (y0,y1)];corners=(min(vals),max(vals))
 if c:
  for x in (x0,x1):
   y=F(-b*x-e,2*c)
   if y0<=y<=y1: vals.append(q(x,y))
 if a:
  for y in (y0,y1):
   x=F(-b*y-d,2*a)
   if x0<=x<=x1: vals.append(q(x,y))
 det=4*a*c-b*b
 if det:
  x=F(b*e-2*c*d,det);y=F(b*d-2*a*e,det)
  if x0<=x<=x1 and y0<=y<=y1:vals.append(q(x,y))
 xc,yc,rx,ry=[F(n,2) for n in (x0+x1,y0+y1,x1-x0,y1-y0)]
 radius=abs(2*a*xc+b*yc+d)*rx+abs(b*xc+2*c*yc+e)*ry+abs(a)*rx**2+abs(b)*rx*ry+abs(c)*ry**2
 center=q(xc,yc);lo,hi=min(vals),max(vals);sg=lambda x:(x>0)-(x<0)
 assert center-radius<=lo<=hi<=center+radius
 return dict(input=raw.hex(),extrema=[str(lo),str(hi)],corners=list(map(str,corners)),symmetric=list(map(str,(center-radius,center+radius))),required=bool(radius==0 or abs(center)>radius),nondyadic=any(F(v).denominator&(F(v).denominator-1) for v in (lo,hi)),corners_miss_sign=bool(tuple(map(sg,corners))!=tuple(map(sg,(lo,hi)))),corners_miss_value=bool(corners!=(lo,hi)))
seeds={p.read_bytes() for p in (root/'final-corpus').iterdir() if p.is_file() and p.stat().st_size==11}
grid={bytes(n%256 for n in [*abc,-3,5,-1,*rect,mode]) for abc in [(1,3,2),(2,4,2),(2,1,3),(0,3,0),(0,0,0),(-2,3,-3)] for rect in [(-2,3,-1,4),(1,1,2,2),(0,0,-3,4),(-2,2,1,1),(0,1,0,1)] for mode in range(12)}
out={}
for name,cases in [('final-corpus',seeds),('grid',grid)]:
 rows=[inspect(raw) for raw in sorted(cases)];out[name]=rows
 print(name,len(rows),{f:sum(r[f] for r in rows) for f in ('required','nondyadic','corners_miss_sign','corners_miss_value')})
(root/'final-corpus-report.json').write_text(json.dumps(out,indent=2)+'\n')
