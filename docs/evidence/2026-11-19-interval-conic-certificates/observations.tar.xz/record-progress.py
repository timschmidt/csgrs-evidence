from pathlib import Path
import os,re,json
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
w=json.loads((s/'wasip1-full/report.json').read_text())
full=(s/'logs/final-native-solver').read_text()
runs=re.split(r'^     Running ',full,flags=re.M)[1:]
assert len(runs)==73
count=sum(int(re.findall(r'^test result: ok\. (\d+) passed',r,re.M)[-1]) for r in runs)
guest=sum(map(len,w['guest'].values()));parents=sum(map(len,w['fresh_replays'].values()));host=sum(map(len,w['host_only'].values()));windows=sum(w['dispatch_windows'].values())
assert guest+parents+host+len(w["dispatch_windows"])==count and len(w['guest'])==len(runs)
assert all('0 failed' in r for r in runs)
p=root/'INTERVAL_REFACTOR_PROGRESS.md'
doc=p.read_text().replace("native and WASI inventories matched across all 72 current solver test executables, including nested coefficient scopes, produced denominator growth and 4,212 Horner dispatch windows", "native and WASI inventories matched across the 72 preceding solver test executables on both compilers and all 73 with the general conic oracle on Rust 1.95, including nested coefficient scopes, produced denominator growth and 4,212 Horner dispatch windows",1)
# Preserve the historical 72-suite comparison on both compilers and add the new dated evidence below.
text=f"""
## Phase 7, quadratic certificates over closed rectangles

At `88f2e5d5b`, the maintained conic oracle checks the original polynomial
at corners, on edges and at interior stationary points using exact integer
arithmetic on rational coordinates. It also requires a decision whenever the
documented Taylor ball has zero radius or excludes zero. On the 360-case
deterministic grid, 272 inputs required a decision and 28 had a sign range
that the corners alone missed. Additional fixtures reach an interior zero at
(1/6, 1/2), an edge minimum at (2, −3/5), a stationary line and a sign
change caused by the mixed term. Removing either stationary-point check
failed its analytic control. Omitting the mixed term from the solver's
remainder produced an incorrect sign and failed the retained regression.
[Solver tests](crates/hypersolve/tests/conic_box_certificates.rs) · [Fuzz target](crates/hypersolve/fuzz/README.md#quadratic-residuals-over-rectangles)

Both compilers passed all 764 deterministic report checks on Linux and WASI.
Rust 1.95 passed {count:,} native tests in {len(runs)} executables. The complete
WASI qualification executed {guest:,} direct tests, {parents} native parents with
fresh guest children, {host} host platform checks and {windows:,} matching dispatch
windows. Linux ASan completed 10,000 inputs from six checked-in seeds in 13
seconds. The four existing release controls matched their preceding SHA-256
digests in all sixteen comparisons. The five new qualification images fit the
existing 64 MiB capacity and 16 MiB free-space requirement. Clippy, workspace and standalone
formatting, the repository retention check and the pedantic workflow security
audit passed.
[Size accounts](docs/research/interval-size-accounts.json)

Three proposed repairs were measured at the same source and build paths.
The table shows final certification benchmark file changes in bytes against
`dba6a5604`. The corresponding native and WASI screens were 4,096 and
1,024 bytes.

| Trial | Rust 1.95 Linux | Rust 1.95 WASI | Rust 1.99 Linux | Rust 1.99 WASI |
| --- | ---: | ---: | ---: | ---: |
| Shared quadratic row traversal, `f2eae56c3` | +11,376 | −1,021 | −6,264 | −36 |
| Shared ordered quadratic remainder, `8f5150b98` | −1,832 | +6,682 | −8,688 | −511 |
| Fully affine system dispatch, `d28dbeaf5` | +6,112 | +15,488 | −5,696 | +4,629 |

Both mixed-degree implementations passed the two whole-box witnesses on all
four compiler/target combinations. The fully affine dispatch corrected 24 of
the 36 incorrect results across the 120 nonzero-target G1 checks. Its twelve
singleton orientation errors and the sixty checks with a zero target still
failed. Each trial exceeded an existing linked-image cap and remains on its
review branch. No production memory or size allowance was charged.
[Proof scope and zero-coefficient reproduction](docs/research/interval-box-proof-scope.md)

The inventory regenerated twice with 7,354 scan rows and 433 body reviews.
Raw per-image sections, case logs, seeds, mutations and build commands are
in the November 19 conic qualification record. [Evidence index](docs/evidence-archive.tsv)
"""
if '## Phase 7, quadratic certificates over closed rectangles' in doc:raise ValueError('duplicate')
p.write_text(doc.rstrip()+'\n'+text)
print(guest,parents,host,windows,count)
