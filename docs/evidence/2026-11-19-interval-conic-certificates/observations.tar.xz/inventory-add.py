from pathlib import Path
import csv
p=Path('interval-inventory.tsv')
with p.open() as f: fields=next(csv.reader(f,delimiter='\t'))
rows=[
('crates/hypersolve/tests/support/conic_box.rs','extrema_signs','integer numerators and a shared positive denominator for each rational critical point','signs of the true lower and upper extrema on a closed rectangle','fixed integer locals','retain independent extrema witness at the solver acceptance boundary'),
('crates/hypersolve/tests/support/conic_box.rs','check','six integer polynomial coefficients, ordered integer rectangle bounds, exact half-integer centers and radii','original residual, required Taylor-ball decisions and independent geometric sign evidence','bounded two-variable fixture; complete owned public report','retain generated qualification and its source-coordinate oracle'),
('crates/hypersolve/tests/support/box_receipt.rs','check_receipt','signed extrema or signs of extrema on the same positive scale','checks exact or filtered whole-box sign, row satisfaction, aggregate and mandatory completion','borrows no external state and consumes one owned report','share receipt assertions across univariate, bilinear and general conic tests')]
with p.open('a') as f:
 w=csv.DictWriter(f,delimiter='\t',fieldnames=fields,lineterminator='\n')
 for file,name,rep,sem,allocation,action in rows:
  line=next(i for i,l in enumerate(Path(file).read_text().splitlines(),1) if l.startswith('pub fn '+name+'('))
  values=['csgrs',file,line,name,'fn',rep,sem,allocation,'Linux and WASI Preview 1; conic fuzz target on Linux ASan','test support','none','Hypersolve interval acceptance tests and opt-in solver-certificates fuzz target','Hypersolve test oracle',action,'conic_box_certificates and interval_quadratic_extrema','qualification workload; no shipped runtime change','body and consumers reviewed at 5c865512e']
  assert len(values)==len(fields)
  w.writerow(dict(zip(fields,values)))
