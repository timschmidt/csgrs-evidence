use hyperlimit::PredicatePolicy;
use hypersolve::{Constraint, Expr, IntervalBoxCertificationPackage as P, Problem, SymbolId, VariableBall, certify_interval_box_candidate, context_from_problem};
use hyperreal::{Rational, Real};
#[test]
fn zero_quadratic_coefficients() {
    let mut problem=Problem::default();
    let half=|n|Real::from(Rational::fraction(n,2).unwrap());
    let x=Expr::anonymous_symbol(problem.add_variable("x",half(1)).into());
    let y=Expr::anonymous_symbol(problem.add_variable("y",half(3)).into());
    let f=Expr::int(0)*x.clone()*x.clone()+Expr::int(0)*x.clone()*y.clone()+Expr::int(0)*y.clone()*y.clone()-Expr::int(3)*x+Expr::int(5)*y-Expr::int(1);
    problem.add_constraint(Constraint::equality("f",f));
    let a=problem.analyze();
    let ctx=context_from_problem(&problem);
    let balls=[VariableBall{symbol:SymbolId(0),radius:half(5)},VariableBall{symbol:SymbolId(1),radius:half(5)}];
    println!("affine {} quadratic {}",a.affine_residuals()[0].is_some(),a.quadratic_residuals()[0].is_some());
    for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
        for pkg in [P::Affine,P::UnivariateQuadratic,P::MultivariateQuadratic] {
            let r=certify_interval_box_candidate(&a,&ctx,&balls,pkg,policy);
            println!("{pkg:?} on [-2,3] x [-1,4]: {:?} {:?}",r.status,r.certification.unwrap().rows[0].status);
        }
    }
}
