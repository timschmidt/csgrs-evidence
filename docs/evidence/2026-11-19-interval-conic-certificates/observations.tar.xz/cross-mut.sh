set -eu
while ! rg -q '^test result: ok' "$s/logs/baseline-axial" 2>/dev/null; do
 if rg -q 'Traceback|error: test failed|^error\[' "$s/logs"/admitted-campaign-* "$s/logs/qualify-primary" 2>/dev/null; then exit 1; fi
 sleep 2
done
cd "$s/tree"
test "$(git rev-parse --short HEAD)" = "5c865512e"
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
i=s.index('            for term in quadratic.quadratic_terms() {',s.index('            for (symbol, gradient) in gradients'))
i=s.index('\n',i)
p.write_text(s[:i]+'\n                if term.first != term.second { continue; }'+s[i:])
PY
git diff -- crates/hypersolve/src/interval.rs >"$s/cross-term.patch"
if cargo +1.95.0 test --locked --release -p hypersolve --all-features --test conic_box_certificates retained_fuzz_inputs_replay_under_both_policies > "$s/logs/omitted-cross-term" 2>&1; then exit 1; fi
rg -q '^test result: FAILED' "$s/logs/omitted-cross-term"
git restore crates/hypersolve/src/interval.rs
