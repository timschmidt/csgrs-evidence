# Fresh Cargo qualification of the deferred support index

Owner: Hypercurve operation-local circular-support relation cache, P4/P10/P19/
P20/P36. Preserve the E46 ordered-pair domain, exact witnesses, policy lifetime,
all nine semantic tests, all fixtures, and unchanged original native/report
acceptance gates. The E46 retained experiment and E51 library qualification
remain historical evidence with their recorded source, tools, limits and scope.

The current production revision has no index. Prepare a separate candidate
worktree from the committed manuscript (whose Rust sources match 7ed4350),
copy the two preserved proposal Rust files exactly, and incorporate only the
README cache paragraph. Preserve the subsequently repaired Apache license link.
This is candidate preparation, not production admission. No existing result or
closed source/build root is modified. The original checkout remains read-only.

Verify source membership and bytes against the fresh baseline inventory before
applying the candidate, including expanded LFS content. Exclude only root
historical evidence from the source checkout; preserve all other tracked
fixtures. Check command-specific external/history dependencies before crediting
any command. Capture the exact diff and candidate source hashes. Record new
Cargo tests, all-target Clippy, documentation, examples/benches and downstream
checks separately from historical direct-rustc observations. Do not treat a
workspace build as the external user-path or real-binding acceptance boundary.

Use the existing fresh Disk B volume, fresh candidate target, and verified fresh
Cargo cache. Commands are sequential, with two build jobs and two test workers
where specified by the workflow. Keep 1,800 seconds per command, 8 GiB child
address space, 2 GiB host memory, 512 MiB volume reserve, 64 GiB cumulative fresh
volume consumption and 64 MiB command logs. These are external containment,
not library work/heap/cancellation bounds. Longer downstream CI jobs require a
separately declared protocol before launch. No runtime comparisons are made
while unrelated task work overlaps. Candidate acceptance requires completed
checks; faster failures, partial suites and document updates do not qualify it.
