"""Qualify the preserved candidate with fresh Cargo commands and unchanged tests."""
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import GIT, dump, reasons, resources, run, sha

C = V / 'checkout-candidate-v1'
TARGET = V / 'target-candidate-v1'
preparation = json.loads((V / 'candidate-preparation-v1.json').read_text())
baseline = json.loads((V / 'baseline-curve-result-v1.json').read_text())
assert preparation['complete'] and baseline['complete']
assert not (V / 'candidate-curve-protocol-v1.json').exists()
assert not TARGET.exists()
tools = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p) == h for p, h in tools['tool_sha256'].items())
os.environ.update(tools['additional_environment'])
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.environ['CARGO_NET_OFFLINE'] = 'true'
inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
prefixes = ('crates/hypercurve/', 'crates/hypersolve/', 'crates/hypertri/',
            'crates/hyperlattice/', 'crates/hyperlimit/', 'crates/hyperreal/')
pins = {p:h for p,h in inventory.items() if p.startswith(prefixes) or p in
        ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml', '.github/workflows/hypercurve.yml']}
assert all(sha(C / p) == h for p,h in pins.items())
assert not reasons(resources())
cargo = str(Path(tools['additional_environment']['RUSTC']).with_name('cargo'))
cwd = C / 'crates/hypercurve'
commands = [
    ('candidate-fmt-v1', [cargo, 'fmt', '--all', '--', '--check'], C, {}),
    ('candidate-curve-clippy-all-v1', [cargo, 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings'], cwd, {}),
    ('candidate-curve-compile-all-v1', [cargo, 'test', '--release', '--locked', '--all-features', '--no-run'], cwd, {}),
    ('candidate-curve-tests-all-v1', [cargo, 'test', '--release', '--locked', '--all-features', '--no-fail-fast', '--', '--test-threads=2'], cwd, {}),
    ('candidate-curve-clippy-minimal-v1', [cargo, 'clippy', '--locked', '--all-targets', '--no-default-features', '--', '-D', 'warnings'], cwd, {}),
    ('candidate-curve-tests-minimal-v1', [cargo, 'test', '--release', '--locked', '--no-default-features', '--no-fail-fast', '--', '--test-threads=2'], cwd, {}),
    ('candidate-curve-docs-v1', [cargo, 'doc', '--locked', '--no-deps', '--all-features'], cwd, {'RUSTDOCFLAGS': '-D warnings'}),
]
protocol = {
    'base_revision': preparation['base_revision'], 'rust_baseline_revision': preparation['rust_baseline_revision'],
    'candidate_source_sha256': preparation['candidate_sha256'], 'source_inventory_sha256': sha(V / 'candidate-source-inventory-v1.json.gz'),
    'verified_affected_source_paths': len(pins), 'compiler_protocol_sha256': sha(V / 'cargo-preparation-protocol-v1.json'),
    'candidate_contract_sha256': preparation['contract_sha256'], 'target': str(TARGET), 'source': str(C),
    'commands': [{'name': n, 'argv': a, 'cwd': str(c), 'additional_environment': e} for n,a,c,e in commands],
    'time_limit_seconds_per_command': 1800, 'test_threads': 2, 'performance_comparison': False,
    'full_fixtures_unchanged': True, 'policy_unchanged': True, 'candidate_admitted': False,
    'baseline_tests_qualified_first': True, 'runner_sha256': sha(V / 'control/validation_runner_v2.py')}
dump(V / 'candidate-curve-protocol-v1.json', protocol)
results = {}
for name, argv, folder, env in commands:
    assert all(sha(C / p) == h for p,h in pins.items())
    old = {k:os.environ.get(k) for k in env}
    os.environ.update(env)
    try:
        results[name] = run(name, argv, folder, target=TARGET)
    finally:
        for key,value in old.items():
            if value is None:
                os.environ.pop(key,None)
            else:
                os.environ[key] = value
    dump(V / 'candidate-curve-progress-v1.json', results)
assert all(sha(C / p) == h for p,h in pins.items())
subprocess.run(GIT + ['diff', '--check'], cwd=C, check=True)
subprocess.run(GIT + ['diff', '--cached', '--quiet'], cwd=C, check=True)
summaries = {}
for name in ['candidate-curve-tests-all-v1', 'candidate-curve-tests-minimal-v1']:
    stdout = (V / 'logs' / name / 'stdout').read_text()
    rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout, re.M)
    assert rows and all(row[0] == 'ok' and row[2] == '0' for row in rows)
    summaries[name] = {'terminal_summaries': rows, 'passed': sum(int(row[1]) for row in rows),
                       'failed': 0, 'ignored': sum(int(row[3]) for row in rows)}
baseline_stdout = (V / 'logs/baseline-curve-tests-v1/stdout').read_text()
baseline_rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', baseline_stdout, re.M)
assert baseline_rows and all(row[0] == 'ok' and row[2] == '0' for row in baseline_rows)
all_rows = summaries['candidate-curve-tests-all-v1']['terminal_summaries']
assert len(all_rows) == len(baseline_rows)
assert int(all_rows[0][1]) == int(baseline_rows[0][1]) + 9
assert all_rows[0][2:] == baseline_rows[0][2:]
assert all_rows[1:] == baseline_rows[1:]
dump(V / 'candidate-curve-result-v1.json', {
    'complete': True, 'commands': results, 'summaries': summaries,
    'source_unchanged': True, 'cargo_curve_matrix_complete': True,
    'all_feature_summary_delta': 'exactly nine new unit-test passes; all other group counts unchanged',
    'downstream_complete': False, 'native_report_gates_complete': False,
    'real_bindings_complete': False, 'external_consumer_qualification_complete': False,
    'candidate_admitted': False, 'full_plan_complete': False})
print(json.dumps({'candidate_curve_matrix_passed': True, 'summaries': summaries, 'candidate_admitted': False}), flush=True)
