"""Prepare a current-source candidate without admitting or modifying production."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import GIT, ORIGIN, REPO, dump, reasons, resources, run, sha

W = Path(__file__).resolve().parent
C = V / 'checkout-candidate-v1'
BASE = 'fc23195a16f45fb396a5dd731feb6c7310d8ce7c'
PROPOSAL = ORIGIN / 'target/properties/circle-support-reuse-index/proposal-source'
BRANCH = 'codex/properties-candidate-20261017'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
assert not C.exists()
assert not reasons(resources())
assert json.loads((V / 'paper-commit-verification-v1.json').read_text())['commit'] == BASE
proposal_record = json.loads((ORIGIN / 'docs/evidence/2026-10-17-circle-support-reuse-index/decision-v1.json').read_text())
pins = proposal_record['proposal_sha256']
assert len(pins) == 3 and all(sha(PROPOSAL / p) == h for p, h in pins.items())
commands = [run('candidate-worktree-v1', GIT + ['worktree', 'add', '--no-checkout', '-b', BRANCH, str(C), BASE], REPO)]
commands.append(run('candidate-sparse-v1', GIT + ['sparse-checkout', 'set', '--no-cone', '--stdin'], C, b'/*\n!/docs/evidence/\n'))
commands.append(run('candidate-checkout-v1', GIT + ['checkout', '--quiet', BRANCH], C))
assert subprocess.check_output(GIT + ['rev-parse', 'HEAD'], cwd=C, text=True).strip() == BASE
subprocess.run(GIT + ['diff', '--quiet'], cwd=C, check=True)
subprocess.run(GIT + ['diff', '--cached', '--quiet'], cwd=C, check=True)
inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
changed = subprocess.check_output(GIT + ['diff', '--name-only', '7ed43501755fd64a01f54c3078d12229cbc0129d', BASE], cwd=C, text=True).splitlines()
assert len(changed) == 20 and all(p.startswith('docs/') for p in changed)
physical = {}
for name, row in inventory.items():
    path = C / name
    if name in changed:
        content = subprocess.check_output(GIT + ['show', BASE + ':' + name], cwd=C)
        assert path.read_bytes() == content
        digest = hashlib.sha256(content).hexdigest()
    elif row['mode'] == '120000':
        assert path.is_symlink()
        digest = hashlib.sha256(os.fsencode(os.readlink(path))).hexdigest()
        assert digest == row['sha256'], name
    else:
        assert path.is_file() and not path.is_symlink()
        digest = sha(path)
        assert digest == row['sha256'], name
    physical[name] = digest
for name in changed:
    if name.startswith('docs/evidence/') or name in physical:
        continue
    path = C / name
    content = subprocess.check_output(GIT + ['show', BASE + ':' + name], cwd=C)
    assert path.read_bytes() == content
    physical[name] = hashlib.sha256(content).hexdigest()
assert not (C / 'docs/evidence').exists()
for name, digest in pins.items():
    if name.endswith('.rs'):
        shutil.copy2(PROPOSAL / name, C / name)
        assert sha(C / name) == digest
readme_name = 'crates/hypercurve/README.md'
old = (C / readme_name).read_text()
proposed = (PROPOSAL / readme_name).read_text()
anchor = '- `CurvePreviewOptions` owns finite display tolerances separately.'
start = proposed.index('- Native intersection batches retain owned circle-support relations')
end = proposed.index(anchor, start)
assert old.count(anchor) == 1
new = old.replace(anchor, proposed[start:end] + anchor)
assert new == proposed.replace('Licensed under the [Apache License 2.0](LICENSE).', 'Licensed under the [Apache License 2.0](LICENSE-APACHE).')
(C / readme_name).write_text(new)
new_pins = {name: sha(C / name) for name in pins}
for name in list(physical):
    if name not in new_pins:
        path = C / name
        digest = hashlib.sha256(os.fsencode(os.readlink(path))).hexdigest() if path.is_symlink() else sha(path)
        assert digest == physical[name], name
physical.update(new_pins)
with gzip.open(V / 'candidate-source-inventory-v1.json.gz', 'wt') as stream:
    json.dump(physical, stream, sort_keys=True)
patch = subprocess.check_output(GIT + ['diff', '--binary', '--', *sorted(pins)], cwd=C)
(V / 'candidate-tracked-v1.patch').write_bytes(patch)
new_test = 'crates/hypercurve/src/circle_support_cache_tests.rs'
assert not subprocess.check_output(GIT + ['ls-files', '--', new_test], cwd=C)
(V / 'candidate-new-tests-v1.rs').write_bytes((C / new_test).read_bytes())
subprocess.run(GIT + ['diff', '--check'], cwd=C, check=True)
subprocess.run(GIT + ['diff', '--quiet'], cwd=REPO, check=True)
result = {'complete': True, 'base_revision': BASE, 'rust_baseline_revision': '7ed43501755fd64a01f54c3078d12229cbc0129d',
    'worktree': str(C), 'branch': BRANCH, 'materialized_paths_verified': len(physical),
    'source_inventory_sha256': sha(V / 'candidate-source-inventory-v1.json.gz'),
    'original_proposal_sha256': pins, 'candidate_sha256': new_pins,
    'readme_license_repair_preserved': True, 'full_fixtures_preserved': True,
    'commands': commands, 'original_repository_updated': False,
    'candidate_changes_uncommitted': True, 'candidate_admitted': False,
    'contract_sha256': sha(W / 'contract-v1.md'), 'prepare_sha256': sha(Path(__file__)),
    'runner_sha256': sha(V / 'control/validation_runner_v2.py')}
dump(V / 'candidate-preparation-v1.json', result)
print(json.dumps({k:result[k] for k in ['complete','materialized_paths_verified','readme_license_repair_preserved','candidate_admitted']}), flush=True)
