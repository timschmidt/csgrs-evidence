# Native scalar test build path

The locked gmp-mpfr-sys 1.7.1 README explicitly excludes build paths containing
spaces. The fresh volume's host path contains one. A successful private mount
probe established a whitespace-free canonical working directory and confirmed
that writes arrive on Disk B while the host mount table remains unchanged.

Run the two existing scalar tests in that private namespace with the original
filesystem read-only, a minimal private /dev, read-only /proc, and the validation
volume writable at /dev/shm/csgrs-validation-disk-b-20261017-v1. The host path at
that name is an empty placeholder, not a RAM-backed build output directory.
Only its private mount redirects to Disk B. Use a separate fresh scalar target
and map Cargo, GMP, XDG and temporary caches to the same volume through that
alias. Preserve source, lockfiles, compiler, test bodies, features and assertions.

The existing host-side supervisor retains its 1,800-second per-command limit,
8 GiB child address-space bound, 2 GiB host-memory reserve, 512 MiB volume
reserve, 64 GiB cumulative volume allowance and 64 MiB log limit. This storage
mapping does not weaken a test or create an internal resource guarantee.
