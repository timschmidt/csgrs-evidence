"""Run existing scalar-owned equality/hash regressions after curve qualification."""
import gzip
import json
import os
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, run, sha

C = V / 'checkout-candidate-v1'
MOUNT = Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
TARGET = V / 'target-scalar-v1'
assert not TARGET.exists()
assert MOUNT.is_dir() and not list(MOUNT.iterdir())
assert json.loads((V / 'control/spaceless-mount-v1/result.json').read_text())['complete']
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert not (V / 'candidate-scalar-hash-protocol-v1.json').exists()
toolchain = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p) == h for p,h in toolchain['tool_sha256'].items())
os.environ.update(toolchain['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GMP_MPFR_SYS_CACHE'] = str(V / 'gmp-cache-v1')
inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
pins = {p:h for p,h in inventory.items() if p.startswith('crates/hyperreal/') or
        p in ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml']}
assert all(sha(C / p) == h for p,h in pins.items())
cargo = str(Path(toolchain['additional_environment']['RUSTC']).with_name('cargo'))
cases = [
    ('unreduced', 'rational::arithmetic::tests::unreduced_arithmetic_preserves_canonical_queries_and_hashes'),
    ('lazy', 'rational::arithmetic::tests::lazy_internal_fraction_is_canonical_at_observable_boundaries')]
commands = {label: [cargo, 'test', '--release', '--locked', '-p', 'hyperreal', '--all-features', '--lib', name,
                    '--', '--exact', '--test-threads=2'] for label,name in cases}
dump(V / 'candidate-scalar-hash-protocol-v1.json', {
    'owning_layer': 'Hyperreal Rational equality and canonical hashing',
    'source_review_sha256': sha(V / 'control/candidate-curve-v1/source-review-v2.json'),
    'source_pins_sha256': pins, 'commands': commands, 'test_sources_unchanged': True,
    'time_limit_seconds_per_command': 1800, 'GMP_MPFR_SYS_CACHE': os.environ['GMP_MPFR_SYS_CACHE'],
    'runtime_cache_candidate_admitted': False,
    'physical_target': str(TARGET), 'namespace_volume': str(MOUNT),
    'mount_contract_sha256': sha(V / 'control/candidate-curve-v1/scalar-mount-contract-v1.md'),
    'mount_probe_sha256': sha(V / 'control/spaceless-mount-v1/result.json')})
results = {}
for label, _ in cases:
    name = 'candidate-scalar-hash-' + label + '-v1'
    mapped = {
        'CARGO_HOME': str(MOUNT / 'cargo-home-v1'),
        'CARGO_TARGET_DIR': str(MOUNT / 'target-scalar-v1'),
        'TMPDIR': str(MOUNT / 'scratch' / name),
        'XDG_CACHE_HOME': str(MOUNT / 'xdg-cache-v1'),
        'GMP_MPFR_SYS_CACHE': str(MOUNT / 'gmp-cache-v1')}
    argv = ['/usr/bin/bwrap', '--die-with-parent', '--ro-bind', '/', '/',
            '--dev', '/dev', '--ro-bind', '/proc', '/proc', '--bind', str(V), str(MOUNT),
            '--chdir', str(MOUNT / 'checkout-candidate-v1')]
    for key, value in mapped.items():
        argv.extend(['--setenv', key, value])
    argv.extend(commands[label])
    results[label] = run(name, argv, C, target=TARGET)
    stdout = (V / 'logs' / name / 'stdout').read_text()
    rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout, re.M)
    assert rows == [('ok', '1', '0', '0')], rows
    assert all(sha(C / p) == h for p,h in pins.items())
dump(V / 'candidate-scalar-hash-result-v1.json', {
    'complete': True, 'commands': results, 'existing_scalar_tests_passed': 2,
    'source_unchanged': True, 'full_scalar_suite_passed': False,
    'candidate_admitted': False, 'full_plan_complete': False})
print(json.dumps({'existing_scalar_tests_passed': 2, 'candidate_admitted': False}), flush=True)
