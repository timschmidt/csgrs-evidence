"""Probe only Node's initial WASM allocation under the unchanged address cap."""
import json
import os
from pathlib import Path
import sys
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, run, sha
O = V / 'node-wasm-memory-probe-v1'
assert not O.exists()
O.mkdir()
node = '/usr/bin/node'
program = 'const m = new WebAssembly.Memory({initial: 1}); console.log(m.buffer.byteLength);'
assert 'NODE_OPTIONS' not in os.environ
protocol = {'node':node, 'node_sha256':sha(node), 'program':program,
    'helper_sha256':sha(Path(__file__)), 'address_space_limit_bytes':8 * 1024**3,
    'alternate_runtime_option':'--disable-wasm-trap-handler',
    'geometry_code_or_tests_executed':False, 'all_resource_limits_unchanged':True}
dump(O / 'protocol.json', protocol)
results = {}
for label, flags in [('default', []), ('explicit-bounds', ['--disable-wasm-trap-handler']), ('node-options', [])]:
    if label == 'node-options':
        os.environ['NODE_OPTIONS'] = '--disable-wasm-trap-handler'
    name = 'node-wasm-memory-' + label + '-v1'
    try:
        result = run(name, [node, *flags, '-e', program], V, wall_seconds=60)
    except RuntimeError as error:
        result = error.args[0]
        assert isinstance(result, dict)
    results[label] = result
    output = (V / 'logs' / name / 'stdout').read_text()
    stderr = (V / 'logs' / name / 'stderr').read_text()
    assert not result['stops']
    if label == 'default':
        assert result['exit_code'] != 0 and 'Out of memory' in stderr and not output
    else:
        assert result['exit_code'] == 0 and output == '65536\n'
os.environ.pop('NODE_OPTIONS', None)
dump(O / 'result.json', {'complete':True, 'commands':results,
    'default_initial_memory_allocation_failed':True,
    'explicit_bounds_runtime_initial_allocation_succeeded':True,
    'node_options_transport_verified':True, 'geometry_claim':False,
    'unchanged_address_space_limit_bytes':8 * 1024**3})
print(json.dumps({'probe_complete':True, 'default_failed':True, 'explicit_bounds_passed':True,
                  'node_options_passed':True, 'resource_limits_unchanged':True}), flush=True)
