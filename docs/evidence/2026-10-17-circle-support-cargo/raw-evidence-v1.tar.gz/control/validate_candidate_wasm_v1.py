"""Run the unchanged real JavaScript/TypeScript consumers with pinned tools."""
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, run, sha

C = V / 'checkout-candidate-v1'
TARGET = V / 'target-candidate-wasm-v1'
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert not TARGET.exists()
assert not (V / 'candidate-wasm-protocol-v1.json').exists()
compiler = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
tools = json.loads((V / 'control/binding-tools-preflight-v1.json').read_text())
assert all(sha(p) == h for p,h in compiler['tool_sha256'].items())
assert all(sha(p) == h for p,h in tools['tools_read_only_sha256'].items())
for row in tools['versions'].values():
    assert sha(row['argv'][0]) == row['sha256']
    assert subprocess.check_output(row['argv'], text=True).strip() == row['stdout']
os.environ.update(compiler['additional_environment'])
os.environ.update(tools['environment_for_future_consumer'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
pins = {p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
assert all(sha(C / p) == h for p,h in pins.items())
cargo = str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
commands = [
    ('candidate-wasm-shell-v1', ['bash', '-n', 'scripts/test-wasm-bindings.sh']),
    ('candidate-wasm-real-consumers-v1', ['bash', 'scripts/test-wasm-bindings.sh']),
    ('candidate-wasm-clippy-v1', [cargo, 'clippy', '--locked', '--profile', 'wasm', '--target',
        'wasm32-unknown-unknown', '--no-default-features', '--features', 'wasm', '--lib', '--', '-D', 'warnings'])]
dump(V / 'candidate-wasm-protocol-v1.json', {
    'commands': commands, 'source': str(C), 'target': str(TARGET),
    'source_pin_count': len(pins), 'source_inventory_sha256': sha(V / 'candidate-source-inventory-v1.json.gz'),
    'tool_preflight_sha256': sha(V / 'control/binding-tools-preflight-v1.json'),
    'script_sha256': sha(C / 'scripts/test-wasm-bindings.sh'),
    'environment_for_binding_tools': tools['environment_for_future_consumer'],
    'helper_sha256': sha(Path(__file__)), 'time_limit_seconds_per_command': 1800,
    'source_or_test_changes': False, 'preserved_tool_files_read_only': True,
    'fresh_binding_outputs': True, 'performance_comparison': False,
    'global_tool_installation_modified': False, 'external_distribution_qualification': False})
results = {}
for name, argv in commands:
    results[name] = run(name, argv, C, target=TARGET)
    assert all(sha(C / p) == h for p,h in pins.items())
    assert all(sha(p) == h for p,h in tools['tools_read_only_sha256'].items())
    dump(V / 'candidate-wasm-progress-v1.json', results)
dump(V / 'candidate-wasm-result-v1.json', {
    'complete': True, 'commands': results, 'real_consumers_passed': True,
    'source_unchanged': True, 'wasm_clippy_passed': True,
    'external_distribution_complete': False, 'all_bindings_complete': False,
    'cache_candidate_admitted': False, 'full_plan_complete': False})
print(json.dumps({'real_wasm_consumers_passed': True, 'wasm_clippy_passed': True,
                  'cache_candidate_admitted': False}), flush=True)
