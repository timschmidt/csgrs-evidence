"""Create an isolated exact-revision checkout without writing to the source repository."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import shutil
import signal
import stat
import subprocess
import time

V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
ORIGIN = Path('/home/tim/Documents/GitHub/workspace/csgrs')
REPO = V / 'checkout-baseline-v1'
BASE = '7ed43501755fd64a01f54c3078d12229cbc0129d'
INITIAL = json.loads((V / 'control/initial-state.json').read_text())
GIT = ['git', '-c', 'core.splitIndex=true', '-c', 'index.version=4',
       '-c', 'maintenance.auto=false', '-c', 'gc.auto=0']


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def resources():
    mem = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    return {'free_bytes': shutil.disk_usage(V).free,
            'host_available_bytes': int(mem['MemAvailable'].split()[0]) * 1024,
            'log_bytes': sum(p.stat().st_size for p in (V / 'logs').rglob('*') if p.is_file())}


def reasons(sample):
    result = []
    if sample['free_bytes'] < 512 * 1024**2:
        result.append('active_volume_free_bytes')
    if INITIAL['new_free_bytes'] - sample['free_bytes'] > 64 * 1024**3:
        result.append('fresh_volume_consumption_64_gib')
    if sample['host_available_bytes'] < 2 * 1024**3:
        result.append('host_available_memory')
    if sample['log_bytes'] > 64 * 1024**2:
        result.append('command_log_bytes')
    return result


def limit_child():
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))


def run(name, argv, cwd, stdin=None):
    folder = V / 'logs' / name
    folder.mkdir()
    scratch = V / 'scratch' / name
    scratch.mkdir()
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0',
               TMPDIR=str(scratch), CARGO_HOME=str(V / 'cargo-home-v1'),
               CARGO_TARGET_DIR=str(V / 'target-baseline-v1'),
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0')
    selected_env = {key: env[key] for key in [
        'GIT_OPTIONAL_LOCKS', 'TMPDIR', 'CARGO_HOME', 'CARGO_TARGET_DIR',
        'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL']}
    before = resources()
    record = {'argv': argv, 'cwd': str(cwd), 'environment_overrides': selected_env,
              'stdin': stdin.decode() if stdin else None, 'start_unix': time.time(),
              'resources_before': before, 'stops': reasons(before), 'launched': False}
    if record['stops']:
        record.update(exit_code=None, output_closed=True)
        dump(folder / 'result.json', record)
        raise RuntimeError(record['stops'])
    started = time.monotonic()
    child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.PIPE if stdin else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True, preexec_fn=limit_child)
    record.update(launched=True, pid=child.pid)
    dump(folder / 'process.json', {'pid': child.pid, 'start_unix': record['start_unix']})
    if stdin:
        child.stdin.write(stdin)
        child.stdin.close()
    selector = selectors.DefaultSelector()
    streams = {}
    for label, pipe in [('stdout', child.stdout), ('stderr', child.stderr)]:
        streams[label] = (folder / label).open('wb')
        selector.register(pipe, selectors.EVENT_READ, label)
    stopped_at = None
    last_probe = 0
    with (folder / 'resources.jsonl').open('w') as telemetry:
        while selector.get_map() or child.poll() is None:
            now = time.monotonic()
            if now - last_probe >= 1:
                sample = resources()
                sample['elapsed_seconds'] = now - started
                telemetry.write(json.dumps(sample) + '\n')
                telemetry.flush()
                failures = reasons(sample)
                if now - started > 1800:
                    failures.append('wall_seconds')
                if failures and stopped_at is None and child.poll() is None:
                    record['stops'] = failures
                    os.killpg(child.pid, signal.SIGTERM)
                    stopped_at = now
                if stopped_at and now - stopped_at > 5 and child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                last_probe = now
            for key, _ in selector.select(0.1):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if chunk:
                    streams[key.data].write(chunk)
                else:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
    for stream in streams.values():
        stream.close()
    selector.close()
    record.update(exit_code=child.wait(), elapsed_seconds=time.monotonic() - started,
                  resources_after=resources(), output_closed=True)
    record['output_sha256'] = {name: sha(folder / name) for name in ['stdout', 'stderr', 'resources.jsonl']}
    dump(folder / 'result.json', record)
    print(json.dumps({'command': name, 'exit_code': record['exit_code'],
                      'seconds': record['elapsed_seconds'], 'stops': record['stops']}), flush=True)
    if record['exit_code'] or record['stops']:
        raise RuntimeError(record)
    return record


def main():
    assert not REPO.exists() and not (V / 'setup-result.json').exists()
    assert subprocess.check_output(GIT + ['rev-parse', 'HEAD'], cwd=ORIGIN, text=True).strip() == BASE
    commands = []
    commands.append(run('git-version', GIT + ['--version'], V))
    commands.append(run('clone-baseline', GIT + ['clone', '--quiet', '--shared', '--no-hardlinks',
        '--no-checkout', str(ORIGIN), str(REPO)], V))
    commands.append(run('configure-no-gc', GIT + ['config', 'gc.auto', '0'], REPO))
    commands.append(run('configure-no-maintenance', GIT + ['config', 'maintenance.auto', 'false'], REPO))
    commands.append(run('sparse-baseline', GIT + ['sparse-checkout', 'set', '--no-cone', '--stdin'],
                        REPO, b'/*\n!/docs/evidence/\n'))
    commands.append(run('checkout-baseline', GIT + ['checkout', '--quiet', '--detach', BASE], REPO))
    assert not (REPO / 'docs/evidence').exists()
    assert subprocess.check_output(GIT + ['rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
    run('baseline-diff', GIT + ['diff', '--exit-code', '--'], REPO)
    run('baseline-cached-diff', GIT + ['diff', '--cached', '--exit-code', '--'], REPO)
    tree = subprocess.check_output(GIT + ['ls-tree', '-rzl', '--full-tree', BASE], cwd=REPO)
    files = {}
    omitted = 0
    omitted_bytes = 0
    gitlinks = {}
    symlinks = {}
    for entry in tree.split(b'\0'):
        if not entry:
            continue
        header, raw_name = entry.split(b'\t', 1)
        mode, kind, oid, length = header.split()
        name = os.fsdecode(raw_name)
        if name.startswith('docs/evidence/'):
            omitted += 1
            if length != b'-':
                omitted_bytes += int(length)
            continue
        path = REPO / name
        if kind == b'commit':
            gitlinks[name] = oid.decode()
            continue
        assert kind == b'blob', (name, kind)
        if mode == b'120000':
            assert path.is_symlink()
            content = os.fsencode(os.readlink(path))
            symlinks[name] = os.readlink(path)
        else:
            assert path.is_file() and not path.is_symlink(), name
            content = path.read_bytes()
            assert bool(path.stat().st_mode & stat.S_IXUSR) == (mode == b'100755'), name
        assert len(content) == int(length), name
        assert hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest() == oid.decode(), name
        files[name] = {'git_blob': oid.decode(), 'sha256': hashlib.sha256(content).hexdigest(),
                       'bytes': len(content), 'mode': mode.decode()}
    with gzip.open(V / 'baseline-source-inventory-v1.json.gz', 'wt') as stream:
        json.dump(files, stream, sort_keys=True)
    result = {'complete': True, 'base_revision': BASE, 'source_repo': str(REPO),
              'setup_helper_sha256': sha(Path(__file__)),
              'materialized_paths_verified': len(files),
              'materialized_source_bytes': sum(row['bytes'] for row in files.values()),
              'source_inventory_sha256': sha(V / 'baseline-source-inventory-v1.json.gz'),
              'historical_evidence_paths_omitted_from_checkout': omitted,
              'historical_evidence_blob_bytes_omitted_from_checkout': omitted_bytes,
              'historical_evidence_tree': subprocess.check_output(GIT + ['rev-parse', BASE + ':docs/evidence'],
                   cwd=REPO, text=True).strip(),
              'original_history_and_worktree_unchanged_by_this_setup': True,
              'git_object_alternates': (REPO / '.git/objects/info/alternates').read_text().splitlines(),
              'symlinks': symlinks, 'gitlinks_requiring_command_specific_qualification': gitlinks,
              'commands': commands, 'remaining_resources': resources(),
              'cargo_validation_complete': False, 'cache_candidate_admitted': False,
              'full_plan_complete': False, 'source_checkout_still_open_for_declared_validation': True}
    dump(V / 'setup-result.json', result)
    assert not reasons(resources())
    print(json.dumps({key: result[key] for key in ['complete', 'materialized_paths_verified',
        'materialized_source_bytes', 'historical_evidence_paths_omitted_from_checkout',
        'cargo_validation_complete']}), flush=True)


if __name__ == '__main__':
    main()
