"""Fresh validation runner with an explicit target and declared per-command limit."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import shutil
import signal
import stat
import subprocess
import time

V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
ORIGIN = Path('/home/tim/Documents/GitHub/workspace/csgrs')
REPO = V / 'checkout-baseline-v1'
BASE = '7ed43501755fd64a01f54c3078d12229cbc0129d'
INITIAL = json.loads((V / 'control/initial-state.json').read_text())
GIT = ['git', '-c', 'core.splitIndex=true', '-c', 'index.version=4',
       '-c', 'maintenance.auto=false', '-c', 'gc.auto=0']


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def resources():
    mem = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    return {'free_bytes': shutil.disk_usage(V).free,
            'host_available_bytes': int(mem['MemAvailable'].split()[0]) * 1024,
            'log_bytes': sum(p.stat().st_size for p in (V / 'logs').rglob('*') if p.is_file())}


def reasons(sample):
    result = []
    if sample['free_bytes'] < 512 * 1024**2:
        result.append('active_volume_free_bytes')
    if INITIAL['new_free_bytes'] - sample['free_bytes'] > 64 * 1024**3:
        result.append('fresh_volume_consumption_64_gib')
    if sample['host_available_bytes'] < 2 * 1024**3:
        result.append('host_available_memory')
    if sample['log_bytes'] > 64 * 1024**2:
        result.append('command_log_bytes')
    return result


def limit_child():
    resource.setrlimit(resource.RLIMIT_AS, (8 * 1024**3, 8 * 1024**3))


def run(name, argv, cwd, stdin=None, *, target=None, wall_seconds=1800):
    folder = V / 'logs' / name
    folder.mkdir()
    scratch = V / 'scratch' / name
    scratch.mkdir()
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0',
               TMPDIR=str(scratch), CARGO_HOME=str(V / 'cargo-home-v1'),
               CARGO_TARGET_DIR=str(target if target is not None else V / 'target-baseline-v1'),
               CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0')
    selected_env = {key: env[key] for key in [
        'GIT_OPTIONAL_LOCKS', 'TMPDIR', 'CARGO_HOME', 'CARGO_TARGET_DIR',
        'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL']}
    selected_env.update({key: env[key] for key in ['CARGO_NET_OFFLINE', 'RUSTC', 'RUSTDOC', 'RUSTUP_TOOLCHAIN', 'RUSTFLAGS', 'RUSTDOCFLAGS'] if key in env})
    before = resources()
    record = {'argv': argv, 'cwd': str(cwd), 'environment_overrides': selected_env,
              'stdin': stdin.decode() if stdin else None, 'start_unix': time.time(),
              'resources_before': before, 'stops': reasons(before), 'launched': False,
              'wall_limit_seconds': wall_seconds}
    if record['stops']:
        record.update(exit_code=None, output_closed=True)
        dump(folder / 'result.json', record)
        raise RuntimeError(record['stops'])
    started = time.monotonic()
    child = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.PIPE if stdin else subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             start_new_session=True, preexec_fn=limit_child)
    record.update(launched=True, pid=child.pid)
    dump(folder / 'process.json', {'pid': child.pid, 'start_unix': record['start_unix']})
    if stdin:
        child.stdin.write(stdin)
        child.stdin.close()
    selector = selectors.DefaultSelector()
    streams = {}
    for label, pipe in [('stdout', child.stdout), ('stderr', child.stderr)]:
        streams[label] = (folder / label).open('wb')
        selector.register(pipe, selectors.EVENT_READ, label)
    stopped_at = None
    last_probe = 0
    with (folder / 'resources.jsonl').open('w') as telemetry:
        while selector.get_map() or child.poll() is None:
            now = time.monotonic()
            if now - last_probe >= 1:
                sample = resources()
                sample['elapsed_seconds'] = now - started
                telemetry.write(json.dumps(sample) + '\n')
                telemetry.flush()
                failures = reasons(sample)
                if now - started > wall_seconds:
                    failures.append('wall_seconds')
                if failures and stopped_at is None and child.poll() is None:
                    record['stops'] = failures
                    os.killpg(child.pid, signal.SIGTERM)
                    stopped_at = now
                if stopped_at and now - stopped_at > 5 and child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                last_probe = now
            for key, _ in selector.select(0.1):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if chunk:
                    streams[key.data].write(chunk)
                    streams[key.data].flush()
                else:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
    for stream in streams.values():
        stream.close()
    selector.close()
    record.update(exit_code=child.wait(), elapsed_seconds=time.monotonic() - started,
                  resources_after=resources(), output_closed=True)
    record['output_sha256'] = {name: sha(folder / name) for name in ['stdout', 'stderr', 'resources.jsonl']}
    dump(folder / 'result.json', record)
    print(json.dumps({'command': name, 'exit_code': record['exit_code'],
                      'seconds': record['elapsed_seconds'], 'stops': record['stops']}), flush=True)
    if record['exit_code'] or record['stops']:
        raise RuntimeError(record)
    return record
