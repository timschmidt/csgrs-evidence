"""Verify the checkout, including expanded Git LFS objects, without rewriting it."""
import gzip
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from setup_v1 import BASE, GIT, ORIGIN, REPO, V, dump, reasons, resources, sha

assert not (V / 'setup-result.json').exists()
assert not (V / 'baseline-source-inventory-v1.json.gz').exists()
assert not reasons(resources())
for name in ['git-version', 'clone-baseline', 'configure-no-gc', 'configure-no-maintenance',
             'sparse-baseline', 'checkout-baseline', 'baseline-diff', 'baseline-cached-diff']:
    result = json.loads((V / 'logs' / name / 'result.json').read_text())
    assert result['exit_code'] == 0 and not result['stops'] and result['output_closed']
    for path, digest in result['output_sha256'].items():
        assert sha(V / 'logs' / name / path) == digest
failure_path = 'crates/comparisons/audits/continuation/calcium/results/matrix-function-memcheck.vgcore'
raw_pointer = subprocess.check_output(GIT + ['cat-file', 'blob', BASE + ':' + failure_path], cwd=REPO)
assert len(raw_pointer) == 133
assert (REPO / failure_path).stat().st_size == 78024704
assert sha(REPO / failure_path) == sha(ORIGIN / failure_path)
dump(V / 'control/setup-v1-failure.json', {
    'observed_exit_code': 1, 'failed_assertion': 'len(content) == Git blob size',
    'path': failure_path, 'git_pointer_bytes': len(raw_pointer),
    'expanded_bytes': 78024704, 'expanded_sha256': sha(REPO / failure_path),
    'original_worktree_bytes_match': True,
    'cause': 'Git LFS checkout materialized the real asset, while the verifier expected pointer bytes.',
    'repair': 'Verify canonical LFS pointer syntax, filter attribution, declared size and object SHA-256.',
    'fixtures_unchanged': True, 'original_helper_sha256': sha(V / 'control/setup_v1.py')})
assert subprocess.check_output(GIT + ['rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
assert not (REPO / 'docs/evidence').exists()
tree = subprocess.check_output(GIT + ['ls-tree', '-rzl', '--full-tree', BASE], cwd=REPO)
files = {}
omitted = 0
omitted_bytes = 0
gitlinks = {}
symlinks = {}
lfs = {}
for entry in tree.split(b'\0'):
    if not entry:
        continue
    header, raw_name = entry.split(b'\t', 1)
    mode, kind, oid, length = header.split()
    name = os.fsdecode(raw_name)
    if name.startswith('docs/evidence/'):
        omitted += 1
        if length != b'-':
            omitted_bytes += int(length)
        continue
    path = REPO / name
    if kind == b'commit':
        gitlinks[name] = oid.decode()
        continue
    assert kind == b'blob'
    if mode == b'120000':
        assert path.is_symlink()
        content = os.fsencode(os.readlink(path))
        h256 = hashlib.sha256(content).hexdigest()
        blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        actual_size = len(content)
        prefix = content[:80]
        symlinks[name] = os.readlink(path)
    else:
        assert path.is_file() and not path.is_symlink(), name
        assert bool(path.stat().st_mode & stat.S_IXUSR) == (mode == b'100755'), name
        actual_size = path.stat().st_size
        h1 = hashlib.sha1(b'blob ' + str(actual_size).encode() + b'\0')
        h2 = hashlib.sha256()
        prefix = b''
        with path.open('rb') as stream:
            while chunk := stream.read(1024 * 1024):
                if not prefix:
                    prefix = chunk[:80]
                h1.update(chunk)
                h2.update(chunk)
        h256 = h2.hexdigest()
        blob = h1.hexdigest()
    storage = 'git-blob'
    if actual_size != int(length) or blob != oid.decode() or prefix.startswith(b'version https://git-lfs.github.com/spec/'):
        assert int(length) < 1024 and mode != b'120000', name
        pointer = subprocess.check_output(GIT + ['cat-file', 'blob', BASE + ':' + name], cwd=REPO)
        assert hashlib.sha1(b'blob ' + str(len(pointer)).encode() + b'\0' + pointer).hexdigest() == oid.decode()
        match = re.fullmatch(rb'version https://git-lfs.github.com/spec/v1\noid sha256:([0-9a-f]{64})\nsize ([0-9]+)\n', pointer)
        assert match, name
        assert h256 == match[1].decode() and actual_size == int(match[2]), name
        attributes = subprocess.check_output(GIT + ['check-attr', '-z', 'filter', '--', name], cwd=REPO)
        assert attributes.split(b'\0')[1:3] == [b'filter', b'lfs']
        lfs[name] = {'pointer_git_blob': oid.decode(), 'expanded_sha256': h256,
                     'expanded_bytes': actual_size}
        storage = 'expanded-lfs-object'
    files[name] = {'git_blob': oid.decode(), 'sha256': h256, 'bytes': actual_size,
                   'mode': mode.decode(), 'storage': storage}
with gzip.open(V / 'baseline-source-inventory-v1.json.gz', 'wt') as stream:
    json.dump(files, stream, sort_keys=True)
result = {'complete': True, 'base_revision': BASE, 'source_repo': str(REPO),
          'setup_helper_sha256': sha(V / 'control/setup_v1.py'),
          'verification_helper_sha256': sha(Path(__file__)),
          'materialized_paths_verified': len(files),
          'materialized_source_bytes': sum(row['bytes'] for row in files.values()),
          'source_inventory_sha256': sha(V / 'baseline-source-inventory-v1.json.gz'),
          'historical_evidence_paths_omitted_from_checkout': omitted,
          'historical_evidence_blob_bytes_omitted_from_checkout': omitted_bytes,
          'historical_evidence_tree': subprocess.check_output(GIT + ['rev-parse', BASE + ':docs/evidence'],
               cwd=REPO, text=True).strip(),
          'original_worktree_unchanged_by_this_setup': True,
          'git_object_alternates': (REPO / '.git/objects/info/alternates').read_text().splitlines(),
          'symlinks': symlinks, 'gitlinks_requiring_command_specific_qualification': gitlinks,
          'expanded_lfs_objects_verified': lfs, 'original_failed_verifier_preserved': True,
          'remaining_resources': resources(), 'cargo_validation_complete': False,
          'cache_candidate_admitted': False, 'full_plan_complete': False,
          'source_checkout_still_open_for_declared_validation': True}
dump(V / 'setup-result.json', result)
assert not reasons(resources())
print(json.dumps({key: result[key] for key in ['complete', 'materialized_paths_verified',
    'materialized_source_bytes', 'historical_evidence_paths_omitted_from_checkout',
    'cargo_validation_complete']} | {'lfs_objects': len(lfs)}), flush=True)
