"""Populate a fresh Cargo home on the validation volume using the unchanged lock."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import tomllib

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from setup_v1 import BASE, ORIGIN, REPO, V, dump, reasons, resources, run, sha

setup = json.loads((V / 'setup-result.json').read_text())
assert setup['complete'] and setup['base_revision'] == BASE
assert not (V / 'cargo-preparation-v1.json').exists()
inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
for name in ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml']:
    assert sha(REPO / name) == inventory[name]['sha256']
toolbin = Path('/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin')
os.environ['PATH'] = str(toolbin) + os.pathsep + os.environ['PATH']
os.environ['RUSTC'] = str(toolbin / 'rustc')
os.environ['RUSTDOC'] = str(toolbin / 'rustdoc')
os.environ['RUSTUP_TOOLCHAIN'] = 'stable-x86_64-unknown-linux-gnu'
os.environ['CARGO_NET_OFFLINE'] = 'false'
os.environ['XDG_CACHE_HOME'] = str(V / 'xdg-cache-v1')
extra_env = {key: os.environ[key] for key in [
    'PATH', 'RUSTC', 'RUSTDOC', 'RUSTUP_TOOLCHAIN', 'CARGO_NET_OFFLINE', 'XDG_CACHE_HOME']}
tools = {str(toolbin / name): sha(toolbin / name) for name in [
    'cargo', 'rustc', 'rustdoc', 'clippy-driver', 'cargo-clippy', 'rustfmt', 'cargo-fmt']}
dump(V / 'cargo-preparation-protocol-v1.json', {
    'base_revision': BASE, 'manifest_sha256': sha(REPO / 'Cargo.toml'),
    'lock_sha256': sha(REPO / 'Cargo.lock'), 'configuration_sha256': sha(REPO / '.cargo/config.toml'),
    'tool_sha256': tools, 'additional_environment': extra_env,
    'fresh_cargo_home': str(V / 'cargo-home-v1'),
    'original_cargo_home_writes_permitted': False, 'rustup_installation_or_update_permitted': False,
    'prepare_helper_sha256': sha(Path(__file__))})
commands = []
commands.append(run('cargo-version-v1', [str(toolbin / 'cargo'), '--version'], REPO))
commands.append(run('rustc-version-v1', [str(toolbin / 'rustc'), '-Vv'], REPO))
commands.append(run('cargo-metadata-v1', [str(toolbin / 'cargo'), 'metadata', '--locked',
    '--offline', '--no-deps', '--format-version', '1'], REPO))
commands.append(run('cargo-fetch-v1', [str(toolbin / 'cargo'), 'fetch', '--locked'], REPO))
assert sha(REPO / 'Cargo.lock') == inventory['Cargo.lock']['sha256']
lock = tomllib.loads((REPO / 'Cargo.lock').read_text())
expected = {(p['name'], p['version']): p.get('checksum') for p in lock['package']
            if p.get('source', '').startswith('registry+')}
archives = {}
for path in sorted((V / 'cargo-home-v1/registry/cache').glob('*/*.crate')):
    key = next(((name, version) for name, version in expected if path.name == name + '-' + version + '.crate'), None)
    assert key is not None, path
    digest = sha(path)
    assert digest == expected[key], path
    archives[str(path)] = {'sha256': digest, 'bytes': path.stat().st_size,
                           'name': key[0], 'version': key[1]}
with gzip.open(V / 'cargo-archive-inventory-v1.json.gz', 'wt') as stream:
    json.dump(archives, stream, sort_keys=True)
assert all(sha(p) == h for p, h in tools.items())
assert not reasons(resources())
dump(V / 'cargo-preparation-v1.json', {'complete': True, 'commands': commands,
    'crate_archives_verified_against_lock': len(archives),
    'registry_packages_in_workspace_lock': len(expected),
    'archive_inventory_sha256': sha(V / 'cargo-archive-inventory-v1.json.gz'),
    'manifest_and_lock_unchanged': True, 'compiler_binaries_unchanged': True,
    'source_checkout': str(REPO), 'cargo_home_still_open_for_validation': True,
    'cargo_validation_complete': False, 'cache_candidate_admitted': False,
    'full_plan_complete': False, 'remaining_resources': resources()})
print(json.dumps({'cargo_cache_prepared': True, 'verified_crate_archives': len(archives),
                  'lock_registry_packages': len(expected)}), flush=True)
