"""Check a private, whitespace-free mount alias without changing the host mounts."""
import hashlib
import json
from pathlib import Path
import subprocess

V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
MOUNT = Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W = V / 'control/spaceless-mount-v1'
assert not W.exists() and not MOUNT.exists()
W.mkdir()
MOUNT.mkdir(mode=0o700)
program = """import json, os
from pathlib import Path
p = Path('control/spaceless-mount-v1/visible-from-host.txt')
p.write_text('private mount alias probe\\n')
print(json.dumps({'cwd': os.getcwd(), 'marker_bytes': p.stat().st_size}))
"""
argv = ['/usr/bin/bwrap', '--die-with-parent', '--ro-bind', '/', '/',
        '--dev', '/dev', '--ro-bind', '/proc', '/proc', '--bind', str(V), str(MOUNT),
        '--chdir', str(MOUNT), '/usr/bin/python3', '-B', '-c', program]
result = subprocess.run(argv, capture_output=True, timeout=30)
(W / 'stdout').write_bytes(result.stdout)
(W / 'stderr').write_bytes(result.stderr)
record = {'argv': argv, 'exit_code': result.returncode, 'host_mount_changes': False,
          'host_placeholder_directory': str(MOUNT), 'physical_volume': str(V),
          'source_and_dependency_changes': False,
          'private_root_read_only_except_validation_alias_and_minimal_dev': True,
          'probe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
if result.returncode == 0:
    observed = json.loads(result.stdout)
    assert observed['cwd'] == str(MOUNT) and ' ' not in observed['cwd']
    marker = W / 'visible-from-host.txt'
    assert marker.read_text() == 'private mount alias probe\n'
    assert not list(MOUNT.iterdir())
    record.update(complete=True, canonical_cwd_has_no_spaces=True,
                  private_writes_visible_on_disk_b=True,
                  marker_sha256=hashlib.sha256(marker.read_bytes()).hexdigest())
else:
    record.update(complete=False, error=result.stderr.decode(errors='replace'))
(W / 'result.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({k:record[k] for k in ['complete','exit_code','host_mount_changes']}))
if result.returncode:
    raise SystemExit(result.returncode)
