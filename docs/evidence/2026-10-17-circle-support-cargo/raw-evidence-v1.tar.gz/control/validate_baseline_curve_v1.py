"""Compile and execute the unchanged Hypercurve CI test command in fresh storage."""
import gzip
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from setup_v1 import BASE, GIT, REPO, V, dump, reasons, resources, run, sha

prepared = json.loads((V / 'cargo-preparation-v1.json').read_text())
assert prepared['complete']
protocol = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(path) == digest for path, digest in protocol['tool_sha256'].items())
os.environ.update(protocol['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
assert subprocess.check_output(GIT + ['rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == BASE
assert not reasons(resources())
inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
for name, row in inventory.items():
    if name.startswith(('crates/hypercurve/', 'crates/hypersolve/', 'crates/hypertri/',
                        'crates/hyperlattice/', 'crates/hyperlimit/', 'crates/hyperreal/')):
        assert sha(REPO / name) == row['sha256'], name
for name in ['Cargo.toml', 'Cargo.lock', '.cargo/config.toml', '.github/workflows/hypercurve.yml']:
    assert sha(REPO / name) == inventory[name]['sha256']
cargo = str(Path(protocol['additional_environment']['RUSTC']).with_name('cargo'))
cwd = REPO / 'crates/hypercurve'
compile_argv = [cargo, 'test', '--release', '--locked', '--all-features', '--no-run']
test_argv = [cargo, 'test', '--release', '--locked', '--all-features', '--no-fail-fast',
             '--', '--test-threads=2']
dump(V / 'baseline-curve-protocol-v1.json', {
    'base_revision': BASE, 'source_checkout': str(REPO),
    'source_inventory_sha256': sha(V / 'baseline-source-inventory-v1.json.gz'),
    'toolchain_protocol_sha256': sha(V / 'cargo-preparation-protocol-v1.json'),
    'workflow_sha256': sha(REPO / '.github/workflows/hypercurve.yml'),
    'compile_command': compile_argv, 'test_command': test_argv,
    'cargo_net_offline': True, 'cargo_target_still_open_for_matrix': True,
    'time_limit_seconds_per_command': 1800, 'test_threads': 2,
    'full_fixtures_unchanged': True, 'policy_unchanged': True,
    'performance_comparison': False, 'candidate_cache_applied': False,
    'omitted_history_not_referenced_by_inspected_affected_rust_tests': True})
compile_result = run('baseline-curve-compile-v1', compile_argv, cwd)
test_result = run('baseline-curve-tests-v1', test_argv, cwd)
subprocess.run(GIT + ['diff', '--quiet'], cwd=REPO, check=True)
subprocess.run(GIT + ['diff', '--cached', '--quiet'], cwd=REPO, check=True)
assert sha(REPO / 'Cargo.lock') == inventory['Cargo.lock']['sha256']
assert not reasons(resources())
dump(V / 'baseline-curve-result-v1.json', {
    'complete': True, 'compile': compile_result, 'tests': test_result,
    'tracked_source_changes': False, 'runtime_tests_executed': True,
    'cache_candidate_applied': False, 'cache_candidate_admitted': False,
    'full_cargo_matrix_qualified': False, 'downstream_native_qualified': False,
    'full_plan_complete': False})
print(json.dumps({'baseline_curve_ci_test_command_passed': True,
                  'cache_candidate_applied': False}), flush=True)
