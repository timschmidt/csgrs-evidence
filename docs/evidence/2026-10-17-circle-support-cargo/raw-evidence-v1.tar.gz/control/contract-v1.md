# Fresh validation on an independently writable volume

Owner: validation/reproducibility infrastructure for the full properties plan.
The original repository has fallen below its 512 MiB free-space reserve. Prior
stopped/refused attempts retain their original outcomes and contracts. A newly
inspected user-owned ext4 volume at /run/media/tim/Disk B provides fresh native
build capacity. This is a new isolated validation environment, not a restart
inside a frozen target and not a reduced geometry workload.

Create a dedicated local Git clone with original objects as read-only alternates
and independent metadata, index and outputs. Use the exact recorded HEAD. Omit
only root docs/evidence from the checkout through a declared sparse pattern;
its historical contents remain in the original repository and object database.
Materialize every other tracked source, fixture, manifest, lockfile and asset.
Before accepting this checkout for a command, inspect that command's source and
artifact dependencies; include any required historical input from verified
original bytes. Never drop a difficult test or fixture to accommodate the
checkout. Do not claim commands requiring missing history have passed.

Use a fresh Cargo home and fresh targets on this volume. The original source,
Git metadata, Cargo home, closed targets, controls and evidence are read-only.
Keep compiler/dependency/source identity explicit. Disable automatic Git
maintenance; no push, publication, cleanup or deletion is part of this setup.
No original workload gate, precision, policy or validation assertion changes.

The active checkout/output filesystem retains the 512 MiB free-space reserve;
require 64 GiB free before initialization. Commands have 1,800 wall seconds,
8 GiB child address space and a 2 GiB host available-memory reserve. Observe
output growth, with 64 GiB for this fresh environment and 64 MiB of command logs
as external limits. Limits may overshoot between observations; they establish
no internal algorithmic bound. A command is complete only after its terminal
status and outputs have been collected. Keep failures and all new physical
paths independently hashed at closure, without inode deduplication.

This setup does not admit the cache candidate, qualify a release, complete the
manuscript, repair the original repository reserve or complete the full plan.
Only an appropriate later acceptance record can support those conclusions.
