set -eu
s=/dev/shm/interval-proof-replay
i=0
for v in entry primary primary entry primary entry entry primary;do
 i=$((i+1))
 if test "$v" = primary;then other=entry;else other=primary;fi
 for cpu in 3 5;do
  if test "$cpu" = 3;then impl=$v;else impl=$other;fi
  CRITERION_HOME="$s/entry-confirmation/$cpu/$i-$impl" setarch "$(uname -m)" -R taskset -c "$cpu" "$s/images/$impl-certification" --bench --noplot --warm-up-time 1 --measurement-time 3 --sample-size 50 'certify_multivariate_quadratic_krawczyk_square/1$' > "$s/logs/confirmation-$cpu-$i-$impl" 2>&1 &
 done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
