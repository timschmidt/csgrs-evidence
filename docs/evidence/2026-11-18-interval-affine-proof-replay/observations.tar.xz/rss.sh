set -eu
s=/dev/shm/interval-proof-replay
for n in $(seq 1 12); do
 if test $(( n % 2 )) = 0; then variants="primary affine"; else variants="affine primary"; fi
 for v in $variants; do
  python3 "$s/history/logs/previous-clients/measure-rss.py" "$s/logs/$v-rss-$n" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-usable" > "$s/logs/$v-usable-$n"
 done
done
