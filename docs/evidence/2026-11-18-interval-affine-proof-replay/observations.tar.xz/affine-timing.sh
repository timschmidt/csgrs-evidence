set -eu
s=/dev/shm/interval-proof-replay
for campaign in quiet confirmation; do
 bash "$s/affine-$campaign.sh"
 python3 "$s/timing.py" "affine-$campaign" > "$s/affine-$campaign.json"
done
