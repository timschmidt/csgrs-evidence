set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-proof-replay
b=/dev/shm/interval-box-coverage
export CARGO_TARGET_DIR="$b/other-target"
cd "$b/observer"
for v in affine primary; do
 if test "$v" = primary; then git -C "$b/csgrs" restore crates/hypersolve/src/interval.rs; fi
 cargo run --release --locked > "$s/logs/$v-proof-rows"
done
cmp "$s/logs/primary-proof-rows" "$s/logs/affine-proof-rows"
cmp "$s/logs/primary-client-rows" "$s/logs/affine-client-rows"
cmp "$s/logs/primary-usable-rows" "$s/logs/affine-usable-rows"
