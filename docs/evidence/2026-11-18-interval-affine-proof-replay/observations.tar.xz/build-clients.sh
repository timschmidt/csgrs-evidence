set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-proof-replay
b=/dev/shm/interval-box-coverage
k=/dev/shm/interval-krawczyk-certainty
case "$2" in
regular-native) cd "$b/lifetime"; p=radius-lifetime;;
stress-native) cd "$k/stress-life"; p=proof-stress-lifetime;;
regular-wasm) cd "$b/portable-krawczyk"; p=box_radius_client.wasm;;
stress-wasm) cd "$k/stress"; p=kraw_stress.wasm;;
esac
case "$2" in
*-native) export CARGO_TARGET_DIR="$b/lifetime-target"; cargo build --release --locked; cp "$CARGO_TARGET_DIR/release/$p" "$s/images/$1-$2";;
*-wasm) export CARGO_TARGET_DIR="$b/wasm-target"; cargo build --release --locked --target wasm32-unknown-unknown; cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/$p" "$s/images/$1-$2";;
esac
