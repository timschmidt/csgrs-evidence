set -eu
s=/dev/shm/interval-proof-replay
i=0
for v in repair primary primary repair primary repair repair primary;do
 i=$((i+1))
 if test "$v" = primary;then other=repair;else other=primary;fi
 for cpu in 5 15;do
  if test "$cpu" = 5;then impl=$v;else impl=$other;fi
  CRITERION_HOME="$s/quiet/$cpu/$i-$impl" setarch "$(uname -m)" -R taskset -c "$cpu" "$s/images/$impl-certification" --bench --noplot --warm-up-time 1 --measurement-time 3 --sample-size 50 'certify_multivariate_quadratic_krawczyk_square/1$' > "$s/logs/quiet-$cpu-$i-$impl" 2>&1 &
 done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
