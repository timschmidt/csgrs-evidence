from pathlib import Path
import json,statistics,sys
s=Path(__file__).parent
campaign=sys.argv[1]
rows=[]
for d in sorted((s/campaign).iterdir()):
 p={}
 for v in ('primary',campaign.split('-')[0]):
  fs=sorted(d.glob('*-'+v+'/**/new/estimates.json'))
  assert len(fs)==4,(d,v,len(fs))
  p[v]=[json.loads(f.read_text())['median']['point_estimate'] for f in fs]
 a,b=map(statistics.median,p.values())
 rows.append(dict(cpu=int(d.name),samples_ns=p,primary_ns=a,candidate_ns=b,change_percent=100*(b/a-1)))
print(json.dumps(rows,indent=2))
