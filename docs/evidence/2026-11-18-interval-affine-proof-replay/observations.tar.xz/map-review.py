from pathlib import Path
import sys,json
s=Path(__file__).parent
part=(s/'memory.py').read_text().split('hist={tuple(')[0]
tag=sys.argv[1] if len(sys.argv)>1 else 'map'
sys.argv[1:]=[tag]
exec(compile(part,'map-regular','exec'))
a=json.loads((s/(tag+'-lifetime.json')).read_text())
print('regular relative and accumulated failures:',sum(not z['passes'] for z in a))
for z in a:
 if not z['passes'] and z['key'][0]=='STACK':
  print('example:',z);break
old=s/'logs/primary-client-rows';new=s/('logs/'+tag+'-client-rows')
if new.exists():
 x=old.read_text().splitlines(); y=new.read_text().splitlines(); assert len(x)==len(y)==252
 for kind in ['VERDICT','EVIDENCE','HEAP']:
  p=[v for v in x if v.startswith(kind+'|')];q=[v for v in y if v.startswith(kind+'|')]
  assert len(p)==len(q)==84
  print(kind,'changed',sum(i!=j for i,j in zip(p,q)))
