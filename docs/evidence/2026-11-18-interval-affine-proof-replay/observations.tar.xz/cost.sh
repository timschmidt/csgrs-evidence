set -eu
s=/dev/shm/interval-proof-replay
b=/dev/shm/interval-box-coverage
k=/dev/shm/interval-krawczyk-certainty
v=$1
for i in $(seq 1 24); do setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-regular-native" > "$s/logs/$v-life-$i" 2> "$s/logs/$v-guard-$i"; done
for i in $(seq 1 48); do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-stress-native" > "$s/logs/$v-stress-life-$i" 2> "$s/logs/$v-stress-guard-$i"; done
node "$b/portable-krawczyk/check.cjs" "$s/images/$v-regular-wasm" repaired > "$s/logs/$v-regular-guest"
if test "$v" = primary; then mode=multi; else mode=entry; fi
if test "$v" = affine; then mode=affine; fi
node "$s/stress-check.cjs" "$s/images/$v-stress-wasm" "$mode" > "$s/logs/$v-stress-guest"
