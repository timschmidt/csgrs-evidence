set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-proof-replay
b=/dev/shm/interval-box-coverage
export CARGO_TARGET_DIR="$b/lifetime-target"
cd "$b/usable"
for v in affine primary; do
 if test "$v" = primary; then git -C "$b/wasm-repo" restore crates/hypersolve/src/interval.rs; fi
 cargo build --locked --release
 cp "$CARGO_TARGET_DIR/release/radius-usable" "$s/images/$v-usable"
 "$s/images/$v-usable" > "$s/logs/$v-usable-rows"
done
git -C "$b/wasm-repo" apply "$s/affine.patch"
cmp "$s/logs/primary-usable-rows" "$s/logs/affine-usable-rows"
python3 "$s/other-size.py" affine
