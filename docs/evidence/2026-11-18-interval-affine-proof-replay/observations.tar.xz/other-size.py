from pathlib import Path
s=Path(__file__).parent
r=(s/'analyze.py').read_text().replace("[('certification','certification'),('lifetime','regular-native'),('wasm','regular-wasm')]", "[('client','client'),('usable','usable')]").replace("+'-size.json'","+'-other-size.json'")
exec(compile(r,'other-size','exec'))
