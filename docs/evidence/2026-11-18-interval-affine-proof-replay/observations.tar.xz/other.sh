set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-proof-replay
b=/dev/shm/interval-box-coverage
export CARGO_TARGET_DIR="$b/other-target"
for v in primary affine; do
 if test "$v" = affine; then git -C "$b/csgrs" apply "$s/affine.patch"; fi
 for t in client usable; do
  if test "$t" = client; then file=box-coverage-client; else file=radius-usable; fi
  cd "$b/$t"
  cargo build --locked --release
  cp "$CARGO_TARGET_DIR/release/$file" "$s/images/$v-$t"
  "$s/images/$v-$t" > "$s/logs/$v-$t-rows"
 done
done
