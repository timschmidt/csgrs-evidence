import json,sys,ast
from pathlib import Path
s=Path(__file__).resolve().parent
h=s/'history'
sys.path.insert(0,str(h/'logs/previous-clients'))
from image_metrics import sizes
def read(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def wasm(p):
 data=p.read_bytes()
 i=8
 while i<len(data):
  k=data[i];i+=1;n=0;shift=0
  while True:
   b=data[i];i+=1;n|=(b&127)<<shift
   if b<128:break
   shift+=7
  if k==10:return {'file':len(data),'code':n}
  i+=n
 raise ValueError(p)
hist={a['target']:a for a in read(h/'images-multi.json')}
rows=[]
for t,suffix in [('certification','certification'),('lifetime','regular-native'),('wasm','regular-wasm')]:
 fn=wasm if t=='wasm' else sizes
 ab=[fn(s/'images'/(tag+'-'+suffix)) for tag in ('primary',sys.argv[1])]
 for metric in set(ab[0])|set(ab[1]):
  p,n=(r.get(metric,0) for r in ab)
  m=hist[t]['metrics'][metric];fixed=m['baseline'];prev=m['measured'];caps=m['limits']
  i=max(0,n-p);carry=m['cumulative']+max(0,p-prev);c=carry+i
  ok=i<=caps[0] and 100*i<=p*caps[1] and c<=caps[2] and 100*c<=fixed*caps[3]
  rows.append(dict(target=t,metric=metric,fixed=fixed,prior_archive=prev,preceding=p,candidate=n,increment=i,carry=carry,cumulative=c,caps=caps,passes=ok))
write(s/(sys.argv[1]+'-size.json'),sorted(rows,key=lambda r:(r['target'],r['metric'])))
print('size failed',[(r['target'],r['metric'],r['preceding'],r['candidate'],r['increment'],r['carry']) for r in rows if not r['passes']])
