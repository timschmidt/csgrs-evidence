from pathlib import Path
import json,ast,sys
r=s=Path(__file__).parent
h=k=s/'history'
tag=sys.argv[1]
def read(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def life(tag):
 d={}
 paths=list((r/'logs').glob(tag+'-life-*'));assert len(paths)==24
 for f in paths:
  for line in f.read_text().splitlines():
   typ,i,rest=line.split('|',2);k=(typ,int(i))
   if typ=='STACK':
    w,pattern,val=rest.split('|');k+=int(w),;v=int(val)
   else:v=ast.literal_eval(rest)
   d.setdefault(k,[]).append(v)
 return {k:max(v) if k[0]=='STACK' else [max(vals) for vals in zip(*v)] for k,v in d.items()}
old,new=life('primary'),life(tag)
a={tuple(m['key']):m for m in read(h/'memory-multi.json')}
hist={(m['workload'],int(m['temperature']=='warm')):m for m in read(h/'regular-stack-accounts.json')}
life_rows=[]
for k,now in new.items():
 if k[0]=='STACK':
  m=hist[k[1:]];prev=min(old[k],m['candidate']);base=m['fixed'];i=max(0,now-prev);c=i+m['cumulative_charge_bytes']
  passes=i<=128 and i*100<=prev and c<=256 and c*100<=2*base and now<=16384
 else:
  prev=min(old[k][-2],a[k]['after'][-2]);i=max(0,now[-2]-prev);c=i;passes=now[-1]==0 and i==0 and now[-2]<=16384
 life_rows.append(dict(key=k,remeasured=old[k],reference=prev,candidate=now,increment=i,cumulative=c,passes=passes))
write(r/(tag+'-lifetime.json'),life_rows)

print('regular failures',[(m['key'],m['increment'],m['cumulative']) for m in life_rows if not m['passes']])
hist={tuple(m['key']):m for m in json.loads((h/'stress-memory-multi.json').read_text())}
def collect(name):
 out={}
 files=list((s/'logs').glob(name+'-stress-life-*'));assert len(files)==48
 for p in files:
  for l in p.read_text().splitlines():
   t,i,rest=l.split('|',2);key=(t.lower(),int(i))
   if t=='STACK':
    w,pattern,val=rest.split('|');key+=int(w),;v=int(val)
   else:v=ast.literal_eval(rest)
   out.setdefault(key,[]).append(v)
 return {key:max(vals) if key[0]=='stack' else [max(col) for col in zip(*vals)] for key,vals in out.items()}
a,b=map(collect,('primary',tag));out=[]
for key,val in sorted(b.items()):
 case=key[1]
 ref=(key[0],case-6,*key[2:]) if case in ((6,9) if tag=="affine" else (6,7,9,10)) else key
 fixed=hist[ref]['fixed_reference']
 prev=a[ref];arch=hist[ref]['candidate']
 old_charge=max(hist[ref]['cumulative_charge'],hist[key]['cumulative_charge'])
 if key[0]=='stack':
  i=max(0,val-min(prev,arch));cum=i+old_charge
  passes=i<=128 and i*100<=min(prev,arch) and cum<=256 and cum*100<=2*fixed and val<=16384
 else:
  i=max(0,val[-2]-min(prev[-2],arch[-2]));cum=i+old_charge
  passes=cum==0 and val[-2]<=16384 and val[-1]==0
 out.append(dict(key=key,completed_reference=ref,same_policy=a[key],previous=prev,archived_previous=arch,fixed=fixed,candidate=val,prior_charge=old_charge,increment=i,cumulative=cum,passes=passes))
(s/(tag+'-stress.json')).write_text(json.dumps(out,indent=2)+'\n')
print('failed',[(x['key'],x['increment'],x['cumulative']) for x in out if not x['passes']]);print('peak charge',max(x['increment'] for x in out))
print('headroom',min(int(l.split()[-1]) for p in (s/'logs').glob(tag+'-stress-guard-*') for l in p.read_text().splitlines()))
