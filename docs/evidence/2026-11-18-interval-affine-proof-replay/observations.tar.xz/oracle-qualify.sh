set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-proof-replay
export CARGO_TARGET_DIR=/dev/shm/interval-ieee-branches/native
cd "$s/mutant"
cargo test --locked -p hypersolve --all-features --test krawczyk_affine_oracle --test krawczyk_certificates > "$s/logs/mutant-existing" 2>&1
if cargo test --locked -p hypersolve --all-features --test krawczyk_affine_residuals > "$s/logs/mutant-new" 2>&1; then exit 1; fi
rg 'pivot_order_preserves_all_three_original_equations .* FAILED' "$s/logs/mutant-new"
cd /mnt/development/csgrs
cargo test --locked -p hypersolve --test krawczyk_affine_residuals > "$s/logs/oracle-default" 2>&1
cargo clippy --locked -p hypersolve --all-features --test krawczyk_affine_residuals -- -D warnings > "$s/logs/oracle-clippy" 2>&1
cargo fmt --all -- --check > "$s/logs/fmt" 2>&1
export CARGO_TARGET_DIR="$s/release"
cargo test --locked -p hypersolve --all-features --release --test krawczyk_affine_residuals --message-format=json > "$s/logs/oracle-release.jsonl" 2>"$s/logs/oracle-release"
