from pathlib import Path
import hashlib,io,json,tarfile,shutil,subprocess as sp,importlib.util
s=Path(__file__).parent; repo=Path.cwd();other=repo.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-affine-proof-replay'
def git(*args):return sp.check_output(['git','-C',other,*args])
assert not git('status','--porcelain')
archive=s/'archive';archive.mkdir()
files={}
for p in s.iterdir():
 if p.is_file() and p.suffix not in ('.rs',):files[p.name]=p
for p in (s/'history').rglob('*'):
 if p.is_file() and not str(p.relative_to(s)).startswith('history/logs/requal/'):
  files[str(p.relative_to(s))]=p
for n in ('krawczyk_elimination.rs','krawczyk_proof_policy.rs'):files[n]=s/'history/logs/requal'/n
for p in (s/'logs').iterdir():
 if p.is_file():files['logs/'+p.name]=p
for d in ('entry-quiet','entry-confirmation','affine-quiet','affine-confirmation','affine-owner'):
 for p in (s/d).rglob('*.json'):
  if p.parent.name=='new':files[str(p.relative_to(s))]=p
files['krawczyk_affine_residuals.rs']=repo/'crates/hypersolve/tests/krawczyk_affine_residuals.rs'
sha=lambda b:hashlib.sha256(b).hexdigest()
digests={}
with tarfile.open(archive/'observations.tar.xz','w:xz',preset=6) as tar:
 for n,p in sorted(files.items()):
  b=p.read_bytes(); i=tarfile.TarInfo(n);i.size=len(b);tar.addfile(i,io.BytesIO(b));digests[n]=sha(b)
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {i.name:sha(tar.extractfile(i).read()) for i in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record); git('add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive affine proof requalification, original-equation oracle and paired resource evidence')
rev=git('rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git('show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',repo/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=repo/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1],len(digests))
