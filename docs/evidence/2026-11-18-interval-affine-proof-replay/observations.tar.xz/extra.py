import ast
import hashlib
import json
import statistics
from pathlib import Path
s=Path(__file__).parent
images={p.name:dict(size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted((s/'images').iterdir()) if p.is_file()}
(s/'images.json').write_text(json.dumps(images,indent=2)+'\n')
summary={}
for v in ['primary','affine']:
 rows={}
 for i in range(1,13):
  l=(s/'logs'/f'{v}-usable-{i}').read_text().splitlines()
  assert len(l)==60
  for line in l:
   j,a,b=line.split('|');req,usable=map(ast.literal_eval,(a,b))
   assert req[-1]==usable[-1]==0
   rows.setdefault(int(j),[]).append((req,usable))
 rss=[int((s/'logs'/f'{v}-rss-{i}').read_text().split()[0]) for i in range(1,13)]
 summary[v]={'per_workload':{i:[list(dict.fromkeys(a for a,b in vals)),list(dict.fromkeys(b for a,b in vals))] for i,vals in rows.items()},'max_requested':max(a[-2] for vals in rows.values() for a,b in vals),'max_usable':max(b[1] for vals in rows.values() for a,b in vals),'rss_KiB':rss}
(s/'usable-rss.json').write_text(json.dumps(summary,indent=2)+'\n')
for v,r in summary.items():print(v,r['max_requested'],r['max_usable'],min(r['rss_KiB']),max(r['rss_KiB']))
