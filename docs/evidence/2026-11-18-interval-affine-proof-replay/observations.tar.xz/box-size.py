from pathlib import Path
s=Path(__file__).parent
r=(s/'analyze.py').read_text().replace("[('certification','certification'),('lifetime','regular-native'),('wasm','regular-wasm')]", "[('lifetime','regular-native'),('wasm','regular-wasm')]")
exec(compile(r,'box-size','exec'))
