import os,sys,io,tarfile,hashlib,lzma,json
from pathlib import Path
s=Path(os.environ['s'])
root=Path('/mnt/development/csgrs-evidence/docs/evidence/2026-11-19-interval-affine-prefix-and-proof')
root.mkdir()
members={}
def save(p):
 if not p.is_file() or p.is_symlink():return
 name=str(p.relative_to(s))
 if name in members:return
 data=p.read_bytes()
 if len(data)>1800000: return
 members[name]=data
for pat in ['*.py','*.sh','*.patch','*.json','archived-*.rs','env','contract.md','reproduction.md','*-revision','logs/*','images.sha256','prior-archives.sha256','*/all-build.log','*/Cargo.lock','*/Cargo.toml','pair/src/*.rs','pair/Cargo.*','*/all-accounted.json','*/all-features.json','wasi-final/report.json','wasi-final/*.children','time-entry-*/*/run.log']:
 for p in s.glob(pat):
  if p.name.endswith('-json') or p.name in ['prior-full-index']:continue
  if p.parent.name in {'all-src','downstream-src','matrix-src','bench-src','templates','confirm-patch'}:continue
  save(p)
# Preserve the integrity of large WASI transcripts without redistributing verbose output.
if (s/'wasi-final/report.json').is_file():
 digest={str(p.relative_to(s/'wasi-final')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((s/'wasi-final').rglob('*')) if p.is_file()}
 members['wasi-final/all-transcript-digests.json']=json.dumps(digest,sort_keys=True,indent=1).encode()
digests={}
with tarfile.open(root/'observations.tar.xz','w:xz',preset=6) as tar:
 for name,data in sorted(members.items()):
  digests[name]=hashlib.sha256(data).hexdigest()
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
(root/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(digests,sort_keys=True,indent=1)+'\n').encode()))
print(len(members),sum(p.stat().st_size for p in root.iterdir()))
