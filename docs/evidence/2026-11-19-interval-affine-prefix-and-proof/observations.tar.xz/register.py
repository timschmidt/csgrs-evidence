import io,sys,subprocess,hashlib,tarfile,lzma,json
from pathlib import Path
repo=Path('/mnt/development/csgrs-evidence');name='docs/evidence/2026-11-19-interval-affine-prefix-and-proof'
rev=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
show=lambda path:subprocess.check_output(['git','-C',repo,'show',f'{rev}:{name}/{path}'])
want=json.loads(lzma.decompress(show('members.sha256.json.xz')))
got={}
with tarfile.open(fileobj=io.BytesIO(show('observations.tar.xz')),mode='r:xz') as tar:
 for entry in tar:
  assert entry.isfile() and entry.name not in got
  got[entry.name]=hashlib.sha256(tar.extractfile(entry).read()).hexdigest()
assert want==got
sys.path.insert(0,str(Path('scripts').resolve()))
import evidence_archive as e
e.ROOTS={name:False};header,row=e.manifest(repo,rev)
path=Path('docs/evidence-archive.tsv');assert name not in path.read_text()
with path.open('a') as f:f.write(row+'\n')
print(rev,len(got),row)
