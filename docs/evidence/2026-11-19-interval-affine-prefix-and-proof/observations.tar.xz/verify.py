import os,json,re,hashlib
from pathlib import Path
s=Path(os.environ['s']);l=s/'logs';out={}
def report(name):return json.loads((s/name).read_bytes())
for name in ['base','entry','owned','tail','root','pivot','normalize','borrow']:
 if name!='base':
  assert (l/(name+'-trace')).read_bytes()==(l/'base-trace').read_bytes()
  assert (l/(name+'-client-1')).read_bytes()==(l/'base-client-1').read_bytes()
 assert len((l/(name+'-trace')).read_text().splitlines())==30
 assert len((l/(name+'-client-1')).read_text().splitlines())==252
 assert '240 ordered calls' in (l/(name+'-wasm-ordinary')).read_text()
 guest=(l/(name+'-wasm-stress')).read_text().splitlines();assert len(guest)==48
 assert all(int(row.split()[4])==(1 if name=='base' and int(row.split()[2]) and int(row.split()[3]) in [0,3] else 2) for row in guest)
 if name=='base':continue
 image=report(name+'-sizes.json');mem=report(name+'-memory.json')
 assert len(image)==8 and len(mem['lifetime'])==180 and len(mem['stress-life'])==36
 out[name]={'sizes_over':[(n,m,v['delta']) for n,art in image.items() for m,v in art['metrics'].items() if not v['incremental'] or (v['delta']>0 and not v['cumulative_pass'])],'lifetime_failures':sum(not r['passes'] for r in mem['lifetime']),'stress_failures':sum(not r['passes'] for r in mem['stress-life']),'max_heap':max(r['candidate'][-2] for group in mem.values() for r in group if r['key'][0]=='heap'),'max_stack':max(r['candidate'] for group in mem.values() for r in group if r['key'][0]=='stack')}
native=(l/'normalize-owner-tests').read_text()
assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',native)))==1552 and not re.search(r'test result: FAILED',native)
assert '1525 direct WASI tests, 17 native parents with fresh WASI children, 5 native platform tests. 4212 Horner dispatch windows matched native and WASI.' in (l/'normalize-wasi-solver').read_text()
for arch in ('x86_64-unknown-linux-gnu','wasm32-wasip1'):
 for tc in ('1.95.0','stable'):
  k='krawczyk_affine_oracle'
  for tag in ('baseline','exposed','entry','old-oracle-with-lost-prefix','mutant-prefix','prefix'):
   assert k in report(f'matrix-{tag}-{tc}-{arch}.json')
  # This pair was independently confirmed from a second source path.
  x=report('prefix-confirm-'+arch.split('-')[0]+'.json')[tc]['after'];y=report(f'matrix-prefix-{tc}-{arch}.json')[k]
  assert all(x[m]==y[m] for m in ('file','code','functions'))
for name in ('entry','normalize','pivot','borrow'):
 f=('all-budget-review.json' if name=='entry' else name+'-all-budget-review.json')
 assert len(report(f))==33
for file in ('primary-affected','primary-fmt195','primary-fmt199','inventory-tests','prefix-clippy195','prefix-clippy199','prefix-min'):assert (l/file).is_file()
(s/'outcomes.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified four toolchain/target pairs, seven complete client comparisons, ordinary and stress replay, local and WASI suites, and four 33-artifact comparisons.')
