from pathlib import Path
import os,sys,subprocess,json,shutil
from concurrent.futures import ThreadPoolExecutor
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
sys.path.insert(0,str(s/'templates/prior/history'));from sizes import metrics
def job(target):
 arch=target.split('-')[0];temp=s/f'prefix-confirm-{arch}';repo=temp/'repo';temp.mkdir(exist_ok=True)
 first='aaebcb395' if arch=='x86_64' else '7b5fb0fdb'
 out={}
 for stage in ('fixed','before','after'):
  if stage!='after':
   if repo.exists():shutil.rmtree(repo)
   repo.mkdir();rev=first if stage=='fixed' else '6aad6b95f'
   with subprocess.Popen(['git','-C',root,'archive',rev],stdout=subprocess.PIPE) as g:
    subprocess.run(['tar','-xm','-C',repo],stdin=g.stdout,check=True);assert g.wait()==0
  else:subprocess.run(['git','apply',s/'prefix.patch'],cwd=repo,check=True)
  for tc in ('1.95.0','stable'):
   env=os.environ|{'CARGO_NET_OFFLINE':'false','CARGO_TARGET_DIR':str(temp/('target-'+tc)),'CARGO_BUILD_JOBS':'6'}
   if arch=='wasm32':env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/('sysroot-'+tc))
   log=s/'logs'/f'prefix-confirm-{arch}-{tc}-{stage}'
   cmd=['cargo','+'+tc,'test','--release','--locked','--target',target,'-p','hypersolve','--all-features','--test','krawczyk_affine_oracle','--no-run','--message-format=json-render-diagnostics']
   with log.open('w') as f:
    raw=subprocess.check_output(cmd,cwd=repo,env=env,stderr=f,text=True)
    names=[Path(x['executable']) for x in map(json.loads,raw.splitlines()) if x.get('executable')];assert len(names)==1
    exe=names[0];run=([s/'node',root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'] if arch=='wasm32' else [])+[exe,'--test-threads=1']
    result=subprocess.check_output(run,cwd=repo,stderr=f,text=True);f.write(result);assert '1 passed; 0 failed;' in result
   out.setdefault(tc,{})[stage]=metrics(exe)
   (s/f'prefix-confirm-{arch}.json').write_text(json.dumps(out,indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(job,['x86_64-unknown-linux-gnu','wasm32-wasip1']))
