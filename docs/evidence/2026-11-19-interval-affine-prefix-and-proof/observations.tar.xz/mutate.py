from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
i=s.index('AffineKrawczykStatus::RootOutsideBox {',s.index('pub fn certify_affine_krawczyk_box'));j=s.index('            None =>',i)
part=s[i:j];assert part.count('                    steps,')==1
p.write_text(s[:i]+part.replace('                    steps,','                    Vec::new(),')+s[j:])
