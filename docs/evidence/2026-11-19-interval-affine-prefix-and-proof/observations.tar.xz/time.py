from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,subprocess,os,json,statistics,random
s=Path(os.environ['s']);candidate=sys.argv[1];imgs=s/'images'
names=['certify_affine_krawczyk_box','certify_multivariate_quadratic_krawczyk_square/1','certify_univariate_quadratic_krawczyk_rows']
def run(job):
 cpu,offset=job;p=s/f'time-{candidate}-{cpu}';p.mkdir(exist_ok=True);out={}
 for target in names:
  rows=[]
  for i,tag in enumerate(([candidate,'base','base',candidate] if offset else ['base',candidate,candidate,'base'])*2):
   home=p/(target.replace('/','-')+str(i));home.mkdir(exist_ok=True)
   cmd=['setarch',os.uname().machine,'-R','taskset','-c',str(cpu),str(imgs/(tag+'-owner')),'--bench','--noplot','--warm-up-time','0.5','--measurement-time','1.25','--sample-size','30','^'+target+'$']
   with (home/'run.log').open('w') as f:subprocess.run(cmd,env=os.environ|{'CRITERION_HOME':str(home)},stdout=f,stderr=subprocess.STDOUT,check=True)
   estimates=list(home.glob('**/new/estimates.json'));assert len(estimates)==1,(target,home,estimates)
   rows.append((tag,json.loads(estimates[0].read_text())['median']['point_estimate']))
  delta=100*(statistics.median(v for k,v in rows if k==candidate)/statistics.median(v for k,v in rows if k=='base')-1)
  out[target]={'samples':rows,'median_change_percent':delta}
  (s/f'time-{candidate}-{cpu}.json').write_text(json.dumps(out,indent=2)+'\n')
  print(cpu,target,round(delta,4),flush=True)
with ThreadPoolExecutor(2) as ex:list(ex.map(run,[(7,False),(17,True)]))
