from pathlib import Path
import os,json
s=Path(os.environ['s']);out={}
for arch in ('x86_64','wasm32'):
 tgt='x86_64-unknown-linux-gnu' if arch=='x86_64' else 'wasm32-wasip1'
 for tc,stages in json.loads((s/f'prefix-confirm-{arch}.json').read_bytes()).items():
  hist=json.loads((s/f'matrix-prefix-{tc}-{tgt}.json').read_bytes())['krawczyk_affine_oracle']
  c=stages['after'];f=stages['fixed'];b=stages['before']
  d={}
  for m in ('file','code','functions'):
   carry=max(0,b[m]-f[m])
   if (arch,tc,m)==('x86_64','1.95.0','file'):carry=max(carry,b[m]-4320048)
   delta=c[m]-b[m];inc=max(0,delta);cum=carry+inc
   sn=min(4096,b[m]*5//1000)-inc;cn=min(32768,f[m]*15//1000)-cum;assert min(sn,cn)>=0
   d[m]=dict(fixed=f[m],previous=b[m],retained=c[m],delta=delta,prior_charge=carry,cumulative=cum,step_headroom=sn,cumulative_headroom=cn,independent_previous=json.loads((s/f'matrix-baseline-{tc}-{tgt}.json').read_bytes())['krawczyk_affine_oracle'][m],independent_retained=hist[m])
  assert 67108864-c['file']>=16777216
  print(tc,tgt,'final',c['file'],'deltas',[d[m]['delta'] for m in d],'cumulative',[d[m]['cumulative'] for m in d])
  out[tc+' '+tgt]={'metrics':d,'fixed_revision':'aaebcb395' if arch=='x86_64' else '7b5fb0fdb','slot_headroom':67108864-c['file'],'fixed_previous_retained_sha256':[v['sha256'] for v in [f,b,c]],'independent_retained_sha256':hist['sha256']}
(s/'prefix-accounts.json').write_text(json.dumps(out,indent=2)+'\n')
