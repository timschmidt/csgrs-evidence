set -eu
tag=$1
CARGO_NET_OFFLINE=false bash "$s/build.sh" "$tag" native >"$s/logs/$tag-native" 2>&1 &
native=$!
CARGO_NET_OFFLINE=false bash "$s/build.sh" "$tag" wasm >"$s/logs/$tag-wasm" 2>&1 &
wasm=$!
cargo +1.95.0 build --locked --release -p hypersolve --all-features --bench certification --message-format=json-render-diagnostics >"$s/logs/$tag-owner-json" 2>"$s/logs/$tag-owner" &
owner=$!
rc=0
for pid in $native $wasm $owner; do wait "$pid" || rc=1; done
test "$rc" = 0
python3 - "$tag" <<'PY'
from pathlib import Path
import sys,json,shutil,os
s=Path(os.environ['s'])
paths=[r["executable"] for r in map(json.loads,(s/'logs'/(sys.argv[1]+'-owner-json')).read_text().splitlines()) if r.get("executable")]
assert len(paths)==1
shutil.copy2(paths[0],s/'images'/(sys.argv[1]+'-owner'))
PY
"$s/images/$tag-observer" > "$s/logs/$tag-trace"
python3 "$s/probes.py" "$tag" > "$s/logs/$tag-probes" 2>&1
