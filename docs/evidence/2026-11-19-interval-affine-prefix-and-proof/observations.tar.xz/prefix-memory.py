from pathlib import Path
import os,sys,subprocess,json,resource
s=Path(os.environ['s']);arch=sys.argv[1];t='wasm32-wasip1' if arch=='wasm32' else 'x86_64-unknown-linux-gnu';d=s/f'prefix-confirm-{arch}';repo=d/'repo';assert all('after' in x for x in json.loads((s/f'prefix-confirm-{arch}.json').read_bytes()).values())
test=repo/'crates/hypersolve/tests/krawczyk_affine_oracle.rs';retained=test.read_bytes();out={};fixed=Path('/mnt/development/csgrs')
for stage in ('before','after'):
 test.write_bytes(subprocess.check_output(['git','-C',fixed,'show','6aad6b95f:crates/hypersolve/tests/krawczyk_affine_oracle.rs']) if stage=='before' else retained)
 for tc in ('1.95.0','stable'):
  env=os.environ|{'CARGO_TARGET_DIR':str(d/('target-'+tc))}
  if arch=='wasm32':env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/('sysroot-'+tc))
  raw=subprocess.check_output(['cargo','+'+tc,'test','--locked','--release','--all-features','-p','hypersolve','--test','krawczyk_affine_oracle','--target',t,'--no-run','--message-format=json-render-diagnostics'],cwd=repo,env=env,text=True)
  exe=next(r['executable'] for r in map(json.loads,raw.splitlines()) if r.get('executable'))
  cmd=([s/'node',fixed/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'] if arch=='wasm32' else [])+[exe,'--test-threads=1']
  peaks=[]
  for rep in range(7):
   log=d/'rss-run.log'
   with log.open('w') as stream:
    c=subprocess.Popen(cmd,env=env,cwd=repo,stdout=stream,stderr=stream);_,status,usage=os.wait4(c.pid,0);c.returncode=os.waitstatus_to_exitcode(status)
   assert c.returncode==0 and '1 passed; 0 failed;' in log.read_text()
   peaks.append(usage.ru_maxrss*1024)
  out.setdefault(tc,{})[stage]=peaks
(s/f'prefix-rss-{arch}.json').write_text(json.dumps(out,indent=2)+'\n')
