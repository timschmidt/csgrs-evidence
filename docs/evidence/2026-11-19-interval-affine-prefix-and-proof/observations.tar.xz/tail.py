from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
i=s.index('        let pivot_tail = matrix[pivot][pivot..].to_vec();')
j=s.index('    }\n    Ok(())',i)
old=s[i:j]
new=old.replace('let pivot_tail = matrix[pivot][pivot..].to_vec();','''let (above, from_pivot) = matrix.split_at_mut(pivot);
        let (pivot_row, below) = from_pivot.split_first_mut().expect("pivot is in the matrix");
        let pivot_tail = &pivot_row[pivot..];''')
new=new.replace('''for row in 0..n {
            if row == pivot {
                continue;
            }
            let factor = matrix[row][pivot].clone();''','''for (index, row) in above.iter_mut().enumerate().chain((pivot + 1..).zip(below)) {
            let factor = row[pivot].clone();''').replace('matrix[row].iter_mut().skip(pivot).zip(&pivot_tail)','row.iter_mut().skip(pivot).zip(pivot_tail)').replace('rhs[row]', 'rhs[index]')
p.write_text(s[:i]+new+s[j:])
