from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs')
s=p.read_text()
old='''    let step = match solve_exact_linear_system(matrix, rhs, policy) {
        Ok(step) => step,
        Err(status) => {
            return affine_krawczyk_report(status, variable_count, variable_count, Vec::new());
        }
    };'''
new='''    let step = match solve_exact_linear_system(matrix, rhs, policy) {
        Ok(step) => step,
        Err(pivot) => {
            return affine_krawczyk_report(
                AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot },
                variable_count,
                variable_count,
                Vec::new(),
            );
        }
    };'''
assert old in s;s=s.replace(old,new)
old=''') -> Result<Vec<Real>, AffineKrawczykStatus> {
    solve_exact_linear_system_raw(&mut matrix, &mut rhs, policy)
        .map_err(|pivot| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot })
}'''
new=''') -> Result<Vec<Real>, usize> {
    gauss_jordan::<true>(&mut matrix, &mut rhs, policy)?;
    Ok(rhs)
}'''
assert old in s;s=s.replace(old,new)
i=s.index('fn solve_exact_linear_system_raw(');j=s.index('// A scalar RHS',i);s=s[:i]+s[j:]
s=s.replace('let mut matrix = vec![vec![derivative.clone()]];', 'let matrix = vec![vec![derivative.clone()]];').replace('let mut rhs = vec![half_scaled_derivative];','let rhs = vec![half_scaled_derivative];').replace('solve_exact_linear_system_raw(&mut matrix, &mut rhs, PredicatePolicy::STRICT)','solve_exact_linear_system(matrix, rhs, PredicatePolicy::STRICT)').replace('solve_exact_linear_system_raw(\n                &mut [vec![unresolved]],\n                &mut [Real::one()],','solve_exact_linear_system(\n                vec![vec![unresolved]],\n                vec![Real::one()],')
assert 'solve_exact_linear_system_raw' not in s;p.write_text(s)
