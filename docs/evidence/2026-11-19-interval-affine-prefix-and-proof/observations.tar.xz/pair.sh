set -eu
cd "$w/bench-src"
for v in base entry owned; do
 git -C /mnt/development/csgrs show 6aad6b95f:crates/hypersolve/src/interval.rs > crates/hypersolve/src/interval.rs
 if test "$v" != base;then git apply "$w/$v.patch";fi
 CARGO_TARGET_DIR="$w/pair-target" cargo +1.95.0 build --release --manifest-path "$w/pair/Cargo.toml" > "$w/logs/$v-pair" 2>&1
 cp "$w/pair-target/release/libmatched_proof.so" "$w/images/$v-pair.so"
done
