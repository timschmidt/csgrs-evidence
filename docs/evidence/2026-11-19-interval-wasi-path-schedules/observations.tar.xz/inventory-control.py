import os,re,json
from pathlib import Path
s=Path(os.environ['s'])
reports={}
for tc in ('stable','1.95.0'):
 names=lambda p: set(re.findall(r'^test (\S+) \.\.\. ok$',p.read_text(),re.M))
 old=names(s/f'logs/interface-standard-{tc}')
 new=names(s/f'logs/iface-runner-{tc}')
 assert len(old)==196 and len(new)==199 and old<new
 assert {n.split('::')[-1] for n in new-old}=={'lowered_package_executes_in_the_portable_split_runtime','lowered_tinybee_input_executes_in_the_firmware_actor_types','lowered_tinybee_pair_executes_both_reads_in_the_firmware_actor_types'}
 reports[tc]=dict(common_cases=sorted(old),added_cases=sorted(new-old))
(s/'interface-comparison.json').write_text(json.dumps(reports,indent=2)+'\n')
