set -eu
tc=$1
export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-$tc" CARGO_TARGET_DIR="$s/target-$tc" CARGO_BUILD_JOBS=8
bash "$s/native.sh" "$tc" after
cmp "$s/before-native-$tc.json" "$s/after-native-$tc.json"
cmp "$s/logs/before-native-tree-$tc" "$s/logs/after-native-tree-$tc"
python3 crates/hyperinterval/conformance/wasi-path.py --toolchain "$tc" --output "$s/final-$tc"
for target in x86_64-unknown-linux-gnu wasm32-wasip1;do
 cargo +"$tc" clippy --release -p hyperpath --all-features --all-targets --locked --target "$target" -- -D warnings > "$s/logs/lint-$tc-$target" 2>&1
done
cargo +"$tc" build --locked --release --all-features -p hyperpath --bench path_predicates --target wasm32-wasip1 --message-format=json-render-diagnostics > "$s/logs/bench-$tc.jsonl"
image=$(python3 -c "import sys,json;print(next(r['executable'] for r in map(json.loads,sys.stdin) if r.get('executable')))" < "$s/logs/bench-$tc.jsonl")
node crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$image" --test > "$s/logs/bench-smoke-$tc" 2>&1
RUSTDOCFLAGS="-D warnings" cargo +"$tc" doc --release --locked -p hyperpath --all-features --no-deps > "$s/logs/docs-$tc" 2>&1
