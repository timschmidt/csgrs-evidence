import { readFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { WASI } from "node:wasi";

const [directory, ...args] = process.argv.slice(2);
const binary = path.join(directory, "interface_bg.wasm");
const glue = await import(pathToFileURL(path.join(directory, "interface_bg.js")));
const wasi = new WASI({version: "preview1", args: [binary, ...args], returnOnExit: true});
const module = await WebAssembly.compile(await readFile(binary));
const instance = await WebAssembly.instantiate(module, {
    ...wasi.getImportObject(),
    "./interface_bg.js": glue,
});
glue.__wbg_set_wasm(instance.exports);
if (instance.exports.__wbindgen_start) instance.exports.__wbindgen_start();
process.exitCode = wasi.start(instance);
