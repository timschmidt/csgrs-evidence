set -eu
python3 "$s/validate.py"
python3 "$s/archive.py"
record=docs/evidence/2026-11-19-interval-wasi-path-schedules
git -C ../csgrs-evidence add --sparse -- "$record"
git -C ../csgrs-evidence -c gc.auto=0 commit -m "Archive native and WASI path schedule and Interface actor qualification"
archive_revision=$(git -C ../csgrs-evidence rev-parse HEAD)
python3 - "$record" "$archive_revision" <<'PY'
from pathlib import Path
import hashlib,importlib.util,io,json,lzma,subprocess,sys,tarfile
record,sha=sys.argv[1:]
repo='../csgrs-evidence'
show=lambda file:subprocess.check_output(['git','-C',repo,'show',sha+':'+record+'/'+file])
hashes=json.loads(lzma.decompress(show('members.sha256.json.xz')))
with tarfile.open(fileobj=io.BytesIO(show('observations.tar.xz'))) as t:
 assert {f.name:hashlib.sha256(t.extractfile(f).read()).hexdigest() for f in t}==hashes
spec=importlib.util.spec_from_file_location('evidence_archive','scripts/evidence_archive.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
a.ROOTS={record: False}
rows=a.manifest(repo,sha)
assert len(rows)==2 and rows[1].startswith(record+'\t2\t')
p=Path('docs/evidence-archive.tsv')
assert record not in p.read_text()
with p.open('a') as f:print(rows[1],file=f)
PY
python3 "$s/update-docs.py" "$archive_revision"
git diff --check
