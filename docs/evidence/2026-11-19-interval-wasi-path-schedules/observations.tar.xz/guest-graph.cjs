const fs = require('node:fs');
const m = new WebAssembly.Module(fs.readFileSync(process.argv[2]));
console.log(JSON.stringify(WebAssembly.Module.exports(m).map(({name})=>({name,export:name,...(['memory','_start'].includes(name) ? {root:true} : {})}))));
