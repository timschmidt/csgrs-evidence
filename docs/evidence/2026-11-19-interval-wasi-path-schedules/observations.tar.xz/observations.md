# Portable schedule and firmware actor controls

The two targets are the native x86_64 Linux host and wasm32-wasip1 with
Node 24.22.3, Rust 1.95.0 and 1.99.0, release mode, one libtest thread.
The run used a private Cargo home and private target, sysroot and temporary
directories on the development volume. There are no binary or dependency
caches in this record. The toolchain identities are in toolchain-*.txt.

## Hyperpath

The first five suites, shipped example and path_predicates benchmark were
built on the preceding and candidate revisions with native.sh. Compare the
before/after native file hashes and feature-tree logs separately within
each compiler. qualify.sh runs the checked-in suite comparator, Clippy,
rustdoc and the actual guest Criterion smoke executable. Each final-* folder
contains all five native and guest logs, the case inventory and the example
result. package.sh was run in two independent clean checkouts of the
committed snapshot. final-packaged.py compiled and executed the shipped
example from unpacked archives on both targets. The generated consumer's
lockfile and manifest identify the active dependency closure. Cargo also
reported two unused optional local patches. The initial pre-commit .crate
and committed .crate differ in VCS metadata and nested archive checksums.
The two clean committed packages match byte for byte on each compiler.

## Alumina Interface

The baseline compile used the unmodified core at f8837074 and the same csgrs
and firmware checkouts as the candidate. The naked module requires normal
wasm-bindgen imports, including after eliminating unreferenced process exports.
In both revisions the actual command was generated as follows.

```sh
wasm-bindgen --target bundler --no-typescript --out-name interface --out-dir "$out" "$linked_test_wasm"
node bundled-command.mjs "$out" --test-threads=1
```

For each compiler the final tree also ran scripts/check-wasi-core.sh as
checked in, the complete native release core test suite, and strict core
Clippy with --lib --tests --no-deps on native, browser and WASI. The stable
compiler additionally ran the guest suite with the exact two sibling
revisions in the Interface deployment workflow. The runner supplies the
generated binding exports and the WASI import object. Tests use their
original assertions and real firmware actor types.

The interface-scope.md predeclared file/code/function caps, command capacity
and stack reserve. interface-baseline.py measured the originally linked test
and the final generated command. There are no production-source or firmware
image edits. For both revisions run-stack.py and stack.mjs cover a complete
fresh preview1 command, libtest and fixture destruction. The two byte patterns
use a verified 1 MiB guest stack below static data. The 196- and 199-test
suites exercise different functionality, and the three named new calls have
no prior WASI execution. The diagonal fixture is the identical workload
common to both. Ending linear-memory extent is monotonic in each instance.
Allocator-level peaks and host/Node stack usage were not measured. These
hosted observations do not qualify a board partition, cycle budget or the
pending solver ownership migration.

Stable Rust emitted the pre-existing alumina-runtime Atomic::fetch_update
deprecation in both the original and expanded guest builds. The Interface
owner passed strict Clippy on all three tested targets. The audits of both
repositories used zizmor 1.32.0 in its default offline mode.
A manual copy in the pinned scratch checkout initially retained the old
0644 mode on the local Node runner. Cargo correctly refused to execute it.
Restoring both scripts from the committed Git tree supplied their recorded
100755 modes. The pinned-inventory log records the rerun.
