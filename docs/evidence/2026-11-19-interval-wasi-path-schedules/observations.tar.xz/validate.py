from pathlib import Path
import json,re,os
s=Path(os.environ['s'])
for tc in ('1.95.0','stable'):
 log=lambda name:(s/f'logs/{name}').read_text()
 h=json.loads((s/f'final-{tc}/report.json').read_text())
 assert sum(len(v) for v in h['suites'].values())==446
 for suite,cases in h['suites'].items():
  for arch in ('native','wasi'):
   out=(s/f'final-{tc}/{suite}-{arch}.log').read_text()
   assert set(re.findall(r'^test (\S+) \.\.\. ok$',out,re.M))==set(cases)
 assert len(re.findall(r'^Success$',log('bench-smoke-'+tc),re.M))==194
 for item in ('iface-check-','iface-native-','iface-runner-'):
  out=log(item+tc)
  assert '199 passed; 0 failed; 0 ignored' in out
  if item=='iface-check-':assert 'Full inventories matched' in out
 for target in ('x86_64-unknown-linux-gnu','wasm32-wasip1','wasm32-unknown-unknown'):
  assert 'Finished' in log('iface-clippy-'+tc+'-'+target)
 assert 'native Certified join feed 2' in log('packaged-clean-'+tc) and 'wasi Certified join feed 2' in log('packaged-clean-'+tc)
 assert log('before-native-tree-'+tc)==log('after-native-tree-'+tc)
 assert (s/f'before-native-{tc}.json').read_bytes()==(s/f'after-native-{tc}.json').read_bytes()
 assert 'No findings' in log('iface-final-audit') and 'No findings' in log('final-audit')
assert 'Full inventories matched' in (s/'logs/pinned-inventory').read_text()
