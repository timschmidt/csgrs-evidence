from pathlib import Path
import os,hashlib,json,struct,io,sys
s=Path(os.environ['s'])
def leb(f):
 v=shift=0
 while True:
  c=f.read(1)[0];v|=(c&127)<<shift
  if c<128:return v
  shift+=7
def metrics(p):
 b=p.read_bytes();data={'file':len(b),'sha256':hashlib.sha256(b).hexdigest()};f=io.BytesIO(b);f.read(8)
 while k:=f.read(1):
  section=f.read(leb(f))
  if k==b'\x0a':
   inner=io.BytesIO(section);n=leb(inner);size=0
   for _ in range(n):
    length=leb(inner);size+=length;inner.seek(length,1)
   assert not inner.read()
   data.update(code=len(section),bodies=size)
 return data
if __name__=='__main__':
 tag=sys.argv[1];tables={}
 for tc in ['1.95.0','stable']:
  raw=next((s/f'target-{tc}/wasm32-wasip1/release/deps').glob('alumina_interface_core-*.wasm'))
  tables[tc]={label:metrics(p) for label,p in [('linked',raw),('command',s/f'bundler-{tc}/interface_bg.wasm')]}
 (s/f'interface-{tag}.json').write_text(json.dumps(tables,indent=2)+'\n')
