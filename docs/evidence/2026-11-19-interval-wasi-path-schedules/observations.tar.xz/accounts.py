import os,json,runpy,tarfile,hashlib
from pathlib import Path
s=Path(os.environ['s'])
metrics=runpy.run_path(str(s/'interface-baseline.py'))['metrics']
get=lambda p:json.loads(p.read_text())
baseline=get(s/'interface-before.json')
after=get(s/'interface-candidate.json')
accounts={}
for tc in ('stable','1.95.0'):
 paths={}
 for group in ('guest','bench'):
  for r in map(json.loads,(s/f'logs/{group}-{tc}.jsonl').read_text().splitlines()):
   if r.get('executable'): paths[r['target']['name']]=Path(r['executable'])
 paths['certified_schedule']=s/f'target-{tc}/wasm32-wasip1/release/examples/certified_schedule.wasm'
 assert len(paths)==7
 new={target:metrics(p) for target,p in paths.items()}
 assert all(a['file']<=48*1024**2 for a in new.values())
 for info in new.values(): info['remaining_slot']=64*1024**2-info['file']
 expanded={}
 for name,c in after[tc].items():
  b=baseline[tc][name]
  d={k:c[k]-b[k] for k in ('file','code','bodies')}
  assert all(d[k]<=131072 and d[k]*100<=b[k]*2 for k in d)
  assert c['file']<=48*1024**2
  expanded[name]=dict(baseline=b,current=c,incremental_and_cumulative=d,remaining_slot=64*1024**2-c['file'])
 assert (s/f'before-native-{tc}.json').read_bytes()==(s/f'after-native-{tc}.json').read_bytes()
 def contents(tag):
  with tarfile.open(s/f'hyperpath-{tag}-{tc}.crate') as t:
   return {f.name:hashlib.sha256(t.extractfile(f).read()).hexdigest() for f in t if f.isfile() and not f.name.endswith(("/.cargo_vcs_info.json","/Cargo.lock"))}
 assert contents('candidate')==contents('clean')
 assert (s/f'hyperpath-clean-{tc}.crate').read_bytes()==(s/f'hyperpath-committed-{tc}.crate').read_bytes()
 accounts[{'stable':'1.99.0','1.95.0':'1.95.0'}[tc]]=dict(hyperpath=new,alumina_interface=expanded)
(s/'accounts.json').write_text(json.dumps(accounts,indent=2)+'\n')
