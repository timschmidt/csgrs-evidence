import json,os,shutil,subprocess,sys,tarfile,tomllib
from pathlib import Path
s=Path(os.environ['s']);tc=sys.argv[1]
packages=s/f'accepted-{tc}';packages.mkdir();client=packages/'client';(client/'src').mkdir(parents=True)
patches=[]
for archive in sorted((s/f'pkg-{tc}/package').glob('*.crate')):
 with tarfile.open(archive) as t:t.extractall(packages,filter='data')
 d=packages/archive.stem
 meta=tomllib.loads((d/'Cargo.toml').read_text())['package']
 patches.append(meta['name']+' = { path = "../'+d.name+'" }')
 if meta['name']=='hyperpath':shutil.copyfile(d/'examples/certified_schedule.rs',client/'src/main.rs')
(client/'Cargo.toml').write_text('[workspace]\n[package]\nname="published-schedule"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nhyperpath="=0.3.0"\nhyperreal="=0.14.0"\nhyperlimit="=0.5.0"\n[patch.crates-io]\n'+'\n'.join(patches)+'\n')
env=os.environ | {'CARGO_TARGET_DIR':str(s/f'package-client-{tc}'),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':f'--sysroot {s}/sysroot-{tc}'}
base=['cargo','+'+tc]; out={}
subprocess.run([*base,'generate-lockfile','--offline'],cwd=client,env=env,check=True)
for name,args in [('native',[]),('wasi',['--target','wasm32-wasip1','--config','target.wasm32-wasip1.runner=["node", "/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs"]'])]:
 out[name]=subprocess.check_output([*base,'run','--release','--offline','--locked',*args],cwd=client,env=env)
 expected=(s/f'path-{tc}/certified_schedule.log').read_bytes();assert out[name]==expected
 print(name, out[name].decode())
