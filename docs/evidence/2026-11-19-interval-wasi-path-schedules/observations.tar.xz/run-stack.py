import subprocess,itertools,os,json,concurrent.futures
from pathlib import Path
s=Path(os.environ['s'])
names=['machine_profile::tests::exact_diagonal_g1_uses_dense_axis_projection_and_lowers_to_terminal_steps']+['graph::deployment::tests::'+x for x in ('lowered_package_executes_in_the_portable_split_runtime','lowered_tinybee_input_executes_in_the_firmware_actor_types','lowered_tinybee_pair_executes_both_reads_in_the_firmware_actor_types')]
def run(item):
 tc,build,fill,name=item
 args=['--exact',name] if name else []
 p=subprocess.run(['node',s/'stack.mjs',s/f'{build}-{tc}',str(fill),'--test-threads=1',*args],text=True,capture_output=True)
 if p.returncode or ('1 passed;' if name else ('199 passed;' if build=='bundler' else '196 passed;')) not in p.stdout: raise ValueError((item,p.stderr,p.stdout[-3000:]))
 return dict(tc=tc,build=build,**json.loads(p.stdout.splitlines()[-1]))
items=[(tc,b,f,n) for tc,b,f in itertools.product(('1.95.0','stable'),('control','bundler'),(90,165)) for n in (['',*names] if b=='bundler' else ['',names[0]])]
with concurrent.futures.ThreadPoolExecutor(8) as pg:
 out=list(pg.map(run,items))
(s/'interface-stack.json').write_text(json.dumps(out,indent=2)+'\n')
