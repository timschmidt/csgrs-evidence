set -eu
tc=$1
raw=$(find "$s/target-$tc/wasm32-wasip1/release/deps" -name 'alumina_interface_core-*.wasm' -print -quit)
node "$s/guest-graph.cjs" "$raw" > "$s/$tc-graph.json"
BINARYEN_CORES=4 wasm-metadce "$raw" --all-features -f "$s/$tc-graph.json" -o "$s/interface-$tc.wasm" > "$s/logs/dce-$tc" 2>&1
node -e 'let m=new WebAssembly.Module(require("node:fs").readFileSync(process.argv[1]));console.log(JSON.stringify({imports:WebAssembly.Module.imports(m),exports:WebAssembly.Module.exports(m)}));' "$s/interface-$tc.wasm" > "$s/interface-$tc-imports.json"
node crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$s/interface-$tc.wasm" --test-threads=1 > "$s/logs/interface-command-$tc" 2>&1
