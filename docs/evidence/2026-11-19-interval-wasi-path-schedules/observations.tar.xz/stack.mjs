import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { WASI } from "node:wasi";

const [directory, fillInput, ...args] = process.argv.slice(2);
const binary = path.join(directory, "interface_bg.wasm");
const glue = await import(pathToFileURL(path.join(directory, "interface_bg.js")));
const wasi = new WASI({version: "preview1", args: [binary, ...args], returnOnExit: true});
const fill = Number(fillInput);
const bytes = await readFile(binary);
let pos = 8;
function nat() {
  let value = 0, shift = 0, byte;
  do {byte = bytes[pos++]; value += (byte & 127) * 2 ** shift; shift += 7;} while (byte & 128);
  return value;
}
function address() {
  assert.equal(bytes[pos++], 0x41);
  const value = nat();
  assert.equal(bytes[pos++], 0xb);
  return value;
}
let top, lowestData = Infinity;
while (pos < bytes.length) {
  const kind = bytes[pos++], length = nat(), end = pos + length;
  if (kind === 6) {
    assert(nat() >= 1);
    assert.equal(bytes[pos++], 0x7f);
    assert.equal(bytes[pos++], 1);
    top = address();
  }
  if (kind === 11) {
    const count = nat();
    for (let i=0; i<count; i++) {
      assert.equal(nat(), 0);
      lowestData = Math.min(lowestData, address());
      const size = nat(); pos += size;
    }
    assert.equal(pos, end);
  }
  pos = end;
}
assert.equal(top, 1048576);
assert(lowestData >= top && Number.isFinite(lowestData));

const module = await WebAssembly.compile(await readFile(binary));
const instance = await WebAssembly.instantiate(module, {
    ...wasi.getImportObject(),
    "./interface_bg.js": glue,
});
glue.__wbg_set_wasm(instance.exports);
if (instance.exports.__wbindgen_start) instance.exports.__wbindgen_start();
const initial = instance.exports.memory.buffer.byteLength;
const stack = () => new Uint8Array(instance.exports.memory.buffer, 0, top);
stack().fill(fill);
process.exitCode = wasi.start(instance);
const low = stack().findIndex(x => x !== fill);
assert(low >= 262144 && low < top);
console.log(JSON.stringify({args,fill,top,lowestData,stack_bytes:top-low,initial_bytes:initial,linear_bytes:instance.exports.memory.buffer.byteLength}));
