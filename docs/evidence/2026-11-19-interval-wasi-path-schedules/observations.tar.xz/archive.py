import hashlib,io,json,lzma,os,subprocess,tarfile
from pathlib import Path
s=Path(os.environ['s'])
e=Path('/mnt/development/csgrs-evidence')
record='docs/evidence/2026-11-19-interval-wasi-path-schedules'
d=e/record
d.mkdir(exist_ok=False,parents=True)
files={}
for pattern in ('*.sh','*.py','*.cjs','*.mjs','*.md','*.json','logs/*','final-stable/*','final-1.95.0/*'):
 for f in s.glob(pattern):
  if f.is_file(): files[str(f.relative_to(s))]=f.read_bytes()
repos=['csgrs','alumina-interface','alumina-firmware']
files['revisions.txt']=''.join(r+' '+subprocess.check_output(['git','-C','/mnt/development/'+r,'rev-parse','HEAD'],text=True) for r in repos).encode()
files['pinned-revisions.txt']=''.join(r+' '+subprocess.check_output(['git','-C',s/'pins'/r,'rev-parse','HEAD'],text=True) for r in repos[::2]).encode()
for r,patterns in {'csgrs':['crates/hyperinterval/conformance/wasi-path.py','crates/hyperinterval/conformance/wasi_libtest.py','crates/hyperlattice-interval/conformance/run-wasi-test.mjs','.github/workflows/workspace.yml','crates/hyperpath/Cargo.toml'],'alumina-interface':['scripts/run-wasi-core.mjs','scripts/check-wasi-core.sh','.github/workflows/deploy.yml']}.items():
 for path in patterns:files[r+'/'+path]=(Path('/mnt/development')/r/path).read_bytes()
for tc in ['1.95.0','stable']:
 for p in ['Cargo.lock','Cargo.toml','src/main.rs']:
  files['package-client-'+tc+'/'+p]=(s/f'accepted-{tc}/client'/p).read_bytes()
 files['toolchain-'+tc+'.txt']=subprocess.check_output(['rustc','+'+tc,'-Vv'])
hashes={name:hashlib.sha256(b).hexdigest() for name,b in sorted(files.items())}
with tarfile.open(d/'observations.tar.xz','w:xz',preset=5) as archive:
 for name,b in sorted(files.items()):
  f=tarfile.TarInfo(name);f.size=len(b)
  archive.addfile(f,io.BytesIO(b))
with lzma.open(d/'members.sha256.json.xz','wt') as h:json.dump(hashes,h,indent=2)
with tarfile.open(d/'observations.tar.xz') as a:
 assert {m.name:hashlib.sha256(a.extractfile(m).read()).hexdigest() for m in a}==hashes
print(len(hashes),sum(f.stat().st_size for f in d.iterdir()))
