import os,json,subprocess,sys
from pathlib import Path
s=Path(os.environ['s'])
iface=subprocess.check_output(['git','-C','../alumina-interface','rev-parse','HEAD'],text=True).strip()
evidence=sys.argv[1]
def append_entry(file,key,record):
 p=Path('docs/research')/file
 t=p.read_text().rstrip()
 old=json.loads(t)
 assert key not in old and t.endswith('}')
 new=t[:-1].rstrip()+',\n'+json.dumps({key:record},indent=2)[2:]+'\n'
 assert old|{key:record}==json.loads(new)
 p.write_text(new)
accounts=json.loads((s/'accounts.json').read_text())
scope='Hosted single-thread wasm32-wasip1 release test commands. Hyperpath development-only binaries have their first measured baseline here. Interface is compared with the preceding 196-test image on precisely the same dependency revisions. The additions exercise existing firmware actor tests. All native Hyperpath controls match byte for byte.'
key='wasi_path_and_interface_tests_2026_11_19'
refs=dict(csgrs='f345872582c8bbe49a7887b5cfbab490ca59ad6d',interface=iface,interface_baseline='f883707429208e5f2355fb7c9550100235da2fb8',firmware='56c2c28df9fa29ac01d88ed1b67bf70690b73897',evidence=evidence)
append_entry('interval-size-accounts.json',key,dict(scope=scope,revisions=refs,slot_bytes=67108864,minimum_free_bytes=16777216,interface_incremental_cap=dict(bytes=131072,percent=2),interface_cumulative_cap=dict(bytes=262144,percent=4),units='bytes; code is the code section payload, bodies is the sum of defined function body payloads',targets=accounts))
stack=json.loads((s/'interface-stack.json').read_text())
memory={}
for tc,label in [('1.95.0','1.95.0'),('stable','1.99.0')]:
 bywork={}
 for r in stack:
  if r['tc']!=tc: continue
  key2=r['args'][-1] if '--exact' in r['args'] else 'whole_suite'
  dst=bywork.setdefault(key2,{}).setdefault(r['build'],{})
  for metric in ['stack_bytes','initial_bytes','linear_bytes']:
   dst[metric]=max(dst.get(metric,0),r[metric])
 for v in bywork.values():
  v['remaining_stack']=1048576-v['bundler']['stack_bytes']
  if 'control' in v: v['stack_difference']=v['bundler']['stack_bytes']-v['control']['stack_bytes']
 memory[label]=bywork
append_entry('interval-memory-accounts.json',key,dict(scope='Hosted guest test command only. Original 196 cases and the expanded 199 cases are different workloads. The isolated canonical diagonal case is a common completed workload. The three added actor calls have their initial WASI workload baselines here.',revisions=refs,call_boundary='One fresh Node WASI instance, after binding initialization through return from libtest _start, including fixture creation, assertions and teardown. Each named case and full-suite invocation used both 0x5a and 0xa5. Byte-resolution sentinel measures deepest observed guest stack write. Linear memory has 65536-byte pages and does not shrink; its ending extent is not a guest allocator measurement.',stack_capacity_bytes=1048576,minimum_remaining_stack_bytes=262144,targets=memory))
p=Path('INTERVAL_REFACTOR_PROGRESS.md')
t=p.read_text().replace('The two-device shared timer fixture pins the complete evidence bytes and ordered transcript hash.','The two-device shared timer fixture pins the complete evidence bytes and ordered transcript hash. The full 199-case Interface core suite now runs on WASI, including machine-profile replay and TinyBee firmware actors.').replace('public lookahead oracle retained; full extraction','public lookahead oracle and all 446 Hyperpath tests qualified on native and WASI; full extraction').replace('and Hypersolve and Hyperdynamics numerical and fresh-process replay cases locally qualified on WASI Preview 1','Hypersolve and Hyperdynamics numerical and fresh-process replay cases, and Hyperpath and Interface schedules locally qualified on WASI Preview 1')
t+=f"""
## Phase 8, 11 and 14 schedule replay on WASI Preview 1

Hyperpath `f34587258` selects in-process proptest and single-threaded Criterion
for WASI. The preceding revision failed to compile its test suite in
`wait-timeout`. All 446 test names matched across native and WASI and passed
on Rust 1.95 and 1.99. The independent schedule oracle retained its reversal,
edited-feed and certificate assertions. The packaged example certified feed
2 and rejected feed 4 on both targets. All seven native test, example and
benchmark binaries matched the preceding revision byte for byte on each
compiler. Both guest benchmark images completed all 194 smoke cases.

Alumina Interface `{iface[:9]}` supplies the real wasm-bindgen imports and
executes the three previously native-only actor tests on WASI. All 199 core
tests passed on both targets and compilers, including 18 machine-profile
cases and the frozen 41,795-byte planner transcript. The stable WASI run also
passed with the firmware and csgrs revisions pinned for deployment. Each final WASI command
grew by less than 32 KiB. With a 1 MiB guest stack, the largest observed
stack use was 62,992 bytes. Peak linear memory remained 15,400,960 bytes for
the complete suite on each compiler. The canonical diagonal workload retained
its stack use and linear memory extent. Source ownership of the path solver,
the previously measured extraction stack excess, and firmware board timing
remain open. [Size accounts](docs/research/interval-size-accounts.json) ·
[Memory accounts](docs/research/interval-memory-accounts.json)

The complete per-case inventories, execution logs, image and archive hashes,
and two-pattern guest stack measurements are in evidence commit `{evidence}`.
[Evidence index](docs/evidence-archive.tsv)
"""
p.write_text(t)
