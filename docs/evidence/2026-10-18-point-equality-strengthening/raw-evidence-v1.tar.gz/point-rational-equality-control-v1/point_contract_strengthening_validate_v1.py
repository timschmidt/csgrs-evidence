"""Validate the P4 test correction after the report comparison is terminal."""
import hashlib,json,os,re,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');A=N/'point-rational-contract-strengthening-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha
assert not A.exists();A.mkdir()
report=N/'point-rational-inline-facts-report-result-v1.json';assert json.loads(report.read_text())['all_report_bytes_equal']
assert all((p/'result.json').exists() for p in (N/'logs').glob('point-rational-*') if (p/'process.json').exists())
transition=json.loads((W/'point-contract-strengthening-transition-v1.json').read_text());pid=transition['pid'];proc=Path('/proc')/str(pid);state=(proc/'stat').read_text()
assert state.split()[21]==transition['proc_stat'].split()[21] and state.split()[2] in ['T','t']
assert [v.decode() for v in (proc/'cmdline').read_bytes().split(b'\0') if v]==transition['argv']
children={}
for child in (proc/'task'/str(pid)/'children').read_text().split():
    row=(Path('/proc')/child/'stat').read_text();assert row.split()[2]=='Z';children[child]=row
os.kill(pid,signal.SIGKILL)
dump(A/'dispatcher-retirement-v1.json',{'pid':pid,'stat_before':state,'children_terminal_zombies':children,'report_result_sha256':sha(report),'intentional_dispatcher_replacement':True,'signal':'SIGKILL to stopped dispatcher only after report child completion','old_progress_not_updated_after_stop':True,'unix':time.time()})
source=O/'crates/hypercurve/tests/point_equality_contract.rs';overlay=W/'point_equality_contract_v2.rs'
assert sha(source)=='8d25627857b5ba0157f8c9cf4946b36703110ffcb6810800920f9cd5059a9aba' and sha(overlay)=='20258117bca15727e8c1299cfb7e84265b8fe4411c3ba56294eab998a55d43ca'
previous=json.loads((O/'docs/evidence/2026-10-18-point-equality-contracts/checkpoint-v1.json').read_text());live=previous['inherited_implementation_sha256'];assert all(sha(O/p)==h for p,h in live.items())
base=json.loads((N/'point-rational-equality-baseline-v1/result-v1.json').read_text());candidate=json.loads((N/'point-rational-inline-facts-cost-v1/result-v1.json').read_text())
inputs={'baseline':base['libraries'],'candidate':candidate['candidate_libraries']};assert all(sha(v['path'])==v['sha256'] for libs in inputs.values() for v in libs.values())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
commands={};root=Path(compiler['additional_environment']['RUSTC']).parent
source.write_bytes(overlay.read_bytes())
dump(A/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'source_sha256':sha(source),'contract_sha256':sha(W/'point-contract-strengthening-v1.md'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'libraries':inputs,'production_implementation_changed':False,'earlier_test_and_evidence_preserved':True})
def execute(label,args):
    name='point-rational-contract-strengthening-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--chdir',str(O if label=='format' else scratch),'--setenv','TMPDIR',str(scratch)]
    commands[label]=run(name,argv+args,O,wall_seconds=60);return (N/'logs'/name/'stdout').read_text()
execute('format',[str(root/'cargo'),'fmt','--all','--','--check'])
binaries={}
for mode,libs in inputs.items():
    binary=A/(mode+'-point-equality-contract');args=[str(root/'rustc'),'--edition=2024','--test','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary)]
    for directory in sorted({str(Path(v['path']).parent) for v in libs.values()}):args+=['-L','dependency='+directory]
    for name,v in sorted(libs.items()):args+=['--extern',name+'='+v['path']]
    execute(mode+'-compile',args);out=execute(mode+'-run',[str(binary),'--test-threads=1','--nocapture']);assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in out
    binaries[mode]={'path':str(binary),'sha256':sha(binary)}
assert sha(source)==sha(overlay)=='20258117bca15727e8c1299cfb7e84265b8fe4411c3ba56294eab998a55d43ca'
assert all(sha(v['path'])==v['sha256'] for libs in inputs.values() for v in libs.values()) and all(sha(O/p)==h for p,h in live.items())
dump(A/'result-v1.json',{'commands':commands,'source_sha256':sha(source),'binaries':binaries,'libraries':inputs,'tests_per_implementation':3,'test_executions':6,'passed':True,'production_implementation_changed':False,'candidate_optimization_admitted':False})
print('format and corrected point contracts passed on baseline and inline-candidate libraries',flush=True)
