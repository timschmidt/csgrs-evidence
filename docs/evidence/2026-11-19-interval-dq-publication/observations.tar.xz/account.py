from pathlib import Path
import json,sys
w=Path(__file__).parent;r=Path('/mnt/development/csgrs/docs/research')
z=json.loads((w/'sizes.json').read_text())
assert len(z)==4 and all(not a['failed'] for a in z.values())
key='dq_simulator_full_counter'
ref='docs/evidence/2026-11-19-interval-dq-publication'
def read(name):return json.loads((r/name).read_text())
def save(name,d): (r/name).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
name='interval-size-accounts.json';d=read(name)
assert key not in d
block={'scope':'Host-only simulator update and maintained overflow witness. Firmware release profile uses DWARF level 2. Complete unstripped file, allocated sections, executable text, and sum of nonduplicate named code spans were measured.', 'fixed_revisions':{'firmware':'2d68e82','csgrs':'c9f1f9ac5'},'previous_revisions':{'firmware':'35d1b0d','csgrs':'35a176de2'},'retained_firmware':(w/'retained').read_text().strip(),'evidence':ref,'caps':'Existing native file/allocated-section and executable-code schedules. The cap applies separately on each compiler and artifact. Positive fixed-to-previous growth remains charged.', 'artifacts':{}}
for k,v in z.items():
 block['artifacts'][k]={'fixed_previous_retained_sha256':{a:t['sha256'] for a,t in v['stages'].items()},'metrics':{n:t for n,t in v['metrics'].items() if n in ('file','.text','named_code') or t['cumulative_charge']>0},'failed_caps':v['failed']}
d[key]=block;save(name,d)
name='interval-memory-accounts.json';d=read(name)
assert key not in d
obs=json.loads((w/'lifetimes.json').read_text());assert len(obs)==36
block={'scope':'Native simulator unit-test suite and external client making one million accepted and one million rejected public calls. Three fresh full-process group lifetimes per compiler, revision and artifact. Peak includes the Python observer. The counter repair uses existing fields and allocates no heap storage. No on-board stack or memory qualification is claimed.','evidence':ref,'cap_bytes':256<<20,'reserved_bytes':64<<20,'swap_bytes':0,'compiler_artifact_peak_bytes':{}}
for v in ('1.88.0','stable'):
 for a in ('sim','client'):
  peaks={k:max(t['peak_bytes'] for t in obs if t['compiler']==v and t['artifact']==a and t['stage']==k) for k in ('fixed','original','candidate')}
  assert max(peaks.values())<192<<20
  block['compiler_artifact_peak_bytes'][v+'-'+a]=dict(**peaks,remaining_above_reserve=(192<<20)-peaks['candidate'])
heap=json.loads((w/'heap.json').read_text())
frames=json.loads((w/'frames.json').read_text())
block['requested_heap']='glibc libmemusage interposition on the linked executables with a common argv[0]. Three fresh instrumented jobs for each stage. Requested peaks and all recorded malloc, calloc, realloc and free counts and bytes agree. Group peaks include the observer and runtime variability.'
block['requested_heap_accounts']={}
for v in ('1.88.0','stable'):
 for a in ('sim','client'):
  runs=[row for row in heap if (row['compiler'],row['artifact'])==(v,a)]
  assert len(runs)==9
  ref={k:runs[0][k] for k in ('total','peak','calls')}
  assert all(all(row[k]==ref[k] for k in ref) for row in runs)
  block['requested_heap_accounts'][v+'-'+a]=dict(**ref,incremental_positive_bytes=0,cumulative_positive_bytes=0)
block['linked_frame_cfa_bytes']={k:{name:(f['max_CFA_offset'] or None) for name,f in v.items()} for k,v in frames.items()}
block['stack_scope']='Maximum observed rsp-based DWARF CFA offset per emitted client frame. A null value is censored. Inlining differs by compiler. These observations do not bound OS startup or whole-thread stack.'
d[key]=block;save(name,d)
