from pathlib import Path
import subprocess,random,json,hashlib
w=Path(__file__).parent;u=1<<30;rng=random.Random(912707)
seeds=[(0,0),(u,0),(-u,0),(0,-u),(0,u),(u//2,-u//2),(1,3),(-1,-3),(u,1)]
drives=seeds+[(3,-5),(-3,5),(-2*u,0),(u, u)]+[(rng.randint(-u,u),rng.randint(-u,u)) for _ in range(30)]
out=[];want=[]
# Exact round-to-nearest, ties-to-even with integer floor and remainder.
def rnd(n):
 q,r=divmod(n,u)
 return q+int(2*r>u or (2*r==u and q%2==1))
for resp in [-1,0,1,3,u//2,u//2+1,u-1,u,u+1]:
 for d,q in seeds:
  cid=len(out);out.append(' '.join(map(str,[resp,d,q]+[x for pt in drives for x in pt])))
  if not 0<resp<=u:want.append(f'{cid} Response');continue
  if d*d+q*q>u*u:want.append(f'{cid} VectorRange');continue
  count=0
  for dd,qq in drives:
   if dd*dd+qq*qq>u*u:tag='VectorRange'
   else:
    tag='OK';count+=1
    d=rnd(d*(u-resp))+rnd(dd*resp);q=rnd(q*(u-resp))+rnd(qq*resp)
   want.append(f'{cid} {tag} {count} {d} {q}')
input=('\n'.join(out)+'\n').encode();expected=('\n'.join(want)+'\n').encode()
(w/'ordered-expectations.txt').write_bytes(expected)
for v in ('stable','1.88.0'):
 import os
 target=w/('ordered-target-'+v)
 env=dict(os.environ,CARGO_TARGET_DIR=str(target))
 subprocess.run(['cargo','+'+v,'build','--release','--locked','--manifest-path',str(w/'ordered-client/Cargo.toml')],check=True,env=env)
 actual=subprocess.check_output([target/'release/dq-client'],input=input)
 assert actual==expected
 print(v,len(out),'seeds',len(want),'ordered records',hashlib.sha256(actual).hexdigest())
