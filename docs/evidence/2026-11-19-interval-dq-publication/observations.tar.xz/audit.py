import csv,sys
from pathlib import Path
root=Path('/mnt/development/csgrs');p=root/'interval-inventory.tsv';module='crates/alumina-sim/src/foc.rs'
source=Path('/mnt/development/alumina-firmware')/module
lines=source.read_text().splitlines()
rev=sys.argv[1];retained=sys.argv[2]=='yes'
rows=list(csv.DictReader(p.open(),delimiter='\t'))
def ln(text,start=0):
 return next(i for i,x in enumerate(lines,1) if i>start and text in x)
def make(key,start,t,m,a,who):
 line=ln(key,start)
 orig,=[r for r in rows if r['path']==module and int(r['line'])==line and r['review_status'].startswith('lexical')]
 row=orig.copy()
 row.update(endpoint_representation=t,semantics=m,allocation=a,platform='Deterministic host simulator, standard library. No device realtime caller.',serialization='No wire codec in this path. Replay uses ordered exact lattice values, counter and typed outcomes.',consumers=who,disposition='Keep the dimensionless plant and its transition count in alumina-sim. Q30 owns rounded point arithmetic and the enclosing interval operations remain distinct.',baseline_tests='cargo test --locked -p alumina-sim --lib foc::tests; final counter and retry witness in 2026-11-19-interval-dq-publication.',baseline_benchmarks='Matched Rust 1.88/1.99 linked public client and host test harness, size, timing and memory samples in 2026-11-19-interval-dq-publication.',review_status='Body and immediate callers reviewed at firmware '+rev+'.')
 return row
begin=ln('impl FirstOrderDqPlant {')
reviews=[
make('pub enum DqPlantError',0,'Typed enum; carries FocError','Distinguishes inadmissible response, unit-circle violation, trace count overflow and arithmetic causes.','Inline enum.','Plant constructors, update and host trace builder.'),
make('pub struct FirstOrderDqPlant',0,'Q30 response, DqPoint current and u64 count','Dimensionless nominal two-axis state. Counter records completed transitions.','Copy, fixed fields.','Host simulator, current loop and public clients.'),
make('pub struct DqLoopSample',0,'u64 index, pre/post DqPoint and DqControlUpdate','Retains the controller result and plant input/output points for each step of a trace.','Copy value held by trace Vec.','simulate_dq_current_loop and simulator replay tests.'),
make('pub const fn new(',begin,'Q30 nominal coefficient','Constructs with zero current through with_current.','No allocation.','Host simulator and public client.'),
make('pub const fn with_current(',begin,'Q30 response, DqPoint','Rejects response outside (0,1] before rejecting an initial point outside the closed unit disk. Initializes count zero.','No allocation.','Constructor and external ordered recurrence oracle.'),
make('pub const fn current(',begin,'DqPoint by value','Copies the two nominal fixed-point coordinates.','No allocation.','Trace builder, tests, public client.'),
make('pub const fn updates(',begin,'u64','Returns the completed-update count by value.','No allocation.','Trace builder and public client.'),
make('pub fn update(',begin,'DqPoint and u64','Validates the drive disk, rounds each product of the two component recurrences and checks the counter. '+('Publishes the next point after every fallible operation succeeds.' if retained else 'On counter overflow, the previous implementation stores the new current before returning TraceLength.'),'Stack locals and stored fields. No allocation.','Public update and simulate_dq_current_loop.'),
make('pub fn simulate_dq_current_loop(',0,'Q30 point target, feed-forward and Vec<DqLoopSample>','Prechecks total count, calls the controller then the plant; successful output retains every before/control/after sample in order.','Preallocates a Vec of requested length with with_capacity. Counter-range validation alone does not bound its byte capacity.','Simulator control convergence and saturation tests.'),
make('fn convex_update(',0,'Q30 nominal point terms','Computes round-even(current*retained) plus round-even(drive*response), using checked Q30 arithmetic.','No allocation.','Both axis updates of FirstOrderDqPlant.'),
make('const fn within_unit_circle(',0,'Two Q30 bit numerators widened to i128','Checks exact squared Euclidean norm against Q30::ONE squared, including equality.','No allocation.','Plant initial state, voltage and servo-current admission.')]
assert len({int(r['line']) for r in reviews})==len(reviews)
with p.open('a',newline='') as f:csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n').writerows(reviews)
print('Added',len(reviews),'body reviews at',rev)
