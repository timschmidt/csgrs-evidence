set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
v=$1; stage=$2
cd "$w/alumina-firmware"
export CARGO_TARGET_DIR="$w/target-$v"
cargo +"$v" test --release --locked -p alumina-sim --lib --no-run --message-format=json > "$w/$stage-$v.build" 2> "$w/logs/$stage-$v.build.log"
bin=$(python3 - "$w/$stage-$v.build" <<'PY'
import sys,json
b,=[t['executable'] for t in map(json.loads,open(sys.argv[1])) if t.get('executable')];print(b)
PY
)
cp "$bin" "$w/$stage-$v-sim"
"$bin" > "$w/logs/$stage-$v-sim.log"
cargo +"$v" build --manifest-path "$w/client/Cargo.toml" --locked --release --message-format=json > "$w/$stage-$v-client.build" 2> "$w/logs/$stage-$v-client.build.log"
cp "$CARGO_TARGET_DIR/release/dq-client" "$w/$stage-$v-client"
"$w/$stage-$v-client" > "$w/logs/$stage-$v-client.log"
