set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
for v in stable 1.88.0; do
 until test -s "$w/logs/candidate-$v-client.log"; do
  pgrep -f "^bash $w/release.sh $v candidate$" >/dev/null || { test -s "$w/logs/candidate-$v-client.log" || exit 1; }; sleep 1
 done
done
python3 "$w/oracle.py"
python3 "$w/size.py"
python3 "$w/jobs.py"
