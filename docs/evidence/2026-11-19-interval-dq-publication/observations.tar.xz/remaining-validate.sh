set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
cd /mnt/development/alumina-firmware
export CARGO_TARGET_DIR="$w/final-stable" DQ_STAGE=publish
cargo +stable test --locked -p alumina-sim > "$w/logs/final-stable-tests.log" 2>&1
RUSTDOCFLAGS="-D warnings" cargo +stable doc --locked -p alumina-sim --no-deps > "$w/logs/final-stable-doc.log" 2>&1
rg -q '68 passed; 0 failed' "$w/logs/final-stable-tests.log"
rg -q '8 passed; 0 failed' "$w/logs/final-stable-tests.log"
python3 "$w/frames.py" publish
python3 "$w/oracle.py"
python3 "$w/jobs.py" > "$w/logs/retained-timing.log"
