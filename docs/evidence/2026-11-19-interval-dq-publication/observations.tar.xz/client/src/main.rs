use std::hint::black_box;
use alumina_foc::{DqPoint, Q30};
use alumina_sim::foc::{DqPlantError, FirstOrderDqPlant};

fn main() {
    let mut plant = FirstOrderDqPlant::new(Q30::HALF).unwrap();
    let mut signature = 0u64;
    for i in 0..1_000_000 {
        let drive = DqPoint {
            d: if i % 2 == 0 { Q30::HALF } else { Q30::ZERO },
            q: if i % 3 == 0 { Q30::HALF } else { Q30::ZERO },
        };
        let before = plant;
        assert_eq!(
            plant.update(black_box(DqPoint { d: Q30::ONE, q: Q30::ONE })),
            Err(DqPlantError::VectorRange)
        );
        assert_eq!(plant, before);
        let next = plant.update(black_box(drive)).unwrap();
        assert_eq!(plant.updates(), i + 1);
        assert_eq!(next, plant.current());
        signature = signature.rotate_left(7) ^ (next.d.bits() as u64);
        signature = signature.rotate_left(11) ^ (next.q.bits() as u64);
    }
    println!("{} {} {} {}", plant.updates(), plant.current().d.bits(), plant.current().q.bits(), signature);
}
