set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
for v in 1.88.0 stable; do
 until test -s "$w/logs/fixed-$v-client.log"; do
  pgrep -f "^bash $w/release.sh $v fixed$" >/dev/null || { test -s "$w/logs/fixed-$v-client.log" || exit 1; }; sleep 1
 done
done
git -C "$w/csgrs" switch --detach 35a176de2
git -C "$w/alumina-firmware" switch --detach 35d1b0d
for stage in original candidate; do
 if test "$stage" = candidate; then
  p=crates/alumina-sim/src/foc.rs
  cp "/mnt/development/alumina-firmware/$p" "$w/alumina-firmware/$p"
 fi
 bash "$w/release.sh" 1.88.0 "$stage" & a=$!
 bash "$w/release.sh" stable "$stage" & b=$!
 wait "$a"
 wait "$b"
done
