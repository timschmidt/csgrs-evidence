"""Collect requested heap bytes and calls on the final dynamically linked host executables."""
from pathlib import Path
import json, os, re, subprocess, sys
w=Path(__file__).parent
probe=Path('/usr/lib/x86_64-linux-gnu/libmemusage.so')
env=dict(os.environ, LD_PRELOAD=str(probe))
rows=[]
for compiler in ('1.88.0', 'stable'):
    for artifact in ('client','sim'):
        for rep in range(3):
            for stage in ('fixed','original',sys.argv[1]):
                args=['dq-fixture']
                if artifact=='sim':args.append('--test-threads=1')
                p=subprocess.run(args, executable=w/f'{stage}-{compiler}-{artifact}',cwd=w,env=env,check=True,capture_output=True,text=True)
                if artifact=='sim':assert '68 passed; 0 failed;' in p.stdout
                else:assert p.stdout==(w/'oracle.txt').read_text()
                log=re.sub(r'\x1b\[[0-9;]*m','',p.stderr)
                (w/'logs'/f'heap-{compiler}-{artifact}-{stage}-{rep}.log').write_text(log)
                total,peak=map(int,re.search(r'heap total: (\d+), heap peak: (\d+)',log).groups())
                calls={}
                for kind in ('malloc','realloc','calloc','free'):
                    match=re.search(r'^\s*'+kind+r'\|\s+(\d+)\s+(\d+)(?:[ \t]+(\d+))?',log,re.M)
                    count,bytes_,failed=match.groups()
                    assert not failed or int(failed)==0
                    calls[kind]=dict(count=int(count),bytes=int(bytes_))
                rows.append(dict(compiler=compiler,artifact=artifact,stage=stage,rep=rep,total=total,peak=peak,calls=calls))
(w/'heap.json').write_text(json.dumps(rows,indent=2)+'\n')
for v in ('1.88.0','stable'):
    for a in ('client','sim'):
        for k in ('fixed','original',sys.argv[1]):
            x=[r for r in rows if (r['compiler'],r['artifact'],r['stage'])==(v,a,k)]
            print(v,a,k,'peak',sorted({r['peak'] for r in x}),'total',sorted({r['total'] for r in x}))
