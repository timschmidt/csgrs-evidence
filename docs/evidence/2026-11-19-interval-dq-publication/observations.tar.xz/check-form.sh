set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
prev=$1;variant=$2
for v in stable 1.88.0; do
 until test -s "$w/logs/$prev-$v-client.log"; do
  pgrep -f "^bash $w/release.sh $v $prev$" >/dev/null || { test -s "$w/logs/$prev-$v-client.log" || exit 1; }; sleep 1
 done
done
DQ_STAGE="$prev" python3 "$w/size.py" > "$w/logs/$prev-size.log"
cp "$w/sizes.json" "$w/$prev-sizes.json"
cd "$w/alumina-firmware"
git restore -- crates/alumina-sim/src/foc.rs
git apply "$w/$variant.patch"
bash "$w/release.sh" stable "$variant" & a=$!
bash "$w/release.sh" 1.88.0 "$variant" & b=$!
wait "$a"
wait "$b"
DQ_STAGE="$variant" python3 "$w/size.py"
cp "$w/sizes.json" "$w/$variant-sizes.json"
