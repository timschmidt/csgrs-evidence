"""Repeat process CPU and elapsed measurements on isolated affinity, balancing order within each pair."""
import json,os,random,resource,statistics,subprocess,time
from pathlib import Path
w=Path(__file__).parent
available=sorted(os.sched_getaffinity(0))
cpu=available[12];os.sched_setaffinity(0,{cpu})
oracle=(w/'oracle.txt').read_bytes()
rng=random.Random(993)
rows=[];report={}
for compiler in ('1.88.0','stable'):
    orders=['original','publish']*24
    rng.shuffle(orders)
    for i, first in enumerate(['original','publish']+orders):
        for stage in (first,'publish' if first=='original' else 'original'):
            proc=lambda: resource.getrusage(resource.RUSAGE_CHILDREN)
            before=proc();start=time.perf_counter_ns()
            out=subprocess.check_output([w/f'{stage}-{compiler}-client'])
            elapsed=time.perf_counter_ns()-start;after=proc()
            assert out==oracle
            rows.append(dict(compiler=compiler,stage=stage,round=i,cpu=cpu,elapsed_ms=elapsed/1e6,user_ms=(after.ru_utime-before.ru_utime)*1000,system_ms=(after.ru_stime-before.ru_stime)*1000))
    by={(r['stage'],r['round']):r for r in rows if r['compiler']==compiler and r['round']>=2}
    for metric in ('user_ms','elapsed_ms'):
        diffs=[by['publish',i][metric]-by['original',i][metric] for i in range(2,50)]
        bootstrap=sorted(statistics.median(rng.choices(diffs,k=len(diffs))) for _ in range(20000))
        report[f'{compiler}-{metric}']=dict(original=statistics.median(by['original',i][metric] for i in range(2,50)),candidate=statistics.median(by['publish',i][metric] for i in range(2,50)),paired_median_difference=statistics.median(diffs),paired_percentile95_bootstrap_ms=[bootstrap[500],bootstrap[19499]])
(w/'paired.json').write_text(json.dumps(dict(cpu=cpu,report=report,samples=rows),indent=2)+'\n')
print(json.dumps(report))
