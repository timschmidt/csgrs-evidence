set -eu
. /mnt/development/.interval-refactor-build/dq-publication.rbskZi/env
variant=$1
p=crates/alumina-sim/src/foc.rs
cd /mnt/development/alumina-firmware
# Only the current trial file may be replaced; its patch has already been saved.
git diff -- "$p" > "$w/retired-trial.patch"
git restore -- "$p"
git apply "$w/$variant.patch"
cmp "$p" "$w/alumina-firmware/$p"
export DQ_STAGE="$variant"
python3 "$w/size.py"
python3 - "$w/sizes.json" <<'PY'
import json,sys
z=json.load(open(sys.argv[1]));assert len(z)==4 and not any(x['failed'] for x in z.values())
PY
python3 - "$w" "$p" <<'PY'
import sys,subprocess
from pathlib import Path
w=Path(sys.argv[1]);p=Path(sys.argv[2]);s=p.read_text();o=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
q='#[cfg(test)]\nmod tests {'
assert o.count(q)==s.count(q)==1
(w/'probe-firmware'/p).write_text(o.partition(q)[0]+q+s.partition(q)[2])
PY
testcase=foc::tests::invalid_response_and_drive_are_rejected_before_state_changes
(cd "$w/probe-firmware"; export CARGO_TARGET_DIR="$w/probe-target"; if cargo +1.88.0 test --locked -p alumina-sim --lib "$testcase" -- --exact > "$w/logs/final-before.log" 2>&1; then exit 1; fi; rg -q '0 passed; 1 failed' "$w/logs/final-before.log")
for v in 1.88.0 stable; do
 export CARGO_TARGET_DIR="$w/final-$v"
 cargo +"$v" fmt --all -- --check > "$w/logs/final-$v-fmt.log" 2>&1
 cargo +"$v" clippy --locked -p alumina-sim --all-targets --no-deps -- -D warnings > "$w/logs/final-$v-clippy.log" 2>&1
 cargo +"$v" test --locked -p alumina-sim > "$w/logs/final-$v-tests.log" 2>&1
 RUSTDOCFLAGS="-D warnings" cargo +"$v" doc --locked -p alumina-sim --no-deps > "$w/logs/final-$v-doc.log" 2>&1
 rg -q '68 passed; 0 failed' "$w/logs/final-$v-tests.log"
done
python3 "$w/frames.py" "$variant"
python3 "$w/oracle.py"
python3 "$w/jobs.py" > "$w/logs/retained-timing.log"
