from pathlib import Path
w=Path(__file__).parent
def half_even(n):
 q,r=divmod(n,2)
 return q+(r and q%2)
def rotate(n,k):return (n<<k | n>>(64-k)) & ((1<<64)-1)
d=q=signature=0
for i in range(10**6):
 d=half_even(d)+(1<<28 if i%2==0 else 0)
 q=half_even(q)+(1<<28 if i%3==0 else 0)
 signature=rotate(signature,7)^d
 signature=rotate(signature,11)^q
expected=f'1000000 {d} {q} {signature}\n'
(w/'oracle.txt').write_text(expected)
for log in (w/'logs').glob('*-client.log'):
 assert log.read_text()==expected,log
print(expected,end='')
