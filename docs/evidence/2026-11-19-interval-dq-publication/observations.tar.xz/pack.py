import json,subprocess,importlib.util
from pathlib import Path
w=Path(__file__).parent
items=set()
for n in ['decision-scope.md','scope.md','result.json','ordered-expectations.txt','oracle.txt','client/Cargo.toml','client/Cargo.lock','client/src/main.rs','transitions.rs','transitions.py','ordered-client/Cargo.toml','ordered-client/Cargo.lock','ordered-client/src/main.rs','jobs.py','audit.py','account.py','size.py','sizes.json','frames.py','frames.json','lifetimes.json','timings.json','remaining-validate.sh','heap.py','heap.json','release.sh','check-form.sh','env','final-validate.sh','compare.sh','measure.sh','pack.py','record.py','oracle.py']:
 items.add(w/n)
items.update(w.glob('*.patch'));items.update(w.glob('*-sizes.json'));items.update(w.glob('full-diagnostics-*.json'))
items.update(p for p in (w/'logs').iterdir() if p.is_file())
if (w/'retained').is_file():items.add(w/'retained')
if (w/'paired.json').is_file():items.add(w/'paired.json')
if (w/'paired.py').is_file():items.add(w/'paired.py')
assert (w/'logs/ordered.log').read_text().count('2097 ordered records')==2
assert (w/'logs/ordered-final.log').read_text().count('2097 ordered records')==2
assert '268435456' in (w/'logs/witness-before.log').read_text()
spec=importlib.util.spec_from_file_location('archive',w/'record.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=m.record('dq-publication',items,'Archive host simulator counter-boundary publication and qualified release trials')
(w/'archive-info.json').write_text(json.dumps(r,indent=2)+'\n')
print(r)
