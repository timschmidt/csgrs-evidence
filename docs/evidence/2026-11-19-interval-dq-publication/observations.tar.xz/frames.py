from pathlib import Path
import re,subprocess,sys,json
w=Path(__file__).parent
out={}
for v in ('1.88.0','stable'):
 for k in ('fixed','original',sys.argv[1]):
  p=w/f'{k}-{v}-client'
  asm=subprocess.check_output(['objdump','--no-show-raw-insn','-dC',p],text=True)
  frames=subprocess.check_output(['readelf','-wF',p],text=True)
  fs={}
  for m in re.finditer(r'^([0-9a-f]+) <((?:alumina_sim::foc::FirstOrderDqPlant::update|alumina_sim::foc::convex_update|alumina_foc::.*Q30.*checked_mul|dq_client::main))>:\n(.*?)(?=\n\n)',asm,re.S|re.M):
   start,name,body=m.groups();addr=int(start,16)
   f=next((f for f in frames.split('\n\n') if re.search(r'pc=0*'+format(addr,'x')+r'\.\.',f)),None)
   fs[name]={'address':start,'instructions':body,'CFI':f,'max_CFA_offset':max(map(int,re.findall(r'\brsp\+(\d+)',f or '')),default=0)}
  assert 'dq_client::main' in fs and 'alumina_sim::foc::convex_update' in fs
  out[v,k] = fs
(w/'frames.json').write_text(json.dumps({v+'-'+k:q for (v,k),q in out.items()},indent=2)+'\n')
