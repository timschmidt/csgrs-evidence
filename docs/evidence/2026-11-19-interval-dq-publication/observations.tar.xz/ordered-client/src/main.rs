use std::io::{self, BufRead};
use alumina_foc::{DqPoint, Q30};
use alumina_sim::foc::{DqPlantError, FirstOrderDqPlant};

fn point(d: i32, q: i32) -> DqPoint { DqPoint { d: Q30::from_bits(d), q: Q30::from_bits(q) } }

fn main() {
    for (case, line) in io::stdin().lock().lines().enumerate() {
        let line = line.unwrap();
        let mut values = line.split_whitespace().map(|n| n.parse::<i32>().unwrap());
        let response = Q30::from_bits(values.next().unwrap());
        let initial = point(values.next().unwrap(), values.next().unwrap());
        let mut plant = match FirstOrderDqPlant::with_current(response, initial) {
            Ok(p) => p,
            Err(e) => { println!("{case} {e:?}"); continue; }
        };
        while let Some(d) = values.next() {
            let voltage = point(d, values.next().unwrap());
            let result = match plant.update(voltage) {
                Ok(value) => { assert_eq!(value, plant.current()); "OK" }
                Err(DqPlantError::VectorRange) => "VectorRange",
                e => panic!("{e:?}"),
            };
            println!("{case} {result} {} {} {}",plant.updates(),plant.current().d.bits(),plant.current().q.bits());
        }
    }
}
