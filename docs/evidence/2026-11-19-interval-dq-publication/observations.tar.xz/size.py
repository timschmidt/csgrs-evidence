import hashlib,json,re,subprocess,os
from pathlib import Path
w=Path(__file__).parent
cat=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
caps=cat['existing_artifacts']
def metrics(binary):
 def run(*cmd):return subprocess.check_output([*cmd,binary],text=True)
 b=binary.read_bytes()
 vals={'file':len(b),'named_code':0}
 x={'named_code'}
 sh={}
 for l in run('readelf','-SW').splitlines():
  m=re.match(r'\s*\[\s*\d+\]\s+(\.\S+)\s+(\S+)\s+[0-9a-f]+\s+([0-9a-f]+)\s+([0-9a-f]+)\s+[0-9a-f]+\s+(\S+)',l)
  if not m:continue
  n,k,o,s,f=m.groups();o=int(o,16);s=int(s,16)
  if 'A' in f:
   vals[n]=s
   sh[n]=None if k=='NOBITS' else hashlib.sha256(b[o:o+s]).hexdigest()
   if 'X' in f:x.add(n)
 spans=set()
 for line in run('nm','-S','--defined-only').splitlines():
  m=re.match(r'([0-9a-f]+) ([0-9a-f]+) [tTwW] ',line)
  if m:spans.add(tuple(int(s,16) for s in m.groups()))
 vals['named_code']=sum(sz for _,sz in spans)
 return {'sha256':hashlib.sha256(b).hexdigest(),'section_sha256':sh,'bytes':vals},x
out={}
for v in ('1.88.0','stable'):
 for artifact in ('sim','client'):
  stages={};ex=set()
  for stage in ('fixed','original','candidate'):
   disk_stage=os.environ.get('DQ_STAGE','candidate') if stage=='candidate' else stage
   p=w/f'{disk_stage}-{v}-{artifact}'
   if p.exists():stages[stage],x=metrics(p);ex.update(x)
  if len(stages)!=3:continue
  rows={};fail=[]
  for n in sorted(set.union(*(set(x['bytes']) for x in stages.values()))):
   f,o,c=[stages[k]['bytes'].get(n,0) for k in ('fixed','original','candidate')]
   limits=caps['native_monomorphized_text_sum' if n in ex else 'native_final_file_and_allocated_sections']
   charge=max(0,o-f)+max(0,c-o)
   ir=min(limits['incremental_bytes'],o*limits['incremental_percent']//100)-max(c-o,0)
   cr=min(limits['cumulative_bytes'],f*limits['cumulative_percent']//100)-charge
   rows[n]=dict(fixed=f,previous=o,candidate=c,change=c-o,prior_charge=max(0,o-f),cumulative_charge=charge,incremental_remaining=int(ir),cumulative_remaining=int(cr))
   if ir<0 or cr<0:fail.append(n)
  key=f'{artifact}-{v}'
  out[key]={'stages':stages,'metrics':rows,'failed':fail}
  print(key,'file/text/named',*(rows[k]['change'] for k in ['file','.text','named_code']), 'failed',[(n,rows[n]['incremental_remaining'],rows[n]['cumulative_remaining']) for n in fail])
(w/'sizes.json').write_text(json.dumps(out,indent=2)+'\n')
