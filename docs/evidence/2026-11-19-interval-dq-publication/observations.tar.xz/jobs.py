from pathlib import Path
import subprocess,sys,os,time,json,statistics
w=Path(__file__).parent
if len(sys.argv)>1:
 v,k,a=sys.argv[1:]
 cg=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
 assert int((cg/'memory.max').read_text())==256<<20 and int((cg/'memory.swap.max').read_text())==0
 disk_stage=os.environ.get('DQ_STAGE','candidate') if k=='candidate' else k
 cmd=[w/f'{disk_stage}-{v}-{a}']
 if a=='sim':cmd+=['--test-threads=1']
 p=subprocess.run(cmd,cwd=w,capture_output=True,text=True,check=True)
 assert p.stdout==(w/'oracle.txt').read_text() if a=='client' else '68 passed; 0 failed;' in p.stdout
 peak=int((cg/'memory.peak').read_text())
 events={k:int(v) for k,v in (t.split() for t in (cg/'memory.events').read_text().splitlines())}
 assert peak+(64<<20)<=256<<20 and not any(events.values())
 print(json.dumps(dict(compiler=v,stage=k,artifact=a,peak_bytes=peak,events=events)))
else:
 data=[]
 for v in ('1.88.0','stable'):
  for a in ('client','sim'):
   for rep in range(3):
    for k in ('fixed','original','candidate'):
     cmd=['systemd-run','--quiet','--user','--scope','-p','MemoryMax=256M','-p','MemorySwapMax=0',sys.executable,__file__,v,k,a]
     data.append(json.loads(subprocess.check_output(cmd,text=True)))
 (w/'lifetimes.json').write_text(json.dumps(data,indent=2)+'\n')
 cpu=sorted(os.sched_getaffinity(0))[12]
 os.sched_setaffinity(0,{cpu});times=[]
 for v in ('1.88.0','stable'):
  for rep in range(18):
   for k in (('original','candidate') if rep%2==0 else ('candidate','original')):
    disk_stage=os.environ.get('DQ_STAGE','candidate') if k=='candidate' else k
    cmd=[w/f'{disk_stage}-{v}-client']
    s=time.perf_counter_ns()
    p=subprocess.run(cmd,stdout=subprocess.PIPE,text=True,check=True)
    elapsed=time.perf_counter_ns()-s
    assert p.stdout==(w/'oracle.txt').read_text()
    times.append(dict(compiler=v,stage=k,round=rep,cpu=cpu,ns=elapsed))
 (w/'timings.json').write_text(json.dumps(times,indent=2)+'\n')
 for v in ('1.88.0','stable'):
  print(v,{k:statistics.median(t['ns'] for t in times if t['compiler']==v and t['stage']==k and t['round']>=2) for k in ('original','candidate')})
