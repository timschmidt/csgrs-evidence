Long-horizon external dynamics tier, 23 November 2026.
campaign/: python3 scripts/validated-dynamics/run.py --iterations 100 --samples 5 --cpu 0 --block-timeout 4000,
  measured at dd87532fa (rebased unchanged as 92e91f5d0; the rebase added only a Hypercurve doctest fix).
  All 40 outcomes validated in every block; 800 timing samples in raw-timing.json; medians in summary.json.
ineligible-timeout/: the first attempt, stopped by the runner's fixed 600-second block timeout during the first
  Hyperdynamics block. It supplies no timings.
capd-cmake.log, capd-make.log: CAPD 6.1.0 at 37057e589 built without upstream tests (no Boost on this host); the
  upstream suite passed at this commit on 15 November (docs/evidence/2026-11-15-interval-external-dynamics).
