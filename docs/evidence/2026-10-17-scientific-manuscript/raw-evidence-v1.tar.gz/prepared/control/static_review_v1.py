"""Check manuscript mathematics, references, table inputs and recorded receipts."""
import gzip
import hashlib
import json
import re
import shutil
import sys
import tarfile
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/home/tim/Documents/GitHub/workspace/csgrs')
R = Path('/run/user/1000/csgrs-scientific-manuscript-v1')
S = R / 'source-v2'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


assert not (R / 'static-review.json').exists()
analysis = read(R / 'analysis.json')
assert all(sha(ROOT / p) == h for p, h in analysis['source_and_evidence_sha256'].items())
tex = (S / 'hyper-stack.tex').read_text()
tables = (S / 'results.tex').read_text()
cites = {k for group in re.findall(r'\\cite\{([^}]+)\}', tex) for k in group.split(',')}
bibs = set(re.findall(r'\\bibitem\{([^}]+)\}', tex))
assert cites == bibs and len(cites) == 10
labels = re.findall(r'\\label\{([^}]+)\}', tex + tables)
refs = re.findall(r'\\ref\{([^}]+)\}', tex)
assert len(labels) == len(set(labels)) and set(refs) <= set(labels)
paths = re.findall(r'\\path\{([^}]+)\}', tex)
assert all((ROOT / p).exists() for p in paths)
assert re.findall(r'\\input\{([^}]+)\}', tex) == ['results.tex']
assert sha(S / 'results.tex') == read(R / 'preparation-result.json')['tables_sha256']
assert '476 recorded process observations' in tex
assert '27,093 missing physical artifact paths' in tex
assert 'proposal is not in production' in tex
assert 'does not isolate lookup' in tex
assert 'No new geometry benchmark was run' in tex
assert Fraction(3602879701896397, 36028797018963968) - Fraction(1, 10) == Fraction(1, 180143985094819840)
assert Fraction(0.1) == Fraction(3602879701896397, 36028797018963968)
assert 'runtime_tests_rerun' not in analysis or not analysis['runtime_tests_rerun']
e46 = ROOT / 'docs/evidence/2026-10-17-circle-support-reuse-index'
members = json.loads(gzip.decompress((e46 / 'archive-members-v1.json.gz').read_bytes()))
receipts = []
with tarfile.open(e46 / 'raw-evidence-v1.tar.xz', 'r:xz') as archive:
    for name in analysis['selected_member_sha256']:
        if not name.endswith('.stdout') or name.startswith('E51:'):
            continue
        raw = archive.extractfile(name).read()
        assert hashlib.sha256(raw).hexdigest() == members[name]['sha256']
        marker = b'CIRCLE_SMALL_CERTAINTY Certified' if name.startswith('run/cost-matched-v1/') else b'CIRCLE_SHARED_CERTAINTY Certified'
        assert raw.count(marker) == 1
        receipts.append(name)
assert len(receipts) == 476
e51 = read(ROOT / 'docs/evidence/2026-10-17-circle-support-reuse-full-library/protocol.json')
proofs = {}
for name in ['circle_support_small_batch_probe.rs', 'circle_support_coefficient_probe.rs']:
    path = Path('/dev/shm/csgrs-circle-support-reuse-index-v1/build-v1/candidate-source/crates/hypercurve/src') / name
    digest = sha(path)
    matches = {key: value for key, value in e51['read_only_source_sha256'].items() if key.endswith('/' + name)}
    assert matches and all(value == digest for value in matches.values())
    proofs[str(path)] = {'sha256': digest, 'retained_source_pins': matches,
                         'inspection': 'Independent geometric construction, STRICT receipt and exact timing boundaries read.'}
assert all(line == line.rstrip() for text in [tex, tables] for line in text.splitlines())
checks = {
    'status': 'static manuscript and historical-data checks passed; rendering and repository application blocked',
    'source_sha256': {str(p): sha(p) for p in sorted(S.iterdir())},
    'analysis_sha256': sha(R / 'analysis.json'),
    'citation_keys_checked': sorted(cites), 'local_reference_paths_checked': sorted(set(paths)),
    'table_labels_checked': sorted(labels), 'exact_decimal_example_verified': True,
    'recorded_certified_receipts_verified': len(receipts), 'retained_probe_sources_verified': proofs,
    'primary_references_checked': [
        {'authors': 'Jonathan Richard Shewchuk', 'year': 1997, 'url': 'https://www.cs.cmu.edu/~quake/robust.html'},
        {'authors': 'Sylvain Pion and Andreas Fabri', 'year': 2006, 'url': 'https://arxiv.org/abs/cs/0608063'},
        {'authors': 'Qingnan Zhou, Eitan Grinspun, Denis Zorin and Alec Jacobson', 'year': 2016,
         'url': 'https://www.cs.columbia.edu/cg/mesh-arrangements/'}],
    'render_complete': False, 'visual_review_complete': False,
    'repository_sources_applied': False, 'manuscript_committed': False,
    'runtime_tests_rerun': False, 'independent_new_geometry_execution': False,
    'publication_ready': False, 'full_plan_complete': False,
    'repository_free_bytes': shutil.disk_usage(ROOT).free,
    'repository_reserve_bytes': 512 * 1024**2,
    'repository_application_planning_allowance_bytes': 1280 * 1024,
}
(R / 'static-review.json').write_text(json.dumps(checks, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: checks[k] for k in ['status', 'recorded_certified_receipts_verified',
    'exact_decimal_example_verified', 'repository_free_bytes', 'render_complete']}))
