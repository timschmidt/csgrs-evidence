"""Verify retained observations and regenerate the manuscript's numerical tables."""
import gzip
from decimal import Decimal
import hashlib
import json
import re
import statistics
import subprocess
import sys
import tarfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/home/tim/Documents/GitHub/workspace/csgrs')
R = Path('/run/user/1000/csgrs-scientific-manuscript-v1')
W = R / 'control'
E46 = ROOT / 'docs/evidence/2026-10-17-circle-support-reuse-index'
E51 = ROOT / 'docs/evidence/2026-10-17-circle-support-reuse-full-library'
P = ROOT / 'docs/evidence/2026-10-17-package-license-texts'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def read(path):
    return json.loads(Path(path).read_text())


assert not (R / 'analysis.json').exists()
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert base == '7ed43501755fd64a01f54c3078d12229cbc0129d'
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
previous = read(P / 'checkpoint-v1.json')
assert all(sha(ROOT / p) == h for p, h in previous['evidence_files_sha256'].items())
pins = {}
for folder, names in [(E46, ['raw-evidence-v1.tar.xz', 'archive-members-v1.json.gz', 'progress-v1.md', 'decision-v1.json']),
                      (E51, ['raw-evidence-v1.tar.gz', 'archive-members-v1.json', 'qualification-v1.json', 'protocol.json'])]:
    expected = read(folder / 'checkpoint-v1.json')['evidence_files_sha256']
    for name in names:
        path = folder / name
        key = str(path.relative_to(ROOT))
        assert sha(path) == expected[key]
        pins[key] = sha(path)
sources = [
    'properties.md', 'docs/admission.md', 'src/context.rs', 'src/solid/cache.rs',
    'crates/hyperlimit/src/predicate.rs', 'crates/hypercurve/src/policy.rs',
    'crates/hyperreal/README.md', 'crates/hyperreal/verification/README.md',
    'docs/evidence/2026-10-16-native-change-disposition/progress-v1.md',
    'docs/evidence/2026-10-17-release-consumer-audit/README.md',
]
for name in sources:
    pins[name] = sha(ROOT / name)
members = json.loads(gzip.decompress((E46 / 'archive-members-v1.json.gz').read_bytes()))
used = {}
with tarfile.open(E46 / 'raw-evidence-v1.tar.xz', 'r:xz') as archive:
    def member(name):
        raw = archive.extractfile(name).read()
        assert len(raw) == members[name]['bytes']
        assert hashlib.sha256(raw).hexdigest() == members[name]['sha256']
        used[name] = members[name]['sha256']
        return raw

    def doc(name):
        return json.loads(member(name))

    build = doc('run/build-v1/protocol.json')
    small_protocol = doc('run/cost-matched-v1/protocol.json')
    shared_protocol = doc('grouped-repeat/protocol.json')
    small_recorded = doc('run/cost-matched-v1/summary.json')
    shared_recorded = doc('grouped-repeat/result.json')
    assert small_protocol['repetitions'] == 7
    assert small_protocol['seed'] == 20261017
    counts = [1, 4, 8, 9, 16, 31, 32, 33, 64, 128]
    small = []
    for count in counts:
        by_phase = {'cold': {'baseline': [], 'candidate': []}, 'warm': {'baseline': [], 'candidate': []}}
        query_counts = set()
        for repetition in range(7):
            for variant in ['baseline', 'candidate']:
                stem = f'run/cost-matched-v1/n{count}-r{repetition}-{variant}'
                result = doc(stem + '.result.json')
                assert result['exit_code'] == 0
                output = member(stem + '.stdout').decode()
                assert 'test result: ok. 1 passed; 0 failed;' in output
                samples = [json.loads(x) for x in re.findall(r'CIRCLE_SMALL_SAMPLE (\{[^\n]*\})', output)]
                assert len(samples) == 2 and {s['phase'] for s in samples} == {'cold', 'warm'}
                for sample in samples:
                    assert sample['count'] == count and sample['queries'] >= 65536
                    query_counts.add(sample['queries'])
                    by_phase[sample['phase']][variant].append(sample['seconds'])
        assert len(query_counts) == 1
        row = {'count': count, 'queries_per_phase': query_counts.pop()}
        for phase, samples in by_phase.items():
            record = next(x for x in small_recorded if x['count'] == count and x['phase'] == phase)
            for variant in ['baseline', 'candidate']:
                assert samples[variant] == record[variant + '_seconds']
                median = statistics.median(samples[variant])
                assert median == record[variant + '_median_seconds']
                row[variant + '_' + phase] = median
            row[phase + '_ratio'] = row['candidate_' + phase] / row['baseline_' + phase]
            assert row[phase + '_ratio'] == record['candidate_over_baseline']
        small.append(row)
    shared = []
    for bits in [64, 65536, 1048576]:
        samples = {'baseline': [], 'candidate': []}
        for group in range(7):
            for variant in ['baseline', 'candidate']:
                phase_seconds = []
                for process in range(8):
                    stem = f'grouped-repeat/b{bits}-g{group}-p{process}-{variant}'
                    result = doc(stem + '.result.json')
                    assert result['exit_code'] == 0
                    output = member(stem + '.stdout').decode()
                    assert 'test result: ok. 1 passed; 0 failed;' in output
                    phases = [json.loads(x) for x in re.findall(r'CIRCLE_SHARED_SAMPLE (\{[^\n]*\})', output)]
                    warm = [x for x in phases if x['phase'] == 'warm']
                    assert len(warm) == 1 and warm[0]['queries'] == 20000
                    assert warm[0]['coefficient_shift_bits'] == bits
                    phase_seconds.append(warm[0]['seconds'])
                total = sum(phase_seconds)
                exact_decimal_total = sum(Decimal(str(x)) for x in phase_seconds)
                assert abs(Decimal(str(total)) - exact_decimal_total) < Decimal('0.0000000005')
                samples[variant].append(total)
        recorded = next(x for x in shared_recorded['comparisons'] if x['bits'] == bits)
        assert all(samples[v] == recorded[v + '_seconds'] for v in samples)
        baseline = statistics.median(samples['baseline'])
        candidate = statistics.median(samples['candidate'])
        ratio = candidate / baseline
        positive = sum(c > b for b, c in zip(samples['baseline'], samples['candidate']))
        separate = min(samples['candidate']) > max(samples['baseline'])
        rejection = ratio > 1.1 and positive == 7 and separate
        assert ratio == recorded['candidate_over_baseline_median']
        assert rejection == recorded['predeclared_rejection_criterion_met']
        shared.append({'bits': bits, 'baseline_seconds': baseline, 'candidate_seconds': candidate,
                       'ratio': ratio, 'positive_pairs': positive, 'separate_ranges': separate,
                       'rejection_criterion_met': rejection})

qualification = read(E51 / 'qualification-v1.json')
index = read(E51 / 'archive-members-v1.json')['members']
suites = []
with tarfile.open(E51 / 'raw-evidence-v1.tar.gz', 'r:gz') as archive:
    for mode in ['no-feature', 'all-feature']:
        name = 'run/' + mode + '/tests.stdout'
        raw = archive.extractfile(name).read()
        assert hashlib.sha256(raw).hexdigest() == index[name]['sha256']
        used['E51:' + name] = index[name]['sha256']
        summaries = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', raw)
        assert len(summaries) == 1
        passed, failed, ignored, measured, filtered = map(int, summaries[0])
        assert failed == measured == filtered == 0
        expected = next(x for x in qualification['modes'] if x['mode'] == mode)
        assert expected['status'] == 'passed' and expected['exit_code'] == 0
        assert expected['summaries'][0][1:] == [str(passed), '0', str(ignored), '0', '0']
        suites.append({'mode': mode, 'passed': passed, 'ignored': ignored, 'failed': failed})
assert 'AMD Ryzen 7 5800X3D' in build['hardware']
assert build['features'] == [] and 'rustc 1.98.1' in build['rustc']
analysis = {'source_revision': base, 'small': small, 'shared': shared, 'library_suites': suites,
            'raw_process_observations_recomputed': 476,
            'independent_new_geometry_execution': False,
            'selected_member_sha256': used, 'source_and_evidence_sha256': pins,
            'hardware': 'AMD Ryzen 7 5800X3D, 8 cores/16 hardware threads',
            'rustc': build['rustc'], 'small_timing_protocol': small_protocol,
            'grouped_timing_protocol': shared_protocol,
            'historical_artifact_missing_paths': 27093,
            'prepared_helper_sha256': sha(W / 'prepare_v2.py')}
dump(R / 'analysis.json', analysis)
lines = [
    r'\begin{table}[htbp]\centering\small',
    r'\caption{Complete small-batch sweep. Medians of seven processes per variant; seconds per phase. Each phase executes at least 65,536 queries. These are historical focused measurements, not downstream completion timings.}\label{tab:small}',
    r'\begin{tabular}{r r r r r}\toprule',
    r'Pairs & Baseline cold & Candidate cold & Baseline warm & Candidate warm\\\midrule']
for row in small:
    lines.append(str(row['count']) + ' & ' + ' & '.join(f"{row[k]:.6f}" for k in [
        'baseline_cold', 'candidate_cold', 'baseline_warm', 'candidate_warm']) + r'\\')
lines += [r'\bottomrule\end{tabular}\end{table}', '',
    r'\begin{table}[htbp]\centering\small',
    r'\caption{Complete grouped shared-coefficient sweep. Each group sums eight independent 20,000-query phases. Seven groups per variant. No row meets the original three-part rejection rule; adverse measurements remain visible.}\label{tab:shared}',
    r'\begin{tabular}{r r r r r}\toprule',
    r'Shift bits & Baseline ms & Candidate ms & Change & Positive pairs\\\midrule']
for row in shared:
    lines.append(f"{row['bits']} & {row['baseline_seconds']*1000:.6f} & {row['candidate_seconds']*1000:.6f} & +{(row['ratio']-1)*100:.4f}" + r'\% & ' + str(row['positive_pairs']) + r'/7\\')
lines += [r'\bottomrule\end{tabular}\end{table}', '',
    r'\begin{table}[htbp]\centering\small',
    r'\caption{Later complete executions of the two preserved candidate library binaries. Configurations overlap; counts must not be added as distinct coverage.}\label{tab:suites}',
    r'\begin{tabular}{l r r r}\toprule',
    r'Configuration & Passed & Failed & Existing ignored\\\midrule']
for row in suites:
    lines.append(f"{row['mode']} & {row['passed']} & {row['failed']} & {row['ignored']}" + r'\\')
lines += [r'\bottomrule\end{tabular}\end{table}', '']
(R / 'source-v1/results.tex').write_text('\n'.join(lines))
dump(R / 'preparation-result.json', {'complete': True, 'raw_process_observations_recomputed': 476,
    'selected_members_verified': len(used), 'source_and_evidence_inputs_verified': len(pins),
    'tables_sha256': sha(R / 'source-v1/results.tex'), 'library_summaries_verified': suites})
print(json.dumps({'recomputed_process_observations': 476, 'verified_members': len(used),
                  'small_rows': len(small), 'adverse_rows': len(shared), 'suites': suites}))
