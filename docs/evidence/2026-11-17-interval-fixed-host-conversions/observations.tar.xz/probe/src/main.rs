use hyperinterval::{FixedEndpoint, FixedInterval, DyadicBudget, IntervalError};
use std::hint::black_box;
#[cfg(feature="heap")]
mod heap;
#[cfg(feature="heap")]
use heap::run;

#[cfg(not(feature="heap"))]
fn run<T>(name: &str, mut op: impl FnMut()->T) {
    for _ in 0..512 { drop(black_box(op())); }
    for block in 0..9 {
        let start=std::time::Instant::now();
        for _ in 0..65_536 { drop(black_box(op())); }
        println!("{name},{block},65536,{}", start.elapsed().as_nanos());
    }
}
fn probe<I: FixedEndpoint+Into<i64>, const F:u32>(case:&str,x:FixedInterval<I,F>) {
    run(&format!("{case}/rational"), || black_box(&x).to_rational());
    run(&format!("{case}/dyadic"), || {
        black_box(&x).to_dyadic(&mut black_box(DyadicBudget::new(64,128))).unwrap()
    });
}
fn main() {
    probe("empty",FixedInterval::<i64,63>::empty().unwrap());
    probe("q30",FixedInterval::<i32,30>::new(-1535,54321).unwrap());
    probe("q32",FixedInterval::<i64,32>::new(-(1_i64<<48),1_i64<<50).unwrap());
    probe("q63-unit",FixedInterval::<i64,63>::point(-1).unwrap());
    let full=FixedInterval::<i64,63>::new(i64::MIN,i64::MAX).unwrap();
    probe("q63-full",full);
    run("q63-reject-retry", || {
        let x=black_box(&full);
        assert_eq!(x.to_dyadic(&mut black_box(DyadicBudget::new(63,128))),Err(IntervalError::SizeExhausted));
        x.to_dyadic(&mut black_box(DyadicBudget::new(64,128))).unwrap()
    });
}
