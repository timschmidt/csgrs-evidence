set -eu
s=/dev/shm/interval-fixed-host
. "$s/env"
cargo +1.95.0 build --locked --release -p hyperinterval --features fixed --example fixed_bounds
cp "$CARGO_TARGET_DIR/release/examples/fixed_bounds" "$s/$1/fixed-only"
cargo +1.95.0 build --locked --release -p hyperinterval --all-features --example fixed_bounds --example host_cost
cp "$CARGO_TARGET_DIR/release/examples/fixed_bounds" "$s/$1/fixed-all"
cp "$CARGO_TARGET_DIR/release/examples/host_cost" "$s/$1/host-all"
