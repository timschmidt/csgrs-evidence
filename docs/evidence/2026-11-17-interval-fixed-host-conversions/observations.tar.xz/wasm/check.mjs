import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const {instance}=await WebAssembly.instantiate(readFileSync(process.argv[2]));
let calls=0;
for(const f of [0,30,32,63]){
  const half=1n<<BigInt(f===30?31:63);
  const points=[-half,1n-half,-4n,-1n,0n,1n,4n,half-2n,half-1n];
  for(const a of points)for(const b of points)if(a<=b){
    for(const d of [false,true])for(const hi of [false,true]){
      assert.equal(instance.exports.lattice_endpoint(f,a,b,d,hi),hi?b:a);
      calls++;
    }
  }
}
console.log(calls,"exact endpoint checks passed");
