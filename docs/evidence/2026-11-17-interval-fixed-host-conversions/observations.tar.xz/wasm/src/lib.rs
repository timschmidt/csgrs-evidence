use hyperinterval::{DyadicBudget, FixedEndpoint, FixedInterval};
use hyperreal::Rational;
fn endpoint<I: FixedEndpoint+Into<i64>, const F:u32>(source:FixedInterval<I,F>,dyadic:bool,hi:bool)->i64 {
    if dyadic {
        let output=source.to_dyadic(&mut DyadicBudget::new(64,128)).unwrap();
        let (a,b,e)=output.bounds().unwrap();
        let n=i64::try_from(if hi {b} else {a}).unwrap();
        i64::try_from(i128::from(n) << u32::try_from(e+F as i32).unwrap()).unwrap()
    } else {
        let output=source.to_rational();
        let (a,b)=output.bounds().unwrap();
        i64::try_from((if hi {b} else {a}) * &Rational::from(1_u64<<F)).unwrap()
    }
}
#[unsafe(no_mangle)]
pub extern "C" fn lattice_endpoint(format:u32,a:i64,b:i64,dyadic:bool,hi:bool)->i64 {
    match format {
        0=>endpoint(FixedInterval::<i64,0>::new(a,b).unwrap(),dyadic,hi),
        30=>endpoint(FixedInterval::<i32,30>::new(a.try_into().unwrap(),b.try_into().unwrap()).unwrap(),dyadic,hi),
        32=>endpoint(FixedInterval::<i64,32>::new(a,b).unwrap(),dyadic,hi),
        63=>endpoint(FixedInterval::<i64,63>::new(a,b).unwrap(),dyadic,hi),
        _=>panic!("unsupported fixture"),
    }
}
