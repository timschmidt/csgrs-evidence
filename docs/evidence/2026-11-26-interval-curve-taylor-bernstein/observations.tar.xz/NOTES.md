# Curve range boxes: natural, subdivided natural, Taylor and Bernstein (2026-11-26)

bernstein-probe.rs is a temporary hypercurve integration test (removed from the
tree), run in release with `--features interval-ranges,hypersolve/taylor-model`
on base-commit.txt. Widths are x/y box widths; times are mean microseconds over
20 repetitions after one warm-up, unpinned, one host. "natural xk" is the hull of
k equal natural sub-boxes. "Bernstein hull" is the exact Aabb2 of the affine
control points after two exact splits; valid as a range box because every
weight is positive.
