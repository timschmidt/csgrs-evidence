#![cfg(feature = "interval-ranges")]
use hyperinterval::{DyadicBudget, DyadicInterval};
use hypercurve::{Aabb2, HomogeneousControl2, RationalBezier2, interval_ranges::prepare_rational_bezier_ranges};
use hyperreal::Real;
use hypersolve::expression_program::{ExpressionBudget, TaylorRequest};
use std::time::Instant;
fn g() -> ExpressionBudget { ExpressionBudget::new(100_000_000, 10_000_000_000) }
fn a() -> DyadicBudget { DyadicBudget::new(16384, 1_000_000_000_000_000) }
fn d(l: i64, u: i64, e: i32) -> DyadicInterval { DyadicInterval::new(l.into(), u.into(), e).unwrap() }
fn f(v: &impl std::fmt::Display, e: i32) -> f64 { v.to_string().parse::<f64>().unwrap() * 2f64.powi(e) }
fn w(i: &DyadicInterval) -> f64 { match i.width(&mut a()).unwrap().upper() { Some((m, e)) => f(m, e), None => f64::NAN } }
fn r(n: i64, dd: i64) -> Real { (Real::from(n) / Real::from(dd)).unwrap() }
fn hc(x: Real, y: Real, wt: Real) -> HomogeneousControl2 { HomogeneousControl2::new(x, y, wt) }
fn hull(c: &RationalBezier2, lo: (i64, i64), hi: (i64, i64)) -> [f64; 2] {
    let al = r(lo.0, lo.1);
    let (_, right) = c.split_at_exact(&al).unwrap();
    let s = ((r(hi.0, hi.1) - al.clone()) / (Real::from(1) - al)).unwrap();
    let (piece, _) = right.split_at_exact(&s).unwrap();
    let b = Aabb2::from_points(piece.affine_control_points().unwrap().iter());
    let hypercurve::Classification::Decided(b) = b else { panic!("uncertain box") };
    [(b.max_x().clone() - b.min_x().clone()).to_f64_lossy().unwrap(), (b.max_y().clone() - b.min_y().clone()).to_f64_lossy().unwrap()]
}
fn time<T>(n: u32, mut f: impl FnMut() -> T) -> (T, f64) {
    let mut out = f();
    let s = Instant::now();
    for _ in 0..n { out = f(); }
    (out, s.elapsed().as_secs_f64() * 1e6 / n as f64)
}
#[test]
fn probe() {
    let curves: Vec<(&str, RationalBezier2)> = vec![
        ("conic", RationalBezier2::from_homogeneous_controls(vec![hc(r(1,1),r(0,1),r(1,1)), hc(r(1,2),r(1,2),r(1,2)), hc(r(0,1),r(1,1),r(1,1))]).unwrap()),
        ("cubic", RationalBezier2::from_homogeneous_controls(vec![hc(r(0,1),r(0,1),r(1,1)), hc(r(3,1),r(6,1),r(3,1)), hc(r(1,1),r(-1,2),r(1,2)), hc(r(8,1),r(2,1),r(2,1))]).unwrap()),
        ("quartic", RationalBezier2::from_homogeneous_controls(vec![hc(r(0,1),r(0,1),r(1,1)), hc(r(4,1),r(8,1),r(4,1)), hc(r(2,1),r(-1,1),r(1,1)), hc(r(12,1),r(8,1),r(4,1)), hc(r(4,1),r(0,1),r(1,1))]).unwrap()),
    ];
    println!("| curve | span | natural | natural x2 | natural x4 | Taylor o2 | Taylor o4 | Bernstein hull |");
    println!("| --- | --- | --- | --- | --- | --- | --- | --- |");
    for (name, curve) in &curves {
        let prepared = prepare_rational_bezier_ranges(curve, &mut g()).unwrap();
        for (lo, hi, e) in [(0i64, 1i64, 0i32), (0, 1, -1), (1, 2, -2), (3, 4, -3)] {
            let den = 1i64 << (-e);
            let cell = |v: Result<[f64; 2], String>, t: f64| match v { Ok(v) => format!("{:.3}/{:.3} ({:.0} µs)", v[0], v[1], t), Err(e) => format!("fails ({:.0} µs)", t).replace("fails", &e) };
            let nat = |l: i64, u: i64, ee: i32| prepared.enclose(&d(l, u, ee), -64, &mut g(), &mut a()).map(|r| [r.coordinates()[0].clone(), r.coordinates()[1].clone()]);
            let pieces = |k: i64| -> Result<[f64; 2], String> {
                // split [lo,hi]*2^e into k pieces and union
                let mut acc: Option<[DyadicInterval; 2]> = None;
                for i in 0..k { let (l, u) = (lo * k + i * (hi - lo), lo * k + (i + 1) * (hi - lo)); let ee = e - (k as f64).log2() as i32;
                    let c = nat(l, u, ee).map_err(|_| "fails".to_string())?;
                    acc = Some(match acc { None => c, Some(p) => [p[0].hull(&c[0], &mut a()).unwrap(), p[1].hull(&c[1], &mut a()).unwrap()] }); }
                let acc = acc.unwrap(); Ok([w(&acc[0]), w(&acc[1])])
            };
            let (n1, t1) = time(20, || nat(lo, hi, e).map(|c| [w(&c[0]), w(&c[1])]).map_err(|_| "fails".to_string()));
            let (n2, t2) = time(20, || pieces(2));
            let (n4, t4) = time(20, || pieces(4));
            let center = d(lo, hi, e).midpoint(&mut a()).unwrap();
            let tay = |order: usize| prepared.program().source().taylor_model(TaylorRequest { center: vec![center.clone()], domain: vec![d(lo, hi, e)], order, precision: -64 }, &mut g(), &mut a()).map(|m| [w(&m.image()[0]), w(&m.image()[1])]).map_err(|_| "fails".to_string());
            let (o2, s2) = time(20, || tay(2));
            let (o4, s4) = time(20, || tay(4));
            let (h, th) = time(20, || Ok::<_, String>(hull(curve, (lo, den), (hi, den))));
            println!("| {name} | [{lo}/{den},{hi}/{den}] | {} | {} | {} | {} | {} | {} |", cell(n1, t1), cell(n2, t2), cell(n4, t4), cell(o2, s2), cell(o4, s4), cell(h, th));
        }
    }
}
