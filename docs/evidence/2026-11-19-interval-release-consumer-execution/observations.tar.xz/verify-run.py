from pathlib import Path
import hashlib,json,os,re,subprocess as sp,sys,tarfile
s=Path(__file__).resolve().parent
log=Path(sys.argv[1]);target=Path(sys.argv[2]);text=log.read_text()
source=(s/'source').read_text().strip()
names=re.search(r'^crates=\(\n(.*?)^\)',(s/'clean/scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
assert len(names)==len(set(names))==21
expected=['user_path',*['quickstart_'+n.replace('-','_') for n in names if n!='csgrs-ffi'],'curve_interval_ranges','ffi_smoke','cpp_smoke','python_bindings','go_bindings','typescript_bindings']
executed=re.findall(r'^([a-zA-Z][\w]*)\s+ok$',text,re.M)
assert executed==expected,(executed,expected)
assert 'local documentation configurations passed: 21' in text and 'resolution: 21 released crates from packages' in text
assert text.rstrip().endswith('release check passed')
assert (target/'consumer/debug/quickstart_retired').exists()
archives={}
for p in (target/'package').glob('*.crate'):
 with tarfile.open(p) as t:
  base=p.name[:-6];vcs=json.load(t.extractfile(base+'/.cargo_vcs_info.json'))['git']
  assert vcs['sha1']==source and not vcs.get('dirty')
 archives[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
assert len(archives)==21
result={'source':source,'archives':archives,'executed':executed,'docs_configurations':21,'poison_executable_present':True}
(s/'receipts'/(log.stem+'.json')).write_text(json.dumps(result,indent=1));print(len(expected),len(archives))
