"""Exercise the exact smoke-loop section, separately from expensive packaging."""
from pathlib import Path
import os,subprocess as sp
p=Path(__file__).resolve().parent; repo=p.parent/'csgrs'
body=(repo/'scripts/release-check.sh').read_text()
loop=body[body.index('run_dir="'):body.index('# The other language bindings')]
script=p/'current-loop.sh'
script.write_text('set -euo pipefail\ntarget="$1/root"\nwork="$1/work"\nrust_programs=(user_path quickstart_current curve_interval_ranges)\n'+loop)
def make(name,status=0):
 f=p/name;f.write_text(f'#!/bin/sh\nexit {status}\n');f.chmod(0o755);return f
root='root/consumer/debug/'
paths=[make(root+n) for n in ['user_path','quickstart_current','curve_interval_ranges']]
(p/'work/rust-binaries').write_bytes(b''.join(os.fsencode(v)+b'\0' for v in paths))
def run(name,status):
 z=sp.run(['bash',script,p],capture_output=True,text=True);print(name, z.returncode, z.stdout,z.stderr);assert (z.returncode==0)==status;return z
stale=make(root+'quickstart_retired',93)
assert not (p/'work/ffi_smoke').exists()
assert 'ffi_smoke' in run('missing C',False).stdout
make('work/ffi_smoke');make('work/cpp_smoke')
out=run('expected set',True);assert len(out.stdout.splitlines())==5 and 'retired' not in out.stdout
(p/'work/cpp_smoke').chmod(0o600);assert 'cpp_smoke' in run('nonexecutable C++',False).stdout
make('work/cpp_smoke')
paths[1].unlink();assert 'quickstart_current' in run('missing required Rust program',False).stdout
