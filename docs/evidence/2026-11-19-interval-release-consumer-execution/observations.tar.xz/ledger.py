from pathlib import Path
import json
s=Path(__file__).resolve().parent
root=s.parent/'csgrs'
r=json.loads((s/'receipt.json').read_text());p=root/'INTERVAL_REFACTOR_PROGRESS.md'
header="## Phase 14 — execute the current release's required clients"
assert header not in p.read_text()
with p.open('a') as f:f.write(f"""
{header}

On `c2f658bef`, the release driver returned success when its C smoke
executable was absent and ran a quick start left by an earlier release.
The compiler had produced a known set of programs, but the driver searched
a reusable build directory and silently skipped missing paths.

Commit `66083909e` requests each Rust consumer by name and runs the executable
Cargo reports for that consumer manifest. Both linked C and C++ programs
must also execute. The compiled regression keeps a retired binary on disk,
builds the remaining programs a second time, and checks missing and
foreign-manifest artifacts. The execution checks detected a missing Rust
quick start, a missing C program and a nonexecutable C++ program.
[Release check](scripts/release-check.sh)

The complete local release check passed on Rust 1.95 and 1.99. Each packaged
and verified 21 crates, rendered 21 documentation configurations and passed
all 27 client checks. These included 20 packaged README quick starts, the
user path, the curve-range example, both linked programs and the Python, Go
and TypeScript bindings. An executable left in the reused target directory
would have exited 93 if called. The archive contains all 22 selected Rust
executable hashes and all 21 rendered crate index hashes for each compiler.

All 21 final package archives reproduced byte-for-byte in separate clean
checkouts with each Cargo version. Across the two versions, 14 archive hashes
matched. Three gzip streams differed with identical decompressed tar bytes.
Four packages had only dependency checksum differences in the generated
`Cargo.lock`. Every changed checksum matched the corresponding rebuilt archive.
The selected dependency names and versions and packaged sources matched.

The first offline run lacked the `target-tuple` index entry. Both complete
runs used registry access. Cargo also warned about the existing yanked
`async-executor` 1.14.0 lockfile entry. The documentation builds used workspace
sources and packaging used the documented local Hypervoxel overlay. Hosted
documentation, registry publication and hardware qualification remain open.
[Release conditions](docs/RELEASE.md)

Evidence commit `{r['commit']}` records {r['members']} verified members
in {int(r['row'].split(chr(9))[2]):,} compressed bytes. [Evidence index](docs/evidence-archive.tsv)
""")
table_old='21 packaged crates and 26 clients on Rust 1.95/stable, clean archive reproducibility'
table_new='21 packages reproduce byte-for-byte across clean checkouts with each of Rust 1.95 and 1.99, and all 27 required client checks pass on both'
body=p.read_text();assert body.count(table_old)==1;p.write_text(body.replace(table_old,table_new))
