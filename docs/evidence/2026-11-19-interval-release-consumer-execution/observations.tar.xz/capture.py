from pathlib import Path
import os,time,hashlib,json,sys
s=Path(__file__).resolve().parent
tag=sys.argv[1]
for _ in range(600):
 for p in (s/('tmp-stable' if tag=='stable' else 'tmp')).glob('csgrs-release-check.*/rust-binaries'):
  raw=p.read_bytes().split(b'\0')
  if len(raw)!=23 or raw[-1]:continue
  root=p.parent/'consumer/Cargo.toml';paths=set(map(os.fsdecode,raw[:-1]))
  rows={}
  for ln in (p.parent/'consumer-build.jsonl').read_bytes().splitlines():
   m=json.loads(ln)
   if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(root) and m['executable'] in paths:
    exe=Path(m['executable']);rows[m['target']['name']]={'source':m['target']['src_path'],'executable':str(exe),'sha256':hashlib.file_digest(exe.open('rb'),'sha256').hexdigest(),'fresh':m['fresh']}
  assert len(rows)==22 and len(paths)==22
  (s/'receipts'/(tag+'-rust-artifacts.json')).write_text(json.dumps(rows,indent=1));print('captured',len(rows));sys.exit(0)
 time.sleep(4)
sys.exit('no final artifacts observed')
