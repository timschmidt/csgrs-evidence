from pathlib import Path
import json,hashlib,os,re,subprocess as sp,sys,tarfile
s=Path(__file__).resolve().parent
v=sys.argv[1]
clean=s.parent/'csgrs' if v=='stable' else s/'clean'
source=sp.check_output(['git','rev-parse','HEAD'],cwd=clean,text=True).strip()
assert source==(s/'source').read_text().strip() and not sp.check_output(['git','status','--porcelain'],cwd=clean)
names=re.search(r'^crates=\(\n(.*?)^\)',(clean/'scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
out=s/('repack-'+v)
cmd=['cargo','+'+v,'package','--locked','--no-verify','--config','patch.crates-io.hypervoxel.path="crates/hypervoxel"']
for n in names:cmd+=['-p',n]
if '--compare-only' not in sys.argv:sp.run(cmd,cwd=clean,env=os.environ|{'CARGO_HOME':str(s/'repack-home'),'CARGO_TARGET_DIR':str(out)},check=True)
if '--stage-only' in sys.argv:sys.exit(0)
def signature(folder):
 result={}
 for p in sorted(folder.glob('*.crate')):
  with tarfile.open(p,'r:gz') as t:
   base=p.name[:-6]; vcs=json.load(t.extractfile(base+'/.cargo_vcs_info.json'))['git']
   assert vcs['sha1']==source and not vcs.get('dirty'),(p,vcs)
   members={str(Path(m.name).relative_to(base)):hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
  result[p.name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'members':members}
 assert len(result)==len(set(names))==21
 return result
a=signature(s/('stable-target' if v=='stable' else 'target')/'release-check/package');b=signature(out/'package')
assert a.keys()==b.keys()
report={}
for n in a:
 x,y=a[n],b[n]
 different=[k for k in sorted(x['members'].keys()|y['members'].keys()) if x['members'].get(k)!=y['members'].get(k)]
 report[n]={'bytes':[x['bytes'],y['bytes']],'sha256':[x['sha256'],y['sha256']],'members':len(x['members']),'different_members':different}
(s/('repack-'+v+'.json')).write_text(json.dumps(report,indent=1))
print('archives',len(report),'identical',sum(x['sha256'][0]==x['sha256'][1] for x in report.values()))
assert all(not d['different_members'] and d['sha256'][0]==d['sha256'][1] for d in report.values())
