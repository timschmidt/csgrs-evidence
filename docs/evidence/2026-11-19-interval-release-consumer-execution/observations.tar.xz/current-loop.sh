set -euo pipefail
target="$1/root"
work="$1/work"
rust_programs=(user_path quickstart_current curve_interval_ranges)
run_dir="${work}/run"
mkdir -p "${run_dir}"
run() {
  local name="$1"
  shift
  printf '%-30s ' "${name}"
  (cd "${run_dir}" && "$@" > "${run_dir}/${name}.log" 2>&1) || {
    echo "FAILED"
    cat "${run_dir}/${name}.log"
    exit 1
  }
  echo "ok"
}
mapfile -d '' -t rust_binaries < "${work}/rust-binaries"
for i in "${!rust_programs[@]}"; do
  run "${rust_programs[i]}" "${rust_binaries[i]}"
done
for name in ffi_smoke cpp_smoke; do
  run "${name}" "${work}/${name}"
done

