from pathlib import Path
import json
from record import record
s=Path(__file__).resolve().parent
items={p for ext in ['*.log','*.py','*.txt','*.json','*.patch','old-loop.sh','current-loop.sh','env','source','receipts/*.json'] for p in s.glob(ext) if p.is_file()}
pack=record('release-consumer-execution',sorted(items),'Archive release smoke artifact selection and clean package verification')
(s/'receipt.json').write_text(json.dumps(pack,indent=1));print(pack)
