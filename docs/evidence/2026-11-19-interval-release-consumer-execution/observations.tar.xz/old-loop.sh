set -eu
target="$1/root"
work="$1/work"
run_dir="${work}/run"
mkdir -p "${run_dir}"
run() {
  local name="$1"
  shift
  printf '%-30s ' "${name}"
  (cd "${run_dir}" && "$@" > "${run_dir}/${name}.log" 2>&1) || {
    echo "FAILED"
    cat "${run_dir}/${name}.log"
    exit 1
  }
  echo "ok"
}
for binary in "${target}/consumer/debug/user_path" "${target}"/consumer/debug/quickstart_* \
    "${target}/consumer/debug/curve_interval_ranges" \
    "${work}/ffi_smoke" "${work}/cpp_smoke"; do
  [[ -x ${binary} && -f ${binary} ]] || continue
  run "$(basename "${binary}")" "${binary}"
done

