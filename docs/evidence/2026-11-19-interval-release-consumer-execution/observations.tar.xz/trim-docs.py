from pathlib import Path
import hashlib,json,re,shutil,sys,time,tarfile,tomllib
s=Path(__file__).resolve().parent;tag=sys.argv[1];target=s/('stable-target' if tag=='stable' else 'target')/'release-check'
log=s/('release-'+tag+'.log')
for _ in range(600):
 if log.is_file() and '== building the consumer against packaged sources' in log.read_text():break
 time.sleep(4)
else:sys.exit('consumer build not reached')
assert target.resolve().is_relative_to(s) and (target/'package').is_dir()
pages={}
for archive in (target/'package').glob('*.crate'):
 base=archive.name[:-6]
 with tarfile.open(archive) as t:meta=tomllib.loads(t.extractfile(base+'/Cargo.toml').read().decode())
 crate=meta['package']['name'];lib=meta.get('lib',{}).get('name',crate.replace('-','_'))
 index=target/'doc'/lib/'index.html';pages[crate]={'size':index.stat().st_size,'sha256':hashlib.sha256(index.read_bytes()).hexdigest()}
assert len(pages)==21
(s/'receipts'/('docs-'+tag+'.json')).write_text(json.dumps(pages,indent=1))
for path in [target/'doc',target/'debug']:shutil.rmtree(path)
print('saved 21 rendered index hashes and retired the workspace build before consumer and FFI verification')
