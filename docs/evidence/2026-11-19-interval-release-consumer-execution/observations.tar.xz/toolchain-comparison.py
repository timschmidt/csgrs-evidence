from pathlib import Path
import gzip,hashlib,json,tarfile,tomllib
s=Path(__file__).resolve().parent
def archive(p):
 with tarfile.open(p) as t:
  name=p.name[:-6]
  files={m.name[len(name)+1:]:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
  lock=tomllib.loads(t.extractfile(name+'/Cargo.lock').read().decode())
 return files,{(x['name'],x['version']):x for x in lock['package']}
rows={}
for p in (s/'repack-1.95.0/package').glob('*.crate'):
 q=s/'repack-stable/package'/p.name
 a,al=archive(p);b,bl=archive(q)
 keys=set(a)|set(b)
 rows[p.name]={'same_archive':p.read_bytes()==q.read_bytes(),'differing_members':[k for k in sorted(keys) if a.get(k)!=b.get(k)],'lock_only_1.95.0':sorted(al.keys()-bl.keys()),'lock_only_1.99.0':sorted(bl.keys()-al.keys()),'changed_lock_entries':sorted(k for k in al.keys()&bl.keys() if al[k]!=bl[k])}
 z=rows[p.name]
 z['tar_stream_identical']=gzip.decompress(p.read_bytes())==gzip.decompress(q.read_bytes())
 for k in z['changed_lock_entries']:
  x,y=al[k],bl[k];assert {key for key in set(x)|set(y) if x.get(key)!=y.get(key)}=={'checksum'}
  dep=k[0]+'-'+k[1]+'.crate'
  assert all(rt['checksum']==hashlib.sha256((here.parent/dep).read_bytes()).hexdigest() for rt,here in [(x,p),(y,q)])
 assert not z['lock_only_1.95.0'] and not z['lock_only_1.99.0']
 if not z['differing_members']:assert z['tar_stream_identical']
assert len(rows)==21
(s/'cross-compiler.json').write_text(json.dumps(rows,indent=1))
for k,x in rows.items():
 if not x['same_archive']:print(k,x['differing_members'],len(x['lock_only_1.95.0']),len(x['lock_only_1.99.0']),len(x['changed_lock_entries']))
