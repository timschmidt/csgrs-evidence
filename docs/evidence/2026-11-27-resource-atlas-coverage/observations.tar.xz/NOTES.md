# Quick resource atlas of every crate, 27 November 2026

`scripts/perf-atlas/run.sh --quick --resources` on csgrs `atlas-coverage`
(base-commit.txt), 40-thread Xeon E5-2680 v2, 84 minutes including release
builds. One JSON document per crate (24 crates); render with
`python3 scripts/perf-atlas/render.py OUT *.json`.

Each point is one warm call on a fresh input, measuring:

- peak, retained and residual heap;
- allocations, reallocations and bytes requested;
- stack high-water;
- result shape, where the atlas declares one.

Quick mode uses short batches and a 250 ms single-call ceiling, so the
measures are indicative.

Findings, with their targets, are in INTERVAL_REFACTOR_PROGRESS.md
("2026-11-27: atlases for every crate, and the first findings").
