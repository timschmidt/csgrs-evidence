from pathlib import Path
import os,json,statistics,subprocess
w=Path(os.environ['w'])
corpora={'cross-format':w/'fuzz-seeds','legacy':Path('/mnt/development/.interval-refactor-build/ieee-egress-fuzz-corpus')}
rows={}
for name,source in corpora.items():
 paths=sorted(str(p) for p in source.iterdir() if p.is_file())
 allvals={s:[] for s in ('fixed','original','expanded')}
 for i in range(5):
  order=list(allvals);order=order[i%3:]+order[:i%3]
  for stage in order:
   p=w/'images'/('fuzz-'+stage)
   with open(os.devnull,'w') as f:
    actions=[(os.POSIX_SPAWN_DUP2,f.fileno(),fd) for fd in (1,2)]
    pid=os.posix_spawn(str(p),[str(p),'-artifact_prefix='+str(w/'tmp')+'/', '-runs=1',*paths],dict(os.environ),file_actions=actions)
    _,status,usage=os.wait4(pid,0)
   assert status==0,(name,stage,status)
   allvals[stage].append([usage.ru_maxrss*1024,usage.ru_utime,usage.ru_stime])
 size=lambda s:max(x[0] for x in allvals[s]);a,b,c=map(size,('fixed','original','expanded'))
 prior=max(0,b-a);inc=max(0,c-b)
 ok=inc<=8<<20 and inc*100<=b*5 and prior+inc<=16<<20 and (prior+inc)*100<=a*10 and c<=768<<20
 rows[name]={'count':len(paths),'observations':allvals,'high_water':[a,b,c],'prior':prior,'increment':inc,'cumulative':prior+inc,'remaining_host_bytes':(1<<30)-c,'pass':ok}
 (w/'sanitizer-memory.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,[a,b,c],inc,prior+inc,ok,flush=True)
