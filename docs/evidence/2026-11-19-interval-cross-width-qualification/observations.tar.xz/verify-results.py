import os,json,hashlib,sys
from pathlib import Path
from collections import Counter
w=Path(os.environ['w'])
read=lambda p:json.loads(p.read_bytes())
r={}
old=read(w/'true-legacy.json');new=read(w/'corpus.json')
assert [row for row in new['cases'] if row[1]!=21]==old['cases']
assert new['lattice']==old['lattice']
legacykeys={tuple(row[:-1]) for row in old['properties']}
assert [r for r in new['properties'] if tuple(r[:-1]) in legacykeys]==old['properties']
counts=Counter((v[0],v[8]) for v in new['cases'] if v[1]==21)
for d in list(w.glob('final-*'))+list(w.glob('extended-*-wasi')):
 if not (d/'report.json').is_file():continue
 rep=read(d/'report.json');tag=d.name;prefix='replay-'+tag+'-'
 results={k:read(w/'logs'/(prefix+k)) for k in ['arithmetic','browser','stack-existing','stack-conversion','stack-expanded','lattice','egress']}
 assert all(results['arithmetic'][k]==results['browser'][k]==rep[k] for k in ('counts','statuses','seed','cases','properties','endpoint_traps','imports'))
 assert results['egress']==rep['dyadic'] and results['lattice']==rep['lattice']
 assert not rep['floating_arithmetic'] and not rep['memory_grow']
 assert rep['guest_stack']==results['stack-expanded']
 for t in ('stack-existing','stack-conversion','stack-expanded'):
  rows=results[t];assert len(rows)==4 and len({(x['sentinel'],x['temperature']) for x in rows})==4
  assert max(x['reservedBytes'] for x in rows)<= (1024 if t=='stack-conversion' else 704)
  assert all(x['stackBytes']==1<<20 for x in rows)
 assert rep['cases']==61575 and rep['properties']==13866 and rep['endpoint_traps']==38
 r[tag]={'report_sha256':hashlib.sha256((d/'report.json').read_bytes()).hexdigest(),
          'corpus_sha256':rep['corpus_sha256'],'binary_sha256':rep['binary_sha256'],'browser':results['browser']['browser']['product'],
          'stack_bytes':{k:[max(x['touchedBytes'] for x in v),max(x['reservedBytes'] for x in v)] for k,v in results.items() if k.startswith('stack-')},'fixed_lattice':rep['fixed_lattice'],'dyadic':rep['dyadic']}
assert len(r)==6
assert len({v['corpus_sha256'] for v in r.values()})==1
for p in (w/'logs').glob('verified-*-*-*'):
 if p.stat().st_size:
  j=read(p);assert j['endpoint_traps']==16 and j['empty']==1 and j['status']==21
r={'targets':r,'corpus':{'existing':len(old['cases']),'added':sum(counts.values()),'retained_properties':len(old['properties']),'cases_by_source_width_and_status':{str(k):v for k,v in sorted(counts.items())}},
   'old_corpus_sha256':hashlib.sha256((w/'true-legacy.json').read_bytes()).hexdigest()}
(w/'verification.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['corpus'])
