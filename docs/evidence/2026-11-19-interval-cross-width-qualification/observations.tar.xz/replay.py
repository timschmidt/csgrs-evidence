from pathlib import Path
import os,subprocess,json,sys
from concurrent.futures import ThreadPoolExecutor
w=Path(os.environ['w'])
d=Path('crates/hyperinterval/conformance/wasm-float')
directories=[w/('final-'+t) for t in ('1.88.0','1.95.0','stable','wasi')]+[w/('extended-'+t+'-wasi') for t in ('stable','1.88.0')]
def run(directory):
 tag=directory.name;wasi='wasi' in tag
 def call(name,args):
  out=w/'logs'/('replay-'+tag+'-'+name)
  with out.open('w') as stdout,out.with_suffix('.stderr').open('w') as stderr:
   subprocess.run(['node',*args],check=True,stdout=stdout,stderr=stderr)
 args=['--wasi-p1'] if wasi else []
 for mode,guest in [('arithmetic','interval_float'),('lattice','interval_layout'),('egress','interval_dyadic')]:
  call(mode,[d/'check.mjs',directory/(guest+'.wasm'),directory/'corpus.json',*(['--'+mode] if mode!='arithmetic' else []),*args])
 for part,corpus in [('existing','true-legacy'),('conversion','conversions'),('expanded','corpus')]:
  call('stack-'+part,[d/'stack.mjs',directory/'interval_float.wasm',directory/'module.wat',w/(corpus+'.json')])
 call('browser',[d/'browser.mjs',directory/'interval_float.wasm',directory/'corpus.json'])
with ThreadPoolExecutor(3) as pool:list(pool.map(run,directories))
