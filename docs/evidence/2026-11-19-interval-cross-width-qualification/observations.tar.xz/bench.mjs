import {readFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {verifyInstance as previous} from './previous-check.mjs';
const {verifyInstance:current}=await import(pathToFileURL(process.cwd()+'/crates/hyperinterval/conformance/wasm-float/check.mjs'));
const w=process.env.w;
const legacy=JSON.parse(readFileSync(w+'/true-legacy.json')),added=JSON.parse(readFileSync(w+'/conversions.json'));
const modules=await Promise.all(['before','separate'].map(t=>WebAssembly.compile(readFileSync(w+'/images/'+t+'-1.95.0.wasm'))));
const reference=previous((await WebAssembly.instantiate(modules[0])).exports,legacy);
assert.deepEqual(current((await WebAssembly.instantiate(modules[1])).exports,legacy),reference);
let rows=[],sink=0;
async function run(which,corpus=legacy){
  const start=process.cpuUsage();
  const api=(await WebAssembly.instantiate(modules[which])).exports;
  const r=(which?current:previous)(api,corpus);
  const t=process.cpuUsage(start);
  sink+=r.cases+r.properties;
  if(corpus===legacy) assert.deepEqual(r,reference);
  return t.user+t.system;
}
for(let i=0;i<4;i++)await run(i%2);
for(let i=0;i<32;i++){
 const observations=[[],[]];
 for(const v of (i+Number(process.argv[2]))%2?[0,1,1,0]:[1,0,0,1]) observations[v].push(await run(v));
 rows.push(observations);
}
const conversionTimes=[];for(let i=0;i<12;i++)conversionTimes.push(await run(1,added));
console.log(JSON.stringify({rows,conversionTimes,sink,unit:'process CPU microseconds',cases:reference.cases,properties:reference.properties}));
