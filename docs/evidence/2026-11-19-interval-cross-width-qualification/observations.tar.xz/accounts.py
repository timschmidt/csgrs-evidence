from pathlib import Path
import os,sys,subprocess,json,tarfile,shutil,hashlib
w=Path(os.environ['w']);repo=Path.cwd();snap=w/'account-src';out=w/'account-target'
source=(w/'metrics.py').read_text()
exec('def wasm(p):'+source.split('def wasm(p):')[1].split('def compare(')[0],globals())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
targets=[(tc,arch,feature) for tc in ('1.88.0','1.95.0','stable') for arch,feature in [('wasm32-unknown-unknown','default'),('wasm32-wasip1','default'),('wasm32-wasip1','opt-in')]]
targets += [('1.95.0','wasm32-wasip1-threads',f) for f in ['default','opt-in']]
d=snap/'crates/hyperinterval/conformance/wasm-float'
data={}
for stage,ref in [('fixed','c9f1f9ac5'),('opt-in-intro','d1a81beae'),('previous','26bfa1093'),('expanded','26bfa1093')]:
 if snap.is_dir():shutil.rmtree(snap)
 snap.mkdir()
 with subprocess.Popen(['git','archive',ref,'crates/hyperinterval','crates/hyperreal'],stdout=subprocess.PIPE) as git:
  subprocess.run(['tar','-xm','-C',snap],stdin=git.stdout,check=True);assert git.wait()==0
 if stage=='expanded':shutil.copy(repo/d.relative_to(snap)/'src/lib.rs',d/'src/lib.rs')
 for tc,arch,feature in targets:
  if stage=='fixed' and feature=='opt-in' or stage=='opt-in-intro' and feature=='default': continue
  sysroot=w/('wasi-lib' if tc=='1.95.0' and arch=='wasm32-wasip1' else 'sysroot-'+tc)
  env=os.environ|{'CARGO_TARGET_DIR':str(out/tc)}
  if 'wasip1' in arch:env['CARGO_TARGET_'+arch.upper().replace('-','_')+'_RUSTFLAGS']='--sysroot '+str(sysroot)
  cmd=['cargo','+'+tc,'build','--locked','--release','--target',arch,'--manifest-path',str(d/'Cargo.toml')]
  if feature=='opt-in':cmd+=['--features','float-enclosure-wasip1']
  subprocess.run(cmd,check=True,env=env,stdout=sys.stderr)
  p=out/tc/arch/'release/interval_float_wasm_conformance.wasm'
  key='/'.join([tc,arch,feature]);data.setdefault(key,{})[stage]=wasm(p)
  print(stage,key,data[key][stage]['bytes'],flush=True)
 (w/'raw-accounts.json').write_text(json.dumps(data,indent=2)+'\n')
