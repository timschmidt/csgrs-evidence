from pathlib import Path
import os,json,tarfile,io,hashlib,lzma
w=Path(os.environ['w'])
dest=Path('../csgrs-evidence/docs/evidence/2026-11-19-interval-cross-width-qualification')
dest.mkdir(parents=True,exist_ok=True)
members={}
def add(p,k):
 if p.is_file() and not p.is_symlink():
  b=p.read_bytes();assert not b.startswith((b'\x00asm',b'\x7fELF'))
  members[k]=b
for pat in ['*.py','*.rs','*.mjs','*.txt','*.json','env','build','wasi-build','more-wasi','run-guest','fuzz-build','fuzz-qualify','setup-fuzz','bad-narrow','bad-widen','bin/chromium-local','logs/*','smoke/*','final-*/report.json','extended-*/report.json','final-*/commands.json','extended-*/commands.json']:
 for p in w.glob(pat):
  if p.name not in ('corpus.json','legacy.json','true-legacy.json','conversions.json'):add(p,str(p.relative_to(w)))
for p in Path('/mnt/development/.interval-refactor-build/ieee-egress-fuzz-corpus').iterdir():add(p,'retained-corpus/'+p.name)
with tarfile.open(dest/'observations.tar.xz','w:xz',preset=6) as t:
 for k,b in sorted(members.items()):
  item=tarfile.TarInfo(k);item.size=len(b);item.mode=0o644;t.addfile(item,io.BytesIO(b))
hashes={k:hashlib.sha256(b).hexdigest() for k,b in sorted(members.items())}
(dest/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(hashes,indent=1)+'\n').encode()))
print(len(hashes),sum(p.stat().st_size for p in dest.iterdir()))
