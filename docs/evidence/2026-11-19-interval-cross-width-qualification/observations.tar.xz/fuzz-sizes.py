import json,os,subprocess,hashlib
from pathlib import Path
w=Path(os.environ['w'])
def metrics(stage):
 p=w/('images/fuzz-'+stage);syms={}
 for line in subprocess.check_output(['nm','-S','--defined-only',p],text=True).splitlines():
  f=line.split(maxsplit=3)
  if len(f)!=4 or f[2] not in ('T','t'):continue
  addr,size=int(f[0],16),int(f[1],16)
  assert addr not in syms or syms[addr]==size
  syms[addr]=size
 lines=subprocess.check_output(['size','-A',p],text=True).splitlines()
 t=next(int(l.split()[1]) for l in lines if l.startswith('.text '))
 return dict(file=p.stat().st_size,code=t,functions=sum(syms.values()),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
f,a,b=[metrics(stage) for stage in ('fixed','original','expanded')]
rows={k:{'preceding':a[k],'expanded':b[k],'positive':max(0,b[k]-a[k])} for k in ('file','code','functions')}
for key,r in rows.items():
 print(key,r)
 r['fixed']=f[key];r['prior']=max(0,a[key]-f[key]);r['cumulative']=r['prior']+r['positive']
 assert r['cumulative']<=512*1024 and r['cumulative']*100<=4*f[key]
 assert r['positive']<=256*1024 and r['positive']*100<=2*r['preceding']
assert (128<<20)-b['file']>=32<<20
(w/'fuzz-sizes.json').write_text(json.dumps({'fixed':f,'baseline':a,'candidate':b,'metrics':rows,'file_headroom':(128<<20)-b['file']},indent=2)+'\n')
