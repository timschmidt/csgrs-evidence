from pathlib import Path
import hashlib,json,re,subprocess,sys,statistics,importlib.util
w=Path(sys.argv[1]);root=Path.cwd()
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def elf(p):
    out=subprocess.check_output(['readelf','-SW',p],text=True)
    sizes={m[1]:int(m[2],16) for l in out.splitlines() if (m:=re.search(r'\[\s*\d+\]\s+(\S+)\s+\S+\s+[0-9a-f]+\s+[0-9a-f]+\s+([0-9a-f]+)\s+\w+\s+(\S+)',l)) and 'A' in m[3]}
    symbols=subprocess.check_output(['nm','-S','--defined-only',p],text=True)
    sizes['named-code']=sum(int(m[1],16) for l in symbols.splitlines() if (m:=re.match(r'\S+ (\S+) [tTwW] ',l)))
    sizes['file']=p.stat().st_size
    return {'sha256':digest(p),'bytes':sizes}
def wasm(p):
    b=p.read_bytes();i=8
    def leb():
        nonlocal i
        n=0;shift=0
        while True:
            x=b[i];i+=1;n|=(x&127)<<shift;shift+=7
            if x<128:return n
    sizes={'file':len(b)}
    while i<len(b):
        k=b[i];i+=1;n=leb();end=i+n
        if k==10:
            sizes['code']=n;count=leb();sizes['bodies']=0
            for _ in range(count):
                body=leb();i+=body;sizes['bodies']+=body
            assert i==end
        i=end
    return {'sha256':digest(p),'bytes':sizes}
def compare(a,b):
    la=a['bytes'];lb=b['bytes']
    return {'before':a,'after':b,'delta':{k:lb.get(k,0)-la.get(k,0) for k in sorted(la.keys()|lb.keys()) if la.get(k,0)!=lb.get(k,0)}}
spec=importlib.util.spec_from_file_location('check_interval_wasm',root/'scripts/check_interval_wasm.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results={}
for version in ['1.88.0','1.95.0','stable']:
    results[version+' existing bare wasm']=compare(*[wasm(w/f'{version}-{s}-client.wasm') for s in ['before','after']])
    wat=(w/f'{version}-format.wat').read_text()
    forbidden=m.floating_operations(wat);assert not forbidden and 'memory.grow' not in wat and '(import ' not in wat
    results[version+' format bare wasm']={**wasm(w/f'{version}-format.wasm'),'forbidden_float_ops':forbidden,'memory.grow':False,'imports':False}
for name in ['float','rational_float_projection','dyadic_float_egress','dyadic_float_ingress']:
    results['x86_64 '+name]=compare(*[elf(w/(s+'-test-'+name)) for s in ['before','after']])
results['x86_64 float_cost']=compare(*[elf(w/(s+'-cost')) for s in ['before','after']])
results['x86_64 mixed conversion client']=compare(*[elf(w/(s+'-client')) for s in ['bridge','direct']])
for s in ['default','qualified']:results['WASI '+s]=wasm(w/f'wasi-{s}.wasm')
a=(w/'before-cost.csv').read_text().splitlines();b=(w/'after-cost.csv').read_text().splitlines()
def work(row):
    fields=row.split(','); return fields[:2]+fields[3:]
assert list(map(work,a))==list(map(work,b))
results['float_cost comparison']={'matching_samples':len(a)-1}
for s in ['bridge','direct']:
    rows=[dict(re.findall(r'(\w+)=(\d+)',line)) for line in (w/(s+'-paired.log')).read_text().splitlines()]
    assert len(rows)==5
    results[s+' roundtrip']={'samples':rows,'median_ns':statistics.median(int(r['elapsed_ns']) for r in rows)}
assert results['bridge roundtrip']['samples'][0]['checksum']==results['direct roundtrip']['samples'][0]['checksum']
print(json.dumps(results,indent=2,sort_keys=True))
