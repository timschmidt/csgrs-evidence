from pathlib import Path
import os,json,struct
w=Path(os.environ['w']);d=w/'fuzz-seeds';d.mkdir(exist_ok=True)
# Lift exact ABI inputs from the independent WebAssembly oracle into the native
# fuzz target's four-word input. The other two words exercise existing checks.
for row in json.loads((w/'conversions.json').read_bytes())['cases']:
 width,_,flags,a,b,c,dummy,_,status,*ends=row
 if flags or status not in (0,18):continue
 v=struct.pack('<QQQQ',int(a,16),int(b,16),int(c,16),int(dummy,16))
 import hashlib
 (d/hashlib.sha1(v).hexdigest()).write_bytes(v)
for title,words in [('bad-narrow',[1,1]),('bad-widen',[0x3f800000,0x3f800001])]:
 (w/title).write_bytes(struct.pack('<QQQQ',*words,0,0))
print('distinct oracle seeds',len(list(d.iterdir())))
