from pathlib import Path
import os,shutil,subprocess
w=Path(os.environ['w']);root=Path.cwd();c=root/'crates/hyperinterval/conformance/wasm-float'
src=w/'mutant-src';shutil.copytree(root/'crates/hyperinterval/src',src)
code=(src/'float.rs').read_text()
patches={
'narrow-up':('BINARY32.enclose_from(BINARY64, hi)?.1','BINARY32.enclose_from(BINARY64, hi)?.0'),
'widen-upper':('BINARY64.enclose_from(BINARY32, hi)?.1','BINARY64.enclose_from(BINARY32, lo)?.1'),
}
for trial,(old,new) in patches.items():
 assert code.count(old)==1
 (src/'float.rs').write_text(code.replace(old,new))
 flags=['rustc','+1.95.0','--edition=2024','--target','wasm32-unknown-unknown','-C','opt-level=3','-C','panic=abort','-C','overflow-checks=yes']
 with (w/'logs'/('mutation-build-'+trial)).open('w') as log:
  subprocess.run(flags+['--crate-type','rlib','--crate-name','hyperinterval','--cfg','feature="float-enclosure"',src/'lib.rs','-o',w/'libhyperinterval.rlib'],check=True,stderr=log)
  subprocess.run(flags+['--crate-type','cdylib','--crate-name','mutation_conformance',c/'src/lib.rs','--extern','hyperinterval='+str(w/'libhyperinterval.rlib'),'-o',w/(trial+'.wasm')],check=True,stderr=log)
 for mode,js,corpus in [('old',w/'previous-check.mjs',w/'true-legacy.json'),('new',c/'check.mjs',w/'corpus.json')]:
  # Import as a module so the archived verifier runs under its alternate name.
  prog='import fs from "node:fs";import {pathToFileURL} from "node:url";const {verify}=await import(pathToFileURL(process.argv[1]));console.log(JSON.stringify(await verify(fs.readFileSync(process.argv[2]),JSON.parse(fs.readFileSync(process.argv[3])))))'
  result=subprocess.run(['node','--input-type=module','-e',prog,js,w/(trial+'.wasm'),corpus],text=True,capture_output=True)
  (w/'logs'/('mutation-'+trial+'-'+mode)).write_text(result.stdout+result.stderr)
  if mode=='old':assert result.returncode==0,result.stderr
  else:assert result.returncode!=0 and 'bits [' in result.stderr,result.stderr
