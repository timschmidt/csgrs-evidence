from pathlib import Path
import os,json,random,statistics
w=Path(os.environ['w']);raw=json.loads((w/'raw-accounts.json').read_text())
historic=json.loads((w/'accounts.json').read_bytes())['wasm_1_95']
out={}
for key,stages in raw.items():
 f=stages.get('fixed',stages.get('opt-in-intro'))
 a,b=stages['previous'],stages['expanded'];rows={}
 for k,c in b['bytes'].items():
  ref,prev=f['bytes'][k],a['bytes'][k]
  carry=max(0,prev-ref)
  if key=='1.95.0/wasm32-unknown-unknown/default':
   hk='function_bodies' if k=='bodies' else k
   if hk not in historic:hk='functions'
   carry=max(carry,historic.get(hk,{}).get('cumulative',0))
  inc=max(0,c-prev);total=carry+inc
  assert inc<=4096 and inc*100<=prev*8 and total<=8192 and total*100<=ref*12,(key,k,inc,total)
  rows[k]={'fixed':ref,'preceding':prev,'expanded':c,'increment':inc,'prior':carry,'cumulative':total,'step_remaining':min(4096,prev*8//100)-inc,'cumulative_remaining':min(8192,ref*12//100)-total}
 headroom=4*1024*1024-b['bytes']['file']
 assert headroom>=1024*1024
 out[key]={'fixed_revision':'c9f1f9ac5' if 'fixed' in stages else 'd1a81beae','metrics':rows,'headroom':headroom,'sha256':b['sha256']}
(w/'qualification.json').write_text(json.dumps(out,indent=2)+'\n')
def timing(j):
 r=random.Random(71);ds=[100*(statistics.mean(b)/statistics.mean(a)-1) for a,b in j['rows']];boot=sorted(statistics.median(r.choices(ds,k=len(ds))) for _ in range(3000))
 return {'median_percent':statistics.median(ds),'bootstrap95':[boot[75],boot[2924]],'additional_conversion_median_us':statistics.median(j['conversionTimes'])}
times={p.stem:timing(json.loads(p.read_bytes())) for p in w.glob('timing-*.json')}
(w/'timing-summary.json').write_text(json.dumps(times,indent=2)+'\n')
for k,v in out.items():print(k,v['metrics']['file']['increment'],v['metrics']['file']['cumulative'],v['metrics']['code']['increment'])
