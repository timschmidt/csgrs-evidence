from pathlib import Path
import sys,os,json,statistics,shutil,resource
w=Path(os.environ['w']);old=w/'images/fuzz-original';new=w/'images/fuzz-expanded'
seeds=sorted((w/'fuzz-seeds').iterdir());legacy=sorted(p for p in Path('/mnt/development/.interval-refactor-build/ieee-egress-fuzz-corpus').iterdir() if p.is_file())
out={}
def run(tag,image,arguments):
 stdout=w/'logs'/('campaign-'+tag)
 with stdout.open('w') as f:
  actions=[(os.POSIX_SPAWN_DUP2,f.fileno(),fd) for fd in (1,2)]
  argv=list(map(str,[image,'-artifact_prefix='+str(w/'tmp')+'/',*arguments]))
  pid=os.posix_spawn(str(image),argv,dict(os.environ),file_actions=actions)
  _,status,usage=os.wait4(pid,0)
 assert status==0,(tag,os.waitstatus_to_exitcode(status))
 out[tag]={'rss':usage.ru_maxrss*1024,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime}
 return stdout.read_text()
for tag,revision in [('original',old),('expanded',new)]:
 for corpus,files in [('cross-format',seeds),('legacy',legacy)]:
  log=run(tag+'-'+corpus,revision,['-runs=1',*files])
  assert all('Executed '+str(f) in log for f in files),(tag,corpus,len(files))
d=w/'smoke';d.mkdir(exist_ok=True)
run('fresh',new,[d,'-runs=100000','-max_len=32','-max_total_time=30','-seed=20261114','-print_final_stats=1'])
(w/'campaign-statistics.json').write_text(json.dumps({'runs':out,'cross_format_files':len(seeds),'legacy_files':len(legacy),'fresh_corpus_files':len(list(d.iterdir()))},indent=2)+'\n')
