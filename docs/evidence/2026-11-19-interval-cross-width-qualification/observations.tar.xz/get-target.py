import sys,tomllib,subprocess,hashlib,tarfile,shutil
from pathlib import Path
import os
w=Path(os.environ['w']);tc,arch=sys.argv[1:]
tool=Path(subprocess.check_output(['rustc','+'+tc,'--print','sysroot'],text=True).strip())
entry=tomllib.loads((tool/'lib/rustlib/multirust-channel-manifest.toml').read_text())['pkg']['rust-std']['target'][arch]
blob=w/(tc+'-'+arch+'.tar.xz')
subprocess.run(['curl','--fail','-sSL',entry['xz_url'],'-o',blob],check=True)
assert hashlib.sha256(blob.read_bytes()).hexdigest()==entry['xz_hash']
d=w/('sysroot-'+tc);d.mkdir(exist_ok=True)
subprocess.run(['tar','xJf',blob,'-C',d,'--wildcards','--strip-components=2','*/rust-std-'+arch+'/lib/rustlib/'+arch],check=True)
print(entry['xz_url'],entry['xz_hash'])
