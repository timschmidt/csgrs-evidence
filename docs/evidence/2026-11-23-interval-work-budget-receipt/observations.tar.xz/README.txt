Exact work-budget receipts (csgrs 777d6abd5 against 0fb217b13), 23 November 2026.
sizes-default-profile.json: hypersolve and hyperdynamics benches, examples and library tests, Rust 1.100.0, all
  features, default release/bench profiles, both revisions at /mnt/development/.rc-wt with one target directory (collect.sh).
sizes-lib-test-one-codegen-unit.json: the hypersolve library test harness rebuilt with codegen-units=1 (diagnostic).
lib-test-symbol-diff.txt: demangled symbol additions/removals in the default-profile library test harness.
var.sh: behavior-identical variants measured on the library test harness (inline hints, non-const accessors, derived Debug view).
interface-run-45152553294-sizes.txt: trunk release sizes from receipt-size.yml on alumina-interface ef5061183 (temporary branch, deleted).
ledger_receipt.py: the text splice that recorded these charges in docs/research/interval-size-accounts.json.
native-tests.log: cargo test --all-features -p hypersolve -p hypercurve -p hyperbrep -p hyperdrc, plus tests/svg_selected_replay.
