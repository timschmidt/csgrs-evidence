#!/bin/bash
# var.sh NAME : build hypersolve lib test from current .rc-wt tree, print size deltas vs base
cd /mnt/development/.rc-wt; export CARGO_TARGET_DIR=/mnt/development/.rc-target
cargo test --locked -q --release -p hypersolve --all-features --lib --no-run --message-format=json 2>/dev/null | python3 -c "
import json,sys,shutil
for l in sys.stdin:
    r=json.loads(l)
    if r.get('reason')=='compiler-artifact' and r.get('executable'): shutil.copy(r['executable'],'/mnt/development/.rc-bins/var-$1')
"
python3 - <<PY
import sys; sys.path.insert(0,'/tmp/claude-1000/-mnt-development/374ec7d8-3b58-4db7-a419-a5fe884f8bb0/scratchpad/be/prev')
import importlib.util
spec=importlib.util.spec_from_file_location('s','/tmp/claude-1000/-mnt-development/374ec7d8-3b58-4db7-a419-a5fe884f8bb0/scratchpad/be/prev/sizes.py')
src=open(spec.origin).read().split('d=Path(sys.argv[1])')[0]
exec(src)
from pathlib import Path
a=sizes(Path('/mnt/development/.rc-bins/lib.hypersolve.lib.test-base')); c=sizes(Path('/mnt/development/.rc-bins/var-$1'))
print('$1', {k:c[k]-a[k] for k in a})
PY
