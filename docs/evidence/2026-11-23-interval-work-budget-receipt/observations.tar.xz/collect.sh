#!/bin/bash
# collect.sh REV TAG : at one fixed worktree path and target dir, build hypersolve and
# hyperdynamics benches, examples and lib tests (all features, default profiles) and copy them.
set -e; rev=$1; tag=$2; W=/mnt/development/.rc-wt; B=/mnt/development/.rc-bins; export CARGO_TARGET_DIR=/mnt/development/.rc-target
mkdir -p $B; cd $W; git checkout -q --detach $rev; rm -f $B/*-$tag
for p in hypersolve hyperdynamics; do
{ cargo bench --locked -q -p $p --all-features --no-run --message-format=json; cargo build --locked -q --release -p $p --all-features --examples --message-format=json; cargo test --locked -q --release -p $p --all-features --lib --no-run --message-format=json; } 2>/dev/null | P=$p B=$B T=$tag python3 -c "
import json,sys,shutil,os
for l in sys.stdin:
    r=json.loads(l)
    if r.get('reason')=='compiler-artifact' and r.get('executable'):
        k=r['target']['kind'][0]; n=r['target']['name']; prof='test' if r['profile']['test'] else 'x'
        if k=='lib': n='lib'
        shutil.copy(r['executable'], f\"{os.environ['B']}/{k}.{os.environ['P']}.{n}.{prof}-{os.environ['T']}\")
"
done
ls $B | grep -c -- "-$tag\$"
