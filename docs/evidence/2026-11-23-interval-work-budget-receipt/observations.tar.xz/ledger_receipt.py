"""Splice work-budget-receipt size charges into interval-size-accounts.json (text splice, no re-dump)."""
import json, sys
p, sizes_path = sys.argv[1], sys.argv[2]
s = open(p).read(); d = json.loads(s); m = json.load(open(sizes_path))
BEFORE = "0fb217b13f3539bf4ddf6dcb089b9f01b2b3b6d9"; AFTER = "777d6abd5a4d86c45bc5b30d1029a59a94959750"
CHANGE = "work-budget-receipt"
METHOD = ("Rust 1.100.0, all features, default release/bench profiles; both revisions built at one checkout path "
          "and target directory. Each charge is the positive difference between adjacent csgrs revisions, never offset.")
IFACE_METHOD = ("Rust 1.100.0 stable, trunk 0.21.14 --locked, wasm-opt and wasm-tools from taiki-e/install-action, Interface "
                "ef5061183 and firmware 9c874b2b8; hosted CI run 45152553294 on a temporary branch since deleted.")
def path(k):
    kind, pkg, name, _ = k.split('.')
    return {'bench': f'crates/{pkg}/benches/{name}.rs', 'example': f'crates/{pkg}/examples/{name}.rs', 'lib': f'crates/{pkg}/src/lib.rs'}[kind]
measured = {}
for k, v in m.items():
    measured[path(k)] = {met: (v['base'][met], v['cand'][met]) for met in ('file', 'text', 'named_text')}
iface = {
    'alumina-interface#wasm-raw': {'file': (13467924, 13466989), 'emitted_code': (10519900, 10519008)},
    'alumina-interface#wasm-final': {'file': (10663025, 10662096), 'emitted_code': (8631200, 8630316)},
    'alumina-interface#wasm-gzip': {'file': (4565088, 4564536)},
    'alumina-interface#wasm-brotli': {'file': (3507856, 3507086)},
}
def block(obj, indent):
    t = json.dumps(obj, indent=2, ensure_ascii=False)
    return '\n'.join(' ' * indent + l if i else l for i, l in enumerate(t.split('\n')))
def match(s, i, open_c, close_c):
    depth = 0; j = i; ins = False; esc = False
    while True:
        c = s[j]
        if ins:
            if esc: esc = False
            elif c == '\\': esc = True
            elif c == '"': ins = False
        elif c == '"': ins = True
        elif c == open_c: depth += 1
        elif c == close_c:
            depth -= 1
            if depth == 0: return j
        j += 1
accounts = {a['artifact']: a for a in d['accounts'] if 'metrics' in a}
charged, failing, unchanged, unaccounted = [], [], [], []
for art, mets in list(measured.items()) + list(iface.items()):
    a = accounts.get(art)
    if a is None:
        if any(b != c for b, c in mets.values()): unaccounted.append(art)
        continue
    if all(b == c for b, c in mets.values()):
        unchanged.append(art); continue
    entries = []
    for met, (b, c) in mets.items():
        if met not in a['metrics']: continue
        mm = a['metrics'][met]; caps = mm['caps']; delta = c - b; pct = round(100 * delta / b, 6)
        later = [x for x in a.get('subsequent_charges', []) if x['metric'] == met]
        if later and 'cumulative_charged_bytes' in later[-1]:
            prior = later[-1]['cumulative_charged_bytes']
        elif 'remaining_cumulative_bytes' in mm:
            prior = caps['cumulative_bytes'] - mm['remaining_cumulative_bytes']
        else:
            prior = mm.get('accepted_positive_growth_bytes', 0) + sum(x.get('charged_bytes', 0) for x in later)
        ch = max(0, delta); cum = prior + ch
        ok_inc = delta <= caps['incremental_bytes'] and pct <= caps['incremental_percent']
        ok_cum = cum <= caps['cumulative_bytes'] and 100 * cum / mm['baseline'] <= caps['cumulative_percent']
        if not (ok_inc and ok_cum): failing.append((art, met, delta, cum, caps))
        entries.append({"change": CHANGE, "metric": met, "csgrs_before": BEFORE, "csgrs_after": AFTER, "before": b, "after": c,
                        "incremental_growth_bytes": delta, "incremental_growth_percent": pct, "charged_bytes": ch,
                        "passes_incremental_caps": ok_inc, "cumulative_charged_bytes": cum, "passes_cumulative_caps": ok_cum})
    key = f'"artifact": "{art}"'
    assert s.count(key) == 1, key
    i = s.index(key); start = s.rindex('{', 0, i); end = match(s, start, '{', '}')
    obj = s[start:end + 1]
    if '"subsequent_charges": [' in obj:
        li = start + obj.index('"subsequent_charges": [') + len('"subsequent_charges": ')
        lj = match(s, li, '[', ']')
        k = s.rindex('}', li, lj) + 1
        s = s[:k] + ''.join(',\n        ' + block(e, 8) for e in entries) + s[k:]
    else:
        meth = IFACE_METHOD if art.startswith('alumina') else METHOD
        ins = ',\n      "subsequent_charge_method": ' + json.dumps(meth) + ',\n      "subsequent_charges": [\n        ' + ',\n        '.join(block(e, 8) for e in entries) + '\n      ]'
        k = s.rindex('\n', start, end)
        s = s[:k] + ins + s[k:]
    charged.append(art)
json.loads(s)
open(p, 'w').write(s)
print('charged', len(charged)); print('failing', failing); print('unchanged', len(unchanged)); print('unaccounted', unaccounted)
