"""Complete consumer qualification using only the independently audited fixture overlay."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'native-aggregation-candidate-v2';T=N/'targets/native-aggregation-candidate-v2'
A=N/'native-aggregation-flat-package-diagnosis-v1';new=A/'left.zip'
fixture='crates/hypercircuit/tests/fixtures/manufacturing-release/release-board-v1.zip'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-source-v1.json.gz').read_bytes()))
audit=json.loads((A/'migration-audit-v1.json').read_text());assert audit['exact_zip_reconstructed_from_declared_changes']
assert sha(new)==audit['new_zip_sha256'] and sha(S/fixture)==audit['old_zip_sha256']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
failed=N/'logs/aggregation-flat-circuit-all-v1';assert json.loads((failed/'result.json').read_text())['exit_code']==101
executed=re.findall(r'^\s*Running [^\n]* \(([^\n)]+)\)$',(failed/'stderr').read_text(),re.M)
assert len(executed)==46, len(executed)
executed.append(str(T/'release/hypercircuit'));binary_pins={p:sha(p) for p in executed}
workflow=next(Path(p) for p in executed if Path(p).name.startswith('workflow-'))
copy=A/'failed-workflow-test-image';assert not copy.exists();shutil.copy2(workflow,copy);assert sha(copy)==binary_pins[str(workflow)]
commands={};counts={};local=[]
protocol=N/'native-aggregation-flat-package-continuation-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'source_inventory_sha256':sha(N/'native-aggregation-flat-source-v1.json.gz'),'overlay':{'logical_path':str(S/fixture),'physical_path':str(new),'sha256':sha(new),'old_sha256':sha(S/fixture)},'migration_audit_sha256':sha(A/'migration-audit-v1.json'),'failed_command_sha256':sha(failed/'result.json'),'executed_binary_sha256':binary_pins,'original_test_source_unchanged':True,'existing_source_snapshot_unchanged':True})
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert sha(new)==audit['new_zip_sha256']
    assert all(sha(p)==h for p,h in binary_pins.items())
def execute(label,args):
    verify();name='aggregation-flat-circuit-'+label+'-v2';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--ro-bind',str(new),str(S/fixture),'--chdir',str(S)]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    commands[label]=run(name,argv+args,S,target=T);verify()
    dump(N/'native-aggregation-flat-package-continuation-progress-v1.json',commands)
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',err)
    return out
out=execute('all-migrated',[cargo,'test','--locked','--release','-p','hypercircuit','--all-features','--message-format=json','--','--test-threads=1'])
rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
assert rows and all(r[0]=='ok' and r[2:]==('0','0','0','0') for r in rows)
assert sum(int(r[1]) for r in rows)==348
for line in out.splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='compiler-artifact' and r.get('manifest_path','').startswith(str(S)):
        local.append({'manifest':r['manifest_path'],'target':r['target']['name'],'fresh':r['fresh']})
assert local and all(r['fresh'] for r in local)
execute('clippy',[cargo,'clippy','--locked','-p','hypercircuit','--all-targets','--all-features','--','-D','warnings'])
commands['default']=json.loads((N/'logs/aggregation-flat-circuit-default-v1/result.json').read_text())
assert commands['default']['exit_code']==0
record={'complete_for_declared_scope':True,'commands':commands,'test_counts':{'default':105,'all':348},'all_prior_test_images_unchanged':True,'all_local_compiler_artifacts_fresh':local,'source_unchanged':True,'fixture_overlay_qualified':protocol.name,'previous_failed_all_feature_run_preserved':True,'no_test_assertion_changes':True,'full_plan_complete':False}
dump(N/'native-aggregation-flat-circuit-result-v2.json',record)
old=json.loads((N/'native-aggregation-flat-continuation-v1.json').read_text());assert not old['complete']
dump(N/'native-aggregation-flat-continuation-v2.json',{'complete':True,'previous_stopped_continuation_sha256':sha(N/'native-aggregation-flat-continuation-v1.json'),'unchanged_completed_phases':['focused','retention','nested_sources','quality','gates','suite','reports'],'consumer_completion':str(N/'native-aggregation-flat-circuit-result-v2.json'),'fixture_migration_audit':str(A/'migration-audit-v1.json'),'no_implementation_or_test_source_change':True})
print('105 default and 348 all-feature consumer tests passed; exact ZIP migration and Clippy qualified',flush=True)
