"""Apply only the fully qualified source and verify a fresh build at the main checkout."""
import gzip,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'native-aggregation-candidate-v2';T=N/'targets/native-aggregation-flat-integration-v1'
A=N/'native-aggregation-flat-integration-artifacts-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,GIT
assert json.loads((N/'native-aggregation-flat-continuation-v1.json').read_text())['complete']
assert json.loads((N/'native-aggregation-flat-msrv-result-v1.json').read_text())['complete_for_declared_scope']
reports=json.loads((N/'native-aggregation-flat-report-result-v1.json').read_text())
assert reports['only_declared_version_migration']
assert all(r['baseline_repeat_equal'] and r['candidate_repeat_equal'] for r in reports['cases'].values())
suite=json.loads((N/'native-aggregation-flat-suite-result-v1.json').read_text());assert sum(suite['test_counts'].values())==1670
for phase in ['quality','gates','circuit']:
    result=json.loads((N/('native-aggregation-flat-'+phase+'-result-v1.json')).read_text())
    assert result['complete_for_declared_scope'] and all(r['exit_code']==0 and not r['stops'] for r in result['commands'].values())
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
head=git('rev-parse','HEAD').decode().strip();assert head=='5a22614321cfcc2d1a4c2f4ed2920bb0fdd8e671'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
unrelated=O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py'
assert sha(unrelated)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-source-v1.json.gz').read_bytes()))
assert all(sha(S/p)==h for p,h in pins.items())
prep=json.loads((W/'preparation-v1.json').read_text());paths=list(prep['implementation_sha256'])
newtests=['crates/hyperdrc/tests/'+name+'.rs' for name in ['native_aggregation','native_aggregation_memory']]
archived='crates/hyperdrc/tests/kicad_native_aggregation.rs'
assert len(paths)==13 and len(newtests)==2 and not (O/archived).exists()
old={p:sha(O/p) for p in paths};assert all(not (O/p).exists() for p in newtests)
for p,h in pins.items():
    if p not in paths+newtests+[archived]:assert sha(O/p)==h,p
for p in paths+newtests:shutil.copy2(S/p,O/p)
pins.pop(archived)
assert all(sha(O/p)==h for p,h in pins.items())
inv=N/'native-aggregation-flat-integration-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
assert not T.exists() and not A.exists();A.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'));commands={}
dump(N/'native-aggregation-flat-integration-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'base_revision':head,'source_inventory_sha256':sha(inv),'candidate_source_inventory_sha256':sha(N/'native-aggregation-flat-source-v1.json.gz'),'old_production_sha256':old,'copied_qualified_sha256':{p:pins[p] for p in paths+newtests},'archive_review_test_remains_in_evidence_only':True,'fresh_target':str(T),'no_cache_or_exact_ingress_change':True})
def execute(label,args,binary=False):
    assert all(sha(O/p)==h for p,h in pins.items())
    name='aggregation-flat-integration-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--chdir',str(scratch if binary else O)]
    if binary:argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    commands[label]=run(name,argv+args,O,target=T)
    assert all(sha(O/p)==h for p,h in pins.items())
    dump(N/'native-aggregation-flat-integration-progress-v1.json',commands)
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',err)
    return out
execute('format',[cargo,'fmt','--all','--','--check'])
tests=['kicad_track_failures','native_aggregation','native_aggregation_memory']
args=[cargo,'test','--locked','--release','-p','hyperdrc','--no-run','--message-format=json']
for test in tests:args+=['--test',test]
out=execute('compile',args);artifacts={};local=[]
for line in out.splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')!='compiler-artifact':continue
    if r.get('manifest_path','').startswith(str(O)):local.append({'manifest':r['manifest_path'],'target':r['target']['name'],'fresh':r['fresh']})
    if not r.get('executable'):continue
    name=r['target']['name'];name='hyperdrc-cli' if name=='hyperdrc' and not r['profile']['test'] else name
    assert name in tests+['hyperdrc-cli']
    path=Path(r['executable']);assert path.is_relative_to(T);dest=A/name;assert not dest.exists();shutil.copy2(path,dest)
    artifacts[name]={'compiled_path':str(path),'executed_copy':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest)}
assert set(artifacts)==set(tests+['hyperdrc-cli']) and local and not any(r['fresh'] for r in local)
dump(A/'executables-v1.json',artifacts);dump(A/'fresh-local-build-v1.json',local)
counts={}
for test,expected in zip(tests,[39,13,1]):
    out=execute(test,[str(A/test),'--test-threads=1','--nocapture'],True)
    rows=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',out,re.M)
    assert rows==[str(expected)];counts[test]=expected
assert set(git('diff','--name-only').decode().splitlines())==set(paths)
assert not git('diff','--check') and not git('diff','--cached','--name-only')
assert sha(unrelated)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
assert all(sha(row['executed_copy'])==row['sha256'] for row in artifacts.values())
dump(N/'native-aggregation-flat-integration-result-v1.json',{'complete_for_declared_scope':True,'base_revision':head,'commands':commands,'test_counts':counts,'source_matches_qualified_candidate':True,'source_sha256':{p:pins[p] for p in paths+newtests},'all_local_targets_fresh':True,'tracked_whitespace_passed':True,'unrelated_file_unchanged':True,'public_distribution_complete':False,'full_plan_complete':False})
print(json.dumps({'main_checkout_integrated':True,'tests':counts}),flush=True)
