"""Prepare a fresh source snapshot only after the allocation regression reproduces."""
import gzip,hashlib,json,os,shutil,subprocess
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=Path(__file__).resolve().parent;C=N/'native-aggregation-candidate-v1';B=N/'native-aggregation-baseline-v1'
S=N/'native-aggregation-candidate-v2';oldW=N/'native-aggregation-control-v1'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def git(args,cwd=O,stdin=None):
    return subprocess.run(GIT+args,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
def dump(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
negative=json.loads((N/'native-aggregation-flat-negative-v1/result-v1.json').read_text());assert negative['regression_reproduced']
assert sha(W/'native_aggregation_memory.rs')==negative['source_sha256']
head=git(['rev-parse','HEAD']).decode().strip();assert head=='5a22614321cfcc2d1a4c2f4ed2920bb0fdd8e671'
changed=git(['diff','--name-only','e515480e3f0f19a371c745b60d453ab322094db6',head]).decode().splitlines()
assert all(p.startswith('docs/evidence/') or p=='docs/properties-status.json' for p in changed)
prior=json.loads((oldW/'candidate-preparation-v2.json').read_text());paths=list(prior['candidate_implementation_sha256'])
oldpins=json.loads(gzip.decompress((N/'native-aggregation-candidate-source-v1.json.gz').read_bytes()))
assert all(sha(C/p)==h for p,h in oldpins.items())
assert not S.exists()
git(['worktree','add','--no-checkout','-b','codex/native-aggregation-flat-20261017',str(S),head])
git(['sparse-checkout','set','--no-cone','--stdin'],S,(oldW/'sparse-selection-v1.txt').read_bytes())
git(['checkout','codex/native-aggregation-flat-20261017'],S)
normalizations={}
basepins=json.loads(gzip.decompress((N/'native-aggregation-baseline-source-v1.json.gz').read_bytes()))
for p,h in basepins.items():
    if p in ['crates/hyperdrc/tests/kicad_native_aggregation.rs','crates/hyperdrc/tests/native_aggregation.rs']:continue
    if p=='docs/properties-status.json':continue
    if sha(S/p)!=h:
        assert (S/p).read_bytes()==(B/p).read_bytes().replace(b'\r\n',b'\n'),p
        normalizations[p]={'checkout_sha256':sha(S/p),'preserved_original_sha256':h};shutil.copy2(B/p,S/p)
for p in paths:shutil.copy2(C/p,S/p)
for name in ['native_aggregation','kicad_native_aggregation']:
    p='crates/hyperdrc/tests/'+name+'.rs';assert not (S/p).exists();shutil.copy2(C/p,S/p)
p=S/'crates/hyperdrc/src/lib.rs';s=p.read_text()
before="""            result.finite_projection_sources =
                Some(sources.iter().copied().cloned().collect::<Vec<_>>().into());"""
after="""            // Keep only authored leaves: retaining aggregate owners would fill
            // every ancestor's report cache and retain all intermediate prefixes.
            result.finite_projection_sources = Some(
                sources
                    .iter()
                    .flat_map(|source| {
                        source
                            .finite_projection_sources
                            .as_deref()
                            .unwrap_or_else(|| std::slice::from_ref(*source))
                            .iter()
                    })
                    .cloned()
                    .collect::<Vec<_>>()
                    .into(),
            );"""
assert s.count(before)==1;p.write_text(s.replace(before,after))
newtest='crates/hyperdrc/tests/native_aggregation_memory.rs';shutil.copy2(W/'native_aggregation_memory.rs',S/newtest)
subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024',str(p),str(S/newtest)],check=True)
assert sha(S/newtest)==negative['source_sha256']
assert set(git(['diff','--name-only'],S).decode().splitlines())==set(paths)
assert not git(['diff','--check'],S)
assert all(sha(S/p)==h for p,h in prior['candidate_implementation_sha256'].items() if p!='crates/hyperdrc/src/lib.rs')
tracked=git(['ls-files','-z'],S).decode().split('\0')[:-1]
pins={p:sha(S/p) for p in tracked if (S/p).is_file()}
for name in ['native_aggregation','native_aggregation_memory','kicad_native_aggregation']:
    p='crates/hyperdrc/tests/'+name+'.rs';pins[p]=sha(S/p)
inv=N/'native-aggregation-flat-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
patch=W/'candidate-tracked-v1.patch';patch.write_bytes(git(['diff','--binary'],S))
dump(W/'preparation-v1.json',{'revision':head,'source_root':str(S),'target':str(N/'targets/native-aggregation-candidate-v2'),'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'negative_control_sha256':sha(N/'native-aggregation-flat-negative-v1/result-v1.json'),'source_inventory':str(inv),'source_inventory_sha256':sha(inv),'production_delta_from_e64':['crates/hyperdrc/src/lib.rs'],'implementation_sha256':{p:sha(S/p) for p in paths},'new_native_test_sha256':{name:sha(S/('crates/hyperdrc/tests/'+name+'.rs')) for name in ['native_aggregation','native_aggregation_memory']},'archived_review_test_sha256':sha(S/'crates/hyperdrc/tests/kicad_native_aggregation.rs'),'checkout_line_ending_normalizations':normalizations,'patch_sha256':sha(patch),'baseline_production_revision_unchanged':True,'unadmitted':True})
print(json.dumps({'source_files':len(pins),'source_root':str(S),'production_changed_files':len(paths),'delta_from_e64':['crates/hyperdrc/src/lib.rs']}))
