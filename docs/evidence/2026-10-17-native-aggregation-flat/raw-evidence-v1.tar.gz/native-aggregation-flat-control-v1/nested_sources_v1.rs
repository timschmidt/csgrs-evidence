use hypercurve::RegionPointLocation;
use hyperdrc::geometry::{empty_profile, polygon_from_points, polygon_to_profile};
use hyperdrc::kicad::{BoardModel, CopperFeature, CopperKind};
use hyperdrc::{PcbRegion, PcbRegionExt, Scalar};

fn square(x: f64) -> PcbRegion {
    polygon_to_profile(polygon_from_points(vec![
        [x, 0.0], [x + 1.0, 0.0], [x + 1.0, 1.0], [x, 1.0],
    ]), None)
}
fn aggregate(regions: Vec<PcbRegion>) -> PcbRegion {
    BoardModel {
        source: "nested-source-order".into(),
        copper: regions.into_iter().map(|region| CopperFeature {
            layer: "F.Cu".into(), net: None, kind: CopperKind::Pad,
            region, location: [Scalar::zero(), Scalar::zero()],
        }).collect(),
        drills: vec![], board_outline: None, panel_features: None,
    }.all_copper().unwrap()
}
fn main() {
    for warm in [false, true] {
        let a = square(5.0);
        let b = square(0.0);
        let c = square(10.0);
        let expected = [&a, &b, &c, &a, &b].into_iter()
            .flat_map(|r| r.try_to_multipolygon().unwrap().0).collect::<Vec<_>>();
        let left = aggregate(vec![a.clone(), b.clone()]);
        let right = aggregate(vec![c, a]);
        if warm {
            left.try_to_multipolygon().unwrap();
            right.try_to_multipolygon().unwrap();
        }
        let region = aggregate(vec![left, empty_profile(None), right, b]);
        assert_eq!(hyperlimit::compare_reals(&region.try_area().unwrap(), &Scalar::from(3),
            hyperlimit::PredicatePolicy::STRICT).value(), Some(std::cmp::Ordering::Equal));
        for x in ["0.5", "5.5", "10.5"] {
            assert_eq!(region.classify_xy(x.parse().unwrap(), "0.5".parse().unwrap()),
                Ok(RegionPointLocation::Inside));
        }
        assert_eq!(region.classify_xy("3".parse().unwrap(), "0.5".parse().unwrap()),
            Ok(RegionPointLocation::Outside));
        let mut report = region.try_to_multipolygon().unwrap();
        assert_eq!(report.0, expected);
        report.0.clear();
        assert_eq!(region.try_to_multipolygon().unwrap().0, expected);
    }
    println!("nested cold/warm authored order, multiplicity, exact area and isolated views passed");
}
