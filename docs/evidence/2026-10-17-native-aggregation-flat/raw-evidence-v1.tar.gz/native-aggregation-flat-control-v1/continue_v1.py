"""Complete affected validation sequentially after fresh compilation."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
assert json.loads((N/'native-aggregation-flat-build-result-v1.json').read_text())['complete_for_declared_scope']
steps=[['validate_v1.py','focused'],['retention_v1.py'],['nested_sources_v1.py'],['validate_v1.py','quality'],['validate_v1.py','gates'],['validate_v1.py','suite'],['reports_v1.py'],['validate_v1.py','circuit']]
record={'helper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'steps':[],'complete':False}
p=N/'native-aggregation-flat-continuation-v1.json';assert not p.exists()
for step in steps:
    started=time.time();result=subprocess.run([sys.executable,'-B',str(W/step[0]),*step[1:]])
    record['steps'].append({'argv':step,'exit_code':result.returncode,'started_unix':started,'finished_unix':time.time()})
    p.write_text(json.dumps(record,indent=2)+'\n')
    if result.returncode:raise SystemExit(result.returncode)
record['complete']=True;p.write_text(json.dumps(record,indent=2)+'\n')
print('flat ownership validation complete',flush=True)
