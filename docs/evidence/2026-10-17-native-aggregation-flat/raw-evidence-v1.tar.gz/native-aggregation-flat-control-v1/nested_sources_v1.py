"""Exercise distinct nested source ordering after both cold and warmed aggregation."""
import gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');W=Path(__file__).resolve().parent
A=N/'native-aggregation-flat-nesting-v1';assert not A.exists();A.mkdir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);source=W/'nested_sources_v1.rs';commands={};libraries={}
for mode,source_name,target_name,inventory,compile_log in [
    ('baseline','native-aggregation-baseline-v1','native-aggregation-baseline-v1','native-aggregation-baseline-source-v1.json.gz','aggregation-baseline-focused-compile-v1'),
    ('flat','native-aggregation-candidate-v2','native-aggregation-candidate-v2','native-aggregation-flat-source-v1.json.gz','aggregation-flat-build-compile-v1')]:
    S=N/source_name;T=N/'targets'/target_name;pins=json.loads(gzip.decompress((N/inventory).read_bytes()));assert all(sha(S/p)==h for p,h in pins.items())
    libs={};searches=set()
    for line in (N/'logs'/compile_log/'stdout').read_text().splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
        if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hyperdrc','hyperlimit','hypercurve'] and not r['profile']['test']:
            for p in r['filenames']:
                if p.endswith('.rlib'):libs[r['target']['name']]=p
    assert len(libs)==3;libraries[mode]={k:{'path':p,'sha256':sha(p)} for k,p in libs.items()};binary=A/('nested-'+mode)
    args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
    for path in sorted(searches):args+=['-L',path]
    for name,path in sorted(libs.items()):args+=['--extern',name+'='+path]
    commands[mode+'-compile']=run('aggregation-flat-nesting-'+mode+'-compile-v1',args,S,target=T)
    commands[mode+'-run']=run('aggregation-flat-nesting-'+mode+'-run-v1',[str(binary)],S,target=T,wall_seconds=60)
    assert all(sha(S/p)==h for p,h in pins.items())
dump(A/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'source_sha256':sha(source),'commands':commands,'library_inputs':libraries,'binary_sha256':{p.name:sha(p) for p in A.iterdir() if p.is_file()},'cold_and_warm_nested_order_and_multiplicity_preserved':True,'independent_exact_area_and_membership_checked':True,'mutated_report_view_isolated':True})
print('nested source contract passed for baseline and flat candidate',flush=True)
