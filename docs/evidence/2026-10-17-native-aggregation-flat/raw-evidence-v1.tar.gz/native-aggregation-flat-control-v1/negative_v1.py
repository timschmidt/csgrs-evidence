"""Prove the new memory regression catches E64's unchanged rejected prototype."""
import gzip,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
W=Path(__file__).resolve().parent;S=N/'native-aggregation-candidate-v1';T=N/'targets/native-aggregation-candidate-v1'
A=N/'native-aggregation-flat-negative-v1';assert not A.exists();A.mkdir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
source=W/'native_aggregation_memory.rs'
subprocess.run([str(Path(compiler['additional_environment']['RUSTC']).with_name('rustfmt')),'--edition','2024','--config-path',str(S/'crates/.rustfmt.toml'),str(source)],check=True)
source_hash=sha(source)
pins=json.loads(gzip.decompress((N/'native-aggregation-candidate-source-v1.json.gz').read_bytes()))
assert all(sha(S/p)==h for p,h in pins.items())
libraries={};searches=set()
for line in (N/'logs/aggregation-candidate-focused-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hyperdrc','hyperlimit','hypercurve'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libraries[r['target']['name']]=p
assert set(libraries)=={'hyperdrc','hyperlimit','hypercurve'}
inputs={k:{'path':p,'sha256':sha(p)} for k,p in libraries.items()}
binary=A/'native-aggregation-memory'
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','--test','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
for path in sorted(searches):args+=['-L',path]
for name,path in sorted(libraries.items()):args+=['--extern',name+'='+path]
compile=run('aggregation-flat-negative-compile-v1',args,S,target=T)
name='aggregation-flat-negative-run-v1'
try:
    run(name,[str(binary),'--test-threads=1','--nocapture'],S,target=T,wall_seconds=60)
except RuntimeError:pass
result=json.loads((N/'logs'/name/'result.json').read_text())
assert result['exit_code']==101 and not result['stops']
stdout=(N/'logs'/name/'stdout').read_text();stderr=(N/'logs'/name/'stderr').read_text()
assert '0 passed; 1 failed; 0 ignored;' in stdout
assert 'fourfold source growth retained more than sixfold report payload' in stderr
assert sha(source)==source_hash and all(sha(S/p)==h for p,h in pins.items())
assert all(sha(row['path'])==row['sha256'] for row in inputs.values())
dump(A/'result-v1.json',{'regression_reproduced':True,'source_sha256':source_hash,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'binary_sha256':sha(binary),'library_inputs':inputs,'compile':compile,'run':result,'stdout':stdout,'stderr':stderr,'frozen_prototype_unchanged':True})
print(stderr,flush=True)
