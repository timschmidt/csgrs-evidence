"""Stage only the byte-verified admitted source after all integration checks pass."""
import hashlib,json,os,subprocess
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
G=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
def git(*a):return subprocess.check_output(G+list(a),cwd=O)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((N/'native-aggregation-flat-integration-result-v1.json').read_text());assert r['complete_for_declared_scope'] and r['source_matches_qualified_candidate']
assert git('rev-parse','HEAD').decode().strip()==r['base_revision']
assert not git('diff','--cached','--name-only')
paths=sorted(r['source_sha256']);assert len(paths)==16
assert all(sha(O/p)==h for p,h in r['source_sha256'].items())
subprocess.run(G+['add','--',*paths],cwd=O,check=True)
subprocess.run(G+['diff','--cached','--check'],cwd=O,check=True)
assert set(git('diff','--cached','--name-only','-z').decode().split('\0')[:-1])==set(paths)
files={}
for p in paths:
    b=git('show',':'+p);assert b==(O/p).read_bytes();assert hashlib.sha256(b).hexdigest()==r['source_sha256'][p]
    files[p]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not git('diff','--name-only')
assert sha(O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py')=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
p=N/'native-aggregation-flat-source-stage-v1.json';assert not p.exists();p.write_text(json.dumps({'parent':r['base_revision'],'files':files,'staged_blobs_verified':True,'staged_whitespace_exit':0,'integration_result_sha256':sha(N/'native-aggregation-flat-integration-result-v1.json'),'helper_sha256':sha(Path(__file__))},indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified_staged_files':len(files),'parent':r['base_revision']}))
