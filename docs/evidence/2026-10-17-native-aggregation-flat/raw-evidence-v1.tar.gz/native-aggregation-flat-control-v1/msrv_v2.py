"""Check affected package targets at the declared compiler floor."""
import gzip,json,os,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'native-aggregation-candidate-v2';T=N/'targets/native-aggregation-flat-msrv-v1'
assert not T.exists();assert json.loads((N/'native-aggregation-flat-continuation-v2.json').read_text())['complete']
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-source-v1.json.gz').read_bytes()))
tools=json.loads((O/'docs/evidence/2026-10-17-in-scope-msrv/review-v1.json').read_text())['tool_sha256']
assert all(sha(p)==h for p,h in tools.items())
root=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
os.environ.update(CARGO_NET_OFFLINE='true',RUSTC=str(root/'rustc'),RUSTDOC=str(root/'rustdoc'),RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
commands={}
dump(N/'native-aggregation-flat-msrv-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'source_inventory_sha256':sha(N/'native-aggregation-flat-source-v1.json.gz'),'tools':tools,'contract_sha256':sha(W/'msrv-contract-v1.md'),'target':str(T),'target_initially_absent':True,'runtime_tests_rerun':False,'compiler_version':'1.95.0','qualified_fixture_overlay_sha256':sha(N/'native-aggregation-flat-package-diagnosis-v1/left.zip')})
for label,feature in [('all','--all-features'),('minimal','--no-default-features')]:
    assert all(sha(S/p)==h for p,h in pins.items())
    name='aggregation-flat-msrv-'+label+'-v1';scratch=N/'scratch'/name
    args=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--ro-bind',str(N/'native-aggregation-flat-package-diagnosis-v1/left.zip'),str(S/'crates/hypercircuit/tests/fixtures/manufacturing-release/release-board-v1.zip'),'--chdir',str(S)]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():args+=['--setenv',k,v]
    commands[label]=run(name,args+[str(root/'cargo'),'check','--locked','-p','hyperdrc','-p','hypercircuit','--all-targets',feature],S,target=T)
    err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M)
    assert all(sha(S/p)==h for p,h in pins.items())
    dump(N/'native-aggregation-flat-msrv-progress-v1.json',commands)
dump(N/'native-aggregation-flat-msrv-result-v1.json',{'complete_for_declared_scope':True,'commands':commands,'compiler':'1.95.0','all_targets':True,'features':['all','no-default'],'source_unchanged':True,'hypervoxel_compiled':False,'runtime_tests_rerun':False,'clippy_on_msrv_run':False,'public_distribution_complete':False})
print('affected compiler-floor checks passed',flush=True)
