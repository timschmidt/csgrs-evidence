"""Re-run the identical complete external retention cases against flat ownership."""
import gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
W=Path(__file__).resolve().parent;S=N/'native-aggregation-candidate-v2';T=N/'targets/native-aggregation-candidate-v2'
A=N/'native-aggregation-flat-retention-v1';assert not A.exists();A.mkdir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
source=W/'retention_probe_v1.rs';source_hash=sha(source)
assert source_hash==sha(N/'native-aggregation-control-v1/retention_probe_v1.rs')
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-source-v1.json.gz').read_bytes()))
assert all(sha(S/p)==h for p,h in pins.items())
libraries={};searches=set()
for line in (N/'logs/aggregation-flat-build-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hyperdrc','hyperlimit','hypercurve'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libraries[r['target']['name']]=p
assert set(libraries)=={'hyperdrc','hyperlimit','hypercurve'}
inputs={k:{'path':p,'sha256':sha(p)} for k,p in libraries.items()}
binary=A/'retention-flat'
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
for path in sorted(searches):args+=['-L',path]
for name,path in sorted(libraries.items()):args+=['--extern',name+'='+path]
commands={'compile':run('aggregation-flat-retention-compile-v1',args,S,target=T)};rows=[]
for n in [16,64,256]:
    name='aggregation-flat-retention-'+str(n)+'-v1';commands[str(n)]=run(name,[str(binary),str(n)],S,target=T,wall_seconds=60)
    row=json.loads((N/'logs'/name/'stdout').read_text());assert row['n']==n and row['exact_area']=='1' and row['center_inside'] and row['report_polygons']==n
    rows.append(row);dump(A/'progress-v1.json',{'commands':commands,'rows':rows})
assert all(sha(S/p)==h for p,h in pins.items()) and sha(source)==source_hash
assert all(sha(row['path'])==row['sha256'] for row in inputs.values())
dump(A/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'probe_sha256':source_hash,'contract_sha256':sha(W/'contract-v1.md'),'binary_sha256':sha(binary),'library_inputs':inputs,'commands':commands,'rows':rows,'all_workloads_completed_and_validated':True,'prior_baseline_and_prototype_evidence':str(N/'native-aggregation-retention-v1/result-v2.json'),'prior_evidence_sha256':sha(N/'native-aggregation-retention-v1/result-v2.json'),'measurement':'requested live and peak Rust allocation payload bytes; not RSS','same_contract_speedup_claimed':False})
print(json.dumps(rows),flush=True)
