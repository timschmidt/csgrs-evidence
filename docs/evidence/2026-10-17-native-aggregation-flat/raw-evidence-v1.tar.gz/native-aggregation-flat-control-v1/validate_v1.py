"""Qualify flat report ownership using immutable source and frozen native executables."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');W=Path(__file__).resolve().parent
S=N/'native-aggregation-candidate-v2';T=N/'targets/native-aggregation-candidate-v2'
A=N/'native-aggregation-flat-artifacts-v1';inv=N/'native-aggregation-flat-source-v1.json.gz'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,reasons,resources
phase=sys.argv[1];assert phase in ['build','focused','gates','quality','suite','circuit']
pins=json.loads(gzip.decompress(inv.read_bytes()));compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
commands={};counts={};summaries={}
protocol=N/('native-aggregation-flat-'+phase+'-protocol-v1.json');assert not protocol.exists()
dump(protocol,{'source_inventory_sha256':sha(inv),'helper_sha256':sha(Path(__file__)),'runner_sha256':sha(N/'control/validation_runner_v3.py'),'compiler_sha256':compiler['tool_sha256'],'contract_sha256':sha(W/'contract-v1.md'),'source_root':str(S),'target':str(T),'target_initially_absent':not T.exists(),'compile_cli_binding':False,'runtime_cwd':'private writable scratch','hypervoxel_deferred':True})
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
    if (A/'executables-v1.json').exists():
        assert all(sha(r['executed_copy'])==r['sha256'] for r in json.loads((A/'executables-v1.json').read_text()).values())
def execute(label,args,binary=False,expected_failure=False,extra_env=None):
    verify();name='aggregation-flat-'+phase+'-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(scratch if binary else S)]
    if binary:argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    env={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
    if extra_env:env.update(extra_env)
    for k,v in env.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,S,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r
        dump(N/('native-aggregation-flat-'+phase+'-progress-v1.json'),commands)
        if r['stops'] or not expected_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(N/('native-aggregation-flat-'+phase+'-progress-v1.json'),commands)
    verify();out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',err)
    return out,err,r
def result_rows(text):
    return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
def passing(label,out):
    rows=result_rows(out);assert rows and all(r[0]=='ok' and r[2:]==('0','0','0','0') for r in rows),rows
    counts[label]=sum(int(r[1]) for r in rows);summaries[label]=rows

tests=sorted(p.stem for p in (S/'crates/hyperdrc/tests').glob('*.rs'))
if phase=='build':
    assert not T.exists() and not A.exists();A.mkdir()
    out,err,_=execute('compile',[cargo,'test','--release','--locked','-p','hyperdrc','--lib','--bins','--tests','--no-run','--message-format=json'])
    artifacts={};local=[]
    for line in out.splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('reason')!='compiler-artifact':continue
        if r.get('manifest_path','').startswith(str(S)):local.append({'manifest':r['manifest_path'],'target':r['target']['name'],'kind':r['target']['kind'],'fresh':r['fresh']})
        if not r.get('executable'):continue
        name=r['target']['name']
        if name=='hyperdrc':
            name='hyperdrc-lib' if 'lib' in r['target']['kind'] else ('hyperdrc-bin-tests' if r['profile']['test'] else 'hyperdrc-cli')
        assert name in tests+['hyperdrc-lib','hyperdrc-bin-tests','hyperdrc-cli'],name
        path=Path(r['executable']);assert path.is_relative_to(T);dest=A/name;assert not dest.exists();shutil.copy2(path,dest)
        artifacts[name]={'compiled_path':str(path),'executed_copy':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size};assert sha(path)==sha(dest)
    assert set(artifacts)==set(tests+['hyperdrc-lib','hyperdrc-bin-tests','hyperdrc-cli'])
    assert local and not any(r['fresh'] for r in local)
    dump(A/'executables-v1.json',artifacts);dump(A/'fresh-local-build-v1.json',local)
elif phase=='focused':
    expected={'kicad_track_failures':39,'native_aggregation':13,'native_aggregation_memory':1}
    for name,count in expected.items():
        out,err,_=execute(name,[str(A/name),'--test-threads=1','--nocapture'],binary=True);passing(name,out);assert counts[name]==count
    out,err,r=execute('kicad_native_aggregation',[str(A/'kicad_native_aggregation'),'--test-threads=1','--nocapture'],binary=True,expected_failure=True)
    assert result_rows(out)==[('FAILED','9','3','0','0','0')]
    failures=re.findall(r'^test ([^ ]+) \.\.\. FAILED$',out,re.M)
    assert set(failures)=={'subrange_stroke_composes_without_a_finite_report_ring','superrange_stroke_survives_empty_accumulation_and_native_handoff','failed_report_prefix_is_not_cached_and_native_composition_recovers'},failures
    summaries['archived_review']={'passed':9,'failed':3,'known_unadmitted_ingress_cases':failures}
elif phase=='gates':
    for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
        out,err,_=execute(label,[str(A/'hyperdrc-lib'),'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],binary=True)
        assert 'skipping complex project fixture' not in out+err
        rows=result_rows(out);assert len(rows)==1 and rows[0][:5]==('ok','1','0','0','0'),rows
        summaries[label]=rows
elif phase=='quality':
    execute('format',[cargo,'fmt','--all','--','--check'])
    execute('clippy',[cargo,'clippy','--locked','-p','hyperdrc','--all-targets','--all-features','--','-D','warnings'])
    execute('docs',[cargo,'doc','--locked','-p','hyperdrc','--all-features','--no-deps'],extra_env={'RUSTDOCFLAGS':'-D warnings'})
elif phase=='suite':
    out,err,_=execute('library',[str(A/'hyperdrc-lib'),'--test-threads=1','--nocapture'],binary=True);passing('library',out);assert counts['library']==1559
    focused={'kicad_track_failures','native_aggregation','native_aggregation_memory'}
    for name in ['hyperdrc-bin-tests',*(n for n in tests if n not in focused|{'kicad_native_aggregation'})]:
        out,err,_=execute(name,[str(A/name),'--test-threads=1','--nocapture'],binary=True);passing(name,out)
    out,err,_=execute('doctests',[cargo,'test','--locked','--release','-p','hyperdrc','--doc']);passing('doctests',out);assert counts['doctests']==3
    out,err,_=execute('metadata',[cargo,'metadata','--locked','--no-deps','--format-version','1']);package=next(p for p in json.loads(out)['packages'] if p['name']=='hyperdrc')
    assert {t['name'] for t in package['targets'] if t['kind']==['test']}==set(tests)
    f=json.loads((N/'native-aggregation-flat-focused-result-v1.json').read_text());assert f['complete_for_declared_scope']
    counts.update(f['test_counts']);assert sum(counts.values())==1670
elif phase=='circuit':
    for label,args in [('default',['test','--locked','-p','hypercircuit']),('all',['test','--locked','--release','-p','hypercircuit','--all-features'])]:
        out,err,_=execute(label,[cargo,*args,'--','--test-threads=1']);passing(label,out)
    execute('clippy',[cargo,'clippy','--locked','-p','hypercircuit','--all-targets','--all-features','--','-D','warnings'])
verify()
dump(N/('native-aggregation-flat-'+phase+'-result-v1.json'),{'complete_for_declared_scope':True,'phase':phase,'commands':commands,'test_counts':counts,'summaries':summaries,'source_unchanged':True,'new_implementation_admitted':False,'full_plan_complete':False})
print(json.dumps({'phase':phase,'test_counts':counts,'summaries':summaries}),flush=True)
