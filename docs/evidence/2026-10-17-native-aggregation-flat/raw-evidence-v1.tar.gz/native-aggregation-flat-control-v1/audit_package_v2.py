"""Independently validate the precise continuation of the readiness ZIP migration."""
import hashlib,io,json,struct,zipfile
from pathlib import Path
W=Path(__file__).resolve().parent;A=W.parent/'native-aggregation-flat-package-diagnosis-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
old=(A/'right.zip').read_bytes();new=(A/'left.zip').read_bytes();a=zipfile.ZipFile(io.BytesIO(old));b=zipfile.ZipFile(io.BytesIO(new))
assert len(old)==len(new) and len(a.namelist())==22 and a.namelist()==b.namelist() and len(set(a.namelist()))==22
assert a.comment==b.comment and a.start_dir==b.start_dir
names=['evidence/hyperdrc.json','manufacturing-release.json']
assert [name for name in a.namelist() if a.read(name)!=b.read(name)]==names
before=a.read(names[0]);after=b.read(names[0]);assert before.count(b'"check_version":21')==160
assert before.replace(b'"check_version":21',b'"check_version":22')==after
old_report='sha256:'+sha(before);new_report='sha256:'+sha(after)
m0=json.loads(a.read(names[1]));m1=json.loads(b.read(names[1]))
for manifest,report in [(m0,old_report),(m1,new_report)]:
    assert manifest['core']['drc_report_digest']==report
    evidence=manifest['core']['artifacts']['artifacts'][8]
    assert evidence['digest']==report
    core=json.dumps(manifest['core'],separators=(',',':'),ensure_ascii=False).encode()
    assert manifest['core_digest']=='sha256:'+sha(core)
    assert manifest['signatures']==[]
expected_manifest=a.read(names[1]).replace(old_report.encode(),new_report.encode()).replace(m0['core_digest'].encode(),m1['core_digest'].encode())
assert expected_manifest==b.read(names[1])
expected=bytearray(old);central=a.start_dir;metadata=[]
for oldinfo,newinfo in zip(a.infolist(),b.infolist()):
    keys=['filename','date_time','compress_type','flag_bits','header_offset','comment','extra','create_system','external_attr','create_version','extract_version','volume','internal_attr','file_size','compress_size']
    assert all(getattr(oldinfo,k)==getattr(newinfo,k) for k in keys)
    assert oldinfo.compress_type==zipfile.ZIP_STORED
    assert old[central:central+4]==b'PK\x01\x02'
    n,e,c=struct.unpack_from('<HHH',old,central+28)
    assert old[central+46:central+46+n].decode()==oldinfo.filename
    if oldinfo.filename in names:
        local=oldinfo.header_offset;assert old[local:local+4]==b'PK\x03\x04'
        nl,el=struct.unpack_from('<HH',old,local+26);start=local+30+nl+el
        data=b.read(oldinfo.filename);expected[start:start+len(data)]=data
        expected[local+14:local+18]=struct.pack('<I',newinfo.CRC)
        expected[central+16:central+20]=struct.pack('<I',newinfo.CRC)
    else:assert oldinfo.CRC==newinfo.CRC
    metadata.append({'name':oldinfo.filename,'old_sha256':sha(a.read(oldinfo.filename)),'new_sha256':sha(b.read(newinfo.filename)),'metadata_unchanged_except_required_crc':True})
    central+=46+n+e+c
assert bytes(expected)==new
p=A/'migration-audit-v1.json';assert not p.exists();p.write_text(json.dumps({'helper_sha256':sha(Path(__file__).read_bytes()),'contract_sha256':sha((W/'package-migration-contract-v1.md').read_bytes()),'old_zip_sha256':sha(old),'new_zip_sha256':sha(new),'members':metadata,'only_declared_member_changes':True,'independent_digest_checks_passed':True,'exact_zip_reconstructed_from_declared_changes':True,'version_fields':160,'derived_digest_fields':3,'test_assertions_unchanged':True},indent=2)+'\n')
print('22-member ZIP migration independently verified: 160 version fields and 3 derived digests',flush=True)
