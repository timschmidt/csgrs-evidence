from pathlib import Path
import ctypes as C, random
s=Path(__file__).parent;r=random.Random(17)
for w,U,one,inf,normal in [(32,C.c_uint32,0x3f800000,0x7f800000,0x00800000),(64,C.c_uint64,0x3ff0000000000000,0x7ff0000000000000,0x0010000000000000)]:
    libs=[C.CDLL(str(s/'images'/('ops-'+v+'.so'))) for v in ('primary','checked')]
    f=[getattr(l,'ops'+str(w)) for l in libs]
    for fn in f:fn.argtypes=[C.c_uint32,U,U,U,U,C.c_uint32];fn.restype=U
    special=[x|sign for x in [0,1,2,normal-1,normal,one,inf-1,inf,inf+1] for sign in [0,1<<(w-1)]]
    count=[0]*6;n=0
    for i in range(8192):
        args=[r.choice(special) if i%4 else r.getrandbits(w) for j in range(4)]
        for op in range(32):
            status=f[0](op,*args,0);count[status]+=1
            for k in range(3 if status==1 else 1):
                assert f[0](op,*args,k)==f[1](op,*args,k),(w,op,args,k)
                n+=1
    print(w,n,count,flush=True)
