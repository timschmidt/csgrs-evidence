from pathlib import Path
import random,ctypes,struct,sys,json
s=Path(__file__).parent
def big(bits,w,f):
 emax=(1<<(w-1-f))-1; frac=bits&((1<<f)-1); e=(bits>>f)&emax
 if e==emax:return None
 value=((1<<f)|frac)<<(e-1) if e else frac
 return -value if bits>>(w-1) else value
def mean(a,b,w,f):
 # Both arguments are signed integer coordinates in units of min_subnormal.
 # Divide their sum by two and round exactly once onto the destination grid.
 n=a+b;sign=(n<0)<<(w-1);n=abs(n)
 shift=max(1,n.bit_length()-(f+1))
 q,r=divmod(n,1<<shift)
 if r*2>1<<shift or (r*2==1<<shift and q%2):q+=1
 grid=q<<(shift-1);k=max(0,grid.bit_length()-1-f)
 if grid < 1<<f:return sign|grid
 return sign|((k+1)<<f)|((grid>>k)-(1<<f))
def cases(w,f):
 rng=random.Random(23891+w);sign=1<<(w-1);emax=(1<<(w-1-f))-1;mask=(1<<f)-1
 for a in range(64):
  for b in range(64):
   for sa,sb in [(0,0),(sign,0),(sign,sign)]:yield a|sa,b|sb
 for e in range(emax):
  for frac in [0,1,2,mask//2,mask-1,mask]:
   a=(e<<f)|frac
   for b in [max(0,a-1),a,min((emax<<f)-1,a+1), ((emax-1)<<f)|mask,((max(0,e-f-2))<<f)|mask,1,0,rng.randrange(emax)<<f|rng.getrandbits(f)]:
    yield a,b
    yield a|sign,b
    yield a|sign,b|sign
 for i in range(40000):
  yield (rng.randrange(emax)<<f)|rng.getrandbits(f)|(rng.getrandbits(1)*sign),(rng.randrange(emax)<<f)|rng.getrandbits(f)|(rng.getrandbits(1)*sign)
def generate(w,f):
 path=s/f'radius-corpus-{w}.bin';fmt=struct.Struct('<IIII' if w==32 else '<QQQQ')
 with path.open('wb') as out:
  for x,y in cases(w,f):
   a,b=big(x,w,f),big(y,w,f)
   if a>b:x,y,a,b=y,x,b,a
   out.write(fmt.pack(x,y,mean(a,b,w,f),mean(-a,b,w,f)))
 return path
def run(w,f,tag):
 lib=ctypes.CDLL(str(s/'images'/('radius-'+tag+'.so')));fn=getattr(lib,'mid'+str(w))
 t=ctypes.c_uint32 if w==32 else ctypes.c_uint64;fn.argtypes=[t,t,ctypes.c_uint32];fn.restype=t
 fmt=struct.Struct('<IIII' if w==32 else '<QQQQ');p=s/f'radius-corpus-{w}.bin';bad=0;count=0
 for a,b,mid,rad in fmt.iter_unpack(p.read_bytes()):
  bad+=fn(a,b,0)!=mid;bad+=fn(a,b,1)!=rad;count+=2
 for a,b in [(1,0),((1<<(w-1))-(1<<f),1),((1<<(w-1))-1,0)]:
  assert big(fn(a,b,1),w,f) is None
 return dict(width=w,tag=tag,total=count,bad=bad)
for w,f in [(32,23),(64,52)]:
 generate(w,f)
 for tag in ['fixed','primary','f32-joint']:
  r=run(w,f,tag);print(json.dumps(r),flush=True)
  if tag=='f32-joint':assert r['bad']==(0 if w==32 else 9666)
