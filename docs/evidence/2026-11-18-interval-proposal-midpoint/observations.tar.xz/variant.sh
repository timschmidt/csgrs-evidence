set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
tag=$1
r="$s/cost-source";cd "$r"
git restore crates/hyperinterval/src/proposal.rs crates/hyperinterval/src/ieee.rs crates/hyperinterval/tests/proposal.rs crates/hyperdynamics/tests/rk_proposal.rs
git apply "$s/$tag.patch"
export CARGO_TARGET_DIR="$s/rk-build"
cargo build --release --locked -p hyperinterval --example proposal_cost --features float-proposal
cp "$CARGO_TARGET_DIR/release/examples/proposal_cost" "$s/images/$tag-proposal-cost"
cargo build --release --locked -p hyperdynamics --example rk_proposal --all-features
cp "$CARGO_TARGET_DIR/release/examples/rk_proposal" "$s/images/$tag-rk-example"
"$s/images/$tag-rk-example" > "$s/logs/$tag-example"
for t in rk-cost rk-stack;do
 cargo build --release --locked --manifest-path "$s/$t/Cargo.toml"
 if test "$t" = rk-cost; then name=rk-proposal-cost-probe; else name=rk-midpoint-lifetime; fi
 cp "$CARGO_TARGET_DIR/release/$name" "$s/images/$tag-$t"
done
for i in $(seq 1 12); do setarch x86_64 -R taskset -c 4 "$s/images/$tag-rk-stack" > "$s/logs/life-$tag-$i" 2>"$s/logs/guard-$tag-$i";done
for pass in existing qualified; do
 if test "$pass" = qualified;then cp /mnt/development/csgrs/crates/hyperinterval/tests/proposal.rs crates/hyperinterval/tests/;cp /mnt/development/csgrs/crates/hyperdynamics/tests/rk_proposal.rs crates/hyperdynamics/tests/;fi
 for test in proposal rk_proposal;do
  if test "$test" = proposal;then crate=hyperinterval;else crate=hyperdynamics;fi
  cargo test --release --locked -p "$crate" --all-features --test "$test" --no-run --message-format=json > "$s/logs/$tag-$pass-$test.jsonl"
  file=$(python3 -c 'import json,sys;print(next(a["executable"] for l in open(sys.argv[1]) if (a:=json.loads(l)).get("executable") and a["target"]["name"]==sys.argv[2]))' "$s/logs/$tag-$pass-$test.jsonl" "$test")
  if test "$pass" = existing; then dest="$tag"; else dest="$tag-qualified";fi
  cp "$file" "$s/images/$dest-$test-test"
  "$file" > "$s/logs/$tag-$pass-$test"
 done
done
