use hyperinterval::{F32ProposalInterval, F64ProposalInterval, IntervalError};
macro_rules! export {
    ($name:ident,$ty:ty,$bits:ty,$p:ty) => {
        #[unsafe(no_mangle)]
        pub extern "C" fn $name(op:u32, a:$bits, b:$bits, c:$bits, d:$bits, field:u32)->$bits {
            let build=|empty:bool, lower,upper| if empty {Ok(<$p>::empty())} else {<$p>::new(<$ty>::from_bits(lower),<$ty>::from_bits(upper))};
            let result=(||{
                let x=build(op & 8 != 0,a,b)?;
                if op%8 == 0 {return Ok(x);}
                if op%8 == 1 {return Ok(x.neg());}
                if op%8 == 2 {return x.affine(<$ty>::from_bits(c),<$ty>::from_bits(d));}
                let y=build(op & 16 != 0,c,d)?;
                match op%8 {3=>x.add(&y),4=>x.sub(&y),5=>x.mul(&y),6=>x.div(&y),_=>y.div(&x)}
            })();
            match result {
                Ok(x)=>match x.estimates() {
                    Some((a,b))=>match field {0=>1,1=>a.to_bits(),_=>b.to_bits()},
                    None=>0,
                },
                Err(e)=>match e {
                    IntervalError::NonFiniteEndpoint=>2,IntervalError::ReversedEndpoints=>3,
                    IntervalError::ContainsZero=>4,IntervalError::Overflow=>5,_=>panic!(),
                },
            }
        }
    }
}
export!(ops32,f32,u32,F32ProposalInterval);
export!(ops64,f64,u64,F64ProposalInterval);
