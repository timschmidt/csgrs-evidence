use hyperinterval::{F32ProposalInterval,F64ProposalInterval};
macro_rules! entry { ($name:ident,$t:ty,$bits:ty,$interval:ty) => {
    #[unsafe(no_mangle)]
    pub extern "C" fn $name(a:$bits,b:$bits,field:u32)->$bits {
        <$interval>::new(<$t>::from_bits(a),<$t>::from_bits(b)).ok().and_then(|span| {
            let (mid,radius)=span.midpoint_radius_estimates()?;
            Some(if field==0 {mid} else {radius})
        }).unwrap_or(<$t>::NAN).to_bits()
    }
};}
entry!(mid32,f32,u32,F32ProposalInterval);
entry!(mid64,f64,u64,F64ProposalInterval);
