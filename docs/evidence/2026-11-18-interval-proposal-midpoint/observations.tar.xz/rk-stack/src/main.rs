use std::alloc::{GlobalAlloc,Layout,System};
use std::sync::atomic::{AtomicBool,AtomicIsize,AtomicUsize,Ordering};
use std::hint::black_box;

use hyperdynamics::field::{EnclosureBudget,EnclosurePolicy,ExpressionField,FieldDefinition,evolution::EvolutionRequest,picard::PicardStatus,proposal::Rk4Options};
use hyperinterval::{DyadicInterval};
use hyperlattice_interval::BoxN;

use hypersolve::{Expr,SymbolId,expression_program::{ExpressionBudget,ExpressionProgram}};
struct CountingAllocator;

#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

static ENABLED: AtomicBool = AtomicBool::new(false);
static ALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
static DEALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
static REALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
static ALLOCATED_BYTES: AtomicUsize = AtomicUsize::new(0);
// Signed deltas expose any pre-epoch allocation freed during measurement
// instead of letting a saturating subtraction hide it as a clean zero.
static LIVE_BYTES: AtomicIsize = AtomicIsize::new(0);
static PEAK_LIVE_BYTES: AtomicIsize = AtomicIsize::new(0);

unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() && ENABLED.load(Ordering::Relaxed) {
            ALLOCATIONS.fetch_add(1, Ordering::Relaxed);
            ALLOCATED_BYTES.fetch_add(layout.size(), Ordering::Relaxed);
            add_live_bytes(layout.size());
        }
        pointer
    }

    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        if ENABLED.load(Ordering::Relaxed) {
            DEALLOCATIONS.fetch_add(1, Ordering::Relaxed);
            subtract_live_bytes(layout.size());
        }
        unsafe { System.dealloc(pointer, layout) };
    }

    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        let replacement = unsafe { System.realloc(pointer, layout, new_size) };
        if !replacement.is_null() && ENABLED.load(Ordering::Relaxed) {
            REALLOCATIONS.fetch_add(1, Ordering::Relaxed);
            ALLOCATED_BYTES.fetch_add(new_size, Ordering::Relaxed);
            if new_size >= layout.size() {
                add_live_bytes(new_size - layout.size());
            } else {
                subtract_live_bytes(layout.size() - new_size);
            }
        }
        replacement
    }
}

fn add_live_bytes(bytes: usize) {
    let bytes = bytes as isize;
    let live = LIVE_BYTES.fetch_add(bytes, Ordering::Relaxed) + bytes;
    let mut peak = PEAK_LIVE_BYTES.load(Ordering::Relaxed);
    while live > peak {
        match PEAK_LIVE_BYTES.compare_exchange_weak(
            peak,
            live,
            Ordering::Relaxed,
            Ordering::Relaxed,
        ) {
            Ok(_) => break,
            Err(observed) => peak = observed,
        }
    }
}

fn subtract_live_bytes(bytes: usize) {
    LIVE_BYTES.fetch_sub(bytes as isize, Ordering::Relaxed);
}

#[derive(Clone, Copy)]
struct AllocationStats {
    allocations: usize,
    deallocations: usize,
    reallocations: usize,
    allocated_bytes: usize,
    peak_live_bytes: isize,
    live_bytes: isize,
}

impl AllocationStats {
    fn snapshot() -> Self {
        Self {
            allocations: ALLOCATIONS.load(Ordering::Relaxed),
            deallocations: DEALLOCATIONS.load(Ordering::Relaxed),
            reallocations: REALLOCATIONS.load(Ordering::Relaxed),
            allocated_bytes: ALLOCATED_BYTES.load(Ordering::Relaxed),
            peak_live_bytes: PEAK_LIVE_BYTES.load(Ordering::Relaxed),
            live_bytes: LIVE_BYTES.load(Ordering::Relaxed),
        }
    }
}

struct CountingGuard;

impl CountingGuard {
    fn start() -> Self {
        for counter in [
            &ALLOCATIONS,
            &DEALLOCATIONS,
            &REALLOCATIONS,
            &ALLOCATED_BYTES,
        ] {
            counter.store(0, Ordering::Relaxed);
        }
        LIVE_BYTES.store(0, Ordering::Relaxed);
        PEAK_LIVE_BYTES.store(0, Ordering::Relaxed);
        ENABLED.store(true, Ordering::SeqCst);
        Self
    }
}

impl Drop for CountingGuard {
    fn drop(&mut self) {
        ENABLED.store(false, Ordering::SeqCst);
    }
}

fn budget()->EnclosureBudget {EnclosureBudget::new(EnclosurePolicy::default())}
fn d(a:i64,e:i32)->DyadicInterval {DyadicInterval::point(a.into(),e).unwrap()}
fn source(expression:Expr)->FieldDefinition {
 let t=SymbolId(100);let x=SymbolId(0);
 let p=ExpressionProgram::compile(&[expression],&[x,t],&mut ExpressionBudget::new(100000,10000000)).unwrap();
 FieldDefinition{source:p.definition().clone(),time:t,state:vec![x]}
}
fn run(i:usize)->u64 {
 let mut budget=budget();let field=ExpressionField::<1>::from_definition(source(Expr::int(0)),&mut budget).unwrap();
 let p=field.rk4_proposer(&mut budget).unwrap();
 let tiny=i%2==1;
 let req=EvolutionRequest {start:if tiny{d(1,-1074)}else{d(0,0)},end:if tiny{d(5,-1074)}else{d(1,-2)},initial:BoxN::new([if tiny{d(-3,-1074)}else{d(1,0)}]).unwrap()};
 if i/2==2 {
  let mut denied=EnclosureBudget::new(EnclosurePolicy{graph_work:0,..Default::default()});
  assert!(p.propose(req.clone(),Rk4Options::default(),&mut denied).is_err());
 }
 let candidate=p.propose(req,Rk4Options::default(),&mut budget).unwrap();
 let bits=candidate.trace().stages()[0].state()[0].to_bits();
 if i/2>0 {let a=candidate.certify(&mut budget);assert!(matches!(a.proof().status(),PicardStatus::Certified));black_box(a);}
 bits
}
unsafe extern "C" {fn measure_stack(f:extern "C" fn(*mut std::ffi::c_void),arg:*mut std::ffi::c_void,warm:i32,pattern:u8)->usize;}
extern "C" fn sample(p:*mut std::ffi::c_void){black_box(run(p.addr()));}
fn main(){
 for i in 0..6 {
  for warm in 0..2 {for pattern in [85,170]{let v=unsafe{measure_stack(sample,std::ptr::without_provenance_mut(i),warm,pattern)};
   println!("STACK {i} {warm} {pattern} {v}");}}
  for warm in 0..2{
   std::thread::spawn(move||{
    if warm==1{black_box(run(i));}
    let guard=CountingGuard::start();let bits=black_box(run(i));let a=AllocationStats::snapshot();drop(guard);
    println!("HEAP {i} {warm} {} {} {} {} {} {} {bits}",a.allocations,a.deallocations,a.reallocations,a.allocated_bytes,a.peak_live_bytes,a.live_bytes);
   }).join().unwrap();
  }
 }
}
