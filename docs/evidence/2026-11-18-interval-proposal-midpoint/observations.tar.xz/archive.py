from pathlib import Path
import hashlib,io,json,tarfile,shutil,subprocess as sp,importlib.util
s=Path(__file__).parent;repo=Path.cwd();other=repo.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-proposal-midpoint'
def git(*args):return sp.check_output(['git','-C',other,*args])
assert not git('status','--porcelain')
files={}
for p in s.iterdir():
 if p.is_file() and (p.suffix in ('.py','.sh','.rs','.json','.c','.cjs','.patch','.txt','.env','.lock') or p.name in ('scope','retained-revision','review-revision')):
  files[p.name]=p
for dirname in ['logs','center-record','checked-record','direct-record','joint-record','ctor-record','barrier-record','client','ops-client','packed-client','width-client','width-initial','radius-client','rk-cost','rk-stack']:
 root=s/dirname
 for p in root.rglob('*'):
  if p.is_file() and not any(d in ('target','.git') for d in p.relative_to(root).parts):files[str(p.relative_to(s))]=p
for dirname in ['joint-wasm-check','joint-codegen','direct-wasm-check','direct-codegen','final-wasm-check','final-codegen']:
 for name in ['report.json','commands.json','command.json','compiler.txt','compiler.log','guest-stack.log','size.txt','symbols.txt']:
  p=s/dirname/name
  if p.is_file():files[str(p.relative_to(s))]=p
archive=s/'archive';archive.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
digests={}
with tarfile.open(archive/'observations.tar.xz','w:xz',preset=6) as tar:
 for n,p in sorted(files.items()):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);tar.addfile(i,io.BytesIO(b));digests[n]=sha(b)
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {i.name:sha(tar.extractfile(i).read()) for i in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git('add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive bounded memory and linked proposal midpoint qualification')
rev=git('rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git('show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',repo/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=repo/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1],len(digests),size)
