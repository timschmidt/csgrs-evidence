from pathlib import Path
import hashlib,sys,json,csv,statistics
s=Path(__file__).parent
hist=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
sys.path.insert(0,str(s))
from artifact_sizes import native,wasm
def save(name,v):(s/(name+'.json')).write_text(json.dumps(v,indent=2)+'\n')
def arith():
 out={}
 for cpu in [5,15]:
  d={}
  for tag in ['primary','f32-barrier']:
   files=sorted((s/'logs').glob(f'arithmetic-{cpu}-*-{tag}'));assert len(files)==4
   for f in files:
    per={}
    for r in csv.DictReader(f.open()):
     key=r['width'];per.setdefault(key,[]).append(int(r['elapsed_ns'])/int(r['completed_steps']))
     out.setdefault('checksums-'+key,set()).add(r['checksum'])
    for k,rows in per.items():d.setdefault(k,{}).setdefault(tag,[]).append(statistics.median(rows))
  for k,box in d.items():out[f'{cpu}/{k}']=dict(samples=box,percent=100*(statistics.median(box['f32-barrier'])/statistics.median(box['primary'])-1))
 for k in ['checksums-32','checksums-64']:
  assert len(out[k])==1;out[k]=list(out[k])
 save('arithmetic',out)
def images():
 snapshot={};rows=[]
 specs={'standalone-native':('.so',native,['file','text'],['fixed','primary','f32-barrier']), 'standalone-wasm':('.wasm',wasm,['file','code'],['fixed','primary','f32-barrier'])}
 for tag in ['rk-example','rk-cost','proposal-cost','proposal-test','rk_proposal-test']:
  specs[tag]=('-'+tag,native,['file','text','named_text'],['fixed','primary','f32-barrier'])
 for tag,(suffix,reader,keys,versions) in specs.items():
  if tag.endswith('-test'):versions=versions+['f32-barrier-qualified']
  vs=[reader(s/'images'/(v+suffix)) for v in versions];snapshot[tag]=dict(zip(versions,vs))
  protected=tag=='rk-example'
  past=next(r['metrics'] for r in hist['accounts'] if r.get('artifact','').endswith('examples/rk_proposal.rs')) if protected else {}
  for k in keys:
   f,p,c=[r[k] for r in vs[:3]]
   cap=([256,1,512,2] if tag=='standalone-native' else [128,5,256,10] if tag=='standalone-wasm' else [1024,.5,4096,1] if k=='named_text' else [4096,1,16384,2])
   positive=max(0,c-p);carry=max(0,p-f)
   if k in past:carry=max(carry,past[k]['accepted_positive_growth_bytes']+max(0,p-past[k]['retained']))
   cumulative=carry+positive
   rows.append(dict(artifact=tag,metric=k,fixed=f,previous=p,retained=c,increment=positive,cumulative=cumulative,caps=cap,remaining_absolute=cap[2]-cumulative,passes=positive<=cap[0] and 100*positive<=cap[1]*p and cumulative<=cap[2] and 100*cumulative<=cap[3]*f))
   if len(vs)==4:
    n=vs[-1][k];i=max(0,n-c);d=cumulative+i;cap=[16384,1,32768,2]
    rows.append(dict(artifact=tag+'-with-regressions',metric=k,fixed=f,previous=c,retained=n,increment=i,cumulative=d,caps=cap,remaining_absolute=cap[2]-d,passes=i<=cap[0] and 100*i<=cap[1]*c and d<=cap[2] and 100*d<=cap[3]*f))
 save('linked-images',snapshot);save('linked-accounts',rows)
 print('incomplete',[(r['artifact'],r['metric'],r['increment'],r['cumulative']) for r in rows if not r['passes']])
def receipt():
 def get(tag):
  f=(s/'logs'/f'rk-f32-barrier-5-1-{tag}')
  if not f.exists():f=next((s/'logs').glob('rk-f32-barrier-5-*-'+tag))
  return [l for l in f.read_text().splitlines() if l.startswith(('EXACT','|'))]
 a,b=map(get,['primary','f32-barrier']);print('receipts',len(a),len(b),sum(x!=y for x,y in zip(a,b)))
 save('rk-differential',dict(primary=a,candidate=b,identical=a==b))
if __name__=='__main__':
 for name in sys.argv[1:]:{'arith':arith,'images':images,'receipt':receipt}[name]()
