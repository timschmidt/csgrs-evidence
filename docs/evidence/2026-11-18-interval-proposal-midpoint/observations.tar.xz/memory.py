from pathlib import Path
import json,sys
s=Path(__file__).parent;tag=sys.argv[1]
def life(v):
 ps=list((s/'logs').glob('life-'+v+'-*'));assert len(ps)==12
 rows={};bits={};traffic={}
 for p in ps:
  for l in p.read_text().splitlines():
   t,j,w,*rest=l.split();k=(t,int(j),int(w));r=list(map(int,rest))
   if t=='HEAP':
    assert r[-2]==0
    bits.setdefault(k,set()).add(r[-1]);traffic.setdefault(k,[]).append(r[:-1]);n=r[-3]
   else:n=r[-1]
   rows.setdefault(k,[]).append(n)
 return {k:max(i) for k,i in rows.items()},bits,traffic
out=[]
def metrics(typ,raw):
 f,p,c=raw
 for k in sorted(c):
  metric,i,w=k;inc=max(0,c[k]-p[k]);cum=max(0,p[k]-f[k])+inc
  allow=(128,1,256,2) if typ=='rk' and (metric=='STACK' or i%2) else (0,0,0,0)
  good=inc<=allow[0] and 100*inc<=allow[1]*p[k] and cum<=allow[2] and 100*cum<=allow[3]*f[k]
  out.append(dict(workload=typ,key=k,fixed=f[k],preceding=p[k],candidate=c[k],increment=inc,cumulative=cum,caps=allow,passes=good))
def scalar(v):
 out={}
 for p in (s/'logs').glob('stack-'+v+'-*'):
  for l in p.read_text().splitlines():
   i,w,pattern,n,res=map(int,l.split());out.setdefault(('STACK',i,w),[]).append(n)
 return {k:max(vals) for k,vals in out.items()}
vs=['fixed','primary',tag];rk=[life(v) for v in vs];metrics('rk',[r[0] for r in rk]);metrics('scalar',[scalar(v) for v in vs])
headrooms={v:min(int(l.split()[-1]) for p in (s/'logs').glob('guard-'+v+'-*') for l in p.read_text().splitlines()) for v in vs}
assert min(headrooms.values())>=1048576
(s/(tag+'-memory.json')).write_text(json.dumps(dict(headrooms=headrooms,rows=out),indent=2)+'\n')
print('failed',[(r['workload'],r['key'],r['increment'],r['cumulative']) for r in out if not r['passes']])
print('headroom',headrooms)
