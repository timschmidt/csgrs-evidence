set -eu
s=/dev/shm/interval-midpoint-review
mode=$1;tag=$2;round=0
for a in "$tag" primary primary "$tag" primary "$tag" "$tag" primary; do
 round=$((round+1))
 if test "$a" = primary; then b="$tag"; else b=primary; fi
 for cpu in 6 16; do
  if test "$cpu" = 6; then var=$a; else var=$b; fi
  if test "$mode" = scalar; then cmd=("$s/packed-probe" "$s/images/width-$var.so" timing); else cmd=("$s/images/$var-rk-cost"); fi
  LD_BIND_NOW=1 setarch x86_64 -R taskset -c "$cpu" "${cmd[@]}" > "$s/logs/width-$tag-$cpu-$round-$var" 2>&1 &
 done
 rc=0;for pid in $(jobs -p); do wait "$pid" || rc=1; done;test "$rc" -eq 0
done
