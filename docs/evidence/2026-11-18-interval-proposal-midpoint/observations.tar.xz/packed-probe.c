#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include <time.h>
#include <inttypes.h>
extern void *__libc_malloc(size_t), *__libc_calloc(size_t,size_t), *__libc_realloc(void*,size_t);
extern void __libc_free(void*);
static _Thread_local int track;
static _Thread_local volatile unsigned events;
void *malloc(size_t n){if(track) ++events;return __libc_malloc(n);}
void *calloc(size_t n,size_t k){if(track) ++events;return __libc_calloc(n,k);}
void *realloc(void *p,size_t n){if(track) ++events;return __libc_realloc(p,n);}
void free(void *p){if(track) ++events;__libc_free(p);}
extern size_t measure_stack(void (*)(void*),void*,int,unsigned char);
static uint64_t (*fn32)(uint32_t,uint32_t);
static uint64_t (*fn64)(uint64_t,uint64_t);
struct call {unsigned width; uint64_t a,b; volatile uint64_t result;};
static void invoke(void *arg){
 struct call *c=arg;events=0;track=1;
 c->result=c->width==32?fn32(c->a,c->b):fn64(c->a,c->b);
 track=0;if(events)abort();
}
static uint64_t now(void){struct timespec t;if(clock_gettime(CLOCK_MONOTONIC_RAW,&t))abort();return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
int main(int argc,char **argv){
 if(argc!=3)return 1;
 void *lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib)abort();
 fn32=dlsym(lib,"mid32");if(!fn32)abort();
 if(strcmp(argv[2],"stack")==0){
  struct call c[]={{32,0x3f700000,0x3fa00000},{32,1,5},{32,0x7f7ffffd,0x7f7fffff},{64,0x3fe0000000000000,0x3ff0000000000000},{64,1,5},{64,0x7feffffffffffffd,0x7fefffffffffffff}};
  for(unsigned i=0;i<3;i++)for(int warm=0;warm<2;warm++)for(int pat=0;pat<2;pat++){
   size_t n=measure_stack(invoke,c+i,warm,pat?0xaa:0x55);printf("%u %d %d %zu %"PRIu64"\n",i,warm,pat,n,c[i].result);
  }
 }else{
  for(int j=0;j<19;j++)for(int w=32;w<=32;w+=32){
   uint64_t hash=0,start=now();
   if(w==32)for(uint32_t i=0;i<500000;i++)hash+=fn32(0x3f000000+(i&0x7fff),0x40000000+(i&0xffff));
   if(w==64)for(uint32_t i=0;i<500000;i++)hash+=fn64(0x3fe0000000000000ULL+(i&0x7fff),0x4000000000000000ULL+(i&0xffff));
   printf("%d %d %"PRIu64" %"PRIu64"\n",j,w,now()-start,hash);
  }
 }
 return 0;
}
