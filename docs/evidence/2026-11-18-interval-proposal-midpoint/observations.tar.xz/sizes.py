from pathlib import Path
import hashlib,subprocess,json,re,sys
s=Path(__file__).parent
def metrics(p):
 d=p.read_bytes();r=dict(file=len(d))
 if p.suffix=='.wasm':
  def consume(i):
   n=shift=0
   while True:
    b=d[i];i+=1;n|=(b&127)<<shift
    if b<128:return n,i
    shift+=7
  i=8
  while i<len(d):
   tag=d[i];n,i=consume(i+1)
   if tag==10:r['code']=n
   i+=n
 else:
  m=re.search(r'\s\.text\s+PROGBITS\s+\S+\s+\S+\s+([\da-f]+)',subprocess.check_output(['readelf','-SW',p],text=True));r['text']=int(m[1],16)
 return r
for suffix in ('.wasm','.so'):
 vals=[metrics(s/'images'/(v+suffix)) for v in ['fixed','primary',sys.argv[1]]]; print(suffix,vals)
 for k in vals[0]:
  f,p,c=(v[k] for v in vals);i=max(0,c-p);acc=i+max(0,p-f)
  a,b,x,y=(128,5,256,10) if suffix=='.wasm' else (256,1,512,2)
  print(k,i,acc,i<=a and i*100<=b*p and acc<=x and acc*100<=y*f)
