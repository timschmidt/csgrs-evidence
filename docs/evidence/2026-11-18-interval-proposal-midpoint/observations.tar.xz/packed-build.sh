set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
tag=$1
src=$2
export CARGO_TARGET_DIR="$s/build-packed-$tag"
cd "$s/packed-client"
sed "s|SOURCE|$src|g" Cargo.toml.in > Cargo.toml
cargo generate-lockfile --offline
cargo build --release --locked
cp "$CARGO_TARGET_DIR/release/libinterval_midpoint_client.so" "$s/images/packed-$tag.so"
cargo build --release --locked --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_midpoint_client.wasm" "$s/images/packed-$tag.wasm"
