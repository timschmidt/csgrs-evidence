set -eu
s=/dev/shm/interval-midpoint-review
i=0
for v in center primary primary center primary center center primary;do
 i=$((i+1));if test "$v" = center;then alt=primary;else alt=center;fi
 for cpu in 5 15;do
  if test "$cpu" = 5;then tag=$v;else tag=$alt;fi
  setarch x86_64 -R taskset -c "$cpu" "$s/images/$tag-proposal-cost" > "$s/logs/arithmetic-$cpu-$i-$tag" 2>"$s/logs/arithmetic-layout-$cpu-$i-$tag" &
 done
 rc=0;for proc in $(jobs -p);do wait "$proc" || rc=1;done;test "$rc" = 0
done
