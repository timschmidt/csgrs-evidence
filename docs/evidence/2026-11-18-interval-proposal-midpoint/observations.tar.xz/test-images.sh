set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
r="$s/cost-source"
cd "$r"
export CARGO_TARGET_DIR="$s/rk-build"
for tag in fixed primary fused qualified; do
 case $tag in
 fixed) git restore crates/hyperinterval/src/proposal.rs;git checkout --detach -q c9f1f9ac5;;
 primary) git checkout --detach -q 6b7b940ed;;
 fused) cp "$s/fused.rs" crates/hyperinterval/src/proposal.rs;;
 qualified) cp /mnt/development/csgrs/crates/hyperinterval/tests/proposal.rs crates/hyperinterval/tests/proposal.rs;cp /mnt/development/csgrs/crates/hyperdynamics/tests/rk_proposal.rs crates/hyperdynamics/tests/rk_proposal.rs;;
 esac
 for target in proposal rk_proposal; do
  if test "$target" = proposal; then crate=hyperinterval; else crate=hyperdynamics; fi
  cargo test --release --locked -p "$crate" --all-features --test "$target" --no-run --message-format=json > "$s/logs/$tag-$target-build.jsonl"
  file=$(python3 -c 'import json,sys; print(next(a["executable"] for l in open(sys.argv[1]) if (a:=json.loads(l)).get("executable") and a["target"]["name"]==sys.argv[2]))' "$s/logs/$tag-$target-build.jsonl" "$target")
  cp "$file" "$s/images/$tag-$target-test"
  if test "$tag" = qualified; then "$file" > "$s/logs/$tag-$target-test"; fi
 done
 if test "$tag" = fixed; then cargo build --locked --release -p hyperinterval --example proposal_cost --features float-proposal;cp "$CARGO_TARGET_DIR/release/examples/proposal_cost" "$s/images/fixed-proposal-cost";fi
done
