const fs=require('fs'),assert=require('assert/strict'),s=__dirname;
(async()=>{
for(const tag of ['fixed','primary','radius-final']){
 const m=await WebAssembly.compile(fs.readFileSync(s+'/images/width-'+tag+'.wasm'));assert.deepEqual(WebAssembly.Module.imports(m),[]);
 for(let run=0;run<2;run++){
  const {exports:x}=await WebAssembly.instantiate(m),p=x.memory.buffer.byteLength;
  const data=fs.readFileSync(s+'/radius-corpus-32.bin');let count=0,bad=0;
  for(let i=0;i<data.length;i+=16){count++;bad+=Number(x.mid32(data.readUInt32LE(i),data.readUInt32LE(i+4))!==BigInt(data.readUInt32LE(i+12)));}
  for(const [a,b] of [[2,1],[0x7f800000,0x7f800000],[0x7fc00000,0]])assert.equal(x.mid32(a,b),-1n);
  assert.equal(x.memory.buffer.byteLength,p);if(tag==='radius-final')assert.equal(bad,0);
  console.log({tag,run,count,bad,bytes:p});
 }
}
})().catch(err=>{console.error(err);process.exitCode=1});
