set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
export CARGO_TARGET_DIR="$s/rk-build"
r="$s/cost-source"
for v in primary fused; do
 cd "$r"
 if test "$v" = primary; then git restore crates/hyperinterval/src/proposal.rs; else cp "$s/fused.rs" crates/hyperinterval/src/proposal.rs; fi
 cargo build --locked --release -p hyperdynamics --example rk_proposal --all-features
 cp "$CARGO_TARGET_DIR/release/examples/rk_proposal" "$s/images/$v-rk-example"
 "$s/images/$v-rk-example" > "$s/logs/$v-example"
 cargo build --locked --release -p hyperinterval --example proposal_cost --features float-proposal
 cp "$CARGO_TARGET_DIR/release/examples/proposal_cost" "$s/images/$v-proposal-cost"
 cd "$s/rk-cost"; cargo build --release --locked
 cp "$CARGO_TARGET_DIR/release/rk-proposal-cost-probe" "$s/images/$v-rk-cost"
done
