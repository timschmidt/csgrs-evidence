set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
tag=$1
src=$2
export CARGO_TARGET_DIR="$s/build-ops-$tag"
cd "$s/ops-client"
sed "s|SOURCE|$src|g" Cargo.toml.in > Cargo.toml
cargo generate-lockfile --offline
cargo build --release --locked
cp "$CARGO_TARGET_DIR/release/libinterval_midpoint_client.so" "$s/images/ops-$tag.so"
cargo build --release --locked --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_midpoint_client.wasm" "$s/images/ops-$tag.wasm"
