use hyperinterval::F32ProposalInterval;
#[unsafe(no_mangle)]
pub extern "C" fn mid32(a:u32,b:u32)->u64 {
 F32ProposalInterval::new(f32::from_bits(a),f32::from_bits(b)).ok().and_then(|span|{span.radius_estimate()}).map(|r|u64::from(r.to_bits())).unwrap_or(u64::MAX)
}
