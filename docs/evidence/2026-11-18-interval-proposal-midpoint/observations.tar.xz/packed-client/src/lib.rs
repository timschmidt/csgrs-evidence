use hyperinterval::F32ProposalInterval;
#[unsafe(no_mangle)]
pub extern "C" fn mid32(a:u32,b:u32)->u64 {
    F32ProposalInterval::new(f32::from_bits(a),f32::from_bits(b)).ok().and_then(|span|{
        let (mid,radius)=span.midpoint_radius_estimates()?;
        Some((u64::from(mid.to_bits()) << 32) | u64::from(radius.to_bits()))
    }).unwrap_or(u64::MAX)
}
