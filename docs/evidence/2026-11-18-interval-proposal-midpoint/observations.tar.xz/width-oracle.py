from pathlib import Path
import ctypes as C,struct
s=Path(__file__).parent
for tag in ['fixed','primary','radius-final']:
 lib=C.CDLL(str(s/'images'/('width-'+tag+'.so')))
 f=lib.mid32;f.argtypes=[C.c_uint32,C.c_uint32];f.restype=C.c_uint64
 n=bad=0
 for a,b,mid,radius in struct.iter_unpack('<IIII',(s/'radius-corpus-32.bin').read_bytes()):
  n+=1;bad+=f(a,b)!=radius
 for a,b in [(2,1),(0x7f800000,0x7f800000),(0x7fc00000,0)]:
  assert f(a,b)==2**64-1
 print(tag,n,bad)
 if tag=='radius-final':assert bad==0
