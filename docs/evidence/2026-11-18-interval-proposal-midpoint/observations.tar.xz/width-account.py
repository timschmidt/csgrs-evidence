from pathlib import Path
import json,sys
from artifact_sizes import native,wasm
s=Path(__file__).parent;repo=Path.cwd()
versions=['fixed','primary','radius-final']
record='docs/evidence/2026-11-18-interval-proposal-midpoint'
fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb'
full={};summary={}
for ext,fn,caps,capacity,reserve in [('so',native,[256,1,512,2],64*2**20,16*2**20),('wasm',wasm,[128,5,256,10],65536,16384)]:
 ds=[fn(s/'images'/('width-'+tag+'.'+ext)) for tag in versions]
 full[ext]=dict(zip(versions,ds))
 fields=['file','code'] if ext=='wasm' else ['file','text','named_text','rodata']
 rows={}
 for k in fields:
  f,p,c=[d[k] for d in ds];inc=max(0,c-p);cum=max(0,p-f)+inc
  assert inc<=caps[0] and inc*100<=p*caps[1] and cum<=caps[2] and cum*100<=f*caps[3],(k,f,p,c)
  rows[k]=[f,p,c,inc,cum,caps[2]-cum,round(caps[3]-100*cum/f,6)]
 free=capacity-ds[2]['file'];assert free>=reserve
 summary[ext]=dict(metrics=rows,caps=caps,capacity=capacity,required_free=reserve,free=free)
(s/'width-linked-images.json').write_text(json.dumps(full,indent=2)+'\n')
stacks=[]
for case in range(3):
 for warm in range(2):
  vals=[]
  for tag in versions:
   files=list((s/'logs').glob(f'stack-width-{tag}-*'));assert len(files)==4
   raw=[int(l.split()[3]) for f in files for l in f.read_text().splitlines() if tuple(map(int,l.split()[:2]))==(case,warm)]
   assert len(raw)==8;vals.append(max(raw))
  assert vals[0]==vals[1]==vals[2]
  stacks.append([case,warm,*vals])
(s/'width-stack.json').write_text(json.dumps(stacks,indent=2)+'\n')
d=json.loads((s/'linked-images.json').read_text());rows=json.loads((s/'linked-accounts.json').read_text());assert all(r['passes'] for r in rows)
for tag,entry in d.items():
 p,c=[entry[v] for v in versions[1:]]
 if tag=='standalone-wasm':assert [r for r in p['sections'] if r['kind']] == [r for r in c['sections'] if r['kind']]
 else:assert p['section_hashes']==c['section_hashes'],tag
tests={}
for test in ['proposal-test','rk_proposal-test']:
 r=[x for x in rows if x['artifact'] in [test,test+'-with-regressions']]
 # Rows in the existing suite and in the augmented suite use different caps.
 for x in r:x['remaining_cumulative_percent']=round(x['caps'][3]-100*x['cumulative']/x['fixed'],6)
 n=d[test]['radius-final-qualified']['file'];assert 64*2**20-n>=16*2**20
 tests[test]=dict(metrics=r,capacity=64*2**20,required_free=16*2**20,free=64*2**20-n)
account=dict(source=(s/'retained-revision').read_text().strip(),replay=(s/'replay-revision').read_text().strip(),fixed=fixed,preceding='6b7b940ed',evidence=record,
 benefit='Return a finite, independently rounded binary32 proposal half-width, including subnormal intervals and the full finite range. The RK4 regression replays exact subnormal outputs through a second flow.',
 scope='Rust 1.95 release native x86_64 Linux and bare wasm32 without default features, float-proposal. The client constructs the interval from IEEE bits and materializes its half-width. Native qualification slots are independent of firmware flash.',
 columns=['fixed_bytes','preceding_bytes','retained_bytes','incremental_charge_bytes','cumulative_charge_bytes','remaining_cumulative_bytes','remaining_cumulative_percent'],
 cap_columns=['incremental_bytes','incremental_percent','cumulative_bytes','cumulative_percent'],
 clients=summary,tests=tests,
 existing_consumers='The sampled existing native .text, .rodata and .data sections, and every non-custom section of the legacy midpoint WASM client, matched the preceding release. Prior RK4 charges remain in their accounts. No memory or firmware exception was charged.')
(s/'width-account.json').write_text(json.dumps(account,indent=2)+'\n')
if 'write' in sys.argv:
 ledger=repo/'docs/research/interval-size-accounts.json';acc=json.loads(ledger.read_text());assert 'binary32_proposal_radius' not in acc
 acc['binary32_proposal_radius']=account
 ledger.write_text(json.dumps(acc,ensure_ascii=False,indent=2)+'\n')
