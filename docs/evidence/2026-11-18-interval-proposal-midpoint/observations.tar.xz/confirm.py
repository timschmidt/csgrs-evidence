from pathlib import Path
import json,ast,statistics,sys
s=Path(__file__).parent;mode,tag=sys.argv[1:];out={}
for cpu in (6,16):
 d={}
 for v in ['primary',tag]:
  files=sorted((s/'logs').glob(f'{mode}-{tag}-{cpu}-*-{v}'));assert len(files)==4
  vals={}
  for f in files:
   proc={}
   for l in f.read_text().splitlines():
    if mode=='scalar':
     i,w,n,c=map(int,l.split());proc.setdefault(str(w),[]).append(n/500000)
    elif l.startswith('TIMING '):
     nm,arr=l[7:].split(' ns_per_operation=');proc[nm]=ast.literal_eval(arr)
   for k,num in proc.items():vals.setdefault(k,[]).append(statistics.median(num))
  d[v]=vals
 for k,z in d[tag].items():
  p=d['primary'][k];x=statistics.median(p);y=statistics.median(z)
  out[str(cpu)+'/'+k]=dict(primary=p,candidate=z,primary_ns=x,candidate_ns=y,percent=round((y/x-1)*100,4))
(s/(mode+'-'+tag+'-confirm.json')).write_text(json.dumps(out,indent=2)+'\n')
for k,r in out.items():
 if mode=='scalar' or 'proposal-and-proof' in k:print(k,round(r['primary_ns'],3),round(r['candidate_ns'],3),r['percent'])
