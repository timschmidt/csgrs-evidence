from pathlib import Path
import json,sys,hashlib
from artifact_sizes import native,wasm
s=Path(__file__).parent
repo=Path.cwd()
ledger=repo/'docs/research/interval-size-accounts.json'
record='docs/evidence/2026-11-18-interval-proposal-midpoint'
fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb'
versions=['fixed','primary','f32-joint'];full={};out={};stacks=[]
for role in ['radius','packed']:
 for ext,read,cap,capacity,reserve in [('so',native,[256,1,512,2],64*2**20,16*2**20),('wasm',wasm,[128,5,256,10],65536,16384)]:
  key=role+'-'+ext
  ds=[read(s/'images'/f'{role}-{v}.{ext}') for v in versions]
  full[key]=dict(zip(versions,ds))
  fields=['file','text','named_text','rodata'] if ext=='so' else ['file','code']
  rows={}
  for k in fields:
   f,p,c=[d[k] for d in ds]
   inc=max(0,c-p);acc=max(0,p-f)+inc
   assert inc<=cap[0] and inc*100<=p*cap[1] and acc<=cap[2] and acc*100<=f*cap[3],(key,k,f,p,c,cap)
   rows[k]=[f,p,c,inc,acc,cap[2]-acc,round(cap[3]-100*acc/f,6)]
  headroom=capacity-ds[2]['file'];assert headroom>=reserve
  out[key]=dict(metrics=rows,caps=cap,capacity_bytes=capacity,required_free_bytes=reserve,free_bytes=headroom)
 prefix='joint' if role=='radius' else 'packed'
 for case in range(3):
  for warm in range(2):
   vals=[]
   for v in versions:
    pp=list((s/'logs').glob(f'stack-{prefix}-{v}-*'));assert len(pp)==4
    raw=[int(l.split()[3]) for f in pp for l in f.read_text().splitlines() if tuple(map(int,l.split()[:2]))==(case,warm)]
    assert len(raw)==8
    vals.append(max(raw))
   assert vals[2]<=vals[1] and vals[2]<=vals[0],(role,case,warm,vals)
   stacks.append([role,case,warm,*vals])
(s/'joint-final-images.json').write_text(json.dumps(full,indent=2)+'\n')
(s/'joint-final-stack.json').write_text(json.dumps(stacks,indent=2)+'\n')
consumers=json.loads((s/'linked-images.json').read_text())
for k,images in consumers.items():
 a,b=[images[v] for v in versions[1:]]
 if k=='standalone-wasm':
  assert [i for i in a['sections'] if i['kind']!=0]==[i for i in b['sections'] if i['kind']!=0]
 else:
  assert a['section_hashes']==b['section_hashes'],k
accounts=json.loads((s/'linked-accounts.json').read_text());assert all(r['passes'] for r in accounts)
test_rows=[r for r in accounts if r['artifact'] in ('proposal-test','proposal-test-with-regressions')]
data=dict(source=(s/'retained-revision').read_text().strip(),fixed=fixed,preceding='6b7b940ed',evidence=record,
 benefit='Expose independently rounded binary32 midpoint and half-width estimates for finite native proposal intervals, including subnormal and extreme endpoints.',
 scope='Release native x86_64 Linux and bare wasm32, float-proposal without default features. The radius client selects an endpoint statistic by index. The packed client materializes both 32-bit results in one return value. Native qualification slots are separate from flash. Thumb builds are a no_std compilation check.',
 columns=['fixed_bytes','preceding_bytes','retained_bytes','incremental_charge_bytes','cumulative_charge_bytes','remaining_cumulative_bytes','remaining_cumulative_percent'],
 cap_columns=['incremental_bytes','incremental_percent','cumulative_bytes','cumulative_percent'],
 clients=out,proposal_test=test_rows,qualification_slot=dict(capacity=64*2**20,required_free=16*2**20,free=64*2**20-consumers['proposal-test']['f32-joint-qualified']['file']),
 existing_consumers='All measured original executable sections matched on native. The legacy WASM client matched in every non-custom section. Existing RK4 accounts carry their previous positive charges. The full review branch is unadmitted.',
 memory='No positive heap or stack charge. See joint-final-stack.json and the complete RK4 lifetime traces in the evidence archive.')
(s/'joint-ledger.json').write_text(json.dumps(data,indent=2)+'\n')
if 'write' in sys.argv:
 d=json.loads(ledger.read_text());assert 'binary32_proposal_midpoint_radius' not in d
 d['binary32_proposal_midpoint_radius']=data
 ledger.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
