const fs=require('fs'), path=require('path'), root=__dirname;
(async()=>{
const images=await Promise.all(['primary','direct'].map(async (v)=>(await WebAssembly.instantiate(fs.readFileSync(path.join(root,'images','ops-'+v+'.wasm')),{})).instance.exports));
for(const w of [32,64]){
 const widths=BigInt(w),m=(1n<<widths)-1n,sign=(1n<<(widths-1n)),inf= w===32?0x7f800000n:0x7ff0000000000000n, min= w===32?0x00800000n:0x0010000000000000n,one=w===32?0x3f800000n:0x3ff0000000000000n;
 const special=[0n,1n,2n,min-1n,min,one,inf-1n,inf,inf+1n].flatMap(x=>[x,x|sign]);let state=17n;
 const next=()=>{state=(6364136223846793005n*state+1442695040888963407n)&((1n<<64n)-1n);return state;};
 const conv=w==32?Number:x=>x, f=images.map(i=>i['ops'+w]),counts=[0,0,0,0,0,0];let comparisons=0;
 for(let i=0;i<32768;i++){
  const raw=Array.from({length:4},()=>{const r=next();return i%4!==0?special[Number((r>>32n)%BigInt(special.length))]:r&m;});
  const input=raw.map(conv);
  for(let op=0;op<32;op++){
   const status=f[0](op,...input,0);counts[Number(status)]++;
   for(let k=0;k<(Number(status)===1?3:1);k++){if(f[0](op,...input,k)!==f[1](op,...input,k))throw Error(JSON.stringify([i,op,k]));comparisons++;}
  }
 }
 console.log(w,comparisons,counts);
}
})().catch(e=>{console.error(e);process.exitCode=1});
