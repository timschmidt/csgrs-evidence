set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
export CARGO_TARGET_DIR="$s/rk-build"
for tag in fixed primary half; do
 cd "$s/cost-source"
 case $tag in
 primary) git checkout -q --detach 6b7b940ed;;
 half) cp "$s/half.rs" crates/hyperinterval/src/proposal.rs;;
 esac
 cargo build --locked --release -p hyperdynamics --example rk_proposal --all-features
 cp "$CARGO_TARGET_DIR/release/examples/rk_proposal" "$s/images/$tag-rk-example"
 "$s/images/$tag-rk-example" > "$s/logs/$tag-example"
 cd "$s/rk-cost"
 # Reproduce the workspace dependency versions for the public client.
 cp "$s/cost-source/Cargo.lock" Cargo.lock
 cargo build --release --offline
 cargo build --release --locked
 cp "$CARGO_TARGET_DIR/release/rk-proposal-cost-probe" "$s/images/$tag-rk-cost"
done
