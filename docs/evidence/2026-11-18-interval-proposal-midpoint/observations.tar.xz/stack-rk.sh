set -eu
. /dev/shm/hyperinterval-coverage/env
s=/dev/shm/interval-midpoint-review
r="$s/cost-source"
export CARGO_TARGET_DIR="$s/rk-build"
cd "$r"
for tag in fixed primary fused; do
 case $tag in
 fixed) git restore crates/hyperinterval/src/proposal.rs crates/hyperinterval/tests/proposal.rs crates/hyperdynamics/tests/rk_proposal.rs;git checkout --detach -q c9f1f9ac5;;
 primary) git checkout --detach -q 6b7b940ed;;
 fused) cp "$s/fused.rs" "$r/crates/hyperinterval/src/proposal.rs";;
 esac
 cp "$r/Cargo.lock" "$s/rk-stack/Cargo.lock"
 cargo build --release --manifest-path "$s/rk-stack/Cargo.toml"
 cargo build --release --locked --manifest-path "$s/rk-stack/Cargo.toml"
 cp "$CARGO_TARGET_DIR/release/rk-midpoint-lifetime" "$s/images/$tag-rk-stack"
 for i in $(seq 1 12); do setarch x86_64 -R taskset -c 4 "$s/images/$tag-rk-stack" > "$s/logs/life-$tag-$i" 2>"$s/logs/guard-$tag-$i";done
done
