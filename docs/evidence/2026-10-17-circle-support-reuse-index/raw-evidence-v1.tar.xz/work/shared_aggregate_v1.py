"""Aggregate unchanged exact warm phases from matched fresh processes."""
import ast
import json
import re
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, run, sha

build = RUNTIME / 'build-v1'
compiled = read(build / 'result.json')
assert compiled['complete'] and compiled['output_closed'] and not compiled['command_failures']
for location in [RUNTIME / 'corpus-v1', ROOT / 'target/properties/circle-support-reuse-library-v1']:
    terminal = read(location / 'result.json')
    assert terminal['complete'] and terminal['output_closed'] and not terminal['command_failures']
    assert terminal['source_mirror_unchanged'] and not terminal['property_persistence_warnings']
assert read(RUNTIME / 'heap-v1/result.json')['all_instrumented_witnesses_identical']
assert read(RUNTIME / 'support-cost-matched-v1/result.json')['all_exact_rows_equal_and_certified']
output = RUNTIME / 'shared-aggregate-v1'
output.mkdir(exist_ok=False)
pins = {str(path): sha(path) for path in [Path(__file__), W / 'runner_v1.py', W / 'contract-v1.md',
    W / 'shared-aggregate-contract-v1.md', build / 'result.json', build / 'protocol.json',
    RUNTIME / 'corpus-v1/result.json', ROOT / 'target/properties/circle-support-reuse-library-v1/result.json',
    RUNTIME / 'heap-v1/result.json', RUNTIME / 'support-cost-matched-v1/result.json']}
pins |= {value['path']: value['sha256'] for value in compiled['binaries'].values()}
assert all(sha(path) == digest for path, digest in pins.items())
schedule = []
for group in range(7):
    for pair in range(8):
        order = ['baseline', 'candidate'] if (group + pair) % 2 == 0 else ['candidate', 'baseline']
        schedule.extend((group, pair, variant) for variant in order)
dump(output / 'protocol.json', {'input_sha256': pins, 'schedule': schedule,
    'groups': 7, 'processes_per_group_per_variant': 8, 'warm_queries_per_process': 20000,
    'warm_queries_per_group_per_variant': 160000, 'coefficient_shift_bits': 64,
    'aggregate_is_not_one_contiguous_timing': True,
    'all_other_qualification_processes_terminal': True,
    'full_contract': str(W / 'shared-aggregate-contract-v1.md'),
    'source_features_policy_and_oracles_unchanged': True})
commands, samples = [], []
for group, pair, variant in schedule:
    name = f'g{group}-p{pair}-{variant}'
    binary = compiled['binaries'][variant]
    row = run(output, name, [binary['path'],
        'curve_intersection::circle_support_coefficient_probe::shared_coefficient_lookup_cost',
        '--exact', '--ignored', '--nocapture', '--test-threads=1'], output,
        {'CIRCLE_SHARED_BITS': '64', 'CIRCLE_SHARED_REPEATS': '20000'})
    commands.append(row)
    dump(output / 'commands.json', commands)
    if row['exit_code'] != 0:
        break
    text = (output / (name + '.stdout')).read_text()
    assert 'CIRCLE_SHARED_CERTAINTY Certified' in text and 'test result: ok. 1 passed; 0 failed;' in text
    times = [json.loads(value) for value in re.findall(r'CIRCLE_SHARED_SAMPLE (\{[^\n]*\})', text)]
    rows = [ast.literal_eval(value) for value in re.findall(r'CIRCLE_SHARED_ROWS (\[[^\n]*\])', text)]
    assert len(times) == len(rows) == 2
    assert [value['phase'] for value in times] == ['cold', 'warm']
    assert rows[0] == [0] and len(rows[1]) == 20000 and all(value == 0 for value in rows[1])
    assert [value['queries'] for value in times] == [1, 20000]
    assert all(value['coefficient_shift_bits'] == 64 and value['numerator_bits'] == 65
               and value['entries'] == 1 for value in times)
    samples.append({'group': group, 'pair': pair, 'variant': variant,
        'cold_seconds': times[0]['seconds'], 'warm_seconds': times[1]['seconds'],
        'warm_queries': 20000, 'certainty': 'Certified', 'all_exact_rows_disjoint': True,
        'stdout_sha256': sha(output / (name + '.stdout'))})
    dump(output / 'samples.json', samples)
groups = []
for group in range(7):
    values = {variant: [row['warm_seconds'] for row in samples
              if row['group'] == group and row['variant'] == variant]
              for variant in ['baseline', 'candidate']}
    if all(len(value) == 8 for value in values.values()):
        groups.append({'group': group, 'warm_queries_per_variant': 160000,
            'aggregate_warm_seconds': {key: sum(value) for key, value in values.items()}})
comparison = None
if len(groups) == 7:
    baseline = [row['aggregate_warm_seconds']['baseline'] for row in groups]
    candidate = [row['aggregate_warm_seconds']['candidate'] for row in groups]
    ratio = statistics.median(candidate) / statistics.median(baseline)
    positive = sum(c > b for b, c in zip(baseline, candidate))
    separated = min(candidate) > max(baseline)
    comparison = {'baseline_seconds': baseline, 'candidate_seconds': candidate,
        'baseline_median_seconds': statistics.median(baseline),
        'candidate_median_seconds': statistics.median(candidate),
        'candidate_over_baseline_median': ratio,
        'positive_paired_differences': positive, 'candidate_range_above_baseline': separated,
        'predeclared_rejection_criterion_met': ratio > 1.10 and positive == 7 and separated}
assert all(sha(path) == digest for path, digest in pins.items())
failures = [row['name'] for row in commands if row['exit_code'] != 0]
dump(output / 'groups.json', groups)
dump(output / 'result.json', {'complete': True, 'output_closed': True,
    'process_samples': len(commands), 'expected_process_samples': len(schedule),
    'command_failures': failures, 'comparison': comparison,
    'all_completed_results_certified_and_exact_rows_preserved': True,
    'aggregate_is_not_one_contiguous_timing': True, 'read_only_inputs_unchanged': True,
    'cache_admitted': False, 'full_plan_complete': False})
raise SystemExit(0 if len(commands) == len(schedule) and not failures else 101)
