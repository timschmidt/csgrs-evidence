# Grouped shared-support follow-up with the unchanged query contract

Keep every original fifteen-case observation and the ten-size small-batch
matrix. This additional comparison uses the same seven groups and exact query
contract as E44 to check overhead on shared supports without replacing the
original large-coefficient fixtures or assuming that short samples prove zero
cost. The deferred-activation source and diagnostics are frozen before timing.

Each fresh process constructs concentric radius-5 and radius-7 circles with
shared exact center `(2^64 + 3, 0)`. It performs one cold query followed by
20,000 warm queries, validates every Disjoint result independently, materializes
all output rows and requires a strict Certified receipt. No point satisfies
both circle equations. Seven groups contain eight processes per variant each,
with alternating variant order. Each group sums 160,000 complete warm queries;
this is an aggregate of independent timed phases, not one contiguous timer.
Keep every individual cold/warm sample, command, output and resource record.
Input construction, startup, printing and cleanup remain outside phase timers
and inside whole-process observations.

Run after the complete support matrix, allocation observations and both full
library jobs are terminal. Use the unchanged quota-aware supervisor. Reject if
the grouped median exceeds baseline by strictly more than 10%, all seven paired
group differences are positive and candidate groups lie wholly above baseline.
This private-kernel comparison cannot establish native end-to-end speedup or
any other unexecuted admission gate. Retain unfavorable and inconclusive results.
