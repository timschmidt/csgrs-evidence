"""Record the completed qualification, adverse observations, and exact remaining scope."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, sha

names = ['reproduction-v1', 'build-v1', 'cost-preflight-v1', 'cost-matched-v1',
         'support-cost-preflight-v1', 'support-cost-matched-v1', 'heap-v1',
         'corpus-v1', 'proposal-v1', 'shared-aggregate-v2']
locations = {name: RUNTIME / name for name in names}
locations['all-feature-library-v1'] = ROOT / 'target/properties/circle-support-reuse-library-v1'
results = {name: read(path / 'result.json') for name, path in locations.items()}
assert all(v['complete'] and v['output_closed'] for v in results.values())
assert all(not v.get('command_failures', v.get('failures', [])) for v in results.values())
small = read(RUNTIME / 'cost-matched-v1/summary.json')
support, heap, aggregate = (results[name] for name in ['support-cost-matched-v1', 'heap-v1', 'shared-aggregate-v2'])
assert results['cost-matched-v1']['process_samples'] == 140
assert support['process_samples'] == 210 and support['all_exact_rows_equal_and_certified']
assert len(heap['measurements']) == 20 and heap['all_instrumented_witnesses_identical']
assert aggregate['process_samples'] == 336 and len(aggregate['comparisons']) == 3
assert aggregate['all_completed_results_certified_and_exact_rows_preserved']
rejections = [v for v in small + aggregate['comparisons'] if v['predeclared_rejection_criterion_met']]
retention = 'rejected' if rejections else 'unadmitted'
status = ('rejected: deferred support indexing retains a decisive cost regression' if rejections else
          'unadmitted: deferred support indexing removes cold activation regression; full downstream acceptance remains open')
proposal = results['proposal-v1']
assert all(sha(Path(proposal['source']) / path) == digest for path, digest in proposal['proposal_sha256'].items())
assert all(sha(W / 'proposal-source' / path) == digest for path, digest in proposal['proposal_sha256'].items())
library = {}
for name in ['corpus-v1', 'all-feature-library-v1']:
    v = results[name]
    assert v['source_mirror_unchanged'] and not v['property_persistence_warnings']
    assert len(v['test_summaries']) == 1
    state, passed, failed, ignored, measured, filtered = v['test_summaries'][0]
    assert state == 'ok' and failed == measured == filtered == '0'
    library[name] = {'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
lines = [
    '# Deferred circle-support index qualification', '', '**' + status[0].upper() + status[1:] + '.**', '',
    'The production cache is unchanged. The 35-file native integration, unguarded',
    'index, eager guarded index and E45 small-hit revision keep their rejection',
    'records; E44 remains historical and unadmitted. Independently admitted fixes',
    'remain intact. The full properties plan and native source-fidelity work remain open.', '',
    'Owner: Hypercurve operation-local support relation cache; P4/P10/P19/P20/P36.',
    'The isolated candidate uses original ordered equality until an eligible pair',
    'is reused with at least 32 retained relations. Only then does it build the',
    'exact rational index. Distinct-only batches avoid index construction; active',
    'indexes preserve earlier unkeyed witness priority and original insertion rules.',
    'Symbolic and very-large coefficient fallbacks, supported inputs, policy,',
    'certainty and ordered witnesses are unchanged. Cold distinct-query work still',
    'uses a linear scan per query; no bounded-work or uniform-speedup claim is made.', '',
    'Before drafting, fourteen fresh processes reproduced E45 at 33 pairs on the',
    'current production-equivalent revision: +10.2245038% cold median, all seven',
    'paired differences positive and separate ranges. That finding remains failed.',
    'The successor compiled with unchanged tests/probes, flags, compiler, features',
    'and verified frozen dependencies. The E44 baseline executable was reused',
    'read-only under its source/build proof. Both binaries passed all nine focused',
    'contracts. Candidate direct Clippy passed with warnings denied.', '',
    '| Full library configuration | Passed | Failed | Preserved ignored |',
    '| --- | ---: | ---: | ---: |',
]
for name, v in library.items():
    lines.append(f"| {name} | {v['passed']} | {v['failed']} | {v['ignored']} |")
lines += [
    '', 'All-feature compilation and direct Clippy also passed. The no-feature suite',
    'preserves one original ignored benchmark and three diagnostics; all-feature',
    'preserves six original ignored benchmarks and those same diagnostics, which',
    'are separately executed in the measurement matrix. No source-mirror mutation',
    'or property-persistence warning occurred. Counts overlap and are not coverage.',
    'These direct library runs do not establish the full Cargo feature/target',
    'matrix, integration/doc/example/bench, downstream, native/report, binding or',
    'clean external package gates. Those remain required before production admission.', '',
    'All 20 small-batch preflight and 140 matched processes completed. The matched',
    '280 phases each include at least 65,536 queries, independent 3-4-5 and circle',
    'equation checks, strict Certified receipts and complete ordered output rows.',
    'Cold includes fresh batch-cache construction/destruction; warm uses a prepared',
    'cache and includes deferred activation on its first hit. Input construction,',
    'reference preparation, printing and startup are outside the phase timers but',
    'inside process observations. Cold does not reset every scalar/process cache.', '',
    '| Pairs | Baseline cold s | Candidate cold s | Baseline warm s | Candidate warm s |',
    '| ---: | ---: | ---: | ---: | ---: |',
]
for count in sorted({v['count'] for v in small}):
    cold = next(v for v in small if v['count'] == count and v['phase'] == 'cold')
    warm = next(v for v in small if v['count'] == count and v['phase'] == 'warm')
    lines.append(f"| {count} | {cold['baseline_median_seconds']:.9f} | {cold['candidate_median_seconds']:.9f} | {warm['baseline_median_seconds']:.9f} | {warm['candidate_median_seconds']:.9f} |")
lines += [
    '', 'No small-batch case meets the predeclared rejection rule. The 33-pair cold',
    'median is 0.76% lower; some small warm medians remain slightly higher (for',
    'example, +1.87% at four pairs, with overlapping ranges). Every sample remains.', '',
    'The original fifteen-case matrix completed all 30 preflight and 210 matched',
    'processes / 420 matched phases, with independent exact witnesses, Certified',
    'receipts and identical ordered rows. Median phase seconds:', '',
    '| Case | Baseline cold | Candidate cold | Baseline warm | Candidate warm |',
    '| --- | ---: | ---: | ---: | ---: |',
]
for case, parameter in dict.fromkeys((v['case'], v['parameter']) for v in support['comparisons']):
    cold = next(v for v in support['comparisons'] if (v['case'], v['parameter'], v['phase']) == (case, parameter, 'cold'))['median_seconds']
    warm = next(v for v in support['comparisons'] if (v['case'], v['parameter'], v['phase']) == (case, parameter, 'warm'))['median_seconds']
    lines.append(f"| {case} {parameter} | {cold['baseline']:.9f} | {cold['candidate']:.9f} | {warm['baseline']:.9f} | {warm['candidate']:.9f} |")
lines += [
    '', 'Single-query and sub-millisecond phases are diagnostic controls. The original',
    'shared-support warm medians were +3.74%, +8.98% and +19.59% for shifts of 64,',
    '65,536 and 1,048,576 bits, with overlapping ranges. All remain adverse evidence.',
    'The independently predeclared follow-up therefore includes all three sizes,',
    'not just the original 64-bit control. Source, query count, exact concentric',
    'circle oracle, strict receipts and materialized Disjoint rows stay unchanged.',
    'After both functional suites and allocation work were terminal, 336 fresh',
    'processes supplied seven groups per size, eight processes per variant/group.',
    'Each group aggregates 160,000 warm queries from independent 20,000-query',
    'phases; it is not one contiguous timer or an end-to-end native workload.', '',
    '| Shift bits | Baseline group s | Candidate group s | Change | Positive pairs | Separate higher range | Rejection rule |',
    '| ---: | ---: | ---: | ---: | ---: | --- | --- |',
]
for v in aggregate['comparisons']:
    lines.append(f"| {v['bits']} | {v['baseline_median_seconds']:.9f} | {v['candidate_median_seconds']:.9f} | {(v['candidate_over_baseline_median'] - 1) * 100:+.4f}% | {v['positive_paired_differences']}/7 | {v['candidate_range_above_baseline']} | {v['predeclared_rejection_criterion_met']} |")
lines += [
    '', 'The rule requires strictly more than 10% median overhead, all seven paired',
    'differences positive and fully separated ranges. No threshold is rounded.',
    'The decision preserves favorable, unfavorable and inconclusive observations.', '',
    'All 20 whole-process heap observations preserve uninstrumented witnesses.',
    'Their scope includes input construction, queries, validation, output, printing',
    'and cleanup; instrumented time is excluded from latency. Index storage raises',
    'peak heap in indexed batches even where allocation counts fall. These are not',
    'isolated cache-byte measurements or an internal resource bound.', '',
    '| Workload | Baseline allocations / peak | Candidate allocations / peak |',
    '| --- | --- | --- |',
]
for case, parameter in dict.fromkeys((v['case'], v['parameter']) for v in heap['measurements']):
    values = {v['variant']: v for v in heap['measurements'] if v['case'] == case and v['parameter'] == parameter}
    b, c = values['baseline'], values['candidate']
    lines.append(f"| {case} {parameter} | {b['allocation_calls']} / {b['peak_heap_human_readable']} | {c['allocation_calls']} / {c['peak_heap_human_readable']} |")
lines += [
    '', 'Matched diagnostic executable sizes (file/text/data/bss bytes):', '',
]
for variant, v in heap['binary_sizes'].items():
    lines.append(f"- {variant}: {v['file_bytes']} / {v['text_bytes']} / {v['data_bytes']} / {v['bss_bytes']}.")
lines += [
    '', 'These are test harness sizes, not distributed package measurements.',
    'The additional all-feature output root used its separately declared 128 MiB',
    'planning allowance while retaining the 512 MiB repository free-space guard.',
    'The planning allowance is not a hard peak-byte limit. All commands preserved',
    'the declared 1,800-second/8 GiB containment, 2 GiB host memory reserve and',
    '256 MiB /dev/shm quota reserve. Original native CPU/wall limits are unchanged.',
    'No completed target was reopened. Full fresh Cargo/downstream builds remain',
    'dependent on larger writable storage; the requested Disk A directory is absent.', '',
    'A source review also found a contradictory README sentence claiming text',
    'typed-failure migration is pending. Current signatures and the same README',
    'already document Result-returning TrueType/Hershey APIs. The proposed small',
    'documentation correction is preserved separately and is not applied here.', '',
    'Raw evidence, helpers, exact source proposals and every adverse result are',
    'retained in the verified archive with per-member hashes. Every new physical',
    'path is hashed independently. Only current_work changes in the ledger.',
    'The inherited 27,093 missing paths remain disclosed; there is no successful',
    'whole-history audit, release claim, whole-plan completion or production admission.', '',
]
assert not (W / 'progress-v1.md').exists()
(W / 'progress-v1.md').write_text('\n'.join(lines))
inputs = [Path(__file__), W / 'contract-v1.md', W / 'library-contract-v1.md',
          W / 'shared-aggregate-contract-v2.md', W / 'progress-v1.md', W / 'readme-review-v1.json']
for path in locations.values():
    inputs.extend(p for name in ['protocol.json', 'commands.json', 'result.json'] if (p := path / name).is_file())
dump(W / 'decision-v1.json', {
    'complete': True, 'main_parent_commit': read(RUNTIME / 'build-v1/protocol.json')['base_commit'],
    'status': status, 'retention_decision': retention, 'cache_index_admitted': False,
    'source_changes_applied': False, 'implementation_sha256': {}, 'proposal_sha256': proposal['proposal_sha256'],
    'input_sha256': {str(p): sha(p) for p in inputs}, 'library_results': library,
    'focused_tests_per_variant': 9, 'candidate_strict_direct_clippy_configurations': ['no-feature', 'all-features'],
    'matched_small_processes': 140, 'matched_support_processes': 210,
    'aggregate_shared_processes': 336, 'aggregate_shared_comparisons': aggregate['comparisons'],
    'decisive_rejection_cases': rejections,
    'short_shared_support_warm_comparisons': [v for v in support['comparisons'] if v['case'] == 'shared-coefficient' and v['phase'] == 'warm'],
    'allocation_observations': 20, 'diagnostic_binary_sizes': heap['binary_sizes'],
    'all_feature_output_bytes': results['all-feature-library-v1']['retained_output_bytes'],
    'native_disposition_preserved': True, 'pending_native_paths_remaining': 0,
    'full_archived_integration_admitted': False, 'native_runtime_admitted': False, 'full_plan_complete': False,
    'limits': ['Private-kernel timings; no end-to-end speedup, zero-overhead, package-size or isolated-cache-heap claim.',
        'Original linear miss search remains; internal total-work and heap-byte bounds stay open.',
        'Full affected Cargo/downstream/native/report/binding and external-release validation remains required.',
        '27,093 inherited missing paths remain disclosed.'],
    'next': ['Use the complete measured result to decide the next isolated cache step; preserve all original fixtures and gates.',
        'Require affected downstream, original native workload/report and real binding gates before retention.',
        'Correct the independently reproduced stale text-migration sentence in a separate documentation change.',
        'Continue ordinary strict completion, provenance, resource contracts, complete user-path validation and every remaining property/target.']})
print(status)
