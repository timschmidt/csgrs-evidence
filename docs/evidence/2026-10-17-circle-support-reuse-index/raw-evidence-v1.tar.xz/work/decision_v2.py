"""Record measured progress with both whole-library qualifications incomplete."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, sha

L = ROOT / 'target/properties/circle-support-reuse-library-v1'
G = Path('/run/user/1000/csgrs-circle-support-reuse-shared-v4')
locations = {name: RUNTIME / name for name in ['reproduction-v1', 'build-v1', 'cost-preflight-v1',
    'cost-matched-v1', 'support-cost-preflight-v1', 'support-cost-matched-v1', 'heap-v1',
    'corpus-v1', 'proposal-v1', 'all-feature-clippy-v1', 'shared-aggregate-v3']}
locations.update({'all-feature-library-v1': L, 'shared-aggregate-v4': G})
results = {name: read(path / 'result.json') for name, path in locations.items()}
for name, result in results.items():
    assert result['complete'] and result['output_closed']
    if name in ['corpus-v1', 'all-feature-library-v1']:
        assert result['command_failures'] == (['tests'] if name == 'corpus-v1' else ['tests', 'clippy'])
    else:
        assert not result.get('command_failures', result.get('failures', []))
small = read(RUNTIME / 'cost-matched-v1/summary.json')
support, heap, grouped = [results[name] for name in ['support-cost-matched-v1', 'heap-v1', 'shared-aggregate-v4']]
assert results['cost-matched-v1']['process_samples'] == 140
assert support['process_samples'] == 210 and support['all_exact_rows_equal_and_certified']
assert len(heap['measurements']) == 20 and heap['all_instrumented_witnesses_identical']
assert grouped['process_samples'] == 336 and len(grouped['comparisons']) == 3
assert results['shared-aggregate-v3']['process_samples'] == 336
assert grouped['all_completed_results_certified_and_exact_rows_preserved']
rejected = [v for v in small + grouped['comparisons'] if v['predeclared_rejection_criterion_met']]
retention = 'rejected' if rejected else 'unadmitted'
status = ('rejected: deferred index retains a decisive measured regression' if rejected else
    'unadmitted: deferred indexing removes cold activation regression; whole-library and downstream qualification remain incomplete')
proposal = results['proposal-v1']
assert all(sha(Path(proposal['source']) / p) == digest == sha(W / 'proposal-source' / p)
           for p, digest in proposal['proposal_sha256'].items())
library = {}
for name in ['corpus-v1', 'all-feature-library-v1']:
    result = results[name]
    assert result['source_mirror_unchanged'] and not result['property_persistence_warnings']
    assert result['test_summaries'] == []
    command = read(locations[name] / 'tests.result.json')
    assert command['exit_code'] == -15 and command['external_stop_reason'] == 'repository_free_bytes-reserve'
    output = (locations[name] / 'tests.stdout').read_text()
    library[name] = {'completed': False, 'reported_individual_passes': output.count(' ... ok'),
        'failure_markers': output.count(' ... FAILED'), 'exit_code': -15,
        'elapsed_seconds': command['elapsed_seconds'], 'external_stop_reason': command['external_stop_reason'],
        'terminal_test_summary': None, 'source_mirror_unchanged': True, 'property_persistence_warnings': False}
assert read(L / 'clippy.result.json')['not_run']
lines = ['# Deferred circle-support indexing: partial qualification', '', '**' + status + '.**', '',
    'Production is unchanged. The earlier 35-file native bundle and rejected cache',
    'proposals remain rejected; independently admitted fixes remain intact. E44',
    'remains historical and unadmitted. The full properties plan stays open.', '',
    'Owner: Hypercurve operation-local support cache, under P4/P10/P19/P20/P36.',
    'The candidate retains ordered equality lookup until an eligible pair is reused',
    'with at least 32 relations. Distinct-query batches avoid building an unused',
    'index. Active indexes keep exact rational keys, earlier unkeyed witness priority,',
    'symbolic/very-large fallback, original insertion rules and ordered witnesses.',
    'The single-policy batch lifetime and supported input domain are unchanged.',
    'Distinct cold queries still require linear scans; no total-work bound follows.', '',
    'Fourteen fresh processes first reproduced E45 at 33 pairs: +10.2245038% cold',
    'median, seven positive pairs and separate ranges. The successor then compiled',
    'with identical tests/probes, features, flags, compiler and verified frozen',
    'dependencies. The E44 baseline executable was reused read-only with its build',
    'and source proof. Both binaries passed nine unchanged focused contracts.',
    'Candidate no-feature direct Clippy passed with warnings denied.', '',
    '| Whole-library attempt | Reported individual passes | Exit | Outcome |',
    '| --- | ---: | ---: | --- |']
for name, v in library.items():
    lines.append(f"| {name} | {v['reported_individual_passes']} | -15 | Resource-stopped; incomplete |")
lines += ['', 'Both suites hit the unchanged 512 MiB repository free-space guard. There is',
    'no terminal test summary, so neither partial count is a suite pass. The new',
    'all-feature root retained about 75.2 MB within its separate 128 MiB planning',
    'allowance; the larger space loss occurred outside those outputs. No particular',
    'process is identified as the cause. Mirrors stayed unchanged and no property',
    'persistence warnings occurred. All-feature compilation passed, but its Clippy',
    'was refused before launch. A fresh metadata-only all-feature Clippy run later',
    'passed under the same guards. That pass does not replace either interrupted suite.', '',
    'All 20 small-batch preflight and 140 matched processes / 280 timed phases',
    'completed with strict Certified receipts and independent 3-4-5/circle-equation',
    'oracles. Each phase contains at least 65,536 queries and complete ordered rows.',
    'Cold includes fresh batch-cache creation/destruction; warm uses a prepared',
    'cache and includes deferred activation on its first hit. Input/reference',
    'construction, printing and startup are outside phase timers and inside process',
    'observations. Cold does not reset every scalar/process cache.', '',
    '| Pairs | Baseline cold s | Candidate cold s | Baseline warm s | Candidate warm s |',
    '| ---: | ---: | ---: | ---: | ---: |']
for n in sorted({v['count'] for v in small}):
    c = next(v for v in small if (v['count'], v['phase']) == (n, 'cold'))
    h = next(v for v in small if (v['count'], v['phase']) == (n, 'warm'))
    lines.append(f"| {n} | {c['baseline_median_seconds']:.9f} | {c['candidate_median_seconds']:.9f} | {h['baseline_median_seconds']:.9f} | {h['candidate_median_seconds']:.9f} |")
lines += ['', 'No small-batch rejection criterion is met. Cold 33 is 0.76% lower; small',
    'warm overhead remains, including +1.87% at four pairs with overlapping ranges.',
    'The original fifteen-case matrix also completed all 30 preflight and 210 matched',
    'processes / 420 phases, preserving every exact ordered row and strict receipt.', '',
    '| Case | Baseline cold s | Candidate cold s | Baseline warm s | Candidate warm s |',
    '| --- | ---: | ---: | ---: | ---: |']
for case, n in dict.fromkeys((v['case'], v['parameter']) for v in support['comparisons']):
    c = next(v['median_seconds'] for v in support['comparisons'] if (v['case'], v['parameter'], v['phase']) == (case,n,'cold'))
    h = next(v['median_seconds'] for v in support['comparisons'] if (v['case'], v['parameter'], v['phase']) == (case,n,'warm'))
    lines.append(f"| {case} {n} | {c['baseline']:.9f} | {c['candidate']:.9f} | {h['baseline']:.9f} | {h['candidate']:.9f} |")
lines += ['', 'Single-query and sub-millisecond phases are diagnostic controls. Shared-support',
    'warm medians increased 3.74%, 8.98% and 19.59% at the three sizes with overlapping',
    'ranges; these adverse observations remain retained. The grouped follow-up',
    'therefore preserves all three sizes, exact concentric-circle oracles, complete',
    'Disjoint rows, strict receipts and the unchanged 20,000-query probe.', '',
    'The first 336-process grouped attempt overlapped proposal rustfmt. Its protocol',
    'assertion that other qualification commands were terminal was false for part',
    'of the run. The whole first comparison is unqualified for performance, regardless',
    'of its favorable medians, and every sample remains preserved. A single repeat',
    'reran the entire fixed schedule after all other local checks were terminal.',
    'Both full-library failures remain failures under the explicit limited diagnostic',
    'contract. The semantic basis is the nine focused contracts plus an independent',
    'oracle and receipt for every measured query, not a claimed whole-library pass.', '',
    'The clean repeat has seven groups per size, eight processes per variant/group:',
    '336 processes, with 160,000 warm queries per group aggregated from separate',
    'phases. This is not one contiguous timer or an end-to-end native measurement.', '',
    '| Shift bits | Baseline group s | Candidate group s | Change | Positive pairs | Separate higher range | Reject |',
    '| ---: | ---: | ---: | ---: | ---: | --- | --- |']
for v in grouped['comparisons']:
    lines.append(f"| {v['bits']} | {v['baseline_median_seconds']:.9f} | {v['candidate_median_seconds']:.9f} | {(v['candidate_over_baseline_median']-1)*100:+.4f}% | {v['positive_paired_differences']}/7 | {v['candidate_range_above_baseline']} | {v['predeclared_rejection_criterion_met']} |")
lines += ['', 'The unchanged rejection rule requires strictly more than 10% median overhead,',
    'all seven positive paired differences and separate higher ranges. No threshold',
    'is rounded and no adverse result is discarded. No zero-overhead claim follows.', '',
    'All 20 whole-process heap observations preserve uninstrumented witnesses.',
    'They include construction, queries, validation, output, printing and cleanup;',
    'instrumented time is excluded from latency. Peak heap increases for indexed',
    'batches even where allocation counts fall. This is not an isolated cache-byte',
    'measurement or an internal resource bound.', '',
    '| Workload | Baseline allocations / peak | Candidate allocations / peak |', '| --- | --- | --- |']
for case,n in dict.fromkeys((v['case'],v['parameter']) for v in heap['measurements']):
    vs={v['variant']:v for v in heap['measurements'] if (v['case'],v['parameter'])==(case,n)}
    b,c=vs['baseline'],vs['candidate']
    lines.append(f"| {case} {n} | {b['allocation_calls']} / {b['peak_heap_human_readable']} | {c['allocation_calls']} / {c['peak_heap_human_readable']} |")
lines += ['', 'Diagnostic test-harness file/text/data/bss bytes (not distributed package size):', '']
for name,v in heap['binary_sizes'].items():
    lines.append(f"- {name}: {v['file_bytes']} / {v['text_bytes']} / {v['data_bytes']} / {v['bss_bytes']}.")
lines += ['', 'The separate all-feature 128 MiB allowance is planning, not a hard peak-byte',
    'limit. Commands retain 1,800-second/8 GiB containment, 2 GiB host memory reserve,',
    '512 MiB repository and 256 MiB /dev/shm quota/filesystem guards. The repeat',
    'adds a 256 MiB guard for its fresh runtime volume. No original native CPU/wall',
    'gate is weakened and no closed target is reopened. Larger writable storage',
    'remains required for full qualification; the requested Disk A directory is absent.', '',
    'A source review independently reproduced a stale README sentence that claims',
    'text typed-failure migration is pending despite current Result-returning APIs',
    'and the README text section. A small proposed correction is preserved for a',
    'separate commit; no main documentation edit is applied in this checkpoint.', '',
    'Full library, Cargo matrix, integration/docs/examples/benches, downstream,',
    'original native/report, real bindings and clean external distribution remain',
    'unqualified. Only current_work changes in the ledger. Raw evidence and every',
    'new physical path are retained and hashed; 27,093 inherited missing paths remain',
    'disclosed. This is not a whole-history audit, production admission, release or',
    'completion of the properties plan. The prepared full-pass decision helper was',
    'never executed. Its first adaptation failed before creating a new helper; that',
    'tool-reported preparation error is recorded separately.', '']
assert not (W/'progress-v1.md').exists()
(W/'progress-v1.md').write_text('\n'.join(lines))
inputs=[Path(__file__),W/'progress-v1.md',W/'contract-v1.md',W/'library-contract-v1.md',
    W/'shared-aggregate-contract-v2.md',W/'partial-qualification-contract-v1.md',W/'grouped-repeat-contract-v1.md',
    W/'readme-review-v1.json',W/'preparation-failures-v1.json']
for path in locations.values():
    inputs += [p for name in ['protocol.json','commands.json','result.json'] if (p:=path/name).exists()]
dump(W/'decision-v1.json',{'complete':True,'main_parent_commit':read(RUNTIME/'build-v1/protocol.json')['base_commit'],
    'status':status,'retention_decision':retention,'cache_index_admitted':False,'source_changes_applied':False,
    'implementation_sha256':{},'proposal_sha256':proposal['proposal_sha256'],
    'input_sha256':{str(p):sha(p) for p in inputs},'library_results':library,'full_library_qualification_complete':False,
    'focused_tests_per_variant':9,'candidate_strict_direct_clippy_configurations':['no-feature','all-feature metadata in fresh root'],
    'matched_small_processes':140,'matched_support_processes':210,'aggregate_shared_processes':336,
    'aggregate_shared_comparisons':grouped['comparisons'],'decisive_rejection_cases':rejected,
    'earlier_unqualified_grouped_processes':336,'earlier_grouped_issue':'Proposal rustfmt overlapped; whole comparison preserved but unqualified for performance.',
    'allocation_observations':20,'diagnostic_binary_sizes':heap['binary_sizes'],
    'native_disposition_preserved':True,'pending_native_paths_remaining':0,'full_archived_integration_admitted':False,
    'native_runtime_admitted':False,'full_plan_complete':False,
    'next':['Finish whole-library and affected downstream qualification using adequate fresh storage; preserve every failed run and adverse cost.',
        'Keep original native workload/report and real binding gates before any production retention.',
        'Correct the reproduced stale text-migration sentence in a separate documentation change.',
        'Continue ordinary strict completion, provenance, resource contracts, user-path validation and every property/target.']})
print(status)
