"""Reproduce the rejected activation transition before drafting new code."""
import gzip
import json
import statistics
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, run, sha

base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert base == 'be2a0c37bfe57799c62a36125a5cb883a5458f00'
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT, check=True)
old = Path('/dev/shm/csgrs-circle-support-small-hit-v1/build-v1')
protocol, compiled = read(old / 'protocol.json'), read(old / 'result.json')
assert compiled['complete'] and compiled['output_closed'] and not compiled['command_failures']
assert subprocess.check_output(['rustc', '-vV'], text=True) == protocol['rustc']
with gzip.open(old / 'main-input-hashes.json.gz', 'rt') as stream:
    main = json.load(stream)
assert all(sha(ROOT / p) == digest for p, digest in main.items() if p != 'docs/properties-status.json')
main['docs/properties-status.json'] = sha(ROOT / 'docs/properties-status.json')
assert all(sha(p) == digest for p, digest in protocol['read_only_dependencies_sha256'].items())
for source in protocol['sources'].values():
    assert all(sha(Path(source['path']) / p) == digest for p, digest in source['sha256'].items())
RUNTIME.mkdir(mode=0o700, exist_ok=False)
output = RUNTIME / 'reproduction-v1';output.mkdir()
with gzip.open(output / 'main-input-hashes.json.gz', 'wt') as stream:
    json.dump(main, stream, sort_keys=True)
pins = {str(p): sha(p) for p in [Path(__file__), W / 'runner_v1.py', W / 'contract-v1.md', old / 'protocol.json', old / 'result.json']}
pins |= {v['path']: v['sha256'] for v in compiled['binaries'].values()}
assert all(sha(p) == digest for p, digest in pins.items())
dump(output / 'protocol.json', {'base_commit': base, 'input_sha256': pins,
    'source_equivalent_current_main': True, 'repetitions': 7, 'pairs': 33,
    'scope': 'Reproduce E45 at its failed transition; this does not replace the successor full ten-size matrix.',
    'policy': 'STRICT', 'source_and_dependencies_verified': True})
commands, samples, witnesses = [], [], None
for rep in range(7):
    for variant in (['baseline', 'candidate'] if rep % 2 == 0 else ['candidate', 'baseline']):
        name = f'r{rep}-{variant}'
        row = run(output, name, [compiled['binaries'][variant]['path'],
            'curve_intersection::circle_support_small_batch_probe::small_batch_complete_cost',
            '--exact', '--ignored', '--nocapture', '--test-threads=1'], output, {'CIRCLE_SMALL_BATCH_N': '33'})
        commands.append(row);dump(output / 'commands.json', commands)
        assert row['exit_code'] == 0
        text = (output / (name + '.stdout')).read_text()
        assert 'CIRCLE_SMALL_CERTAINTY Certified' in text and 'test result: ok. 1 passed; 0 failed;' in text
        times = [json.loads(line.split('CIRCLE_SMALL_SAMPLE ', 1)[1]) for line in text.splitlines() if 'CIRCLE_SMALL_SAMPLE ' in line]
        rows = [json.loads(line.removeprefix('CIRCLE_SMALL_ROWS ')) for line in text.splitlines() if line.startswith('CIRCLE_SMALL_ROWS ')]
        assert len(times) == len(rows) == 2 and rows[0] == rows[1] and len(rows[0]) == 33
        if witnesses is None: witnesses = rows[0]
        assert rows[0] == witnesses
        samples.extend(v | {'variant': variant, 'repetition': rep} for v in times)
        dump(output / 'samples.json', samples)
comparisons = []
for phase in ['cold', 'warm']:
    values = {v: [s['seconds'] for s in samples if s['variant'] == v and s['phase'] == phase] for v in ['baseline', 'candidate']}
    comparisons.append({'phase': phase, 'seconds': values,
        'candidate_over_baseline_median': statistics.median(values['candidate']) / statistics.median(values['baseline']),
        'positive_paired_differences': sum(c > b for b,c in zip(values['baseline'], values['candidate'])),
        'candidate_range_above_baseline': min(values['candidate']) > max(values['baseline'])})
assert all(sha(p) == digest for p, digest in pins.items())
assert all(sha(ROOT / p) == digest for p, digest in main.items())
dump(output / 'result.json', {'complete': True, 'output_closed': True, 'command_failures': [],
    'comparisons': comparisons, 'processes': len(commands), 'all_results_certified': True,
    'same_ordered_rows': True, 'read_only_inputs_unchanged': True})
print(json.dumps(comparisons))
