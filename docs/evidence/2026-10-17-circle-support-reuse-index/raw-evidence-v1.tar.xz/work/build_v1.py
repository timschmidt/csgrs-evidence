"""Build deferred activation with unchanged semantic tests and cost probes."""
import gzip
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, resources, run, sha, violation

base = 'be2a0c37bfe57799c62a36125a5cb883a5458f00'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == base
subprocess.run(['git', 'diff', '--quiet'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT, check=True)
assert violation(resources()) is None
old = Path('/dev/shm/csgrs-circle-support-small-hit-v1/build-v1')
prior, previous = read(old / 'protocol.json'), read(old / 'result.json')
assert previous['complete'] and previous['output_closed'] and not previous['command_failures']
assert subprocess.check_output(['rustc', '-vV'], text=True) == prior['rustc']
assert all(sha(p) == digest for p, digest in prior['read_only_dependencies_sha256'].items())
for source in prior['sources'].values():
    assert all(sha(Path(source['path']) / p) == digest for p, digest in source['sha256'].items())
repro = RUNTIME / 'reproduction-v1'
assert read(repro / 'result.json')['output_closed'] and not read(repro / 'result.json')['command_failures']
with gzip.open(repro / 'main-input-hashes.json.gz', 'rt') as stream:
    main = json.load(stream)
assert all(sha(ROOT / p) == digest for p, digest in main.items())
output = RUNTIME / 'build-v1';output.mkdir(exist_ok=False)
source = output / 'candidate-source';source.mkdir()
for p, digest in prior['sources']['candidate']['sha256'].items():
    original = Path(prior['sources']['candidate']['path']) / p
    assert sha(original) == digest
    dest = source / p;dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, dest)
for path in (W / 'proposal-source').rglob('*'):
    if path.is_file():
        shutil.copy2(path, source / path.relative_to(W / 'proposal-source'))
relative = 'crates/hypercurve/src/curve_intersection.rs'
path = source / relative
text = path.read_text()
for module in ['circle_support_cost_probe', 'circle_support_coefficient_probe', 'circle_support_small_batch_probe']:
    hook = f'\n#[cfg(test)]\n#[path = "{module}.rs"]\nmod {module};\n'
    assert hook not in text
    text += hook
path.write_text(text)
commands = [run(output, 'format', ['rustfmt', '--check', '--edition', '2024',
    '--config-path', str(ROOT / 'crates/.rustfmt.toml'), '--config', 'skip_children=true', str(path)], source)]
assert commands[-1]['exit_code'] == 0
source_pins = {str(p.relative_to(source)): sha(p) for p in source.rglob('*') if p.is_file()}
sources = {'baseline': prior['sources']['baseline'], 'candidate': {'path': str(source), 'sha256': source_pins}}
for relative in ['crates/hypercurve/src/circle_support_cache_tests.rs',
                 'crates/hypercurve/src/circle_support_small_batch_probe.rs',
                 'crates/hypercurve/src/circle_support_cost_probe.rs',
                 'crates/hypercurve/src/circle_support_coefficient_probe.rs']:
    assert sha(source / relative) == sha(Path(sources['baseline']['path']) / relative)
inputs = {str(p): sha(p) for p in [Path(__file__), W / 'runner_v1.py', W / 'contract-v1.md',
    old / 'protocol.json', old / 'result.json', ROOT / 'crates/.rustfmt.toml',
    repro / 'result.json', Path(shutil.which('quota'))]}
inputs |= {str(p): sha(p) for p in (W / 'proposal-source').rglob('*') if p.is_file()}
shutil.copy2(repro / 'main-input-hashes.json.gz', output / 'main-input-hashes.json.gz')
dump(output / 'protocol.json', {'base_commit': base, 'input_sha256': inputs, 'sources': sources,
    'read_only_dependencies_sha256': prior['read_only_dependencies_sha256'], 'externs': prior['externs'],
    'rustc': prior['rustc'], 'clippy': subprocess.check_output(['clippy-driver', '--version'], text=True),
    'hardware': prior['hardware'], 'current_lscpu': json.loads(subprocess.check_output(['lscpu', '-J'], text=True)),
    'features': prior['features'], 'baseline_reused_read_only': True, 'same_tests_and_diagnostics': True,
    'full_build_storage_still_pending': True, 'completed_cargo_targets_reopened': False,
    'resource_contract': str(W / 'contract-v1.md'), 'initial_resources': resources()})
binary = output / 'candidate-tests'
command = ['rustc', '--crate-name', 'hypercurve', '--edition=2024', '--test',
    'crates/hypercurve/src/lib.rs', '-C', 'opt-level=3', '-C', 'codegen-units=16',
    '-C', 'embed-bitcode=no', '-D', 'warnings',
    '-L', 'dependency=' + str(Path(prior['externs']['hyperreal']).parent), '-o', str(binary)]
for name, p in prior['externs'].items():
    command += ['--extern', name + '=' + p]
commands.append(run(output, 'candidate', command, source))
dump(output / 'commands.json', commands)
binaries = {'baseline': previous['binaries']['baseline']}
if commands[-1]['exit_code'] == 0:
    binaries['candidate'] = {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size}
    for label, executable in binaries.items():
        commands.append(run(output, label + '-contracts', [executable['path'],
            'curve_intersection::circle_support_cache_tests::', '--nocapture', '--test-threads=1'], source))
    lint = command.copy();lint[0] = 'clippy-driver'
    lint[lint.index('-o') + 1] = str(output / 'candidate.rmeta')
    lint.append('--emit=metadata')
    commands.append(run(output, 'candidate-clippy', lint, source))
    dump(output / 'commands.json', commands)
assert all(sha(p) == digest for p, digest in (inputs | prior['read_only_dependencies_sha256']).items())
assert all(sha(Path(v['path']) / p) == digest for v in sources.values() for p, digest in v['sha256'].items())
assert all(sha(ROOT / p) == digest for p, digest in main.items())
failures = [row['name'] for row in commands if row['exit_code'] != 0]
dump(output / 'result.json', {'complete': True, 'output_closed': True, 'binaries': binaries,
    'command_failures': failures, 'main_sources_unchanged': True,
    'frozen_sources_and_dependencies_unchanged': True, 'baseline_reused_read_only': True,
    'cache_admitted': False, 'full_plan_complete': False})
raise SystemExit(0 if len(binaries) == 2 and not failures else 101)
