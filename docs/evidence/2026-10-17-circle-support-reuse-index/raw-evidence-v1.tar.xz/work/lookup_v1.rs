    fn circular_support_relation(
        &mut self,
        first_curve: &Curve2,
        second_curve: &Curve2,
        policy: &CurveContext,
    ) -> ExactCurveResult<Option<CircleCircleRelation>> {
        let (Some(first), Some(second)) = (
            retained_curve_circular_support(first_curve),
            retained_curve_circular_support(second_curve),
        ) else {
            return Ok(None);
        };
        let entries = &self.circular_support_relations;
        let matches = |position: usize| {
            let entry = &entries[position];
            entry.first.center == *first.center
                && entry.first.radius_squared == *first.radius_squared
                && entry.second.center == *second.center
                && entry.second.radius_squared == *second.radius_squared
        };
        let key;
        if let Some(index) = &self.circular_support_index {
            key = ExactCircularSupportPairKey::new(first, second);
            let retained = if let Some(key) = &key {
                let indexed = index.exact.get(key).copied();
                // Earlier unindexed witnesses keep their original priority.
                index
                    .unkeyed
                    .iter()
                    .copied()
                    .take_while(|&position| indexed.is_none_or(|cached| position < cached))
                    .find(|&position| matches(position))
                    .or(indexed)
            } else {
                (0..entries.len()).find(|&position| matches(position))
            };
            if let Some(position) = retained {
                return Ok(Some(entries[position].relation.clone()));
            }
        } else {
            key = None;
            if let Some(position) = (0..entries.len()).find(|&position| matches(position)) {
                let relation = entries[position].relation.clone();
                // A batch of distinct queries never needs an index. Pay for
                // indexing only after an eligible support is actually reused.
                if entries.len() >= 32 && ExactCircularSupportPairKey::new(first, second).is_some() {
                    self.circular_support_index =
                        Some(CircularSupportIndex::from_relations(entries));
                }
                return Ok(Some(relation));
            }
        }
        let relation = circle_relation_from_supports(
            first.center,
            first.radius_squared,
            second.center,
            second.radius_squared,
            policy,
        )
        .map_err(|cause| {
            ExactCurveError::invalid(CurveOperation2::Intersection, first_curve.family(), cause)
        })?;
        let position = self.circular_support_relations.len();
        self.circular_support_relations
            .push(CircularSupportRelationCacheEntry {
                first: RationalQuadraticCircle2 {
                    center: first.center.clone(),
                    radius_squared: first.radius_squared.clone(),
                    tangent_contacts: None,
                },
                second: RationalQuadraticCircle2 {
                    center: second.center.clone(),
                    radius_squared: second.radius_squared.clone(),
                    tangent_contacts: None,
                },
                relation: relation.clone(),
            });
        if let Some(index) = &mut self.circular_support_index {
            if let Some(key) = key {
                index.exact.entry(key).or_insert(position);
            } else {
                index.unkeyed.push(position);
            }
        }
        Ok(Some(relation))
    }
