"""Run all-feature metadata lint in a new root; retain the earlier refused lint."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from runner_v1 import ROOT, RUNTIME, W, dump, read, run, sha

old = ROOT / 'target/properties/circle-support-reuse-library-v1'
closed, protocol = read(old / 'result.json'), read(old / 'protocol.json')
assert closed['complete'] and closed['output_closed']
assert closed['command_failures'] == ['tests', 'clippy']
assert read(old / 'build.result.json')['exit_code'] == 0
assert read(old / 'tests.result.json')['external_stop_reason'] == 'repository_free_bytes-reserve'
assert read(old / 'clippy.result.json')['not_run']
source = protocol['source']
assert all(sha(Path(source['path']) / p) == digest for p, digest in source['sha256'].items())
assert all(sha(p) == digest for p, digest in protocol['read_only_dependencies_sha256'].items())
output = RUNTIME / 'all-feature-clippy-v1';output.mkdir(exist_ok=False)
pins = {str(p):sha(p) for p in [Path(__file__), W / 'runner_v1.py', W / 'partial-qualification-contract-v1.md',
    old / 'protocol.json', old / 'result.json', old / 'build.result.json', old / 'clippy.result.json']}
dump(output / 'protocol.json', {'input_sha256':pins, 'source':source,
    'read_only_dependencies_sha256':protocol['read_only_dependencies_sha256'],
    'features':protocol['features'], 'earlier_refused_attempt_preserved':True,
    'full_library_pass_claimed':False})
command=read(old / 'build.result.json')['command'].copy()
command[0]='clippy-driver';command[command.index('-o')+1]=str(output/'hypercurve.rmeta')
command.append('--emit=metadata')
row=run(output,'clippy',command,Path(source['path']))
dump(output/'commands.json',[row])
assert all(sha(p)==digest for p,digest in pins.items())
assert all(sha(Path(source['path'])/p)==digest for p,digest in source['sha256'].items())
dump(output/'result.json',{'complete':True,'output_closed':True,
    'command_failures':[] if row['exit_code']==0 else ['clippy'], 'external_stop_reason':row.get('external_stop_reason'),
    'earlier_refused_attempt_preserved':True,'read_only_inputs_unchanged':True,'full_library_pass_claimed':False,
    'cache_admitted':False,'full_plan_complete':False})
raise SystemExit(0 if row['exit_code']==0 else 101)
