from pathlib import Path
import json,math,sys,re
w=Path(sys.argv[1])
exec((w/'metrics.py').read_text().split('spec=')[0])
j=json.loads((w/'metrics.json').read_text())
fixed=wasm(w/'fixed-1.95.wasm')['bytes'];pair=j['1.95.0 existing bare wasm'];wasm_accounts={}
for key in fixed:
    a,b,c=fixed[key],pair['before']['bytes'][key],pair['after']['bytes'][key]
    h=max(0,b-a);i=max(0,c-b);inc=min(1024,int(b*.05));cum=min(4096,int(a*.1))
    assert i<=inc and h+i<=cum
    wasm_accounts[key]=dict(fixed=a,previous=b,retained=c,prior_charge=h,increment=i,cumulative=h+i,remaining=cum-h-i)
for k,v in j.items():
    if k.startswith('x86_64') and 'mixed' not in k:assert all(n<=0 for n in v['delta'].values())
for v in ['1.88.0','stable']:assert all(n<=0 for n in j[v+' existing bare wasm']['delta'].values())
slot=64<<20; reserve=16<<20
harness=Path(re.search(r'Running tests/float_format.rs \(([^)]+)\)',(w/'owner-lattice.log').read_text())[1])
new={'native format acceptance':elf(harness)['bytes']}
new.update({k:v['bytes'] for k,v in j.items() if k.startswith('WASI') or 'format bare' in k})
for version in ['1.88.0','1.95.0','stable']:
    new[version+' external package']=elf(w/('package-final-'+version)/'release/format-application')['bytes']
for k,v in new.items():
    capacity,required=(slot,reserve) if k=='native format acceptance' else (4<<20,1<<20)
    assert capacity-v['file']>=required
    v.update(qualification_slot_bytes=capacity,required_free_bytes=required,remaining_qualification_bytes=capacity-v['file'])
stack={}
for p in sorted(w.glob('*-stack.json')):
 rows=json.loads(p.read_text()); stack[p.stem]=[max(r[k] for r in rows) for k in ('reservedBytes','touchedBytes','stackBytes','linearBytes')]
assert all(v[:2]==[224,224] for k,v in stack.items() if 'format' in k)
assert stack['1.95.0-before-stack']==stack['1.95.0-after-stack']
print(json.dumps({'fixed_revision':'c9f1f9ac5','preceding_revision':'dd275ffda','source_revision':'db9fa026c','wasm_1_95':wasm_accounts,'new_binaries':new,'qualification_slot':slot,'required_free':reserve,'stack_fields':['reserved','touched','stack capacity','initial/final linear memory'],'stack':stack,'fixed_native_float_test':elf(w/'fixed-float-test')},indent=2))
