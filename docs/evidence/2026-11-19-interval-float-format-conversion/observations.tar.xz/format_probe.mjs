import fs from "node:fs";
import assert from "node:assert/strict";
const { instance } = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]));
const { narrow, widen } = instance.exports;
const data = new DataView(new ArrayBuffer(8));
function unpack32(x) { data.setUint32(0, x); return data.getFloat32(0); }
function bits32(x) { data.setFloat32(0, x); return data.getUint32(0); }
function unpack64(x) { data.setBigUint64(0, x); return data.getFloat64(0); }
function bits64(x) { data.setFloat64(0, x); return data.getBigUint64(0); }
const max = unpack32(0x7f7fffff);
function nearestBound(x, upper) {
    if (Math.abs(x) > max) return 1n << 32n;
    const nearest = Math.fround(x);
    if (upper ? nearest >= x : nearest <= x) return BigInt(bits32(nearest || 0));
    if (!nearest) return upper ? 1n : 0x80000001n;
    const adjacent = bits32(nearest) + ((upper === (nearest > 0)) ? 1 : -1);
    return adjacent === 0x80000000 ? 0n : BigInt(adjacent);
}
let state = 0x912df52a;
function rand() { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return state >>> 0; }
function rand64() { return unpack64((BigInt(rand()) << 32n) | BigInt(rand())); }
let narrows = 0, widens = 0, overflows = 0;
for (let i=0; i<65536; i++) {
    let x = rand64(), y = rand64();
    if (Number.isFinite(x) && Number.isFinite(y)) {
        [x,y] = [Math.min(x,y),Math.max(x,y)];
        const overflow = x < -max || y > max;
        for (let bound=0; bound<2; bound++) {
            const expected = overflow ? 1n << 32n : nearestBound(bound ? y : x, !!bound);
            assert.equal(narrow(bits64(x), bits64(y), bound), expected);
        }
        narrows++; overflows += Number(overflow);
    }
    x = unpack32(rand()); y = unpack32(rand());
    if (Number.isFinite(x) && Number.isFinite(y)) {
        [x,y] = [Math.min(x,y),Math.max(x,y)];
        for (let bound=0; bound<2; bound++) {
            const expected = bits64((bound ? y : x) || 0);
            assert.equal(BigInt.asUintN(64, widen(bits32(x), bits32(y), bound)), expected);
        }
        widens++;
    }
}
console.log(JSON.stringify({widens,narrows,overflows,comparisons:2*(widens+narrows)}));
