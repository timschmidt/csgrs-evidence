use hyperinterval::{F32Enclosure, F64Enclosure, IntervalError};
fn main() {
    let wide=F64Enclosure::new(-f64::from_bits(1),1.0+f64::EPSILON).unwrap();
    let narrow=wide.to_f32_enclosure().unwrap();
    assert_eq!(narrow,F32Enclosure::new(-f32::from_bits(1),f32::from_bits(0x3f800001)).unwrap());
    assert!(wide.subset_of(&narrow.to_f64_enclosure().unwrap()));
    assert_eq!(F32Enclosure::empty().to_f64_enclosure(),Ok(F64Enclosure::empty()));
    assert_eq!(F64Enclosure::point(f64::MAX).unwrap().to_f32_enclosure(),Err(IntervalError::Overflow));
}
