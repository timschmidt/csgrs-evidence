use hyperinterval::{F32Enclosure as F32, F64Enclosure as F64, IntervalError};
use std::{hint::black_box, time::Instant};
#[path="/mnt/development/csgrs/crates/hyperlattice-interval/conformance/allocations.rs"]
mod allocations;

#[inline(never)]
fn round_trip(lo: f64, hi: f64) -> Result<(u64, u64), IntervalError> {
    let x = F64::new(lo, hi)?;
    #[cfg(feature="bridge")]
    let wide = {
        let mut budget = hyperinterval::DyadicBudget::new(4096, 1_000_000);
        let narrow = F32::from_dyadic(&x.to_dyadic(&mut budget)?, &mut budget)?;
        F64::from_dyadic(&narrow.to_dyadic(&mut budget)?, &mut budget)?
    };
    #[cfg(not(feature="bridge"))]
    let wide = {
        let narrow: F32 = x.to_f32_enclosure()?;
        narrow.to_f64_enclosure()?
    };
    let (a,b) = wide.bounds().unwrap();
    Ok((a.to_bits(), b.to_bits()))
}
fn main() {
    let start = Instant::now();
    let (checksum,allocations,bytes) = allocations::measure(|| {
        let mut checksum = 0u64;
        for i in 0..65_536u64 {
            let exp = 800 + (i % 348);
            let x = f64::from_bits((exp << 52) | ((i * 0x1_0000_0001) & ((1<<52)-1)));
            let lo = if i % 2 == 0 { -f64::from_bits(1) } else { -x };
            let (a,b) = round_trip(black_box(lo), black_box(x)).unwrap();
            checksum = checksum.rotate_left(7).wrapping_add(a).wrapping_add(b);
        }
        checksum
    });
    println!("calls=65536 checksum={checksum} allocations={allocations} allocated_bytes={bytes} elapsed_ns={}",start.elapsed().as_nanos());
}
