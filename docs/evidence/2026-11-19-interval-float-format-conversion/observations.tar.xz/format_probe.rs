#![no_std]
use hyperinterval::{F32Enclosure, F64Enclosure, IntervalError};
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { core::arch::wasm32::unreachable() }

#[unsafe(no_mangle)]
pub extern "C" fn narrow(a: u64, b: u64, which: u32) -> u64 {
    match F64Enclosure::new(f64::from_bits(a), f64::from_bits(b)).unwrap().to_f32_enclosure() {
        Ok(x) => {
            let (lo, hi) = x.bounds().unwrap();
            u64::from(if which == 0 { lo.to_bits() } else { hi.to_bits() })
        }
        Err(IntervalError::Overflow) => 1u64 << 32,
        _ => panic!()
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn widen(a: u32, b: u32, which: u32) -> u64 {
    let (lo, hi) = F32Enclosure::new(f32::from_bits(a), f32::from_bits(b)).unwrap()
        .to_f64_enclosure().unwrap().bounds().unwrap();
    if which == 0 { lo.to_bits() } else { hi.to_bits() }
}
