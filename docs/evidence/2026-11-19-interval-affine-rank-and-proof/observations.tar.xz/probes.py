from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,os,sys
s=Path(__file__).resolve().parent;tag=sys.argv[1];d=s/'logs';images=s/'images'
def run(job):
 name,core,count=job
 for index in range(count):
    suffix=f'{tag}-{name}-{index+1}'
    with (d/suffix).open('w') as out,(d/(suffix+'.err')).open('w') as err:
        subprocess.run(['setarch',os.uname().machine,'-R','taskset','-c',str(core),images/(tag+'-'+name)],stdout=out,stderr=err,check=True)
# Each measurement is process-local. Across variants, reuse the same core for each workload.
with ThreadPoolExecutor(4) as pool:list(pool.map(run,[('lifetime',3,24),('stress-life',4,48),('usable',7,12),('client',8,1)]))
