const fs=require("node:fs"),assert=require("node:assert/strict");
(async()=>{
 const m=await WebAssembly.compile(fs.readFileSync(process.argv[2]));assert.deepEqual(WebAssembly.Module.imports(m),[]);
 for(let run=0;run<2;run++){const {exports}=await WebAssembly.instantiate(m);
 for(let cycle=0;cycle<2;cycle++)for(let mode=0;mode<2;mode++)for(let c=0;c<6;c++){
 const value=exports.proof(c,mode);assert.equal(value,(mode===0||(process.argv[3]==="row" ? [1,2,4,5].includes(c) : process.argv[3]==="multi" ? c===2||c===5 : process.argv[3]!=="before"))?2:(c<4?1:3));
 console.log(run,cycle,mode,c,value,exports.memory.buffer.byteLength);}
 }
})().catch(e=>{console.error(e);process.exit(1)})
