use hyperlimit::PredicatePolicy;
use hyperreal::{Real, dispatch_trace as trace};
use hypersolve::*;
fn main() {
 for package in 0..3 {
  for (case,radius,c) in [(0,0,0),(1,0,1),(2,1,-1),(3,3,2),(4,1,0)] {
   for (mode,policy) in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512].into_iter().enumerate() {
    let symbol=SymbolId(0);
    let mut p=Problem::default();p.add_variable("x",Real::zero());
    let x=Expr::anonymous_symbol(symbol);
    let linear=x.clone()+Expr::int(c);
    p.add_constraint(Constraint::equality("f",if package==0{linear}else{x.clone()*x+linear}));
    let a=p.analyze();let ctx=context_from_problem(&p);let b=[VariableBall{symbol,radius:Real::from(radius)}];
    trace::reset();
    let result=match package {
     0=>format!("{:?}", trace::with_recording(||certify_affine_krawczyk_box(&a,&ctx,&b,policy))),
     1=>format!("{:?}", trace::with_recording(||certify_univariate_quadratic_krawczyk_box(&a,&ctx,&b,policy))),
     _=>format!("{:?}", trace::with_recording(||certify_multivariate_quadratic_krawczyk_box(&a,&ctx,&b,policy))),
    };
    let snapshot=trace::take_trace();
    assert!(!snapshot.dispatch.is_empty());println!("{package}|{case}|{mode}|{result}|{snapshot:?}");
   }
  }
 }
}
