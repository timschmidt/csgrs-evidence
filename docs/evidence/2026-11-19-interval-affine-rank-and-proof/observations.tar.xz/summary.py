from pathlib import Path
import os,json,hashlib,re
root=Path(os.environ['w']);l=root/'logs';summary={}
tags=['bounds','local','augmented','rowview','proofsites','scalarproof','magnitude','early','boundary','entry','boundaryroot']
for tag in tags:
 sizes=root/(tag+'-sizes.json');mem=root/(tag+'-memory.json')
 if not sizes.exists() or not mem.exists():continue
 a=json.loads(sizes.read_text());m=json.loads(mem.read_text())
 size_fail={name:{k:v['delta'] for k,v in rr['metrics'].items() if not v['incremental'] or (v['delta']>0 and not v['cumulative_pass'])} for name,rr in a.items()}
 size_fail={k:v for k,v in size_fail.items() if v}
 failures=[[name,r['key'],r['increment']] for name,rows in m.items() for r in rows if not r['passes']]
 assert sum(map(len,m.values()))==216 and len(a)==8
 lines=lambda s:(l/s).read_text().splitlines()
 before=lines('base-trace');after=lines(tag+'-trace');assert len(before)==len(after)==30
 sameclient=lines('base-client-1')==lines(tag+'-client-1')
 out=dict(linked_size_exceptions=size_fail, lifetime_failures=failures, qualified_heap_stack_rows=216-len(failures),matched_ordinary_traces=sum(x==y for x,y in zip(before,after)),matched_box_client=sameclient)
 stress=lines(tag+'-wasm-stress');assert len(stress)==48 and all(int(x.split()[4])==2 for x in stress)
 assert '240 ordered calls' in lines(tag+'-wasm-ordinary')[0]
 out['physical_cpu_medians']={str(cpu):json.loads(p.read_text())['summary'] for cpu in [7,17] if (p:=root/f'physical-{tag}-{cpu}.json').exists()}
 summary[tag]=out
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print([(k,len(v['linked_size_exceptions']),v['qualified_heap_stack_rows'],v['matched_ordinary_traces']) for k,v in summary.items()])
