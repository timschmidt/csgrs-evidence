set -euo pipefail
source "$(dirname "$0")/env"
tag=$1
bash "$w/build.sh" "$tag" native >"$w/logs/$tag-native" 2>&1 &
p=$!
bash "$w/build.sh" "$tag" wasm >"$w/logs/$tag-wasm" 2>&1 &
q=$!
cargo +1.95.0 build --release --locked --manifest-path "$w/pair/Cargo.toml" >"$w/logs/$tag-pair" 2>&1 && cp "$CARGO_TARGET_DIR/release/libmatched_proof.so" "$w/images/$tag-pair.so"
wait "$p"
wait "$q"
"$w/images/$tag-observer" >"$w/logs/$tag-trace"
