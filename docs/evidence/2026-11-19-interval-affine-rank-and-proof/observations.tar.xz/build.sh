set -eu
tag=$1
arch=$2
export CARGO_BUILD_JOBS=6 CARGO_TARGET_DIR="$s/client-$arch"
if test "$arch" = wasm; then
 for spec in 'portable-krawczyk box_radius_client' 'stress kraw_stress'; do
   read -r project bin <<< "$spec"
   cargo +1.95.0 build --release --locked --manifest-path "$s/$project/Cargo.toml" --target wasm32-unknown-unknown
   cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/$bin.wasm" "$s/images/$tag-$project.wasm"
 done
else
 for spec in 'lifetime radius-lifetime' 'stress-life proof-stress-lifetime' 'observer proof-observer' 'client box-coverage-client' 'usable radius-usable'; do
   read -r project bin <<< "$spec"
   cargo +1.95.0 build --release --locked --manifest-path "$s/$project/Cargo.toml"
   cp "$CARGO_TARGET_DIR/release/$bin" "$s/images/$tag-$project"
 done
fi
