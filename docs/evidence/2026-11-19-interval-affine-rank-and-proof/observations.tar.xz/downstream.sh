set -eu
if test "$1" = primary; then
  mkdir "$s/downstream-src"
  git -C /mnt/development/csgrs archive e5524c9ca | tar -xm -C "$s/downstream-src"
fi
cd "$s/downstream-src"
export CARGO_TARGET_DIR="$s/downstream-target" CARGO_BUILD_JOBS=6
for v in "$1"; do
 if test "$v" != primary;then git apply "$s/$v.patch";fi
 cargo +1.95.0 build --locked --release -p csgrs --bench successive_operations --no-default-features --features curve,stl-io,obj-io --message-format=json > "$s/logs/$v-successive.jsonl"
 python3 - "$v" <<'PY'
import json,shutil,sys
from pathlib import Path
s=Path(__import__('os').environ['s']);v=sys.argv[1]
p=next(x['executable'] for x in map(json.loads,(s/f'logs/{v}-successive.jsonl').read_text().splitlines()) if x.get('executable') and x['target']['name']=='successive_operations')
shutil.copy(p,s/'images'/f'{v}-successive')
PY
done
