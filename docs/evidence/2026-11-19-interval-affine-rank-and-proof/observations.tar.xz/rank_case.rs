
#[test]
fn a_point_solving_both_rows_does_not_establish_unique_rank() {
    // The addition identity in hidden_positive makes c exactly 2^-2048.
    // Both rows are multiples of x + 2^2048*y. The origin and (1,-2^-2048)
    // are distinct solutions on the closed unit box.
    let scale = Real::from(2).powi_i64(2048).unwrap();
    let tiny = Real::from(2).powi_i64(-2048).unwrap();
    oracle::assert_equal(&(&scale * &tiny), &Real::one());
    for coefficient in [tiny, hidden_positive()] {
        let mut problem = Problem::default();
        let [x, y] = ["x", "y"].map(|name| SymbolId::from(problem.add_variable(name, Real::zero())));
        let rows = [
            Expr::anonymous_symbol(x) + Expr::real(scale.clone()) * Expr::anonymous_symbol(y),
            Expr::real(coefficient) * Expr::anonymous_symbol(x) + Expr::anonymous_symbol(y),
        ];
        for row in &rows {
            problem.add_constraint(Constraint::equality("row", row.clone()));
        }
        let context = context_from_problem(&problem);
        for row in &rows {
            oracle::assert_exact_zero(&row.eval_real(context.bindings()).unwrap());
        }
        let analysis = problem.analyze();
        let bounds = [x, y].map(|symbol| VariableBall { symbol, radius: Real::one() });
        for policy in [PredicatePolicy::APPROXIMATE_512, PredicatePolicy::STRICT] {
            let report = certify_affine_krawczyk_box(&analysis, &context, &bounds, policy);
            assert_eq!(
                report.status, AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot: 1 },
                "{policy:?}"
            );
            assert!(report.steps.is_empty());
            assert_eq!((report.variable_count, report.equality_rows), (2, 2));
        }
    }
}
