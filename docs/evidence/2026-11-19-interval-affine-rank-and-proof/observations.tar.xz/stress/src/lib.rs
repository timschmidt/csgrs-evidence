use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use hypersolve::*;
#[unsafe(no_mangle)]
pub extern "C" fn proof(case:u32,mode:u32)->u32 {
 let policy=if mode==0 {PredicatePolicy::STRICT} else {PredicatePolicy::APPROXIMATE_512};
 let c=(Real::e()+Real::one()).sin()-Real::e().sin()*Real::one().cos()-Real::e().cos()*Real::one().sin()+Real::from(2).powi_i64(-2048).unwrap();
 let mut p=Problem::default(); let s=SymbolId(0);p.add_variable("x",Real::zero());
 let x=Expr::anonymous_symbol(s);let mut b=vec![VariableBall{symbol:s,radius:Real::zero()}];
 if case==3 {
  let y=SymbolId(1);p.add_variable("y",Real::zero());b[0].radius=Real::one();b.push(VariableBall{symbol:y,radius:Real::zero()});
  p.add_constraint(Constraint::equality("x=1",x.clone()-Expr::int(1)));
  p.add_constraint(Constraint::equality("c*x+y=0",Expr::real(c)*x+Expr::anonymous_symbol(y)));
 } else {
  let f=if case==0 {x+Expr::real(c)} else if case>=4 {
   b[0].radius=Real::from(2).powi_i64(-1).unwrap()-c;x.clone()*x.clone()+x
  } else {x.clone()*x.clone()+(x+Expr::real(c))};
  p.add_constraint(Constraint::equality("f",f));
 }
 let a=p.analyze();let ctx=context_from_problem(&p);
 match case {
  0|3=>match certify_affine_krawczyk_box(&a,&ctx,&b,policy).status {AffineKrawczykStatus::CertifiedUniqueRoot=>1,AffineKrawczykStatus::UndecidedContainment{..}=>2,_=>99},
  1|4=>match certify_univariate_quadratic_krawczyk_box(&a,&ctx,&b,policy).rows[0].status {QuadraticKrawczykStatus::CertifiedUniqueRoot=>1,QuadraticKrawczykStatus::Undecided=>2,QuadraticKrawczykStatus::NonContractiveDerivative=>3,_=>99},
  _=>match certify_multivariate_quadratic_krawczyk_box(&a,&ctx,&b,policy).status {MultivariateQuadraticKrawczykStatus::CertifiedUniqueRoot=>1,MultivariateQuadraticKrawczykStatus::Undecided{..}=>2,MultivariateQuadraticKrawczykStatus::NonContractiveDerivative{..}=>3,_=>99},
 }
}
