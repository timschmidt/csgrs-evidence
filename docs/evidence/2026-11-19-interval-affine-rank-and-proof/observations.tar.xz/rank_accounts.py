from pathlib import Path
import sys,json,os,hashlib
w=Path(sys.argv[1]);out={}
for f in sorted(w.glob('matrix-integral-final-*.json')):
 j=json.loads(f.read_text())['krawczyk_affine_rank'];part=f.name[len('matrix-integral-final-'):-5];tc,arch=part.split('-',1)
 d=w/('matrix-'+tc)/arch/'release/deps'
 paths=[p for p in d.glob('krawczyk_affine_rank-*') if p.suffix in ('','.wasm')]
 path=next(p for p in paths if hashlib.sha256(p.read_bytes()).hexdigest()==j['sha256'])
 cmd=[w/'node',Path.cwd()/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs',path] if arch.startswith('wasm') else [path]
 cmd=list(map(str,cmd));rss=[]
 for run in range(5):
  with (w/'logs'/f'rank-rss-{part}-{run}').open('w+') as log:
   actions=[(os.POSIX_SPAWN_DUP2,log.fileno(),fd) for fd in [1,2]]
   pid=os.posix_spawn(cmd[0],cmd,dict(os.environ),file_actions=actions)
   _,status,usage=os.wait4(pid,0);log.seek(0)
   assert status==0 and 'test result: ok' in log.read();rss.append(usage.ru_maxrss*1024)
 out[part]=j|{'slot_bytes':64<<20,'headroom':(64<<20)-j['file'],'required_headroom':16<<20,'complete_process_rss_bytes':rss}
 assert out[part]['headroom']>=16<<20
assert len(out)==4
(w/'rank-accounts.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:(v['file'],max(v['complete_process_rss_bytes'])) for k,v in out.items()})
