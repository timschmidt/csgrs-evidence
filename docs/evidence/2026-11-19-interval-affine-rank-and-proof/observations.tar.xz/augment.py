from pathlib import Path
import os,sys,subprocess
w=Path(os.environ['w']);f='crates/hypersolve/src/interval.rs'
s=subprocess.check_output(['git','show','fd842e2b0:'+f],text=True)
a=s.index('pub fn certify_affine_krawczyk_box(');b=s.index('/// Certify univariate quadratic rows',a)
v=s[a:b].replace('    let variable_count =','    let policy = policy.certified_only();\n    let variable_count =',1).replace('    let mut rhs = Vec::new();\n','')
v=v.replace('        matrix.push(affine.coefficients().to_vec());\n        rhs.push(-residual);','''        let row = affine.coefficients().iter().cloned().chain([ -residual ]).collect();
        matrix.push(row);''')
v=v.replace('solve_exact_linear_system(matrix, rhs, policy)','solve_affine_steps(matrix, policy)')
s=s[:a]+v+s[b:]
s=s.replace('for every variable. Use `PredicatePolicy::STRICT` for proof.\n/// Terminal approximation can skip a nonzero factor or accept a root outside the box.','for every variable. Pivot selection, elimination and\n/// containment use the certified stages of the supplied policy.')
a=s.index('fn solve_exact_linear_system(');b=s.index('fn invert_exact_matrix(',a)
s=s[:a]+'''// Reduce [A | -f(candidate)] with the same pivot and row operations used for
// [A | I]. The last entry in each reduced row is one coordinate of the step.
fn solve_affine_steps(
    mut matrix: Vec<Vec<Real>>,
    policy: PredicatePolicy,
) -> Result<Vec<Real>, AffineKrawczykStatus> {
    gauss_jordan(&mut matrix, policy)
        .map_err(|pivot| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot })?;
    Ok(matrix.into_iter().map(|mut row| row.pop().expect("augmented affine row")).collect())
}

'''+s[b:]
s=s.replace('gauss_jordan::<false>(&mut matrix, &mut [], policy)?','gauss_jordan(&mut matrix, policy)?')
a=s.index('fn solve_exact_linear_system_raw(');b=s.index('// Keep this large kernel',a)
s=s[:a]+s[b:]
s=s.replace('fn gauss_jordan<const SCALAR_RHS: bool>(', 'fn gauss_jordan(').replace('    rhs: &mut [Real],\n','').replace('    debug_assert!(!SCALAR_RHS || rhs.len() == n);\n','')
import re
s,n=re.subn(r'(\n *)(if SCALAR_RHS \{\n[^\n]*\n *\})', '',s);assert n==4,n
a=s.index('        let pivot_rhs = if SCALAR_RHS');b=s.index('\n\n',a);s=s[:a]+s[b+1:]
# Tests exercise the same augmented production path.
s=s.replace('let rhs = q\n','let rhs: Vec<Real> = q\n')
s=s.replace('let solved =\n                        solve_exact_linear_system(matrix, rhs, PredicatePolicy::STRICT).unwrap();','let mut augmented = matrix;\n                    for (row, value) in augmented.iter_mut().zip(rhs) { row.push(value); }\n                    let solved = solve_affine_steps(augmented, PredicatePolicy::STRICT).unwrap();')
s=s.replace('let mut matrix = vec![vec![derivative.clone()]];\n        let mut rhs = vec![half_scaled_derivative];','let matrix = vec![vec![derivative.clone(), half_scaled_derivative]];').replace('solve_exact_linear_system_raw(&mut matrix, &mut rhs, PredicatePolicy::STRICT)','solve_affine_steps(matrix, PredicatePolicy::STRICT)')
s=s.replace('solve_exact_linear_system_raw(\n                &mut [vec![unresolved]],\n                &mut [Real::one()],\n                PredicatePolicy::STRICT,\n            )','solve_affine_steps(vec![vec![unresolved, Real::one()]], PredicatePolicy::STRICT)').replace('            Err(0)\n        );\n    }\n}', '            Err(AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot: 0 })\n        );\n    }\n}')
assert 'solve_exact_linear_system' not in s and 'SCALAR_RHS' not in s
if len(sys.argv)>1 and sys.argv[1]=='rowview':
 a=s.index('        let pivot_tail = matrix[pivot][pivot..].to_vec();')
 b=s.index('            if compare_reals(&factor',a)
 s=s[:a]+'''        let (above, rest) = matrix.split_at_mut(pivot);
        let (pivot_row, below) = rest.split_first_mut().expect("matrix contains pivot");
        let pivot_tail = &pivot_row[pivot..];
        for row in above.iter_mut().chain(below) {
            let factor = row[pivot].clone();
'''+s[b:]
 s=s.replace('matrix[row].iter_mut().skip(pivot).zip(&pivot_tail)','row.iter_mut().skip(pivot).zip(pivot_tail)')
(w/'src'/f).write_text(s)
