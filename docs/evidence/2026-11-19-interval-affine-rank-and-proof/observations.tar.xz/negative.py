from pathlib import Path
import os,sys,subprocess
w=Path(os.environ['w']);path='crates/hypersolve/src/interval.rs'
source=subprocess.check_output(['git','show','fd842e2b0:'+path],text=True)
for mode in ('column','success'):
 old='.map_err(|pivot| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot })'
 new='.map_err(|_| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot: 0 })' if mode=='column' else '.map_err(|_| AffineKrawczykStatus::CertifiedUniqueRoot)'
 assert source.count(old)==1
 (w/'mutant'/path).write_text(source.replace(old,new))
 for case,ok in [('krawczyk_affine_oracle',True),('krawczyk_affine_residuals',True),('krawczyk_affine_rank',False)]:
  cmd=['cargo','+1.95.0','test','--locked','--release','-p','hypersolve','--all-features','--test',case]
  f=w/'logs'/f'mutant-{mode}-{case}'
  with f.open('w') as output:p=subprocess.run(cmd,cwd=w/'mutant',env=os.environ|{'CARGO_TARGET_DIR':str(w/'mutant-target')},stdout=output,stderr=subprocess.STDOUT)
  assert (p.returncode==0)==ok
  assert ('test result: '+('ok' if ok else 'FAILED')) in f.read_text()
