from pathlib import Path
import json,os,subprocess
s=Path(os.environ['s'])
def segments(p):
 rows=[]
 for l in subprocess.check_output(['readelf','-Wl',p],text=True).splitlines():
  h=l.split()
  if h and h[0] in ('GNU_RELRO','LOAD'):
   start=int(h[2],16);n=int(h[5],16)
   rows.append({'type':h[0],'flags':''.join(h[6:-1]),'file':int(h[4],16),'memory':n,'pages':(start+n+4095)//4096-start//4096})
 return rows
for tag in ('entry','boundary','boundaryroot','bounds','local','augmented','rowview','proofsites','scalarproof','magnitude','early'):
 out={}
 for k in ['owner','lifetime','stress-life','observer','usable','client']:
  a,b=map(segments,[s/'images'/('base-'+k),s/'images'/(tag+'-'+k)]);assert len(a)==len(b)
  out[k]={'baseline':a,'candidate':b}
  if tag=='normalize':
   print(k,'page deltas',[r['pages']-l['pages'] for l,r in zip(a,b)],'memory bytes',[r['memory']-l['memory'] for l,r in zip(a,b)])
 (s/(tag+'-segments.json')).write_text(json.dumps(out,indent=2)+'\n')
