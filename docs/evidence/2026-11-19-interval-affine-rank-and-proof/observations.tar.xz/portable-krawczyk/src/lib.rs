use hyperlimit::{compare_reals,PredicatePolicy};
use hyperreal::Real;
use hypersolve::{Constraint,Expr,Problem,VariableBall,SymbolId,certify_interval_box_candidate,context_from_problem,IntervalBoxCertificationPackage as P,IntervalBoxCertificationStatus as S};
#[unsafe(no_mangle)]
pub extern "C" fn box_verdict(case:u32,mode:u32,package:u32)->u32 {
 let policy=if mode==0 {PredicatePolicy::STRICT} else {PredicatePolicy::APPROXIMATE_512};
 let package=match package {0=>P::Affine,1=>P::UnivariateQuadratic,_=>P::MultivariateQuadratic};
 let radius=fixture_radius(case);
 let mut p=Problem::default();p.add_variable("x",Real::zero());
 p.add_constraint(Constraint::equality("zero",Expr::int(0)));
 let report=certify_interval_box_candidate(&p.analyze(),&context_from_problem(&p),&[VariableBall{symbol:SymbolId(0),radius}],package,policy);
 match report.status {S::Certified=>1,S::Violation=>2,S::Unknown=>3,S::InvalidInput=>{
 assert!(report.certification.is_none());if report.message.unwrap().contains("unknown variable radius sign"){4}else{5}
 }}
}

fn fixture_radius(case:u32)-> Real {
match case {0|4=>{
 let zero=(Real::e()+Real::one()).sin()-Real::e().sin()*Real::one().cos()-Real::e().cos()*Real::one().sin();
 let r=zero-Real::from(2).powi_i64(-2048).unwrap();
 let _=compare_reals(&r,&Real::zero(),PredicatePolicy::APPROXIMATE_512);
 if case==4 {r+Real::one()} else {r}
 },1=>Real::one(),2=>Real::zero(),_=>Real::from(-1)}
}
#[unsafe(no_mangle)]
pub extern "C" fn kraw_radius(case:u32, mode:u32, package:u32)->u32 {
 use hypersolve::{AffineKrawczykStatus as A, QuadraticKrawczykStatus as Q, MultivariateQuadraticKrawczykStatus as M,certify_affine_krawczyk_box,certify_univariate_quadratic_krawczyk_box,certify_multivariate_quadratic_krawczyk_box};
 let policy=if mode==0{PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512};
 let symbol=SymbolId(0);let x=Expr::anonymous_symbol(symbol);
 let mut p=Problem::default();p.add_variable("x",Real::zero());
 p.add_constraint(Constraint::equality("f", if package==0 {x} else {x.clone()*x.clone()+x}));
 let a=p.analyze();let c=context_from_problem(&p);
 let radii=[VariableBall{symbol,radius:fixture_radius(case)}];
 match package {
  0=> match certify_affine_krawczyk_box(&a,&c,&radii,policy).status {A::CertifiedUniqueRoot=>1,A::UnknownVariableRadiusSign{..}=>4,A::NegativeVariableRadius{..}=>5,_=>9},
  1=> match certify_univariate_quadratic_krawczyk_box(&a,&c,&radii,policy).rows[0].status {Q::CertifiedUniqueRoot=>1,Q::UnknownVariableRadiusSign{..}=>4,Q::NegativeVariableRadius{..}=>5,_=>9},
  _=> match certify_multivariate_quadratic_krawczyk_box(&a,&c,&radii,policy).status {M::CertifiedUniqueRoot=>1,M::UnknownVariableRadiusSign{..}=>4,M::NegativeVariableRadius{..}=>5,_=>9},
 }
}
