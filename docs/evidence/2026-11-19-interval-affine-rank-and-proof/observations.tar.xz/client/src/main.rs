mod allocations;
use hyperlimit::PredicatePolicy;
use hyperreal::{Real,dispatch_trace};
use hypersolve::{Constraint,Expr,IntervalBoxCertificationPackage as P,Problem,SymbolId,VariableBall,certify_interval_box_candidate,context_from_problem};
fn main() {
    for center in [0i64,1] {
        for case in 0..7 {
            for package in [P::Affine,P::UnivariateQuadratic,P::MultivariateQuadratic] {
                for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
                    let mut problem = Problem::default();
                    problem.add_variable("x",Real::from(center));
                    problem.add_variable("y",Real::from(4));
                    let x=Expr::anonymous_symbol(SymbolId(0));
                    let y=Expr::anonymous_symbol(SymbolId(1));
                    if case != 6 {
                        let r=match case {0=>x.clone(),1=>x.clone()*x.clone(),_=>x.clone()*x.clone()*x};
                        problem.add_constraint(Constraint::equality("r",r));
                    }
                    if case==4 {problem.add_constraint(Constraint::equality("y=7",y-Expr::int(7)));}
                    let a=problem.analyze();let c=context_from_problem(&problem);
                    let radii=[VariableBall{symbol:SymbolId(u32::from(case==3)),radius:Real::from(i64::from(case!=5))}];
                    let run=||certify_interval_box_candidate(&a,&c,&radii,package,policy);
                    dispatch_trace::reset();
                    let report=dispatch_trace::with_recording(run);
                    let trace=dispatch_trace::take_trace();
                    let key=format!("{center}|{case}|{package:?}|{policy:?}");
                    println!("VERDICT|{key}|{:?}",report.status);
                    println!("EVIDENCE|{key}|{:?}|{:?}|{:?}|{:?}|{trace:?}",report.package,report.variable_balls,report.certification,report.message);
                    drop(report);
                    let h=allocations::measure(16,run);
                    println!("HEAP|{key}|{:?}",(h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes));
                }
            }
        }
    }
}
