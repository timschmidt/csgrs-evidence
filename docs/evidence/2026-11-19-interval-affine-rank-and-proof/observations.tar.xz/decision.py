import json,os
from pathlib import Path
root=Path(os.environ['w']);read=lambda p:json.loads((root/p).read_bytes())
reg=read('registered/all-budget-review.json')
stages=[read('registered/'+s+'/all-accounted.json') for s in ('fixed','preceding','candidate')]
orig=set(stages[0]);assert all(set(s)==orig for s in stages)
checks={}
for k,v in reg.items():
 for m,z in v.items():
  if z['incremental_exceeded'] or z['cumulative_exceeded']:
   checks.setdefault(k,{})[m]=[z['delta'],z['prior_charge_lower_bound'],z['cumulative_lower_bound']]
mismatch=sorted(orig-set(reg))
assert len(mismatch)==9 and all(stages[1][n]==stages[2][n] for n in mismatch)
assert 'hypersolve' not in (root/'logs/lattice-dependencies').read_text()
d=dict(raw_feature_matched=len(reg),feature_mismatch_unchanged=mismatch,raw_overages=checks,old_new_fuzz_accounts=read('fuzz-comparable-accounts.json'))
rows={}
for a in sorted(root.glob('matrix-rank-base-*.json')):
 target=a.name[len('matrix-rank-base-'):-5]
 b=read(a.name);c=read('matrix-rank-repair-'+target+'.json')
 assert set(b)==set(c)
 rows[target]={s:{k:c[s][k]-b[s][k] for k in ['file','code','functions']} for s in b}
d['qualification_suite_deltas']=rows
assert len(rows)==4
d['quiet_owner']={str(cpu):{k:v['median_change_percent'] for k,v in read('quiet-owner-entry-'+str(cpu)+'.json').items()} for cpu in (7,17)}
assert all(len(r)==6 for r in d['quiet_owner'].values())
d['downstream']={str(cpu):read(f'chain-certentry-{cpu}.json')['ratios'] for cpu in (4,14)}
d['standalone_guest_rank']={tag:read('rank-stack-'+tag+'.json') for tag in ('before','entry')}
d['regular_wasi_tests']={stage:(root/'logs'/stage).read_text().splitlines()[-1] for stage in ('wasi-all','wasi-review')}
(root/'decision.json').write_text(json.dumps(d,indent=2)+'\n')
