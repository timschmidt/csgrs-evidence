from pathlib import Path
import os,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
w=Path(os.environ['w'])
script=(w/'old/paired.py').read_text().replace("s/f'paired-{left}-{right}-{cpu}-{order}.json'", "s/f'quiet-paired-{os.environ[\"BLOCK\"]}-{left}-{right}-{cpu}-{order}.json'")
(w/'quiet-paired.py').write_text(script)
def run(cpu):
 for repeat in (1,2):
  for l,r,order in ([('base','base','0'),('base','entry','0'),('entry','base','1')] if (repeat==1)==(cpu==7) else [('entry','base','1'),('base','entry','0'),('base','base','0')]):
   subprocess.run([sys.executable,w/'quiet-paired.py',l,r,str(cpu),order],check=True,env=os.environ|{'BLOCK':str(repeat)})
with ThreadPoolExecutor(2) as ex:list(ex.map(run,(7,17)))
