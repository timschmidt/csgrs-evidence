from pathlib import Path
import hashlib,io,json,lzma,os,tarfile
w=Path(os.environ['w']);record=Path('../csgrs-evidence/docs/evidence/2026-11-19-interval-affine-rank-and-proof')
record.mkdir(parents=True,exist_ok=True)
members={}
def add(p):
 if p.is_file() and not p.is_symlink():
  b=p.read_bytes()
  assert len(b)<3000000 and not b.startswith((b'\x7fELF',b'\0asm'))
  members[str(p.relative_to(w))]=b
for pat in ('*.py','*.patch','*.rs','*.mjs','*.json','trial','partial','build.sh','images.sh','downstream.sh','env','evaluate','bench','check-primary','contract.md','logs/*','registered/*/*.log','registered/*/all-accounted.json','registered/*/all-features.json','registered/*.py','registered/*.patch','registered/*.json','wasi-*/report.json','templates/**/*.json','templates/**/*.py','old/account.py','old/memory.py','old/physical.py','old/paired.py','old/chain.py','old/time-full.py','old/matrix.py','prior/*.cjs','fuzz-account/fuzz-comparable-accounts.json'):
 for p in w.glob(pat):
  if p.suffix!='.jsonl':add(p)
for base in ('client','lifetime','stress-life','observer','usable','portable-krawczyk','pair','stress','rank-guest'):
 for p in (w/base).rglob('*'):
  if p.suffix in ('.rs','.toml','.lock','.cjs') or p.name=='run':add(p)
for stage in ['quiet-owner-entry','time-entry']:
 for p in w.glob(stage+'-*/*/run.log'):add(p)
for k in ('chain-certentry-4','chain-certentry-14'):
 add(w/k/'rows.tsv')
digests={}
with tarfile.open(record/'observations.tar.xz','w:xz',preset=6) as t:
 for k,b in sorted(members.items()):
  info=tarfile.TarInfo(k);info.size=len(b);info.mode=0o644
  t.addfile(info,io.BytesIO(b));digests[k]=hashlib.sha256(b).hexdigest()
(record/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(digests,indent=1,sort_keys=True)+'\n').encode()))
print(len(members),sum(len(b) for b in members.values()),sum(p.stat().st_size for p in record.iterdir()))
