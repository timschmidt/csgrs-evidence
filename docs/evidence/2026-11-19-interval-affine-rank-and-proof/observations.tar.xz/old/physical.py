import ctypes as c,sys,os,json,subprocess,time,random,statistics
from pathlib import Path
s=Path(os.environ['s'])
if sys.argv[1]=='measure':
 lib=c.CDLL(sys.argv[2]);fn=lib.measure;fn.argtypes=[c.c_uint,c.c_size_t];fn.restype=c.c_size_t
 out=[]
 for kind,n,weight in [(0,900,2),(1,450,1),(2,90,16)]:
  assert fn(kind,80)==80*weight
  start=time.thread_time_ns();count=fn(kind,n);delta=time.thread_time_ns()-start
  assert count==n*weight;out.append(delta/n)
 print(json.dumps([out,c.cast(fn,c.c_void_p).value]));exit()
tag,cpu=sys.argv[1:];cpu=int(cpu);os.sched_setaffinity(0,{cpu});root=s/f'physical-{tag}-{cpu}';root.mkdir(exist_ok=True);p=root/'proof.so'
binaries={v:(s/'images'/(v+'-pair.so')).read_bytes() for v in ('base',tag)}
r=random.Random(cpu+111);rows=[];addresses={}
def run(v):
 p.write_bytes(binaries[v]);cmd=['setarch',os.uname().machine,'-R',sys.executable,__file__,'measure',str(p)]
 raw=subprocess.check_output(cmd,text=True);vals,addr=json.loads(raw);addresses.setdefault(v,set()).add(addr);return vals
for block in range(56):
 order=[0,1,1,0] if r.getrandbits(1) else [1,0,0,1];obs=[[],[]]
 for i in order:obs[i].append(run(['base',tag][i]))
 rows.append(obs)
stats={}
for k in range(3):
 delta=[100*(statistics.mean(x[k] for x in b)/statistics.mean(x[k] for x in a)-1) for a,b in rows]
 boot=sorted(statistics.median(r.choices(delta,k=len(delta))) for _ in range(2500))
 stats[k]=[statistics.median(delta),[boot[62],boot[2437]]]
(s/f'physical-{tag}-{cpu}.json').write_text(json.dumps(dict(raw=rows,cpu=cpu,summary=stats,addresses={k:sorted(v) for k,v in addresses.items()}))+'\n')
print(tag,cpu,stats)
