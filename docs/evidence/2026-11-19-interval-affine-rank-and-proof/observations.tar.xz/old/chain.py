from pathlib import Path
import os,sys,subprocess,csv,json,statistics,random,resource
s=Path(os.environ['s']);tag=sys.argv[1];cpu=int(sys.argv[2]);os.sched_setaffinity(0,{cpu})
d=s/f'chain-{tag}-{cpu}';d.mkdir(exist_ok=True);prog=d/'successive_operations';raw=d/'rows.tsv';images={v:(s/'images'/(v+'-successive')).read_bytes() for v in ('primary',tag)}
ref=None
def run(v):
 global ref
 prog.write_bytes(images[v]);prog.chmod(0o755);raw.unlink(missing_ok=True)
 env=dict(os.environ,SUCCESSIVE_OPERATIONS_RAW=str(raw));usage=resource.getrusage(resource.RUSAGE_CHILDREN)
 subprocess.run(['setarch',os.uname().machine,'-R',prog,'((A-B)-C)+D feedback'],env=env,cwd=d,stdout=subprocess.DEVNULL,check=True)
 diff=resource.getrusage(resource.RUSAGE_CHILDREN);lines=raw.read_text().splitlines();rows=list(csv.DictReader((x for x in lines if not x.startswith('#')),delimiter='\t'))
 assert lines[-1]=='# completed' and len(rows)==6 and all(x['outcome']=='certified' and x['manifold']=='yes' for x in rows)
 cols=[k for k in rows[0] if k not in ('step_ns','drop_ns','validation_ns')];stable=[[x[k] for k in cols] for x in rows]
 if ref is None:ref=stable
 assert ref==stable
 return [sum(int(x[k]) for x in rows for k in ('step_ns','drop_ns','validation_ns')),round(1e9*(diff.ru_utime+diff.ru_stime-usage.ru_utime-usage.ru_stime))]
r=random.Random(195);run('primary');run(tag);pairs=[]
for _ in range(32):
 ids=[0,1,1,0] if r.getrandbits(1) else [1,0,0,1];obs=[[],[]]
 for i in ids:obs[i].append(run(['primary',tag][i]))
 pairs.append(obs)
res=[]
for k in range(2):
 ratio=[(statistics.mean(x[k] for x in b)/statistics.mean(x[k] for x in a)-1)*100 for a,b in pairs]
 boot=sorted(statistics.median(r.choices(ratio,k=len(ratio))) for _ in range(2500))
 res.append([statistics.median(ratio),[boot[62],boot[2437]]])
(s/f'chain-{tag}-{cpu}.json').write_text(json.dumps({'same_rows':ref,'trial':tag,'ratios':res,'raw':pairs})+'\n');print(cpu,tag,res)
