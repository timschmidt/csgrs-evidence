import sys,os,json,hashlib,ast
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1];t=s/'templates';sys.path.insert(0,str(t/'prior/history'))
from sizes import metrics
from image_metrics import sizes
history=json.loads((t/'final-account.json').read_bytes())
records={}
for k in ['certification','lifetime','stress-life','observer','usable','client','portable-krawczyk.wasm','stress.wasm']:
 name='owner' if k=='certification' else k
 imgs=[s/'images'/(v+'-'+name) for v in ('base',tag)]
 a,b=[metrics(p) if k.endswith('.wasm') else sizes(p) for p in imgs]
 acc=history[k]['accounts']
 rows={}
 for m,h in acc.items():
  if m not in a or m not in b:continue
  before,after=a[m],b[m];step=max(0,after-before);limits=h['caps'];f=h['fixed']
  inc_basis,cum_basis=(4096,4096) if '4096' in h['percentage_reference'] else (before,f)
  carry=max(h['cumulative'],max(0,before-f))
  rows[m]=dict(baseline=before,trial=after,delta=after-before,prior=carry,cumulative=carry+step,caps=limits,incremental=step<=limits[0] and step*100<=limits[1]*inc_basis,cumulative_pass=(carry+step)<=limits[2] and (carry+step)*100<=limits[3]*cum_basis)
 records[k]={'sha256':[hashlib.sha256(p.read_bytes()).hexdigest() for p in imgs],'headroom_64MiB':67108864-b['file'],'metrics':rows}
 bad=[(m,v['delta']) for m,v in rows.items() if not v['incremental'] or (v['delta']>0 and not v['cumulative_pass'])]
 print(k,'file/code',b['file']-a['file'],b.get('code',b.get('.text'))-a.get('code',a.get('.text')),'exceptions',bad)
(s/(tag+'-sizes.json')).write_text(json.dumps(records,indent=2)+'\n')
