from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,sys,subprocess,json
s=Path(os.environ['s']);tag=sys.argv[1];repo=s/'matrix-src'
sys.path.insert(0,str(s/'templates/prior/history'));from sizes import metrics
def run(job):
 tc,arch=job;wasm=arch=='wasm32-wasip1'
 env=os.environ|{'CARGO_TARGET_DIR':str(s/f'matrix-{tc}'),'CARGO_BUILD_JOBS':'5','CARGO_NET_OFFLINE':'false'}
 if wasm:env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/('sysroot-'+tc))
 suites=sys.argv[2:]
 log=s/'logs'/f'matrix-{tag}-{tc}-{arch}'
 with log.open('w') as f:
  cmd=['cargo','+'+tc,'test','--locked','--release','--all-features','-p','hypersolve','--target',arch,'--no-run','--message-format=json-render-diagnostics']
  for suite in suites:cmd+=['--test',suite]
  result=subprocess.run(cmd,cwd=repo,env=env,stderr=f,stdout=subprocess.PIPE,text=True,check=True)
  rows=[r for r in map(json.loads,result.stdout.splitlines()) if r.get('executable')]
  assert set(r['target']['name'] for r in rows)==set(suites)
  out={}
  for r in rows:
   p=Path(r['executable']);suite=r['target']['name']
   out[suite]=metrics(p)
   cmd=([s/'node',repo/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'] if wasm else [])+[p,'--test-threads=1']
   result=subprocess.run(cmd,cwd=repo,env=env,stderr=subprocess.STDOUT,stdout=subprocess.PIPE,text=True)
   f.write(result.stdout);f.flush()
   expect_fail=(tag=='exposed' and suite=='krawczyk_affine_residuals') or (tag.startswith('mutant') and suite=='krawczyk_affine_oracle')
   if expect_fail:
    assert result.returncode
    names=(['point_box_requires_certified_equality_at_the_only_point','unresolved_elimination_factor_survives_row_swaps_and_box_faces'] if suite=='krawczyk_affine_residuals' else ['coupled_affine_certificates_preserve_the_root_and_closed_faces'])
    for case in names:
     isolated=subprocess.run(cmd+[case,'--exact','--nocapture'],cwd=repo,env=env,stderr=subprocess.STDOUT,stdout=subprocess.PIPE,text=True)
     f.write(isolated.stdout);f.flush()
     assert isolated.returncode and case in isolated.stdout and 'assertion' in isolated.stdout, isolated.stdout[:1200]
   else:result.check_returncode();assert 'test result: ok' in result.stdout
  (s/f'matrix-{tag}-{tc}-{arch}.json').write_text(json.dumps(out)+'\n')
jobs=[(tc,t) for tc in ['1.95.0','stable'] for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']]
with ThreadPoolExecutor(4) as pool:list(pool.map(run,jobs))
