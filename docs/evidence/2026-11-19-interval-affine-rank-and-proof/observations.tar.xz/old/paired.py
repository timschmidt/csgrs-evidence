import os,sys,ctypes,time,statistics,json,random
from pathlib import Path
s=Path(os.environ['s']);left,right,cpu,order=sys.argv[1:];cpu=int(cpu);os.sched_setaffinity(0,{cpu})
libs=[ctypes.CDLL(str(s/'images'/(v+'-pair.so'))) for v in (left,right)]
fs=[lib.measure for lib in libs]
for fn in fs: fn.argtypes=[ctypes.c_uint,ctypes.c_size_t];fn.restype=ctypes.c_size_t
r=random.Random(195+cpu);results={}
for k,expected in enumerate([2,1,16]):
 for fn in fs: assert fn(k,80)==80*expected
 samples=[];iterations=[100,50,10][k]
 for block in range(320):
  ids=[0,1,1,0] if (r.getrandbits(1)^int(order)) else [1,0,0,1];obs=[[],[]]
  for i in ids:
   start=time.thread_time_ns();n=fs[i](k,iterations);delta=time.thread_time_ns()-start
   assert n==expected*iterations;obs[i].append(delta/iterations)
  samples.append([statistics.mean(v) for v in obs])
 ratio=[(b/a-1)*100 for a,b in samples]
 boot=sorted(statistics.median(r.choices(ratio,k=len(ratio))) for _ in range(3000))
 results[k]=dict(median=statistics.median(ratio),bootstrap95=[boot[74],boot[2924]],raw_ns=samples)
print(cpu,left,right,{k:(round(row['median'],3),[round(v,3) for v in row['bootstrap95']]) for k,row in results.items()})
(s/f'paired-{left}-{right}-{cpu}-{order}.json').write_text(json.dumps(results)+'\n')
