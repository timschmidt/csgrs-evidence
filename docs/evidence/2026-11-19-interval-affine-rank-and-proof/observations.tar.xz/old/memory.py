from pathlib import Path
import os,sys,json,ast
s=Path(os.environ['s']);tag=sys.argv[1];t=s/'templates'
read=lambda p: json.loads(p.read_bytes())
def rows(stage,name,n):
 files=[p for p in (s/'logs').glob(stage+'-'+name+'-[0-9]*') if p.suffix==''];assert len(files)==n
 d={}
 for f in files:
  for line in f.read_text().splitlines():
   typ,i,rest=line.split('|',2);key=(typ.lower(),int(i))
   if typ=='STACK':
    warm,pattern,h=rest.split('|');key+=(int(warm),);v=int(h)
   else:v=ast.literal_eval(rest)
   d.setdefault(key,[]).append(v)
 return {k:max(v) if k[0]=='stack' else [max(a) for a in zip(*v)] for k,v in d.items()}
out={}
for name,n in [('lifetime',24),('stress-life',48)]:
 stress=name=='stress-life'
 hist={tuple([r['key'][0].lower(),*r['key'][1:]]):r for r in read(t/('magnitude-'+('stress' if stress else 'lifetime')+'.json'))}
 fixed_by={(h['workload'],int(h['temperature']=='warm')):h['fixed'] for h in read(t/'prior/history/regular-stack-accounts.json')}
 a,b=[rows(v,name,n) for v in ('base',tag)];assert set(a)==set(b)==set(hist)
 res=[]
 for k,now in b.items():
  ref=(k[0],k[1]-6,*k[2:]) if stress and k[1] in (6,9) else k
  stack=k[0]=='stack';value=lambda v:v if stack else v[-2]
  prev=value(a[ref]);current=value(now);arch=value(hist[ref]['candidate'])
  fixed=(value(hist[ref]['fixed']) if stress else fixed_by[ref[1:]] if stack else hist[ref]['reference'])
  prior=max(hist[k]['cumulative'],hist[ref]['cumulative'])+max(0,prev-arch)
  inc=max(0,current-prev);cum=inc+prior
  ok=(inc<=128 and inc*100<=prev and cum<=256 and cum*100<=fixed*2) if stack else (now[-1]==0 and inc==0)
  res.append(dict(key=k,ref=ref,baseline=a[k],matched=a[ref],candidate=now,fixed=fixed,prior=prior,increment=inc,cumulative=cum,passes=ok and current<=16384))
 print(name,'comparisons',len(res),'failures',[(r['key'],r['increment'],r['cumulative']) for r in res if not r['passes']])
 out[name]=res
(s/(tag+'-memory.json')).write_text(json.dumps(out,indent=2)+'\n')
