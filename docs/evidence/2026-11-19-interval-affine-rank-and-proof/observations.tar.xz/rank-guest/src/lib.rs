use hyperreal::Real;
use hypersolve::{AffineKrawczykStatus,Constraint,Expr,PredicatePolicy,Problem,SymbolId,VariableBall,certify_affine_krawczyk_box,context_from_problem};
fn tiny(hidden: bool) -> Real {
    let eps = Real::from(2).powi_i64(-2048).unwrap();
    if !hidden {return eps;}
    (Real::e()+Real::one()).sin() - Real::e().sin()*Real::one().cos() - Real::e().cos()*Real::one().sin() + eps
}
#[unsafe(no_mangle)]
pub extern "C" fn rank(case:u32, mode:u32)->u32{
    let mut p=Problem::default();
    let [x,y]=["x","y"].map(|s|SymbolId::from(p.add_variable(s,Real::zero())));
    let c=tiny(case&1!=0);let scale=Real::from(2).powi_i64(2048).unwrap();
    let (c,scale)=if case&2!=0{(-c,-scale)}else{(c,scale)};
    let a=Expr::anonymous_symbol(x)+Expr::real(scale)*Expr::anonymous_symbol(y);
    let b=Expr::real(c)*Expr::anonymous_symbol(x)+Expr::anonymous_symbol(y);
    for r in if case&4!=0{[b,a]}else{[a,b]}{p.add_constraint(Constraint::equality("row",r));}
    let ctx=context_from_problem(&p);let analysis=p.analyze();
    let bounds=[x,y].map(|symbol|VariableBall{symbol,radius:Real::one()});
    let policy=if mode==0{PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512};
    let report=certify_affine_krawczyk_box(&analysis,&ctx,&bounds,policy);
    assert_eq!((report.variable_count,report.equality_rows),(2,2));
    match report.status{
        AffineKrawczykStatus::SingularOrUnsupportedPivot{pivot:1}=>{assert!(report.steps.is_empty());0}
        AffineKrawczykStatus::CertifiedUniqueRoot=>{assert_eq!(report.steps.len(),2);for s in report.steps{assert_eq!(s.certified_root,Real::zero());}1}
        _=>2,
    }
}
