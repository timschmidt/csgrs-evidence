const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
const m=await WebAssembly.compile(fs.readFileSync(process.argv[2]));assert.deepEqual(WebAssembly.Module.imports(m),[]);
let counts=[0,0,0];
for (let cold=0;cold<2;cold++){
 const {exports}=await WebAssembly.instantiate(m);
 for(let repeat=0;repeat<2;repeat++)for(let c=0;c<8;c++)for(let mode=0;mode<2;mode++){
  const v=exports.rank(c,mode);counts[v]++;console.log(cold,repeat,c,mode,v);
  if(process.argv[3]==='fixed'||!(c&1)||!mode)assert.equal(v,0);
 }
}
console.log(JSON.stringify(counts));if(process.argv[3]==='before')assert(counts[1]>0);
})().catch(e=>{console.error(e);process.exit(1)});
