from pathlib import Path
import os,sys,subprocess
w=Path(os.environ['w']);tag=sys.argv[1];f='crates/hypersolve/src/interval.rs';s=subprocess.check_output(['git','show','fd842e2b0:'+f],text=True)
if tag=='factorproof':
 a='gauss_jordan::<true>(matrix, rhs, policy)?;';assert s.count(a)==1;s=s.replace(a,'gauss_jordan::<true>(matrix, rhs, policy.certified_only())?;')
 s=s.replace('Terminal approximation can skip a nonzero factor or accept a root outside the box.', 'The elimination uses certified pivots and factors. A terminal containment\n/// comparison can still accept a root outside the box.')
elif tag=='faceproof':
 a='compare_reals(&displacement, radius, policy)';assert s.count(a)==1;s=s.replace(a,'compare_reals(&displacement, radius, policy.certified_only())')
 s=s.replace('Terminal approximation can skip a nonzero factor or accept a root outside the box.', 'Containment uses certified comparisons. Terminal approximation during\n/// elimination can still skip a nonzero factor.')
else:raise ValueError(tag)
(w/'src'/f).write_text(s)
