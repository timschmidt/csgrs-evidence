use hypersolve::*;
use hyperreal::{Rational,Real};
use std::hint::black_box;
fn r(v:i64)->Real{ Real::new(Rational::new(v)) }

fn affine_krawczyk_problem() -> Problem {
    let x = Expr::symbol(SymbolId(0), "x");
    let y = Expr::symbol(SymbolId(1), "y");
    let mut problem = Problem::default();
    problem.add_variable("x", r(2));
    problem.add_variable("y", r(2));
    problem.add_constraint(Constraint::equality(
        "x plus y minus five",
        x.clone() + y.clone() - Expr::int(5),
    ));
    problem.add_constraint(Constraint::equality(
        "x minus y minus one",
        x - y - Expr::int(1),
    ));
    problem
}

fn univariate_quadratic_problem(row_count: usize) -> Problem {
    let x = Expr::symbol(SymbolId(0), "x");
    let mut problem = Problem::default();
    problem.add_variable("x", r(3));
    for index in 0..row_count {
        let scale = index as i64 + 1;
        problem.add_constraint(Constraint::equality(
            format!("quadratic {index}"),
            x.clone() * x.clone() * Expr::int(scale) - x.clone() * Expr::int(2 * scale)
                + Expr::int(scale),
        ));
    }
    problem
}

fn multi(dimension:usize)->Problem {
        let mut square_problem = Problem::default();
        let offsets = (0..dimension)
            .map(|index| {
                square_problem.add_variable(format!("x{index}"), Real::one());
                Expr::symbol(SymbolId(index as u32), format!("x{index}")) - Expr::int(1)
            })
            .collect::<Vec<_>>();
        for row in 0..dimension {
            let mut residual = offsets[row].clone().powi(2);
            for (column, offset) in offsets.iter().enumerate() {
                let coefficient = if column == row { 2 * dimension + 1 } else { 1 };
                residual = residual + Expr::int(coefficient as i64) * offset.clone();
            }
            square_problem
                .add_constraint(Constraint::equality(format!("square row {row}"), residual));
        }
square_problem
}

type Setup = (ProblemAnalysis<'static>, EvaluationContext, Vec<VariableBall>);
fn setup(p: Problem, balls: Vec<VariableBall>) -> Setup {
 let p=Box::leak(Box::new(p));(p.analyze(),context_from_problem(p),balls)
}
thread_local! {
 static A:Setup=setup(affine_krawczyk_problem(),vec![]);
 static U:Setup=setup(univariate_quadratic_problem(16),vec![]);
 static M:Setup=setup(multi(1),vec![VariableBall{symbol:SymbolId(0),radius:Real::new(Rational::fraction(1,16).unwrap())}]);
}
#[unsafe(no_mangle)]
pub extern "C" fn measure(kind:u32,n:usize)->usize {
 let mut count=0;
 match kind {
 0=>A.with(|(a,c,_)|for _ in 0..n {
 let report=black_box(certify_affine_krawczyk_box(a,c,&[VariableBall{symbol:SymbolId(0),radius:r(1)},VariableBall{symbol:SymbolId(1),radius:r(0)}],PredicatePolicy::APPROXIMATE_512));
 assert_eq!(report.status,AffineKrawczykStatus::CertifiedUniqueRoot);count+=report.steps.len();}),
 1=>M.with(|(a,c,b)|for _ in 0..n {let report=black_box(certify_multivariate_quadratic_krawczyk_box(a,c,b,PredicatePolicy::STRICT));assert!(report.certified_unique_root());count+=report.variables.len();}),
 2=>U.with(|(a,c,_)|for _ in 0..n {let report=black_box(certify_univariate_quadratic_krawczyk_box(a,c,&[VariableBall{symbol:SymbolId(0),radius:r(0)}],PredicatePolicy::APPROXIMATE_512));count+=report.examined_rows;}),
 _=>unreachable!()
 };count
}
