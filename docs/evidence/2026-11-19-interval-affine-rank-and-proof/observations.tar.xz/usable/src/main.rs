mod allocation;
use std::{ffi::c_void,hint::black_box};
extern "C" fn run(ptr:*mut c_void){
 let i=ptr.addr() as u32;
 let case=i%5;let mode=i/5%2;let package=i/10%3;
 let result=if i/30==0{box_radius_client::box_verdict(case,mode,package)}else{box_radius_client::kraw_radius(case,mode,package)};
 black_box(result);
}
fn main(){
 for i in 0..60 {
  let ptr=std::ptr::without_provenance_mut(i);
  for _ in 0..8 {run(ptr);}
  let (_,v)=allocation::observe(||{run(ptr);run(ptr);});
  println!("{}|{:?}|{:?}",i,v.values(),v.usable());assert_eq!(v.usable().2,0);
 }
}
