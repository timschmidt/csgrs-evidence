from pathlib import Path
import os
s=Path(os.environ['s'])
exec((s/'fuzz-account.py').read_text().split('out={}')[0])
f=s/'fuzz-budget-measurement.json';out=json.loads(f.read_text())
assert len(out)==4
for stage in ('old-previous','old-retained'):
 if stage=='old-previous':
  tree('e5524c9ca')
  for p in ['crates/hypersolve/benches/retained_fuzz.rs','crates/hypersolve/benches/support/benchmark_report.rs','crates/hypersolve/benches/support/retained_fuzz.rs']:
   (w/p).write_bytes(subprocess.check_output(['git','-C',repo,'show','c9f1f9ac5:'+p]))
 else:subprocess.run(['git','apply',s/'certentry.patch'],cwd=w,check=True)
 out[stage]=build(stage);print(stage,out[stage]['metrics'],flush=True)
 f.write_text(json.dumps(out,indent=2)+'\n')
