from pathlib import Path
import hashlib,io,json,lzma,sys,subprocess,tarfile
root=Path.cwd();repo=str(root.parent/'csgrs-evidence');commit=sys.argv[1];record='docs/evidence/2026-11-19-interval-affine-rank-and-proof'
def blob(s):return subprocess.check_output(['git','-C',repo,'show',commit+':'+record+'/'+s])
hashes=json.loads(lzma.decompress(blob('members.sha256.json.xz')))
with tarfile.open(fileobj=io.BytesIO(blob('observations.tar.xz')),mode='r:xz') as tf:
 actual={}
 for f in tf:
  assert f.isfile() and f.name not in actual
  actual[f.name]=hashlib.sha256(tf.extractfile(f).read()).hexdigest()
 assert actual==hashes
sys.path.insert(0,str(root))
from scripts import evidence_archive as ea
ea.ROOTS={record:False}
_,row=ea.manifest(repo,commit)
dest=root/'docs/evidence-archive.tsv'
existing=dest.read_text().splitlines()
if row not in existing:
 assert not any(x.startswith(record+'\t') for x in existing)
 with dest.open('a') as out:out.write(row+'\n')
assert dest.read_text().splitlines().count(row)==1
print(commit,len(hashes),row)
