from pathlib import Path
import os,sys,subprocess
w=Path(os.environ['w']);tag=sys.argv[1]
f='crates/hypersolve/src/interval.rs'
s=subprocess.check_output(['git','show','fd842e2b0:'+f],text=True)
assert s.count('let mut matrix = Vec::new();\n    let mut rhs = Vec::new();')==1
s=s.replace('let mut matrix = Vec::new();\n    let mut rhs = Vec::new();','let mut matrix = Vec::new();\n    let mut rhs = Vec::new();')
idx=s.index('    let variable_count = ',s.index('pub fn certify_affine_krawczyk_box('))
s=s[:idx]+'    let policy = policy.certified_only();\n'+s[idx:]
s=s.replace('for every variable. Use `PredicatePolicy::STRICT` for proof.\n/// Terminal approximation can skip a nonzero factor or accept a root outside the box.','for every variable. Pivot selection, elimination and\n/// containment use the certified stages of the supplied policy.')
if tag in ('boxed','early','exact','bounds'):
 s=s.replace('solve_exact_linear_system_raw(&mut matrix, &mut rhs, policy)\n        .map_err(|pivot| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot })','gauss_jordan::<true>(&mut matrix, &mut rhs, policy)\n        .map_err(|pivot| AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot })?;\n    Ok(rhs.into_boxed_slice().into_vec())')
 s=s.replace('fn solve_exact_linear_system_raw(', '#[cfg(test)]\nfn solve_exact_linear_system_raw(')
 if tag=='early':
  s=s.replace('    gauss_jordan::<true>(&mut matrix, &mut rhs, policy)', '    rhs.shrink_to_fit();\n    gauss_jordan::<true>(&mut matrix, &mut rhs, policy)',1).replace('Ok(rhs.into_boxed_slice().into_vec())','Ok(rhs)')
 if tag=='exact':
  s=s.replace('    let mut rhs = Vec::new();','    let mut rhs = Vec::with_capacity(variable_count.min(analysis.problem().constraints.len()));',1).replace('Ok(rhs.into_boxed_slice().into_vec())','Ok(rhs)')
 if tag=='bounds':
  a=s.index('fn solve_exact_linear_system(')
  b=s.index('fn invert_exact_matrix(',a)
  s=s[:a]+s[a:b].replace('Result<Vec<Real>,','Result<Box<[Real]>,').replace('rhs.into_boxed_slice().into_vec()','rhs.into_boxed_slice()')+s[b:]
if tag in ('boxed','early','exact','bounds'):
 a=s.index('#[cfg(test)]\nfn solve_exact_linear_system_raw(')
 b=s.index('// A scalar RHS',a)
 s=s[:a]+s[b:]
 s=s.replace('let mut matrix = vec![vec![derivative.clone()]];', 'let matrix = vec![vec![derivative.clone()]];').replace('let mut rhs = vec![half_scaled_derivative];','let rhs = vec![half_scaled_derivative];').replace('solve_exact_linear_system_raw(&mut matrix, &mut rhs, PredicatePolicy::STRICT)','solve_exact_linear_system(matrix, rhs, PredicatePolicy::STRICT)').replace('solve_exact_linear_system_raw(\n                &mut [vec![unresolved]],\n                &mut [Real::one()],','solve_exact_linear_system(\n                vec![vec![unresolved]],\n                vec![Real::one()],').replace('            Err(0)\n        );\n    }\n}', '            Err(AffineKrawczykStatus::SingularOrUnsupportedPivot { pivot: 0 })\n        );\n    }\n}')
if tag in ('radius','local','slice'):
 a=s.index('fn validate_krawczyk_variable_balls(')
 b=s.index('fn solve_exact_linear_system(',a)
 v=s[a:b].replace('HashMap<SymbolId, Real>', 'HashMap<SymbolId, &Real>').replace('radii.insert(ball.symbol, ball.radius.clone());','radii.insert(ball.symbol, &ball.radius);')
 s=s[:a]+v+s[b:]
 a=s.index('pub fn certify_affine_krawczyk_box(')
 b=s.index('/// Certify univariate quadratic rows',a)
 v=s[a:b].replace('let Some(radius) = radius_by_symbol.get','let Some(&radius) = radius_by_symbol.get')
 if tag=='local':
  v=v.replace('let displacement = abs_real(&step);','let radius = radius.clone();\n        let displacement = abs_real(&step);').replace('compare_reals(&displacement, radius, policy)','compare_reals(&displacement, &radius, policy)').replace('radius: radius.clone(),','radius,')
 s=s[:a]+v+s[b:]
if tag in ('proofsites','scalarproof','scalarowned'):
 a=s.index('pub fn certify_affine_krawczyk_box(');b=s.index('/// Certify univariate quadratic rows',a)
 v=s[a:b].replace('    let policy = policy.certified_only();\n','').replace('compare_reals(&displacement, radius, policy)','compare_reals(&displacement, radius, policy.certified_only())')
 s=s[:a]+v+s[b:]
 if tag=='proofsites':
  a=s.index('    let n = matrix.len();',s.index('fn gauss_jordan<const'))
  s=s[:a]+'    let policy = policy.certified_only();\n'+s[a:]
 else:
  s=s.replace('gauss_jordan::<true>(matrix, rhs, policy)?;', 'gauss_jordan::<true>(matrix, rhs, policy.certified_only())?;')
  if tag=='scalarowned':
   s=s.replace('certified_root: candidate.clone() + step.clone(),', 'certified_root: candidate + &step,',1)
if tag=='magnitude':
 a=s.index('fn abs_real(value: &Real) -> Real {');b=s.index('\n}',a)+2
 old=s[a:b];assert old.count('value.clone()')==2
 s=s[:a]+'''fn abs_real(value: &Real) -> Real {
    abs_real_ref(value).into_owned()
}

fn abs_real_ref(value: &Real) -> std::borrow::Cow<'_, Real> {
    use std::borrow::Cow;
    match value.structural_facts().sign {
        Some(RealSign::Negative) => Cow::Owned(-value.clone()),
        Some(RealSign::Zero | RealSign::Positive) => Cow::Borrowed(value),
        None => Cow::Owned(value.abs()),
    }
}'''+s[b:]
 s=s.replace('let displacement = abs_real(&step);','let displacement = abs_real_ref(&step);',1)
if tag in ('boundary','boundaryroot'):
 a=s.index('pub fn certify_affine_krawczyk_box(')
 b=s.index('    let variable_count =',a)
 sig=s[a:s.index('    let policy = policy.certified_only();',a)]
 s=s[:a]+'#[inline]\n'+sig+'    affine_krawczyk_box(analysis, context, variable_balls, policy.certified_only())\n}\n\n// The public proof boundary has already restricted the policy to certified stages.\n#[inline(never)]\n'+sig.replace('pub fn certify_affine_krawczyk_box(', 'fn affine_krawczyk_box(')+s[b:]
if tag=='entry':
 v=s.index('fn validate_krawczyk_variable_balls(');end=s.index('fn solve_exact_linear_system(',v)
 s=s[:v]+s[v:end].replace('policy.certified_only()', 'policy')+s[end:]
if tag=='boundaryroot':
 s=s.replace('certified_root: candidate.clone() + step.clone(),','certified_root: candidate + &step,',1)
(w/'src'/f).write_text(s)
