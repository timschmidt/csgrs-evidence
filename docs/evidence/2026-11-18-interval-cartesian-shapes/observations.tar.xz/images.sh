set -eu
s=/dev/shm/interval-cartesian-shapes
cd "$s/control"
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/mutations-target"
for tag in before retained;do
 if test "$tag" = retained;then git checkout --detach "$(cat "$s/revision")";fi
 for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown;do
  cargo +1.88.0 build --locked --release -p hyperlattice-interval --features fixed --example fixed_affine --target "$target"
  if test "$target" = wasm32-unknown-unknown;then suffix=.wasm;else suffix=;fi
  cp "$CARGO_TARGET_DIR/$target/release/examples/fixed_affine$suffix" "$s/$tag-$target"
 done
done
for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown;do cmp "$s/before-$target" "$s/retained-$target";done
