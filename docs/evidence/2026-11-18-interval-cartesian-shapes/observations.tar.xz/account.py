from pathlib import Path
import hashlib,json,re
s=Path(__file__).parent
revision=(s/'revision').read_text().strip()
p=Path('docs/research/interval-size-accounts.json')
data=json.loads(p.read_text())
cap=64*2**20; free=16*2**20
key='new_cartesian_shape_test_harnesses'
assert key not in data
data[key]=[]
native=Path(re.search(r'Running tests/shape_replay.rs \(([^)]+)\)',(s/'logs/published-release').read_text())[1])
asan=Path('/dev/shm/interval-atanh-oracle/fuzz-target/x86_64-unknown-linux-gnu/release/cartesian_shapes')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for path,artifact,tool,features in [
 (native,'crates/hyperlattice-interval/tests/shape_replay.rs','Rust 1.95.0 release','all Hyperlattice interval features; workspace lock'),
 (asan,'crates/hyperinterval/fuzz/fuzz_targets/cartesian_shapes.rs',(s/'nightly.txt').read_text().strip(),'lattice-shapes; ASan with libFuzzer; standalone interval fuzz lock'),
]:
 n=path.stat().st_size;assert cap-n>=free
 row=dict(artifact=artifact,target='x86_64-unknown-linux-gnu',toolchain=tool,features=features,source_snapshot=revision,file_bytes=n,sha256=digest(path),qualification_capacity_bytes=cap,required_free_bytes=free,remaining_bytes=cap-n,evidence='docs/evidence/2026-11-18-interval-cartesian-shapes')
 data[key].append(row)
(s/'qualification-images.json').write_text(json.dumps(data[key],indent=2)+'\n')
p.write_text(json.dumps(data,indent=2)+'\n')
pairs={}
for target in ('wasm32-unknown-unknown','x86_64-unknown-linux-gnu'):
 a,b=[s/(tag+'-'+target) for tag in ('before','retained')]
 assert a.read_bytes()==b.read_bytes()
 pairs[target]=dict(bytes=a.stat().st_size,sha256=digest(b))
(s/'fixed-affine-images.json').write_text(json.dumps(pairs,indent=2)+'\n')
print([(r['file_bytes'],r['remaining_bytes']) for r in data[key]],pairs)
