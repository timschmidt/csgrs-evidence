from pathlib import Path
from itertools import product
from collections import Counter
import json
s=Path(__file__).parent
source=Path.cwd()/'crates/hyperlattice-interval/tests/fixtures/shapes'
shapes=[(0,0),(0,3),(3,0),(2,3),(3,2),(1,33),(33,1)]
def classify(data):
 if not data:return None
 byte=lambda i:data[i%len(data)]
 phase=byte(0)//64
 r,c=shapes[(byte(0)%64)%7]
 def endpoint(i):
  v=byte(4+i)
  if phase==2:return int.from_bytes(bytes(byte(4+4*i+j) for j in range(4)),'little',signed=True)
  if phase==1 and v in [127,128]:return 2**31-1 if v==127 else -2**31
  return v if v<128 else v-256
 def lane(i):return sorted((endpoint(2*i),endpoint(2*i+1)))
 m=byte(1)%9 if byte(1)<128 else 0
 v=byte(2)%7 if byte(2)<128 else 0
 def status(mode,has_entry):
  if mode==0:return 'nonempty'
  if mode==6 or mode==1 and has_entry:return 'empty'
  return 'invalid'
 a,b=status(m,r*c>0),status(v,c>0)
 shape=f'{r}x{c}'
 if 'invalid' in [a,b]:return shape,a,b,'invalid'
 if 'empty' in [a,b]:return shape,a,b,'empty'
 rows=[[lane(i*c+j) for j in range(c)] for i in range(r)]
 vec=[lane(r*c+i) for i in range(c)]
 def dot(u,w):
  sums=[0,0]
  for x,y in zip(u,w):
   corners=[l*h for l,h in product(x,y)]
   for i,val in enumerate((min(corners)//4,-((-max(corners))//4))):
    sums[i]+=val
    if not -2**31<=val<2**31:raise OverflowError('term')
    if not -2**31<=sums[i]<2**31:raise OverflowError('sum')
  return sums
 try:y=[dot(row,vec) for row in rows]
 except OverflowError as e:return shape,a,b,'first-'+str(e)
 try:[dot([row[j] for row in rows],y) for j in range(c)]
 except OverflowError as e:return shape,a,b,'second-'+str(e)
 return shape,a,b,'completed'
def count(data):
 d=[Counter() for _ in range(4)]
 for inp in data:
  result=classify(inp)
  if result:
   for bucket,item in zip(d,result):bucket[item]+=1
 return dict(zip(('shape','matrix','vector','action'),d))
grid=(bytes([sh|enc,m,v,i,128,3,17,127,0]) for sh,m,v,i,enc in product(range(7),range(9),range(7),[0,1,2,127,255],[0,64,128]))
out={'native':count(grid),'fixtures':{p.name:classify(p.read_bytes()) for p in source.glob('*.bin')}}
assert [out['fixtures'][k][-1] for k in ['prefix-overflow.bin','replayed-overflow.bin','wide-quarter-grid.bin','empty-before-invalid.bin']]==['first-sum','second-term','completed','invalid']
for name in ['final-corpus','seeded','ci-corpus']:
 unique={p.read_bytes() for p in (s/name).iterdir() if p.is_file()}
 out[name]=count(unique)
(s/'census.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v.get('action',v) for k,v in out.items()}))
