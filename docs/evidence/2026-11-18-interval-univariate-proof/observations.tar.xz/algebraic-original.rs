//! For k((x-t)²-n), the roots are t ± sqrt(n). At either root, a ball of
//! radius m*sqrt(n) has contraction factor m and image radius m²*sqrt(n).
#[path = "support/represented_roots.rs"]
mod oracle;

use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use hypersolve::{
    Constraint, EvaluationContext, Expr, Problem, QuadraticKrawczykStatus as Status, SymbolId,
    VariableBall, certify_univariate_quadratic_krawczyk_box, context_from_problem,
};

#[test]
fn algebraic_center_and_radius_preserve_the_signed_derivative_and_original_equation() {
    for (n, translation, scale) in [(2, 0, 1_i64), (3, -5, -2), (5, 4, 3)] {
        let root = oracle::sqrt(n);
        for sign in [-1_i64, 1] {
            let center = Real::from(translation) + Real::from(sign) * &root;
            let mut problem = Problem::default();
            let symbol = SymbolId::from(problem.add_variable("x", center.clone()));
            let shifted = Expr::anonymous_symbol(symbol) - Expr::int(translation);
            let original = Expr::int(scale) * (shifted.clone() * shifted - Expr::int(n));
            problem.add_constraint(Constraint::equality(
                "translated quadratic",
                original.clone(),
            ));
            let analysis = problem.analyze();
            let context = context_from_problem(&problem);
            // The image is contained up to and including m = 1. Contraction is strict.
            for quarters in [0_i64, 1, 3, 4, 5, 8] {
                let radius = &root * oracle::q(quarters, 4);
                let bounds = [VariableBall {
                    symbol,
                    radius: radius.clone(),
                }];
                let expected = match quarters.cmp(&4) {
                    std::cmp::Ordering::Less => Status::CertifiedUniqueRoot,
                    std::cmp::Ordering::Equal => Status::NonContractiveDerivative,
                    std::cmp::Ordering::Greater => Status::ImageOutsideBox,
                };
                for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
                    let report = certify_univariate_quadratic_krawczyk_box(
                        &analysis, &context, &bounds, policy,
                    );
                    assert_eq!(report.rows.len(), 1);
                    assert_eq!(report.examined_rows, 1);
                    assert_eq!(report.certified_rows, usize::from(quarters < 4));
                    let row = &report.rows[0];
                    assert_eq!(row.status, expected, "{n} {scale} {sign} {quarters}");
                    assert_eq!((row.constraint_index, row.symbol), (0, symbol));
                    oracle::assert_equal(&row.candidate, &center);
                    oracle::assert_equal(&row.radius, &radius);
                    oracle::assert_exact_zero(&row.residual);
                    oracle::assert_exact_zero(row.step.as_ref().unwrap());
                    oracle::assert_equal(&row.derivative, &(Real::from(2 * scale * sign) * &root));
                    oracle::assert_equal(
                        row.remainder_radius.as_ref().unwrap(),
                        &(&root * oracle::q(quarters * quarters, 16)),
                    );
                    oracle::assert_equal(
                        row.contraction_numerator.as_ref().unwrap(),
                        &(Real::from(2 * scale.abs()) * &radius),
                    );
                    oracle::assert_equal(
                        row.contraction_denominator.as_ref().unwrap(),
                        &(Real::from(2 * scale.abs()) * &root),
                    );

                    let mut replay = EvaluationContext::default();
                    replay.bind(symbol, &row.candidate + row.step.as_ref().unwrap());
                    oracle::assert_exact_zero(&original.eval_real(replay.bindings()).unwrap());
                }
            }
        }
    }
}
