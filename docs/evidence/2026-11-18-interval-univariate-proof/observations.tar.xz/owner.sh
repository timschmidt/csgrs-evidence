set -eu
s=/dev/shm/interval-univariate-proof; v=$1
cd "$s/src"
. /dev/shm/interval-horner-readmission/env
export CARGO_TARGET_DIR="$s/owner" CARGO_BUILD_JOBS=14
cargo +1.95.0 build --locked --release -p hypersolve --all-features --bench certification --test krawczyk_univariate_certainty --message-format=json > "$s/logs/$v-build.jsonl"
python3 - "$v" <<'PY'
from pathlib import Path
import json,shutil,sys
s=Path('/dev/shm/interval-univariate-proof');v=sys.argv[1]
for r in map(json.loads,(s/f'logs/{v}-build.jsonl').read_text().splitlines()):
 if r.get('executable'):shutil.copyfile(r['executable'],p:=s/'images'/(v+'-'+r['target']['name']));p.chmod(0o755)
PY
"$s/images/$v-krawczyk_univariate_certainty" --nocapture > "$s/logs/$v-green.log" 2>&1
