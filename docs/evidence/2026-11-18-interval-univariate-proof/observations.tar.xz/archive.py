from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-univariate-proof'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p):files[str(p.relative_to(d))]=p.read_bytes()
for p in d.iterdir():
 if p.is_file() and (p.suffix in ('.log','.py','.sh','.json','.rs','.patch','.md','.txt','.cjs') or p.name in ('scope','oracle-revision','source-revision')):add(p)
for folder in ('logs','head-wasi-stable','head-wasi-1.95.0','history','inputs'):
 for p in (d/folder).rglob('*'):
    if p.is_file() and p.suffix!='.pyc':
        if p.suffix=='.jsonl':continue
        add(p)
for project in ('observer','observer-primary','client','usable','lifetime','stress','stress-life','portable-krawczyk'):
 for p in (d/project).rglob('*'):
    if p.is_file() and p.suffix in ('.toml','.lock','.rs','.c','.cjs'):add(p)
for folder in ('timing','confirmation','borrowed-timing','caller-timing','caller-confirmation'):
 for p in (d/folder).rglob('*.json'):
    if p.parent.name=='new':add(p)
for stage in ('fixed','preceding','candidate'):
 for name in ('all-build.log','all-features.json','all-accounted.json'):
    add(d/stage/name)
assert len(list((d/'caller-confirmation').rglob('new/sample.json')))==16
assert len(list((d/'caller-timing').rglob('new/sample.json')))==32
for p in (d/'images').iterdir():
    files['images/'+p.name+'.sha256']=h(p.read_bytes()).encode()
assert '1 passed; 2 failed;' in (d/'logs/red.log').read_text()
assert 'derivative, n=2, k=1, sign=-1, quarters=0' in (d/'logs/mutant.log').read_text()
for tag in ('row','entry','borrowed','derivative','magnitude','inline','caller'):
 assert '3 passed; 0 failed;' in (d/f'logs/{tag}-green.log').read_text()
 assert (d/f'{tag}-size.json').is_file()
for v in ('1.95.0','stable'):
 assert (d/f'logs/head-quality-{v}.log').read_text().strip().endswith('PASS')
 assert '64 solver tests passed in WASI. 4212 Horner' in (d/f'logs/solver-head-{v}.log').read_text()
assert (d/'logs/primary-trace').read_bytes()==(d/'logs/borrowed-trace').read_bytes()
assert (d/'logs/primary-trace').read_bytes()==(d/'logs/caller-trace').read_bytes()
assert (d/'all-budget-review.json').is_file() and (d/'downstream-review.json').is_file()
assert (d/'source-revision').read_text().strip()==git(r,'rev-parse','HEAD').decode().strip()
sha={k:h(v) for k,v in sorted(files.items())}
dest=d/'record';dest.mkdir(exist_ok=True)
with tarfile.open(dest/'observations.tar.xz','w:xz') as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(dest/'observations.tar.xz','r|xz') as t:assert {m.name:h(t.extractfile(m).read()) for m in t}==sha
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(sha,indent=1).encode()))
total=sum(p.stat().st_size for p in dest.iterdir())
assert shutil.disk_usage(e).free-(e/'.git/index').stat().st_size-3*total-1048576>20*1024**3
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(dest,e/record);git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive univariate proof-policy and algebraic-root replay measurements')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in dest.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOTS={record:False};row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
print(rev,row,'members',len(sha))
