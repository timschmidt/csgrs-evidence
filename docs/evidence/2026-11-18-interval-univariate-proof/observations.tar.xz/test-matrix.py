from pathlib import Path
import json,os,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent
root=Path('/mnt/development/csgrs')
tag=sys.argv[1];work=root if tag=='head' else s/'src'
suites=['krawczyk_univariate_algebraic'] if tag=='head' else ['krawczyk_univariate_algebraic','krawczyk_univariate_certainty','krawczyk_multivariate_certainty','krawczyk_affine_oracle','krawczyk_affine_residuals','krawczyk_certificates']
def run(job):
 v,target=job
 env=os.environ|{'CARGO_TARGET_DIR':str(s/f'matrix-{target}-{v}'),'CARGO_BUILD_JOBS':'4'}
 args=['cargo','+'+v,'test','--release','--locked','-p','hypersolve','--all-features',*[x for case in suites for x in ('--test',case)],'--target',target,'--no-run','--message-format=json-render-diagnostics']
 prefix=s/'logs'/f'{tag}-{v}-{target}'
 with Path(str(prefix)+'.build-log').open('w') as err:
    rows=subprocess.check_output(args,cwd=work,env=env,stderr=err,text=True)
 seen=set()
 for row in map(json.loads,rows.splitlines()):
    p=row.get('executable')
    if not p:continue
    case=row['target']['name'];assert case in suites and case not in seen;seen.add(case)
    cmd=[p] if not target.startswith('wasm') else ['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',str(root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),p]
    with (s/'logs'/f'{tag}-{v}-{target}-{case}.log').open('w') as log:
        subprocess.run([*cmd,'--test-threads=1'],cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    assert Path(p).stat().st_size<48*2**20
    print(tag,v,target,case,Path(p).stat().st_size,flush=True)
 assert seen==set(suites)
with ThreadPoolExecutor(4) as pool:list(pool.map(run,[(v,t) for v in ('1.95.0','stable') for t in ('wasm32-wasip1','x86_64-unknown-linux-gnu')]))
