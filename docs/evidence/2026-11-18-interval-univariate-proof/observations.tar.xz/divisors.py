from pathlib import Path
s=Path(__file__).resolve().parent
p=s/'src/crates/hypersolve/src/interval.rs'
x=(s/'row.rs').read_text()
start=x.index('fn classify_quadratic_krawczyk_row(')
end=x.index('fn classify_quadratic_krawczyk_row_policy_fallback',start)
segment=x[start:end]
for a,b in [('(-residual.clone() / derivative.clone())','(-residual.clone() / &derivative)'),('let contraction_denominator = derivative_abs.clone();','let contraction_denominator = derivative_abs;'),('radius.clone() / derivative_abs','radius.clone() / &contraction_denominator')]:
 assert segment.count(a)==1
 segment=segment.replace(a,b)
p.write_text(x[:start]+segment+x[end:])
