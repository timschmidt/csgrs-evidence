set -eu
s=/dev/shm/interval-univariate-proof
for which in derivative magnitude; do
 python3 - "$which" <<'PY'
from pathlib import Path
import sys
s=Path('/dev/shm/interval-univariate-proof')
x=(s/'row.rs').read_text()
i=x.index('fn classify_quadratic_krawczyk_row(');j=x.index('fn classify_quadratic_krawczyk_row_policy_fallback',i)
p=x[i:j]
if sys.argv[1]=='derivative':
 p=p.replace('(-residual.clone() / derivative.clone())','(-residual.clone() / &derivative)')
else:
 p=p.replace('let contraction_denominator = derivative_abs.clone();','let contraction_denominator = derivative_abs;').replace('radius.clone() / derivative_abs','radius.clone() / &contraction_denominator')
assert p!=x[i:j]
(s/'src/crates/hypersolve/src/interval.rs').write_text(x[:i]+p+x[j:])
PY
 diff -u --label a/crates/hypersolve/src/interval.rs --label b/crates/hypersolve/src/interval.rs "$s/original.rs" "$s/src/crates/hypersolve/src/interval.rs" > "$s/$which.patch" || test "$?" -eq 1
 for t in native wasm; do taskset -c 0-3,7-13,17-23,27-33,37-39 bash "$s/build-clients.sh" "$which" "$t" > "$s/logs/$which-$t.log" 2>&1 & done
 taskset -c 0-3,7-13,17-23,27-33,37-39 bash "$s/owner.sh" "$which" > "$s/logs/$which-build.log" 2>&1 &
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
 python3 "$s/size-review.py" "$which" > "$s/$which-size.log"
done
