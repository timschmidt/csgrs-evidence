set -eu
s=/dev/shm/interval-univariate-proof
v=$1
SUCCESSIVE_OPERATIONS_RAW="$s/logs/$v-successive.tsv" taskset -c 18 "$s/images/$v-successive" '((A-B)-C)+D feedback' > "$s/logs/$v-chain.log" 2>&1
