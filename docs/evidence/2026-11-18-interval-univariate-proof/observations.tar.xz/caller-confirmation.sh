set -eu
s=/dev/shm/interval-univariate-proof
i=0
for v in primary caller caller primary caller primary primary caller;do
 i=$((i+1))
 if test "$v" = primary;then other=caller;else other=primary;fi
 for pair in '5 uni' '15 uni'; do
   read -r cpu kind <<< "$pair"
   case "$cpu" in 5|6) impl=$v;; *) impl=$other;; esac
   case "$kind" in uni) needle='certify_univariate_quadratic_krawczyk_rows$';; multi) needle='certify_multivariate_quadratic_krawczyk_square/1$';; esac
   CRITERION_HOME="$s/caller-confirmation/$cpu/$i-$impl" setarch "$(uname -m)" -R taskset -c "$cpu" "$s/images/$impl-certification" --bench --noplot --warm-up-time 1 --measurement-time 5 --sample-size 50 "$needle" > "$s/logs/caller-confirmation-$cpu-$i-$impl" 2>&1 &
 done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
