set -eu
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-univariate-proof
mkdir "$s/downstream-src"
git -C /mnt/development/csgrs archive 20504d9b4 | tar -xm -C "$s/downstream-src"
cd "$s/downstream-src"
export CARGO_TARGET_DIR="$s/downstream-target" CARGO_BUILD_JOBS=6
for v in primary caller; do
 if test "$v" = caller;then git apply "$s/caller.patch";fi
 cargo +1.95.0 build --locked --release -p csgrs --bench successive_operations --no-default-features --features curve,stl-io,obj-io --message-format=json > "$s/logs/$v-successive.jsonl"
 python3 - "$v" <<'PY'
import json,shutil,sys
from pathlib import Path
s=Path('/dev/shm/interval-univariate-proof');v=sys.argv[1]
p=next(x['executable'] for x in map(json.loads,(s/f'logs/{v}-successive.jsonl').read_text().splitlines()) if x.get('executable') and x['target']['name']=='successive_operations')
shutil.copy(p,s/'images'/f'{v}-successive')
PY
done
