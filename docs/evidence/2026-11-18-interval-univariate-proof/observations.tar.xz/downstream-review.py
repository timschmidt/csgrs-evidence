import csv, hashlib, json, sys
from pathlib import Path
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root/'history'))
from image_metrics import sizes
def read_chain(stage, matched=False):
    lines = (root/'logs'/f'{stage}{"-matched" if matched else ""}-successive.tsv').read_text().splitlines()
    assert lines[-1] == '# completed'
    rows = list(csv.DictReader((line for line in lines if not line.startswith('#')), delimiter='\t'))
    assert len(rows) == 6
    assert all(row['outcome']=='certified' and row['manifold']=='yes' for row in rows)
    return rows
p,c = map(read_chain, ('primary','caller'))
complete = [k for k in p[0] if k not in ('step_ns','validation_ns','drop_ns')]
changed = {k:[[a[k],b[k]] for a,b in zip(p,c) if a[k]!=b[k]] for k in complete}
out={'semantic_and_allocation_differences':{k:v for k,v in changed.items() if v}}
p,c = [read_chain(s,True) for s in ('primary','caller')]
out['matched_path_differences']={k:[[a[k],b[k]] for a,b in zip(p,c) if a[k]!=b[k]] for k in complete if any(a[k]!=b[k] for a,b in zip(p,c))}
assert not out['matched_path_differences']
out['images']={}
for name in ('primary','caller'):
    binary=root/'images'/f'{name}-successive'
    out['images'][name]=dict(sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),metrics=sizes(binary))
a,b=[x['metrics'] for x in out['images'].values()]
out['metric_deltas']={k:b.get(k,0)-a.get(k,0) for k in sorted(set(a)|set(b)) if a.get(k,0)!=b.get(k,0)}
(root/'downstream-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(out['semantic_and_allocation_differences'],out['metric_deltas'])
