set -eu
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-univariate-proof
b=/dev/shm/interval-box-coverage
test ! -e "$b/wasm-repo"
mkdir "$b/wasm-repo"
git -C /mnt/development/csgrs archive 20504d9b4 | tar -xm -C "$b/wasm-repo"
export CARGO_TARGET_DIR="$b/lifetime-target" CARGO_BUILD_JOBS=6
for v in primary entry borrowed; do
 if test "$v" != primary;then cp "$s/$v.rs" "$b/wasm-repo/crates/hypersolve/src/interval.rs";fi
 for spec in 'lifetime radius-lifetime' 'usable radius-usable'; do
  read -r dir bin <<< "$spec"
  cargo +1.95.0 build --release --locked --manifest-path "$b/$dir/Cargo.toml"
  cp "$CARGO_TARGET_DIR/release/$bin" "$s/images/reference-$v-$dir"
 done
done
# Restore the source control for subsequent inspections and avoid stale candidate state.
cp "$s/original.rs" "$b/wasm-repo/crates/hypersolve/src/interval.rs"
