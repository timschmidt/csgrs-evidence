from pathlib import Path
import subprocess as sp,os,re,hashlib,json,sys
s=Path(__file__).parent
v=sys.argv[1]
d=s/('native-'+v)
d.mkdir(exist_ok=True)
scalar_dir=Path('/dev/shm/interval-scalar-wasi')/('final-'+v)/'target/release/deps'
scalar_binary,=[p for p in scalar_dir.glob('rational-*') if p.is_file() and p.suffix=='']
solver_binary,=[p for p in (s/('t-'+v)/'release/deps').glob('hypersolve-*') if p.is_file() and p.suffix=='']
suites=[(scalar_binary,'product_dispatch_and_reducer_counts_match_baseline','HYPERINTERVAL_TRACE_BACKEND','TRACE',450),(solver_binary,'algebraic::interval_migration::rational_horner_dispatch_differential','HYPERSOLVE_HORNER_BACKEND','HORNER',1404),(solver_binary,'root_isolation::interval_migration::rational_horner_exclusion_dispatch_differential','HYPERSOLVE_HORNER_BACKEND','HORNER',2808)]
def rows(path,case):
    return [x for line in path.read_text().splitlines() if (x:=line.removeprefix(f'test {case} ... ')).startswith(('TRACE TraceSnapshot ','HORNER TraceSnapshot '))]
summary={}
for binary,case,key,marker,count in suites:
  for mode in ('legacy','shared'):
    log=d/f'{case}-{mode}.log'
    with log.open('w') as w:
        sp.run([str(binary),'--exact',case,'--test-threads=1','--nocapture'],stdout=w,stderr=sp.STDOUT,env=os.environ|{key:mode},check=True)
    guest=(s/f'scalar-{v}-{mode}.log') if marker=='TRACE' else (s/f'final-horner-{v}'/f'{case}-{mode}.log')
    a=rows(log,case);b=rows(guest,case)
    assert len(a)==len(b)==count
    diff=[i+1 for i,(left,right) in enumerate(zip(a,b)) if left!=right]
    h=lambda xs:hashlib.sha256(('\n'.join(xs)+'\n').encode()).hexdigest()
    summary[f'{case}/{mode}']={'count':count,'native':h(a),'guest':h(b),'differing_windows':len(diff),'first':diff[:1]}
(d/'comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
