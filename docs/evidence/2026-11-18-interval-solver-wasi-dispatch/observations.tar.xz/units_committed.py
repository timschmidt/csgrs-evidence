from pathlib import Path
import concurrent.futures as futures, subprocess as sp, re, json, sys, time
s=Path(__file__).parent
r=Path('/mnt/development/csgrs')
runner=r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'
v=sys.argv[1]
d=s/('retained-units-'+v)
d.mkdir()
binary=next(j['executable'] for j in map(json.loads,(s/f'committed-{v}.jsonl').open()) if j.get('executable') and j['target']['name']=='hypersolve')
base=['node',str(runner),str(binary)]
suite=sp.check_output([*base,'--list'],text=True,stderr=sp.DEVNULL)
names=re.findall(r'^(.*): test$',suite,re.M)
assert len(set(names))==len(names)==627
(d/'inventory').write_text(suite)
def run(item):
    ix,case=item
    start=time.monotonic()
    with (d/f'{ix:03}.log').open('w') as log:
        try: status=sp.run([*base,'--exact',case,'--nocapture','--test-threads=1'],cwd=r,stdout=log,stderr=sp.STDOUT,timeout=180).returncode
        except sp.TimeoutExpired: status='timeout'
    result=(d/f'{ix:03}.log').read_text()
    ok=status==0 and f'test {case} ... ' in result and 'test result: ok. 1 passed; 0 failed; 0 ignored;' in result
    return ix, dict(name=case,passed=ok,status=status,seconds=round(time.monotonic()-start,3),log=f'{ix:03}.log')
with futures.ThreadPoolExecutor(max_workers=6) as pool:
    rows=dict(pool.map(run,enumerate(names)))
report=[rows[i] for i in range(len(names))]
(d/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(v,len(rows),sum(row['passed'] for row in report),'passed',flush=True)
for row in report:
    if not row['passed']: print(row['name'],row['status'],row['log'])
