from pathlib import Path
import concurrent.futures as futures, subprocess as sp, re, json, sys, time
s=Path(__file__).parent
r=Path('/mnt/development/csgrs')
runner=r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'
v=sys.argv[1]
d=s/('retained-integrations-'+v)
d.mkdir()
binaries={j['target']['name']:j['executable'] for j in map(json.loads,(s/f'committed-{v}.jsonl').open()) if j.get('executable')}
binaries.pop('hypersolve')
cases=[]
for target,binary in sorted(binaries.items()):
    listing=sp.check_output(['node',str(runner),binary,'--list'],text=True,stderr=sp.DEVNULL)
    (d/f'{target}.list').write_text(listing)
    for k,case in enumerate(re.findall(r'^(.*): test$',listing,re.M)):
        cases.append((target,k,binary,case))
def run(item):
    target,k,binary,case=item
    name=f'{target}-{k:03}.log'
    with (d/name).open('w') as log:
        try: status=sp.run(['node',str(runner),binary,'--exact',case,'--nocapture','--test-threads=1'],cwd=r,stdout=log,stderr=sp.STDOUT,timeout=180).returncode
        except sp.TimeoutExpired: status='timeout'
    result=(d/name).read_text()
    ok=status==0 and f'test {case} ... ' in result and 'test result: ok. 1 passed; 0 failed; 0 ignored;' in result
    return dict(target=target,name=case,passed=ok,status=status,log=name)
with futures.ThreadPoolExecutor(max_workers=8) as pool: report=list(pool.map(run,cases))
(d/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(v,len(binaries),'binaries',len(report),sum(row['passed'] for row in report),'passed')
for row in report:
    if not row['passed']: print(row['target'],row['name'],row['status'],row['log'])
