from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence';record='docs/evidence/2026-11-18-interval-solver-wasi-dispatch'
def git(repo,*args):return sp.check_output(['git','-C',repo,*args])
files={}
def add(p):files[str(p.relative_to(s))]=p.read_bytes()
for p in s.iterdir():
 if not p.is_file():continue
 if p.name in ('scope','source-revision') or p.suffix in ('.log','.py','.txt','.patch','.sh','.diff','.list','.json'):
    if p.name=='consumer-graph.json':continue
    add(p)
 if p.name.startswith('client-') and p.suffix=='.bin':
    files[p.name+'.sha256']=hashlib.sha256(p.read_bytes()).hexdigest().encode()
for stem in ['final-solver','retained-units','retained-integrations','scalar-admit','counter-control','horner']:
 for d in s.glob(stem+'-*') if stem!='counter-control' else [s/stem]:
    if not d.is_dir():continue
    for p in d.iterdir():
        if p.is_file() and (p.suffix in ('.log','.json','.list','.txt') or p.name=='inventory'):add(p)
for p in [s/'consumer/Cargo.toml',s/'consumer/Cargo.lock']:add(p)
for p in [s/'solver-1.95.jsonl']:
 rows=[j['message']['rendered'] for j in map(json.loads,p.read_text().splitlines()) if j.get('reason')=='compiler-message']
 files['baseline-compiler-diagnostic.txt']='\n'.join(rows).encode()
assert 'Verified native' in files['verified.log'].decode() and 'No findings to report' in files['zizmor-final.log'].decode()
assert files['source-revision'].decode().strip()==git(r,'rev-parse','HEAD').decode().strip()
h=lambda b:hashlib.sha256(b).hexdigest()
digests={k:h(v) for k,v in sorted(files.items())}
archive=s/'record';archive.mkdir(exist_ok=True)
with tarfile.open(archive/'observations.tar.xz','w:xz') as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(archive/'observations.tar.xz','r|xz') as t: assert {m.name:h(t.extractfile(m).read()) for m in t}==digests
(archive/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(digests,indent=2).encode()))
assert json.loads(lzma.decompress((archive/'sha256.json.xz').read_bytes()))==digests
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(e).free-3*size-1024**2>=20*1024**3,(size,shutil.disk_usage(e).free)
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(archive,e/record)
git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive paired solver WASI dispatch, test inventories and artifact measurements')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
(s/'evidence-revision').write_text(rev+'\n')
print(rev,row)
