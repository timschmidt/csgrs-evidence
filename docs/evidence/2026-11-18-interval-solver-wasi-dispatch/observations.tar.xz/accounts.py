from pathlib import Path
import json,hashlib
s=Path(__file__).parent
d=Path('/mnt/development/csgrs')
def uleb(data,i):
 n=0
 for shift in range(0,35,7):
    b=data[i];i+=1;n|=(b&127)<<shift
    if b<128:return n,i
 raise ValueError('invalid Wasm section length')
def wasm(p):
 data=p.read_bytes();assert data[:8]==b'\0asm\x01\0\0\0'
 i=8;code=None
 while i<len(data):
    kind=data[i];size,start=uleb(data,i+1)
    if kind==10:
        assert code is None;code=size
    i=start+size
 assert i==len(data) and code and len(data)<48*1024**2
 return dict(file_bytes=len(data),code_section_bytes=code,headroom_bytes=64*1024**2-len(data),sha256=hashlib.sha256(data).hexdigest())
guests={}
for v in ['1.95.0','stable']:
 rows=[r for r in map(json.loads,(s/f'committed-{v}.jsonl').open()) if r.get('executable')]
 assert len(rows)==69
 guests[v]={j['target']['name']:wasm(Path(j['executable'])) for j in rows}
(s/'wasm-image-accounts.json').write_text(json.dumps(guests,sort_keys=True,indent=2)+'\n')
measure=json.loads((s/'matched-measurements.json').read_text())
assert len(measure)==8 and all(not v['failed'] for v in measure.values())
rev=(s/'source-revision').read_text().strip()
record='docs/evidence/2026-11-18-interval-solver-wasi-dispatch'
row={'benefit':"Qualifies the solver's original interval suites, width-dependent tensor capacity failures and full native/WASI dispatch differentials with a fixed heap-backed polynomial matrix fixture.",
'evidence':record,'source_snapshot':rev,'baseline':'c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb','preceding':'6f0815cfb',
'production_change':False,'target':'x86_64-unknown-linux-gnu, locked release. Rust 1.95.0 and 1.99.0 (stable). Each artifact, toolchain, and feature selection is accounted separately.',
'caps':{'incremental_bytes':4096,'incremental_percent':1,'cumulative_bytes':8192,'cumulative_percent':2,'file_slot_bytes':67108864,'required_free_bytes':16777216},
'metrics':'Final file size, union of defined ELF function ranges, and every allocated ELF section. No allocated section or function union grew versus the preceding revision. Raw values and all positive historical charges remain in matched-measurements.json in the evidence archive.',
'cumulative_rule':'Charge positive steps separately against the fixed baseline. Preserve prior increases even after a decrease. Previously over-cap metrics receive no new charge. The stable all-feature tensor file had already grown by 11704 bytes and its RELRO padding by 1672 bytes before this change. Neither increased here.',
'columns':['executable','Rust','features','fixed_file','previous_file','retained_file','incremental_file_charge','cumulative_file_charge','remaining_incremental_cap_bytes','remaining_cumulative_cap_bytes','slot_headroom_bytes'],
'native_files':[]}
for key,x in measure.items():
 name,v,flags=key.split('-')
 m=x['measurements'];a,b,c=[m[k]['file'] for k in ('fixed','previous','candidate')]
 charge=max(0,c-b);acc=max(b-a,0)+charge
 row['native_files'].append(['hypersolve library tests' if name=='matrix' else 'trivariate_arithmetic',v,'dispatch-trace' if flags=='trace' else 'all',a,b,c,charge,acc,max(0,min(4096,b//100)-charge),max(0,min(8192,a*2//100)-acc),64*1024**2-c])
row['new_guest_images']={'target':'wasm32-wasip1, release, hypersolve --all-features','scope':'New hosted test command images. Each has a 64 MiB file slot with 16 MiB reserved; no earlier image on this target qualified for comparison. The archive contains every image name, CODE-section size, file size, SHA-256 and headroom in wasm-image-accounts.json.','counts':{v:len(t) for v,t in guests.items()},'minimum_headroom_bytes':{v:min(r['headroom_bytes'] for r in t.values()) for v,t in guests.items()}}
p=d/'docs/research/interval-size-accounts.json'
old=p.read_text()
assert 'solver_wasi_dispatch' not in old
doc=json.loads(old)
assert old.rstrip().endswith('}')
section=json.dumps(row,indent=2).splitlines()
p.write_text(old.rstrip()[:-1].rstrip()+',\n  "solver_wasi_dispatch": '+section[0]+'\n'+'\n'.join('  '+t for t in section[1:])+'\n}\n')
loaded=json.loads(p.read_text());assert loaded.pop('solver_wasi_dispatch')==row and loaded==doc
print('Verified eight linked native test accounts and 138 WASI test images; retained previous account values.')
