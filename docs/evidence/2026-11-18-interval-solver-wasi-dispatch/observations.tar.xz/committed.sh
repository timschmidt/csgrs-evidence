set -eu
v=$1
. /dev/shm/interval-lattice-coverage/env
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup
d=/dev/shm/interval-wasi-dispatch
export CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR="$d/t-$v"
cd /mnt/development/csgrs/crates/hypersolve
python3 ../hyperinterval/conformance/wasi-solver.py --toolchain "$v" --output "$d/final-solver-$v" > "$d/final-solver-$v.log" 2>&1
cargo +"$v" test --locked --release --all-features -p hypersolve --tests --lib > "$d/committed-host-$v.log" 2>&1
cargo +"$v" test --locked --release --all-features -p hypersolve --tests --lib --target wasm32-wasip1 --no-run --message-format=json-render-diagnostics > "$d/committed-$v.jsonl" 2>"$d/committed-guest-$v.log"
python3 "$d/units_committed.py" "$v" > "$d/retained-units-$v.log"
python3 "$d/integrations_committed.py" "$v" > "$d/retained-integrations-$v.log"
