from pathlib import Path
import re,sys,subprocess,json,hashlib
s=Path(__file__).parent
def measure(p):
    def run(*cmd):return subprocess.check_output([*cmd,p],text=True)
    sections={}
    for line in run('readelf','-SW').splitlines():
        m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',line)
        if m and 'A' in m[3]:sections[m[1]]=int(m[2],16)
    regs=[]
    for line in run('readelf','-Ws').splitlines():
        r=line.split()
        if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit():
            start=int(r[1],16);regs.append((start,start+int(r[2])))
    hi=n=0
    for start,end in sorted(regs):
        n+=max(0,end-max(start,hi));hi=max(hi,end)
    return {**sections,'file':p.stat().st_size,'functions':n}

result={}
for target in ['matrix','tensor']:
 for compiler in ['1.95.0','stable']:
  for config in ['trace','all']:
   name=f'{target}-{compiler}-{config}'
   ps=[s/f'{target}-{stage}-{compiler}-{config}.elf' for stage in ['fixed','preceding','slice']]
   if not all(p.exists() for p in ps):continue
   a,b,c=map(measure,ps)
   counts={}
   failed=[]
   for metric,x in c.items():
    prior=max(0,b[metric]-a[metric])
    change=max(0,x-b[metric]);total=prior+change
    if not change and not prior:continue
    counts[metric]=dict(fixed=a[metric],previous=b[metric],candidate=x,prior_growth=prior,incremental=change,cumulative=total)
    if change and (change>4096 or 100*change>b[metric] or total>8192 or 100*total>2*a[metric]):failed.append(metric)
   assert c['file']+16*1024**2 < 64*1024**2
   result[name]=dict(measurements=dict(fixed=a,previous=b,candidate=c),charged=counts,failed=failed,digests=[hashlib.sha256(p.read_bytes()).hexdigest() for p in ps])
   print(name,'failed',failed,'file',b['file'],c['file'])
(s/'matched-measurements.json').write_text(json.dumps(result,indent=2)+'\n')
