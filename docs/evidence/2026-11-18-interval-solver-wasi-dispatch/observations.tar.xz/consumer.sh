set -eu
d=/dev/shm/interval-wasi-dispatch
root=/mnt/development/csgrs
. /dev/shm/interval-lattice-coverage/env
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_TARGET_DIR="$d/consumer-target" CARGO_BUILD_JOBS=6
cd "$d/consumer"
cargo +1.95.0 metadata --format-version=1 --offline > "$d/consumer-graph.json" 2>"$d/consumer-graph.log"
for stage in before after
do
if test "$stage" = after
then
cp "$root/crates/hypersolve/Cargo.toml" "$d/mutant/crates/hypersolve/Cargo.toml"
cp "$root/crates/hypersolve/src/curve_resultant.rs" "$d/mutant/crates/hypersolve/src/curve_resultant.rs"
fi
for target in x86_64-unknown-linux-gnu wasm32-wasip1
do
cargo +1.95.0 build --locked --release --target "$target" > "$d/consumer-$stage-$target.log" 2>&1
f="$CARGO_TARGET_DIR/$target/release/solver-wasi-consumer"
if test "$target" = wasm32-wasip1
then
f="$f.wasm"
node "$root/crates/hyperlattice-interval/conformance/run-wasi-test.mjs" "$f" >"$d/client-$stage-$target.txt" 2>"$d/client-$stage-$target.stderr"
else
"$f" > "$d/client-$stage-$target.txt"
fi
cp "$f" "$d/client-$stage-$target.bin"
done
done
for target in x86_64-unknown-linux-gnu wasm32-wasip1
do
cmp "$d/client-before-$target.bin" "$d/client-after-$target.bin"
cmp "$d/client-before-$target.txt" "$d/client-after-$target.txt"
done
cmp "$d/client-after-wasm32-wasip1.txt" "$d/client-after-x86_64-unknown-linux-gnu.txt"
sha256sum "$d"/client-*.bin
