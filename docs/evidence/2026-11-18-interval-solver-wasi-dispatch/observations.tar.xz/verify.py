from pathlib import Path
import collections,hashlib,json,re,subprocess as sp
s=Path(__file__).parent
h=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
out={}
for v in ['1.95.0','stable']:
    solver=load(s/f'final-solver-{v}/report.json')
    scalar=load(s/f'scalar-admit-{v}/report.json')
    assert sum(map(len,solver['guest'].values()))==63
    assert sorted(solver['dispatch_windows'].values())==[1404,2808]
    assert sum(map(len,scalar['guest'].values()))==228 and len(scalar['host_required'])==9
    assert scalar['guest_dispatch']=={'rational':450}
    unit=load(s/f'retained-units-{v}/report.json')
    integrations=load(s/f'retained-integrations-{v}/report.json')
    assert (len(unit),sum(j['passed'] for j in unit))==(627,622)
    assert (len(integrations),sum(j['passed'] for j in integrations))==(904,887)
    assert all(j['status'] in (0,1) for j in unit+integrations)
    host=(s/f'committed-host-{v}.log').read_text()
    sections=re.split(r'^\s*Running (.+?) \(.+?\)\s*$',host,flags=re.M)
    native={}
    for target,log in zip(sections[1::2],sections[2::2]):
        name='hypersolve' if target=='unittests src/lib.rs' else Path(target.split('/')[-1]).stem
        assert name not in native
        tests=set(re.findall(r'^test (\S+) \.\.\. ok$',log,re.M))
        # A fresh native process can print a separate result for its exact case.
        assert not re.search(r'^test result: FAILED|^error:',log,re.M)
        native[name]=tests
    assert all(j['name'] in native['hypersolve'] for j in unit)
    assert all(j['name'] in native[j['target']] for j in integrations)
    traces={}
    for path,count,key in [(s/f'scalar-admit-{v}',450,'product_dispatch'),(s/f'final-solver-{v}',1404,'algebraic.interval_migration.rational_horner_dispatch'),(s/f'final-solver-{v}',2808,'root_isolation.interval_migration.rational_horner_exclusion_dispatch')]:
        logs=sorted(path.glob(key+'*-*.log'))
        assert len(logs)==4,logs
        sums=[]
        for log in logs:
            data=[]
            for l in log.read_text().splitlines():
                if l.startswith('test '): l=l.split(' ... ',1)[-1]
                if l.startswith(('TRACE TraceSnapshot ','HORNER TraceSnapshot ')):data.append(l)
            assert len(data)==count
            sums.append(h(('\n'.join(data)+'\n').encode()))
        assert len(set(sums))==1
        traces[key]={'windows':count,'ordered_rows_sha256':sums[0]}
    out[v]={'direct_unit':622,'available_unit':627,'direct_integration':887,'available_integration':904,'integration_executables':len(set(j['target'] for j in integrations)), 'native_names':sum(map(len,native.values())),'traces':traces,
            'os_required':[j['name'] for j in unit+integrations if not j['passed']]}
assert load(s/'scalar-admit-1.88.0/report.json')['host_required'] and sum(map(len,load(s/'scalar-admit-1.88.0/report.json')['guest'].values()))==178
for target in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
    b=(s/f'client-before-{target}.bin').read_bytes()
    assert b==(s/f'client-after-{target}.bin').read_bytes()
    assert (s/f'client-before-{target}.txt').read_bytes()==(s/f'client-after-{target}.txt').read_bytes()
    out[target]={'krawczyk_client_bytes':len(b),'sha256':h(b)}
assert 'row 1 differs' in (s/'counter-control/rejection.txt').read_text()
assert 'No findings to report' in (s/'zizmor-final.log').read_text()
(s/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified native counterparts for every inventoried guest, exact counts, four complete trace streams per comparison, changed-counter rejection, and byte-identical linked Krawczyk controls.')
