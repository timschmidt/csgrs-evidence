from pathlib import Path
import concurrent.futures as futures, subprocess as sp,os,sys,json,shutil
d=Path(__file__).parent; w=d/'mutant'
def git(*cmd):sp.run(['git','-C',str(w),*cmd],check=True)
def measure(item):
 stage,v,config=item
 args=['cargo','+'+v,'test','--locked','--release','-p','hypersolve','--test','trivariate_arithmetic','--no-run','--message-format=json-render-diagnostics']
 args+=['--features','dispatch-trace'] if config=='trace' else ['--all-features']
 t=d/f'matched-{v}-{config}'
 env=os.environ|{'CARGO_TARGET_DIR':str(t),'CARGO_BUILD_JOBS':'6'}
 stem=f'{stage}-{v}-{config}'
 with (d/f'tensor-{stem}.log').open('w') as log:
    out=sp.check_output(args,text=True,stderr=log,env=env,cwd=w)
 binary=next(j['executable'] for j in map(json.loads,out.splitlines()) if j.get('executable'))
 shutil.copyfile(binary,d/f'tensor-{stem}.elf')
for stage in sys.argv[1:] or ('fixed','preceding','slice'):
 if stage in ('fixed','preceding'): git('switch','--quiet','--detach',{'fixed':'c9f1f9ac5','preceding':'6f0815cfb'}[stage])
 else:
    for p in ['crates/hypersolve/Cargo.toml','crates/hypersolve/src/curve_resultant.rs','crates/hypersolve/tests/trivariate_arithmetic.rs']:
        src=Path('/mnt/development/csgrs')/p
        if src.read_bytes()!=(w/p).read_bytes():shutil.copyfile(src,w/p)
 with futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(measure,[(stage,v,c) for v in ['1.95.0','stable'] for c in ['trace','all']]))
