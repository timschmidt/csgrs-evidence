# Validate the byte-identical integration in a fresh root-volume target.
import gzip,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');W=Path(__file__).resolve().parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import GIT,dump,run,sha,reasons,resources
assert json.loads((V/'resume-integration-execution-v1/result-v1.json').read_text())['complete']
T=N/'targets/integration-v1';assert T.is_dir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
names=subprocess.check_output(GIT+['ls-files','-z'],cwd=O).decode().split('\0')[:-1]
names=[p for p in names if not p.startswith(('docs/evidence/','crates/comparisons/'))]
pins={p:sha(O/p) for p in names}
inventory=N/'integration-source-v1.json.gz'
assert json.loads(gzip.decompress(inventory.read_bytes()))==pins
commands=[('fmt',[cargo,'fmt','--all','--','--check']),
    ('readme-default',[cargo,'test','--locked','-p','hyperreal','--test','readme_metadata','--','--test-threads=1']),
    ('readme-all',[cargo,'test','--locked','-p','hyperreal','--all-features','--test','readme_metadata','--','--test-threads=1']),
    ('quickstart',[cargo,'run','--locked','-p','hyperreal','--example','readme_quickstart'])]
def verify():
    assert not reasons(resources())
    assert all(sha(O/p)==h for p,h in pins.items())
    assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()=='9abc309af48acad10369bfe9fb9a82d39cc9fceb'
verify()
dump(N/'integration-protocol-v2.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'runner_sha256':sha(N/'control/validation_runner_v3.py'),'initial_state_sha256':sha(N/'control/initial-state-v1.json'),
    'source_files':len(pins),'source_inventory_sha256':sha(inventory),'source_lock_sha256':sha(O/'Cargo.lock'),
    'target':str(T),'target_initially_absent':False,'same_source_target_continuation':True,'commands':commands,'compiler_sha256':compiler['tool_sha256'],
    'new_implementation_admission':False,'hypervoxel_deferred_by_user':True})
results=json.loads((N/'integration-progress-v1.json').read_text());counts={}
assert set(results)=={'fmt','readme-default'}
for label, result in results.items():
    assert result['exit_code']==0 and not result['stops']
    folder=N/'logs'/('integration-'+label+'-v1')
    assert all(sha(folder/name)==digest for name,digest in result['output_sha256'].items())
stdout=(N/'logs/integration-readme-default-v1/stdout').read_text()
assert re.findall(r'^test (\w+) \.\.\. ok$',stdout,re.M)==['gmp_binding_remains_a_development_only_dependency','readme_version_matches_crate_version']
assert re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',stdout,re.M)==['2']
counts['readme-default']=2
dump(N/'integration-helper-correction-v1.json',{'v1_helper_sha256':sha(W/'validate_integration_v1.py'),
    'v1_complete':False,'stop_reason':'helper assertion expected four tests but this test target declares and passes two',
    'source_test_file_sha256':sha(O/'crates/hyperreal/tests/readme_metadata.rs'),
    'unchanged_source_test_names':['gmp_binding_remains_a_development_only_dependency','readme_version_matches_crate_version'],
    'completed_commands_preserved':list(results),'remaining_commands':['readme-all','quickstart'],
    'test_or_source_changes':False,'correction_helper_sha256':sha(Path(__file__))})
for label,args in commands[2:]:
    verify();name='integration-'+label+'-v2'
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--bind',str(N),str(N),'--chdir',str(O)]
    for key,value in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),
        'TMPDIR':str(N/'scratch'/name),'XDG_CACHE_HOME':str(N/'xdg-cache'),
        'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',key,value]
    argv+=args
    result=run(name,argv,O,target=T);results[label]=result
    dump(N/'integration-progress-v2.json',results)
    stdout=(N/'logs'/name/'stdout').read_text();stderr=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking|Verifying|Packaging) hypervoxel\b',stderr)
    if label.startswith('readme'):
        rows=re.findall(r'^test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',stdout,re.M)
        assert rows==['2'],rows;counts[label]=2
    verify()
dump(N/'integration-result-v2.json',{'complete_for_declared_scope':True,'commands':results,'readme_passes':sum(counts.values()),
    'format_passed':True,'quickstart_passed':True,'source_unchanged':True,'fresh_target_used':True,
    'new_implementation_admission':False,'cache_index_admitted':False,'exact_ingress_admitted':False,
    'hypervoxel_deferred_by_user':True,'full_plan_complete':False})
print(json.dumps({'format_passed':True,'readme_passes':sum(counts.values()),'quickstart_passed':True,
    'source_unchanged':True,'fresh_target_used':True}),flush=True)
