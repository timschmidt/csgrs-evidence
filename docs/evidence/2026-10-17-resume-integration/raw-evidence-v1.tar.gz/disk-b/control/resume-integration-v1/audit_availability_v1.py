# Read retained expectations and observe availability after the resumed boot.
import gzip,hashlib,json,os,stat,sys,time,shutil,subprocess
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
D=V/'paper-worktree-v1';W=Path(__file__).resolve().parent;A=V/'resume-availability-v1';A.mkdir()
sys.path.insert(0,str(O/'docs/evidence/2026-10-16-physical-build-requalification'))
from load_expectations_v1 import load

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
checkpoint=D/'docs/evidence/2026-10-17-native-cache-combination/checkpoint-v1.json';r=json.loads(checkpoint.read_text())
assert all(sha(D/p)==h for p,h in r['evidence_files_sha256'].items())
expected,prior_missing=load(D/r['artifact_expectations'],allow_unqualified=True)
assert len(expected)==1298910 and len(prior_missing)==27093
started=time.monotonic();unavailable={};other={};prefix_counts={};present=0
for n,(p,h) in enumerate(expected.items(),1):
    try:s=os.stat(p)
    except FileNotFoundError:unavailable[p]=h
    except OSError as e:other[p]={'errno':e.errno,'detail':str(e)}
    else:
        if stat.S_ISREG(s.st_mode):present+=1
        else:other[p]={'mode':s.st_mode,'detail':'expected a file'}
    if n%200000==0:print(json.dumps({'examined':n,'unavailable':len(unavailable),'other_errors':len(other)}),flush=True)
for p in unavailable:
    prefix='/tmp' if p.startswith('/tmp/') else '/dev/shm' if p.startswith('/dev/shm/') else str(V) if p.startswith(str(V)+'/') else str(O) if p.startswith(str(O)+'/') else 'other'
    prefix_counts[prefix]=prefix_counts.get(prefix,0)+1
manifest=json.loads(gzip.decompress((D/r['artifact_expectations']).read_bytes()))
latest=manifest['added_physical_artifacts_sha256'];assert len(latest)==22235
latest_missing=[];latest_mismatch=[]
for p,h in latest.items():
    if not Path(p).is_file():latest_missing.append(p)
    elif sha(p)!=h:latest_mismatch.append(p)
with gzip.open(A/'currently-unavailable-v1.json.gz','wt') as f:json.dump(unavailable,f,sort_keys=True)
new={p:h for p,h in unavailable.items() if p not in prior_missing}
with gzip.open(A/'newly-unavailable-v1.json.gz','wt') as f:json.dump(new,f,sort_keys=True)
dump(A/'other-errors-v1.json',other)
record={'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'checkpoint_sha256':sha(checkpoint),'expectation_manifest_sha256':sha(D/r['artifact_expectations']),
    'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'uptime':Path('/proc/uptime').read_text().strip(),
    'expected_paths':len(expected),'present_file_paths':present,'currently_unavailable_paths':len(unavailable),
    'prior_recorded_missing_paths':len(prior_missing),'newly_unavailable_paths':len(new),
    'prior_missing_now_present_unverified':len(set(prior_missing)-set(unavailable)-set(other)),
    'unavailable_by_prefix':prefix_counts,'other_path_errors':len(other),
    'current_missing_manifest_sha256':sha(A/'currently-unavailable-v1.json.gz'),
    'new_missing_manifest_sha256':sha(A/'newly-unavailable-v1.json.gz'),
    'latest_e62_paths_content_checked':len(latest),'latest_e62_missing':latest_missing,'latest_e62_mismatches':latest_mismatch,
    'all_history_content_audited':False,'complete_historical_preservation_claim':False,
    'elapsed_seconds':time.monotonic()-started,'root_free_bytes':shutil.disk_usage(O).free,'disk_b_free_bytes':shutil.disk_usage(V).free}
dump(A/'result-v1.json',record)
assert not other and not latest_missing and not latest_mismatch
print(json.dumps({k:record[k] for k in ['expected_paths','currently_unavailable_paths','newly_unavailable_paths','unavailable_by_prefix','latest_e62_paths_content_checked','elapsed_seconds']}),flush=True)
