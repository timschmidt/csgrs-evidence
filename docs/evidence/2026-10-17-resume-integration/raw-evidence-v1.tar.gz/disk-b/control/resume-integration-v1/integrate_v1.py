# Transfer only already verified commits and preserve the original untracked helper.
import hashlib,json,os,shutil,subprocess
from pathlib import Path
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');D=V/'paper-worktree-v1';W=Path(__file__).resolve().parent
A=V/'resume-integration-execution-v1';A.mkdir()
OLD='7ed43501755fd64a01f54c3078d12229cbc0129d';NEW='9abc309af48acad10369bfe9fb9a82d39cc9fceb'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_LFS_SKIP_SMUDGE='1')
def git(args,root=O):return subprocess.run(GIT+args,cwd=root,env=env,capture_output=True,check=True).stdout
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(path,value):Path(path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
audit=json.loads((V/'resume-availability-v1/result-v1.json').read_text())
assert not audit['latest_e62_missing'] and not audit['latest_e62_mismatches'] and not audit['other_path_errors']
assert git(['rev-parse','HEAD']).decode().strip()==OLD
assert git(['branch','--show-current']).decode().strip()=='main'
assert git(['rev-parse','HEAD'],D).decode().strip()==NEW and not git(['status','--porcelain=v1'],D)
assert not git(['diff','--name-only']) and not git(['diff','--cached','--name-only'])
untracked='docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py'
assert git(['status','--porcelain=v1','--untracked-files=all']).decode().splitlines()==['?? '+untracked]
assert sha(O/untracked)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
assert shutil.disk_usage(O).free>17*1024**3
names=git(['diff','--name-only','-z',OLD,NEW],D).decode().split('\0')[:-1]
assert len(names)==115
non_docs={p for p in names if not p.startswith('docs/')}
assert non_docs=={'Cargo.lock','crates/hyperreal/Cargo.toml','crates/hyperreal/README.md','crates/hyperreal/tests/readme_metadata.rs'}
pins={p:hashlib.sha256(git(['show',NEW+':'+p],D)).hexdigest() for p in names}
assert all(sha(D/p)==h for p,h in pins.items())
protocol={'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'original_head':OLD,
    'source_head':NEW,'original_branch':'main','source_worktree':str(D),'changed_files_sha256':pins,
    'preexisting_untracked':{untracked:sha(O/untracked)},'root_free_before':shutil.disk_usage(O).free,
    'disk_b_free_before':shutil.disk_usage(V).free,'hypervoxel_deferred_by_user':True,
    'new_implementation_admission':False,'cache_or_native_proposals_included':False,'push_planned':False}
dump(A/'protocol-v1.json',protocol)
commands={}
for label,args in [('fetch',['fetch','--no-tags','--no-recurse-submodules',str(D),'refs/heads/codex/properties-validation-20261017']),
                   ('fast-forward',['merge','--ff-only','--no-edit','--no-stat',NEW])]:
    if label=='fast-forward':
        assert git(['rev-parse','FETCH_HEAD']).decode().strip()==NEW
        assert git(['rev-parse','HEAD']).decode().strip()==OLD
        assert not git(['diff','--name-only']) and not git(['diff','--cached','--name-only'])
    result=subprocess.run(GIT+args,cwd=O,env=env,capture_output=True)
    (A/(label+'.stdout')).write_bytes(result.stdout);(A/(label+'.stderr')).write_bytes(result.stderr)
    commands[label]={'argv':GIT+args,'cwd':str(O),'exit_code':result.returncode,
        'stdout_sha256':sha(A/(label+'.stdout')),'stderr_sha256':sha(A/(label+'.stderr'))}
    dump(A/'commands-v1.json',commands);assert result.returncode==0,result.stderr.decode()
assert git(['rev-parse','HEAD']).decode().strip()==NEW
assert git(['rev-parse','HEAD^{tree}'])==git(['rev-parse','HEAD^{tree}'],D)
assert all(sha(O/p)==h for p,h in pins.items())
assert not git(['diff','--name-only']) and not git(['diff','--cached','--name-only'])
assert git(['status','--porcelain=v1','--untracked-files=all']).decode().splitlines()==['?? '+untracked]
assert sha(O/untracked)==protocol['preexisting_untracked'][untracked]
assert git(['rev-parse','HEAD'],D).decode().strip()==NEW and not git(['status','--porcelain=v1'],D)
dump(A/'result-v1.json',{'complete':True,'old_head':OLD,'new_head':NEW,'changed_files_verified':len(pins),
    'source_changes':sorted(non_docs),'tracked_worktree_clean':True,'preexisting_untracked_preserved':True,
    'isolated_source_worktree_unchanged':True,'root_free_after':shutil.disk_usage(O).free,
    'disk_b_free_after':shutil.disk_usage(V).free,'new_implementation_admission':False,'pushed':False})
print(json.dumps({'integrated_commit':NEW,'changed_files_verified':len(pins),'tracked_worktree_clean':True,
    'preexisting_untracked_preserved':True,'new_implementation_admission':False}),flush=True)
