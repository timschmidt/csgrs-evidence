set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
export CARGO_TARGET_DIR="$w/probe-target"
cd "$w/probe-interface"
stage=$1
for m in transcript outer; do
 python3 "$w/mutate.py" "$m"
 if cargo +stable test --locked -p alumina-interface-core --lib machine_profile::tests::shared_timer_minimum_is_driven_by_the_strict_participant_only -- --exact > "$w/logs/$stage-$m.log" 2>&1; then
  test "$stage" = before && rg -q '1 passed; 0 failed' "$w/logs/$stage-$m.log" || exit 1
 else
  test "$stage" = after && rg -q 'assertion .* failed' "$w/logs/$stage-$m.log" && rg -q '0 passed; 1 failed' "$w/logs/$stage-$m.log" || exit 1
 fi
done
