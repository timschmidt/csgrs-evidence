from pathlib import Path
import json,subprocess,sys
w=Path(__file__).parent
r=Path('/mnt/development/alumina-interface')
assert all(p.is_file() for p in (w/'sizes.json',w/'fixture-lifetimes.jsonl'))
z=json.loads((w/'sizes.json').read_text())
assert all('fixed' in v['stages'] for v in z.values())
good=not any(v['failed'] for v in z.values()) and json.loads((w/'layout-review.json').read_text())['fixed_matches_byte_for_byte']
entry=dict(native_size_caps_pass=good,failed={k:v['failed'] for k,v in z.items()},baseline='fdb7b153ca5042c15838651accccf4f89540ae2f',inventory=(w/'inventory-commit').read_text().strip(),core_release_tests_per_toolchain=199,preliminary_mixed_target_compile_attempt='Excluded. Negative controls completed in a separate clean target directory.',ownership='Phase 0 scanner and Phase 8 shared schedule evidence compatibility. No changes to production machine code.')
if good:
 p='crates/alumina-interface-core/src/machine_profile.rs'
 assert subprocess.check_output(['git','diff','--',p],cwd=r)==(w/'test.patch').read_bytes()
 subprocess.run(['git','add','--',p],cwd=r,check=True)
 subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
 subprocess.run(['git','-c','gc.auto=0','commit','-m','Pin the complete two-device shared retiming record'],cwd=r,check=True)
 entry['interface_commit']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
 (w/'interface-commit').write_text(entry['interface_commit']+'\n')
(w/'decision.json').write_text(json.dumps(entry,indent=2)+'\n')
print('fixed and incremental caps',good)
