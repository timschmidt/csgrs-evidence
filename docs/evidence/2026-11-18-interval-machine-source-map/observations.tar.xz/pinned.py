from pathlib import Path
import os,subprocess,time,random,json,statistics
w=Path(__file__).parent
core=sorted(os.sched_getaffinity(0))[12]
os.sched_setaffinity(0,{core})
rng=random.Random(77121)
out=[]
for v in ('1.95.0','stable'):
 for i in range(7):
  stages=['original','candidate']
  if i%2:stages.reverse()
  for stage in stages:
   start=time.monotonic_ns()
   p=subprocess.run([w/f'{stage}-{v}.bin','--exact','machine_profile::tests::shared_timer_minimum_is_driven_by_the_strict_participant_only'],cwd=w,capture_output=True,text=True,check=True)
   assert '1 passed; 0 failed' in p.stdout
   out.append(dict(compiler=v,stage=stage,round=i,cpu=core,seconds=(time.monotonic_ns()-start)/1e9))
(w/'pinned-times.json').write_text(json.dumps(out,indent=2)+'\n')
for v in ('1.95.0','stable'):
 print(v,{k:statistics.median(x['seconds'] for x in out if x['compiler']==v and x['stage']==k) for k in ('original','candidate')})
