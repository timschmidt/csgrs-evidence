set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
for v in 1.95.0 stable; do
 until test -e "$w/logs/candidate-$v.run" && rg -q '1 passed' "$w/logs/candidate-$v.run"; do sleep 2; done
done
for v in 1.95.0 stable; do
 (cd "$w" && "$w/candidate-$v.bin" --test-threads=8 > "$w/logs/full-$v.log" 2>&1) & 
 if test "$v" = stable; then second=$!; else first=$!; fi
done
wait "$first"
wait "$second"
for v in 1.95.0 stable; do
 for rep in 1 2 3; do
  if test "$rep" = 2; then stages='candidate original'; else stages='original candidate'; fi
  for stage in $stages; do
   systemd-run --quiet --user --scope -p MemoryMax=256M -p MemorySwapMax=0 python3 "$w/measure.py" "$v" "$stage" "$rep" >> "$w/fixture-lifetimes.jsonl"
  done
 done
done
