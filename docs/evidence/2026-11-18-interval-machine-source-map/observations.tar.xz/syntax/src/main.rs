use syn::visit::{self, Visit};
struct Inventory<'a>(&'a str);
impl Inventory<'_> {
    fn row(&self, kind: &str, ident: &syn::Ident) {
        println!("{}\t{}\t{}\t{}", self.0, ident.span().start().line, kind, ident);
    }
}
macro_rules! item {
    ($visit:ident, $item:ident, $kind:literal) => {
        fn $visit(&mut self, node: &'ast syn::$item) {
            self.row($kind, &node.ident);
            visit::$visit(self, node);
        }
    }
}
impl<'ast> Visit<'ast> for Inventory<'_> {
    item!(visit_item_struct, ItemStruct, "struct");
    item!(visit_item_enum, ItemEnum, "enum");
    item!(visit_item_trait, ItemTrait, "trait");
    item!(visit_item_type, ItemType, "type");
    item!(visit_trait_item_type, TraitItemType, "type");
    item!(visit_impl_item_type, ImplItemType, "type");
    item!(visit_signature, Signature, "fn");
}
fn main() {
    for path in std::env::args().skip(1) {
        let text = std::fs::read_to_string(&path).unwrap();
        Inventory(&path).visit_file(&syn::parse_file(&text).unwrap());
    }
}
