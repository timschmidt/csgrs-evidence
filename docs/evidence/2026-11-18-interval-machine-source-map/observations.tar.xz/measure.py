from pathlib import Path
import sys,json,time,subprocess,os
w=Path(__file__).resolve().parent
v,stage,rep=sys.argv[1:]
cg=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
assert int((cg/'memory.max').read_text())==256<<20 and int((cg/'memory.swap.max').read_text())==0
start=time.monotonic_ns()
binary=w/(f'acct-{stage}.bin' if os.environ.get('MEASURE_ACCOUNTED_LAYOUT')=='1' else f'{stage}-{v}.bin')
p=subprocess.run([binary,'--exact','machine_profile::tests::shared_timer_minimum_is_driven_by_the_strict_participant_only'],cwd=w,capture_output=True,text=True,check=True)
assert '1 passed; 0 failed;' in p.stdout
peak=int((cg/'memory.peak').read_text())
events={k:int(v) for k,v in (l.split() for l in (cg/'memory.events').read_text().splitlines())}
assert not any(events.values()) and (256<<20)-peak >=64<<20
print(json.dumps(dict(compiler=v,revision=stage,rep=rep,peak_bytes=peak,seconds=(time.monotonic_ns()-start)/1e9,events=events)))
