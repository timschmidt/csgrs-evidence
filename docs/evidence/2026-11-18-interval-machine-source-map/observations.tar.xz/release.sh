set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
v=$1
stage=$2
export CARGO_TARGET_DIR="$w/release-$v" CARGO_BUILD_JOBS=8
cd "$w/alumina-interface"
cargo +"$v" test --locked --release -p alumina-interface-core --lib --no-run --message-format=json-render-diagnostics > "$w/$stage-$v.build" 2> "$w/logs/$stage-$v.build.log"
binary=$(python3 - "$w/$stage-$v.build" <<'PY'
import json,sys
p,=[s['executable'] for s in map(json.loads,open(sys.argv[1])) if s.get('executable')]
print(p)
PY
)
cp "$binary" "$w/$stage-$v.bin"
"$binary" --exact machine_profile::tests::shared_timer_minimum_is_driven_by_the_strict_participant_only --nocapture > "$w/logs/$stage-$v.run" 2>&1
rg -q 'test result: ok. 1 passed; 0 failed;' "$w/logs/$stage-$v.run"
