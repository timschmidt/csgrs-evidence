import subprocess,hashlib,json,importlib.util,sys
from pathlib import Path
w=Path(__file__).parent
historical='docs/evidence/2026-11-16-interval-interface-compiler-display/interface-core-budget/fixed/test-binary'
e='/mnt/development/csgrs-evidence'
old=subprocess.check_output(['git','show','6c09f756f:'+historical],cwd=e)
fixed=(w/'acct-fixed.bin').read_bytes()
result=dict(archived_sha256=hashlib.sha256(old).hexdigest(),reproduced_sha256=hashlib.sha256(fixed).hexdigest(),fixed_matches_byte_for_byte=fixed==old,archived_revision='6c09f756f',archived_path=historical,temporary_layout_report='temporary-layout-sizes.json',temporary_layout_padding=[8,3712,3416])
for stage in ('original','candidate','fixed'):
 a=w/f'acct-{stage}.bin'
 with (w/f'logs/acct-{stage}.program-headers').open('w') as f:subprocess.run(['readelf','-lW',a],stdout=f,check=True)
 with (w/f'logs/acct-{stage}.sections').open('w') as f:subprocess.run(['readelf','-SW',a],stdout=f,check=True)
(w/'layout-review.json').write_text(json.dumps(result,indent=2)+'\n')
# Keep the original reporting class, limits and prior charges, substituting
# only the Rust 1.95 accounted build paths. Keep the scratch-path result intact.
source=(w/'size.py').read_text()
expr="measurements(s/f'{k}-{v}.bin')"
assert source.count(expr)==1
src=source.replace(expr,"measurements(s/(f'acct-{k}.bin' if v=='1.95.0' else f'{k}-{v}.bin'))")
exec(compile(src,'account-layout-size','exec'),{'__file__':str(w/'size.py')})
z=json.loads((w/'sizes.json').read_text())
result['checks']=z['1.95.0']['failed']
(w/'layout-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
