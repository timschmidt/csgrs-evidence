set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
export MEASURE_ACCOUNTED_LAYOUT=1
cp "$w/fixture-lifetimes.jsonl" "$w/temporary-layout-lifetimes.jsonl"
python3 - "$w/fixture-lifetimes.jsonl" <<'PY2'
import json,sys
from pathlib import Path
p=Path(sys.argv[1])
rows=p.read_text().splitlines()
assert len(rows)==18
p.write_text(''.join(r+'\n' for r in rows if json.loads(r)['compiler']=='stable'))
PY2
for rep in 1 2 3; do
 for stage in fixed original candidate; do
  systemd-run --quiet --user --scope -p MemoryMax=256M -p MemorySwapMax=0 python3 "$w/measure.py" 1.95.0 "$stage" "$rep" >> "$w/fixture-lifetimes.jsonl"
 done
done
"$w/acct-candidate.bin" --test-threads=8 > "$w/logs/acct-candidate-full.log"
rg -q '199 passed; 0 failed' "$w/logs/acct-candidate-full.log"
python3 "$w/layout-review.py"
python3 "$w/decide.py"
test -f "$w/interface-commit"
python3 "$w/account.py"
python3 "$w/pack.py"
python3 "$w/progress.py"
