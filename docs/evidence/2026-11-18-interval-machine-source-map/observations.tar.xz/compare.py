from pathlib import Path
import csv,sys,json,subprocess
s=Path(__file__).parent;r=Path('/mnt/development')
i=r/'alumina-interface/crates/alumina-interface-core/src';f=r/'alumina-firmware/crates'
files=sorted([i/(n+'.rs') for n in ('compiler','direct_motion','servo_motion','shared_timing_evidence','graph','boundary','machine_profile','motion_schedule')]+list((i/'graph').rglob('*.rs'))+[f/'alumina-foc/src'/(n+'.rs') for n in ('lib','angle','current','servo','pwm')]+[f/'alumina-clock/src/lib.rs',f/'alumina-sim/src/foc.rs'])
paths={str(p.relative_to(r)) for p in files}
def lexical(p):
 with p.open(newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
 return {(x['repository']+'/'+x['path'],int(x['line']),x['kind'],x['symbol'])for x in rows if x['review_status'].startswith('lexical') and x['repository']+'/'+x['path'] in paths}
result=subprocess.check_output([s/'syntax-target/debug/machine-source-map-oracle',*sorted(paths)],cwd=r,text=True)
(s/'ast.tsv').write_text(result)
syntax={(p,int(line),k,n)for p,line,k,n in (x.split('\t') for x in result.splitlines())}
old=lexical(s/'baseline.tsv');new=lexical(r/'csgrs/interval-inventory.tsv')
report={'files':len(files),'declarations':len(syntax),'old':len(old),'final':len(new),'added':len(new-old),'missing':sorted(syntax-new),'unexpected':sorted(new-syntax)}
print(json.dumps(report,indent=2))
