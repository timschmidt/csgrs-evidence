from pathlib import Path
import struct,hashlib,re,json
s=Path(__file__).parent
blob=(s/'canonical-record.bin').read_bytes()
f=json.loads((s/'record-fields.json').read_text())
p=Path('/mnt/development/alumina-interface/crates/alumina-interface-core/src/machine_profile.rs')
m=re.search(r'const EXPECTED_SHARED_EVIDENCE: \[u8; 104\] = \[(.*?)\];',p.read_text(),re.S)
assert bytes(int(x,16) for x in re.findall(r'0x([0-9a-f]{2})',m[1]))==blob
assert len(blob)==104 and blob[:16]==struct.pack('<8sHHI',b'ALMSYN01',1,2,15)
assert struct.unpack('<QIIIIQQQII',blob[48:])==(64597,4151,4096,65536,20,40,1000000,2495232,1,2)
assert hashlib.sha256(blob).hexdigest()=='7ecca498d9e15745a56432a3eeda4be5d96fbce3b7184206934bfb8917b1273f'
for m in ('transcript','outer'):
 old=(s/f'logs/before-{m}.log').read_text();new=(s/f'logs/after-{m}.log').read_text()
 assert '1 passed; 0 failed;' in old and '0 passed; 1 failed;' in new
 vals=[bytes(map(int,a.split(','))) for a in re.findall(r'(?:left|right): \[([^\]]+)\]',new)]
 assert len(vals)==2 and vals[1]==blob
 diff=[i for i in range(104) if vals[0][i]!=blob[i]]
 assert diff and (all(16<=i<48 for i in diff) if m=='transcript' else all(56<=i<64 for i in diff))
 print(m,'changed positions',diff)
