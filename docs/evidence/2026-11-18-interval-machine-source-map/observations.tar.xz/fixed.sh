set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
mkdir "$w/history"
for tuple in 'csgrs c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb' 'alumina-firmware 2d68e82b7341db7b747b20e4ad1455a4c1113a00'; do
 set -- $tuple
 git -C /mnt/development/"$1" worktree add --detach "$w/history/$1" "$2" >/dev/null
done
for v in stable 1.95.0; do
 until test -f "$w/logs/candidate-$v.run" && rg -q '1 passed; 0 failed' "$w/logs/candidate-$v.run"; do sleep 2; done
done
p=crates/alumina-interface-core/src/machine_profile.rs
cmp "$w/alumina-interface/$p" "/mnt/development/alumina-interface/$p"
git -C "$w/alumina-interface" restore "$p"
git -C "$w/alumina-interface" switch --detach f5341f36803ad77c856313315d67ac8b3bb63f9a
for n in csgrs alumina-firmware; do
 test "$(readlink "$w/$n")" = "/mnt/development/$n"
 ln -sfn "$w/history/$n" "$w/$n"
done
for v in 1.95.0 stable; do mv "$w/release-$v" "$w/compiled-$v"; done
bash "$w/release.sh" 1.95.0 fixed & a=$!
bash "$w/release.sh" stable fixed & b=$!
wait "$a"
wait "$b"
