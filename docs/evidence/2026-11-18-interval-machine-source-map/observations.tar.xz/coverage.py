from pathlib import Path
import csv,collections,json
s=Path(__file__).parent
def read(p):
 with p.open() as f:return list(csv.DictReader(f,delimiter='\t'))
def name(r):return r['repository'],r['path'],r['kind'],r['symbol']
def candidates(rows):return collections.Counter(name(r) for r in rows if r['review_status'].startswith('lexical'))
a,b=map(lambda p:candidates(read(p)),[s/'baseline.tsv',s/'second.tsv'])
assert not a-b
new=b-a
assert sum(new.values())==2190
report=json.loads((s/'comparison.json').read_text())
report['added_after_accounting_for_moved_lines']=sum(new.values())
report['line_key_additions']=report.pop('added')
(s/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
