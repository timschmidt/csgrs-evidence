import hashlib,json,re,struct,sys
from pathlib import Path
s=Path(__file__).parent
log=(s/'logs/baseline.log').read_text()
assert 'test result: ok. 1 passed; 0 failed;' in log
b=bytes.fromhex(re.search(r'^SHARED_RECORD=\[([^\]]+)\]$',log,re.M)[1].replace(',',''))
assert len(b)==104
fmt='<8sHHI32sQIIIIQQQII'
magic,version,axes,flags,digest,length,n,den,maximum,rounds,replays,hz,tick,quantum,count=struct.unpack(fmt,b)
print(magic,version,axes,flags,length,n,den,maximum,rounds,replays,hz,tick,quantum,count)
(s/'canonical-record.bin').write_bytes(b)
(s/'record-fields.json').write_text(json.dumps(dict(magic=magic.decode(),version=version,axes=axes,flags=flags,transcript_sha256=digest.hex(),transcript_bytes=length,numerator=n,denominator=den,maximum=maximum,rounds=rounds,replays=replays,hz=hz,tick=tick,quantum=quantum,participants=count,record_sha256=hashlib.sha256(b).hexdigest()),indent=2)+'\n')
p=Path('/mnt/development/alumina-interface/crates/alumina-interface-core/src/machine_profile.rs')
t=p.read_text();anchor='        assert_eq!(&evidence.encoded()[..8], b"ALMSYN01");';assert t.count(anchor)==1
rows=['            '+', '.join(f'0x{x:02x}' for x in b[i:i+12])+','for i in range(0,len(b),12)]
p.write_text(t.replace(anchor,'''        // Published two-device record from fdb7b15. This pins both the outer
        // framing and the digest of the exact, ordered retiming transcript.
        const EXPECTED_SHARED_EVIDENCE: [u8; 104] = [
'''+ '\n'.join(rows)+'''
        ];
        assert_eq!(evidence.encoded(), EXPECTED_SHARED_EVIDENCE.as_slice());
'''+anchor))
