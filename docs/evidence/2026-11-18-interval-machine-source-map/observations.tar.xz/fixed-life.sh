set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
for v in 1.95.0 stable; do
 until test -f "$w/logs/fixed-$v.run" && rg -q '1 passed; 0 failed' "$w/logs/fixed-$v.run"; do
  sleep 2
 done
 for rep in 1 2 3; do
  systemd-run --quiet --user --scope -p MemoryMax=256M -p MemorySwapMax=0 python3 "$w/measure.py" "$v" fixed "$rep" >> "$w/fixture-lifetimes.jsonl"
 done
done
python3 "$w/size.py"
