from pathlib import Path
import json,sys,resource,time,subprocess
w=Path(__file__).parent
impl=sys.argv[1]
p= w/'old-inventory.py' if impl=='old' else Path('/mnt/development/csgrs/scripts/interval_inventory.py')
s=time.monotonic()
out=subprocess.check_output([sys.executable,p,'--workspace','/mnt/development','--output',w/f'cost-{impl}.tsv'],text=True)
print(json.dumps(dict(implementation=impl,seconds=time.monotonic()-s,peak_child_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,result=out.strip())))
