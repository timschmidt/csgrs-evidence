set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
space=$(df --output=avail -B1 "$w" | tail -n 1)
test "$space" -gt 23622320128
# Two simultaneous jobs use separate physical target directories, each mounted at the historically recorded target path inside its namespace.
mkdir "$w/fixed-account-target"
sed 's|"$w/account-target"|"$w/fixed-account-target"|' "$w/account-release.sh" > "$w/account-fixed.sh"
unshare -Urm bash "$w/account-fixed.sh" fixed & a=$!
unshare -Urm bash "$w/account-release.sh" original & b=$!
wait "$b"
p=crates/alumina-interface-core/src/machine_profile.rs
cp "/mnt/development/alumina-interface/$p" "$w/current-interface/$p"
unshare -Urm bash "$w/account-release.sh" candidate & c=$!
wait "$a"
wait "$c"
