from pathlib import Path
import hashlib,subprocess,re,json,sys
r=Path('/mnt/development/csgrs')
s=Path(__file__).parent
accounts=json.loads((r/'docs/research/interval-size-accounts.json').read_text())
account=next(a for a in accounts['accounts'] if a['artifact'].endswith('core/src/lib.rs#release-tests'))
hist=account['matched_layout_requalifications'][0]
def measurements(p):
 sections={}
 raw=p.read_bytes()
 for l in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
  m=re.match(r'\s*\[\s*\d+\]\s+(\.\S+)\s+(\S+)\s+[0-9a-f]+\s+([0-9a-f]+)\s+([0-9a-f]+)\s+[0-9a-f]+\s+(\S+)',l)
  if not m:continue
  n,t,o,z,f=m.groups();off=int(o,16);size=int(z,16)
  if 'A' in f:
   sections[n]={'bytes':size,'sha256':None if t=='NOBITS' else hashlib.sha256(raw[off:off+size]).hexdigest(),'executable':'X' in f}
 return dict(file={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'executable':False},**sections)
def data(v):
 stages={k:measurements(s/f'{k}-{v}.bin') for k in ('candidate','original','fixed') if (s/f'{k}-{v}.bin').is_file()}
 if not {'candidate','original'}<=stages.keys():return {}
 rows={}
 for n,val in stages['candidate'].items():
  c=val['bytes'];o=stages['original'][n]['bytes']
  f=stages.get('fixed',{}).get(n,{}).get('bytes')
  caps=accounts['existing_artifacts']['native_monomorphized_text_sum' if val['executable'] else 'native_final_file_and_allocated_sections'].copy()
  prior=max(o-f,0) if f is not None else 0
  if v=='1.95.0':
   prior=432 if n=='file' else 224 if n=='.text' else max(0,hist['comparisons']['cumulative']['allocated_sections'][n]['delta_bytes'])+max(0,-min(0,hist['comparisons']['incremental']['allocated_sections'][n]['delta_bytes']))
   if n=='.relro_padding':prior=48;caps=dict(incremental_bytes=2287,incremental_percent=150,cumulative_bytes=1879,cumulative_percent=100)
  extra=max(c-o,0)
  charge=prior+extra
  inc=extra<=caps['incremental_bytes'] and extra*100<=o*caps['incremental_percent']
  cum=None if f is None else max(charge,c-f)<=caps['cumulative_bytes'] and max(charge,c-f)*100<=f*caps['cumulative_percent']
  result=dict(original=o,candidate=c,fixed=f,delta=c-o,new_charge=extra,prior_charge=prior,cumulative_charge=charge,inc_pass=inc,cum_pass=cum,caps=caps)
  if f is not None:
   result['net_bytes_from_fixed']=c-f
   result['remaining_incremental_bytes']=min(caps['incremental_bytes'],o*caps['incremental_percent']//100)-extra
   result['remaining_cumulative_bytes']=min(caps['cumulative_bytes'],f*caps['cumulative_percent']//100)-max(charge,c-f)
  rows[n]=result
 return dict(stages=stages,metrics=rows,failed=[(k,r['inc_pass'],r['cum_pass']) for k,r in rows.items() if not r['inc_pass'] or r['cum_pass'] is False])
out={v:data(v) for v in ('1.95.0','stable')}
(s/'sizes.json').write_text(json.dumps(out,indent=2)+'\n')
for v,d in out.items():
 if d:print(v,{k:d['metrics'][k]['delta'] for k in ('file','.text')},d['failed'])
