from pathlib import Path
import json,statistics
w=Path(__file__).parent
r=Path('/mnt/development/csgrs/docs/research')
data=json.loads((w/'sizes.json').read_text())
assert all(z and 'fixed' in z['stages'] and not z['failed'] for z in data.values())
def read(p):return json.loads((r/p).read_text())
def write(p,d):
 (r/p).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
p='interval-size-accounts.json';d=read(p)
acct=next(a for a in d['accounts'] if a['artifact'].endswith('core/src/lib.rs#release-tests'))
assert len(acct['matched_layout_requalifications'])==1
entry={'change':'shared-timing-evidence-reference-record','scope':'Test-only 104-byte reference for the complete two-device record and ordered transcript. Every allocated section and the complete stripped executable were measured on both compilers.','retained_source_commit':(w/'interface-commit').read_text().strip(),'baseline_repositories':acct['baseline_repositories'],'previous_repositories':{'csgrs':'dba77e15b','alumina-interface':'fdb7b15','alumina-firmware':'35d1b0d'},'evidence':'docs/evidence/2026-11-18-interval-machine-source-map/sizes.json (inside observations.tar.xz)','targets':{}}
for v,z in data.items():
 metrics=z['metrics']
 cap=acct['metrics']
 growth={k:{x:m[x] for x in ('fixed','original','candidate','delta','prior_charge','new_charge','cumulative_charge','net_bytes_from_fixed','remaining_incremental_bytes','remaining_cumulative_bytes')} for k,m in metrics.items() if k in ('file','.text') or m['new_charge']}
 entry['targets']['Rust 1.99.0' if v=='stable' else 'Rust 1.95.0']={'target':'x86_64-unknown-linux-gnu','sha256':{k:v['file']['sha256'] for k,v in z['stages'].items()},'metrics':growth,'allocated_sections_checked':len(metrics)-1,'failed_caps':z['failed']}
entry['accounting']='Fixed and immediately prior links use the same paths for each compiler. Earlier positive file and code charges of 432 and 224 bytes on Rust 1.95 remain charged. Each remaining allowance takes the greater of cumulative positive charges and net fixed-to-candidate growth. The supplemental Rust 1.99 account charges positive predecessor growth against its fixed control before adding this change. All existing limits apply, including the historical Rust 1.95 RELRO padding provision.'
entry['layout_verification']=json.loads((w/'layout-review.json').read_text())
entry['layout_limitation']='Rust 1.95 temporary-path RELRO padding failed its cumulative cap (fixed 8, predecessor 3712, candidate 3416 bytes). Only the registered release layout is qualified. Caps and prior charges remain unchanged.'
acct['matched_layout_requalifications'].append(entry)
write(p,d)
p='interval-memory-accounts.json';d=read(p)
key='shared_timing_evidence_reference_job'
assert key not in d
obs=[json.loads(x) for x in (w/'fixture-lifetimes.jsonl').read_text().splitlines()]
assert len(obs)==18 and all(not any(q['events'].values()) for q in obs)
c={'scope':'Native host test process and observer from spawn through result and exit, two-participant exact retiming, global job publication and drop. Test assertion borrows the existing record and a static expected slice. Production code is unchanged.', 'evidence':entry['evidence'].split('/sizes.json')[0], 'limit_bytes':256<<20,'required_headroom_bytes':64<<20,'swap_limit_bytes':0,'measurement':'Fresh cgroup v2 memory.peak for each run, including the Python observer. This is a complete group capacity check, not an allocation or stack measurement. The three repetitions at each revision use the same completed test.', 'observations':{}}
for v in data:
 result={k:max(t['peak_bytes'] for t in obs if t['revision']==k and t['compiler']==v) for k in ('fixed','original','candidate')}
 assert result['candidate']+(64<<20)<=256<<20
 c['observations'][v]={**result,'candidate_remaining_above_reserve_bytes':(192<<20)-result['candidate']}
d[key]=c;write(p,d)
