from pathlib import Path
import json,subprocess,importlib.util
w=Path(__file__).parent
def success(path,substring):
 assert substring in (w/path).read_text(),path
for v in ['1.95.0','stable']:
 for k in ['original','candidate','fixed']:
  success(f'logs/{k}-{v}.run','1 passed; 0 failed')
 success(f'logs/full-{v}.log','199 passed; 0 failed')
for scope in ('clippy','wasm-clippy'):success(f'logs/{scope}.log','Finished')
success('logs/control-graph.log','0 failed')
success('logs/sim-foc.log','7 passed; 0 failed')
success('logs/sim-full.log','68 passed; 0 failed')
success('logs/seed-tests.log','Ran 7 tests')
success('logs/final-scan.log','6338 scan rows and 312 review records')
assert len((w/'fixture-lifetimes.jsonl').read_text().splitlines())==18
manifest=json.loads((w/'sizes.json').read_text())
assert all(z.get('metrics') and 'fixed' in z['stages'] for z in manifest.values())
items=set()
for n in ('syntax/Cargo.toml','syntax/Cargo.lock','syntax/src/main.rs','baseline.tsv','inventory-summary.json','comparison.json','ast.tsv','canonical-record.bin','record-fields.json','account.py','scope.md','record.py','pack.py','release.sh','negative.sh','fixed.sh','fixed-life.sh','pinned.py','pinned-times.json','toolchains.txt','measure.py','suite.sh','env','sizes.json','size.py','fixture-lifetimes.jsonl','scan-cost.jsonl','production-prefix.sha256','inventory-commit','audit.py','compare.py','coverage.py','fixture.py','mutate.py','recheck-record.py','scan-cost.py','test.patch','scanner.patch','decision.json'):
 items.add(w/n)
items.update(w/n for n in ('layout-review.py','layout-review.json','account-release.sh','account-fixed.sh','qualified-layout.sh','temporary-layout-sizes.json','temporary-layout-lifetimes.jsonl','finish.sh','decide.py'))
items.update(p for p in (w/'logs').iterdir() if p.is_file() and p.name!='inventory-old-1.log')
spec=importlib.util.spec_from_file_location('rec',w/'record.py');rec=importlib.util.module_from_spec(spec);spec.loader.exec_module(rec)
result=rec.record('machine-source-map',items,'Archive Alumina declaration coverage and shared retiming compatibility evidence')
(w/'archive-info.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
