from pathlib import Path
import subprocess,sys
s=Path(__file__).parent;root=s/'probe-interface'
name=sys.argv[1]
p=Path('crates/alumina-interface-core/src/shared_timing_evidence.rs')
t=subprocess.check_output(['git','show','HEAD:'+str(p)],cwd=root,text=True)
if name=='transcript':
 old='const EXACT_REAL_FORMAT_VERSION: u16 = 1;';new=old.replace('= 1','= 2')
else:
 old='    push_u32(&mut encoded, shared.selected_factor_numerator());\n    push_u32(&mut encoded, shared.selected_factor_denominator());'
 new='\n'.join(reversed(old.splitlines()))
assert t.count(old)==1;(root/p).write_text(t.replace(old,new))
