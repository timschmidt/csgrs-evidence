import csv
from pathlib import Path
p=Path('/mnt/development/csgrs/interval-inventory.tsv')
rows=list(csv.DictReader(p.open(),delimiter='\t'))
module='crates/alumina-interface-core/src/shared_timing_evidence.rs'
source=[r for r in rows if r['path']==module and r['review_status'].startswith('lexical')]
assert len(source)==34
getters={
'digest':('Digest','SHA-256 of the complete outer record; used as the global synchronization identity.'),
'transcript_digest':('Digest','SHA-256 of the ordered exact retiming transcript.'),
'transcript_byte_len':('u64','Exact hashed transcript byte count.'),
'selected_factor_numerator':('u32','Selected common dilation numerator.'),
'selected_factor_denominator':('u32','Positive common dilation lattice denominator.'),
'maximum_factor_numerator':('u32','Inclusive caller-specified search ceiling numerator.'),
'candidate_rounds':('u32','Count of all-participant search rounds, including repeated boundary checks.'),
'participant_replays':('u64','Count of individual participant preflights across rounds.'),
'timer_ticks_per_second':('u64','Common local timer frequency in ticks per second.'),
'output_quantum_cycles':('u32','Common output grid quantum in timer cycles.'),
'terminal_tick':('u64','Final stream-relative common tick.'),
'participant_count':('u32','Number of participating MCUs.')}
# representation, meaning, allocation, serialization, immediate caller/consumer
spec={}
for k,(t,m) in getters.items():
 spec[k]=(t,m,'Copies one stored field.','Copies the decoded field or stored digest.','Public evidence API; digest also feeds global job packaging.' if k=='digest' else 'Public evidence API.')
def add(n,t,m,a,fmt,cons):spec[n]=(t,m,a,fmt,cons)
add('SharedTimingEvidenceResult','Result<T, SharedTimingEvidenceError>','Carries a complete value or a typed evidence failure.','Depends on T and wrapped cause.','Rust result; no standalone wire form.','Public evidence operations and private validation.')
add('SharedTimingEvidenceParticipant2','DeviceId and three borrowed references','Binds an MCU to its exact planner, lowering and final partition.','Copyable borrowed record.','Device identity and derived facts enter the transcript.','Global job construction and shared evidence builder.')
add('new','DeviceId and three borrowed references','Constructs the binding. Validation occurs in the evidence builder.','Stores references inline.','No encoding here.','Global job builder and shared schedule fixture.')
add('device_id','DeviceId','Returns the bound physical identity by value.','Copies stored identifier.','No encoding here.','Public participant API.')
add('CanonicalSharedTimingEvidence1','Vec<u8>, two digests and integer fields','Owns a canonical outer record and the matching derived facts.','Owns the outer buffer; cloning duplicates it.','ALMSYN01 v1, 104 bytes.','Global job packaging, replay and public accessors.')
add('encoded','&[u8]','Borrows the complete canonical record.','Borrows existing storage.','Exposes all 104 bytes in field order.','Outer verification and exact byte compatibility fixture.')
add('build_shared_timing_evidence','Exact Reals, rationals, digests and fixed-width integer fields','Sorts by DeviceId, validates participant and search facts, commits per-device planner and lowering digests, outcomes, ticks, segments and preflights.','Sorts owned participant vector in place; allocates outer record and derivation temporaries.','Streams ALMSRT01; exact Real encoding capped at 1 MiB, individual transcript at 64 MiB. Commits digest and length to ALMSYN01.','Shared timer global job compiler, replay and tests.')
add('replay_shared_timing_evidence','CanonicalSharedTimingEvidence1 plus original inputs','Rebuilds the record and compares all fields; mismatch is typed.','Rebuild allocates independently.','Full byte and field equality through derived Eq.','Public replay API and shared timer fixture.')
add('verify_shared_timing_evidence_bytes','Borrowed bytes and expected Digest','Checks length, magic, version, axes, flags and SHA-256. Requires external digest and does not replay a schedule.','Reads borrowed bytes.','Validates outer framing and hash only.','Public byte verification and corruption fixture.')
add('validate_participants','Sorted participant slice and shared schedule','Checks counts, distinct IDs, config and capability digests, timer/grid, endpoints, terminal tick and segment count.','Iterates borrowed slices.','Checked facts precede transcript emission.','Evidence builder; global job packages the selected streams before calling.')
add('validate_search_trace','Integer factor lattice and recorded candidate reports','Checks round and replay counts, allowed rejections, unit case or binary-search order, selected and predecessor outcomes and matching final preflights.','Iterates borrowed reports and participant slices.','Validates ordered source reports before hashing.','Evidence builder.')
add('all_accepted','Slice of tagged candidate outcomes','Requires every participant outcome to be Accepted in this round.','Reads slice.','No encoding here.','Search trace validator.')
add('accepted_preflight','SharedTimerCandidateOutcome2','Extracts a two-axis preflight summary or returns SearchTraceMismatch.','Copies accepted summary.','No encoding here.','Search trace validator.')
add('push_candidate_outcome','Accepted preflight or rejected motion error','Commits the participant outcome and its payload.','Writes through the borrowed transcript encoder.','u8 tag 1 plus preflight or 0 plus motion error.','Builder and optional outcome writer.')
add('push_optional_candidate_outcome','Option<SharedTimerCandidateOutcome2>','Preserves absence of the predecessor separately from an explicit rejection.','Writes through the borrowed transcript encoder.','u8 tag 0 for absent or 1 followed by the tagged outcome.','Builder, per-participant predecessor.')
for typ in ('u16','u32','u64'):add('push_'+typ,typ,'Appends the exact fixed-width unsigned value.','Extends the outer vector pre-reserved by the caller.','Little-endian, '+str(int(typ[1:])//8)+' bytes.','Evidence builder.')
add('SharedTimingEvidenceError','Typed enum with device or upstream payload where applicable','Separates participant, identity, terminal, search, derivation, allocation, counter, encoding, replay and digest failures.','Payload dependent; retains upstream cause by value.','Errors do not encode successful evidence.','Builder, replay, byte verification and public job errors.')
add('fmt','fmt::Formatter and borrowed error','Formats variant-specific diagnostics including device or derivation cause.','Writes into caller-provided formatter.','Display text only.','Display consumers.')
add('source','Option<&dyn Error>','Returns the nested ScheduleEvidenceError for Derivation. Other variants have no nested cause.','Borrows stored cause.','No wire encoding.','Error chain traversal.')
add('from','ScheduleEvidenceError','Wraps upstream failure as Derivation without mapping away its cause.','Moves upstream error.','No wire encoding.','Builder via question-mark propagation.')
assert set(spec)=={r['symbol'] for r in source} and len(source)==len(spec)
reviews=[]
for orig in source:
 r=orig.copy()
 (r['endpoint_representation'],r['semantics'],r['allocation'],r['serialization'],r['consumers'])=spec[r['symbol']]
 r.update(platform='Interface core, standard library on host/Wasm; this audit exercises native.',disposition='Keep in Interface core. Preserve device identity, units, field order and typed evidence outcomes.',baseline_tests='cargo test --locked -p alumina-interface-core --lib machine_profile::tests::shared_timer',baseline_benchmarks='No isolated symbol timing. Linked two-device fixture measurements in the machine-source-map record.',review_status='Body reviewed at Alumina Interface fdb7b15 with shared timer fixture and global_job caller.')
 reviews.append(r)
assert not any(r['review_status']==reviews[0]['review_status'] for r in rows)
with p.open('a',newline='') as f:
 csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n').writerows(reviews)
