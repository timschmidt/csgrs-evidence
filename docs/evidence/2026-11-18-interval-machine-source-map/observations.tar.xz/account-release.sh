set -eu
w=/mnt/development/.interval-refactor-build/alumina-map.LltqiP
. "$w/env"
k=$1
case "$k" in
fixed) interface="$w/alumina-interface";csgrs="$w/history/csgrs";firmware="$w/history/alumina-firmware";;
original|candidate) interface="$w/current-interface";csgrs=/mnt/development/csgrs;firmware=/mnt/development/alumina-firmware;;
*) exit 1;;
esac
# Reproduce the historical absolute source/registry paths. Private mounts
# disappear on exit; every writable cache is backed by the current scratch.
mount --make-rprivate /
mount --bind "$w/cargo" /home/tim/.cargo
export CARGO_HOME=/home/tim/.cargo CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=4
historical=/mnt/development/interval-coordinated-stack
for n in interface csgrs firmware; do
 case "$n" in interface) dir=alumina-interface;; csgrs) dir=csgrs;; firmware) dir=alumina-firmware;; esac
 eval 'src=$'"$n"
 mount --bind "$src" "$historical/$dir"
 mount -o remount,bind,ro "$historical/$dir"
done
base=/mnt/development/.interval-refactor-build/coordinated-ci
mount --bind "$w/account-target" "$base"
export CARGO_TARGET_DIR="$base/interface-core-budget-1.95.0"
cd "$historical/alumina-interface"
# Invoke the installed toolchain directly. Rustup need not resolve a proxy in the masked Cargo home.
export PATH="/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin:$PATH"
cargo test --locked --release -p alumina-interface-core --lib --no-run --message-format=json > "$w/acct-$k.build" 2> "$w/logs/acct-$k.build.log"
bin=$(python3 - "$w/acct-$k.build" <<'PY'
import json,sys
a,=[v['executable'] for v in map(json.loads,open(sys.argv[1])) if v.get('executable')];print(a)
PY
)
cp "$bin" "$w/acct-$k.bin"
"$bin" --exact machine_profile::tests::shared_timer_minimum_is_driven_by_the_strict_participant_only > "$w/logs/acct-$k.run"
rg -q '1 passed; 0 failed' "$w/logs/acct-$k.run"
