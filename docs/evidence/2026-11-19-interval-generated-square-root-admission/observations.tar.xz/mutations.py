from pathlib import Path
import os,sys,subprocess as sp
s=Path(__file__).resolve().parent;r=s/'src';p=r/'crates/hyperinterval/src/dyadic.rs';orig=p.read_text();assert orig==(s.parent/'csgrs/crates/hyperinterval/src/dyadic.rs').read_text()
def run(name,old,new,test,selected):
 assert orig.count(old)==1
 p.write_text(orig.replace(old,new));cmd=['cargo','+1.95.0','test','--locked','--release','-p','hyperinterval','--all-features','--test',test,selected]
 with (s/(name+'.log')).open('w') as out:rtn=sp.run(cmd,cwd=r,stdout=out,stderr=sp.STDOUT)
 txt=(s/(name+'.log')).read_text();assert rtn.returncode==101 and 'test result: FAILED' in txt,name
try:
 run('mutant-skip-upper','for source in [a, b] {','for source in [a] {','fractional_power_ingress','generated_square_root')
 run('mutant-undercharge','crate::rational_admission::reserve_reduction(source, budget)?;','budget.reserve(source.reduction_input_bits(), 1, true)?;','monotone_ingress','generated_square_root')
 run('mutant-eager-cache','if source.is_positive() {\n                crate::rational_admission::reserve_reduction(source, budget)?;', 'if source.is_positive() {\n                let _ = source.numerator();\n                crate::rational_admission::reserve_reduction(source, budget)?;','fractional_power_ingress','generated_square_root')
 run('mutant-ignore-remainder','remainder.is_zero() && &lower * &lower == floor','&lower * &lower == floor','square_roots','independent::')
finally:p.write_text(orig)
with (s/'restored.log').open('w') as f:sp.run(['cargo','+1.95.0','test','--release','--locked','-p','hyperinterval','--all-features','--test','square_roots','--test','fractional_power_ingress','--test','monotone_ingress'],cwd=r,stdout=f,stderr=sp.STDOUT,check=True)
