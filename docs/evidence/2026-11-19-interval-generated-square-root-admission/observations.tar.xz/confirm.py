from pathlib import Path
import csv,json,subprocess as sp,statistics as st
s=Path(__file__).resolve().parent;r={}
for i in range(9):
 for tag in (['control','unsigned'] if i%2==0 else ['unsigned','control']):
  t=s/'bin'/(tag+'-owner-stable-sqrt_cost')
  rows=list(csv.DictReader(sp.check_output([t],text=True).splitlines()));assert len(rows)==640
  for row in rows:
   if row['backend']=='rational' and row['case']=='point' and row['precision']=='-256':
    r.setdefault(tag,[]).append(int(row['elapsed_ns']))
(s/'confirm.json').write_text(json.dumps(r))
dd=[100*(st.median(r['unsigned'][i:i+20])/st.median(r['control'][i:i+20])-1) for i in range(0,180,20)]
print([round(q,2) for q in dd],round(st.median(dd),2))
