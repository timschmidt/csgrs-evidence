from pathlib import Path
import os,subprocess as sp,json,sys
from metrics import metrics
s=Path(__file__).resolve().parent;tag,v=sys.argv[1:];native=s/('target' if v=='1.95.0' else 'stable-target')
# Other terminal users of scaled_quotient, principal inverse functions,
# finite and extended division, and the actual transcendental cost drivers.
tests=['arctangent','exponential','logarithm','trigonometry','tangent','inverse_functions','square_roots','fractional_power','rational_conversion','split_division','extended','dyadic','periodic_ingress']
examples=['atan_cost','exp_cost','log_cost','trig_cost','tangent_cost','division_cost','host_cost']
cmd=['cargo','+'+v,'build','--locked','--release','-p','hyperinterval','--all-features','--message-format=json']
for n in tests: 
 if (s/('src/crates/hyperinterval/tests/'+n+'.rs')).exists():cmd+=['--test',n]
for n in examples:cmd+=['--example',n]
with (s/(tag+'-indirect-'+v+'.log')).open('w') as f:out=sp.check_output(cmd,cwd=s/'src',env=os.environ|{'CARGO_TARGET_DIR':str(native)},stderr=f,text=True)
rows={x['target']['name']:metrics(Path(x['executable'])) for x in map(json.loads,out.splitlines()) if x.get('executable')}
(s/(tag+'-indirect-'+v+'.json')).write_text(json.dumps(rows,indent=1))
