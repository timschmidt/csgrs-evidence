import sys
from pathlib import Path
import wasmtime as w
s=Path(__file__).parent
def run(path,args,out):
 e=w.Engine();m=w.Module.from_file(e,str(path));store=w.Store(e);link=w.Linker(e)
 cfg=w.WasiConfig();cfg.argv=[path.name,*args];cfg.stdout_file=str(out);cfg.stderr_file=str(out)+'.stderr';cfg.preopen_dir(str(s/'tmp'),'/tmp')
 store.set_wasi(cfg);link.define_wasi();api=link.instantiate(store,m).exports(store)
 try:api['_start'](store)
 except w.ExitTrap as err:
  if err.code!=0:raise
if __name__=='__main__':run(Path(sys.argv[1]),sys.argv[3:],Path(sys.argv[2]))
