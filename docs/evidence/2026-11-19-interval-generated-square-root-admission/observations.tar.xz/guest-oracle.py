from pathlib import Path
import os,subprocess as sp,json
s=Path(__file__).resolve().parent
manifest=s/'guest/Cargo.toml'
original=manifest.read_text()
try:
 manifest.write_text(original+'\n[[test]]\nname="dyadic_guest"\npath="../dyadic_guest.rs"\n')
 for v in ['1.95.0','stable']:
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('wasi-'+v)),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot '+str(s/('sysroot-'+v))}
  data=sp.check_output(['cargo','+'+v,'build','--locked','--offline','--release','--all-features','--target','wasm32-wasip1','--test','dyadic_guest','--message-format=json'],env=env,cwd=s/'guest',text=True)
  exe=next(d['executable'] for d in map(json.loads,data.splitlines()) if d.get('executable'))
  sp.run([s/'venv/bin/python',s/'run-wasi.py',exe,s/('dyadic-guest-'+v+'.log'),'--test-threads=1'],check=True)
finally:manifest.write_text(original)
