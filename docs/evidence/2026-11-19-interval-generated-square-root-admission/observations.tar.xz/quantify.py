from pathlib import Path
import json,sys
s=Path(__file__).resolve().parent;t=sys.argv[1]
def read(p):return json.loads(p.read_text())
for v in ['1.95.0','stable']:
 for lane in ['owner','wasmtest']:
  if lane=='owner':
   outp=s/f'{t}-owner-{v}.json';basep=s/f'control-owner-{v}.json'
   if not outp.exists():continue
   a=read(basep)|{'monotone_ingress':read(s/f'before-owner-{v}.json')['monotone_ingress']};b=read(outp)
  else:
   outp=s/f'{t}-wasi-images.json'
   if not outp.exists():continue
   a=read(s/'baseline-wasi-images.json')[v];b=read(outp)[v]
  for name,z in b.items():
   if 'ingress' not in name:continue
   dif=[z[k]-a[name][k] for k in ['file','code','functions']];rem=[min(32768,int(a[name][k]*.02))-q for k,q in zip(['file','code','functions'],dif)];print(lane,v,name,dif,'step remaining',rem)
for p in [s/'records'/(t+'.json')]:
 if not p.exists():continue
 a=read(s/'records/before.json');b=read(p)
 for n in b:
  bad=[]
  for k,z in b[n]['jobs'].items():
   orig=a[n]['jobs'][k]
   if orig[0]!=z[0]:continue
   for i in [0,2]:
    o,h=[max(x[1][i:i+2]) for x in [orig,z]]
    if h-o>min(128,.02*o):bad.append([k,i,h-o])
  print('stack',n,len(bad),bad[:1])
