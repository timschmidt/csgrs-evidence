from pathlib import Path
import subprocess as sp,shutil,os,sys,json
from metrics import metrics
s=Path(__file__).resolve().parent;c=s/'client';tag=sys.argv[1];rows={}
for v in ['1.95.0','stable']:
 for arch in ['x86_64-unknown-linux-gnu','wasm32-unknown-unknown']:
  wasm=arch.startswith('wasm');env=os.environ|{'CARGO_TARGET_DIR':str(s/('client-'+v))}
  for ins in [False,True]:
   cmd=['cargo','+'+v,'build','--locked','--release','--target',arch]+(['--lib'] if wasm else ['--bin','sqrt-admission-client'])+(['--features','measure'] if ins else [])
   key=f'{v}-{arch}'+('-alloc' if ins else '')
   with (s/f'{tag}-{key}.log').open('w') as log:sp.run(cmd,cwd=c,stdout=log,stderr=sp.STDOUT,check=True,env=env)
   image=s/'bin'/(tag+'-'+key);file=Path(env['CARGO_TARGET_DIR'])/arch/'release'/('sqrt_admission_client.wasm' if wasm else 'sqrt-admission-client');shutil.copy2(file,image)
   rows[key]=metrics(image)
(s/(tag+'-images.json')).write_text(json.dumps(rows,indent=2))
