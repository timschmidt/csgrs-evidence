from pathlib import Path
import json,os,subprocess as sp
from metrics import metrics
s=Path(__file__).resolve().parent
def git(*a):return sp.check_output(['git','-C',s/'src',*a])
refs=['crates/hyperinterval/tests/inverse_functions.rs','crates/hyperinterval/tests/support/atanh_oracle.rs']
def switch(arg):sp.run(['python3',s/'switch-stage.py',arg],check=True)
switch('restore');switch('c9f1f9ac5')
try:
 for f in refs:(s/'src'/f).write_bytes((s.parent/'csgrs'/f).read_bytes())
 for v in ['1.95.0','stable']:
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('target' if v=='1.95.0' else 'stable-target'))}
  raw=sp.check_output(['cargo','+'+v,'build','--release','--locked','-p','hyperinterval','--all-features','--test','inverse_functions','--message-format=json'],cwd=s/'src',env=env,text=True)
  path=next(d['executable'] for d in map(json.loads,raw.splitlines()) if d.get('executable'))
  (s/('inverse-same-workload-'+v+'.json')).write_text(json.dumps(metrics(Path(path))))
finally:
 git('restore','--',refs[0]);(s/'src'/refs[1]).unlink();assert not git('status','--porcelain');switch('candidate')
