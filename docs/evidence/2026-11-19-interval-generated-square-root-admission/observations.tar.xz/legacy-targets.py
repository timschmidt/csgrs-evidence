from pathlib import Path
import json,re,os,subprocess as sp
from metrics import metrics
s=Path(__file__).resolve().parent
def switch(arg):sp.run(['python3',s/'switch-stage.py',arg],check=True)
def measure(tag):
 cmd=['cargo','+1.95.0','build','--release','--locked','--offline','-p','hyperinterval','--features','integer,fixed,rational,dyadic,float-enclosure','--example','tangent_cost','--example','fractional_power_cost','--message-format=json']
 raw=sp.check_output(cmd,cwd=s/'src',text=True)
 rows={}
 for d in map(json.loads,raw.splitlines()):
  if d.get('executable'):
   p=Path(d['executable'])
   (s/(tag+'-legacy-'+d['target']['name']+'-layout.log')).write_bytes(sp.check_output(['readelf','-W','-S','-l',p]))
   rows[d['target']['name']]=metrics(p)|{m[1]:int(m[2]) for m in re.finditer(r'^(\.\S+)\s+(\d+)\s+\d+',sp.check_output(['size','-A',p],text=True),re.M)}
 (s/'records'/('legacy-'+tag+'.json')).write_text(json.dumps(rows,indent=1))
measure('unsigned')
switch('restore')
try:
 measure('before')
 switch('c9f1f9ac5')
 measure('fixed')
finally:switch('candidate')
