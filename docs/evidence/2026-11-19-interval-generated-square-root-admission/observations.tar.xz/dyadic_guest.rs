use hyperinterval::{DomainCoverage, DyadicBudget, DyadicInterval, IntervalError};

#[test]
fn check_grid_tightness() {
    let range = |a: i64, b: i64, e| DyadicInterval::new(a.into(), b.into(), e).unwrap();
    for a in -5i64..=12 {
        for b in a..=12 {
            for e in -4i32..=4 {
                for p in -3i32..=3 {
                    let got = range(a,b,e).sqrt(p, &mut DyadicBudget::new(256, 10_000_000));
                    if b < 0 {
                        assert_eq!(got, Err(IntervalError::EmptyDomain));
                        continue;
                    }
                    let shift = e - 2*p;
                    let scaled = |x: i64| x.max(0) << shift.max(0);
                    let den = 1 << (-shift).max(0);
                    let lo = (scaled(a)/den).isqrt();
                    let floor = (scaled(b)/den).isqrt();
                    let hi = floor + i64::from(floor*floor*den < scaled(b));
                    let result = got.unwrap();
                    assert_eq!(result.range,range(lo, hi, p));
                    assert_eq!(result.domain, if a<0 {DomainCoverage::Partial} else {DomainCoverage::Complete});
                }
            }
        }
    }
}
