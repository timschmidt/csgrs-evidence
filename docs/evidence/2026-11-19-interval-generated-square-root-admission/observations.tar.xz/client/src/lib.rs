use hyperinterval::{DomainCoverage,DyadicBudget,DyadicInterval,IntervalError,RationalInterval};
use hyperreal::{ExactDyadicLine2,Rational};
fn coordinate(y:i32)->Rational {
 let t=281_474_976_710_662.;
 let l=ExactDyadicLine2::from_f64([0.,0.],[t,t]).unwrap();
 let (_,p)=l.intersection_point_f64([0.,f64::from(y)],[t,f64::from(y)]).unwrap();
 p[0].exact_rational_ref().unwrap().clone()
}
pub fn input(k:u32)->RationalInterval {
 let q=|v| if k%2==0 {Rational::from(v)}else{coordinate(v)};
 match k/2 {0=>RationalInterval::point(q(3)),1=>RationalInterval::new(q(2),q(9)).unwrap(),2=>RationalInterval::new(q(-8),q(4)).unwrap(),_=>RationalInterval::new(q(9),q(9)).unwrap()}
}
pub fn image(k:u32, source:&RationalInterval,limit:u64)->i32{
 let (lo,hi,domain)=match k/2{0=>(27,28,DomainCoverage::Complete),1=>(22,48,DomainCoverage::Complete),2=>(0,32,DomainCoverage::Partial),_=>(48,48,DomainCoverage::Complete)};
 match source.sqrt(-4,&mut DyadicBudget::new(limit,100_000_000)) {
 Ok(r)=>{assert_eq!(r.domain,domain);assert_eq!(r.range,DyadicInterval::new(lo.into(),hi.into(),-4).unwrap());1}
 Err(IntervalError::SizeExhausted)=>2, Err(IntervalError::WorkExhausted)=>3, Err(_)=>4,
 }
}
#[unsafe(no_mangle)]
pub extern "C" fn replay(k:u32,limit:u32)->i32{image(k,&input(k),limit.into())}
#[cfg(all(feature="measure",target_arch="wasm32"))] mod allocations;
#[cfg(all(feature="measure",target_arch="wasm32"))]
#[unsafe(no_mangle)]
pub extern "C" fn heap(k:u32,limit:u32,warm:u32,stat:u32)->i64{
 use std::hint::black_box;
 let once=if warm!=0 {let x=input(k);black_box(image(k,&x,limit.into()));allocations::once(||{black_box(image(k,&x,limit.into()));})}
 else{black_box(replay(k,limit));allocations::once(||{black_box(replay(k,limit));})};
 [once.allocations as i64,once.deallocations as i64,once.reallocations as i64,once.allocated_bytes as i64,once.peak_live_bytes as i64,once.live_bytes as i64][stat as usize]
}
