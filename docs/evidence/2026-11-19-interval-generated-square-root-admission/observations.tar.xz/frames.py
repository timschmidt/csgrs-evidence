from pathlib import Path
import io,sys
from metrics import leb
def frames(p):
 raw=io.BytesIO(p.read_bytes());raw.read(8);names={};func=[]
 while t:=raw.read(1):
  b=io.BytesIO(raw.read(leb(raw)))
  if t==b'\0' and b.read(leb(b))==b'name':
   while section:=b.read(1):
    a=io.BytesIO(b.read(leb(b)))
    if section==b'\1':
     for _ in range(leb(a)):
      idx=leb(a);names[idx]=a.read(leb(a)).decode()
  if t==b'\x0a':
   for _ in range(leb(b)):
    body=io.BytesIO(b.read(leb(b)))
    for _ in range(leb(body)):leb(body);body.read(1)
    h=body.read(1)
    stack=leb(body) if h==b'\x23' and leb(body)==0 and body.read(1)==b'A' else 0
    func.append(stack)
 return {n:func[i] for i,n in names.items() if any(k in n for k in ['scaled_sqrt','4sqrt','scaled_quotient','5image','replay','reserve_reduction'])}
s=Path(__file__).resolve().parent
for tag in sys.argv[1:]:
 print(tag,frames(s/'bin'/(tag+'-1.95.0-wasm32-unknown-unknown')))
