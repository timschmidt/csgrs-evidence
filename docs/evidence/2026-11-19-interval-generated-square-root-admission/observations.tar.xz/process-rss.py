from pathlib import Path
import os,sys,json
s=Path(__file__).resolve().parent
if len(sys.argv)>1:
 import wasmtime as w
 engine=w.Engine();store=w.Store(engine);m=w.Module.from_file(engine,sys.argv[1]);api=w.Instance(store,m,[]).exports(store)
 for k in range(8):
  for limit in [64,1024]:assert api['replay'](store,k,limit) in [1,2]
else:
 rows={}
 for p in (s/'bin').glob('*-unknown-*'):
  if 'alloc' in p.name or not p.name.startswith(('fixed-','before-','unsigned-')):continue
  cmds=[[s/'venv/bin/python',__file__,p]] if 'wasm32' in p.name else [[p,str(k),str(limit),'1'] for k in range(8) for limit in [64,1024]]
  rss=[]
  for cmd in cmds:
   cmd=list(map(str,cmd)); pid=os.posix_spawn(cmd[0],cmd,os.environ,file_actions=[(os.POSIX_SPAWN_OPEN,1,'/dev/null',os.O_WRONLY,0)]); _,status,usage=os.wait4(pid,0);assert status==0;rss.append(usage.ru_maxrss)
  rows[p.name]=rss
 (s/'process-rss.json').write_text(json.dumps({'unit':'KiB process maximum RSS; Wasm includes Python and the Wasmtime compiler/runtime','workloads':rows},indent=1))
