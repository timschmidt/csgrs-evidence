from pathlib import Path
import json, math, ast
s=Path(__file__).resolve().parent
def read(n):return json.loads((s/(n+'.json')).read_text())
previous=read('power-prior')
repo=json.loads((s.parent/'csgrs/docs/research/interval-size-accounts.json').read_text())
measures=['file','code','functions']
summary={}; accounts={}; memory={}; memory_summary={}
def add(name, ref, before, after, limits, previous_charge=None, prev_image=None, keys=measures):
 info={'final_file':after['file'],'headroom':64*1024**2-after['file'],'metrics':{}}
 assert info['headroom']>=16*1024**2
 for metric in keys:
  a,b,c=(x[metric] for x in [ref,before,after])
  pos=max(0,c-b)
  history=max(0,b-a) if previous_charge is None else previous_charge[metric]+max(0,b-prev_image[metric])
  inc,tot=limits(metric,a,b)
  balance=tot-history-pos
  info['metrics'][metric]=[a,b,c,history,pos,history+pos,inc-pos,balance]
  if inc<pos or balance<0:raise RuntimeError((name,metric,info['metrics'][metric]))
 accounts[name]=info
 summary[name]={'file_bytes':after['file'],'file_delta':after['file']-before['file'],'minimum_remaining_step':min(z[6] for z in info['metrics'].values()),'minimum_remaining_cumulative':min(z[7] for z in info['metrics'].values()),'slot_headroom_bytes':info['headroom']}
def caps(inc,pi,total,pt):return lambda m,a,b:(min(inc,int(b*pi)),min(total,int(a*pt)))
xx=[read(tag+'-images') for tag in ['fixed','before','unsigned']]
for name in xx[0]:
 w='wasm' in name
 def limits(m,a,b):
  return caps(1024 if w or m=='functions' else 4096,(.05 if w else (.005 if m=='functions' else .01)),4096 if w else 8192,.10 if w else .02)(m,a,b)
 add(name,*[x[name] for x in xx],limits)
for v in ['1.95.0','stable']:
 for lane in ['native','wasm32-wasip1']:
  prefix=v+'-'+lane
  if lane=='native':
   control=read('control-owner-'+v)|{'monotone_ingress':read('before-owner-'+v)['monotone_ingress']};retained=read('unsigned-owner-'+v)
  else:control=read('baseline-wasi-images')[v];retained=read('unsigned-wasi-images')[v]
  for n,ref in [('fractional_power_ingress',previous['new_harness'][prefix]),('monotone_ingress',repo['monotone_composition_qualification']['targets'][v][lane])]:
   name=prefix+'/'+n
   add(name,ref,control[n],retained[n],caps(32768,.02,65536,.04))
   assert retained[n]['file']<=4194304
   accounts[name]['absolute_file_allowance_remaining']=4194304-retained[n]['file']
 a,b,c=[read(tag+'-indirect-'+v) for tag in ['fixed','before','unsigned']]
 a.update(read('fixed-owner-'+v));b.update(read('control-owner-'+v));c.update(read('unsigned-owner-'+v))
 prefix=v+'-native'
 for n in sorted(set(c)-{'monotone_ingress','fractional_power_ingress'}):
  orig,old,now=a.get(n),b[n],c[n]
  histories={name:previous[name][prefix][n] for name in ['ordinary','earlier_native_harnesses'] if n in previous[name][prefix]}
  if histories:
   for hist,table in histories.items():
    def prior(i):return {m:z[i] for m,z in table.items()}
    add(prefix+'/'+n+'/'+hist,prior(0),old,now,lambda m,a,b:(table[m][4]+table[m][6],table[m][5]+table[m][7]),prior(5),prior(2))
  else:
   if n=='inverse_functions':orig=read('inverse-same-workload-'+v)
   add(prefix+'/'+n,orig,old,now,caps(4096,.01,8192,.02))
for tag in ['fixed','before','unsigned']:
 assert (s/'records'/('legacy-'+tag+'.json')).exists()
legacy=[read('records/legacy-'+t) for t in ['fixed','before','unsigned']]
for n in ['tangent_cost','fractional_power_cost']:
 old=previous['legacy'][n]
 for m in sorted(set(old)|{k for k in legacy[-1][n] if k.startswith('.') and k not in ['.comment','.symtab','.strtab','.shstrtab','.relro_padding']}|set(measures)):
  if m not in legacy[0][n]:continue
  if m in old:
   z=old[m];add('legacy/'+n+'/'+m,{m:z[0]},legacy[1][n],legacy[2][n],lambda m,a,b:(z[4]+z[6],z[5]+z[7]),{m:z[5]},{m:z[2]},[m])
  else:
   add('legacy/'+n+'/'+m,*[x[n] for x in legacy],caps(1024 if m=='functions' else 4096,.005 if m=='functions' else .01,4096 if m=='functions' else 16384,.01 if m=='functions' else .02),keys=[m])
stack=[read('records/'+t) for t in ['fixed','before','unsigned']]
heap=[read(t+'-outcomes') for t in ['fixed','before','unsigned']]
for name in stack[-1]:
 v,lane=name.split('-',1);w=lane=='wasm';hname=v+('-wasm32-unknown-unknown' if w else '-x86_64-unknown-linux-gnu')+'-alloc'
 rows={};memory[name]=rows;remaining=[];maxpeak=0;maxstack=0;peakinc=0;cumul=[];steps=[]
 for n in stack[2][name]['jobs']:
  k,lim=ast.literal_eval(n)
  take=[d[name]['jobs'][n] for d in stack]
  series=[d[hname][f'{k}/{lim}']['fresh_retained'] for d in heap]
  status=[x[0] for x in take]
  rec={'status':status,'calls':{}};rows[n]=rec
  for i,kind in enumerate(['cold','warm']):
   raw=[max(z[1][i::2] if w else z[1][2*i:2*i+2]) for z in take]
   # The pthread stack slot includes one 4 KiB guard; Wasm uses the full 1 MiB.
   head=(1048576 if w else 2097152-4096)-raw[2]
   assert head>=262144
   maxstack=max(maxstack,raw[2])
   rec['calls'][kind]={'stack_bytes':raw,'remaining_stack_bytes':head}
   if len(set(status))==1:
    history=max(0,raw[1]-raw[0]);charge=max(0,raw[2]-raw[1]);cum=history+charge
    inc=min(128,int(raw[1]*.02));tot=min(256,int(raw[0]*.04))
    assert inc>=charge and tot>=cum
    remaining.append(tot-cum);cumul.append(cum);steps.append(charge)
    rec['calls'][kind]['charges_and_remaining']=[history,charge,cum,inc-charge,tot-cum]
  for i,kind in enumerate(['fresh','retained']):
   vals=[x[6*i:6*i+6] for x in series];maxpeak=max(maxpeak,vals[2][4])
   rec[kind+'_heap']=vals
   if len(set(status))==1:
    for index in [0,4,5]:
     assert max(0,vals[2][index]-vals[1][index])==0, (name,n,i,index,vals)
    peakinc=max(peakinc,vals[2][4]-vals[1][4])
  assert all(x==0 for x in (series[2][5],series[2][11]))
 memory_summary[name]={'maximum_stack_bytes':maxstack,'largest_positive_step':max(steps),'largest_cumulative_stack_charge':max(cumul),'minimum_remaining_cumulative_allowance':min(remaining),'minimum_stack_headroom':(1048576 if w else 2097152-4096)-maxstack,'maximum_requested_heap_bytes':maxpeak,'largest_peak_heap_increase':peakinc,'retained_after_drop_bytes':0}
def dump(n,d):(s/(n+'.json')).write_text(json.dumps(d,indent=1)+'\n')
dump('size-accounted',{'columns':previous['columns'],'accounts':accounts});dump('memory-accounted',memory);dump('size-summary',summary);dump('memory-summary',memory_summary)
