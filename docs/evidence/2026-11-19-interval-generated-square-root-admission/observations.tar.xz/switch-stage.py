from pathlib import Path
import subprocess as sp,sys
s=Path(__file__).resolve().parent;src=s/'src';root=s.parent/'csgrs';rev='c5e8b5168';files=['crates/hyperinterval/src/dyadic.rs','crates/hyperinterval/src/rational_admission.rs','crates/hyperinterval/tests/fractional_power_ingress.rs','crates/hyperinterval/tests/monotone_ingress.rs','crates/hyperinterval/tests/support/rational_sqrt_sources.rs','crates/hyperinterval/README.md']
def git(*a):return sp.check_output(['git','-C',src,*a])
if sys.argv[1]=='restore':
 for n in files:
  assert (src/n).read_bytes()==(root/n).read_bytes(),n
  if n.endswith('support/rational_sqrt_sources.rs'):(src/n).unlink()
  else:git('restore','--',n)
 assert not git('status','--porcelain')
elif sys.argv[1]=='candidate':
 git('switch','--detach',rev)
 for n in files:(src/n).write_bytes((root/n).read_bytes())
else:
 assert not git('status','--porcelain');git('switch','--detach',sys.argv[1])
