import json,re,subprocess as sp
from pathlib import Path
s=Path(__file__).resolve().parent
def layout(raw):
 segs=[(int(z[2],16),int(z[4],16),int(z[5],16)) for ln in raw.splitlines() if (z:=ln.split()) and z[0]=='LOAD']
 pages=set()
 for va,file,mem in segs:pages.update(range(va//4096,(va+mem+4095)//4096))
 z=next(ln.split() for ln in raw.splitlines() if ln.strip().startswith('GNU_RELRO '))
 return {'load_pages':len(pages),'initialized_load_bytes':sum(i[1] for i in segs),'relro_pages':(int(z[2],16)+int(z[5],16)+4095)//4096-int(z[2],16)//4096,'relro_file_bytes':int(z[4],16),'relro_padding':int(re.search(r'\.relro_padding\s+NOBITS\s+\w+\s+\w+\s+(\w+)',raw)[1],16)}
data={}
for name in ['legacy-tangent_cost','legacy-fractional_power_cost',*[p.name[len('unsigned-'):] for p in (s/'bin').glob('unsigned-*x86_64*')]]:
 a=[]
 for tag in ['fixed','before','unsigned']:
  fn=tag+'-'+name
  if name.startswith('legacy-'):
   raw=(s/(fn+'-layout.log')).read_text()
  else:raw=sp.check_output(['readelf','-W','-S','-l',s/'bin'/fn],text=True)
  a.append(layout(raw))
 data[name]=a
 assert a[2]['load_pages']<=a[1]['load_pages'] and a[2]['initialized_load_bytes']<=a[1]['initialized_load_bytes'],(name,a)
(s/'layout-pages.json').write_text(json.dumps(data,indent=1))
