from pathlib import Path
import json
from record import record
s=Path(__file__).resolve().parent
items=set()
for g in ['*.py','*.sh','*.c','*.rs','*.txt','*.patch','*.log','*.json','*.log.stderr','records/*.json','client/src/*.rs','client/Cargo.*','guest/Cargo.*','fuzz-in/*','unsigned-fuzz-output/*','env','source-revision']:
 items.update(p for p in s.glob(g) if p.is_file())
items.discard(s/'guest-metadata.json')
assert all(p.stat().st_size<2*1024**2 for p in items)
receipt=record('generated-square-root-admission',sorted(items),'Archive generated square-root budget regression and matched resource measurements')
(s/'receipt.json').write_text(json.dumps(receipt,indent=1));print(receipt)
