from pathlib import Path
import os,subprocess as sp,shutil,sys,json
from metrics import metrics
s=Path(__file__).resolve().parent;r=s.parent/'csgrs';p=s/'src/crates/hyperinterval/src/dyadic.rs';a=(r/'crates/hyperinterval/src/dyadic.rs').read_text();loop='''            for value in [a, b] {
                if value.is_positive() {
                    crate::rational_admission::reserve_reduction(value, budget)?;
                }
            }
'''
def scope(t):
 assert t.count(loop)==1
 t=t.replace(loop,'''            reserve_sqrt_reductions(a, b, budget)?;
''')
 i=t.index('    fn round_rational(')
 return t[:i]+'''    #[inline(never)]
    fn reserve_sqrt_reductions(a: &Rational, b: &Rational, budget: &mut DyadicBudget) -> Result<(), IntervalError> {
        for source in [a, b] {
            if source.is_positive() {
                crate::rational_admission::reserve_reduction(source, budget)?;
            }
        }
        Ok(())
    }

'''+t[i:]
both=scope(a);admit=scope((s/'guarded-dyadic.rs').read_text())
# Same endpoint work, with no stack-allocated iterator in the public function.
unroll=(s/'guarded-dyadic.rs').read_text().replace(loop,'''            if a.is_positive() {
                crate::rational_admission::reserve_reduction(a, budget)?;
            }
            if b.is_positive() {
                crate::rational_admission::reserve_reduction(b, budget)?;
            }
''')
def bench(tag,t):
 p.write_text(t);(s/(tag+'-dyadic.rs')).write_text(t);env=os.environ|{'CARGO_TARGET_DIR':str(s/'client-1.95.0')}
 with (s/(tag+'-screen.log')).open('w') as f:sp.run(['cargo','+1.95.0','build','--locked','--release','--lib','--target','wasm32-unknown-unknown'],env=env,cwd=s/'client',stdout=f,stderr=sp.STDOUT,check=True)
 out=s/'bin'/(tag+'-1.95.0-wasm32-unknown-unknown');shutil.copy2(s/'client-1.95.0/wasm32-unknown-unknown/release/sqrt_admission_client.wasm',out)
 import importlib.util
 spec=importlib.util.spec_from_file_location('stack',s/'stack-one.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 rr=m.capture(out);(s/(tag+'-screen.json')).write_text(json.dumps({'metrics':metrics(out),'cases':rr},indent=1));print(tag,rr['(0, 1024)'],flush=True)
try:
 for tag,t in [('split-admission',admit),('split-both',both),('unrolled',unroll)]:bench(tag,t)
finally:p.write_text(a)
