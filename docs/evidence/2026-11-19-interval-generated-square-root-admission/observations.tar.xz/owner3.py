from pathlib import Path
import os,subprocess as sp,json,sys,shutil
from metrics import metrics
s=Path(__file__).resolve().parent;stage=sys.argv[1];rev=sys.argv[2] if len(sys.argv)>2 else '1.95.0'
stem=stage+'-owner-'+rev
with (s/(stem+'.log')).open('w') as log:
 out=sp.check_output(['cargo','+'+rev,'build','--release','--locked','-p','hyperinterval','--all-features','--example','sqrt_cost','--test','square_roots','--test','fractional_power_ingress','--example','fractional_power_cost','--test','monotone_ingress','--message-format=json'],cwd=s/'src',env=os.environ|{'CARGO_TARGET_DIR':str(s/('target' if rev=='1.95.0' else 'stable-target'))},stderr=log,text=True)
rows={}
for d in map(json.loads,out.splitlines()):
 if not d.get('executable'):continue
 n=d['target']['name'];p=s/'bin'/(stem+'-'+n);shutil.copy2(d['executable'],p);rows[n]=metrics(p)
assert set(rows)=={'sqrt_cost','square_roots','fractional_power_ingress','fractional_power_cost','monotone_ingress'}
(s/(stem+'.json')).write_text(json.dumps(rows,indent=2))
