from pathlib import Path
import math,statistics as st,json
s=Path(__file__).resolve().parent
def read(n):return json.loads((s/(n+'.json')).read_text())
def compare(tag,x,y,owner=False):
 out={};violations=[]
 for n in x:
  a,b=x[n],y[n];wasm='wasm' in n;mono='ingress' in n;frac=5 if wasm else 2 if mono else 1
  inc=1024 if wasm else 32768 if mono else 4096
  metrics={}
  for m in ['file','code','functions']:
   limit=min(inc,math.floor(a[m]*frac/100))
   if m=='functions' and not wasm and not mono:limit=min(limit,1024,math.floor(a[m]*0.005))
   delta=b[m]-a[m];metrics[m]=[a[m],b[m],delta,limit]
   if delta>limit:violations.append([n,m,delta,limit])
  out[n]=metrics
 print(tag,[(n,d['file'][2],d['code'][2],d['functions'][2]) for n,d in out.items()]);print('violations',violations)
 return out
result={}
for suff in ['images','owner-1.95.0','owner-stable']:
 result[suff]=compare(suff,read(('before-' if suff=='images' else 'control-')+suff),read('compact-'+suff))
before=read('before-outcomes');after=read('compact-outcomes');bad=[]
for n,rows in before.items():
 if not n.endswith('-alloc'):continue
 for k,base in rows.items():
  latest=after[n][k];case=int(k.split('/')[0])
  if case%2==0 and latest!=base:bad.append([n,k,base,latest])
print('ordinary allocation differences',bad)
(s/'compact-comparison.json').write_text(json.dumps({'metrics':result,'ordinary_allocation_differences':bad},indent=2))
