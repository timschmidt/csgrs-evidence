from pathlib import Path
import subprocess as sp,os,csv,statistics as st,json
s=Path(__file__).resolve().parent;r={}
for v in ['1.95.0','stable']:
 obs={}
 for i in range(7):
  for tag in (['before','after'] if i%2==0 else ['after','before']):
   exe=s/'bin'/(tag+'-owner-'+v+'-sqrt_cost');rows=list(csv.DictReader(sp.check_output([exe],text=True).splitlines()))
   assert len(rows)==640
   for d in rows:
    assert d['completed_images']=='1024'
    k='-'.join([d['backend'],d['case'],d['precision']]);obs.setdefault(k,{}).setdefault(tag,[]).append(int(d['elapsed_ns']))
 r[v]=obs
 print(v,[(k,round(100*(st.median(vv['after'])/st.median(vv['before'])-1),1)) for k,vv in obs.items() if k.startswith('rational')],flush=True)
(s/'cost.json').write_text(json.dumps(r,separators=(',',':')))
