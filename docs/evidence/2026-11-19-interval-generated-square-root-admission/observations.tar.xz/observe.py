from pathlib import Path
import io,sys,os,subprocess as sp,json,re
import wasmtime as w
from metrics import metrics,leb
s=Path(__file__).resolve().parent
def uleb(n):
 out=bytearray()
 while n>=128:out.append(n%128+128);n>>=7
 out.append(n);return bytes(out)
def instrument(raw):
 f=io.BytesIO(raw);out=bytearray(f.read(8));stack=None;parts=[]
 while tag:=f.read(1):
  body=f.read(leb(f));parts.append((tag,body))
  if tag==b'\0':
   data=io.BytesIO(body)
   if data.read(leb(data))!=b'name': continue
   while ty:=data.read(1):
    sub=io.BytesIO(data.read(leb(data)))
    if ty!=b'\x07': continue
    for _ in range(leb(sub)):
     index=leb(sub);name=sub.read(leb(sub))
     if name==b'__stack_pointer':stack=index
 assert stack is not None
 for tag,body in parts:
  if tag==b'\x07':
   g=io.BytesIO(body);count=leb(g);body=uleb(count+1)+g.read()+b'\x02sp\x03'+uleb(stack)
  out+=tag+uleb(len(body))+body
 return out
def capture(path):
 raw=path.read_bytes();engine=w.Engine()
 module=w.Module(engine,raw);tracked=w.Module(engine,instrument(raw))
 assert not module.imports
 out={}
 for k in range(8):
  for limit in [1024,64]:
   store=w.Store(engine);api=w.Instance(store,module,[]).exports(store);plain=api['replay'](store,k,limit)
   hits=[]
   for pattern in [0x5a,0xa5]:
    store=w.Store(engine);api=w.Instance(store,tracked,[]).exports(store);stack=api['sp'].value(store);assert stack==1<<20 and not any(api['memory'].read(store,0,stack))
    mem=api['memory'];mark=bytes([pattern])*stack
    for i in range(2):
     mem.write(store,mark,0);assert api['replay'](store,k,limit)==plain;assert api['sp'].value(store)==stack
     changed=len(bytes(mem.read(store,0,stack)).lstrip(bytes([pattern])));hits.append(changed)
   out[str((k,limit))]=[plain,hits]
 return out
def native(path):
 off=re.search(r'^(\w+) T replay$',sp.check_output(['nm','-an',path],text=True),re.M)[1];out={}
 for k in range(8):
  for lim in [64,1024]:
   row=[k,lim]; args=list(map(str,row))
   actual=int(sp.check_output([path,*args,'0']))
   stack=list(map(int,sp.check_output([path,off,*args],env=os.environ|{'LD_PRELOAD':str(s/'stack.so')}).split()))
   heap=sp.check_output([str(path)+'-alloc',*args,'1'],text=True)
   out[str((k,lim))]=[actual,stack,heap]
 return out
for label in sys.argv[1:]:
 data={}
 for c in ['1.95.0','stable']:
  for platform in ['native','wasm']:
   arch='x86_64-unknown-linux-gnu' if platform=='native' else 'wasm32-unknown-unknown';path=s/'bin'/f'{label}-{c}-{arch}';data[c+'-'+platform]={'size':metrics(path),'jobs':(native if platform=='native' else capture)(path)}
 (s/'records'/f'{label}.json').write_text(json.dumps(data,indent=2))
