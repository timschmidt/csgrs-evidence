import sys,subprocess as sp,json,re
from pathlib import Path
from wasmtime import Module, Store, Engine, Instance
s=Path(__file__).resolve().parent
tag=sys.argv[1];rows={}
for v in ['1.95.0','stable']:
 for mode in ['native','wasm']:
  for measured in [False,True]:
   stem=v+'-'+('x86_64-unknown-linux-gnu' if mode=='native' else 'wasm32-unknown-unknown')+('-alloc' if measured else '')
   exe=s/'bin'/(tag+'-'+stem);r={};rows[stem]=r
   if mode=='wasm':
    engine=Engine();m=Module.from_file(engine,exe);assert len(m.imports)==0
    store=Store(engine);inst=Instance(store,m,[]);exports=inst.exports(store)
   for k in range(8):
    for cap in [64,1024]:
     key=f'{k}/{cap}';ret=int(sp.check_output([exe,str(k),str(cap),'0'])) if mode=='native' else exports['replay'](store,k,cap)
     # The third kind clips a negative lower bound and admits its positive upper.
     assert ret==(2 if tag=='unsigned' and k%2 and cap==64 else 1),(tag,stem,k,cap,ret)
     r[key]={'status':ret}
     if measured:
      if mode=='native':
       out=sp.check_output([exe,str(k),str(cap),'1'],text=True);a=re.findall(r'(?:allocations|deallocations|reallocations|allocated_bytes|peak_live_bytes|live_bytes): (\d+)',out);assert len(a)==12,out;r[key]['fresh_retained']=list(map(int,a))
      else:r[key]['fresh_retained']=[exports['heap'](store,k,cap,w,i) for w in [0,1] for i in range(6)]
(s/(tag+'-outcomes.json')).write_text(json.dumps(rows,indent=1))
