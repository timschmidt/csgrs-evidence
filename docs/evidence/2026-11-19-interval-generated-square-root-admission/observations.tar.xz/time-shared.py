from pathlib import Path
import os,json,subprocess as sp,statistics as st
s=Path(__file__).resolve().parent;rows={}
for v in ['1.95.0','stable']:
 obs={}
 for k in range(8):
  for j in range(13):
   for tag in (['before','shared'] if j%2==0 else ['shared','before']):
    exe=s/'bin'/(tag+'-'+v+'-x86_64-unknown-linux-gnu');times=4000
    a,b=map(int,sp.check_output([exe,str(k),'1024',str(times)]).split())
    obs.setdefault(str(k),{}).setdefault(tag,[]).append([a/times,b/times])
 rows[v]=obs
 print(v,[(k,[round(100*(st.median(z[i] for z in rr['shared'])/st.median(z[i] for z in rr['before'])-1),1) for i in [0,1]]) for k,rr in obs.items()],flush=True)
(s/'shared-times.json').write_text(json.dumps(rows,indent=1))
