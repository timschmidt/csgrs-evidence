from pathlib import Path
import os,json,subprocess as sp,sys
from metrics import metrics
s=Path(__file__).resolve().parent;tag=sys.argv[1];rows={}
for v in ['1.95.0','stable']:
 env=os.environ|{'CARGO_TARGET_DIR':str(s/('wasi-'+v)),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot '+str(s/('sysroot-'+v))}
 with (s/(tag+'-wasi-'+v+'.log')).open('w') as f:
  cmd=['cargo','+'+v,'build','--offline','--release','--all-features','--target','wasm32-wasip1','--test','fractional_power_ingress','--message-format=json']
  if (s/'guest/Cargo.lock').exists():cmd.append('--locked')
  out=sp.check_output(cmd,env=env,cwd=s/'guest',stderr=f,text=True)
 exe=next(Path(d['executable']) for d in map(json.loads,out.splitlines()) if d.get('executable'));rows[v]=metrics(exe)
 sp.run([s/'venv/bin/python',s/'run-wasi.py',exe,s/(tag+'-guest-'+v+'.log'),'--test-threads=1'],env=env,check=True)
(s/(tag+'-wasi-images.json')).write_text(json.dumps(rows,indent=2))
