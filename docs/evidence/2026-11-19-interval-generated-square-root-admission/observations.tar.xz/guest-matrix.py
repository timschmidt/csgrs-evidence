from pathlib import Path
import os,json,subprocess as sp,sys
from metrics import metrics
s=Path(__file__).resolve().parent;tag=sys.argv[1];rows={}
for v in ['1.95.0','stable']:
 env=os.environ|{'CARGO_TARGET_DIR':str(s/('wasi-'+v)),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot '+str(s/('sysroot-'+v))}
 with (s/(tag+'-wasi-'+v+'.log')).open('w') as f:
  cmd=['cargo','+'+v,'build','--offline','--release','--all-features','--target','wasm32-wasip1','--tests','--message-format=json']
  if (s/'guest/Cargo.lock').exists():cmd.append('--locked')
  out=sp.check_output(cmd,env=env,cwd=s/'guest',stderr=f,text=True)
 data={}
 for d in map(json.loads,out.splitlines()):
  if not d.get('executable'):continue
  exe=Path(d['executable']);name=d['target']['name'];data[name]=metrics(exe)
  sp.run([s/'venv/bin/python',s/'run-wasi.py',exe,s/(tag+'-guest-'+v+'-'+name+'.log'),'--test-threads=1'],env=env,check=True)
 assert set(data)=={'fractional_power_ingress','monotone_ingress'};rows[v]=data
(s/(tag+'-wasi-images.json')).write_text(json.dumps(rows,indent=2))
