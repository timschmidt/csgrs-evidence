cd /mnt/development/csgrs
export CARGO_TARGET_DIR=/mnt/development/.sens-target
run() { echo "== $*"; out=$("$@" 2>&1); rc=$?; echo "$out" | grep -E "^(error|warning)" -A6 | head -30; p=$(echo "$out" | grep -E "^test result" | awk '{s+=$4; f+=$6} END {print "tests passed", s+0, "failed", f+0}'); [ -n "$p" ] && echo "$p"; echo "rc=$rc"; }
for tc in stable 1.95.0; do
  run cargo +$tc fmt -p hyperdynamics -- --check
  run cargo +$tc check --locked -p hyperdynamics --no-default-features --all-targets
  for f in flow-sensitivity flow-sensitivity,coordinates flow-sensitivity,taylor-evolution flow-sensitivity,adaptive-taylor flow-sensitivity,qr-evolution flow-sensitivity,serde,qr-evolution; do
    run cargo +$tc clippy --locked -p hyperdynamics --no-default-features --features $f --all-targets -- -D warnings
  done
  run cargo +$tc clippy --locked -p hyperdynamics --all-targets --no-default-features -- -D warnings
  run cargo +$tc clippy --locked -p hyperdynamics --all-targets --all-features -- -D warnings
  run cargo +$tc test --locked -p hyperdynamics --no-default-features
  run cargo +$tc test --locked -p hyperdynamics --all-targets --all-features
  run cargo +$tc test --locked -p hyperdynamics --release --lib --tests --all-features
  run cargo +$tc test --locked -p hyperdynamics --doc --all-features
  run cargo +$tc doc --locked -p hyperdynamics --no-deps --all-features
done
run cargo +stable fmt --all -- --check
run cargo +stable check --locked --workspace --all-targets
run cargo +stable clippy --locked --all-features -- -D warnings
