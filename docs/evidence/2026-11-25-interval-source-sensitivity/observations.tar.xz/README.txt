Sensitivity of Taylor, adaptive Taylor, fixed-chart and QR evolutions
25 November 2026, csgrs branch chart-sensitivity, based on main 7a4b89b71.

source/              sensitivity.rs, flow_sensitivity.rs tests and perf_atlas.rs as committed.
flow_sensitivity-tests.log   13 sensitivity tests, stable, all features.
validate.sh / .log   Full validation on stable and 1.95.0 (fmt, clippy feature
                     combinations, 188 all-target and release tests, doc,
                     workspace check, root clippy).
mutations/           mutate.py and one log per deliberate defect; all seven fail
                     at least one test.
timing/              Perf atlas JSON, base = 7a4b89b71, cand = this change.
                     Rounds 1-2: horizon (-h) and series-terms (-t) sweeps,
                     first candidate (per-step copies). Rounds 3-9: series terms,
                     unpinned; 7-9 after preallocation. Rounds 10-13: pinned to
                     one core with taskset -c 4, final candidate: fastest-of-
                     rounds ratio +0.8% (geometric mean, 0.5%..1.2%).
                     compare*.log: example and atlas file and text sizes.
                     source-method-quick.json: the new by-source sweep (quick).
