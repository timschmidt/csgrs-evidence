import sys
p, name = sys.argv[1], sys.argv[2]
s = open(p).read()
muts = {
 "drop-transition": ("chain = product(&entry, &chain, precision, &mut budget.arithmetic)?;", "let _ = entry;"),
 "transition-right": ("chain = product(&entry, &chain, precision, &mut budget.arithmetic)?;", "chain = product(&chain, &entry, precision, &mut budget.arithmetic)?;"),
 "no-conjugation": ("                budget.graph.charge(pair_work)?;\n                let left", "                if b.is_empty() || a.is_empty() || true { return Ok(p.clone()); }\n                budget.graph.charge(pair_work)?;\n                let left"),
 "swap-chart-inverse": ("let left = product(a, p, precision, &mut budget.arithmetic)?;\n                product(&left, b, precision, &mut budget.arithmetic)", "let left = product(b, p, precision, &mut budget.arithmetic)?;\n                product(&left, a, precision, &mut budget.arithmetic)"),
 "native-compose-right": ("let end_chain = product(&local_end, previous,", "let end_chain = product(previous, &local_end,"),
 "transition-always": ("QrFrameChoice::Retained => None,", "QrFrameChoice::Retained => Some(window.transition().unwrap().relation().matrix()),"),
 "incoming-chart": ("chart: Some(&branch.chart().transformation().change().to_source),", "chart: Some(&window.selection().chart().transformation().change().to_source),"),
}
old, new = muts[name]
assert s.count(old) == 1, name
open(p, "w").write(s.replace(old, new))
