set -e
SP=/tmp/claude-1000/-mnt-development/374ec7d8-3b58-4db7-a419-a5fe884f8bb0/scratchpad/probe
cd /mnt/development/.sens-base
CARGO_TARGET_DIR=/mnt/development/.sens-base-target cargo +stable build --locked --release -p hyperdynamics --all-features --example perf_atlas --example flow_sensitivity 2>&1 | tail -1
cd /mnt/development/csgrs
CARGO_TARGET_DIR=/mnt/development/.sens-target cargo +stable build --locked --release -p hyperdynamics --all-features --example perf_atlas --example flow_sensitivity 2>&1 | tail -1
for f in flow_sensitivity perf_atlas; do
  echo "$f base $(stat -c %s /mnt/development/.sens-base-target/release/examples/$f) cand $(stat -c %s /mnt/development/.sens-target/release/examples/$f)"
  echo "$f text base $(size -A /mnt/development/.sens-base-target/release/examples/$f | awk '$1==".text"{print $2}') cand $(size -A /mnt/development/.sens-target/release/examples/$f | awk '$1==".text"{print $2}')"
done
for round in 1 2; do
  for side in base cand; do
    if [ $side = base ]; then bin=/mnt/development/.sens-base-target/release/examples/perf_atlas; else bin=/mnt/development/.sens-target/release/examples/perf_atlas; fi
    $bin --out $SP/$side-$round-h.json --filter "initial-state sensitivity by horizon" > /dev/null 2>&1; $bin --out $SP/$side-$round-t.json --filter "initial-state sensitivity by series" > /dev/null 2>&1
  done
done
echo done
