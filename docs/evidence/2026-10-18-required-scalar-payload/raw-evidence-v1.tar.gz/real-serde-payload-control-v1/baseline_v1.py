"""Reproduce the new public-boundary tests before changing production."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from cargo_harness_v1 import Harness,cargo,dump,sha
h=Harness('baseline-v1',W/'source-pins-v1.json.gz')
keys=h.build('build',[ 'test','--locked','--offline','-p','hyperreal','--release','--features','serde','--test','serde_payload'])
assert len(keys)==1
rows,out,err,r=h.test('run',keys[0],allow_failure=True,limit=60)
assert rows==[('FAILED','2','6','0','0','0')],rows
dump(h.R/'result-v1.json',{'passed':False,'expected_baseline_failure':True,'summary':rows,'commands':h.commands,'production_source_changed':False,'helper_sha256':sha(Path(__file__)),'candidate_applied':False})
print(json.dumps({'baseline_new_failures':6,'valid_controls_passed':2,'production_source_changed':False}),flush=True)
