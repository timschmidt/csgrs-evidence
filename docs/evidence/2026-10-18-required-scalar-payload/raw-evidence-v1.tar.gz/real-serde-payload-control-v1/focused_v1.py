"""Verify the required-payload repair before the wider actual-source suites."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from cargo_harness_v1 import Harness,cargo,dump,sha
h=Harness('focused-v1',W/'source-pins-v3.json.gz');summaries={}
for name,crate,flags,targets in [
 ('scalar','hyperreal',['--features','serde'],['serde_payload']),
 ('curve','hypercurve',['--features','svg'],['svg_scalar_failures','hypercurve_svg']),
 ('predicate','hyperlimit',['--all-features'],['real_representations']),
]:
 args=['test','--release','--locked','--offline','-p',crate]+flags
 for target in targets:args+=['--test',target]
 keys=h.build(name+'-build',args)
 for i,key in enumerate(keys):
  if not h.artifacts[key]['profile']['test']:continue
  rows,out,err,r=h.test(name+'-'+str(i),key,limit=60)
  assert rows and all(row[0]=='ok' and row[2]=='0' and row[3]=='0' for row in rows),rows
  summaries[key]=rows
 assert len(keys)>=len(targets)
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'summaries':summaries,'commands':h.commands,'artifacts':h.artifacts,'helper_sha256':sha(Path(__file__)),'affine_candidate_applied':False,'actual_main_source':True,'full_plan_complete':False})
print(json.dumps({'passed':True,'summaries':summaries}),flush=True)
