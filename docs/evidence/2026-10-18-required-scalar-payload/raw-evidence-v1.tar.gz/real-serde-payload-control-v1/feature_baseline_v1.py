"""Reproduce only the feature-specific compile failure on committed source."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from feature_baseline_harness_v1 import Harness,cargo,dump,sha
h=Harness('feature-baseline-v1',W/'source-pins-v3.json.gz')
out,err,r=h.execute('curved-outline',[cargo,'clippy','--release','--locked','-p','hypercircuit','--features','interchange','--test','curved_outline','--','-D','warnings'],allow_failure=True)
assert r['exit_code']==101
assert 'unresolved imports' in err and 'FabricationExportOptions' in err and 'geometry' in err
dump(h.R/'result-v1.json',{'baseline_failure_reproduced':True,'commands':h.commands,'committed_revision':'7ce3ff7f000b59d8b497f42b3f9bd9c135fc71fe','source_overlays_sha256':sha(W/'feature-baseline-overlays-v1.json'),'failure':'Interchange-only curved_outline imports geometry-gated API; its cubic_exterior helper is likewise only consumed under geometry.','no_test_bodies_changed':True})
print('Committed-source interchange-only feature failure reproduced.',flush=True)
