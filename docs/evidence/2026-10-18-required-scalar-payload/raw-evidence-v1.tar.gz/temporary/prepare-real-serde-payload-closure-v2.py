"""Prepare the updated closure for the scalar and consumer feature-gate repair."""
import ast
from pathlib import Path
p=Path('/tmp/close-real-serde-payload-v1.py')
s=p.read_text()
s=s.replace("'crates/hyperreal/tests/serde_payload.rs','crates/hypercurve/tests/svg_scalar_failures.rs',","'crates/hyperreal/tests/serde_payload.rs','crates/hypercurve/tests/svg_scalar_failures.rs',\n 'crates/hypercircuit/tests/curved_outline.rs',")
s=s.replace('source-pins-v3','source-pins-v4')
for phase in ['scalar','consumers','msrv','boundary']:
 s=s.replace('real-serde-payload-'+phase+'-v1/result-v1.json','real-serde-payload-'+phase+'-v2/result-v1.json')
needle="assert consumers['packages']['hyperlimit']['passed']==365"
s=s.replace(needle,needle+"\nassert consumers['packages']['hypercircuit']['passed']==60\nassert consumers['feature_gate_matrix']['geometry']['summaries']==[['ok','4','0','0','0','0']]\nassert consumers['feature_gate_matrix']['all']['summaries']==[['ok','5','0','0','0','0']]\nassert read(N/'real-serde-payload-feature-baseline-v1/result-v1.json')['baseline_failure_reproduced']")
s=s.replace("'real-serde-payload-baseline-v1-build','real-serde-payload-baseline-v2-run',","'real-serde-payload-baseline-v1-build','real-serde-payload-baseline-v2-run',\n 'real-serde-payload-consumers-v1-hypercircuit-clippy','real-serde-payload-feature-baseline-v1-curved-outline',")
s=s.replace("for pattern in ['prepare-real-serde-payload-*.py',","for pattern in ['prepare-real-serde-payload-*.py','prepare-payload-feature-baseline-*.py',")
s=s.replace("roots.append(Path(__file__))","roots+=sorted(Path('/tmp').glob('close-real-serde-payload-*.py'))")
s=s.replace("generated=path.is_relative_to(U/'target') or path.is_relative_to(U/'target-msrv-v1')","generated=any(path.is_relative_to(U/name) for name in ['target','target-msrv-v2','target-feature-baseline-v1'])")
s=s.replace("Retain typed rejection of a missing opaque Real payload; the independent present-graph domain blocker remains open.","Retain typed rejection of a missing opaque Real payload and repair the reproduced circuit test feature declarations; the present-graph domain blocker remains open.")
s=s.replace("'consumer_cargo':consumers['packages'],","'consumer_cargo':consumers['packages'],'consumer_feature_gate_matrix':consumers['feature_gate_matrix'],\n 'consumer_feature_gate_repair':{'baseline_failure_reproduced':True,'all_test_bodies_and_original_gates_byte_identical':True,'interchange_tests_passed':2,'geometry_tests_passed':4,'all_feature_tests_passed':5,'scalar_and_affected_consumer_checks_repeated_after_final_edit':True},")
s=s.replace("'Hypercircuit interchange all targets'],","'Hypercircuit interchange all targets','Hypercircuit interchange+geometry curved_outline','Hypercircuit all features curved_outline'],")
s=s.replace("'admitted_scope':'Required opaque payload at deserialization only.'","'admitted_scope':'Required opaque payload at deserialization, plus consumer test declarations aligned with their existing feature gates.'")
s=s.replace("['contract-v1.md','tmp-contract-v1.json']","['contract-v1.md','feature-contract-v1.md','tmp-contract-v1.json']")
needle="No existing test, policy, fixture or ignore marker was weakened."
s=s.replace(needle,needle+"""

An interchange-only circuit Clippy check exposed imports of geometry-only
APIs in curved_outline. A separate target reproduces the same failure with
committed scalar sources. Gate those imports and their geometry-only helper;
all test bodies and existing test gates are byte-identical. The two
interchange, four geometry, and five all-feature curved-outline tests pass,
including the original DRC/CAM assertions. The full scalar and affected
consumer checks were repeated after this final configuration edit.
""")
s=s.replace("'consumers':consumers['packages'],","'consumers':consumers['packages'],'consumer_feature_gate_matrix':consumers['feature_gate_matrix'],")
ast.parse(s)
out=Path('/tmp/close-real-serde-payload-v2.py')
with out.open('x') as f:f.write(s)
print('Prepared v2 closure; execution still requires all final-source checks to pass.')
