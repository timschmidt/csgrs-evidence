"""Prepare affected consumers and compiler-floor checks without running them."""
import ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'real-serde-payload-control-v1'
consumer='''"""Run affected predicate, curve interchange and circuit interchange consumers."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from cargo_harness_v1 import Harness,cargo,dump,rows
assert json.loads((W.parent/'real-serde-payload-scalar-v1/result-v1.json').read_text())['passed']
h=Harness('consumers-v1',W/'source-pins-v3.json.gz');summaries={};packages={}
for name,flags,targets in [
 ('hyperlimit',['--all-features'],[]),
 ('hypercircuit',['--features','interchange'],['interchange','event_interchange','package','edit']),
]:
 args=['test','--release','--locked','--offline','-p',name]+flags
 if targets:
  for target in targets:args+=['--test',target]
 else:args+=['--tests']
 keys=h.build(name+'-build',args);h.bind_programs(keys);counts=[]
 for i,key in enumerate(keys):
  if not h.artifacts[key]['profile']['test']:continue
  result,_,_,_=h.test(name+'-test-'+str(i),key)
  assert result and all(row[0]=='ok' and row[2]=='0' for row in result),result
  summaries[key]=result;counts.append(result[-1])
 h.execute(name+'-clippy',[cargo,'clippy','--release','--locked','-p',name,'--all-targets']+flags+['--','-D','warnings'])
 out,_,_=h.execute(name+'-doctests',[cargo,'test','--release','--locked','-p',name,'--doc']+flags+['--','--test-threads=1'])
 docs=rows(out);assert docs and all(r[0]=='ok' and r[2]=='0' for r in docs)
 h.execute(name+'-docs',[cargo,'doc','--release','--locked','-p',name,'--no-deps']+flags)
 packages[name]={'passed':sum(int(r[1]) for r in counts),'ignored':sum(int(r[3]) for r in counts),'doctests':docs,'features':flags,'selected_targets':targets or ['all test targets']}
 dump(h.R/'summaries-v1.json',{'summaries':summaries,'packages':packages})
h.execute('hypercurve-clippy',[cargo,'clippy','--release','--locked','-p','hypercurve','--features','svg','--all-targets','--','-D','warnings'])
h.execute('hypercurve-docs',[cargo,'doc','--release','--locked','-p','hypercurve','--features','svg','--no-deps'])
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'commands':h.commands,'artifacts':h.artifacts,'main_source_without_overlays':True,'full_native_workloads_rerun':False,'full_plan_complete':False})
print(json.dumps({'passed':True,'packages':packages}),flush=True)
'''
ast.parse(consumer)
with (W/'consumers_v1.py').open('x') as f:f.write(consumer)
msrv=Path('/tmp/qualify-affine-cargo-msrv-v1.py').read_text()
msrv=msrv.replace("explicit-affine-cargo-control-v1","real-serde-payload-control-v1")
msrv=msrv.replace("/tmp/csgrs-explicit-affine-cargo-20261018-v1","/tmp/csgrs-real-serde-payload-20261018-v1")
msrv=msrv.replace("assert json.loads((W/'malformed-serde-review-v1.json').read_text())['new_failure_masking'] is False\n","")
msrv=msrv.replace("affine-cargo-downstream-v2","real-serde-payload-consumers-v1")
msrv=msrv.replace("affine_cargo_harness_v1","cargo_harness_v1")
msrv=msrv.replace("affine_msrv_harness_v1","payload_msrv_harness_v1")
msrv=msrv.replace("h=Harness('msrv-v1')","h=Harness('msrv-v1',W/'source-pins-v3.json.gz')")
msrv=msrv.replace("candidate scalar","required-payload repair")
msrv=msrv.replace("'production_source_changed':False","'production_source_changed':True")
ast.parse(msrv)
with (W/'msrv_v1.py').open('x') as f:f.write(msrv)
print('Prepared predicate suite, affected interchange targets, lints/docs and Rust 1.95 checks.')
