"""Reproduce the interchange target failure on the committed production sources."""
import ast,json,sys,subprocess
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'real-serde-payload-control-v1';U=Path('/tmp/csgrs-real-serde-payload-20261018-v1')
sys.path.insert(0,str(W))
from cargo_harness_v1 import sha,dump,resources,reasons
assert not reasons(resources())
overlays={}
for relative in ['crates/hyperreal/src/real/arithmetic/representation.rs','crates/hyperreal/src/serde.rs','crates/hyperreal/README.md']:
 data=subprocess.check_output(['git','show','7ce3ff7f0:'+relative],cwd=O)
 copy=W/('feature-baseline-'+relative.replace('/','--'))
 with copy.open('xb') as f:f.write(data)
 overlays[str(O/relative)]={'copy':str(copy),'sha256':sha(copy)}
dump(W/'feature-baseline-overlays-v1.json',overlays)
s=(W/'cargo_harness_v1.py').read_text()
s=s.replace("self.target=U/'target'","self.target=U/'target-feature-baseline-v1'")
s=s.replace("compiler=json.loads(", "overlays=json.loads((W/'feature-baseline-overlays-v1.json').read_text())\ncompiler=json.loads(",1)
s=s.replace("'source_overlays':{},","'source_overlays':overlays,")
s=s.replace("'actual_main_source_without_overlays':True","'committed_scalar_baseline_overlay':True")
s=s.replace("    def verify(self):","    def verify(self):\n        assert all(sha(v['copy'])==v['sha256'] for v in overlays.values())")
needle="        if binary:\n            for dest,src in self.runtime_bindings.items():"
assert s.count(needle)==1
s=s.replace(needle,"        for dest,entry in overlays.items():argv+=['--ro-bind',entry['copy'],dest]\n"+needle)
ast.parse(s)
with (W/'feature_baseline_harness_v1.py').open('x') as f:f.write(s)
(U/'target-feature-baseline-v1').mkdir()
driver='''"""Reproduce only the feature-specific compile failure on committed source."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from feature_baseline_harness_v1 import Harness,cargo,dump,sha
h=Harness('feature-baseline-v1',W/'source-pins-v3.json.gz')
out,err,r=h.execute('curved-outline',[cargo,'clippy','--release','--locked','-p','hypercircuit','--features','interchange','--test','curved_outline','--','-D','warnings'],allow_failure=True)
assert r['exit_code']==101
assert 'unresolved imports' in err and 'FabricationExportOptions' in err and 'geometry' in err
dump(h.R/'result-v1.json',{'baseline_failure_reproduced':True,'commands':h.commands,'committed_revision':'7ce3ff7f000b59d8b497f42b3f9bd9c135fc71fe','source_overlays_sha256':sha(W/'feature-baseline-overlays-v1.json'),'failure':'Interchange-only curved_outline imports geometry-gated API; its cubic_exterior helper is likewise only consumed under geometry.','no_test_bodies_changed':True})
print('Committed-source interchange-only feature failure reproduced.',flush=True)
'''
ast.parse(driver)
with (W/'feature_baseline_v1.py').open('x') as f:f.write(driver)
