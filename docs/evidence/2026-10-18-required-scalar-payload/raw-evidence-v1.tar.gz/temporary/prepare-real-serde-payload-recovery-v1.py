"""Qualify the final source after the independently reproduced consumer feature fix."""
import ast,gzip,json,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'real-serde-payload-control-v1'
sys.path.insert(0,str(W))
from cargo_harness_v1 import sha,dump,resources,reasons
assert not reasons(resources())
assert json.loads((N/'real-serde-payload-feature-baseline-v1/result-v1.json').read_text())['baseline_failure_reproduced']
key='crates/hypercircuit/tests/curved_outline.rs'
original=subprocess.check_output(['git','show','7ce3ff7f0:'+key],cwd=O).decode()
current=(O/key).read_text()
# The helpers and all test bodies are byte-identical. Only geometry imports
# and the already geometry-only cubic_exterior helper acquire their gate.
assert original[original.index('fn p('):]==current[current.index('fn p('):].replace('#[cfg(feature = "geometry")]\nfn cubic_exterior()', 'fn cubic_exterior()')
with (W/'curved_outline_before_feature_fix_v1.rs').open('x') as f:f.write(original)
pins=json.loads(gzip.decompress((W/'source-pins-v3.json.gz').read_bytes()))
assert {p for p,h in pins.items() if sha(O/p)!=h}=={key}
pins[key]=sha(O/key)
with (W/'source-pins-v4.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
with (W/'feature-contract-v1.md').open('x') as f:f.write("""# Circuit test feature declarations

Owner: Hypercircuit test configuration, P35/P37. The interchange-only target
imports geometry-only APIs despite its geometry tests already being gated.
This compile failure is reproduced on committed scalar source in a separate
target, before editing the consumer test. Scalar production is not its cause.

Gate only those imports and the helper used solely by the geometry tests.
Every test body, fixture, policy, assertion and existing test gate stays
byte-identical. Two interchange tests must run without geometry; all four
geometry tests and all five all-feature tests remain executable, including
the original DRC/CAM assertions in the all-feature build.

Rerun the full scalar qualification and affected consumer qualification
after this final edit; retain the original failed command and the independent
baseline reproduction. Use the same source/dependency pins and resource
ceilings. No optimization or performance claim.
""")
s=(W/'scalar_v1.py').read_text().replace("'scalar-v1'","'scalar-v2'").replace('source-pins-v3','source-pins-v4')
ast.parse(s)
with (W/'scalar_v2.py').open('x') as f:f.write(s)
s=(W/'consumers_v1.py').read_text().replace('real-serde-payload-scalar-v1','real-serde-payload-scalar-v2').replace("'consumers-v1'","'consumers-v2'").replace('source-pins-v3','source-pins-v4')
s=s.replace("['interchange','event_interchange','package','edit']", "['interchange','event_interchange','package','edit','curved_outline']")
extra='''feature_matrix={}
for label,flags,expected in [
 ('geometry',['--features','interchange,geometry'],4),
 ('all',['--all-features'],5),
]:
 keys=h.build('curved-'+label+'-build',['test','--release','--locked','-p','hypercircuit','--test','curved_outline']+flags)
 tests=[key for key in keys if h.artifacts[key]['profile']['test']]
 assert len(tests)==1
 result,_,_,_=h.test('curved-'+label,tests[0])
 assert result==[('ok',str(expected),'0','0','0','0')],result
 feature_matrix[label]={'features':flags,'summaries':result,'test_bodies_unchanged':True}
 h.execute('curved-'+label+'-clippy',[cargo,'clippy','--release','--locked','-p','hypercircuit','--test','curved_outline']+flags+['--','-D','warnings'])
'''
needle="h.execute('hypercurve-clippy'"
assert s.count(needle)==1
s=s.replace(needle,extra+needle)
s=s.replace("'packages':packages,'summaries':summaries,'commands':h.commands", "'packages':packages,'feature_gate_matrix':feature_matrix,'summaries':summaries,'commands':h.commands")
ast.parse(s)
with (W/'consumers_v2.py').open('x') as f:f.write(s)
s=(W/'msrv_v1.py').read_text().replace('real-serde-payload-consumers-v1','real-serde-payload-consumers-v2').replace("'msrv-v1'","'msrv-v2'").replace('target-msrv-v1','target-msrv-v2').replace('source-pins-v3','source-pins-v4').replace('payload_msrv_harness_v1','payload_msrv_harness_v2')
ast.parse(s)
with (W/'msrv_v2.py').open('x') as f:f.write(s)
s=Path('/tmp/real-serde-payload-boundary-v1.py').read_text().replace('real-serde-payload-scalar-v1','real-serde-payload-scalar-v2').replace("'boundary-v1'","'boundary-v2'").replace('boundary-build-v1','boundary-build-v2').replace('source-pins-v3','source-pins-v4')
ast.parse(s)
with Path('/tmp/real-serde-payload-boundary-v2.py').open('x') as f:f.write(s)
dump(W/'feature-fix-preparation-v1.json',{'helper_sha256':sha(Path(__file__)),'original_test_source_sha256':sha(W/'curved_outline_before_feature_fix_v1.rs'),'final_test_source_sha256':sha(O/key),'source_pins_sha256':sha(W/'source-pins-v4.json.gz'),'all_test_bodies_and_original_gates_unchanged':True,'only_change_after_scalar_v1':key,'scalar_and_consumer_checks_will_be_repeated_after_final_edit':True})
print('Prepared final-source scalar, consumer, three-feature curved-outline and compiler-floor validation.',flush=True)
