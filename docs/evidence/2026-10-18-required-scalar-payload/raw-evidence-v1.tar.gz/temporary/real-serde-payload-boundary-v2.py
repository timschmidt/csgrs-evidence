"""Compare the retained baseline with the repair; preserve the remaining domain defect."""
import json,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'real-serde-payload-control-v1'
sys.path.insert(0,str(W))
from cargo_harness_v1 import Harness,O,U,compiler,sha,dump,file_state
assert json.loads((N/'real-serde-payload-scalar-v2/result-v1.json').read_text())['passed']
h=Harness('boundary-v2',W/'source-pins-v4.json.gz')
old=json.loads((N/'explicit-affine-cargo-control-v1/serialization-input-preservation-v1.json').read_text())['libraries']['baseline']
baseline=Path('/tmp/csgrs-explicit-affine-cargo-20261018-v1/frozen/malformed-serde-v2/library-inputs/baseline')/Path(old['original_path']).name
assert sha(baseline)==old['sha256']
libraries={'baseline':{'path':str(baseline),'deps':str(Path(old['original_path']).parent),'sha256':sha(baseline)}}
for line in (N/'logs/real-serde-payload-scalar-v2-all-build/stdout').read_text().splitlines():
 if not line.startswith('{'):continue
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact' and row['target']['name']=='hyperreal' and row['target']['kind']==['lib']:
  paths=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
  if paths:
   assert len(paths)==1
   p=paths[0];libraries['repair']={'path':str(p),'deps':str(p.parent),'sha256':sha(p),'features':row['features']}
assert set(libraries)=={'baseline','repair'}
source=Path('/tmp/real-serde-payload-boundary-probe-v1.rs');source_hash=sha(source)
build=U/'boundary-build-v2';assert not build.exists();build.mkdir()
outputs={}
for variant,lib in libraries.items():
 folder=h.A/variant;folder.mkdir()
 copy=folder/Path(lib['path']).name
 assert sha(lib['path'])==lib['sha256'];shutil.copy2(lib['path'],copy)
 assert sha(copy)==lib['sha256'];lib['frozen_copy']=str(copy)
 binary=build/variant
 h.execute(variant+'-compile',[compiler['additional_environment']['RUSTC'],'--crate-name','payload_boundary','--edition=2024','-C','opt-level=3','-D','warnings',source,'--extern','hyperreal='+str(copy),'-L','dependency='+lib['deps'],'-o',binary],limit=60)
 frozen=folder/'probe';shutil.copy2(binary,frozen);digest=sha(binary);assert sha(frozen)==digest
 h.states[str(frozen)]=file_state(frozen)
 h.artifacts[variant]={'copy':str(frozen),'sha256':digest,'features':lib.get('features',[]),'target':{'name':'payload_boundary','kind':['bin']},'profile':{'test':False},'direct_probe_build':True}
 dump(h.A/'executables-v1.json',h.artifacts)
 out,err,_=h.execute(variant+'-run',[frozen],binary=True,limit=60)
 outputs[variant]={'stdout':out,'stderr':err}
 assert sha(source)==source_hash and sha(copy)==lib['sha256'] and sha(frozen)==digest
assert outputs['baseline']['stdout'].splitlines()==[
 'missing-json\tdecoded','missing-json/refinement\tpanic',
 'negative-root\tdecoded','negative-root/refinement\tpanic',
 'svg-cbor-coordinate\tdecoded',
],outputs
assert outputs['repair']['stdout'].splitlines()==[
 'missing-json\tErr(ParseError)',
 'negative-root\tdecoded','negative-root/refinement\tpanic',
 'svg-cbor-coordinate\tErr(ParseError)',
],outputs
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'libraries':libraries,'source_sha256':source_hash,'outputs':outputs,'commands':h.commands,'artifacts':h.artifacts,'svg_fixture_was_structurally_decodable_before_repair':True,'missing_payload_error_is_now_typed':True,'negative_root_domain_defect_remains':True,'affine_candidate_admitted':False})
print(json.dumps({'missing_payload_typed':True,'svg_fixture_regression_confirmed':True,'negative_root_blocker_remains':True}),flush=True)
