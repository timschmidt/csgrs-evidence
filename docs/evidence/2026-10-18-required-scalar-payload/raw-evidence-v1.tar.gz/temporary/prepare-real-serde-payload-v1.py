"""Prepare a fresh, contained Cargo target for the required-payload invariant."""
import ast,gzip,json,os,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
OLD=N/'explicit-affine-cargo-control-v1';W=N/'real-serde-payload-control-v1'
U=Path('/tmp/csgrs-real-serde-payload-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(OLD))
from validation_runner_v1 import resources,reasons,sha
assert not reasons(resources())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=O).decode().strip()=='7ce3ff7f000b59d8b497f42b3f9bd9c135fc71fe'
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
assert not W.exists() and not U.exists()
pins=json.loads(gzip.decompress((OLD/'main-source-pins-v1.json.gz').read_bytes()))
assert len(pins)==2654 and all(sha(O/p)==h for p,h in pins.items())
pins['crates/hyperreal/tests/serde_payload.rs']=sha(O/'crates/hyperreal/tests/serde_payload.rs')
registry=json.loads(gzip.decompress((OLD/'registry-inputs-v1.json.gz').read_bytes()))
assert len(registry)==48478 and all(sha(p)==h for p,h in registry.items())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
W.mkdir();U.mkdir()
for name in ['target','cargo-home','gmp-cache','xdg-cache','scratch','frozen']:(U/name).mkdir()
for name in ['index','cache','src']:(U/'cargo-home/registry'/name).mkdir(parents=True,exist_ok=True)
(U/'cargo-home/config.toml').write_text('[net]\noffline = true\n[cache]\nauto-clean-frequency = "never"\n')
for name in ['tmp-contract-v1.json','validation_runner_v1.py','registry-inputs-v1.json.gz']:
 shutil.copy2(OLD/name,W/name);assert sha(OLD/name)==sha(W/name)
(W/'source-pins-v1.json.gz').write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
gmp={}
for p in sorted((V/'gmp-cache-v1').rglob('*')):
 assert not p.is_symlink()
 dest=U/'gmp-cache'/p.relative_to(V/'gmp-cache-v1')
 if p.is_dir():dest.mkdir(exist_ok=True)
 elif p.is_file():
  digest=sha(p);shutil.copy2(p,dest);assert sha(dest)==sha(p)==digest
  gmp[str(p)]={'copy':str(dest),'sha256':digest}
(W/'native-cache-copy-v1.json').write_text(json.dumps(gmp,indent=2,sort_keys=True)+'\n')
(W/'contract-v1.md').write_text("""# Required opaque scalar payload

Parent: 7ce3ff7f000b59d8b497f42b3f9bd9c135fc71fe.
Owner: Hyperreal Real deserialization, shared by Serde and its JSON/CBOR
wrappers. Properties P3, P6, P18, P26 and P35-P39.

The input domain is the existing serialized Real schema. The Irrational
class has no symbolic certificate from which to reconstruct its value;
its Computable payload is mandatory, even when the outer rational is zero.
An absent field and explicit null must fail before a Real is published.
Serde returns its typed error; the existing convenience wrappers and CBOR
Value conversions preserve their Problem::ParseError contract. Valid exact
symbolic certificates may still omit the lazily materialized payload.

First reproduce the missing acceptance tests against unchanged production.
Then implement only this structural invariant in the common Deserialize
implementation. Preserve field order/name, valid representation bytes,
cache skipping and all existing tests. Test all affected public ingress
routes and enclosing collections. Independently known rational/pi/e/root
bounds and downstream translation check consumability; serialization-byte
identity is a separate assertion.

This step does not validate every mathematical domain in a present graph,
or certify consistency of arbitrary symbolic tags and supplied graphs.
The separately reproduced sqrt(-1) blocker remains open. The affine
subtraction candidate is not applied or admitted by this patch.

Run the full scalar default/all-feature Cargo suites, debug units, relevant
doctests, strict Clippy, docs and formatting, plus affected serialization
consumers. Run declared compiler-floor checks where available. Broader native
workloads and release/distribution work must be named separately if unrun.
Use actual source without overlays after the final production edit.

Use a new empty target and private Cargo bookkeeping. Mount retained
registry input trees read-only. Copy GMP cache files independently.
Freeze every executed Cargo binary before later builds can replace outputs;
preserve previous closed experiments and every adverse result.

All original storage baselines and current ceilings remain: root 16 GiB,
Disk B 72 GiB, /tmp 24 GiB, cumulative logs 96 MiB. Child address space
8 GiB, at most two jobs, focused 60 seconds, compile/full suite 1800 seconds.
No benchmark or speedup claim. Temporary artifacts are volatile.
Hypervoxel remains excluded. No push or publication.
""")
source=(OLD/'affine_cargo_harness_v1.py').read_text()
source=source.replace('Fresh Cargo target, read-only source/registry, independently frozen executables.','Actual-source Cargo validation for the required opaque-payload invariant.')
source=source.replace('/tmp/csgrs-explicit-affine-cargo-20261018-v1',str(U))
source=source.replace("prep=json.loads((W/'preparation-v2.json').read_text())","")
source=source.replace("pins=json.loads(gzip.decompress((W/'main-source-pins-v1.json.gz').read_bytes()))","")
source=source.replace("def __init__(self,phase):","def __init__(self,phase,pins_file):\n        self.pins=json.loads(gzip.decompress(Path(pins_file).read_bytes()))")
source=source.replace("'affine-cargo-'","'real-serde-payload-'")
source=source.replace("'preparation_sha256':sha(W/'preparation-v2.json'),","'source_pins_sha256':sha(pins_file),")
source=source.replace("'source_overlays':{str(O/'crates/hyperreal/src/real'):str(W/'real'),str(O/'crates/hyperreal/src/computable/node/algebra.rs'):str(W/'algebra_explicit_v2.rs')},","'source_overlays':{},")
source=source.replace("'production_source_changed':False,","'actual_main_source_without_overlays':True,")
source=source.replace("for p,h in pins.items()","for p,h in self.pins.items()")
source=source.replace("        assert all(sha(p)==h for p,h in prep['overlay_sha256'].items())\n","")
source=source.replace("        argv+=['--ro-bind',str(W/'real'),str(O/'crates/hyperreal/src/real'),'--ro-bind',str(W/'algebra_explicit_v2.rs'),str(O/'crates/hyperreal/src/computable/node/algebra.rs')]\n","")
assert "W/'real'" not in source and 'prep[' not in source
ast.parse(source);(W/'cargo_harness_v1.py').write_text(source)
baseline='''"""Reproduce the new public-boundary tests before changing production."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from cargo_harness_v1 import Harness,cargo,dump,sha
h=Harness('baseline-v1',W/'source-pins-v1.json.gz')
keys=h.build('build',[ 'test','--locked','--offline','-p','hyperreal','--release','--features','serde','--test','serde_payload'])
assert len(keys)==1
rows,out,err,r=h.test('run',keys[0],allow_failure=True,limit=60)
assert rows==[('FAILED','2','6','0','0','0')],rows
dump(h.R/'result-v1.json',{'passed':False,'expected_baseline_failure':True,'summary':rows,'commands':h.commands,'production_source_changed':False,'helper_sha256':sha(Path(__file__)),'candidate_applied':False})
print(json.dumps({'baseline_new_failures':6,'valid_controls_passed':2,'production_source_changed':False}),flush=True)
'''
ast.parse(baseline);(W/'baseline_v1.py').write_text(baseline)
(W/'preparation-v1.json').write_text(json.dumps({'parent_revision':'7ce3ff7f000b59d8b497f42b3f9bd9c135fc71fe','helper_sha256':sha(Path(__file__)),'source_pins_sha256':sha(W/'source-pins-v1.json.gz'),'registry_files_verified':len(registry),'registry_inputs_sha256':sha(W/'registry-inputs-v1.json.gz'),'compiler_protocol_sha256':sha(V/'cargo-preparation-protocol-v1.json'),'source_test_sha256':pins['crates/hyperreal/tests/serde_payload.rs'],'target_initially_empty':not any((U/'target').iterdir()),'storage_baselines_reset':False,'resources':resources()},indent=2,sort_keys=True)+'\n')
assert not reasons(resources())
print(json.dumps({'prepared':True,'source_paths':len(pins),'registry_paths':len(registry),'target':str(U/'target')}),flush=True)
