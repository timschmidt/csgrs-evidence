from pathlib import Path
import os,sys,subprocess as sp
s=Path(os.environ['s']);w=s/'source';tag=sys.argv[1]
sp.run(['python3',s/'candidate.py',tag],check=True)
p=w/'crates/hyperinterval/src/proposal.rs';a=p.read_text()
old='self.estimates().map(|(a, b)| a.midpoint(b))'
ordered='''self.estimates().map(|(a, b)| {
                    // For ordered finite inputs these two bounds also cover both
                    // opposite-sign extremes. Halve first only in that high range.
                    if a < -(<$float>::MAX * 0.5) || b > <$float>::MAX * 0.5 {
                        a * 0.5 + b * 0.5
                    } else {
                        (a + b) * 0.5
                    }
                })'''
assert old in a
if tag=='ordered':a=a.replace(old,ordered)
elif tag=='widen':
 a=a.replace('$format:ident) =>', '$format:ident, $midpoint:ident) =>')
 a=a.replace(old,'self.estimates().map(|(a, b)| $midpoint(a, b))')
 a=a.replace('proposal!(F32ProposalInterval, f32, u32, BINARY32);','''// The wider significand adds binary32 endpoints exactly whenever their
// exponents are close enough for the smaller to affect the rounded mean.
// Halving in binary64 also preserves all binary32 subnormals.
fn midpoint32(a: f32, b: f32) -> f32 {
    ((f64::from(a) + f64::from(b)) * 0.5) as f32
}

// The validated endpoints are ordered. In the ordinary range the sum
// cannot overflow, and halving it last avoids two subnormal roundings.
fn midpoint64(a: f64, b: f64) -> f64 {
    if a < -(f64::MAX * 0.5) || b > f64::MAX * 0.5 {
        a * 0.5 + b * 0.5
    } else {
        (a + b) * 0.5
    }
}

proposal!(F32ProposalInterval, f32, u32, BINARY32, midpoint32);''').replace('proposal!(F64ProposalInterval, f64, u64, BINARY64);','proposal!(F64ProposalInterval, f64, u64, BINARY64, midpoint64);')
else:raise ValueError(tag)
p.write_text(a)
