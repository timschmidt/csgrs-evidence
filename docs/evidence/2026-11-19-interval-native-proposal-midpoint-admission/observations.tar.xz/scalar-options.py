from pathlib import Path
import os,sys,subprocess as sp
s=Path(os.environ['s']);w=s/'source';tag=sys.argv[1]
sp.run(['python3',s/'candidate.py',tag],check=True)
p=w/'crates/hyperinterval/src/proposal.rs';a=p.read_text()
old='self.estimates().map(|(a, b)| a.midpoint(b))'
expressions={
'mask':'''// Each finite endpoint has at most the exponent field of MAX.
                    // This test catches every endpoint whose addition could overflow.
                    let high = <$float>::MAX.to_bits() & <$float>::INFINITY.to_bits();
                    if (a.to_bits() | b.to_bits()) & high == high {
                        a * 0.5 + b * 0.5
                    } else {
                        (a + b) * 0.5
                    }''',
'normal':'''// Both magnitudes below 2 can be added without overflow. If either
                    // is at least 2, halving is exact for every term that can
                    // influence a nearest-rounded result at that magnitude.
                    let two = (2.0 as $float).to_bits();
                    if (a.to_bits() | b.to_bits()) & two == 0 {
                        (a + b) * 0.5
                    } else {
                        a * 0.5 + b * 0.5
                    }''',
'sum':'''let sum = a + b;
                    if sum.abs() < <$float>::MAX {
                        sum * 0.5
                    } else {
                        a * 0.5 + b * 0.5
                    }'''}
assert old in a;p.write_text(a.replace(old,'self.estimates().map(|(a, b)| {\n                    '+expressions[tag]+'\n                })'))
