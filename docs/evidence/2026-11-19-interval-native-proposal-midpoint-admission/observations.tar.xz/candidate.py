from pathlib import Path
import os,subprocess as sp,sys
s=Path(os.environ['s']);w=s/'source';tag=sys.argv[1]
def base(path):return sp.check_output(['git','-C',w,'show','HEAD:'+str(path)],text=True)
p=Path('crates/hyperinterval/src/proposal.rs');a=base(p)
a=a.replace('/// Approximate midpoint proposal, using halved endpoints to avoid\n            /// overflow. Underflow can move it outside the estimated range.','/// Native midpoint estimate, or None for empty. Under rounding to nearest\n            /// with gradual underflow, even a subnormal midpoint rounds once.')
a=a.replace('self.estimates().map(|(a, b)| a * 0.5 + b * 0.5)','self.estimates().map(|(a, b)| a.midpoint(b))')
(w/p).write_text(a)
p=Path('crates/hyperdynamics/src/field/proposal.rs');a=base(p)
a=a.replace('        let middle = F64ProposalInterval::new(start, end)?\n            .midpoint_estimate()\n            .expect("nonempty time");\n','')
a=a.replace('            initial[i] = projected\n                .midpoint_estimate()\n                .expect("nonempty initial lane");\n            radius[i] = b * 0.5 - a * 0.5;','            initial[i] = a.midpoint(b);\n            radius[i] = (-a).midpoint(b);')
a=a.replace('        let k2 = self.stage(','        let middle = start.midpoint(end);\n        let k2 = self.stage(')
assert a.count('let middle = start.midpoint(end);')==1
(w/p).write_text(a)
