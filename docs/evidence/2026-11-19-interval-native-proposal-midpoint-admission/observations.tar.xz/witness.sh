set -u
cd "$s/source"
export CARGO_TARGET_DIR="$s/witness"
rc=0
cargo +1.95.0 test --locked --release -p hyperinterval --no-default-features --features float-proposal --test proposal midpoint_rounds_once_on_the_subnormal_grid > "$s/logs/$1-witness-mid.log" 2>&1 || rc=1
cargo +1.95.0 test --locked --release -p hyperdynamics --all-features --test rk_proposal subnormal > "$s/logs/$1-witness-rk.log" 2>&1 || rc=1
exit "$rc"
