set -eu
export CARGO_TARGET_DIR="$s/owner" CARGO_BUILD_JOBS=10
cargo +1.95.0 fmt --all -- --check > "$s/logs/fmt.log" 2>&1
for pkg in hyperinterval hyperdynamics; do
 cargo +1.95.0 test --locked -p "$pkg" --all-features --all-targets > "$s/logs/$pkg-tests.log" 2>&1
 cargo +1.95.0 test --locked -p "$pkg" --all-features --doc > "$s/logs/$pkg-doctests.log" 2>&1
 cargo +1.95.0 test --locked -p "$pkg" --no-default-features > "$s/logs/$pkg-nodefault.log" 2>&1
 cargo +1.95.0 clippy --locked -p "$pkg" --all-targets --all-features -- -D warnings > "$s/logs/$pkg-clippy.log" 2>&1
 RUSTDOCFLAGS='-D warnings' cargo +1.95.0 doc --locked -p "$pkg" --all-features --no-deps > "$s/logs/$pkg-doc.log" 2>&1
 cargo +1.95.0 check --locked -p "$pkg" --all-features --examples --benches > "$s/logs/$pkg-examples.log" 2>&1
done
