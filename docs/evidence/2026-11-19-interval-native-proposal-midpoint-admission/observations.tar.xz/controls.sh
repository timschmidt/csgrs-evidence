set -eu
cd "$s/source"
mapfile -t paths < "$s/paths.txt"
test "${#paths[@]}" -eq 5
git restore -- "${paths[@]}"
test -z "$(git status --porcelain)"
for tag in fixed before repair; do
 case "$tag" in
 fixed) git switch -q --detach c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb;;
 before) git switch -q --detach e17866b40;;
 repair) git apply "$s/repair-source.patch" && git apply "$s/repair-tests.patch";;
 esac
 if test "$tag" != before; then bash "$s/build.sh" "$tag" > "$s/logs/$tag-complete-build.log" 2>&1; fi
 bash "$s/extra.sh" "$tag" > "$s/logs/$tag-extra.log" 2>&1
 for pkg in hyperinterval hyperdynamics; do
  case "$pkg" in hyperinterval) suite=proposal;; hyperdynamics) suite=rk_proposal;; esac
  CARGO_TARGET_DIR="$s/witness" cargo +1.95.0 test -p "$pkg" --all-features --release --locked --test "$suite" --no-run --message-format=json-render-diagnostics > "$s/logs/$tag-$suite.jsonl" 2>"$s/logs/$tag-$suite-build.log"
  python3 - "$tag" "$suite" <<'PY'
import json,os,shutil,sys
from pathlib import Path
s=Path(os.environ['s']);tag,suite=sys.argv[1:];exes=[j['executable'] for j in map(json.loads,(s/f'logs/{tag}-{suite}.jsonl').read_text().splitlines()) if j.get('executable') and j['target']['name']==suite]
assert len(exes)==1;shutil.copy2(exes[0],s/f'images/{tag}-test-{suite}')
PY
 done
 "$s/images/$tag-rk-stack" > "$s/logs/$tag-memory.log" 2>"$s/logs/$tag-rk-headroom.log"
 "$s/probe" "$s/images/$tag.so" stack > "$s/logs/$tag-mid-memory.log" 2>"$s/logs/$tag-mid-headroom.log"
 "$s/packed-probe" "$s/images/$tag-packed.so" stack > "$s/logs/$tag-packed-memory.log" 2>"$s/logs/$tag-packed-headroom.log"
done
