from pathlib import Path
import json,os,struct,sys,hashlib,random
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM,UC_MODE_THUMB,UC_MODE_MCLASS,UC_PROT_READ,UC_PROT_EXEC,UC_PROT_WRITE
from unicorn.arm_const import *
s=Path(os.environ['s']);flash=0x08000000;slot=65536;ram=0x20000000;top=ram+8192;stop=flash+slot-2
regs=[UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3]
rows=[]
for w,f in [(32,23),(64,52)]:
 fmt=struct.Struct('<III' if w==32 else '<QQQ');data=list(fmt.iter_unpack((s/f'corpus-{w}.bin').read_bytes()))
 # One deterministic random record per 64 plus explicit first and last
 # subnormal pairs, edge exponents, closest normal and maximum finite pairs.
 sel=set(range(0,len(data),64))
 unit=1<<f;mask=(1<<(w-1))-1;max_finite=mask-unit
 for i,(a,b,_) in enumerate(data):
  if a==b and (a&mask) in (0,1,2,3,31,unit-1,unit,unit+1,max_finite-1,max_finite):sel.add(i)
 for i in sorted(sel):rows.append((w,*data[i]))
out={}
for tag in ['fixed','before','repair']:
 p=s/'images'/f'{tag}-arm.elf'
 with p.open('rb') as file:
  elf=ELFFile(file);segments=[(g['p_paddr'],g.data(),g['p_memsz']) for g in elf.iter_segments() if g['p_type']=='PT_LOAD']
  assert elf.elfclass==32 and elf.little_endian and elf['e_machine']=='EM_ARM'
  syms=elf.get_section_by_name('.symtab');entries={sym.name:sym['st_value'] for sym in syms.iter_symbols() if sym.name in ('mid32','mid64')}
  ranges=sorted((t['st_value']&~1,(t['st_value']&~1)+t['st_size']) for t in syms.iter_symbols() if t['st_info']['type']=='STT_FUNC' and t['st_size'])
  text=elf.get_section_by_name('.text')['sh_size']
 extent=max(a+mem for a,_,mem in segments)-flash
 assert extent<=slot-16384 and set(entries)=={'mid32','mid64'}
 hi=total=0
 for a,b in ranges:total+=max(0,b-max(a,hi));hi=max(b,hi)
 rounds=[]
 for pattern in [0x55,0xaa]:
  cpu=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS);cpu.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M4)
  cpu.mem_map(flash,slot,UC_PROT_READ|UC_PROT_EXEC);cpu.mem_map(ram+4096,4096,UC_PROT_READ|UC_PROT_WRITE)
  for a,b,_ in segments:cpu.mem_write(a,b)
  cpu.reg_write(UC_ARM_REG_C1_C0_2,cpu.reg_read(UC_ARM_REG_C1_C0_2)|0xf<<20)
  cpu.reg_write(UC_ARM_REG_FPEXC,1<<30)
  for repeat in range(2):
   cpu.mem_write(ram+4096,bytes([pattern])*4096);bad={32:0,64:0}
   for w,a,b,expected in rows:
    args=[a,b] if w==32 else [a&0xffffffff,a>>32,b&0xffffffff,b>>32]
    for reg,x in zip(regs,args):cpu.reg_write(reg,x)
    cpu.reg_write(UC_ARM_REG_SP,top);cpu.reg_write(UC_ARM_REG_LR,stop|1)
    cpu.emu_start(entries['mid'+str(w)]|1,stop,count=8000)
    assert cpu.reg_read(UC_ARM_REG_PC)==stop and cpu.reg_read(UC_ARM_REG_SP)==top
    got=cpu.reg_read(UC_ARM_REG_R0)
    if w==64:got|=cpu.reg_read(UC_ARM_REG_R1)<<32
    bad[w]+=got!=expected
   memory=cpu.mem_read(ram+4096,4096);touched=4096-next((i for i,b in enumerate(memory) if b!=pattern),4096)
   rounds.append(dict(repeat=repeat,fill=pattern,wrong=bad,stack_written=touched))
   if tag=='repair':assert sum(bad.values())==0,bad
 out[tag]=dict(load_extent=extent,text=text,defined_functions=total,file=p.stat().st_size,remaining_flash=slot-extent,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rounds=rounds)
 print(tag,extent,total,rounds[0],flush=True)
(s/'arm-results.json').write_text(json.dumps({'rows':{w:sum(r[0]==w for r in rows) for w in [32,64]},'targets':out},indent=1))
