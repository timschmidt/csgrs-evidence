const fs=require('fs'),assert=require('assert/strict'),s=__dirname;
(async()=>{
for(const tag of ['fixed','before','collected']){
 const m=await WebAssembly.compile(fs.readFileSync(s+'/images/'+tag+'-radius.wasm'));assert.deepEqual(WebAssembly.Module.imports(m),[]);
 for(let run=0;run<2;run++){
  const {exports:x}=await WebAssembly.instantiate(m),p=x.memory.buffer.byteLength;
  const data=fs.readFileSync(s+'/corpus-packed.bin');let count=0,bad=0;
  for(let i=0;i<data.length;i+=16){count++;bad+=Number(x.mid32(data.readUInt32LE(i),data.readUInt32LE(i+4))!==BigInt(data.readUInt32LE(i+8)));}
  for(const [a,b] of [[2,1],[0x7f800000,0x7f800000],[0x7fc00000,0]])assert.equal(x.mid32(a,b),-1n);
  assert.equal(x.memory.buffer.byteLength,p);if(tag!=='fixed')assert.equal(bad,0);
  console.log({tag,run,count,bad,bytes:p});
 }
}
})().catch(err=>{console.error(err);process.exitCode=1});
