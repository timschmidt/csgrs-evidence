import ast,json,os,random,statistics as st,subprocess as sp,sys
from pathlib import Path
s=Path(os.environ['s']);mode=sys.argv[1];tags=sys.argv[2:];out={}
for cpu in (5,15):
 gen=random.Random(2751+cpu);rows=[]
 for i in range(4):
  order=tags[i%len(tags):]+tags[:i%len(tags)]
  if i%2:order=order[::-1]
  for tag in order:
   if mode=='rk':cmd=[s/'images'/(tag+'-rk-cost')]
   elif mode=='packed':cmd=[s/'packed-probe',s/'images'/(tag+'-packed.so'),'time']
   else:cmd=[s/'probe',s/'images'/(tag+'.so'),'time']
   res=sp.check_output(['taskset','-c',str(cpu),*cmd],text=True)
   log=s/'logs'/f'time-{mode}-{cpu}-{i}-{tag}.log';log.write_text(res)
   data={}
   for line in res.splitlines():
    if mode=='rk':
     if not line.startswith('TIMING '):continue
     key,raw=line[7:].split(' ns_per_operation=');data[key]=ast.literal_eval(raw)
    else:
     j,w,n,chk=map(int,line.split());data.setdefault(str(w),[]).append(n/500000)
   assert data
   rows.append((tag,{k:st.median(v) for k,v in data.items()}))
 d={}
 for tag in tags:
  v={k:st.median(r[k] for t,r in rows if t==tag) for k in rows[0][1]}
  d[tag]=v
 out[str(cpu)]={'medians':d,'per_process':rows}
 print(cpu,[(tag,[(k,round(100*(y/d[tags[0]][k]-1),2)) for k,y in val.items() if mode!='rk' or k.endswith('/graph-1/exhausted')]) for tag,val in d.items()],flush=True)
(s/'logs'/('paired-'+mode+'-'+'-'.join(tags)+'.json')).write_text(json.dumps(out))
