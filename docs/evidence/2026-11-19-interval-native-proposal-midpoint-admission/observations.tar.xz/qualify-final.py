from pathlib import Path
import json,hashlib,re,subprocess
s=Path(__file__).resolve().parent
def read(n):return (s/n).read_text()
def log(n):return read('logs/'+n)
def rows(n):return [json.loads(x) for x in log(n).splitlines()]
def stdout(*cmd):return subprocess.check_output(cmd,text=True).strip()
for v in ['1.88.0','1.95.0','stable']:
 for target in ['native','wasm']:
  for t in ['fixed','before','collected']:
   r=rows(f'{t}-matrix-{v}-{target}.jsonl')
   assert [x.get('total',x.get('count')) for x in r]==[89008,347056]
   assert [x['bad'] for x in r]==([0,0] if t=='collected' else [4830,4882])
assert all(r['bad']==0 and r['count']==89008 for f in ['collected-packed-oracle.jsonl','collected-packed-guest.jsonl'] for r in rows(f))
assert 'collected 89008 0' in log('final-radius.log')
assert 'Rejected(SelfMapNotCertified)' in log('mutated-replay.log') and 'test result: FAILED' in log('mutated-replay.log')
assert all('Done 100000 runs' in log(f'final-fuzz-{t}.log') for t in ['primitive_proposals','strict_float'])
assert '55988 arithmetic cases passed' in log('final-strict-wasm.log') and '172284 calls passed' in log('final-strict-wasm.log')
assert 'verified 70 emitted symbols' in log('final-codegen.log')
assert '528/528' in log('collected-coverage.log') and '10093/10546' in log('collected-coverage.log')
assert log('before-traces.txt')==log('collected-traces.txt') and log('before-traces.txt').count('TRACE ')==30
assert not re.search(r'\b(?:hyperinterval|hyperdynamics) v',log('successive-dependencies.txt'))
assert 'Finished' in log('hyperdynamics-examples.log')
for owner in ['hyperinterval','hyperdynamics']:
 for gate in ['clippy','doc','examples']:
  assert not re.search('^warning:|^error:',log(f'{owner}-{gate}.log'),re.M)
 for gate in ['tests','doctests','nodefault']:
  assert 'test result: ok' in log(f'{owner}-{gate}.log') and 'test result: FAILED' not in log(f'{owner}-{gate}.log')
(s/'final-toolchains.txt').write_text('\n\n'.join(stdout('rustc','+'+v,'-Vv') for v in ['1.88.0','1.95.0','stable','nightly'])+'\n')
print('Verified final oracle results, exact-source falsifier, identical dispatch/receipt records, host and guest qualification, coverage and fuzz artifacts.')
