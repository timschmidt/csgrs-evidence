set -eu
export CARGO_TARGET_DIR="$s/arm-build"
arch=thumbv7em-none-eabihf
src="$s/arm-src"
sysroot=$(rustc +1.95.0 --print sysroot)
linker="$sysroot/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld"
for tag in fixed before repair; do
 if test "$tag" = before; then git -C "$src" switch -q --detach e17866b40; fi
 if test "$tag" = repair; then git -C "$src" apply "$s/repair-source.patch"; fi
 cargo +1.95.0 build --manifest-path "$s/arm-client/Cargo.toml" --release --target "$arch"
 "$linker" -flavor gnu --entry=mid32 --gc-sections --no-undefined --script="$s/arm.ld" -u mid32 -u mid64 "$s/arm-build/$arch/release/libinterval_midpoint_client.a" -o "$s/images/$tag-arm.elf"
done
