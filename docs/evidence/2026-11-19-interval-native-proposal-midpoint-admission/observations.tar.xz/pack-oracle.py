from pathlib import Path
import ctypes,sys,struct,os,json
s=Path(os.environ['s'])
# Reuse the integer IEEE decoder and exact average for the half difference.
src=(s/'oracle.py').read_text().split('for w,f in [(32,23),(64,52)]:')[0]
exec(compile(src,str(s/'oracle.py'),'exec'))
fmt=struct.Struct('<III');outfmt=struct.Struct('<IIQ');rows=[]
for a,b,mid in fmt.iter_unpack((s/'corpus-32.bin').read_bytes()):
 radius=mean(-big(a,32,23),big(b,32,23),32,23)
 rows.append((a,b,(mid<<32)|radius))
(s/'corpus-packed.bin').write_bytes(b''.join(outfmt.pack(*r) for r in rows))
for tag in sys.argv[1:]:
 fn=ctypes.CDLL(str(s/f'images/{tag}-packed.so')).mid32
 fn.argtypes=[ctypes.c_uint32,ctypes.c_uint32];fn.restype=ctypes.c_uint64
 bad=sum(fn(a,b)!=out for a,b,out in rows)
 print(json.dumps(dict(tag=tag,count=len(rows),bad=bad)))
 if tag=='repair':assert bad==0
