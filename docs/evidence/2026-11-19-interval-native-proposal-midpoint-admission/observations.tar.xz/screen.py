from pathlib import Path
import json,sys,os
from artifact_sizes import native,wasm
s=Path(os.environ['s'])
def wasm_fields(p):
 b=p.read_bytes();i=8
 def u():
  nonlocal i
  val=shift=0
  while True:
   x=b[i];i+=1;val |= (x&127)<<shift
   if x<128:return val
   shift+=7
 while i<len(b):
  t=b[i];i+=1;n=u();end=i+n
  if t==10:
   bodies=[]
   for _ in range(u()):
    z=u();bodies.append(z);i+=z
   assert i==end
   return dict(file=len(b),text=n,named_text=sum(bodies))
  i=end
 raise ValueError('missing Wasm code section')
def sizes(t):
 out={}
 for suffix in ('.so','.wasm','-rk-cost','-rk-stack'):
  p=s/'images'/(t+suffix)
  if not p.is_file():continue
  rec=wasm_fields(p) if suffix=='.wasm' else native(p)
  out[suffix]={k:rec[k] for k in ['file','text','named_text']}
 return out
rows={t:sizes(t) for t in sys.argv[1:]}
print(json.dumps(rows,indent=1));(s/'logs'/('sizes-'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(rows,indent=1))
for t,v in list(rows.items())[1:]:
 for k,z in v.items():
  first=rows[sys.argv[1]][k]
  print(t,k,{m:(n-first[m],round((n/first[m]-1)*100,3)) for m,n in z.items()})
