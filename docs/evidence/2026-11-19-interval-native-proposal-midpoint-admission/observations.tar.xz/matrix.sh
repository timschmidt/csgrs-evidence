set -eu
export CARGO_TARGET_DIR="$s/matrix" CARGO_BUILD_JOBS=7
for v in 1.88.0 1.95.0 stable; do
 for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
  cargo +"$v" build --locked --release --target "$target" --manifest-path "$s/matrix-client/Cargo.toml" > "$s/logs/linked-$v-$target.log" 2>&1
  case "$target" in wasm*) name=interval_midpoint_client.wasm; ext=wasm;; *) name=libinterval_midpoint_client.so; ext=so;; esac
  cp "$s/matrix/$target/release/$name" "$s/images/final-$v.$ext"
 done
 python3 "$s/oracle.py" "final-$v" > "$s/logs/final-$v-native.jsonl"
 "$s/node/node" "$s/guest.cjs" "final-$v" > "$s/logs/final-$v-wasm.jsonl"
done
