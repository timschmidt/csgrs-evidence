const fs = require('node:fs'), assert = require('node:assert/strict');
(async () => {
 const tag = process.argv[2], data = fs.readFileSync(__dirname+'/corpus-packed.bin');
 const mod = await WebAssembly.compile(fs.readFileSync(__dirname+'/images/'+tag+'-packed.wasm'));
 assert.deepEqual(WebAssembly.Module.imports(mod), []);
 for (let repeat=0; repeat<2; repeat++) {
  const {exports:e}=await WebAssembly.instantiate(mod);
  const pages=e.memory.buffer.byteLength; let bad=0;
  for(let i=0;i<data.length;i+=16) {
   const val=BigInt.asUintN(64,e.mid32(data.readUInt32LE(i),data.readUInt32LE(i+4)));
   if (val!==data.readBigUInt64LE(i+8)) bad++;
  }
  console.log(JSON.stringify({tag,repeat,bad,count:data.length/16,pages}));
  assert.equal(pages,e.memory.buffer.byteLength);
  if(tag==='repair')assert.equal(bad,0);
 }
})().catch(e=>{console.error(e);process.exit(1)});
