set -eu
cd "$s"
src="$s/arm-src"; mapfile -t files < "$s/paths.txt"
mkdir -p trace-client/src
sed -e 's|/source/crates/|/arm-src/crates/|g' -e 's/"rk-proposal", "serde"/"rk-proposal", "serde", "dispatch-trace"/' rk-cost/Cargo.toml > trace-client/Cargo.toml
cp rk-cost/Cargo.lock trace-client/Cargo.lock
python3 - <<'PY'
from pathlib import Path
p=Path('rk-cost/src/main.rs').read_text()
begin=p.index(' print_row(name,operation,32,measure(32,&mut f));')
end=p.index('\n}',begin)
p=p[:begin]+''' hyperreal::dispatch_trace::reset();
 hyperreal::dispatch_trace::with_recording(||drop(black_box(f())));
 let snapshot=hyperreal::dispatch_trace::take_trace();
 println!("TRACE {name}/{operation} {snapshot:?}");'''+p[end:]
Path('trace-client/src/main.rs').write_text(p)
PY
git -C "$src" restore -- "${files[@]}"
for tag in before collected; do
 if test "$tag" = collected; then git -C "$src" apply "$s/collected-source.patch"; fi
 CARGO_TARGET_DIR="$s/trace-target" cargo +1.95.0 run --manifest-path trace-client/Cargo.toml --release --locked > "$s/logs/$tag-traces.txt" 2>"$s/logs/$tag-trace-build.log"
done
cmp "$s/logs/before-traces.txt" "$s/logs/collected-traces.txt"
test "$(rg -c '^TRACE ' "$s/logs/collected-traces.txt")" -eq 30
