from pathlib import Path
import os
s=Path(os.environ['s']);p=s/'source/crates/hyperinterval/src/proposal.rs'
a=p.read_text()
start=a.index('                Ok(Self {',a.index('fn from_bits('))
end=a.index('\n            }',start)
a=a[:start]+'''                Ok(Self::from_ordered_bits(a as $bits, b as $bits))
            }

            fn from_ordered_bits(lower: $bits, upper: $bits) -> Self {
                Self {
                    estimates: Some(Bounds::ordered(
                        <$float>::from_bits(lower),
                        <$float>::from_bits(upper),
                    )),
                }'''+a[end:]
old='''                    Some((a, b)) => Self::new(
                        <$float>::from_bits(a as $bits),
                        <$float>::from_bits(b as $bits),
                    ),'''
assert a.count(old)==1
p.write_text(a.replace(old,'''                    // Every candidate passed finite validation before selection.
                    Some((a, b)) => Ok(Self::from_ordered_bits(a as $bits, b as $bits)),'''))
