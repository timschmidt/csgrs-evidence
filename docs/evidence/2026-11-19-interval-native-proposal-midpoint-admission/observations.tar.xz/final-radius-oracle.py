from pathlib import Path
import ctypes as C,struct
s=Path(__file__).parent
for tag in ['fixed','before','collected']:
 lib=C.CDLL(str(s/'images'/(tag+'-radius.so')))
 f=lib.mid32;f.argtypes=[C.c_uint32,C.c_uint32];f.restype=C.c_uint64
 n=bad=0
 for a,b,radius,mid in struct.iter_unpack('<IIII',(s/'corpus-packed.bin').read_bytes()):
  n+=1;bad+=f(a,b)!=radius
 for a,b in [(2,1),(0x7f800000,0x7f800000),(0x7fc00000,0)]:
  assert f(a,b)==2**64-1
 print(tag,n,bad)
 if tag!='fixed':assert bad==0
