const fs=require('fs'),assert=require('assert/strict'),dir=__dirname,tag=process.argv[2];
(async()=>{
 const m=await WebAssembly.compile(fs.readFileSync(dir+'/images/'+tag+'.wasm'));
 assert.deepEqual(WebAssembly.Module.imports(m),[]);
 for(const w of [32,64]){
  const corpus=fs.readFileSync(dir+'/corpus-'+w+'.bin'), stride=w/8;
  const {exports:x}=await WebAssembly.instantiate(m), pages=x.memory.buffer.byteLength;
  let bad=0;
  for(let k=0;k<corpus.length;k+=3*stride){
   const get=i=>w===32?corpus.readUInt32LE(k+i*stride):corpus.readBigUInt64LE(k+i*stride);
   const val=w===32?x.mid32(get(0),get(1))>>>0:BigInt.asUintN(64,x.mid64(get(0),get(1)));
   bad+=Number(val!==get(2));
  }
  assert.equal(x.memory.buffer.byteLength,pages);
  console.log(JSON.stringify({tag,w,bad,count:corpus.length/(3*stride),pages_bytes:pages}));
  if(!['primary','fixed','before'].includes(tag))assert.equal(bad,0);
 }
})().catch(e=>{console.error(e);process.exit(1)});
