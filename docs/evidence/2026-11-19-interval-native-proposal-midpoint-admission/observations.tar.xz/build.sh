set -eu
tag=$1
export CARGO_TARGET_DIR="$s/build"
for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
 cargo +1.95.0 build --manifest-path "$s/client/Cargo.toml" --target "$target" --release
 if [ "$target" = x86_64-unknown-linux-gnu ]; then
  cp "$s/build/$target/release/libinterval_midpoint_client.so" "$s/images/$tag.so"
 else
  cp "$s/build/$target/release/interval_midpoint_client.wasm" "$s/images/$tag.wasm"
 fi
done
for p in rk-cost rk-stack; do
 cargo +1.95.0 build --release --manifest-path "$s/$p/Cargo.toml"
 case $p in rk-cost) name=rk-proposal-cost-probe;; rk-stack) name=rk-midpoint-lifetime;; esac
 cp "$s/build/release/$name" "$s/images/$tag-$p"
done
