set -eu
tag=$1
export CARGO_TARGET_DIR="$s/extra"
cp "$s/packed/src/lib.rs" "$s/packed-source.rs"
if test "$tag" = fixed; then cp "$s/packed-base.rs" "$s/packed/src/lib.rs"; fi
trap 'cp "$s/packed-source.rs" "$s/packed/src/lib.rs"' EXIT
for arch in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
 cargo +1.95.0 build --release --manifest-path "$s/packed/Cargo.toml" --target "$arch"
 case "$arch" in wasm*) file=interval_midpoint_client.wasm; ext=wasm;; *) file=libinterval_midpoint_client.so; ext=so;; esac
 cp "$s/extra/$arch/release/$file" "$s/images/$tag-packed.$ext"
done
cd "$s/source"
for row in 'hyperinterval proposal_cost' 'hyperdynamics rk_proposal'; do
 read -r owner name <<< "$row"
 cargo +1.95.0 build --locked --release -p "$owner" --example "$name" --all-features
 cp "$s/extra/release/examples/$name" "$s/images/$tag-$name"
done
