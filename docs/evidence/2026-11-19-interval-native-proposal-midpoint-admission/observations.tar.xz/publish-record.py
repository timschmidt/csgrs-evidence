from record import record,s
import json,subprocess
subprocess.run(['python3',s/'qualify-final.py'],check=True)
subprocess.run(['python3',s/'accounts.py'],check=True,stdout=subprocess.DEVNULL)
files={p for p in s.iterdir() if p.is_file() and p.suffix in {'.txt','.sh','.py','.rs','.c','.cjs','.ld','.log','.json','.patch','.diff'}}
files.update((s/'logs').glob('*'))
for dirname in ['client','external-client','packed','rk-cost','rk-stack','arm-client','trace-client','radius-client']:
 files.update(p for p in (s/dirname).rglob('*') if p.is_file() and p.suffix in {'.rs','.toml','.in','.lock','.c'})
for sub,names in [('final-codegen',['command.json','compiler.txt','report.json','size.txt','symbols.txt']),('final-strict-wasm',['compiler.log','commands.json','report.json'])]:
 files.update(s/sub/n for n in names)
files.add(s/'env')
assert all(p.stat().st_size<5*1024**2 for p in files)
r=record('native-proposal-midpoint-admission',sorted(files),'Archive interval midpoint and RK4 subnormal admission results')
(s/'receipt.json').write_text(json.dumps(r,indent=1)+'\n')
print(json.dumps(r,indent=1))
