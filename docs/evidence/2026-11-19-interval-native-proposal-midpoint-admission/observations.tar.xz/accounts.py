from pathlib import Path
import json,sys,os,hashlib
from artifact_sizes import native
s=Path(__file__).parent;root=Path('/mnt/development/csgrs')
exec('def wasm_fields'+(s/'screen.py').read_text().split('def wasm_fields',1)[1].split('def sizes',1)[0])
def save(file,obj): (s/file).write_text(json.dumps(obj,indent=1)+'\n')
tags=['fixed','before','collected']; results={}; errors=[]
old=json.loads((root/'docs/research/interval-size-accounts.json').read_text())['binary32_proposal_radius']
def account(name,values,caps,prior=0):
 a,b,c=values
 inc=max(0,c-b); cum=max(prior,b-a,0)+inc
 step=min(caps[0],int(b*caps[1]/100)); ceiling=min(caps[2],int(a*caps[3]/100))
 if inc>step or cum>ceiling: errors.append((name,values,inc,cum,step,ceiling))
 return [*values,inc,cum,step,ceiling,ceiling-cum]
for suffix in ['.so','.wasm','-packed.so','-packed.wasm','-radius.so','-radius.wasm','-rk-cost','-rk-stack','-proposal_cost','-rk_proposal','-test-proposal','-test-rk_proposal']+[f'-{v}.{ext}' for v in ['1.88.0','1.95.0','stable'] for ext in ['so','wasm']]:
 wasm=suffix.endswith('wasm');direct=suffix.endswith(('.wasm','.so'));test=suffix.startswith('-test')
 caps=[128,5,256,10] if wasm else [256,1,512,2] if direct else [16384,1,32768,2] if test else [4096,.5,8192,1]
 capacity=65536 if wasm else 64<<20; reserve=capacity//4
 def measure(tag):
  p=s/'images'/(tag+suffix)
  return (wasm_fields(p) if wasm else native(p)),hashlib.sha256(p.read_bytes()).hexdigest()
 raw,hashes=zip(*(measure(t) for t in tags))
 metrics={}
 for k in ['file','text','named_text']+(['rodata'] if suffix=='-radius.so' else []):
  prior=0
  if test:
   testkey=suffix[6:]+'-test'; prior=max((r['cumulative'] for r in old['tests'][testkey]['metrics'] if r['metric']==k),default=0)
  elif '-radius.' in suffix:
   prior=old['clients']['wasm' if wasm else 'so']['metrics'].get('code' if wasm and k in ('text','named_text') else k,[0]*5)[4]
  metrics[k]=account((suffix,k),[v[k] for v in raw],caps,prior)
 free=capacity-raw[-1]['file'];assert free>=reserve
 results[suffix]=dict(caps=caps,metrics=metrics,capacity=capacity,reserve=reserve,free=free,sha256=hashes,rodata_observed=[r.get('rodata') for r in raw] if not wasm else None)
arm=json.loads((s/'arm-final.json').read_text())['targets']
caps=[256,10,512,20];results['thumbv7em-none-eabihf']=dict(caps=caps,capacity=65536,reserve=16384,free=arm['collected']['remaining_flash'],metrics={k:account(k,[arm[t][k] for t in tags],caps) for k in ['load_extent','text','defined_functions']})
save('final-size.json',results);print('size',errors)
for k,d in results.items(): print(k, [(m,r[2]-r[1]) for m,r in d['metrics'].items()])
def lines(n):return (s/'logs'/n).read_text().splitlines()
def nums(n):return [list(map(int,row.split())) for row in lines(n)]
mem={}; caps=[128,2,256,4]
for kind in ['mid','packed','radius','rk']:
 def readstack(t):
  if kind=='rk':
   return [(r[1],r[2],r[3],r[4]) for l in lines(t+'-memory.log') if (r:=l.split())[0]=='STACK']
  return [r[:4] for r in nums(f'{t}-{kind}-memory.log')]
 def group(tag):
  res={}
  for case,warm,pat,height in readstack(tag):
   key=f'{case}/{warm}';res[key]=max(res.get(key,0),int(height))
  return res
 rs=[group(t) for t in tags]
 assert len({tuple(r) for r in rs})==1
 head=[min(int(l.split()[-1]) for l in lines(f'{t}-{kind}-headroom.log')) for t in tags]
 mem[kind]=dict(peak_by_case={k:account((kind,k),[r[k] for r in rs],caps) for k in rs[0]},headroom=head)
def heap(t):return [list(map(int,l.split()[1:-1])) for l in lines(t+'-memory.log') if l.startswith('HEAP')]
assert heap('fixed')==heap('before')==heap('collected') and len(heap('before'))==12
mem['rk']['heap']=heap('collected')
wasm={}
for n in ['early-wasm-memory.jsonl','final-wasm-memory.jsonl','radius-wasm-memory.jsonl']:
 for l in lines(n):
  d=json.loads(l);arg=d['name'];wasm[arg]={k:max(r[k] for r in d['rows']) for k in ['stack_written','reserved','memory_bytes']}
for suffix in ['','-packed','-radius']:
 mem['wasm'+suffix]={k:account(('wasm'+suffix,k),[wasm[t+suffix][k] for t in tags],caps) for k in wasm['fixed'+suffix]}
mem['arm']=account('arm',[max(r['stack_written'] for r in arm[t]['rounds']) for t in tags],caps)
save('final-memory.json',mem)
controls=list((s/'logs').glob('collected-confirm-*-rk-*-*-*.log'))
def receipts(p):return [l for l in p.read_text().splitlines() if l.startswith(('EXACT ','| '))]
ref=receipts(controls[0]);assert len([k for k in ref if k.startswith('EXACT ')])==5 and len(ref)==35
assert all(receipts(p)==ref for p in controls) and len(controls)==120
print('receipts',len(controls),'arm',mem['arm'],'memory',errors)
assert not errors,errors
