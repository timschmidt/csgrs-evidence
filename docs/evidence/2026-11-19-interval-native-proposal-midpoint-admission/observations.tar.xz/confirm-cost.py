from pathlib import Path
from statistics import median
from math import exp,log
import json,os,random,subprocess as sp,ast
s=Path(os.environ['s']);out={}
def parse(blob,mode):
 rows={}
 for line in blob.splitlines():
  if mode=='rk':
   if line.startswith('TIMING '):
    k,ls=line[7:].split(' ns_per_operation=');rows[k]=ast.literal_eval(ls)
  elif mode=='owner':
   if line.startswith(('binary','f32','f64','32,','64,')):
    w,sample,ns,iterations,receipt=line.split(',');rows.setdefault(w,[]).append(int(ns)/int(iterations))
  else:
   i,w,ns,chk=map(int,line.split());rows.setdefault(str(w),[]).append(ns/500000)
 assert rows,(mode,blob[:150])
 return {k:median(v) for k,v in rows.items()}
for cpu in (7,17):
 for mode in ('rk','owner','mid','packed'):
  gen=random.Random(68703+cpu);orders=['ABBA','BAAB','AAAA']*5;gen.shuffle(orders)
  data=[]
  for i,order in enumerate(orders):
   block=[]
   for j,role in enumerate(order):
    tag={'A':'before','B':'repair'}[role]
    if mode=='rk':cmd=[s/f'images/{tag}-rk-cost']
    elif mode=='owner':cmd=[s/f'images/{tag}-proposal_cost']
    else:cmd=[s/('packed-probe' if mode=='packed' else 'probe'),s/('images/'+tag+('-packed' if mode=='packed' else '')+'.so'),'time']
    stdout=sp.check_output(['taskset','-c',str(cpu),*cmd],text=True)
    (s/f'logs/confirm-{cpu}-{mode}-{i}-{j}-{role}.log').write_text(stdout)
    block.append(parse(stdout,mode))
   data.append((order,block))
  sums={}
  for k in data[0][1][0]:
   summary={}
   for ctl in (False,True):
    ratios=[]
    for order,b in data:
     if (order=='AAAA')!=ctl:continue
     z=(log(b[1][k])+log(b[2][k])-log(b[0][k])-log(b[3][k]))/2
     ratios.append(-z if order=='BAAB' else z)
    boots=sorted(median(gen.choices(ratios,k=len(ratios))) for _ in range(3000))
    summary['repeat_control' if ctl else 'repair']=[round(100*(exp(z)-1),3) for z in (median(ratios),boots[75],boots[2924])]
   sums[k]=summary
  out[f'{cpu}/{mode}']=sums
  print(cpu,mode,{k:v['repair'] for k,v in sums.items() if mode!='rk' or k in ('time-affine/graph-1/exhausted','constant/replay-and-proof','contraction-rejected/replay-and-proof')},flush=True)
  (s/'confirm-summary.json').write_text(json.dumps(out,indent=1))
