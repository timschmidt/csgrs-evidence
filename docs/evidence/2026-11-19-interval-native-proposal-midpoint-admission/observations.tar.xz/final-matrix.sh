set -eu
src="$s/arm-src"; mat="$s/external-client"
while ! rg -q 'test result:' "$s/logs/mutated-replay.log"; do sleep 2; done
rg -q 'test result: FAILED' "$s/logs/mutated-replay.log"
mapfile -t files < "$s/paths.txt"
git -C "$src" restore -- "${files[@]}"
test -z "$(git -C "$src" status --porcelain)"
mkdir -p "$mat/src";sed "s|SOURCE|$src|g" "$s/client/Cargo.toml.in" > "$mat/Cargo.toml"
cp "$s/client/Cargo.lock" "$mat/Cargo.lock";cp "$s/client/src/lib.rs" "$mat/src/lib.rs"
export CARGO_TARGET_DIR="$s/final-matrix" CARGO_BUILD_JOBS=7
for tag in fixed before collected; do
 case "$tag" in
 fixed) git -C "$src" switch -q --detach c9f1f9ac5;;
 before) git -C "$src" switch -q --detach e17866b40;;
 collected) git -C "$src" apply "$s/collected-source.patch";;
 esac
 for v in 1.88.0 1.95.0 stable; do
  for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
   cargo +"$v" build --release --locked --manifest-path "$mat/Cargo.toml" --target "$target" > "$s/logs/$tag-matrix-$v-$target.log" 2>&1
   case "$target" in wasm*) name=interval_midpoint_client.wasm; ext=wasm;; *) name=libinterval_midpoint_client.so; ext=so;; esac
   cp "$s/final-matrix/$target/release/$name" "$s/images/$tag-$v.$ext"
  done
  python3 "$s/oracle.py" "$tag-$v" > "$s/logs/$tag-matrix-$v-native.jsonl"
  "$s/node/node" "$s/matrix-guest.cjs" "$tag-$v" > "$s/logs/$tag-matrix-$v-wasm.jsonl"
 done
done
arch=thumbv7em-none-eabihf
CARGO_TARGET_DIR="$s/arm-build" cargo +1.95.0 build --manifest-path "$s/arm-client/Cargo.toml" --release --target "$arch"
sysroot=$(rustc +1.95.0 --print sysroot)
"$sysroot/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld" -flavor gnu --entry=mid32 --gc-sections --no-undefined --script="$s/arm.ld" -u mid32 -u mid64 "$s/arm-build/$arch/release/libinterval_midpoint_client.a" -o "$s/images/collected-arm.elf"
