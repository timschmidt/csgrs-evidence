#![no_std]
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! {
    loop { core::hint::spin_loop(); }
}
use hyperinterval::{F32ProposalInterval, F64ProposalInterval};

// NaNs cannot be valid proposal midpoints. The sentinel also catches invalid
// ordering and nonfinite endpoint inputs without conflating zero with failure.
#[unsafe(no_mangle)]
pub extern "C" fn mid32(a: u32, b: u32) -> u32 {
    F32ProposalInterval::new(f32::from_bits(a), f32::from_bits(b))
        .ok().and_then(|v| v.midpoint_estimate()).unwrap_or(f32::NAN).to_bits()
}
#[unsafe(no_mangle)]
pub extern "C" fn mid64(a: u64, b: u64) -> u64 {
    F64ProposalInterval::new(f64::from_bits(a), f64::from_bits(b))
        .ok().and_then(|v| v.midpoint_estimate()).unwrap_or(f64::NAN).to_bits()
}
