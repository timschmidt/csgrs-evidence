set -eu
cd "$s"
test -s "$s/images/collected-arm.elf"
src="$s/arm-src"
mapfile -t files < "$s/paths.txt"
git -C "$src" restore -- "${files[@]}"
mkdir -p "$s/radius-client/src"
cp "$s/external-client/"Cargo.{toml,lock} "$s/radius-client/"
export CARGO_TARGET_DIR="$s/final-matrix"
for tag in fixed before collected; do
 case "$tag" in
 fixed) git -C "$src" switch --detach c9f1f9ac5; cp width-base.rs radius-client/src/lib.rs;;
 before) git -C "$src" switch --detach e17866b40; cp width-new.rs radius-client/src/lib.rs;;
 collected) git -C "$src" apply "$s/collected-source.patch";;
 esac
 for arch in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
  cargo +1.95.0 build --locked --release --manifest-path radius-client/Cargo.toml --target "$arch"
  case "$arch" in wasm*) n=interval_midpoint_client.wasm; ext=wasm;; *) n=libinterval_midpoint_client.so; ext=so;; esac
  cp "$s/final-matrix/$arch/release/$n" "$s/images/$tag-radius.$ext"
 done
done
sed -e "s/'primary','radius-final'/'before','collected'/" -e "s/('width-'+tag+'.so')/(tag+'-radius.so')/" -e "s/tag=='radius-final'/tag!='fixed'/" -e 's/radius-corpus-32.bin/corpus-packed.bin/' -e 's/a,b,mid,radius in/a,b,radius,mid in/' width-oracle.py > final-radius-oracle.py
sed -e "s/'primary','radius-final'/'before','collected'/" -e "s|/images/width-'+tag+'.wasm|/images/'+tag+'-radius.wasm|" -e "s/tag==='radius-final'/tag!=='fixed'/" -e 's/radius-corpus-32.bin/corpus-packed.bin/' -e 's/LE(i+12)/LE(i+8)/g' width-guest.cjs > final-radius-guest.cjs
python3 final-radius-oracle.py
"$s/node/node" final-radius-guest.cjs
