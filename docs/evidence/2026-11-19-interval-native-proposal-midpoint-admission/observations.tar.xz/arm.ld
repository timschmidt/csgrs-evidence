PHDRS { rom PT_LOAD FLAGS(5); }
SECTIONS {
 . = 0x08000000;
 .text : { *(.text .text.*) } :rom
 .rodata : { *(.rodata .rodata.*) } :rom
 .ARM.exidx : { *(.ARM.exidx .ARM.exidx.*) } :rom
 /DISCARD/ : { *(.comment) }
}
