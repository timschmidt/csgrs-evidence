set -eu
while ! rg -q 'test result:' "$s/logs/before-witness-rk.log"; do sleep 2; done
rg -q 'test result: FAILED' "$s/logs/before-witness-rk.log"
python3 "$s/candidate.py" direct
bash "$s/build.sh" direct > "$s/logs/direct-build.log" 2>&1
python3 "$s/oracle.py" direct > "$s/logs/direct-oracle.jsonl"
"$s/node/node" "$s/guest.cjs" direct > "$s/logs/direct-wasm.jsonl"
bash "$s/witness.sh" direct
