set -eu
while ! rg -q 'test result:' "$s/logs/direct-witness-rk.log"; do sleep 2; done
for tag in ordered widen; do
 python3 "$s/variant.py" "$tag"
 bash "$s/build.sh" "$tag" > "$s/logs/$tag-build.log" 2>&1
 python3 "$s/oracle.py" "$tag" > "$s/logs/$tag-oracle.jsonl"
 "$s/node/node" "$s/guest.cjs" "$tag" > "$s/logs/$tag-wasm.jsonl"
done
