set -eu
tag=$1
export CARGO_TARGET_DIR="$s/build"
for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
 cargo +1.95.0 build --manifest-path "$s/client/Cargo.toml" --target "$target" --release
 if [ "$target" = x86_64-unknown-linux-gnu ]; then
  cp "$s/build/$target/release/libinterval_midpoint_client.so" "$s/images/$tag.so"
 else
  cp "$s/build/$target/release/interval_midpoint_client.wasm" "$s/images/$tag.wasm"
 fi
done
