from pathlib import Path
import os,sys,subprocess as sp
s=Path(os.environ['s']);w=s/'source';tag=sys.argv[1]
p=Path('crates/hyperinterval/src/ieee.rs');cur=sp.check_output(['git','-C',w,'show','HEAD:'+str(p)],text=True)
o=sp.check_output(['git','-C',w,'show','90cc4e789:'+str(p)],text=True)
start='    pub(crate) fn finite(self, bits: u64)';end='    fn key(self, bits: u64)'
(w/p).write_text(cur[:cur.index(start)]+o[o.index(start):o.index(end)]+cur[cur.index(end):])
if tag=='pair':sp.run(['python3',s/'candidate.py',tag],check=True)
else:sp.run(['python3',s/'scalar-options.py','normal'],check=True)
p=Path('crates/hyperinterval/src/proposal.rs')
a=(w/p).read_text();pre=sp.check_output(['git','-C',w,'show','90cc4e789:'+str(p)],text=True)
start='            /// Validates finite ordered estimates.';end='            /// A single finite proposed value'
a=a[:a.index(start)]+pre[pre.index(start):pre.index(end)]+a[a.index(end):]
(w/p).write_text(a)
