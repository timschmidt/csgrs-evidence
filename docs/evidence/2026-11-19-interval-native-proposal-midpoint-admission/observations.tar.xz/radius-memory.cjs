const fs=require('node:fs'),assert=require('node:assert/strict'),cp=require('node:child_process');
(async()=>{
 for(const name of process.argv.slice(2)){
  const path=__dirname+'/images/'+name+'.wasm';
  const wat=cp.execFileSync('wasm-dis',[path],{encoding:'utf8'});
  const sp=/\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)/.exec(wat);
  // If optimization eliminates the stack pointer the guest must have no stores.
  if(!sp)assert.doesNotMatch(wat,/\b(?:i32|i64|f32|f64)\.store/);
  const top=sp?Number(sp[1]):0;
  assert.doesNotMatch(wat,/\(data /);
  const module=await WebAssembly.compile(fs.readFileSync(path));
  assert.deepEqual(WebAssembly.Module.imports(module),[]);
  let instrumentedModule;
  const writes=/^(\s*)\(global\.set \$__stack_pointer(?=\s)/gm;
  if(sp && [...wat.matchAll(writes)].length){
  const instrumented = wat.trimEnd().replace(writes, "$1(call $interval_probe_set");
  assert.doesNotMatch(instrumented, /\(global\.set \$__stack_pointer(?=\s)/,
    "unrecognized guest stack write");
  assert.ok(instrumented.endsWith(")"));
  const source = instrumented.slice(0, -1) + `
    (global $interval_probe_min (mut i32) (i32.const ${top}))
    (export "interval_probe_min" (global $interval_probe_min))
    (export "interval_probe_sp" (global $__stack_pointer))
    (func $interval_probe_set (param $sp i32)
      (if (i32.gt_u (local.get $sp) (i32.const ${top})) (then (unreachable)))
      (global.set $__stack_pointer (local.get $sp))
      (if (i32.lt_u (local.get $sp) (global.get $interval_probe_min))
        (then (global.set $interval_probe_min (local.get $sp)))))
  )`;

   const prefix=__dirname+'/'+name+'-observe';
   fs.writeFileSync(prefix+'.wat',source);
   cp.execFileSync('wasm-as',[prefix+'.wat','-o',prefix+'.wasm','--all-features']);
   instrumentedModule=await WebAssembly.compile(fs.readFileSync(prefix+'.wasm'));
  }
  const out=[];
  for(const pattern of [0x55,0xaa])for(const warm of [false,true]){
   let api=(await WebAssembly.instantiate(module)).exports;
   const mem=new Uint8Array(api.memory.buffer);
   const exec=()=>{
    if(name.endsWith('-radius')) {
     const row=fs.readFileSync(__dirname+'/corpus-packed.bin');
     for(let i=0;i<row.length;i+=16){
      const a=BigInt.asUintN(64,api.mid32(row.readUInt32LE(i),row.readUInt32LE(i+4)));
      if(name.startsWith('collected'))assert.equal(a,BigInt(row.readUInt32LE(i+8)));
     }
    }else{
     for(const width of [32,64]){
      const row=fs.readFileSync(__dirname+'/corpus-'+width+'.bin'),stride=width/8;
      const get=width===32?row.readUInt32LE.bind(row):row.readBigUInt64LE.bind(row);
      for(let i=0;i<row.length;i+=stride*3){
       let a=api['mid'+width](get(i),get(i+stride));a=width===32?a>>>0:BigInt.asUintN(64,a);
       if(name==='collected')assert.equal(a,get(i+2*stride));
      }
     }
    }
   };
   if(warm)exec();mem.fill(pattern,0,top);exec();
   let first=0;while(first<top&&mem[first]===pattern)first++;
   assert.equal(api.memory.buffer.byteLength,mem.byteLength);
   let reserved=0;
   if(instrumentedModule) {
    api=(await WebAssembly.instantiate(instrumentedModule)).exports;
    if(warm)exec();
    api.interval_probe_min.value=top;exec();assert.equal(api.interval_probe_sp.value,top);
    reserved=top-api.interval_probe_min.value;
   }
   out.push({warm,pattern,first,stack_written:top-first,reserved,memory_bytes:mem.byteLength});
  }
  console.log(JSON.stringify({name,stack_top:top,rows:out}));
 }
})().catch(e=>{console.error(e);process.exit(1)});
