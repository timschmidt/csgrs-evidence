from pathlib import Path
import os,subprocess as sp
s=Path(os.environ['s']);w=s/'source'
p=w/'crates/hyperinterval/tests/proposal.rs';t=p.read_text()
anchor='            #[test]\n            fn finite_order_and_special_values()'
test='''            #[test]
            fn midpoint_rounds_once_on_the_subnormal_grid() {
                let grid = |units: i32| {
                    let value = <$float>::from_bits(units.unsigned_abs() as $bits);
                    if units < 0 { -value } else { value }
                };
                for lo in -31..=31 {
                    for hi in lo..=31 {
                        let sum: i32 = lo + hi;
                        let floor = sum.div_euclid(2);
                        let rounded = floor + i32::from(sum % 2 != 0 && floor % 2 != 0);
                        let expected = if rounded == 0 && sum < 0 { -0.0 } else { grid(rounded) };
                        let image = $interval::new(grid(lo), grid(hi)).unwrap();
                        assert_eq!(image.midpoint_estimate().unwrap().to_bits(), expected.to_bits(), "units [{lo},{hi}]");
                    }
                }
                let tiny = <$float>::MIN_POSITIVE;
                for value in [<$float>::from_bits(tiny.to_bits() + 1), <$float>::MAX] {
                    assert_eq!($interval::point(value).unwrap().midpoint_estimate(), Some(value));
                    assert_eq!($interval::point(-value).unwrap().midpoint_estimate(), Some(-value));
                }
            }

'''
assert anchor in t;p.write_text(t.replace(anchor,test+anchor))
p=w/'crates/hyperdynamics/tests/rk_proposal.rs'
o=sp.check_output(['git','show','90cc4e789:crates/hyperdynamics/tests/rk_proposal.rs'],cwd=w,text=True)
start='#[test]\nfn zero_flow_preserves_subnormal_proposal_width_before_exact_replay()'
end='#[test]\nfn uncertain_constant_flows_keep_exact_inputs_and_feed_subsequent_operations()'
t=p.read_text();assert start not in t and end in t
p.write_text(t.replace(end,o[o.index(start):o.index(end)]+end).replace('[(-3_i64, -3_i64), (1, 3), (-3, 1)]','[(-3_i64, -3_i64), (1, 3), (-3, 1), (1, 2)]'))
