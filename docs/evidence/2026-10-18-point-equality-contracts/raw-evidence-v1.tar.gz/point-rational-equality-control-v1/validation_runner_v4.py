"""User-authorized Disk B retention extension; all execution bounds unchanged."""
import json
from pathlib import Path
import validation_runner_v3 as _base

_contract = Path(__file__).with_name('retention-contract-v2.json')
assert _base.sha(_contract) == '6c8cce0beb66399e924b4571d516419132986eb18a181514c86a4fe0235ef4c7'
assert _base.sha(_base.__file__) == '2992cfe177f57c780a258545cd33cda2c0509b7205937aeef102fa9f44d50729'
_authorized = json.loads(_contract.read_text())
assert _base.INITIAL['disk_b_net_consumption_limit_bytes'] == 64 * 1024**3
assert _base.INITIAL['disk_b_initial_free_bytes'] == _authorized['disk_b_initial_free_bytes']
assert _base.INITIAL['root_free_bytes'] == _authorized['root_initial_free_bytes']
assert _base.INITIAL['root_net_consumption_limit_bytes'] == 16 * 1024**3
_base.INITIAL = dict(_base.INITIAL, disk_b_net_consumption_limit_bytes=72 * 1024**3)
from validation_runner_v3 import GIT, dump, reasons, resources, run, sha
