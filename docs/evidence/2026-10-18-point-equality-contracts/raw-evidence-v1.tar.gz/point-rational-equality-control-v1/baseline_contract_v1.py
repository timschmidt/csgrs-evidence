"""Establish added acceptance checks on unchanged current kernel libraries."""
import json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');W=Path(__file__).resolve().parent
A=N/'point-rational-equality-baseline-v1';T=N/'targets/native-aggregation-flat-integration-v1';assert not A.exists();A.mkdir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,GIT
assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()=='1b90c0105c71e09cacb613b4d8bfe63d62011d1c'
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
source=W/'point_equality_contract.rs'
subprocess.run([str(Path(compiler['additional_environment']['RUSTC']).with_name('rustfmt')),'--edition','2024','--config-path',str(O/'crates/.rustfmt.toml'),str(source)],check=True)
libs={};searches=set()
for line in (N/'logs/aggregation-flat-integration-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hypercurve','hyperreal','hyperlimit'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libs[r['target']['name']]=p
assert len(libs)==3;inputs={k:{'path':p,'sha256':sha(p)} for k,p in libs.items()};commands={};source_sha=sha(source);binary=A/'point-equality-contract'
def execute(label,args):
    name='point-rational-baseline-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--ro-bind',str(T),str(T),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    r=run(name,argv+args,O,target=T,wall_seconds=60);commands[label]=r;return (N/'logs'/name/'stdout').read_text()
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','--test','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
for path in sorted(searches):args+=['-L',path]
for k,p in sorted(libs.items()):args+=['--extern',k+'='+p]
execute('compile',args);out=execute('run',[str(binary),'--test-threads=1','--nocapture']);assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in out
assert sha(source)==source_sha and all(sha(v['path'])==v['sha256'] for v in inputs.values())
dump(A/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'source_sha256':source_sha,'binary_sha256':sha(binary),'libraries':inputs,'commands':commands,'test_count':3,'existing_semantics_established':True})
print(out,flush=True)
