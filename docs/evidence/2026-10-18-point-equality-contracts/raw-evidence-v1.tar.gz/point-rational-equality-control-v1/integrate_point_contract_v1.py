"""Validate the independently admitted tests against unchanged production libraries."""
import json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');T=N/'targets/native-aggregation-flat-integration-v1';A=N/'point-rational-contract-integration-v1';assert not A.exists();A.mkdir()
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha
baseline=json.loads((N/'point-rational-equality-baseline-v1/result-v1.json').read_text());source=O/'crates/hypercurve/tests/point_equality_contract.rs';assert sha(source)==baseline['source_sha256']
assert all(sha(v['path'])==v['sha256'] for v in baseline['libraries'].values())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
commands={};root=Path(compiler['additional_environment']['RUSTC']).parent;binary=A/'point-equality-contract'
dump(A/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'source_sha256':sha(source),'baseline_result_sha256':sha(N/'point-rational-equality-baseline-v1/result-v1.json'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'production_libraries':baseline['libraries'],'production_implementation_changed':False})
def execute(label,args):
    name='point-rational-contract-integration-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--ro-bind',str(T),str(T),'--chdir',str(O if label=='format' else scratch),'--setenv','TMPDIR',str(scratch)]
    commands[label]=run(name,argv+args,O,target=T,wall_seconds=60);return (N/'logs'/name/'stdout').read_text()
execute('format',[str(root/'cargo'),'fmt','--all','--','--check'])
old=baseline['commands']['compile']['argv'];idx=old.index(str(root/'rustc'));args=old[idx:]
args=[str(source) if v==str(W/'point_equality_contract.rs') else str(binary) if v==str(N/'point-rational-equality-baseline-v1/point-equality-contract') else v for v in args]
execute('compile',args);out=execute('run',[str(binary),'--test-threads=1','--nocapture']);assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in out
assert sha(source)==baseline['source_sha256'] and all(sha(v['path'])==v['sha256'] for v in baseline['libraries'].values())
dump(A/'result-v1.json',{'commands':commands,'source_sha256':sha(source),'binary_sha256':sha(binary),'test_count':3,'passed':True,'production_implementation_changed':False,'full_candidate_qualification_claimed':False})
print('format and all three integrated point contracts passed against unchanged production libraries',flush=True)
