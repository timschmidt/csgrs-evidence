from pathlib import Path
import hashlib,json,re,tomllib
s=Path(__file__).parent; root=Path.cwd()
read=lambda p:json.loads(p.read_text())
write=lambda p,obj:p.write_text(json.dumps(obj,indent=2)+'\n')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(s/'revision').read_text().strip();fw=(s/'fw-revision').read_text().strip()
rows=[]
for crate,example,features,tool,rev in [
 ('hyperinterval','proposal_replay','rational,float-proposal','1.95.0',source),('hyperinterval','real_to_dyadic','hyperreal','1.95.0',source),
 ('hyperlattice-interval','affine_image','fixed','1.95.0',source),('hypersolve','krawczyk_certificate','default (empty)','1.95.0',source),
 ('hyperpath','certified_schedule','default','1.95.0',source),('alumina-foc','current_calibration','default','1.88.0',fw)]:
 assert 'examples/'+example+'.rs' in (s/'logs'/('package-'+crate)).read_text().splitlines()
 file=s/'images'/example;size=file.stat().st_size
 assert 64*2**20-size>=16*2**20
 rows.append(dict(artifact=f'{crate}/examples/{example}',repository='alumina-firmware' if crate=='alumina-foc' else 'csgrs',target='x86_64-unknown-linux-gnu',toolchain='Rust '+tool+' release',features=features,source_snapshot=rev,file_bytes=size,sha256=digest(file),qualification_capacity_bytes=64*2**20,required_free_bytes=16*2**20,remaining_bytes=64*2**20-size,evidence='docs/evidence/2026-11-18-interval-worked-proofs'))
write(s/'example-images.json',rows)
p=root/'docs/research/interval-size-accounts.json';d=read(p);assert 'worked_interval_examples' not in d;d['worked_interval_examples']=rows;write(p,d)
pairs={}
for t in ['hyperinterval','hypersolve','hyperlattice-interval','hyperpath','native-probe','shared-probe','coordinated.wasm']:
 base='before' if t in ['hyperinterval','hypersolve','hyperlattice-interval','hyperpath'] else 'matched-control'
 a,b=[s/'images'/(v+'-'+t) for v in [base,'retained']]
 assert a.read_bytes()==b.read_bytes()
 pairs[t]=dict(baseline=base,bytes=b.stat().st_size,sha256=digest(b))
write(s/'control-images.json',pairs)
import subprocess
locks={}
for name in subprocess.check_output(['rg','-l','^name = "alumina-foc"','-g','Cargo.lock','.','../alumina-firmware','../alumina-interface'],text=True).splitlines():
 meta=tomllib.loads(Path(name).read_text());f=next(p for p in meta['package'] if p['name']=='alumina-foc');locks[name]=f['dependencies'];assert 'hyperinterval' in f['dependencies']
assert len(locks)==7
write(s/'foc-locks.json',locks)
