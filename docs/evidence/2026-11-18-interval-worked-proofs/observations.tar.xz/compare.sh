set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-worked-proofs
export CARGO_TARGET_DIR="$s/compare-target"
cd "$s/trees/csgrs"
for revision in before retained;do
 if test "$revision" = retained;then
  git checkout --detach "$(cat "$s/revision")"
  git -C "$s/trees/alumina-firmware" checkout --detach "$(cat "$s/fw-revision")"
 fi
 for spec in 'hyperinterval fixed_bounds fixed' 'hyperlattice-interval fixed_affine fixed' 'hypersolve basic' 'hyperpath basic';do
  set -- $spec
  cargo +1.95.0 build --locked --release -p "$1" --example "$2" --features "${3:-}"
  cp "$CARGO_TARGET_DIR/release/examples/$2" "$s/images/$revision-$1"
 done
 cargo +1.88.0 build --locked --release --manifest-path crates/hyperlattice-interval/conformance/alumina-foc/Cargo.toml --bin native-probe
 cp "$CARGO_TARGET_DIR/release/native-probe" "$s/images/$revision-native-probe"
done
for t in hyperinterval hyperlattice-interval hypersolve hyperpath native-probe;do cmp "$s/images/before-$t" "$s/images/retained-$t";done
