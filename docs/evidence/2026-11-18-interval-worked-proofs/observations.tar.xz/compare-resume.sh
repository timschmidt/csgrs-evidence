set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-worked-proofs
export CARGO_TARGET_DIR="$s/compare-target"
cd "$s/trees/csgrs"
m=crates/hyperlattice-interval/conformance/alumina-foc
# Both previous conformance clients are blocked by stale locks. Repair only
# dependency metadata in the old checkout and keep those controls distinct.
cargo +1.88.0 metadata --offline --manifest-path "$m/wasm/Cargo.toml" --format-version 1 > /dev/null
git diff -- "$m" | cmp "$s/both-locks.patch" -
build_foc() {
 cargo +1.88.0 build --locked --release --manifest-path "$m/Cargo.toml" --bin native-probe --bin shared-probe
 for p in native shared;do cp "$CARGO_TARGET_DIR/release/$p-probe" "$s/images/$1-$p-probe";done
 cargo +1.88.0 build --locked --release --manifest-path "$m/wasm/Cargo.toml" --target wasm32-unknown-unknown
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" "$s/images/$1-coordinated.wasm"
}
build_foc matched-control
for mutation in sample range;do
 case "$mutation" in
 sample) sed -i 's/let sample = samples::sample(index);/let sample = samples::sample(index.wrapping_add(1));/' "$m/wasm/lib.rs";;
 range) sed -i 's/Err(FocError::Range) => 1/Err(FocError::Range) => 0/' "$m/wasm/lib.rs";;
 esac
 git diff -- "$m/wasm/lib.rs" > "$s/$mutation.patch"
 cargo +1.88.0 build --locked --release --manifest-path "$m/wasm/Cargo.toml" --target wasm32-unknown-unknown
 if timeout 20s node "/mnt/development/csgrs/$m/wasm/check.mjs" "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" > "$s/logs/mutation-$mutation" 2>&1;then exit 1;fi
 rg -q 'AssertionError' "$s/logs/mutation-$mutation"
 git restore -- "$m/wasm/lib.rs"
done
git restore -- "$m/Cargo.lock" "$m/wasm/Cargo.lock"
git checkout --detach "$(cat "$s/foc-revision")"
git -C "$s/trees/alumina-firmware" checkout --detach "$(cat "$s/fw-revision")"
for spec in 'hyperinterval fixed_bounds fixed' 'hyperlattice-interval fixed_affine fixed' 'hypersolve basic' 'hyperpath basic';do
 set -- $spec
 cargo +1.95.0 build --locked --release -p "$1" --example "$2" --features "${3:-}"
 cp "$CARGO_TARGET_DIR/release/examples/$2" "$s/images/retained-$1"
 cmp "$s/images/before-$1" "$s/images/retained-$1"
done
build_foc retained
for t in native-probe shared-probe coordinated.wasm;do cmp "$s/images/matched-control-$t" "$s/images/retained-$t";done
timeout 20s node "$m/wasm/check.mjs" "$s/images/retained-coordinated.wasm"
