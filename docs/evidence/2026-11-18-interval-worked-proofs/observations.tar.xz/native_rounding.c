#include <fenv.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int selected_mode;
__attribute__((constructor)) static void choose_rounding(void) {
    const char* name = getenv("EXAMPLE_ROUNDING");
    if (!strcmp(name, "nearest")) selected_mode = FE_TONEAREST;
    else if (!strcmp(name, "up")) selected_mode = FE_UPWARD;
    else if (!strcmp(name, "down")) selected_mode = FE_DOWNWARD;
    else if (!strcmp(name, "zero")) selected_mode = FE_TOWARDZERO;
    else abort();
    if (fesetround(selected_mode) || fegetround() != selected_mode) abort();
}
__attribute__((destructor)) static void check_rounding(void) {
    if (fegetround() != selected_mode) abort();
    fputs("initial hardware rounding mode preserved\n", stderr);
}
