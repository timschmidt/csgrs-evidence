from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
import json
s=Path(__file__).parent
logs=s/'logs'
def lines(name):return (logs/name).read_text().splitlines()
obs={}
nominal,uncertainty=Q(1,2),Q(1,4)
lo,hi=nominal-uncertainty,nominal+uncertainty
for mode,coarse in [('nearest',0),('down',0),('zero',0),('up',2)]:
 expected=[f'offset 1: proposed [0.25, 0.75], exact [{lo}, {hi}], encloses = true',f'offset 9007199254740992: proposed [{coarse}, {coarse}], exact [{lo}, {hi}], encloses = false']
 assert lines('round-'+mode)==expected+['initial hardware rounding mode preserved']
obs['measurement']=[str(lo),str(hi)]
def sqrt_hull(bits):
 d=1<<bits;k=isqrt(2*d*d)
 return Q(k,d),Q(k+1,d)
threshold=Q(181,128)
coarse,fine=sqrt_hull(4),sqrt_hull(24)
assert coarse[0]<threshold<coarse[1] and threshold<fine[0]
obs['tight_independent_sqrt_grids']=[[str(v) for v in pair] for pair in (coarse,fine)]
center=Q(3,2);xradius=Q(1,4)
# Solve the triangular center Jacobian [2x,0;2x,2y] and weight the
# second-order coefficients and derivative widths of both residuals.
dx=-(center**2-2)/(2*center)
dy=-(2*center**2-4+2*center*dx)/(2*center)
for yr in [xradius,Q(3,32)]:
 rem=[xradius**2,xradius**2+yr**2]
 rad=[abs(dx)+rem[0]/(2*center),abs(dy)+sum(rem)/(2*center)]
 con=[xradius/center,(2*xradius+yr)/center]
 assert all(v<1 for v in con)
 assert (center-yr)**2 < 2 < (center+yr)**2
 if yr==xradius:
  for i,(name,v) in enumerate([('x',dx),('y',dy)]):
   assert f'{name} step {v}, image radius {rad[i]}, contraction {con[i]}' in lines('release-krawczyk_certificate')
  assert rad[0]<=xradius and rad[1]<=yr
 else:assert rad[0]<=xradius and rad[1]>yr
 obs['certificate y radius '+str(yr)]={'step':[str(dx),str(dy)],'image':list(map(str,rad)),'contraction':list(map(str,con))}
a,b=1,3
assert {2*t-(2*t+1) for t in [a,b]}=={-1}
cart=[2*x-y for x in (a,b) for y in (2*a+1,2*b+1)]
assert [min(cart),max(cart)]==[-5,3]
assert '2x - y is -1 on the affine image and ranges from -5 to 3 on its hull.' in lines('release-affine_image')
obs['affine_images']=[[-1,-1],[-5,3]]
forward,stop=(isqrt(2*length) for length in [8,2])
assert (forward,stop)==(4,2) and forward**2>2*2
assert f'Certified join feed {stop} between spans of lengths 8 and 2.' in lines('release-certified_schedule')
obs['join_feeds']=[forward,stop]
for count in [2045,2051]:
 raw=[(count-2048)*gain+err for gain in (1024,2048) for err in (-1024,1024)]
 assert f'ADC {count} gives [{min(raw)}, {max(raw)}] × 2^-30 normalized current.' in lines('fw-release')
 obs['adc '+str(count)]=[min(raw),max(raw)]
(s/'oracles.json').write_text(json.dumps(obs,indent=2)+'\n')
