# Standalone cancellation focused runtime screen

Independent higher-priority gate evidence for candidate8a454c860 vs source
primarye63cbf68 (current primarycfbff85 differs only in documentation). No source
or fixture assertion changes. The source worktree begins/restores clean control
4f41bd58. Keep held queue1621335/start38218939 and dead watcher3416600 unchanged;
this screen does not resume, replace or grant release clearance to that queue.
Memory/count/distribution and full owner/successive/release qualification remain
open even if this focused screen passes. No runtime allowance is introduced.

## Completed contracts

Build the existing Hypersolve certification benchmark unchanged and run the
existing15case owner filter covering alpha, candidate domains and solver engines.
The complete consumer imports byte-identical fixtures from the separated memory
campaign. Its Input/Output, operation, trace reset/recording/take, validation and
printing functions are exact extracted source fragments. Only the Criterion
orchestration is new. Every timed iteration materializes the report and optional
trace, validates all original exact expectations and generation invariants, and
drops the report, trace and any rebuilt owned input. Reused input creation and
final teardown, initial validation/printing and debug serialization are outside
timing. Existing process/TLS caches may be warm; no cold-cache claim follows.
No allocator interposer, stack probe or RSS measurement is present.

Common workloads:4cases1/4/16/64variables, both policies, reused/rebuilt inputs;
default16cases and trace32cases including passive/active. Source/candidate
functional --test controls must have identical CASE/OUTPUT/TRACE records. Added
cancellation/retry at candidate has16/32cases; original diagnostics and scope
cleanup assertions execute inside each iteration. Record its absolute completed
costs separately; primary failures are not successful runtime baselines.

## Build and screen windows

One3600second build window,160directchildren,900perbuild/check,60Git;
6buildjobs, locked offline Rust1.95, isolated RAM Cargo metadata, RAM target and
images.1GiBfiles,512MiBstage,2.5GiBtmp/20GiBdevelopment reserves. Preserve hashes,
compiler identity, source identities, eight final images, functional control
outputs, strict public four-configuration and owner-benchmark Clippy, formatting.
No automatic retry/reset. Restore source control before any timing begins.

Separate3600second timing window,160directchildren at one counted spawn site,
300seconds per benchmark and60per host-tool call. No concurrent owned build or
CPU-heavy audit. PinCPU0 and disableASLR; use one shared executable path/argv per
family. Confirm CPU affinity/personality controls before timing, and retain
before/after /proc/process records. Reject competing compiler/routing/KiCad work;
boundary observations do not prove continuous host exclusivity. Keep every raw
sample and adverse observation; no automatic rerun.

Each common family(owner15/default16/trace32) has eight invocations in ABBA/BAAB
order,30Criterion samples,0.5second warmup,1second requested measurement, no plots.
Added candidate default/trace run once each with identical settings and no old
cost denominator. Require all expected Criterion sample records, successful
full outputs and control records. Review paired process/case estimates and
uncertainty separately; sample counts are not an automatic non-regression proof.
Offline review separately capped300seconds. Archive after all timing is terminal.

One preparatory rustfmt invocation formats only the new consumer source tree.
Charge it against the same160child build ceiling; original fixture byte hashes
and the extracted observer fragments must remain unchanged.

## Reviewed extraction correction

The first build attempt completed15owner controls, then failed to compile the
consumer because the extracted prefix also included an unused measure_stack
extern declaration whose c_void import was intentionally absent. No timing ran.
Preserve the original12producer commands, one formatter preparation and owner
image. Remove only that unused declaration, not an operation, assertion or
validation. Keep all fixtures/executed observer functions byte-identical.
The corrected build starts from the clean detached base left by failure, shares
the original3600second deadline and160child ceiling (13already charged), and
restores the original control on success. No automatic retry.

Public-consumer locked core dependencies match the previously measured resource
consumer; the existing owner benchmark retains its separate repository lock.
Record those configurations separately rather than claiming identical dependency
closures across owner and public harnesses.
