# Standalone cancellation: bounded byte allowance proposal

Owner Hypersolve work-budget publication, P5/P6/P20/P36 and plan14.4. Benefit:
the reproduced scope-local extension prevents a completed callback value from
escaping after cancellation is observed. It preserves cleanup and fresh retry.
Candidate8a454c86054ae4d5a4b0813d8e9edd1e6775ec47; source basee63cbf68;
fixed program baselinec9f1f9ac55216b762e9eb97672de1e66f3b8a3fb. Current primary
cfbff85ad differs from source base only in documentation/evidence references.
The complete current consumer and historical reconciliation are frozen in
cancellation-standalone-consumer-separated and cancellation-standalone-history.
No geometry rerun, source change, candidate admission or automatic global
allowance follows from this offline assessment.

## Scope and rationale

Apply only to the measured x86_64 Linux/glibc native complete-consumer workload,
one worker, active dispatch-trace recording. The full four-case corpus, both
policies, input lifetime variants, warm/cold state, both stack patterns and
32cycle histories remain unchanged. Prior seven-case/ten-boundary bundle costs
remain in their own complete ledger; this revision does not admit that bundle.
No WASM, firmware, no-alloc or arbitrary-input memory claim follows.

The old uniform4096byte AND2percent limit is too coarse to express a small byte
allowance when the small active-trace temporary working set is about16KiB, or
when stress allocator traffic is about9MiB per completed operation. Grant a
small target-specific byte budget for the demonstrated correctness extension,
not a trace optimization or a claim that the added check caused every observed
charge. Preserve all measured costs, unfavorable results and positive charges.
Source identity and allocation variability are not waivers or proof of a cause.

Declare these combined absolute AND relative limits for both incremental and
cumulative positive growth before judging retention:

* One-variable active-trace requested/usable temporary peak:2048bytes AND10percent
  of the existing fixed-baseline measured metric. The absolute limit tightens
  from4096bytes; the larger percentage permits small discrete container costs
  in a small working set.2048bytes is0.1953125percent of the unchanged1MiB heap
  capacity and0.048828125percent of the4MiB worker reserve. It is a deliberately
  small absolute allowance, not a general ten-percent memory policy.
* One-variable active-trace requested/usable traffic:4096bytes AND5percent, with
  the absolute amount scaled32 for complete32cycle histories. The absolute cap
  is unchanged;4096bytes is0.0244140625percent of the16MiB per-operation traffic
  capacity. Retained input/report/proof/cache bytes do not use this allowance.
*64variable active-trace requested/usable traffic:16384bytes AND0.25percent,
  scaled32 only for complete history traffic. The absolute cap rises from4096;
  the percentage tightens from2percent.16384bytes is0.006103515625percent of the
  unchanged256MiB stress traffic capacity. A0.25percent gate still prevents
  substantial traffic growth even where the absolute limit permits small
  allocator-sized differences.

Other cases and metrics retain their original caps. In particular, allocation,
deallocation and reallocation counts, retained/persistent bytes, stack, total
capacities, required headroom, no-retention-after-cycle-two, exact outputs,
certainty/trace counts, runtime and validation gates do not change. Both the
absolute and relative cap apply; zero denominators still require zero growth.
The reported footprint is requested/usable payload, not allocator metadata or
RSS. These limits do not establish latency, work, or universal memory bounds.

## Cumulative accounting and disposition

Read the existing reconciled accounts without modifying them. Keep every value,
denominator, positive boundary charge and historical observation byte-for-byte
as data. Re-evaluate old charges under the declared new byte limits, retaining
the old verdict alongside the new verdict; do not carry a superseded cap's
Boolean verdict as though the cap itself were unchanged. Unchanged metric gates
must retain their old failures. Do not net decreases against positive charges,
change baseline, remove an account, omit a workload or fabricate a successful
old baseline for added cancellation/retry. Keep all final-image accounts intact.

Passing revised byte limits is only a proposed memory allowance. Any remaining
count, runtime, distribution or validation failure still blocks source admission.
Accepted exception totals remain unchanged until full admission is satisfied.

One300second offline review; no subprocess or geometry execution. Read immutable
hashes and verify values, charges, old/new verdicts, denominators, capacities,
headroom and account counts independently. Keep all earlier evidence. No auto
retry or alteration of old producer budgets/deadlines. Archive after review.
