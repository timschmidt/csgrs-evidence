from pathlib import Path
from fractions import Fraction
from collections import Counter
import hashlib,json,time
s=Path(__file__).parent;old=s.parent/'cancellation-standalone-history';start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();began=load(s/'started.json');done=load(s/'completion.json');assert done['exit_code']==0 and done['seconds']<300 and done['subprocesses']==0;assert sha((s/'review.py').read_bytes())==began['driver_sha256']
for p,digest in began['source_hashes'].items():assert sha(Path(p).read_bytes())==digest
original=load(old/'accounts.json');revised=load(s/'accounts.json');caps=load(s/'caps.json');summary=load(s/'summary.json');assert len(original)==len(revised)==288;changed=0
ok=lambda amount,denominator,absolute,percent:denominator>=0 and amount<=absolute and Fraction(amount*100)<=Fraction(str(percent))*denominator
for before,after in zip(original,revised):
 assert before['key']==after['key'] and before['values']==after['values'];assert after['original_failures']==before['failures'];key=before['key'];history=isinstance(key[1],str);case=key[2] if history else key[1];trace=key[4] if history else key[3];failures=before['failures'].copy()
 for metric,e in before['metrics'].items():
  v=after['metrics'][metric];rules=[r for r in caps['rules'] if not before['added_functionality'] and key[0]=='trace' and case==r['case'] and trace==r['trace'] and metric in r['metrics']]
  if not rules:assert v==e;continue
  rule=rules[0];absolute=rule['absolute_bytes']*(rule['history_absolute_scale'] if history else 1);percent=rule['relative_percent'];assert v['absolute_cap']==absolute and v['percent_cap']==percent;changed+=1
  for name in ['values','denominator','cumulative_positive_charge','historical_observations','total_limit','total_pass']:assert v[name]==e[name]
  assert v['original_gate']['absolute_cap']==e['absolute_cap'] and v['original_gate']['percent_cap']==e['percent_cap'];hist_pass=all(ok(o['charge'],o['denominator'],absolute,percent) for o in e['historical_observations']);flags=[]
  for oldc,c in zip(e['changes'],v['changes']):
   for name in ['before','after','delta','positive_charge','prior']:assert c[name]==oldc[name]
   prior=c['prior'];flag=ok(c['positive_charge'],e['denominator'],absolute,percent) and (not prior or ok(prior['charge'],prior['denominator'],absolute,percent));assert c['incremental_pass']==flag and c['original_incremental_pass']==oldc['incremental_pass'];flags.append(flag)
  incremental=all(flags) and hist_pass;cumulative=ok(e['cumulative_positive_charge'],e['denominator'],absolute,percent) and hist_pass;assert v['incremental_pass']==incremental and v['cumulative_pass']==cumulative and v['historical_obligations_pass']==hist_pass
  for suffix,flag in [('incremental',incremental),('cumulative',cumulative)]:
   tag=metric+':'+suffix
   if tag in failures:failures.remove(tag)
   if not flag:failures.append(tag)
 assert failures==after['failures']
assert changed==summary['metrics_with_revised_byte_caps']==72;assert summary['proposed_failed_accounts']==sum(bool(a['failures']) for a in revised)==1;assert summary['proposed_failed_metrics']==dict(Counter(f for a in revised for f in a['failures']));assert summary['new_source_admission'] is False
v=dict(accounts=288,revised_byte_metrics=72,old_failed_accounts=17,proposed_failed_accounts=1,remaining_failure='historical allocation/deallocation count charge2, unchanged count caps',all_old_values_denominators_charges_verdicts_retained=True,all_unchanged_gates_verified=True,independent_fraction_arithmetic=True,new_source_admission=False,seconds=time.monotonic()-start);(s/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
