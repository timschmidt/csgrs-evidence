from pathlib import Path
from collections import Counter
import copy,hashlib,json,time
s=Path(__file__).parent;old=s.parent/'cancellation-standalone-history';start=time.monotonic();deadline=start+300;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');assert not (s/'started.json').exists();assert load(old/'verification.json')['old_failures_preserved'];sources=[old/'accounts.json',old/'size-accounts.json',old/'summary.json',old/'verification.json',s/'caps.json',s/'PROTOCOL.md'];hashes={str(p):sha(p.read_bytes()) for p in sources};save('started.json',dict(time=time.time(),driver_sha256=sha(Path(__file__).read_bytes()),source_hashes=hashes,deadline_seconds=300,subprocesses=0));caps=load(s/'caps.json');original=load(old/'accounts.json');accounts=copy.deepcopy(original);revised_metrics=0;actually_changed=0
passed=lambda charge,base,cap,percent:base>=0 and charge<=cap and charge*100<=percent*base
for a in accounts:
 assert time.monotonic()<deadline;key=a['key'];history=isinstance(key[1],str);case=key[2] if history else key[1];trace=key[4] if history else key[3];a['original_failures']=a['failures'].copy();a['byte_allowance_proposal']=True
 if a['added_functionality']:continue
 for metric,e in a['metrics'].items():
  rules=[rule for rule in caps['rules'] if key[0]=='trace' and case==rule['case'] and trace==rule['trace'] and metric in rule['metrics']]
  if not rules:continue
  assert len(rules)==1;rule=rules[0];cap=rule['absolute_bytes']*(rule['history_absolute_scale'] if history else 1);percent=rule['relative_percent'];e['original_gate']={k:e[k] for k in ['absolute_cap','percent_cap','incremental_pass','cumulative_pass','historical_obligations_pass','remaining_absolute','remaining_relative_bytes']};e['absolute_cap']=cap;e['percent_cap']=percent;e['remaining_absolute']=cap-e['cumulative_positive_charge'];e['remaining_relative_bytes']=e['denominator']*percent/100-e['cumulative_positive_charge'];e['historical_obligations_pass']=all(passed(o['charge'],o['denominator'],cap,percent) for o in e['historical_observations'])
  for c in e['changes']:
   c['original_incremental_pass']=c['incremental_pass'];prior=c['prior'];c['incremental_pass']=passed(c['positive_charge'],e['denominator'],cap,percent) and (not prior or passed(prior['charge'],prior['denominator'],cap,percent))
  e['incremental_pass']=all(c['incremental_pass'] for c in e['changes']) and e['historical_obligations_pass'];e['cumulative_pass']=passed(e['cumulative_positive_charge'],e['denominator'],cap,percent) and e['historical_obligations_pass'];revised_metrics+=1;actually_changed+=e['original_gate']['incremental_pass']!=e['incremental_pass'] or e['original_gate']['cumulative_pass']!=e['cumulative_pass']
  for test in ['incremental','cumulative']:
   tag=metric+':'+test
   if tag in a['failures']:a['failures'].remove(tag)
   if not e[test+'_pass']:a['failures'].append(tag)
for before,after in zip(original,accounts):
 assert before['key']==after['key'] and before['values']==after['values'] and before['failures']==after['original_failures'];assert set(before['metrics'])==set(after['metrics'])
 for name,e in before['metrics'].items():
  revised=after['metrics'][name]
  if 'original_gate' not in revised:assert e==revised;continue
  for key in ['values','total_limit','total_pass','denominator','cumulative_positive_charge','historical_observations']:assert e[key]==revised[key]
  for a,b in zip(e['changes'],revised['changes']):
   for key in ['before','after','delta','positive_charge','prior']:assert a[key]==b[key]
summary=dict(accounts=len(accounts),original_failed_accounts=sum(bool(a['failures']) for a in original),proposed_failed_accounts=sum(bool(a['failures']) for a in accounts),proposed_failed_metrics=dict(Counter(f for a in accounts for f in a['failures'])),metrics_with_revised_byte_caps=revised_metrics,metrics_with_changed_verdicts=actually_changed,all_values_denominators_positive_charges_retained=True,all_original_verdicts_retained=True,count_retention_stack_capacity_headroom_size_runtime_gates_unchanged=True,unchanged_size_accounts_sha256=hashes[str(old/'size-accounts.json')],new_source_admission=False,accepted_memory_exceptions=0,seconds=time.monotonic()-start)
for path,digest in hashes.items():assert sha(Path(path).read_bytes())==digest
save('accounts.json',accounts);save('summary.json',summary);save('completion.json',dict(exit_code=0,seconds=time.monotonic()-start,subprocesses=0));print(json.dumps(summary,indent=2))
