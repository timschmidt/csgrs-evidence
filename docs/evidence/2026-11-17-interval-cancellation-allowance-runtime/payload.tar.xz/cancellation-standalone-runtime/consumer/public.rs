mod fixture;
use criterion::{Criterion, criterion_group, criterion_main};
use fixture::{ChainOutput, Fixture, operation};
use hyperlimit::PredicatePolicy;
use std::hint::black_box;

#[cfg(feature = "trace")]
type Trace = hyperreal::dispatch_trace::TraceSnapshot;
#[cfg(not(feature = "trace"))]
type Trace = ();

unsafe extern "C" {
    fn measure_stack(
        callback: unsafe extern "C" fn(*mut c_void),
        context: *mut c_void,
        warm: i32,
        pattern: u8,
    ) -> usize;
}
struct Input {
    case: usize,
    policy: PredicatePolicy,
    reused: Option<Fixture>,
    generation: Option<u64>,
}
struct Output {
    report: ChainOutput,
    trace: Trace,
    owned: Option<Fixture>,
}
fn operation_with_input(input: &Input) -> (ChainOutput, Option<Fixture>) {
    let owned = input.reused.is_none().then(|| fixture::fixture(input.case));
    let f = input.reused.as_ref().or(owned.as_ref()).unwrap();
    (operation(f, input.policy), owned)
}
fn run<const RECORD: bool>(input: &Input) -> Output {
    #[cfg(feature = "trace")]
    hyperreal::dispatch_trace::reset();
    #[cfg(feature = "trace")]
    let (report, owned) = if RECORD {
        hyperreal::dispatch_trace::with_recording(|| operation_with_input(input))
    } else {
        operation_with_input(input)
    };
    #[cfg(not(feature = "trace"))]
    let (report, owned) = {
        assert!(!RECORD);
        operation_with_input(input)
    };
    #[cfg(feature = "trace")]
    let trace = hyperreal::dispatch_trace::take_trace();
    #[cfg(not(feature = "trace"))]
    let trace = ();
    Output {
        report,
        trace,
        owned,
    }
}
fn validate(input: &Input, output: &Output) {
    fixture::validate(input.case, input.policy, &output.report);
    if let Some(f) = &input.reused {
        assert_eq!(Some(f.context.generation()), input.generation);
    }
    assert_eq!(output.owned.is_none(), input.reused.is_some());
}
fn print_output(input: &Input, output: &Output) {
    validate(input, output);
    println!("OUTPUT {:?}", output.report);
    println!("TRACE {:?}", output.trace);
}
fn measure<const RECORD: bool>(
    c: &mut Criterion,
    case: usize,
    policy_name: &str,
    policy: PredicatePolicy,
    reuse: bool,
) {
    let input = Input {
        case,
        policy,
        reused: reuse.then(|| fixture::fixture(case)),
        generation: None,
    };
    let input = Input {
        generation: input.reused.as_ref().map(|f| f.context.generation()),
        ..input
    };
    let name = format!(
        "cancellation/{}/{case}/{policy_name}/{}",
        if reuse { "reuse" } else { "rebuild" },
        if RECORD { "active" } else { "passive" },
    );
    let output = run::<RECORD>(&input);
    println!("CASE {name}");
    print_output(&input, &output);
    drop(output);
    c.bench_function(&name, |b| {
        b.iter(|| {
            let output = black_box(run::<RECORD>(black_box(&input)));
            validate(&input, &output);
            drop(output);
        })
    });
}

fn public(c: &mut Criterion) {
    for case in 0..4 {
        for (name, policy) in [
            ("strict", PredicatePolicy::STRICT),
            ("approx", PredicatePolicy::APPROXIMATE_512),
        ] {
            for reuse in [true, false] {
                measure::<false>(c, case, name, policy, reuse);
                #[cfg(feature = "trace")]
                measure::<true>(c, case, name, policy, reuse);
            }
        }
    }
}
criterion_group!(benches, public);
criterion_main!(benches);
