from pathlib import Path
import gzip,hashlib,json,os,resource,shutil,signal,subprocess,time
s=Path(__file__).parent;h=s/'consumer';r=Path('/dev/shm/interval-trace-materialization/csgrs');target=Path('/dev/shm/interval-cancellation-runtime-target');art=Path('/dev/shm/interval-cancellation-runtime-images');start=time.monotonic();deadline=start+3600;commands=[];builds=[];sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];control='4f41bd58415d936968e1955dbd431f0cb5e988f0';base='e63cbf68aea24a5939332c738c4a6652be881627';candidate='8a454c86054ae4d5a4b0813d8e9edd1e6775ec47';current='cfbff85ad075d81c2d4d3bddc04d2977bdb57b82';owner_filter='^(certify_univariate_quadratic_alpha_rows|certify_candidate_domains|solve_(levenberg_marquardt|modified_newton|dogleg|powell_hybrid|bfgs|sqp).*)$';env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='6',CARGO_NET_OFFLINE='true',HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1')
def run(name,args,work=h,cap=900):
 f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();assert time.monotonic()<deadline and len(commands)+1<160;assert shutil.disk_usage('/tmp').free>=2560*1024**2 and shutil.disk_usage('/mnt/development').free>=20*1024**3;assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<512*1024**2
 t=time.monotonic();p=s/(name+'.log');timed=False
 with p.open('wb') as out:
  child=subprocess.Popen(args,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(1024**3,hard)));save('build-active.json',dict(producer=os.getpid(),child=child.pid,name=name,number=len(commands)+1,remaining=deadline-t))
  try:child.wait(timeout=min(cap,deadline-t))
  except BaseException as error:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
   if isinstance(error,subprocess.TimeoutExpired):timed=True
   else:raise
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();c=dict(name=name,command=args,cwd=str(work),exit_code=child.returncode,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_sha256=sha(raw),stored_sha256=sha(stored),raw_bytes=len(raw),stored_bytes=len(stored));commands.append(c);save('build-commands.json',commands);save('build-active.json',dict(producer=os.getpid(),child=None));assert child.returncode==0 and not timed,(name,child.returncode);assert not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines());return raw.decode()
def git(name,*args):return run(name,['git',*args],work=r,cap=60).strip()
def build(label,revision,family,features=''):
 name=label+'-'+family;owner=family=='owner';args=['cargo','+1.95.0','bench','--no-run','--locked','--offline','--message-format=json']
 if owner:args+=['-p','hypersolve','--no-default-features','--bench','certification']
 else:
  args+=['--bench','public']
  if features:args+=['--features',features]
 raw=run(name+'-build',args,work=r if owner else h);found=[]
 for line in raw.splitlines():
  try:v=json.loads(line)
  except ValueError:continue
  if v.get('reason')=='compiler-artifact' and v.get('executable') and v.get('target',{}).get('name')==('certification' if owner else 'public'):found.append(v['executable'])
 assert len(found)==1;image=art/name;shutil.copy2(found[0],image);expected=15 if owner else 32 if 'trace' in features else 16;args=[str(image),'--test']+([owner_filter] if owner else []);output=run(name+'-controls',args,cap=300);assert sum(line.strip()=='Success' for line in output.splitlines())==expected
 row=dict(label=label,revision=revision,family=family,features=features,expected_cases=expected,image=dict(path=str(image),bytes=image.stat().st_size,sha256=sha(image.read_bytes())),control_log=name+'-controls.log.gz',consumer_sources={p.name:sha(p.read_bytes()) for p in h.iterdir() if p.is_file()},owner_source_sha256=sha((r/'crates/hypersolve/benches/certification.rs').read_bytes()));builds.append(row);save('builds.json',builds);print(name,expected,'functional cases passed',flush=True)
assert not (s/'build-started.json').exists() and not art.exists();art.mkdir();target.mkdir();save('build-started.json',dict(time=time.time(),producer=os.getpid(),driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes()),preparation_sha256=sha((s/'preparation.json').read_bytes()),provenance_sha256=sha((s/'provenance.json').read_bytes()),observer_sha256=sha((s/'observer-fragments.json').read_bytes()),environment_overrides={k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','HYPERSOLVE_SKIP_BENCHMARK_REPORTS']}))
try:
 assert git('initial-head','rev-parse','HEAD')==control and git('initial-branch','branch','--show-current')=='interval-trace-materialization' and not git('initial-clean','status','--porcelain=v1');assert not git('current-source-diff','diff','--name-only',base,current,'--','crates','Cargo.toml','Cargo.lock','.cargo')
 for v in load(s/'provenance.json'):assert sha((h/v['path']).read_bytes())==v['sha256']==sha(Path(v['source']).read_bytes())
 fragments=load(s/'observer-fragments.json');text=(h/'public.rs').read_text();assert fragments['execution_fragment'] in text and fragments['printing_fragment'] in text
 git('base-checkout','checkout','--detach',base);run('lock',['cargo','+1.95.0','generate-lockfile','--offline']);run('format',['cargo','+1.95.0','fmt','--all','--','--check']);run('compiler',['rustc','+1.95.0','-Vv'])
 for label,revision in [('baseline',base),('candidate',candidate)]:
  if label=='candidate':git('candidate-checkout','checkout','--detach',revision)
  assert git(label+'-head','rev-parse','HEAD')==revision
  build(label,revision,'owner');build(label,revision,'default');build(label,revision,'trace','trace')
  if label=='candidate':build(label,revision,'added-default','cancel-retry');build(label,revision,'added-trace','trace,cancel-retry')
  run(label+'-owner-clippy',['cargo','+1.95.0','clippy','--locked','--offline','-p','hypersolve','--no-default-features','--bench','certification','--','-D','warnings'],work=r)
 for features in ['', 'trace','cancel-retry','trace,cancel-retry']:
  args=['cargo','+1.95.0','clippy','--locked','--offline','--all-targets']
  if features:args+=['--features',features]
  run('public-clippy-'+(features.replace(',','-') or 'default'),args+['--','-D','warnings'])
 for family in ['default','trace']:
  pair=[b for b in builds if b['family']==family];raws=[gzip.decompress((s/b['control_log']).read_bytes()).decode() for b in pair];selected=lambda raw:[x for x in raw.splitlines() if x.startswith(('CASE ','OUTPUT ','TRACE '))];assert len(pair)==2 and selected(raws[0])==selected(raws[1]);assert len(selected(raws[0]))==pair[0]['expected_cases']*3
 run('final-format',['cargo','+1.95.0','fmt','--all','--','--check']);assert not git('candidate-clean','status','--porcelain=v1');git('restore-control','checkout','interval-trace-materialization');assert git('restored-head','rev-parse','HEAD')==control and not git('restored-clean','status','--porcelain=v1');save('build-completion.json',dict(exit_code=0,commands=len(commands),aggregate_direct_children=len(commands)+1,images=len(builds),functional_case_invocations=sum(b['expected_cases'] for b in builds),source_restored=True,seconds=time.monotonic()-start,admitted=False));print('Runtime builds and functional controls complete',flush=True)
except BaseException as error:save('build-completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),aggregate_direct_children=len(commands)+1,seconds=time.monotonic()-start,automatic_retry=False,admitted=False));raise
