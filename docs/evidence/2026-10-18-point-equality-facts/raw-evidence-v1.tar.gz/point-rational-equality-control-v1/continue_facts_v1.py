"""Continue scalar-fact qualification after terminal combined native gates."""
import json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import dump,sha,resources,reasons
combined=json.loads((N/'point-rational-native-facts-gates-result-v1.json').read_text())
assert combined['source_unchanged'] and all(r['output_closed'] and not r['stops'] for r in combined['commands'].values())
steps=[['facts_validate_v2.py','gates'],['facts_reports_v1.py'],['combined_facts_kernel_validate_v1.py','point-unit'],['combined_facts_kernel_validate_v1.py','scalar-suite'],['combined_facts_kernel_validate_v1.py','curve-suite'],['combined_facts_kernel_validate_v1.py','kernel-clippy'],['combined_facts_kernel_validate_v1.py','kernel-doc']]
protocol=N/'point-rational-facts-continuation-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'steps':steps,'step_helpers_sha256':{s[0]:sha(W/s[0]) for s in steps},'combined_gates_result_sha256':sha(N/'point-rational-native-facts-gates-result-v1.json'),'resource_contract_unchanged':True})
progress=[]
for step in steps:
    assert not reasons(resources())
    started=time.time();print(json.dumps({'starting':step}),flush=True)
    code=subprocess.run([sys.executable,str(W/step[0]),*step[1:]],cwd=W).returncode
    progress.append({'step':step,'exit_code':code,'start_unix':started,'end_unix':time.time()})
    dump(N/'point-rational-facts-continuation-progress-v1.json',progress)
    assert code==0,step
    if step==['facts_validate_v2.py','gates']:
        assert json.loads((N/'point-rational-facts-gates-result-v2.json').read_text())['passed']
dump(N/'point-rational-facts-continuation-result-v1.json',{'steps':progress,'listed_phases_passed':True,'admitted':False,'full_plan_complete':False})
