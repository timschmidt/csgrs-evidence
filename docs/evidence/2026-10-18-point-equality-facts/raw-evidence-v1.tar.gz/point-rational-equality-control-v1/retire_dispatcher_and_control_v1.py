"""Retire the stopped old dispatcher only after its child is terminal."""
import json,os,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import dump,sha,reasons,resources
transition=json.loads((W/'retention-transition-v1.json').read_text());pid=transition['pid']
phase=N/'point-rational-kernel-facts-curve-suite-result-v2.json'
command=N/'logs/point-rational-kernel-facts-curve-suite-tests-v2/result.json'
pending=W/'retention-transition-completion-v1.json';assert not pending.exists()
protocol=W/'retention-transition-wait-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'original_transition_sha256':sha(W/'retention-transition-v1.json'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'next_helper_sha256':sha(W/'rational_control_v2.py'),'action':'wait for terminal old-contract curve child, verify stopped dispatcher identity and no live child, retire dispatcher, run isolated direct Rational control','elapsed_wait_is_not_approval':True})
print('waiting for the original curve child to close',flush=True)
started=time.monotonic()
while not command.exists():
    assert time.monotonic()-started<1900
    time.sleep(3)
r=json.loads(command.read_text());assert r['output_closed']
if r['exit_code']==0 and not r['stops']:
    deadline=time.monotonic()+30
    while not phase.exists():
        assert time.monotonic()<deadline;time.sleep(1)
stat_path=Path('/proc')/str(pid)/'stat'
state=stat_path.read_text();assert state.split()[21]==transition['proc_stat'].split()[21]
assert state.split()[2] in ['T','t']
argv=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0');assert [a.decode() for a in argv if a]==transition['argv']
children=(Path('/proc')/str(pid)/'task'/str(pid)/'children').read_text().split();child_states={}
for child in children:
    child_state=(Path('/proc')/child/'stat').read_text();assert child_state.split()[2]=='Z';child_states[child]=child_state
os.kill(pid,signal.SIGKILL)
dump(pending,{'dispatcher_pid':pid,'dispatcher_stat_before':state,'children_terminal_zombies':child_states,'intentional_dispatcher_replacement':True,'current_child_output_closed':True,'current_child_command_result_sha256':sha(command),'current_child_phase_result_sha256':sha(phase) if phase.exists() else None,'old_dispatcher_progress_not_updated_after_stop':True,'signal':'SIGKILL to stopped dispatcher only after child completion','new_contract_sha256':sha(W/'retention-contract-v2.json'),'unix':time.time()})
assert r['exit_code']==0 and not r['stops'],r
assert json.loads(phase.read_text())['passed'] and not reasons(resources())
print('original curve child passed; dispatcher retired; starting direct Rational control',flush=True)
code=subprocess.run([sys.executable,str(W/'rational_control_v2.py')],cwd=W).returncode
p=W/'retention-transition-control-result-v1.json';assert not p.exists();dump(p,{'exit_code':code,'helper_sha256':sha(W/'rational_control_v2.py'),'admitted':False})
assert code==0
