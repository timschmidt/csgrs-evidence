"""Compare the unchanged allocation probe and added semantic checks on pinned kernels."""
import gzip,json,os,platform,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
S=N/'point-rational-facts-source-v1';T=V/'targets/point-rational-native-facts-v1';A=N/'point-rational-inline-facts-cost-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert json.loads((N/'point-rational-inline-facts-build-result-v1.json').read_text())['passed']
assert all((p/'result.json').exists() for p in (N/'logs').glob('point-rational-*') if (p/'process.json').exists())
assert not A.exists();A.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
pins=json.loads(gzip.decompress((N/'point-rational-facts-source-v1.json.gz').read_bytes()));assert all(sha(S/p)==h for p,h in pins.items())
libs={};searches=set()
for line in (N/'logs/point-rational-inline-facts-build-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hypercurve','hyperreal','hyperlimit'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libs[r['target']['name']]=str(V/Path(p).relative_to(M))
assert len(libs)==3;inputs={k:{'path':p,'sha256':sha(p)} for k,p in libs.items()};commands={};rows=[]
old=N/'native-track-revisit-point-cost-v1';old_result=json.loads((old/'result-v1.json').read_text());baseline=old/'point-equality-cost';assert sha(baseline)==old_result['binary_sha256']
assert sha(W/'point_equality_cost_v1.rs')==old_result['source_sha256']
source_hashes={str(p):sha(p) for p in [W/'point_equality_cost_v1.rs',W/'point_equality_contract.rs']}
def execute(label,args):
    assert not reasons(resources());name='point-rational-inline-facts-cost-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--ro-bind',str(T),str(T),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    try:r=run(name,argv+args,S,target=T,wall_seconds=60)
    except RuntimeError:r=json.loads((N/'logs'/name/'result.json').read_text())
    commands[label]=r;dump(A/'progress-v1.json',commands)
    assert not r['stops'] and r['exit_code']==0,r
    return (N/'logs'/name/'stdout').read_text()
for name,source,test in [('point-equality-contract',W/'point_equality_contract.rs',True),('point-equality-cost',W/'point_equality_cost_v1.rs',False)]:
    args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(A/name),'-L','dependency='+str(T/'release/deps')]
    if test:args+=['--test']
    for path in sorted(searches):args+=['-L',path]
    for k,p in sorted(libs.items()):args+=['--extern',k+'='+p]
    execute(name+'-compile',args)
out=execute('contract',[str(A/'point-equality-contract'),'--test-threads=1','--nocapture']);assert '3 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in out
candidate=A/'point-equality-cost';binary_hashes={'baseline':sha(baseline),'candidate':sha(candidate)}
for ordinal,mode in enumerate(['baseline','candidate','candidate','baseline']):
    binary=baseline if mode=='baseline' else candidate
    for case in ['integer','shared','same-x','decimal','non-dyadic','subrange','superrange','large-coefficients','symbolic']:
        assert sha(binary)==binary_hashes[mode]
        out=execute(str(ordinal)+'-'+mode+'-'+case,[str(binary),case]);parsed=[json.loads(line) for line in out.splitlines() if line.startswith('{')]
        assert len(parsed)==2 and [r['comparisons'] for r in parsed]==[4096,65536] and [r['equal'] for r in parsed]==[64,1024] and all(r['case']==case for r in parsed)
        rows.extend(dict(r,mode=mode,ordinal=ordinal) for r in parsed);dump(A/'rows-v1.json',rows)
assert all(sha(p)==h for p,h in source_hashes.items()) and all(sha(v['path'])==v['sha256'] for v in inputs.values()) and all(sha(S/p)==h for p,h in pins.items())
environment={'kernel':platform.uname()._asdict(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'lscpu':json.loads(subprocess.check_output(['lscpu','--json'],text=True)),'compiler_protocol_sha256':sha(V/'cargo-preparation-protocol-v1.json'),'build_jobs':2,'no_task_owned_compilation_or_native_run_overlapped':True}
dump(A/'environment-v1.json',environment)
dump(A/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'scalar-facts-inline-contract-v1.md'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'production_overlay_sha256':sha(W/'rational_comparison_inline_v2.rs'),'sources_sha256':source_hashes,'source_inventory_sha256':sha(N/'point-rational-facts-source-v1.json.gz'),'candidate_libraries':inputs,'baseline_result_sha256':sha(old/'result-v1.json'),'baseline_binary_sha256':binary_hashes['baseline'],'candidate_binary_sha256':binary_hashes['candidate'],'binary_bytes':{'baseline':baseline.stat().st_size,'candidate':candidate.stat().st_size},'commands':commands,'rows':rows,'all_cases_completed_and_matched_integer_oracle':True,'contract_tests_passed':3,'instrumented_diagnostic_not_general_benchmark':True,'admitted':False})
print(json.dumps({'completed_processes':36,'matched_rows':len(rows),'contract_tests':3,'binary_bytes':{'baseline':baseline.stat().st_size,'candidate':candidate.stat().st_size}}),flush=True)
