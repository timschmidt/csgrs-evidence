"""Combine the isolated point proof shortcut with the unchanged rejected exact importer."""
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
P=N/'point-rational-facts-source-v1';B=N/'native-track-revisit-source-v1';S=N/'point-rational-native-facts-source-v1';T=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/targets/point-rational-native-facts-v1')
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import sha,dump,GIT,reasons,resources
assert not reasons(resources())
cost=json.loads((N/'point-rational-facts-cost-v1/result-v1.json').read_text());assert cost['all_cases_completed_and_matched_integer_oracle'] and cost['contract_tests_passed']==3
prep=json.loads((W/'facts-preparation-v1.json').read_text());assert sha(P/'crates/hypercurve/src/point.rs')==prep['implementation_sha256']['crates/hypercurve/src/point.rs']
assert all(sha(B/p)==h for p,h in json.loads(gzip.decompress((N/'native-track-revisit-source-v1.json.gz').read_bytes())).items())
def git(a,cwd=O,stdin=None):return subprocess.run(GIT+a,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip();assert head=='1b90c0105c71e09cacb613b4d8bfe63d62011d1c'
assert not git(['diff','HEAD','--name-only']) and not S.exists() and not T.exists()
git(['worktree','add','--no-checkout','-b','codex/point-rational-native-facts-20261017',str(S),head])
sparse=W/'sparse-selection-v1.txt';git(['sparse-checkout','set','--no-cone','--stdin'],S,sparse.read_bytes());git(['checkout','codex/point-rational-native-facts-20261017'],S)
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-integration-source-v1.json.gz').read_bytes()));normalizations={}
for p,h in pins.items():
    if p=='docs/properties-status.json':h=sha(O/p)
    assert sha(O/p)==h
    if sha(S/p)!=h:
        assert (S/p).read_bytes()==(O/p).read_bytes().replace(b'\r\n',b'\n'),p
        normalizations[p]={'checkout_sha256':sha(S/p),'original_sha256':h};shutil.copy2(O/p,S/p)
origins={}
for root,paths in [(P,['crates/hypercurve/src/point.rs','crates/hypercurve/tests/point_equality_contract.rs','crates/hyperreal/src/rational/arithmetic/comparison.rs','crates/hyperreal/src/rational/arithmetic/tests.rs','crates/hyperreal/src/real/arithmetic/facts.rs','crates/hyperreal/src/real/mod.rs','crates/hyperreal/src/real/immediate_equality_tests.rs']),(B,['crates/hyperdrc/src/kicad/tracks.rs','crates/hyperdrc/tests/kicad_track_failures.rs','crates/hyperdrc/tests/kicad_native_strokes.rs','crates/hyperdrc/tests/kicad_native_aggregation.rs'])]:
    for p in paths:shutil.copy2(root/p,S/p);origins[p]={'source_path':str(root/p),'sha256':sha(root/p)}
assert set(git(['diff','--name-only'],S).decode().splitlines())=={'crates/hypercurve/src/point.rs','crates/hyperreal/src/rational/arithmetic/comparison.rs','crates/hyperreal/src/rational/arithmetic/tests.rs','crates/hyperreal/src/real/arithmetic/facts.rs','crates/hyperreal/src/real/mod.rs','crates/hyperdrc/src/kicad/tracks.rs','crates/hyperdrc/tests/kicad_track_failures.rs'}
assert not git(['diff','--check'],S)
tracked=git(['ls-files','-z'],S).decode().split('\0')[:-1];pins={p:sha(S/p) for p in tracked if (S/p).is_file()};pins.update({p:v['sha256'] for p,v in origins.items()})
inv=N/'point-rational-native-facts-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'combined-facts-tracked-v1.patch').write_bytes(git(['diff','--binary'],S))
dump(W/'combined-facts-preparation-v1.json',{'revision':head,'source_root':str(S),'target':str(T),'source_inventory_sha256':sha(inv),'source_files':len(pins),'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'scalar-facts-contract-v1.md'),'origins':origins,'checkout_normalizations':normalizations,'only_production_delta_from_rejected_e66':['crates/hypercurve/src/point.rs','crates/hyperreal/src/rational/arithmetic/comparison.rs','crates/hyperreal/src/real/arithmetic/facts.rs'],'unchanged_e66_importer':True,'cache_proposal_present':False,'admitted':False})
print(json.dumps({'source_files':len(pins),'delta_from_e66':['crates/hypercurve/src/point.rs','crates/hyperreal/src/rational/arithmetic/comparison.rs','crates/hyperreal/src/real/arithmetic/facts.rs']}),flush=True)
