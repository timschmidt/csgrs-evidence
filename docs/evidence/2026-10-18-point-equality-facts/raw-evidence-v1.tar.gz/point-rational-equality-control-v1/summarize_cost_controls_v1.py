"""Preserve both favorable and unfavorable instrumented equality observations."""
import hashlib,json,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def read(p):return json.loads(Path(p).read_text())

names=['point-rational-equality-cost-v1','point-rational-facts-cost-v1','point-rational-inline-facts-cost-v1','point-rational-direct-control-v1','point-rational-inline-direct-control-v2','point-rational-inline-matched-control-v1']
result={}
for name in names:
    path=N/name/'result-v1.json';raw=read(path)
    assert raw['all_cases_completed_and_matched_integer_oracle']
    rows=raw['rows'];groups={}
    for case in sorted({r['case'] for r in rows}):
        for phase in sorted({r['phase'] for r in rows}):
            selected=[r for r in rows if r['case']==case and r['phase']==phase]
            modes={m:sorted([r for r in selected if r['mode']==m],key=lambda x:x['ordinal']) for m in ['baseline','candidate']}
            assert len(modes['baseline'])==len(modes['candidate']) and modes['baseline']
            assert len({(r['comparisons'],r['equal']) for r in selected})==1
            medians={m:statistics.median(r['elapsed_ns'] for r in rr) for m,rr in modes.items()}
            groups[case+'/'+phase]={'rows':modes,'baseline_median_ns':medians['baseline'],'candidate_median_ns':medians['candidate'],'median_time_change_percent':100*(medians['candidate']/medians['baseline']-1),'baseline_range_ns':[min(r['elapsed_ns'] for r in modes['baseline']),max(r['elapsed_ns'] for r in modes['baseline'])],'candidate_range_ns':[min(r['elapsed_ns'] for r in modes['candidate']),max(r['elapsed_ns'] for r in modes['candidate'])]}
    result[name]={'source_result_path':str(path),'source_result_sha256':sha(path),'row_count':len(rows),'all_rows_retained':sum(len(g['rows']['baseline'])+len(g['rows']['candidate']) for g in groups.values())==len(rows),'groups':groups,'binaries':raw.get('binaries',raw.get('binary_bytes'))}
output=W/'all-equality-cost-controls-review-v1.json';assert not output.exists()
output.write_text(json.dumps({'helper_sha256':sha(Path(__file__)),'controls':result,'timings_are_allocator_instrumented':True,'standalone_inline_scalar_context_unmatched':True,'general_benchmark_claim':False,'admission_decided_here':False},indent=2,sort_keys=True)+'\n')
for name in names:
    print(name)
    for label,g in result[name]['groups'].items():
        if label.endswith('/repeated-traversal'):
            print(label,round(g['median_time_change_percent'],3),g['baseline_range_ns'],g['candidate_range_ns'])
print('review_sha256',sha(output),flush=True)
