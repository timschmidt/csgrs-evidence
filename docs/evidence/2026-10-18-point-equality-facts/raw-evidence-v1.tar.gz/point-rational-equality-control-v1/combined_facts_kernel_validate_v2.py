"""Shared scalar and curve qualification using the preserved combined source."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'point-rational-native-facts-source-v1';T=M/'targets/point-rational-native-facts-v1';physical_target=V/'targets/point-rational-native-facts-v1';A=V/'point-rational-native-facts-artifacts-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,reasons,resources
phase=sys.argv[1];assert phase in ['point-unit','scalar-suite','curve-suite','kernel-clippy','kernel-doc']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
inv=N/'point-rational-native-facts-source-v1.json.gz';pins=json.loads(gzip.decompress(inv.read_bytes()));commands={};summaries={}
protocol=N/('point-rational-kernel-facts-'+phase+'-protocol-v2.json');assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'runner_sha256':sha(N/'control/validation_runner_v3.py'),'source_inventory_sha256':sha(inv),'contract_sha256':sha(W/'scalar-facts-contract-v1.md'),'compiler_sha256':compiler['tool_sha256'],'target_initially_absent':not physical_target.exists(),'runtime_cwd':'writable private scratch','cache_proposal_present':False,'hypervoxel_excluded':True,'test_overlay_sha256':'b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6','production_delta_from_initial_source':False,'api_inventory_overlay_sha256':'e0ca03d37445c0f5fef332414c8057fbfd78de8131e3f25b14d095cc8ca23ab4','api_inventory_contract_sha256':sha(W/'api-classification-contract-v1.md')})
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
    if (A/'executables-v1.json').exists():assert all(sha(v['executed_copy'])==v['sha256'] for v in json.loads((A/'executables-v1.json').read_text()).values())
def execute(label,args,binary=False,allow_failure=False):
    verify();name='point-rational-kernel-facts-'+phase+'-'+label+'-v2';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(scratch if binary else S)]
    overlay=W/'immediate_equality_tests_v2.rs'
    assert sha(overlay)=='b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6'
    argv+=['--ro-bind',str(overlay),str(S/'crates/hyperreal/src/real/immediate_equality_tests.rs')]
    inventory_overlay=W/'gmp_api_coverage_v2.rs'
    assert sha(inventory_overlay)=='e0ca03d37445c0f5fef332414c8057fbfd78de8131e3f25b14d095cc8ca23ab4'
    argv+=['--ro-bind',str(inventory_overlay),str(S/'crates/hyperreal/tests/gmp_api_coverage.rs')]
    if binary:argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,S,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(N/('point-rational-kernel-facts-'+phase+'-progress-v2.json'),commands)
        if r['stops'] or not allow_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(N/('point-rational-kernel-facts-'+phase+'-progress-v2.json'),commands)
    verify();out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',err)
    return out,err,r
def rows(text):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
if phase=='point-unit':
    out,err,r=execute('tests',[cargo,'test','--release','--locked','-p','hypercurve','--lib','point::','--','--test-threads=1','--nocapture'])
    summary=rows(out);assert len(summary)==1 and summary[0][0]=='ok' and int(summary[0][1])>=11 and summary[0][2:5]==('0','0','0'),summary
    summaries['existing_point_tests']=summary
elif phase in ['scalar-suite','curve-suite']:
    package='hyperreal' if phase=='scalar-suite' else 'hypercurve'
    out,err,r=execute('tests',[cargo,'test','--release','--locked','-p',package,'--all-features','--no-fail-fast','--','--test-threads=2'])
    summary=rows(out);assert summary and all(v[0]=='ok' and v[2]=='0' for v in summary),summary
    summaries[package]=summary
elif phase=='kernel-clippy':
    out,err,r=execute('lint',[cargo,'clippy','--release','--locked','-p','hyperreal','-p','hypercurve','--all-targets','--all-features','--','-D','warnings'])
    summaries['all_features_all_targets']=True
elif phase=='kernel-doc':
    os.environ['RUSTDOCFLAGS']='-D warnings'
    out,err,r=execute('docs',[cargo,'doc','--release','--locked','-p','hyperreal','-p','hypercurve','--all-features','--no-deps'])
    summaries['all_features_docs_warnings_denied']=True
verify();dump(N/('point-rational-kernel-facts-'+phase+'-result-v2.json'),{'phase':phase,'commands':commands,'summaries':summaries,'passed':all(r['exit_code']==0 for r in commands.values()),'source_unchanged':True,'admitted':False,'full_plan_complete':False})
print(json.dumps({'phase':phase,'summaries':summaries}),flush=True)
