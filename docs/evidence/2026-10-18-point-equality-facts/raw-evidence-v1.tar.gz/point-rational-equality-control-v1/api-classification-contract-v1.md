# Public scalar API benchmark classification

The all-feature scalar suite on the pinned candidate fails its existing
`gmp_api_coverage` check because `Real::immediate_equality` has no entry. The
failure and complete run remain preserved. The owning layer is Hyperreal's
public numeric API inventory; P3, P36 and P37 apply.

Classify the method alongside the existing retained-structure and certification
queries. It returns an optional exact fact and intentionally leaves some
rational pairs and symbolic inputs inconclusive. GMP's total rational equality
and MPFR's comparison of rounded values do not supply this partial proof-search
contract. This is not a competitive GMP benchmark claim. The nine-family exact
Point2 consumer probe supplies the measured costs of the new method's use and
complete fallback, including the rejected wide-coefficient direct-comparison
alternative.

Add one documented inventory entry. Preserve the test's public API discovery,
full inventory, failure assertion and all benchmark fixtures. Production code
and supported numeric inputs do not change. Bind the corrected inventory as a
hashed read-only test overlay, preserving both original snapshots and the
failed run. Rerun the full scalar suite and affected lint checks after this edit.
