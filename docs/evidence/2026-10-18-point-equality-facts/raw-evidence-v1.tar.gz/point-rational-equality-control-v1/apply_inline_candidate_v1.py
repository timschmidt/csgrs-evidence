"""Apply only qualified equality bytes after explicit cost review."""
import gzip,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-facts-source-v1'
BASE='c4f6b43e4431601853cf482ac9d80936b8adde5f'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'

def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def read(p):return json.loads(Path(p).read_text())

def dump(p,v):
    assert not Path(p).exists(),p;Path(p).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')

def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)

assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert sha(O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py')=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
review=read(W/'inline-admission-review-v1.json');assert review['proceed_with_integration'] and not review['runtime_admitted']
assert read(N/'point-rational-inline-continuation-result-v2.json')['listed_phases_passed']
assert read(N/'point-rational-inline-matched-control-v1/result-v1.json')['all_cases_completed_and_matched_integer_oracle']
previous=read(O/'docs/evidence/2026-10-18-point-equality-strengthening/checkpoint-v1.json')
live=previous['restored_native_sha256']|previous['inherited_implementation_sha256']|previous['implementation_sha256']
assert all(sha(O/p)==h for p,h in live.items())
assert sha(O/'docs/properties-status.json')==previous['ledger_after_sha256']
pins=json.loads(gzip.decompress((N/'point-rational-facts-source-v1.json.gz').read_bytes()))
assert all(sha(S/p)==h for p,h in pins.items())
files={p:S/p for p in ['crates/hypercurve/src/point.rs','crates/hyperreal/src/rational/arithmetic/tests.rs','crates/hyperreal/src/real/arithmetic/facts.rs','crates/hyperreal/src/real/mod.rs']}
overlays={'crates/hyperreal/src/rational/arithmetic/comparison.rs':('rational_comparison_inline_v2.rs','c1790e9b60bb046224a5c05a6f6d30bd68d60db4fcf1632250e982a97f725bf2'),'crates/hyperreal/src/real/immediate_equality_tests.rs':('immediate_equality_tests_v2.rs','b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6'),'crates/hyperreal/tests/gmp_api_coverage.rs':('gmp_api_coverage_v2.rs','e0ca03d37445c0f5fef332414c8057fbfd78de8131e3f25b14d095cc8ca23ab4')}
for p,(name,h) in overlays.items():
    assert sha(W/name)==h;files[p]=W/name
readme=read(W/'documentation-proposal-v1.json');assert sha(readme['source'])==readme['source_sha256'] and sha(readme['proposal'])==readme['proposal_sha256'];files['crates/hyperreal/README.md']=Path(readme['proposal'])
point='crates/hypercurve/tests/point_equality_contract.rs';assert sha(O/point)==sha(W/'point_equality_contract_v2.rs')=='20258117bca15727e8c1299cfb7e84265b8fe4411c3ba56294eab998a55d43ca'
qualified={p:h for p,h in pins.items() if p.startswith(('crates/','src/','tests/','examples/','.cargo/')) or p in ['Cargo.toml','Cargo.lock','build.rs','.rustfmt.toml']}
assert len(qualified)==2653
qualified.update({p:sha(q) for p,q in files.items()});qualified[point]=sha(O/point)
assert all(sha(O/p)==h for p,h in qualified.items() if p not in files)
rows={p:{'source':str(q),'before_sha256':sha(O/p) if (O/p).exists() else None,'qualified_sha256':sha(q)} for p,q in files.items()}
dump(W/'main-integration-application-protocol-v1.json',{'parent_revision':BASE,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'main-integration-contract-v1.md'),'review_sha256':sha(W/'inline-admission-review-v1.json'),'files':rows,'point_contract_unchanged':True,'new_runtime_validation_required':True})
for p,q in files.items():shutil.copy2(q,O/p)
assert all(sha(O/p)==h for p,h in qualified.items())
assert all(sha(S/p)==h for p,h in pins.items())
dump(W/'main-integration-application-result-v1.json',{'files':rows,'qualified_input_sha256':qualified,'source_and_fixture_paths_compared':len(qualified),'only_declared_files_applied':True,'point_contract_unchanged':True,'runtime_admitted':False,'final_validation_pending':True,'final_performance_documentation_pending':True})
print(json.dumps({'copied_files':len(files),'qualified_paths_compared':len(qualified)}),flush=True)
