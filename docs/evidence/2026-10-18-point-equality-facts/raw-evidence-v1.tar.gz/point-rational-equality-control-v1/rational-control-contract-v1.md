# Direct Rational equality control

Hyperreal owns the complete rational comparison, which now consumes the shared
partial fact before its unchanged cross-product fallback. P3, P5 and P36 require
checking that extraction separately from the Point2 consumer improvement.

Compile one identical new source against the frozen current-production and
scalar-fact candidate libraries. It compares Rational values directly. Seven
rational families retain the point probe's exact base/scale construction:
integers, shared storage, decimals, non-dyadic fractions, subrange, superrange,
and the full 1e12000 + i*1e-400 large-coefficient case. The scalar domain does
not include symbolic points or a second coordinate; the original nine-family
Point2 probe remains unchanged and preserved.

For each family, all 4096 pairs in a 64-value grid must match the independently
derived integer equality i == j. Translation and nonzero rational scaling are
injective. Preserve one cold traversal, then 1024 repeated traversals for the
six smaller cases and 16 for the large-coefficient case, identically for both
versions. This is a new control with declared counts, not a reduction of any
existing case. Use B-C-C-B process order, retain every row, and count requested
Rust allocation payload with the existing System allocator instrumentation.
Construction and output are outside the loop. This diagnostic is not a
competitive GMP benchmark, RSS measurement, universal bound or general speed
claim. No other task-owned compilation or timed workload may overlap the runs.
The original external 60-second probe and cumulative storage limits still apply.
