use hypercurve::Point2;
use hyperreal::Real;
use std::alloc::{GlobalAlloc, Layout, System};
use std::hint::black_box;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::Instant;

struct Meter;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
fn allocated(size: usize) {
    if ACTIVE.load(Ordering::Relaxed) {
        ALLOCS.fetch_add(1, Ordering::Relaxed);
        REQUESTED.fetch_add(size, Ordering::Relaxed);
    }
    let live = LIVE.fetch_add(size, Ordering::Relaxed) + size;
    PEAK.fetch_max(live, Ordering::Relaxed);
}
unsafe impl GlobalAlloc for Meter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() { allocated(layout.size()); }
        p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() { allocated(layout.size()); }
        p
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
        unsafe { System.dealloc(ptr, layout) };
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let p = unsafe { System.realloc(ptr, layout, size) };
        if !p.is_null() {
            LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
            allocated(size);
        }
        p
    }
}
#[global_allocator]
static ALLOCATOR: Meter = Meter;
fn real(s: &str) -> Real { s.parse().unwrap() }
fn run(points: &[(Point2, Point2)], count: usize) -> usize {
    let mut equal = 0;
    for _ in 0..count {
        for (i, (a, _)) in points.iter().enumerate() {
            for (j, (_, b)) in points.iter().enumerate() {
                let same = black_box(a) == black_box(b);
                assert_eq!(same, i == j);
                equal += usize::from(same);
            }
        }
    }
    equal
}
fn main() {
    let kind = std::env::args().nth(1).unwrap();
    let (base, scale) = match kind.as_str() {
        "integer" | "shared" | "same-x" => (Real::zero(), Real::one()),
        "decimal" => (real("123.456789"), real("-0.000001")),
        "non-dyadic" => (Real::zero(), (Real::one()/Real::from(97)).unwrap()),
        "subrange" => (Real::zero(), real("1e-400")),
        "superrange" => (real("1e400"), Real::one()),
        "large-coefficients" => (real("1e12000"), real("1e-400")),
        "symbolic" => (Real::pi(), real("-3")),
        _ => panic!("unknown input family"),
    };
    let make = |i: i32| {
        let x = if kind == "same-x" { base.clone() } else { &base + Real::from(i) * &scale };
        let y = &base + Real::from(i + 1) * &scale;
        Point2::new(x, y)
    };
    let points: Vec<_> = (0..64).map(|i| {
        let left = make(i);
        let right = if kind == "shared" { left.clone() } else { make(i) };
        (left, right)
    }).collect();
    for (phase, iterations) in [("first-traversal", 1), ("repeated-traversal", 16)] {
        let start_live = LIVE.load(Ordering::Relaxed);
        ALLOCS.store(0, Ordering::Relaxed);
        REQUESTED.store(0, Ordering::Relaxed);
        PEAK.store(start_live, Ordering::Relaxed);
        ACTIVE.store(true, Ordering::Relaxed);
        let start = Instant::now();
        let equal = run(&points, iterations);
        let ns = start.elapsed().as_nanos();
        ACTIVE.store(false, Ordering::Relaxed);
        let live = LIVE.load(Ordering::Relaxed);
        let peak = PEAK.load(Ordering::Relaxed);
        let allocs = ALLOCS.load(Ordering::Relaxed);
        let requested = REQUESTED.load(Ordering::Relaxed);
        assert_eq!(equal, 64 * iterations);
        println!("{{\"case\":\"{kind}\",\"phase\":\"{phase}\",\"comparisons\":{},\"equal\":{equal},\"allocations\":{allocs},\"requested_bytes\":{requested},\"live_before\":{start_live},\"live_after\":{live},\"peak\":{peak},\"elapsed_ns\":{ns}}}", 4096 * iterations);
    }
}
