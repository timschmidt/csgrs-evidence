"""Finish the inline candidate's affected qualification without relaxing gates."""
import json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import dump,sha,resources,reasons
assert json.loads((W/'inline-point-review-v1.json').read_text())['continue_qualification']
assert json.loads((W/'inline-direct-rational-review-v1.json').read_text())['continue_qualification']
assert all((p/'result.json').exists() for p in (N/'logs').glob('point-rational-*') if (p/'process.json').exists())
assert json.loads((N/'point-rational-inline-facts-gates-result-v1.json').read_text())['passed']
assert json.loads((N/'point-rational-inline-facts-report-result-v1.json').read_text())['all_report_bytes_equal']
assert json.loads((N/'point-rational-contract-strengthening-v1/result-v1.json').read_text())['passed']
steps=[['inline_native_suite_v1.py'],['inline_downstream_validate_v2.py','native-doctests'],['inline_kernel_validate_v2.py','scalar-suite'],['inline_kernel_validate_v2.py','curve-suite'],['inline_kernel_validate_v2.py','kernel-clippy'],['inline_kernel_validate_v2.py','kernel-doc'],['inline_downstream_validate_v2.py','predicates'],['inline_downstream_validate_v2.py','mesh'],['inline_downstream_validate_v2.py','modeling'],['inline_downstream_validate_v2.py','circuit'],['inline_downstream_validate_v2.py','native-quality'],['inline_downstream_validate_v2.py','native-doc'],['inline_msrv_v2.py']]
protocol=N/'point-rational-inline-continuation-protocol-v2.json';assert not protocol.exists()
pins={s[0]:sha(W/s[0]) for s in steps}
dump(protocol,{'helper_sha256':sha(Path(__file__)),'preceding_gates_sha256':sha(N/'point-rational-inline-facts-gates-result-v1.json'),'preceding_reports_sha256':sha(N/'point-rational-inline-facts-report-result-v1.json'),'point_contract_validation_sha256':sha(N/'point-rational-contract-strengthening-v1/result-v1.json'),'dispatcher_retirement_sha256':sha(N/'point-rational-contract-strengthening-v1/dispatcher-retirement-v1.json'),'steps':steps,'step_helpers_sha256':pins,'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'runner_sha256':sha(W/'validation_runner_v4.py'),'execution_limits_unchanged':True,'disk_b_allowance_gib':72,'point_cost_review_sha256':sha(W/'inline-point-review-v1.json'),'scalar_control_review_sha256':sha(W/'inline-direct-rational-review-v1.json'),'earlier_failures_preserved':True,'native_full_suite_includes_focused_cases_and_original_gates':True,'main_test_only_commit':'7758062126b228695cb7a56aaaa205923ffc86c9'})
progress=[]
for step in steps:
    assert all(sha(W/name)==digest for name,digest in pins.items());assert not reasons(resources())
    started=time.time();print(json.dumps({'starting':step}),flush=True)
    code=subprocess.run([sys.executable,str(W/step[0]),*step[1:]],cwd=W).returncode
    progress.append({'step':step,'exit_code':code,'start_unix':started,'end_unix':time.time()});dump(N/'point-rational-inline-continuation-progress-v2.json',progress)
    assert code==0,step
    if step==['inline_facts_validate_v1.py','gates']:
        assert json.loads((N/'point-rational-inline-facts-gates-result-v1.json').read_text())['passed']
dump(N/'point-rational-inline-continuation-result-v2.json',{'steps':progress,'listed_phases_passed':True,'admitted':False,'full_plan_complete':False})
