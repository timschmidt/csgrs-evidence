"""Build the one-attribute scalar successor and run its direct equality control."""
import gzip,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');S=N/'point-rational-facts-source-v1';T=M/'targets/point-rational-native-facts-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert all((p/'result.json').exists() for p in (N/'logs').glob('point-rational-*') if (p/'process.json').exists())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
inv=N/'point-rational-facts-source-v1.json.gz';pins=json.loads(gzip.decompress(inv.read_bytes()));assert all(sha(S/p)==h for p,h in pins.items())
overlay=W/'rational_comparison_inline_v2.rs';assert sha(overlay)=='c1790e9b60bb046224a5c05a6f6d30bd68d60db4fcf1632250e982a97f725bf2'
protocol=N/'point-rational-inline-scalar-build-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'source_inventory_sha256':sha(inv),'production_overlay_sha256':sha(overlay),'contract_sha256':sha(W/'scalar-facts-inline-contract-v1.md'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'compiler_sha256':compiler['tool_sha256'],'features':['cached-f64-approx','default','serde'],'target_mutable_before_execution':True,'next_control_helper_sha256':sha(W/'rational_inline_control_v1.py')})
name='point-rational-inline-scalar-build-v1';scratch=N/'scratch'/name
args=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--ro-bind',str(overlay),str(S/'crates/hyperreal/src/rational/arithmetic/comparison.rs'),'--chdir',str(S)]
for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():args+=['--setenv',k,v]
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
r=run(name,args+[cargo,'build','--release','--locked','-p','hyperreal','--features','cached-f64-approx,serde','--message-format=json'],S,target=T)
lines=[json.loads(line) for line in (N/'logs'/name/'stdout').read_text().splitlines() if line.startswith('{')]
found=[row for row in lines if row.get('reason')=='compiler-artifact' and row['target']['name']=='hyperreal'];assert len(found)==1 and not found[0]['fresh']
row=found[0];assert row['features']==['cached-f64-approx','default','serde'];files=[p for p in row['filenames'] if p.endswith('.rlib')];assert len(files)==1
library=V/Path(files[0]).relative_to(M);assert library.is_file()
assert all(sha(S/p)==h for p,h in pins.items()) and sha(overlay)=='c1790e9b60bb046224a5c05a6f6d30bd68d60db4fcf1632250e982a97f725bf2'
err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M)
dump(N/'point-rational-inline-scalar-build-result-v1.json',{'passed':True,'command':r,'library':{'path':str(library),'sha256':sha(library)},'artifact':row,'source_unchanged':True,'production_overlay_sha256':sha(overlay),'admitted':False})
code=subprocess.run([sys.executable,str(W/'rational_inline_control_v1.py')],cwd=W).returncode;assert code==0
