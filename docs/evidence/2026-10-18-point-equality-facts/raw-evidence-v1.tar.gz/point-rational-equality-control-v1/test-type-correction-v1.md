# Test-only type correction

The first scalar test build failed with E0282 at the new BigInt affine-oracle setup. It ran no scalar tests. Preserve its source and logs. The correction adds explicit `BigInt` types to the two existing local additions; inputs, loops, independent oracle, assertions and production code are unchanged.

Keep both prepared source trees unchanged. Qualify the corrected test as a hashed read-only bind over the original test path during Cargo checks, following the earlier E65 overlay protocol. The failed unit build produced no successful unit-test image, and the next build must actually compile the test. Runtime/native production images and the earlier point measurements remain about identical production code. Record the original and overlay hashes, helper and commands; future source admission would require installing the qualified test bytes and running affected integration checks.
