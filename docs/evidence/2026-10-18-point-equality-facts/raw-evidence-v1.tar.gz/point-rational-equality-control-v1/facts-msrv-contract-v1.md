# Scalar fact compiler-floor qualification

Hyperreal owns the new exact retained-rational fact; Hypercurve consumes it. P3/P5 and P37/P39 require the documented compiler floor to accept the affected public API and targets. Use the installed pinned Rust 1.95.0 toolchain, a fresh Disk B target, locked offline dependencies, and all targets in both all-feature and no-default-feature configurations for Hyperreal and Hypercurve. Keep the typed-test and explicit API-inventory overlays identical to the runtime-qualified proposal. This is compile qualification, not a runtime, external-package, binding, or public-release claim. Hypervoxel remains excluded.

The user-authorized retention-contract-v2.json applies: cumulative Disk B consumption may reach 72 GiB from its original baseline. Root consumption, command time, memory, two build jobs, logs, and fixture gates are unchanged. Do not overwrite older targets or artifacts.
