"""Continue affected qualification under the authorized retention allowance."""
import json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import dump,sha,resources,reasons
for file in ['point-rational-kernel-facts-scalar-suite-result-v2.json','point-rational-kernel-facts-curve-suite-result-v2.json','point-rational-facts-gates-result-v2.json']:
    assert json.loads((N/file).read_text())['passed']
assert json.loads((N/'point-rational-facts-report-result-v1.json').read_text())['all_report_bytes_equal']
assert json.loads((N/'point-rational-direct-control-v1/result-v1.json').read_text())['all_cases_completed_and_matched_integer_oracle']
assert json.loads((W/'direct-rational-review-v1.json').read_text())['continue_qualification']
steps=[['combined_facts_kernel_validate_v3.py','kernel-clippy'],['combined_facts_kernel_validate_v3.py','kernel-doc'],['facts_native_suite_v2.py'],['facts_downstream_validate_v2.py','predicates'],['facts_downstream_validate_v2.py','mesh'],['facts_downstream_validate_v2.py','modeling'],['facts_downstream_validate_v2.py','circuit'],['facts_downstream_validate_v2.py','native-quality'],['facts_downstream_validate_v2.py','native-doc'],['facts_msrv_v1.py']]
protocol=N/'point-rational-facts-continuation-protocol-v3.json';assert not protocol.exists()
pins={s[0]:sha(W/s[0]) for s in steps}
dump(protocol,{'helper_sha256':sha(Path(__file__)),'steps':steps,'step_helpers_sha256':pins,'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'runner_sha256':sha(W/'validation_runner_v4.py'),'execution_limits_unchanged':True,'disk_b_allowance_gib':72,'old_dispatcher_retirement_sha256':sha(W/'retention-transition-completion-v1.json'),'scalar_control_review_sha256':sha(W/'direct-rational-review-v1.json'),'earlier_failures_preserved':True})
progress=[]
for step in steps:
    assert all(sha(W/name)==digest for name,digest in pins.items())
    assert not reasons(resources())
    started=time.time();print(json.dumps({'starting':step}),flush=True)
    code=subprocess.run([sys.executable,str(W/step[0]),*step[1:]],cwd=W).returncode
    progress.append({'step':step,'exit_code':code,'start_unix':started,'end_unix':time.time()})
    dump(N/'point-rational-facts-continuation-progress-v3.json',progress)
    assert code==0,step
dump(N/'point-rational-facts-continuation-result-v3.json',{'steps':progress,'listed_phases_passed':True,'admitted':False,'full_plan_complete':False})
