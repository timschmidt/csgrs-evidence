"""Qualify scalar-fact and curve targets at the declared compiler floor."""
import gzip,json,os,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'point-rational-facts-source-v1';T=M/'targets/point-rational-inline-facts-msrv-v1'
assert not (V/'targets/point-rational-inline-facts-msrv-v1').exists()
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha
inv=N/'point-rational-facts-source-v1.json.gz';pins=json.loads(gzip.decompress(inv.read_bytes()))
tools=json.loads((O/'docs/evidence/2026-10-17-in-scope-msrv/review-v1.json').read_text())['tool_sha256']
assert all(sha(p)==h for p,h in tools.items())
root=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
os.environ.update(CARGO_NET_OFFLINE='true',RUSTC=str(root/'rustc'),RUSTDOC=str(root/'rustdoc'),RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
commands={};overlays={'crates/hyperreal/src/rational/arithmetic/comparison.rs':('rational_comparison_inline_v2.rs','c1790e9b60bb046224a5c05a6f6d30bd68d60db4fcf1632250e982a97f725bf2'),'crates/hyperreal/src/real/immediate_equality_tests.rs':('immediate_equality_tests_v2.rs','b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6'),'crates/hyperreal/tests/gmp_api_coverage.rs':('gmp_api_coverage_v2.rs','e0ca03d37445c0f5fef332414c8057fbfd78de8131e3f25b14d095cc8ca23ab4')}
protocol=N/'point-rational-inline-facts-msrv-protocol-v1.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'source_inventory_sha256':sha(inv),'tools':tools,'contract_sha256':sha(W/'facts-msrv-contract-v1.md'),'inline_contract_sha256':sha(W/'scalar-facts-inline-contract-v1.md'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'runner_sha256':sha(W/'validation_runner_v4.py'),'target':str(T),'target_initially_absent':True,'runtime_tests_rerun':False,'compiler_version':'1.95.0','test_overlays':overlays})
for label,feature in [('all','--all-features'),('minimal','--no-default-features')]:
    assert all(sha(S/p)==h for p,h in pins.items())
    name='point-rational-inline-facts-msrv-'+label+'-v1';scratch=N/'scratch'/name
    args=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(S)]
    for destination,(filename,digest) in overlays.items():
        assert sha(W/filename)==digest;args+=['--ro-bind',str(W/filename),str(S/destination)]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():args+=['--setenv',k,v]
    commands[label]=run(name,args+[str(root/'cargo'),'check','--locked','-p','hyperreal','-p','hypercurve','--all-targets',feature],S,target=T)
    err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M)
    assert all(sha(S/p)==h for p,h in pins.items())
    dump(N/'point-rational-inline-facts-msrv-progress-v1.json',commands)
dump(N/'point-rational-inline-facts-msrv-result-v1.json',{'complete_for_declared_scope':True,'commands':commands,'compiler':'1.95.0','all_targets':True,'features':['all','no-default'],'source_unchanged':True,'hypervoxel_compiled':False,'runtime_tests_rerun':False,'clippy_on_msrv_run':False,'public_distribution_complete':False})
print('affected compiler-floor checks passed',flush=True)
