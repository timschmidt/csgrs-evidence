"""Prepare a fresh scalar-fact variant without modifying the rejected prototype."""
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
S=N/'point-rational-facts-source-v1';T=N/'targets/point-rational-facts-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import sha,dump,GIT,reasons,resources
assert not reasons(resources())
cost=json.loads((N/'point-rational-equality-cost-v1/result-v1.json').read_text());assert cost['all_cases_completed_and_matched_integer_oracle']
rows=[r for r in cost['rows'] if r['case']=='large-coefficients' and r['phase']=='repeated-traversal'];assert min(r['elapsed_ns'] for r in rows if r['mode']=='candidate')>6*max(r['elapsed_ns'] for r in rows if r['mode']=='baseline')
def git(a,cwd=O,stdin=None):return subprocess.run(GIT+a,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip();assert head=='1b90c0105c71e09cacb613b4d8bfe63d62011d1c'
assert not git(['diff','HEAD','--name-only']) and not S.exists() and not T.exists()
git(['worktree','add','--no-checkout','-b','codex/point-rational-facts-20261017',str(S),head])
sparse=W/'sparse-selection-v1.txt';git(['sparse-checkout','set','--no-cone','--stdin'],S,sparse.read_bytes());git(['checkout','codex/point-rational-facts-20261017'],S)
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-integration-source-v1.json.gz').read_bytes()));normalizations={}
for p,h in pins.items():
    if p=='docs/properties-status.json':h=sha(O/p)
    assert sha(O/p)==h
    if sha(S/p)!=h:
        assert (S/p).read_bytes()==(O/p).read_bytes().replace(b'\r\n',b'\n'),p
        normalizations[p]={'checkout_sha256':sha(S/p),'original_sha256':h};shutil.copy2(O/p,S/p)
p=S/'crates/hyperreal/src/rational/arithmetic/comparison.rs';s=p.read_text();old=s[:s.index('impl Eq for Rational {}')]
new="""impl Rational {
    /// Exact equality from retained shape and borrowed arithmetic, without
    /// constructing a difference or arbitrary-width cross products.
    pub(crate) fn immediate_equality(&self, other: &Self) -> Option<bool> {
        if std::sync::Arc::ptr_eq(&self.0, &other.0) {
            Some(true)
        } else if self.sign != other.sign {
            Some(false)
        } else if self.denominator == other.denominator {
            Some(self.numerator == other.numerator)
        } else if let Some(ordering) = compare_dyadic_magnitudes(self, other) {
            Some(ordering.is_eq())
        } else if let Some(ordering) = compare_word_magnitudes(self, other) {
            crate::trace_dispatch!("rational", "comparison", "word-sized");
            Some(ordering.is_eq())
        } else if self.msd_exact() != other.msd_exact() {
            crate::trace_dispatch!("rational", "comparison", "magnitude-bits");
            Some(false)
        } else {
            None
        }
    }
}

impl PartialEq for Rational {
    fn eq(&self, other: &Self) -> bool {
        self.immediate_equality(other).unwrap_or_else(|| {
            crate::trace_dispatch!("rational", "comparison", "biguint-cross-product");
            &self.numerator * &other.denominator == &other.numerator * &self.denominator
        })
    }
}

"""
assert old.startswith('impl PartialEq for Rational');p.write_text(new+s[len(old):])
p=S/'crates/hyperreal/src/real/arithmetic/facts.rs';s=p.read_text();needle='    /// Return an exact sign available without walking the computable graph.';assert s.count(needle)==1
method="""    /// Returns an exact equality fact available from known rational structure.
    ///
    /// Both `Some(true)` and `Some(false)` certify the stated equality or
    /// inequality. `None` is inconclusive: symbolic values and rational pairs
    /// requiring wider arithmetic retain their ordinary comparison paths.
    /// This query reuses shared storage, signs, common denominators, dyadic
    /// comparisons, checked word products, and disjoint binary magnitudes. It
    /// does not construct a difference or arbitrary-width cross products.
    /// Borrowed digit comparisons are not a constant-time resource bound.
    ///
    /// ```
    /// use hyperreal::Real;
    /// assert_eq!(Real::one().immediate_equality(&Real::from(2)), Some(false));
    /// assert_eq!(Real::from(3).immediate_equality(&Real::from(3)), Some(true));
    /// ```
    #[inline]
    pub fn immediate_equality(&self, other: &Self) -> Option<bool> {
        self.exact_rational_ref()?
            .immediate_equality(other.exact_rational_ref()?)
    }

"""
p.write_text(s.replace(needle,method+needle))
p=S/'crates/hypercurve/src/point.rs';s=p.read_text();old="""        Arc::ptr_eq(&self.0, &other.0)
            || ((self.x() - other.x()).zero_status() == ZeroKnowledge::Zero
                && (self.y() - other.y()).zero_status() == ZeroKnowledge::Zero)"""
new="""        fn coordinate_eq(left: &Real, right: &Real) -> bool {
            left.immediate_equality(right)
                .unwrap_or_else(|| (left - right).zero_status() == ZeroKnowledge::Zero)
        }

        Arc::ptr_eq(&self.0, &other.0)
            || (coordinate_eq(self.x(), other.x()) && coordinate_eq(self.y(), other.y()))"""
assert s.count(old)==1;p.write_text(s.replace(old,new))
p=S/'crates/hyperreal/src/rational/arithmetic/tests.rs';s=p.read_text();needle='                    assert_eq!(left == right, expected, "pair {i}, {j}");';assert s.count(needle)==1
s=s.replace(needle,needle+"""
                    if let Some(equal) = left.immediate_equality(right) {
                        assert_eq!(equal, expected, "immediate pair {i}, {j}");
                    }""");p.write_text(s)
p=S/'crates/hyperreal/src/real/mod.rs';s=p.read_text();needle='mod tests;';assert s.count(needle)==1;p.write_text(s.replace(needle,needle+'\n\n#[cfg(test)]\nmod immediate_equality_tests;'))
for src,dst in [(W/'immediate_equality_tests.rs',S/'crates/hyperreal/src/real/immediate_equality_tests.rs'),(W/'point_equality_contract.rs',S/'crates/hypercurve/tests/point_equality_contract.rs')]:assert not dst.exists();shutil.copy2(src,dst)
changed=['crates/hypercurve/src/point.rs','crates/hyperreal/src/rational/arithmetic/comparison.rs','crates/hyperreal/src/rational/arithmetic/tests.rs','crates/hyperreal/src/real/arithmetic/facts.rs','crates/hyperreal/src/real/mod.rs']
# Only format complete modules and the new ordinary Rust test; included scalar
# fragments retain their established parent formatting.
subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config-path',str(S/'crates/.rustfmt.toml'),str(S/'crates/hypercurve/src/point.rs'),str(S/'crates/hyperreal/src/real/immediate_equality_tests.rs')],check=True)
assert set(git(['diff','--name-only'],S).decode().splitlines())==set(changed);assert not git(['diff','--check'],S)
tracked=git(['ls-files','-z'],S).decode().split('\0')[:-1];pins={p:sha(S/p) for p in tracked if (S/p).is_file()}
added=['crates/hyperreal/src/real/immediate_equality_tests.rs','crates/hypercurve/tests/point_equality_contract.rs']
for p in added:pins[p]=sha(S/p)
inv=N/'point-rational-facts-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'facts-tracked-v1.patch').write_bytes(git(['diff','--binary'],S))
dump(W/'facts-preparation-v1.json',{'revision':head,'source_root':str(S),'target':str(T),'source_inventory_sha256':sha(inv),'source_files':len(pins),'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'scalar-facts-contract-v1.md'),'changed_paths':changed,'added_paths':added,'implementation_sha256':{p:sha(S/p) for p in changed+added},'checkout_normalizations':normalizations,'exact_track_importer_present':False,'cache_proposal_present':False,'rejected_direct_point_source_unchanged':True,'admitted':False})
print(json.dumps({'source_files':len(pins),'changed_paths':changed}),flush=True)
