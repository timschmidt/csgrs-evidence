"""Continue scalar-fact qualification after terminal combined native gates."""
import json,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import dump,sha,resources,reasons
assert json.loads((N/'point-rational-facts-report-result-v1.json').read_text())['all_report_bytes_equal']
assert json.loads((N/'point-rational-facts-gates-result-v2.json').read_text())['passed']
combined=json.loads((N/'point-rational-native-facts-gates-result-v1.json').read_text())
assert combined['source_unchanged'] and all(r['output_closed'] and not r['stops'] for r in combined['commands'].values())
steps=[['combined_facts_kernel_validate_v2.py','scalar-suite'],['combined_facts_kernel_validate_v2.py','curve-suite'],['combined_facts_kernel_validate_v2.py','kernel-clippy'],['combined_facts_kernel_validate_v2.py','kernel-doc'],['facts_native_suite_v1.py'],['facts_downstream_validate_v1.py','predicates'],['facts_downstream_validate_v1.py','mesh'],['facts_downstream_validate_v1.py','modeling'],['facts_downstream_validate_v1.py','circuit'],['facts_downstream_validate_v1.py','native-quality'],['facts_downstream_validate_v1.py','native-doc']]
protocol=N/'point-rational-facts-continuation-protocol-v2.json';assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'steps':steps,'step_helpers_sha256':{s[0]:sha(W/s[0]) for s in steps},'combined_gates_result_sha256':sha(N/'point-rational-native-facts-gates-result-v1.json'),'resource_contract_unchanged':True,'previous_failure_preserved':str(N/'point-rational-facts-continuation-progress-v1.json'),'test_inventory_correction_sha256':sha(W/'api-classification-correction-v1.json')})
progress=[]
for step in steps:
    assert not reasons(resources())
    started=time.time();print(json.dumps({'starting':step}),flush=True)
    code=subprocess.run([sys.executable,str(W/step[0]),*step[1:]],cwd=W).returncode
    progress.append({'step':step,'exit_code':code,'start_unix':started,'end_unix':time.time()})
    dump(N/'point-rational-facts-continuation-progress-v2.json',progress)
    assert code==0,step
    if step==['facts_validate_v2.py','gates']:
        assert json.loads((N/'point-rational-facts-gates-result-v2.json').read_text())['passed']
dump(N/'point-rational-facts-continuation-result-v2.json',{'steps':progress,'listed_phases_passed':True,'admitted':False,'full_plan_complete':False})
