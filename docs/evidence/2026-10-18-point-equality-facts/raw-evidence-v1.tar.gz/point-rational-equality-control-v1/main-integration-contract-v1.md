# Conditional integration of shared exact equality facts

Owning layers: Hyperreal owns retained rational equality facts (P1, P3-P5);
Hypercurve consumes a sufficient exact fact while keeping its symbolic fallback
(P17-P20). P27 and P35-P37 govern preserved outputs and measured retention.
The input domain, independently derived oracles, fixed workloads and external
containment are those in the original point, scalar-fact and inline contracts.

Integration is conditional on the remaining consumer/compiler-floor checks and
the matched native-context direct Rational control. Preserve and evaluate every
first and repeated row, including retained-payload and binary-size increases.
The direct-comparison rejection, unhinted extraction regression, unmatched
standalone pilot, helper compile failure and combined importer failures remain
evidence. No importer or cache proposal is part of this integration.

If the candidate earns retention, copy only the seven qualified implementation
and test files from the frozen scalar-fact source and its existing typed-test,
API-inventory and inline overlays. Keep the already committed corrected Point2
contract unchanged. Apply the prepared public API documentation and update the
two owning crates' performance ledgers with all tradeoffs and scoped claims.
Verify the complete 2,653-path source/fixture comparison against the qualified
snapshot, accounting explicitly for the overlays and documentation. No new
source snapshot is needed on the nearly full root-volume allowance.

After the final edit, run whole-workspace formatting, the scalar equality
regressions, public point contracts, point unit tests, scalar API coverage and
doctests, and the 53 native ingress/aggregation regression tests through the
main checkout. Reuse only the still-open Disk B target. Record actual commands,
source pins and test counts. Earlier full scalar, curve, native, predicate,
mesh, modeling and circuit suites, warning-denied lint/docs, original native
resource gates, complete unchanged reports and compiler-floor checks apply
only to the verified identical implementation bytes. Do not claim those were
rerun on main or claim a full pre-push matrix or released user path.

The original baselines and cumulative 16 GiB root / approved 72 GiB Disk B
allowances, command/probe time limits, 8 GiB child address space and other
resource limits remain fixed. Hash physical paths independently when closing
the experiment. Verify previously closed E67/E68 paths rather than re-admitting
or changing them. Hypervoxel remains outside scope. No push is requested.
