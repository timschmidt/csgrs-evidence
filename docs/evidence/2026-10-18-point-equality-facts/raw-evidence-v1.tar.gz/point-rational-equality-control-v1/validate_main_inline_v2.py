"""Verify the final main-checkout equality implementation and its consumers."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');T=M/'targets/point-rational-native-facts-v1'
A=V/'point-rational-main-integration-artifacts-v2';R=N/'point-rational-main-integration-v2'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert not R.exists() and not A.exists();R.mkdir();A.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
application=json.loads((W/'main-integration-application-result-v1.json').read_text());qualified=application['qualified_input_sha256']
pins={p:sha(O/p) for p in qualified};different={p for p,h in pins.items() if h!=qualified[p]}
assert different=={'crates/hyperreal/PERFORMANCE.md','crates/hypercurve/PERFORMANCE.md'},different
assert sha(O/'crates/hypercurve/tests/point_equality_contract.rs')=='20258117bca15727e8c1299cfb7e84265b8fe4411c3ba56294eab998a55d43ca'
assert sha(O/'docs/properties-status.json')=='cb16d5c8e7ebc34b34360522f83b8357fbd91c5372e5c9973b16388b6df75f17'
(R/'source-pins-v1.json.gz').write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'harness_correction_sha256':sha(W/'main-integration-harness-correction-v1.json'),'contract_sha256':sha(W/'main-integration-contract-v1.md'),'application_sha256':sha(W/'main-integration-application-result-v1.json'),'retention_review_sha256':sha(W/'inline-admission-review-v1.json'),'source_pins_sha256':sha(R/'source-pins-v1.json.gz'),'qualified_source_comparison_paths':len(pins),'only_documentation_differs_from_qualified_bytes':sorted(different),'tool_sha256':compiler['tool_sha256'],'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'runner_sha256':sha(W/'validation_runner_v4.py'),'target_reused_and_open':str(T),'hypervoxel_excluded':True})
prior=N/'point-rational-main-integration-v1'
assert sha(R/'source-pins-v1.json.gz')==sha(prior/'source-pins-v1.json.gz')
prior_commands=json.loads((prior/'progress-v1.json').read_text());prior_summaries=json.loads((prior/'summaries-v1.json').read_text())
commands={k:prior_commands[k] for k in ['format','scalar-equality','point-contract']};summaries=dict(prior_summaries);artifacts={}
for k,r in commands.items():
    assert r['exit_code']==0 and not r['stops']
    folder=N/'logs'/('point-rational-main-integration-'+k+'-v1')
    assert all(sha(folder/file)==h for file,h in r['output_sha256'].items())
def verify():
    assert all(sha(O/p)==h for p,h in pins.items())
    assert not reasons(resources())
    assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
def execute(label,args,binary=False):
    verify();name='point-rational-main-integration-'+label+'-v2';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--chdir',str(scratch if binary else O)]
    if binary and 'hyperdrc' in artifacts:argv+=['--ro-bind',artifacts['hyperdrc']['copy'],str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,O,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands);raise
    commands[label]=r;dump(R/'progress-v1.json',commands);verify()
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M),err
    return out

def tests(label,args,expected=None,binary=False):
    out=execute(label,args,binary=binary);rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
    assert rows and all(r[0]=='ok' and r[2:5]==('0','0','0') for r in rows),rows
    count=sum(int(r[1]) for r in rows);assert count>0 and (expected is None or count==expected),(label,rows)
    summaries[label]={'rows':rows,'passed':count};dump(R/'summaries-v1.json',summaries)
tests('point-unit',[cargo,'test','--release','--locked','-p','hypercurve','--all-features','--lib','point::','--','--test-threads=2'],14)
tests('scalar-api-coverage',[cargo,'test','--release','--locked','-p','hyperreal','--all-features','--test','gmp_api_coverage','--','--test-threads=2'])
tests('scalar-doc',[cargo,'test','--release','--locked','-p','hyperreal','--all-features','--doc','--','--test-threads=2'])
native={'kicad_track_failures':39,'native_aggregation':13,'native_aggregation_memory':1}
args=[cargo,'test','--release','--locked','-p','hyperdrc','--no-run','--message-format=json']
for name in native:args+=['--test',name]
out=execute('native-compile',args)
for line in out.splitlines():
    if not line.startswith('{'):continue
    item=json.loads(line);name=item.get('target',{}).get('name')
    if item.get('reason')!='compiler-artifact' or not item.get('executable') or name not in set(native)|{'hyperdrc'}:continue
    original=Path(item['executable']);physical=V/original.relative_to(M);copy=A/name;assert not copy.exists();shutil.copy2(physical,copy);assert sha(physical)==sha(copy)
    artifacts[name]={'cargo_path':str(original),'physical_compilation_path':str(physical),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size}
assert set(native)<=set(artifacts);dump(A/'executables-v1.json',artifacts)
for name,count in native.items():tests(name,[artifacts[name]['copy'],'--test-threads=2'],count,binary=True)
verify();dump(R/'result-v1.json',{'passed':True,'reused_successful_pre_correction_commands':['format','scalar-equality','point-contract'],'earlier_narrow_filter_harness_failure_preserved':True,'commands':commands,'summaries':summaries,'artifacts':artifacts,'source_pins_sha256':sha(R/'source-pins-v1.json.gz'),'source_and_fixture_paths_verified':len(pins),'qualified_implementation_bytes_unchanged':True,'documentation_differences':sorted(different),'point_contract_unchanged':True,'broad_qualified_suites_rerun_on_main':False,'original_resource_limits_unchanged':True,'hypervoxel_compiled':False,'admission_pending_evidence_closure':True,'public_distribution_complete':False,'full_plan_complete':False})
print(json.dumps({'main_validation_passed':True,'counts':{k:v['passed'] for k,v in summaries.items()}}),flush=True)
