"""Fresh point-only build and unchanged semantic/resource gates."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;S=N/'point-rational-facts-source-v1';T=M/'targets/point-rational-native-facts-v1';physical_target=V/'targets/point-rational-native-facts-v1';A=V/'point-rational-inline-facts-artifacts-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha,reasons,resources
phase=sys.argv[1];assert phase in ['build','focused','gates','point-unit','scalar-unit','scalar-doc']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
inv=N/'point-rational-facts-source-v1.json.gz';pins=json.loads(gzip.decompress(inv.read_bytes()));commands={};summaries={}
protocol=N/('point-rational-inline-facts-'+phase+'-protocol-v1.json');assert not protocol.exists()
dump(protocol,{'helper_sha256':sha(Path(__file__)),'runner_sha256':sha(W/'validation_runner_v4.py'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'inline_contract_sha256':sha(W/'scalar-facts-inline-contract-v1.md'),'production_overlay_sha256':sha(W/'rational_comparison_inline_v2.rs'),'source_inventory_sha256':sha(inv),'contract_sha256':sha(W/'contract-v1.md'),'compiler_sha256':compiler['tool_sha256'],'target_initially_absent':not physical_target.exists(),'runtime_cwd':'writable private scratch','cache_proposal_present':False,'hypervoxel_excluded':True,'test_overlay_sha256':'b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6','production_delta_from_unhinted_source':'inline attribute on the shared rational fact'})
def verify():
    assert all(sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
    if (A/'executables-v1.json').exists():assert all(sha(v['executed_copy'])==v['sha256'] for v in json.loads((A/'executables-v1.json').read_text()).values())
def execute(label,args,binary=False,allow_failure=False):
    verify();name='point-rational-inline-facts-'+phase+'-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(scratch if binary else S)]
    overlay=W/'immediate_equality_tests_v2.rs'
    assert sha(overlay)=='b35459a4bb3873e125e78eae6d50c903c03747350a88c202ca2134169a02e5d6'
    argv+=['--ro-bind',str(overlay),str(S/'crates/hyperreal/src/real/immediate_equality_tests.rs')]
    for relative,filename,digest in [('crates/hyperreal/src/rational/arithmetic/comparison.rs','rational_comparison_inline_v2.rs','c1790e9b60bb046224a5c05a6f6d30bd68d60db4fcf1632250e982a97f725bf2'),('crates/hyperreal/tests/gmp_api_coverage.rs','gmp_api_coverage_v2.rs','e0ca03d37445c0f5fef332414c8057fbfd78de8131e3f25b14d095cc8ca23ab4')]:
        assert sha(W/filename)==digest;argv+=['--ro-bind',str(W/filename),str(S/relative)]
    if binary:argv+=['--ro-bind',str(A/'hyperdrc-cli'),str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,S,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(N/('point-rational-inline-facts-'+phase+'-progress-v1.json'),commands)
        if r['stops'] or not allow_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(N/('point-rational-inline-facts-'+phase+'-progress-v1.json'),commands)
    verify();out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'(?:Compiling|Checking) hypervoxel\b',err)
    return out,err,r
def rows(text):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
if phase=='build':
    assert physical_target.is_dir() and not A.exists();A.mkdir()
    out,err,r=execute('compile',[cargo,'test','--release','--locked','-p','hyperdrc','--lib','--bins','--tests','--no-run','--message-format=json'])
    artifacts={};local=[]
    for line in out.splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('reason')!='compiler-artifact':continue
        if r.get('manifest_path','').startswith(str(S)):local.append({'manifest':r['manifest_path'],'target':r['target']['name'],'fresh':r['fresh']})
        if not r.get('executable'):continue
        name=r['target']['name']
        if name=='hyperdrc':name='hyperdrc-lib' if 'lib' in r['target']['kind'] else ('hyperdrc-bin-tests' if r['profile']['test'] else 'hyperdrc-cli')
        src=V/Path(r['executable']).relative_to(M);dst=A/name;assert not dst.exists();shutil.copy2(src,dst);assert sha(src)==sha(dst)
        artifacts[name]={'compiled_path':str(src),'executed_copy':str(dst),'sha256':sha(dst),'bytes':dst.stat().st_size}
    assert local;assert any(r['manifest'].endswith('/hyperdrc/Cargo.toml') and not r['fresh'] for r in local)
    assert set(artifacts)==set(p.stem for p in (S/'crates/hyperdrc/tests').glob('*.rs'))|{'hyperdrc-lib','hyperdrc-bin-tests','hyperdrc-cli'}
    dump(A/'executables-v1.json',artifacts);dump(A/'local-build-cache-state-v1.json',local)
elif phase=='focused':
    for name,count in {'kicad_track_failures':39,'native_aggregation':13,'native_aggregation_memory':1}.items():
        out,err,r=execute(name,[str(A/name),'--test-threads=1','--nocapture'],binary=True)
        summary=rows(out);assert summary==[('ok',str(count),'0','0','0','0')],summary;summaries[name]=summary
elif phase=='scalar-unit':
    out,err,r=execute('tests',[cargo,'test','--release','--locked','-p','hyperreal','--lib','equality','--','--test-threads=1','--nocapture'])
    summary=rows(out);assert len(summary)==1 and summary[0][0]=='ok' and int(summary[0][1])>=4 and summary[0][2:5]==('0','0','0'),summary
    summaries['scalar_equality_tests']=summary
elif phase=='scalar-doc':
    out,err,r=execute('example',[cargo,'test','--release','--locked','-p','hyperreal','--doc','immediate_equality','--','--test-threads=1'])
    summary=rows(out);assert summary and sum(int(r[1]) for r in summary)==1 and all(r[0]=='ok' and r[2:5]==('0','0','0') for r in summary),summary
    summaries['new_scalar_doc_example']=summary
elif phase=='point-unit':
    out,err,r=execute('tests',[cargo,'test','--release','--locked','-p','hypercurve','--lib','point::','--','--test-threads=1','--nocapture'])
    summary=rows(out);assert len(summary)==1 and summary[0][0]=='ok' and int(summary[0][1])>=5 and summary[0][2:5]==('0','0','0'),summary
    summaries['existing_point_tests']=summary
elif phase=='gates':
    for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
        out,err,r=execute(label,[str(A/'hyperdrc-lib'),'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],binary=True,allow_failure=True)
        assert 'skipping complex project fixture' not in out+err
        summary=rows(out);assert len(summary)==1 and sum(map(int,summary[0][1:3]))==1 and summary[0][3:5]==('0','0'),summary
        summaries[label]={'summary':summary,'exit_code':r['exit_code'],'process_elapsed_seconds':r['elapsed_seconds']}
verify();dump(N/('point-rational-inline-facts-'+phase+'-result-v1.json'),{'phase':phase,'commands':commands,'summaries':summaries,'passed':all(r['exit_code']==0 for r in commands.values()),'source_unchanged':True,'admitted':False,'full_plan_complete':False})
print(json.dumps({'phase':phase,'summaries':summaries}),flush=True)
