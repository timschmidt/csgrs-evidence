"""Compare complete Rational equality independently of its Point2 consumer."""
import gzip,json,os,platform,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
S=N/'point-rational-facts-source-v1';A=N/'point-rational-inline-direct-control-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert all((p/'result.json').exists() for p in (N/'logs').glob('point-rational-*') if (p/'process.json').exists())
assert not A.exists();A.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
old=json.loads((N/'native-track-revisit-point-cost-v1/result-v1.json').read_text())
new=json.loads((N/'point-rational-inline-scalar-build-result-v1.json').read_text())
inputs={'baseline':old['libraries']['hyperreal'],'candidate':new['library']}
assert all(sha(r['path'])==r['sha256'] for r in inputs.values())
source=W/'rational_equality_cost_v1.rs';source_hash=sha(source);commands={};rows=[]
pins=json.loads(gzip.decompress((N/'point-rational-facts-source-v1.json.gz').read_bytes()));assert all(sha(S/p)==h for p,h in pins.items())
dump(A/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'runner_sha256':sha(W/'validation_runner_v4.py'),'retention_contract_sha256':sha(W/'retention-contract-v2.json'),'source_sha256':source_hash,'contract_sha256':sha(W/'rational-control-contract-v1.md'),'inline_contract_sha256':sha(W/'scalar-facts-inline-contract-v1.md'),'inline_proposal_sha256':sha(W/'inline-proposal-v1.json'),'inputs':inputs,'order':['baseline','candidate','candidate','baseline'],'compiler_sha256':compiler['tool_sha256'],'instrumented_diagnostic':True,'other_task_commands_terminal_before_launch':True})
def execute(label,args):
    assert not reasons(resources());name='point-rational-inline-direct-control-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(S),str(S),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    try:r=run(name,argv+args,S,wall_seconds=60)
    except RuntimeError:r=json.loads((N/'logs'/name/'result.json').read_text())
    commands[label]=r;dump(A/'progress-v1.json',commands);assert not r['stops'] and r['exit_code']==0,r
    return (N/'logs'/name/'stdout').read_text()
for mode,r in inputs.items():
    args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(A/mode),'-L','dependency='+str(Path(r['path']).parent),'--extern','hyperreal='+r['path']]
    execute(mode+'-compile',args)
binaries={m:{'sha256':sha(A/m),'bytes':(A/m).stat().st_size} for m in inputs}
for ordinal,mode in enumerate(['baseline','candidate','candidate','baseline']):
    for case in ['integer','shared','decimal','non-dyadic','subrange','superrange','large-coefficients']:
        assert sha(A/mode)==binaries[mode]['sha256']
        out=execute(str(ordinal)+'-'+mode+'-'+case,[str(A/mode),case]);parsed=[json.loads(line) for line in out.splitlines() if line.startswith('{')]
        repeats=16 if case=='large-coefficients' else 1024
        assert len(parsed)==2 and [r['comparisons'] for r in parsed]==[4096,4096*repeats] and [r['equal'] for r in parsed]==[64,64*repeats] and all(r['case']==case for r in parsed)
        rows.extend(dict(r,mode=mode,ordinal=ordinal) for r in parsed);dump(A/'rows-v1.json',rows)
assert sha(source)==source_hash and all(sha(r['path'])==r['sha256'] for r in inputs.values()) and all(sha(S/p)==h for p,h in pins.items())
dump(A/'environment-v1.json',{'kernel':platform.uname()._asdict(),'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'lscpu':json.loads(subprocess.check_output(['lscpu','--json'],text=True)),'compiler_protocol_sha256':sha(V/'cargo-preparation-protocol-v1.json')})
dump(A/'result-v1.json',{'commands':commands,'rows':rows,'inputs':inputs,'binaries':binaries,'all_cases_completed_and_matched_integer_oracle':True,'instrumented_diagnostic_not_general_benchmark':True,'admitted':False})
print(json.dumps({'processes':28,'rows':len(rows),'all_integer_oracles_passed':True}),flush=True)
