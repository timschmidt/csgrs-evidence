"""Prepare a point-only source, preserving current importer and every original fixture."""
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
S=N/'point-rational-equality-source-v1';T=N/'targets/point-rational-equality-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import sha,dump,GIT,reasons,resources
assert not reasons(resources())
base= json.loads((N/'point-rational-equality-baseline-v1/result-v1.json').read_text());assert base['existing_semantics_established']
assert sha(W/'point_equality_contract.rs')==base['source_sha256']
def git(a,cwd=O,stdin=None):return subprocess.run(GIT+a,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip();assert head=='1b90c0105c71e09cacb613b4d8bfe63d62011d1c'
assert not git(['diff','HEAD','--name-only']) and not S.exists() and not T.exists()
git(['worktree','add','--no-checkout','-b','codex/point-rational-equality-20261017',str(S),head])
sparse=N/'native-aggregation-control-v1/sparse-selection-v1.txt';shutil.copy2(sparse,W/'sparse-selection-v1.txt')
git(['sparse-checkout','set','--no-cone','--stdin'],S,sparse.read_bytes());git(['checkout','codex/point-rational-equality-20261017'],S)
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-integration-source-v1.json.gz').read_bytes()));normalizations={}
for p,h in pins.items():
    if p=='docs/properties-status.json':h=sha(O/p)
    assert sha(O/p)==h
    if sha(S/p)!=h:
        assert (S/p).read_bytes()==(O/p).read_bytes().replace(b'\r\n',b'\n'),p
        normalizations[p]={'checkout_sha256':sha(S/p),'original_sha256':h};shutil.copy2(O/p,S/p)
path=S/'crates/hypercurve/src/point.rs';before=path.read_text()
old="""        Arc::ptr_eq(&self.0, &other.0)
            || ((self.x() - other.x()).zero_status() == ZeroKnowledge::Zero
                && (self.y() - other.y()).zero_status() == ZeroKnowledge::Zero)"""
new="""        fn coordinate_eq(left: &Real, right: &Real) -> bool {
            match (left.exact_rational_ref(), right.exact_rational_ref()) {
                // Reuse the scalar's complete rational comparison without
                // constructing a difference solely to query its zero status.
                (Some(left), Some(right)) => left == right,
                _ => (left - right).zero_status() == ZeroKnowledge::Zero,
            }
        }

        Arc::ptr_eq(&self.0, &other.0)
            || (coordinate_eq(self.x(), other.x()) && coordinate_eq(self.y(), other.y()))"""
assert before.count(old)==1;path.write_text(before.replace(old,new))
test=S/'crates/hypercurve/tests/point_equality_contract.rs';assert not test.exists();shutil.copy2(W/'point_equality_contract.rs',test)
subprocess.run(['/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config-path',str(S/'crates/.rustfmt.toml'),str(path),str(test)],check=True)
assert sha(test)==base['source_sha256'];assert git(['diff','--name-only'],S).decode().splitlines()==['crates/hypercurve/src/point.rs'];assert not git(['diff','--check'],S)
tracked=git(['ls-files','-z'],S).decode().split('\0')[:-1];pins={p:sha(S/p) for p in tracked if (S/p).is_file()};pins[str(test.relative_to(S))]=sha(test)
inv=N/'point-rational-equality-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'candidate-tracked-v1.patch').write_bytes(git(['diff','--binary'],S))
shutil.copy2(N/'native-track-revisit-control-v1/point_equality_cost_v1.rs',W/'point_equality_cost_v1.rs')
dump(W/'preparation-v1.json',{'revision':head,'source_root':str(S),'target':str(T),'source_inventory':str(inv),'source_inventory_sha256':sha(inv),'source_files':len(pins),'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'changed_production_paths':['crates/hypercurve/src/point.rs'],'implementation_sha256':sha(path),'new_test_sha256':sha(test),'checkout_normalizations':normalizations,'exact_track_importer_present':False,'cache_proposal_present':False,'admitted':False})
print(json.dumps({'source_files':len(pins),'production_paths':['crates/hypercurve/src/point.rs']}),flush=True)
