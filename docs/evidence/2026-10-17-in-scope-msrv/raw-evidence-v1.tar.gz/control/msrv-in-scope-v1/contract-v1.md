# In-scope compiler compatibility qualification

User scope correction: Hypervoxel is out of scope. Defer its workspace,
packaging, adapters and release work. Do not remove or weaken an existing
supported feature to obtain a package success; dependent distribution blockers
remain explicitly open. Root workspace checks may resolve the unchanged graph,
but no command targets Hypervoxel or its nested workspace and no source changes
are authorized by this qualification helper.

Owning layer: each in-scope crate's declared compiler and feature contract,
P37 and T12. CSGRS, CSGRS FFI, HyperDRC and Hypergraphics declare Rust 1.95.
Hypergraphics CI requires all-target all-feature and no-default-feature checks
on 1.95.0. Missing evidence: the exact retained cache candidate has only been
qualified with stable 1.98.1, and the corrected actual Hyperreal package has
not been checked at the stack's declared 1.95 floor.

Use the already installed Rust 1.95.0 toolchain, record versions and binary
hashes, and change no global rustup configuration. Run the unchanged root
workspace default all-target check, then the four explicitly versioned packages'
all-feature and no-default-feature all-target checks. Also check both default
and all-feature all-target configurations of the exact corrected Hyperreal
archive extraction. That extraction is a closed artifact: mount it read-only
and verify its member hashes before and after. Use a fresh shared MSRV target.
No fixture, policy, dependency version, lockfile or production source changes.

C is the retained three-file Hypercurve candidate, with its independently
pinned original lock. D's newly admitted Hyperreal packaging fix changes only
metadata, a dev dependency/test and README; the exact extracted package tests
that change separately. Do not claim that unrelated later changes were compiled
as part of C. All Hypervoxel-specific qualification remains deferred by user.

Use validation_runner_v2 unchanged: per-command 1800 seconds, 8 GiB address
space, two Cargo jobs, incremental off, 2 GiB available-host-memory and 512 MiB
volume reserves, 64 GiB cumulative volume consumption and 64 MiB aggregate
command logs. Use the verified spaceless mount and Disk B caches for GMP.
Run qualification commands sequentially; retain raw output and every failure.

Compiler checking is not runtime testing, a full feature powerset, a published
package consumer, complete formal verification, cache admission or full-plan
completion. Clippy is not installed for 1.95 and is not part of the repository's
MSRV workflow; separately retained stable Clippy results remain scoped to their
actual compiler. No push, publishing or original-volume writes.
