# Check declared compiler contracts without modifying source or hidden dependencies.
import gzip,json,os,re,sys,tomllib
from pathlib import Path
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent; C=V/'checkout-candidate-v1'; D=V/'paper-worktree-v1'
P=V/'hyperreal-package-candidate-v1'; T=V/'target-msrv-in-scope-v1'
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
BIN=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
assert not T.exists() and not (V/'msrv-in-scope-protocol-v1.json').exists()
assert not reasons(resources())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
os.environ.update(CARGO_NET_OFFLINE='true',RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu',
    RUSTC=str(BIN/'rustc'),RUSTDOC=str(BIN/'rustdoc'),PYTHONDONTWRITEBYTECODE='1',
    PATH=str(BIN)+':'+compiler['additional_environment']['PATH'])
assert all((BIN/n).is_file() for n in ['cargo','rustc','rustdoc'])
tool_pins={str(BIN/n):sha(BIN/n) for n in ['cargo','rustc','rustdoc']}
source_inventory=V/'candidate-source-inventory-v1.json.gz'
pins={p:h for p,h in json.loads(gzip.decompress(source_inventory.read_bytes())).items()
    if not p.startswith(('crates/comparisons/','crates/hypervoxel/'))}
package_members=json.loads(gzip.decompress((V/'hyperreal-package-candidate-members-v1.json.gz').read_bytes()))
assert all(sha(C/p)==h for p,h in pins.items())
assert all(sha(P/p)==r['sha256'] for p,r in package_members.items())
assert sha(D/'docs/properties-status.json')=='5b091207a5231439af70eab3a75807b3dd6276d4098f6cc65ebdc85be58eb2df'
selected=['csgrs','csgrs-ffi','hyperdrc','hypergraphics']
manifest_paths={'csgrs':'Cargo.toml',**{name:'crates/'+name+'/Cargo.toml' for name in selected if name!='csgrs'}}
for name,path in manifest_paths.items():
    manifest=tomllib.loads((C/path).read_text())
    assert manifest['package']['name']==name and manifest['package']['rust-version'] in ['1.95','1.95.0']
cargo=str(BIN/'cargo')
checks=[('workspace-default',[cargo,'check','--locked','--workspace','--all-targets'],C)]
for name in selected:
    for label,flags in [('all',['--all-features']),('minimal',['--no-default-features'])]:
        checks.append((name+'-'+label,[cargo,'check','--locked','-p',name,'--all-targets',*flags],C))
for label,flags in [('default',[]),('all',['--all-features'])]:
    checks.append(('extracted-hyperreal-'+label,[cargo,'check','--locked','--all-targets',*flags],P))
dump(V/'msrv-in-scope-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),'tool_sha256':tool_pins,
    'source_inventory_sha256':sha(source_inventory),'source_pin_count_excluding_deferred_workspaces':len(pins),
    'candidate_lock_sha256':sha(C/'Cargo.lock'),'declared_msrv_packages':manifest_paths,
    'hyperreal_extracted_members_sha256':sha(V/'hyperreal-package-candidate-members-v1.json.gz'),
    'commands':[{'name':n,'argv':a,'cwd':str(c)} for n,a,c in checks],
    'target':str(T),'hypervoxel_deferred_by_user':True,'source_changes':False,
    'runtime_tests':False,'msrv_clippy_available':False,'candidate_admitted':False,'full_plan_complete':False})
results={}
def execute(label,args,cwd):
    name='msrv-in-scope-'+label+'-v1'
    mapped={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/T.relative_to(V)),
        'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),
        'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--ro-bind',str(P),str(M/P.relative_to(V)),
        '--chdir',str(M/cwd.relative_to(V))]
    for key,value in mapped.items():argv.extend(['--setenv',key,value])
    argv+=args
    try:result=run(name,argv,cwd,target=T)
    except RuntimeError:
        result=json.loads((V/'logs'/name/'result.json').read_text())
        results[label]=result
        dump(V/'msrv-in-scope-failure-v1.json',{'failed_command':label,'command':result,
            'completed_commands':results,'source_changes':False,'hypervoxel_deferred_by_user':True,
            'candidate_admitted':False,'full_plan_complete':False})
        raise
    results[label]=result
    assert all(sha(P/p)==r['sha256'] for p,r in package_members.items())
    return (V/'logs'/name/'stdout').read_text()
rustc=execute('rustc-version',[str(BIN/'rustc'),'-vV'],C)
assert re.search(r'^release: 1\.95\.0$',rustc,re.M),rustc
execute('cargo-version',[cargo,'-vV'],C)
execute('rustdoc-version',[str(BIN/'rustdoc'),'--version'],C)
for name,args,cwd in checks:
    execute(name,args,cwd)
    assert all(sha(C/p)==h for p,h in pins.items())
assert all(sha(p)==h for p,h in tool_pins.items())
assert sha(D/'docs/properties-status.json')=='5b091207a5231439af70eab3a75807b3dd6276d4098f6cc65ebdc85be58eb2df'
dump(V/'msrv-in-scope-result-v1.json',{'complete_for_declared_scope':True,'commands':results,
    'compiler':'1.95.0','candidate_workspace_default_all_targets_checked':True,
    'declared_msrv_packages_all_and_minimal':selected,'extracted_hyperreal_default_and_all_checked':True,
    'source_and_extracted_package_unchanged':True,'source_changes':False,'hypervoxel_deferred_by_user':True,
    'runtime_tests_rerun':False,'msrv_clippy_run':False,'candidate_admitted':False,
    'release_qualified':False,'full_plan_complete':False})
print(json.dumps({'complete_for_declared_scope':True,'commands':len(results),
    'compiler':'1.95.0','hypervoxel_deferred_by_user':True,'candidate_admitted':False}),flush=True)
