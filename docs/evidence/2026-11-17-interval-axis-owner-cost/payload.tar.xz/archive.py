from pathlib import Path
import hashlib,json,subprocess,tarfile,io,shutil,importlib.util
root=Path(__file__).resolve().parent
repo=Path('/mnt/development/csgrs-evidence'); main=Path('/mnt/development/csgrs')
record='docs/evidence/2026-11-17-interval-axis-owner-cost'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
assert not git('status','--porcelain')
old=git('rev-parse','HEAD').decode().strip()
dest=repo/record
assert not dest.exists()
out=root/'archive'
out.mkdir()
members=sorted([*filter(Path.is_file,(root/'record').rglob('*')),root/'baseline',root/'candidate',root/'archive.py'])
def digest(data):return hashlib.sha256(data).hexdigest()
hashes={p.relative_to(root).as_posix():digest(p.read_bytes()) for p in members}
with tarfile.open(out/'payload.tar.xz','w:xz',preset=3) as t:
    for p in members:
        raw=p.read_bytes();name=p.relative_to(root).as_posix();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=p.stat().st_mode&0o777;t.addfile(info,io.BytesIO(raw))
with tarfile.open(out/'payload.tar.xz') as t:
    assert hashes=={m.name:digest(t.extractfile(m).read()) for m in t}
(out/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
(out/'README.md').write_text('Native Hyperpath owner benchmark and legacy trace feature comparison. The payload contains baseline and candidate executables, matched timing samples, build records, the isolated consumer and the feature correction checks. See record/protocol.json for the selected cases and comparison rule. The images and timing samples are for the original isolated extraction. The correction has a separate executable identity check.\n')
assert shutil.disk_usage(repo).free-3*sum(p.stat().st_size for p in out.iterdir())-20*1024**2>=20*1024**3
shutil.copytree(out,dest)
git('add','--sparse','--',record);git('diff','--cached','--check')
assert all(p.startswith(record+'/') for p in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive matched axis projection owner costs and trace compatibility evidence')
rev=git('rev-parse','HEAD').decode().strip()
for p in out.iterdir():assert p.read_bytes()==git('show',rev+':'+record+'/'+p.name)
spec=importlib.util.spec_from_file_location('manifest',main/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(repo),rev);assert len(rows)==2
(root/'archive.json').write_text(json.dumps(dict(commit=rev,parent=old,row=rows[1]),indent=2)+'\n')
print(rows[1],rev)
