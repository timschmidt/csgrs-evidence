from pathlib import Path
import os,shutil,subprocess,sys,json,hashlib
out=Path(__file__).resolve().parent
candidate=Path('/dev/shm/interval-axis-projection/csgrs')
baseline=Path('/mnt/development/csgrs')
def witness(label,src,expected=0):
    p=subprocess.run([sys.executable,str(out/'witness.py'),label,str(src)])
    assert p.returncode==expected,(label,p.returncode,expected)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=candidate,text=True).strip()
assert git('rev-parse','HEAD')=='8f351042e1880a8d77b50606df8b387066522c45' and not git('status','--porcelain')
witness('before',baseline)
witness('extracted',candidate,101)
assert 'left: 1' in (out/'extracted.run.log').read_text() and 'right: 0' in (out/'extracted.run.log').read_text()
manifest=candidate/'crates/hyperpath/Cargo.toml'
orig=manifest.read_text()
target='"hyperdynamics/dispatch-trace", '
assert orig.count(target)==1
manifest.write_text(orig.replace(target,''))
witness('repaired',candidate)
traces=[(out/f'{key}.run.log').read_text().split('PredicatePolicy(0) ')[-1] for key in ('before','repaired')]
assert traces[0]==traces[1]
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/target','CARGO_BUILD_JOBS':'12'}
def run(label,cmd,cwd):
    with (out/(label+'.log')).open('w') as log:subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=log,check=True)
cargo=['cargo','+1.95.0']
run('path-tests',cargo+['test','--offline','--locked','-p','hyperpath','--all-features'],candidate)
run('path-lint',cargo+['clippy','--offline','--locked','-p','hyperpath','--all-targets','--all-features','--','-D','warnings'],candidate)
run('format',cargo+['fmt','-p','hyperpath','--','--check'],candidate)
# Rebuild and run the unchanged earlier legacy probe, configuring only the legacy trace entry point.
prior=Path('/tmp/interval-refactor/axis-projection-owner')
for name,src in [('old',baseline),('new',candidate)]:
    w=out/('full-'+name);shutil.copytree(prior/'baseline-consumer',w)
    m=w/'Cargo.toml';m.write_text(m.read_text().replace(str(baseline),str(src)).replace('"hyperpath/dispatch-trace", "hyperdynamics/dispatch-trace", "hyperreal/dispatch-trace", "hyperlimit/dispatch-trace"','"hyperpath/dispatch-trace"'))
    assert 'trace = ["hyperpath/dispatch-trace"]' in m.read_text()
    run('full-'+name+'-lock',cargo+['generate-lockfile','--offline'],w)
    run('full-'+name+'-build',cargo+['build','--offline','--locked','--features','trace'],w)
    run('full-'+name+'-output',[env['CARGO_TARGET_DIR']+'/debug/axis-projection-owner-consumer'],w)
assert (out/'full-old-output.log').read_bytes()==(out/'full-new-output.log').read_bytes()
git('diff','--check')
git('add','--','crates/hyperpath/Cargo.toml')
git('-c','gc.auto=0','commit','-m','Preserve legacy trace feature selection in axis extraction candidate')
(out/'repair-revision.txt').write_text(git('rev-parse','HEAD')+'\n')
