from pathlib import Path
import os,subprocess,json
s=Path(__file__).resolve().parent;root=Path('/dev/shm/interval-axis-projection/csgrs');primary=Path('/mnt/development/csgrs')
conf=Path('crates/hyperinterval/conformance/alumina-measurements');records=[]
env=os.environ|dict(CARGO_HOME=str(s.parent/'cargo-home'),CARGO_TARGET_DIR='/dev/shm/interval-axis-projection/target',CARGO_BUILD_JOBS='12',CARGO_NET_RETRY='1',CARGO_HTTP_TIMEOUT='15')
for label,w,cmd in [
('candidate-fuzz',root/'crates/hyperpath/fuzz',['+1.95.0','check','--all-targets']),
('candidate-comparisons',root/'crates/comparisons',['+1.95.0','check','--features','path','--lib']),
('candidate-conformance',root/conf,['+1.95.0','test','--features','trace']),
('candidate-conformance-wasm',root/conf/'wasm',['+1.95.0','check','--target','wasm32-unknown-unknown']),
('base-conformance-clippy',primary/conf,['+1.95.0','clippy','--all-targets','--all-features','--','-D','warnings']),
('base-conformance-wasm-release',primary/conf/'wasm',['+stable','build','--release','--target','wasm32-unknown-unknown'])]:
    args=['cargo',*cmd[:2],'--locked',*cmd[2:]]
    if label.startswith('base-'):env['CARGO_TARGET_DIR']='/dev/shm/interval-axis-projection/base-conformance-target'
    with (s/(label+'.log')).open('w') as o:p=subprocess.run(args,cwd=w,env=env,stdout=o,stderr=o,timeout=900)
    records.append(dict(label=label,cwd=str(w),args=args,exit=p.returncode))
    (s/'package-checks.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,p.returncode,flush=True)
