#![allow(deprecated)] // Explicitly qualify the one-release compatibility API.
#[cfg(feature = "direct")]
use hyperdynamics::axis_projection::{
    AffineSpanAxisProjection, AxisMotionLimits, AxisProjectionError as Error,
    certify_axis_projected_motion_limits, plan_axis_projected_motion_limits,
};
#[cfg(not(feature = "direct"))]
use hyperpath::{
    AffineSpanAxisProjection, AxisMotionLimits, RouteCertificationError as Error,
    certify_axis_projected_motion_limits, plan_axis_projected_motion_limits,
};
use hyperlimit::PredicatePolicy;
use hyperreal::Real;
fn r(n: i32) -> Real { Real::from(n) }
fn ratio(n: i32, d: i32) -> Real { (r(n)/r(d)).unwrap() }
fn axes() -> Vec<AxisMotionLimits> {
    vec![AxisMotionLimits { maximum_velocity:r(6), maximum_acceleration:r(8), maximum_jerk:r(10) },
         AxisMotionLimits { maximum_velocity:r(12), maximum_acceleration:r(9), maximum_jerk:r(21) }]
}
fn spans() -> Vec<AffineSpanAxisProjection> {
    vec![AffineSpanAxisProjection { absolute_axis_derivatives:vec![ratio(3,5),ratio(4,5)] },
         AffineSpanAxisProjection { absolute_axis_derivatives:vec![r(0),r(1)] }]
}
fn trace() {
    #[cfg(feature="trace")]
    println!("TRACE {:#?}",hyperreal::dispatch_trace::take_trace());
}
fn main() {
    for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
        println!("POLICY {policy:?}");
        #[cfg(feature="trace")]
        let _recording = hyperreal::dispatch_trace::recording_scope();
        let projections=spans(); let limits=axes();
        #[cfg(feature="trace")]
        hyperreal::dispatch_trace::reset();
        let plan=plan_axis_projected_motion_limits(&projections,&limits,policy).unwrap();
        trace();
        assert_eq!(plan.maximum_path_feed,r(10));
        assert_eq!(plan.maximum_path_acceleration,r(9));
        assert_eq!(plan.maximum_path_jerk,ratio(50,3));
        assert_eq!((plan.feed_bottleneck.span_index,plan.feed_bottleneck.axis_index),(0,0));
        assert_eq!((plan.acceleration_bottleneck.span_index,plan.acceleration_bottleneck.axis_index),(1,1));
        assert_eq!((plan.jerk_bottleneck.span_index,plan.jerk_bottleneck.axis_index),(0,0));
        assert_eq!(plan.certification.rows.len(),4);
        assert_eq!(plan.bottleneck_certification.rows.len(),3);
        assert!(plan.all_satisfied());
        println!("PLAN {plan:#?}");
        #[cfg(feature="trace")]
        hyperreal::dispatch_trace::reset();
        let replay=certify_axis_projected_motion_limits(&projections,&limits,plan.maximum_path_feed.clone(),plan.maximum_path_acceleration.clone(),plan.maximum_path_jerk.clone(),policy).unwrap();
        trace(); assert_eq!(replay,plan.certification); println!("REPLAY {replay:#?}");
        #[cfg(feature="trace")]
        hyperreal::dispatch_trace::reset();
        let unsafe_plan=certify_axis_projected_motion_limits(&projections,&limits,r(11),r(9),r(16),policy).unwrap();
        trace(); assert!(!unsafe_plan.all_satisfied()); assert!(unsafe_plan.rows[0].certification.has_certified_violation()); println!("UNSAFE {unsafe_plan:#?}");
        for (bad,expected) in [
            (vec![],Error::EmptyAxisProjection),
            (vec![AffineSpanAxisProjection { absolute_axis_derivatives:vec![r(1)] }],Error::AxisProjectionShapeMismatch),
            (vec![AffineSpanAxisProjection { absolute_axis_derivatives:vec![r(-1),r(1)] }],Error::NegativeAxisProjection),
            (vec![AffineSpanAxisProjection { absolute_axis_derivatives:vec![r(0),r(0)] }],Error::DegenerateAxisProjection),
        ] {
            #[cfg(feature="trace")]
            hyperreal::dispatch_trace::reset();
            let error=plan_axis_projected_motion_limits(&bad,&limits,policy).unwrap_err();
            trace(); assert_eq!(error,expected); println!("ERROR {error:?}");
        }
        // Identical rows must preserve the first exact minimizer.
        let tied=vec![AffineSpanAxisProjection { absolute_axis_derivatives:vec![r(1),r(1)] };2];
        let tied_axes=vec![AxisMotionLimits { maximum_velocity:r(3),maximum_acceleration:r(4),maximum_jerk:r(5) };2];
        #[cfg(feature="trace")]
        hyperreal::dispatch_trace::reset();
        let tie=plan_axis_projected_motion_limits(&tied,&tied_axes,policy).unwrap();
        trace(); assert!(tie.all_satisfied());
        for selected in [tie.feed_bottleneck,tie.acceleration_bottleneck,tie.jerk_bottleneck] { assert_eq!((selected.span_index,selected.axis_index),(0,0)); }
        println!("TIE {tie:#?}");
    }
}
