from pathlib import Path
import os, subprocess,sys
out=Path(__file__).resolve().parent; w=out/'witness'
label,tree=sys.argv[1:]
manifest=(w/'Cargo.in').read_text().replace('TREE',tree)
(w/'Cargo.toml').write_text(manifest)
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/target'}
for name,args in [('lock',['generate-lockfile','--offline']),('tree',['tree','--offline','--locked','-e','features']),('run',['run','--offline','--locked'])]:
    with (out/f'{label}.{name}.log').open('w') as log:
        p=subprocess.run(['cargo','+1.95.0',*args],env=env,cwd=w,stdout=log,stderr=log)
    if p.returncode:sys.exit(p.returncode)
