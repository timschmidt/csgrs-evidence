from pathlib import Path
import subprocess,os,json,sys,tomllib
out=Path(__file__).resolve().parent
paths=['crates/comparisons','crates/hyperdynamics/fuzz','crates/hyperinterval/conformance/alumina-measurements','crates/hyperinterval/conformance/alumina-measurements/wasm','crates/hyperpath/fuzz','scripts/validated-dynamics']
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/target'}
results={}
for label,root in [('base','/mnt/development/csgrs'),('candidate','/dev/shm/interval-axis-projection/csgrs')]:
    results[label]={}
    for i,path in enumerate(paths):
        cmd=['cargo','+1.95.0','tree','--manifest-path',root+'/'+path+'/Cargo.toml','--offline','--locked','--all-features']
        p=subprocess.run(cmd,env=env,capture_output=True);(out/f'lock-{label}-{i}.log').write_bytes(p.stdout+p.stderr);results[label][path]=p.returncode
(out/'locks.json').write_text(json.dumps(results,indent=2)+'\n')
print(results)
