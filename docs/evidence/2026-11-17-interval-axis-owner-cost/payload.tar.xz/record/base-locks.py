from pathlib import Path
import os,subprocess,sys
root=Path('/mnt/development/csgrs')
out=Path(__file__).resolve().parent
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/base-conformance-target','CARGO_BUILD_JOBS':'12'}
for i,name in enumerate(['','wasm']):
    w=root/'crates/hyperinterval/conformance/alumina-measurements'/name
    before=(w/'Cargo.lock').read_text()
    def run(label,args):
        with (out/f'primary-{i}-{label}.log').open('w') as log:subprocess.run(['cargo','+1.95.0',*args],cwd=w,env=env,stdout=log,stderr=log,check=True)
    run('resolve',['tree','--offline'])
    after=(w/'Cargo.lock').read_text()
    diff=subprocess.check_output(['git','diff','--',str(w/'Cargo.lock')],cwd=root,text=True)
    assert [line for line in diff.splitlines() if line.startswith(('+','-')) and not line.startswith(('+++','---'))]==['+ "hyperinterval",']*2
    run('tree',['tree','--offline','--locked'])
    run('check',['check','--offline','--locked','--all-features','--all-targets']+(['--target','wasm32-unknown-unknown'] if name else []))
    if not name:run('test',['test','--offline','--locked','--all-features'])
