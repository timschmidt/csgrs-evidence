set -eu
base=/dev/shm/interval-axis-cost
export EXACTCORE_ROOT="$base/oracle/trunk"
export CPLUS_INCLUDE_PATH="$base/mpfr/usr/include"
export LIBRARY_PATH="$base/mpfr/usr/lib/x86_64-linux-gnu"
export CARGO_HOME="$base/cargo-home"
export CARGO_TARGET_DIR=/dev/shm/interval-axis-projection/target
export CARGO_BUILD_JOBS=12
cd /dev/shm/interval-axis-projection/csgrs/crates/comparisons
cargo +1.95.0 test --locked --features path --test paths
