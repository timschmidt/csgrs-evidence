from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess,time
stage=Path(__file__).resolve().parent.parent
out=stage/'record'
tree=stage/'csgrs'
env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(stage/'target'),CARGO_BUILD_JOBS='16',CARGO_NET_OFFLINE='true')
sources={'baseline':'52b6d1bab627ab212eda80fbc0d4c08a4cd23176','candidate':'8f351042e1880a8d77b50606df8b387066522c45'}
cases=['axis_aligned_line_offset_exact','quadratic_bezier_exact_hodograph','rect_pad_board_edge_clearance_exact','rectangular_additive_bead_schedule','specctra_trace_record_exact_import','specctra_grid_route_text_parse_256']
pattern='^(?:'+'|'.join(cases)+')$'
order=['baseline','candidate','candidate','baseline','candidate','baseline','baseline','candidate']
def save(name,x): (out/name).write_text(json.dumps(x,indent=2)+'\n')
def sha(p): return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
save('protocol.json',dict(sources=sources,order=order,cases=cases,criterion='1 second warmup, 2 second measurement, 30 samples',screen='in each block both candidate lower mean bounds above both baseline upper bounds; both blocks required to confirm',scope='focused owner runtime, native owner file/text and defined function ranges; no memory or size allowance',toolchain='1.95.0',jobs=16,source_path=str(tree)))
for label,rev in sources.items():
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)
    subprocess.run(['git','checkout','--detach',rev],cwd=tree,check=True)
    args=['cargo','+1.95.0','bench','--offline','--locked','-p','hyperpath','--bench','path_predicates','--no-run','--message-format=json']
    with (out/(label+'.jsonl')).open('w') as o,(out/(label+'.build')).open('w') as e: subprocess.run(args,cwd=tree,env=env,stdout=o,stderr=e,check=True,timeout=900)
    rows=map(json.loads,(out/(label+'.jsonl')).read_text().splitlines())
    paths=[r['executable'] for r in rows if r.get('executable') and r['target']['name']=='path_predicates']
    assert len(paths)==1
    image=stage/label
    shutil.copy2(paths[0],image)
    size=subprocess.check_output(['size','-A',str(image)],text=True)
    (out/(label+'.sections')).write_text(size)
    ranges={};unsized=0
    for line in subprocess.check_output(['readelf','-Ws',str(image)],text=True).splitlines():
        fields=line.split(None,7)
        if len(fields)<8 or fields[3]!='FUNC' or fields[6]=='UND': continue
        start=int(fields[1],16); n=int(fields[2],0)
        if n: ranges.setdefault(fields[6],[]).append((start,start+n))
        else: unsized+=1
    total=0
    for spans in ranges.values():
        end=0
        for a,b in sorted(spans): total+=max(0,b-max(a,end));end=max(end,b)
    save(label+'.image.json',dict(revision=rev,sha256=sha(image),bytes=image.stat().st_size,text=int(next(x.split()[1] for x in size.splitlines() if x.startswith('.text '))),function_union=total,unsized=unsized,command=args,lock=sha(tree/'Cargo.lock')))
    print(label,'built',flush=True)
for i,label in enumerate(order):
    image=stage/'workload'
    shutil.copy2(stage/label,image)
    home=stage/'criterion'
    if home.exists():shutil.rmtree(home)
    args=['setarch','x86_64','-R','taskset','-c','0','python3',str(out/'warm-exec.py'),str(image),'--bench',pattern,'--warm-up-time','1','--measurement-time','2','--sample-size','30','--save-baseline','sample','--noplot']
    with (out/f'run-{i}.log').open('w') as log:subprocess.run(args,cwd=stage,env=os.environ|{'CRITERION_HOME':str(home)},stdout=log,stderr=log,timeout=600,check=True)
    for name in cases:shutil.copytree(home/name/'sample',out/str(i)/name)
    print(i,label,'finished',flush=True)
results={}
for name in cases:
    values=[json.loads((out/str(i)/name/'estimates.json').read_text())['mean'] for i in range(8)]
    blocks=[]
    for k in (0,4):
        b=[values[i] for i in range(k,k+4) if order[i]=='baseline'];c=[values[i] for i in range(k,k+4) if order[i]=='candidate']
        blocks.append(dict(ratio=statistics.mean(x['point_estimate'] for x in c)/statistics.mean(x['point_estimate'] for x in b),adverse=min(x['confidence_interval']['lower_bound'] for x in c)>max(x['confidence_interval']['upper_bound'] for x in b)))
    results[name]=blocks
save('results.json',results)
