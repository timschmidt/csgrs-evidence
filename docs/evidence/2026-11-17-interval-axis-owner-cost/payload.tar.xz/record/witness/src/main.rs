use hyperlimit::PredicatePolicy;
use hyperpath::{AffineSpanAxisProjection, AxisMotionLimits};
use hyperreal::{Real, dispatch_trace};

#[allow(deprecated)]
fn main() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let _guard = dispatch_trace::recording_scope();
        let projection = [AffineSpanAxisProjection { absolute_axis_derivatives: vec![Real::one()] }];
        let axes = [AxisMotionLimits {
            maximum_velocity: Real::from(1),
            maximum_acceleration: Real::from(2),
            maximum_jerk: Real::from(3),
        }];
        let result = hyperpath::plan_axis_projected_motion_limits(&projection, &axes, policy).unwrap();
        assert!(result.all_satisfied());
        let matrix = hyperlattice::Matrix4::identity();
        dispatch_trace::reset();
        std::hint::black_box(matrix.structural_facts());
        let count = dispatch_trace::take_trace().path_count("hyperlattice_matrix", "query", "matrix4-structural-facts");
        println!("{policy:?} {count}");
        assert_eq!(count, 0, "Hyperpath tracing alone changed lattice tracing");
    }
}
