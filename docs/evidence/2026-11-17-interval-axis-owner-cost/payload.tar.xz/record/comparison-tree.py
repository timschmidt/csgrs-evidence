from pathlib import Path
import os,subprocess
out=Path(__file__).resolve().parent
src=Path('/dev/shm/interval-cancellation-cargo-home/registry')
dest=out.parent/'cargo-home/registry'
dest.mkdir(parents=True)
(dest/'index').symlink_to(src/'index')
for name in ['src','cache']:
    for d in (src/name).iterdir():
        target=dest/name/d.name;target.mkdir(parents=True)
        for f in d.iterdir(): (target/f.name).symlink_to(f)
env=os.environ|{'CARGO_HOME':str(dest.parent),'CARGO_NET_RETRY':'1','CARGO_HTTP_TIMEOUT':'15'}
for label,root in [('base','/mnt/development/csgrs'),('new','/dev/shm/interval-axis-projection/csgrs')]:
    with (out/f'comparison-{label}-tree.log').open('w') as log:subprocess.run(['cargo','+1.95.0','tree','--locked','--all-features'],cwd=root+'/crates/comparisons',env=env,stdout=log,stderr=log,check=True,timeout=90)
