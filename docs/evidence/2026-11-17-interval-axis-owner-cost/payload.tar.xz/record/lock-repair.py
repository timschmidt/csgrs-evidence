from pathlib import Path
import os,subprocess,json,tomllib
out=Path(__file__).resolve().parent
root=Path('/dev/shm/interval-axis-projection/csgrs')
env=os.environ|{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/target'}
paths=['crates/comparisons','crates/hyperinterval/conformance/alumina-measurements','crates/hyperinterval/conformance/alumina-measurements/wasm','crates/hyperpath/fuzz']
r={}
for i,path in enumerate(paths):
    w=root/path; lock=w/'Cargo.lock'
    old=lock.read_bytes()
    r[path]={}
    for name,args in [('resolve',[]),('locked',['--locked'])]:
        cmd=['cargo','+1.95.0','tree','--offline',*args,'--all-features']
        q=subprocess.run(cmd,cwd=w,env=env,capture_output=True)
        (out/f'lockrepair-{i}-{name}.log').write_bytes(q.stdout+q.stderr)
        r[path][name]=q.returncode
    def registry(blob):return sorted((p['name'],p['version'],p['checksum']) for p in tomllib.loads(blob.decode())['package'] if 'checksum' in p)
    assert registry(old)==registry(lock.read_bytes())
    r[path]['registry_entries_identical']=True
(out/'lock-repair.json').write_text(json.dumps(r,indent=2)+'\n')
print(r)
