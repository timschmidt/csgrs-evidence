from pathlib import Path
import hashlib,subprocess,json,os,re
p=Path(__file__).resolve().parent
tree=p.parent/'csgrs'
rev=(p/'repair-revision.txt').read_text().strip()
subprocess.run(['git','checkout','--detach',rev],cwd=tree,check=True)
env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(p.parent/'target'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='16')
command=json.loads((p/'candidate.image.json').read_text())['command']
with (p/'repair-build.jsonl').open('w') as out,(p/'repair.build').open('w') as err:subprocess.run(command,cwd=tree,env=env,stdout=out,stderr=err,check=True)
rows=list(map(json.loads,(p/'repair-build.jsonl').read_text().splitlines()));images=[Path(r['executable']) for r in rows if r.get('executable') and r['target']['name']=='path_predicates'];assert len(images)==1
identical=images[0].read_bytes()==(p.parent/'candidate').read_bytes()
output=(p/'full-new-output.log').read_bytes()
counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', (p/'path-tests.log').read_text())]
assert all((p/str(i)/name/'estimates.json').exists() for i in range(8) for name in json.loads((p/'protocol.json').read_text())['cases'])
samples=[json.loads(path.read_text()) for path in p.glob('[0-7]/*/sample.json')]
assert len(samples)==48 and all(len(x['times'])==30 for x in samples)
v=dict(repaired_revision=rev,benchmark_byte_identical=identical,repaired_sha256=hashlib.sha256(images[0].read_bytes()).hexdigest(),path_tests=sum(counts),full_output_bytes=len(output),full_output_sha256=hashlib.sha256(output).hexdigest(),measured_iterations=sum(sum(x['iters']) for x in samples),sample_count=sum(len(x['times']) for x in samples))
(p/'verification.json').write_text(json.dumps(v,indent=2)+'\n')
print(v)
