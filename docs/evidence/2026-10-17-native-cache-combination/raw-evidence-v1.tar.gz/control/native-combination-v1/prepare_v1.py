# Prepare fresh baseline/candidate trees without editing retained proposals.
import gzip,json,os,re,shutil,subprocess,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import GIT,dump,reasons,resources,sha
W=Path(__file__).resolve().parent;D=V/'paper-worktree-v1';R=V/'checkout-release-candidate-v1'
BASE='2564d20ed04e23c54ab8969b71ba2b0843efac63'
mode=sys.argv[1];assert mode in ['baseline','candidate']
S=V/('checkout-native-combination-'+mode+'-v1')
branch='codex/native-combination-'+mode+'-20261017'
receipt=V/('native-combination-'+mode+'-preparation-v1.json')
assert not S.exists() and not receipt.exists() and not reasons(resources())
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_LFS_SKIP_SMUDGE='1')
def git(args,cwd=D,stdin=None):
    return subprocess.run(GIT+args,cwd=cwd,env=env,input=stdin,capture_output=True,check=True).stdout
assert git(['rev-parse','HEAD']).decode().strip()==BASE
assert not git(['status','--porcelain=v1'])
original=json.loads(gzip.decompress((V/'release-candidate-source-inventory-v1.json.gz').read_bytes()))
assert all(sha(R/p)==h for p,h in original.items())
expected=dict(original);expected['docs/properties-status.json']=sha(D/'docs/properties-status.json')
assert expected['docs/properties-status.json']=='1cd2e9d7795659210e9374e70fde93cb567346efe1f7486b5e37ece93874d1d2'
archive=O/'docs/evidence/2026-10-17-kicad-native-strokes'
pins=json.loads((archive/'decision-v1.json').read_text())['candidate_source_changes_sha256']['4']
assert len(pins)==13 and all(sha(archive/'candidate-changes-v4'/p)==h for p,h in pins.items())
probe_paths=['crates/hyperdrc/tests/kicad_native_strokes.rs','crates/hyperdrc/tests/kicad_native_aggregation.rs']
if mode=='candidate':
    reproduction=json.loads((V/'native-combination-baseline-result-v1.json').read_text())
    assert reproduction['complete_for_declared_scope'] and reproduction['missing_claims_reproduced']
patterns=set()
for p in expected:
    parts=PurePosixPath(p).parts
    if parts[0]=='docs':patterns.add('/'+p)
    elif parts[0]=='crates':patterns.add('/'+p if len(parts)==2 else '/crates/'+parts[1]+'/')
    else:patterns.add('/'+parts[0]+('/' if len(parts)>1 else ''))
assert not any('/comparisons/' in p or p.startswith('/docs/evidence/') for p in patterns)
selection=('\n'.join(sorted(patterns))+'\n').encode()
(W/('sparse-'+mode+'-v1.txt')).write_bytes(selection)
git(['worktree','add','--no-checkout','-b',branch,str(S),BASE])
git(['sparse-checkout','set','--no-cone','--stdin'],S,selection);git(['checkout',branch],S)
assert not git(['status','--porcelain=v1'],S)
overlay=['crates/hypercurve/README.md','crates/hypercurve/src/curve_intersection.rs','crates/hypercurve/src/circle_support_cache_tests.rs']
for p,h in expected.items():
    if p not in overlay:assert (S/p).is_file() and not (S/p).is_symlink() and sha(S/p)==h,p
for p in overlay:shutil.copy2(R/p,S/p)
assert all(sha(S/p)==h for p,h in expected.items())
if mode=='baseline':
    for p in probe_paths:
        assert not (S/p).exists();shutil.copy2(archive/'candidate-changes-v4'/p,S/p);expected[p]=pins[p]
else:
    patch=(archive/'candidate-v4.patch').read_bytes()
    (W/'exact-track-input-v4.patch').write_bytes(patch)
    git(['apply','--check','-'],S,patch);git(['apply','-'],S,patch)
    for p,h in pins.items():
        # The later admitted Apache license README correction is outside E36 hunks.
        if p!='crates/hyperdrc/README.md':assert sha(S/p)==h,p
        expected[p]=sha(S/p)
assert all(sha(S/p)==h for p,h in expected.items())
status=git(['status','--porcelain=v1','--untracked-files=all'],S).decode().splitlines()
assert {line[3:] for line in status}==set(overlay)|set(probe_paths if mode=='baseline' else pins),status
(W/(mode+'-tracked-v1.patch')).write_bytes(git(['diff','--binary'],S))
for p in probe_paths:shutil.copy2(S/p,W/(mode+'-'+Path(p).name))
inventory=V/('native-combination-'+mode+'-source-v1.json.gz')
inventory.write_bytes(gzip.compress((json.dumps(expected,sort_keys=True)+'\n').encode(),mtime=0))
dump(receipt,{'mode':mode,'source_root':str(S),'base_revision':BASE,'branch':branch,
    'source_files_verified':len(expected),'source_inventory':str(inventory),'source_inventory_sha256':sha(inventory),
    'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'original_e36_patch_sha256':sha(archive/'candidate-v4.patch'),'original_e36_file_sha256':pins,
    'cache_overlay_sha256':{p:expected[p] for p in overlay},'unadmitted_changes':True,
    'original_full_bundle_restored':False,'hypervoxel_deferred_by_user':True})
assert all(sha(R/p)==h for p,h in original.items())
assert git(['rev-parse','HEAD']).decode().strip()==BASE and not git(['status','--porcelain=v1'])
print(json.dumps({'prepared':mode,'source_files':len(expected),'worktree':str(S)}),flush=True)
