# Freeze CLI children and requalify the exact test against explicit executable images.
import gzip,json,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent;M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
T=V/'target-candidate-v1';A=V/'native-combination-cli-v1';A.mkdir()
assert json.loads((V/'native-combination-candidate-result-v1.json').read_text())['complete_for_declared_scope']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
roots={};pins={};tests={}
for mode in ['baseline','candidate']:
    prep=json.loads((V/('native-combination-'+mode+'-preparation-v1.json')).read_text())
    roots[mode]=Path(prep['source_root']);pins[mode]=json.loads(gzip.decompress(Path(prep['source_inventory']).read_bytes()))
    tests[mode]=json.loads((V/('native-combination-'+mode+'-result-v1.json')).read_text())['artifacts']
def verify():
    assert all(sha(roots[m]/p)==h for m in roots for p,h in pins[m].items())
    assert not reasons(resources())
verify();commands={}
def execute(label,mode,args,cli=None):
    verify();name='native-combination-cli-'+label+'-v1';S=roots[mode]
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--ro-bind',str(S),str(M/S.relative_to(V)),'--chdir',str(M/S.relative_to(V))]
    for key,value in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/T.relative_to(V)),
        'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():
        argv+=['--setenv',key,value]
    if cli is not None:argv+=['--ro-bind',str(cli),str(M/T.relative_to(V)/'release/hyperdrc')]
    argv+=args;row=run(name,argv,S,target=T);commands[label]=row
    dump(A/'progress-v1.json',commands)
    return (V/'logs'/name/'stdout').read_text()
children={}
def freeze(mode):
    built=T/'release/hyperdrc';copy=A/(mode+'-hyperdrc');shutil.copy2(built,copy)
    assert sha(copy)==sha(built)
    children[mode]={'source':str(roots[mode]),'original_target_path':str(built),'frozen_path':str(copy),
        'sha256':sha(copy),'bytes':copy.stat().st_size,'first_baseline_image_preservation_claim':False}
    return copy
name='cli_preserves_source_diagnostic_and_cannot_allow_a_failed_load'
cli=freeze('candidate');t=Path(tests['candidate']['kicad_track_failures']['executed_copy'])
assert sha(t)==tests['candidate']['kicad_track_failures']['sha256']
output=execute('candidate-check','candidate',[str(M/t.relative_to(V)),name,'--exact','--nocapture','--test-threads=1'],cli)
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in output
original=json.loads((V/'logs/native-combination-baseline-compile-v1/result.json').read_text())['argv']
args=original[original.index(cargo):]
assert args[:8]==[cargo,'test','--release','--locked','-p','hyperdrc','--no-run','--message-format=json']
output=execute('baseline-recompile','baseline',args)
rebuilt={}
for line in output.splitlines():
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if row.get('reason')!='compiler-artifact' or not row.get('executable') or not row.get('profile',{}).get('test'):continue
    label=row['target']['name']
    if label not in tests['baseline']:continue
    path=Path(row['executable']);physical=V/path.relative_to(M) if path.is_relative_to(M) else path
    rebuilt[label]={'path':str(physical),'sha256':sha(physical),'matches_retained_test':sha(physical)==tests['baseline'][label]['sha256']}
assert len(rebuilt)==3
cli=freeze('baseline');t=Path(tests['baseline']['kicad_track_failures']['executed_copy'])
assert sha(t)==tests['baseline']['kicad_track_failures']['sha256']
output=execute('baseline-check','baseline',[str(M/t.relative_to(V)),name,'--exact','--nocapture','--test-threads=1'],cli)
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in output
assert all(sha(row['frozen_path'])==row['sha256'] for row in children.values());verify()
dump(A/'result-v1.json',{'complete_for_declared_scope':True,'helper_sha256':sha(Path(__file__)),
    'contract_sha256':sha(W/'cli-retention-contract-v1.md'),'commands':commands,'children':children,
    'rebuilt_test_images':rebuilt,'fresh_cli_test_passes':2,'fresh_cli_test_failures':0,
    'first_baseline_cli_image_preserved':False,'baseline_rebuilt_for_fresh_qualification':True,
    'test_and_source_unchanged':True,'no_prior_workload_timing_affected':True,
    'production_source_changes':False,'cache_admitted':False,'exact_ingress_admitted':False})
print(json.dumps({'fresh_cli_passes':2,'retained_child_images':2,
    'rebuilt_tests_byte_identical':all(r['matches_retained_test'] for r in rebuilt.values()),
    'first_baseline_cli_image_preserved':False}),flush=True)
