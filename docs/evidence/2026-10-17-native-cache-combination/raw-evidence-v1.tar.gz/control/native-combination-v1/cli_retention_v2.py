# A clean target prevents shared Cargo fingerprints from selecting another snapshot.
import gzip,json,os,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent;M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
T=V/'target-native-combination-cli-baseline-v2';A=V/'native-combination-cli-v2'
assert not T.exists() and not A.exists();A.mkdir()
old=json.loads((V/'native-combination-cli-v1/result-v1.json').read_text())
assert old['children']['baseline']['sha256']==old['children']['candidate']['sha256']
assert all(not r['matches_retained_test'] for r in old['rebuilt_test_images'].values())
initial={}
for mode in ['baseline','candidate']:
    rows=[]
    for line in (V/'logs'/('native-combination-'+mode+'-compile-v1')/'stdout').read_text().splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue
        if r.get('reason')=='compiler-artifact' and r.get('package_id','').startswith('path+file:'):
            assert not r['fresh'],(mode,r)
            assert '/checkout-native-combination-'+mode+'-v1/' in r['target']['src_path'],r
            rows.append(r)
    assert rows;initial[mode]=rows
correction={'shared_target_retry_qualified_for_baseline':False,
    'reason':'Cargo marked overwritten candidate artifacts fresh for the older baseline source timestamps; frozen child hashes are identical and test hashes differ from baseline.',
    'rejected_commands':['native-combination-cli-baseline-recompile-v1','native-combination-cli-baseline-check-v1'],
    'v1_candidate_cli_check_qualified':True,'original_compilations_local_artifacts_fresh_false':initial,
    'original_focused_and_workload_results_affected':False,'first_baseline_cli_image_preserved':False}
dump(A/'stale-artifact-correction-v1.json',correction)
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
prep=json.loads((V/'native-combination-baseline-preparation-v1.json').read_text());S=Path(prep['source_root'])
pins=json.loads(gzip.decompress(Path(prep['source_inventory']).read_bytes()))
def verify():
    assert all(sha(S/p)==h for p,h in pins.items()) and not reasons(resources())
verify();commands={}
def execute(label,args,cli=None):
    verify();name='native-combination-cli-'+label+'-v2'
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--ro-bind',str(S),str(M/S.relative_to(V)),'--chdir',str(M/S.relative_to(V))]
    for key,value in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/T.relative_to(V)),
        'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():
        argv+=['--setenv',key,value]
    if cli is not None:
        argv+=['--ro-bind',str(T),str(M/T.relative_to(V)),
            '--ro-bind',str(cli),str(M/T.relative_to(V)/'release/hyperdrc')]
    argv+=args;row=run(name,argv,S,target=T);commands[label]=row;dump(A/'progress-v1.json',commands)
    return (V/'logs'/name/'stdout').read_text()
original=json.loads((V/'logs/native-combination-baseline-compile-v1/result.json').read_text())['argv']
args=original[original.index(cargo):]
output=execute('baseline-recompile',args)
local=[];test=None;binrow=None
for line in output.splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')!='compiler-artifact' or not r.get('package_id','').startswith('path+file:'):continue
    assert not r['fresh'] and '/checkout-native-combination-baseline-v1/' in r['target']['src_path'],r
    local.append(r)
    if r['target']['name']=='kicad_track_failures' and r.get('executable') and r['profile']['test']:test=r
    if r['target']['name']=='hyperdrc' and r['target']['kind']==['bin'] and r.get('executable') and not r['profile']['test']:binrow=r
assert local and test and binrow
copies={}
for name,row in [('baseline-hyperdrc',binrow),('baseline-kicad_track_failures',test)]:
    mapped=Path(row['executable']);path=V/mapped.relative_to(M);assert path.is_relative_to(T)
    copy=A/name;shutil.copy2(path,copy);assert sha(path)==sha(copy)
    copies[name]={'compiled_path':str(path),'frozen_path':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size}
assert copies['baseline-hyperdrc']['sha256']!=old['children']['candidate']['sha256']
name='cli_preserves_source_diagnostic_and_cannot_allow_a_failed_load'
parent=Path(copies['baseline-kicad_track_failures']['frozen_path']);child=Path(copies['baseline-hyperdrc']['frozen_path'])
output=execute('baseline-check',[str(M/parent.relative_to(V)),name,'--exact','--nocapture','--test-threads=1'],child)
assert 'test result: ok. 1 passed; 0 failed; 0 ignored;' in output
assert all(sha(r['frozen_path'])==r['sha256'] for r in copies.values());verify()
dump(A/'result-v1.json',{'complete_for_declared_scope':True,'helper_sha256':sha(Path(__file__)),
    'contract_sha256':sha(W/'cli-retention-contract-v2.md'),'commands':commands,'copies':copies,
    'local_compiler_artifacts':local,'target_initially_absent':True,'target':str(T),
    'fresh_baseline_cli_test_passed':True,'v1_baseline_retry_superseded':True,
    'original_compilations_verified_fresh':True,'first_baseline_cli_image_preserved':False,
    'source_unchanged':True,'production_source_changes':False,'workload_results_unchanged':True})
print(json.dumps({'fresh_baseline_cli_passes':1,'fresh_local_artifacts':len(local),
    'stale_retry_superseded':True,'target_initially_absent':True}),flush=True)
