# Preserve and requalify the CLI child boundary

The frozen test executable for kicad_track_failures launches the separately
built CARGO_BIN_EXE_hyperdrc. The first runner retained seven test executables,
but did not separately freeze that child CLI before reusing the open target.
The original baseline CLI image is therefore not independently preserved; its
source, successful build and test receipt remain. Do not claim that a later
rebuild recovers an unrecorded earlier binary hash.

After all original gates terminate, freeze the current candidate CLI before
any further build. Verify its source and build receipt. Repeat the exact public
CLI diagnostic test, binding its compiled child path to that frozen copy in a
private mount. Preserve the complete command and test result.

Then replay the exact baseline compilation command on the unchanged baseline
source, using the same compiler, locked dependencies and features. Freeze the
resulting CLI immediately, record whether the three rebuilt test images equal
the first retained images, and run the original frozen baseline CLI diagnostic
test with its child path bound to the new frozen baseline CLI. This is fresh
qualification, not a retroactive binary-preservation claim. No geometry test,
policy, fixture or production source changes. Do not run this while any original
workload gate is active. Use the same external containment and open Cargo target.
Close both CLI copies and all new raw evidence with the experiment.
