# Final non-mutating format check and semantic comparison of the two snapshots.
import gzip,json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,run,sha
W=Path(__file__).resolve().parent
baseline=json.loads((V/'native-combination-baseline-result-v1.json').read_text())
candidate=json.loads((V/'native-combination-candidate-result-v1.json').read_text())
assert baseline['complete_for_declared_scope'] and candidate['complete_for_declared_scope']
S=V/'checkout-native-combination-candidate-v1';M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());os.environ.update(compiler['additional_environment'])
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
    '--bind',str(V),str(M),'--ro-bind',str(S),str(M/S.relative_to(V)),
    '--chdir',str(M/S.relative_to(V)),cargo,'fmt','--all','--','--check']
result=run('native-combination-final-format-v1',argv,S,target=V/'target-candidate-v1')
observations={}
for name,old in baseline['focused'].items():
    new=candidate['focused'][name];before=dict(old['test_observations']);after=dict(new['test_observations'])
    if name=='kicad_track_failures':
        removed=set(before)-set(after);added=set(after)-set(before)
        assert removed=={'positive_source_that_the_finite_adapter_cannot_construct_is_an_error'}
        assert added=={'exact_source_ranges_remain_certified_after_native_handoff'},added
        common=set(before)&set(after);assert all(before[n]==after[n]=='ok' for n in common)
        observations[name]={'preserved_passes':len(common),'explicit_source_domain_migration':{'removed':sorted(removed),'added':sorted(added)}}
    else:
        assert before.keys()==after.keys() and all(v=='ok' for v in after.values())
        observations[name]={'preserved_passes':sum(v=='ok' for v in before.values()),
            'newly_passed':[n for n,v in before.items() if v=='FAILED' and after[n]=='ok']}
for mode in ['baseline','candidate']:
    prep=json.loads((V/('native-combination-'+mode+'-preparation-v1.json')).read_text())
    pins=json.loads(gzip.decompress(Path(prep['source_inventory']).read_bytes()))
    assert all(sha(Path(prep['source_root'])/p)==h for p,h in pins.items())
dump(V/'native-combination-final-review-v1.json',{'helper_sha256':sha(Path(__file__)),
    'baseline_missing_claims':sum(r['failed'] for r in baseline['focused'].values()),
    'candidate_focused_passes':sum(r['passed'] for r in candidate['focused'].values()),
    'candidate_focused_failures':sum(r['failed'] for r in candidate['focused'].values()),
    'test_relationships':observations,'format_exit_code':result['exit_code'],
    'candidate_gates':candidate['gates'],'all_original_gates_passed':candidate['all_original_gates_passed'],
    'decision':'unadmitted: original gates pass but broader admission remains open' if candidate['all_original_gates_passed'] else 'rejected: at least one original resource gate still fails',
    'same_contract_speedup_claimed':False,'lint_rerun':False,'full_suite_rerun':False,
    'independent_report_migration_audit_complete':False,'external_distribution_complete':False,
    'hypervoxel_deferred_by_user':True,'cache_index_admitted':False,'exact_ingress_admitted':False,
    'full_native_bundle_restored':False,'source_unchanged':True,'production_source_changes':False,'full_plan_complete':False})
print(json.dumps({'format_exit_code':result['exit_code'],'baseline_missing_claims':14,
    'candidate_focused_passes':61,'all_original_gates_passed':candidate['all_original_gates_passed']}),flush=True)
