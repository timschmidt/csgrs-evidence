# Reject the stale shared-target retry and use a fresh baseline target

The v1 CLI retry returned in 0.31 seconds, reported fresh Cargo artifacts, and
all three supposed rebuilt baseline test hashes differed from the preserved
baseline hashes. Both frozen child CLIs were identical to the candidate image.
Therefore v1 baseline-recompile and baseline-check are unqualified for baseline
behavior, despite exit zero. Preserve their original files and misleading
summary; this correction supersedes that baseline qualification claim. The v1
candidate CLI check used the actual retained candidate and remains applicable.

Create a previously absent Cargo target for the unchanged baseline snapshot.
Replay the exact original baseline compilation arguments and require every
local crate artifact to be newly built from that snapshot. Freeze the resulting
baseline CLI and its CLI test harness, then execute the exact original diagnostic
test with an explicit private binding to that child image. Preserve the entire
fresh target and all hashes after completion. Do not infer binary identity with
the first unsnapshotted baseline CLI. Source, compiler, lock, test assertions,
features and original resource gates remain unchanged. No runtime gate is rerun;
the first baseline/candidate compilations and their frozen test executables are
checked independently for fresh compilation and source identity. Run sequentially
under the existing external limits, including the unchanged 64 GiB volume cap.
