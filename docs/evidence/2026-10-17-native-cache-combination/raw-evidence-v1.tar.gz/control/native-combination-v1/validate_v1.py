# Compile immutable proposals, reproduce missing claims, and preserve original gates.
import gzip,json,os,re,shutil,sys,subprocess,zipfile,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['baseline','candidate']
prep=json.loads((V/('native-combination-'+mode+'-preparation-v1.json')).read_text())
S=Path(prep['source_root']);T=V/'target-candidate-v1'
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
A=V/('native-combination-'+mode+'-artifacts-v1');A.mkdir()
assert not (V/('native-combination-'+mode+'-protocol-v1.json')).exists()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
pins=json.loads(gzip.decompress(Path(prep['source_inventory']).read_bytes()))
def verify():
    assert all((S/p).is_file() and not (S/p).is_symlink() and sha(S/p)==h for p,h in pins.items())
    assert not reasons(resources())
verify()
protocol={'mode':mode,'source_root':str(S),'source_inventory_sha256':sha(prep['source_inventory']),
    'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),'compiler_sha256':compiler['tool_sha256'],
    'source_lock_sha256':sha(S/'Cargo.lock'),'test_workers':1,'build_jobs':2,
    'target':str(T),'binary_snapshot_root':str(A),'cpu_gate_seconds':120,'neck_wall_gate_seconds':60,
    'performance_comparison':False,'cache_admitted':False,'exact_ingress_admitted':False,
    'hypervoxel_deferred_by_user':True,'original_35_file_bundle_restored':False}
dump(V/('native-combination-'+mode+'-protocol-v1.json'),protocol)
results={}
def execute(label,args,allow_assertion_failure=False):
    verify();name='native-combination-'+mode+'-'+label+'-v1'
    mapped={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/T.relative_to(V)),
        'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
        '--bind',str(V),str(M),'--ro-bind',str(S),str(M/S.relative_to(V)),
        '--chdir',str(M/S.relative_to(V))]
    for key,value in mapped.items():argv.extend(['--setenv',key,value])
    argv+=args
    try:result=run(name,argv,S,target=T)
    except RuntimeError:
        result=json.loads((V/'logs'/name/'result.json').read_text())
        results[label]=result
        dump(V/('native-combination-'+mode+'-progress-v1.json'),results)
        if result['stops'] or not allow_assertion_failure or result['exit_code']!=101:raise
    results[label]=result;dump(V/('native-combination-'+mode+'-progress-v1.json'),results)
    verify()
    return (V/'logs'/name/'stdout').read_text(),(V/'logs'/name/'stderr').read_text(),result

tests=['kicad_track_failures','kicad_native_strokes','kicad_native_aggregation']
compile_args=[cargo,'test','--release','--locked','-p','hyperdrc','--no-run','--message-format=json']
for name in tests:compile_args+=['--test',name]
if mode=='candidate':compile_args+=['--lib']
stdout,stderr,_=execute('compile',compile_args)
artifacts={}
for line in stdout.splitlines():
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if row.get('reason')!='compiler-artifact' or not row.get('executable') or not row.get('profile',{}).get('test'):continue
    name=row['target']['name']
    if name not in tests+(['hyperdrc'] if mode=='candidate' else []):continue
    path=Path(row['executable']);physical=V/path.relative_to(M) if path.is_relative_to(M) else path
    assert physical.is_file() and physical.is_relative_to(T)
    copy=A/name;assert not copy.exists();shutil.copy2(physical,copy);assert sha(copy)==sha(physical)
    artifacts[name]={'compiled_path':str(physical),'executed_copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,
        'cargo_target':row['target'],'profile':row['profile']}
assert set(artifacts)==set(tests+(['hyperdrc'] if mode=='candidate' else [])),artifacts.keys()
dump(A/'executables-v1.json',artifacts)
focused={}
for name in tests:
    binary=M/Path(artifacts[name]['executed_copy']).relative_to(V)
    stdout,stderr,result=execute(name,[str(binary),'--test-threads=1','--nocapture'],True)
    rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',stdout,re.M)
    assert len(rows)==1 and rows[0][3:]==('0','0','0'),rows
    row=rows[0];assert (result['exit_code']==0)==(row[0]=='ok')
    focused[name]={'status':row[0],'passed':int(row[1]),'failed':int(row[2]),'ignored':0,
        'test_observations':re.findall(r'^test ([^ ]+) \.\.\. (ok|FAILED)$',stdout,re.M),'exit_code':result['exit_code']}
    assert len(focused[name]['test_observations'])==int(row[1])+int(row[2])
    dump(V/('native-combination-'+mode+'-focused-v1.json'),focused)
assert focused['kicad_track_failures']['passed']==39 and focused['kicad_track_failures']['failed']==0
missing=focused['kicad_native_strokes']['failed']>0 or focused['kicad_native_aggregation']['failed']>0
if mode=='baseline':assert missing
fixtures={};gates={}
if mode=='candidate':
    assert all(r['failed']==0 for r in focused.values()),focused
    assert sum(r['passed'] for r in focused.values())==61
    unzip=Path(shutil.which('unzip')).resolve();original=json.loads((V/'native-fixture-preflight-v1/result.json').read_text())
    assert sha(unzip)==original['unzip_sha256']
    for archive_name,board in [('CPArti FPGA dev board.zip','CPArti FPGA dev board.kicad_pcb'),('HVP109A.zip','HVP109A.kicad_pcb')]:
        relative='crates/hyperdrc/docs/'+archive_name;archive=S/relative
        assert sha(archive)==pins[relative]==original['records']['candidate/'+archive_name]['archive_sha256']
        with zipfile.ZipFile(archive) as source:
            assert source.testzip() is None;entries=source.infolist()
            assert len({p.filename for p in entries})==len(entries)
            members={}
            for info in entries:
                if info.is_dir():continue
                with source.open(info) as stream:members[info.filename]={'bytes':info.file_size,'sha256':hashlib.file_digest(stream,'sha256').hexdigest()}
            expected=source.read(board)
        assert members==original['records']['candidate/'+archive_name]['members']
        command=[str(unzip),'-p',str(archive),board]
        extracted=subprocess.run(command,capture_output=True,timeout=120)
        (A/board).write_bytes(extracted.stdout);(A/(archive_name+'.stderr')).write_bytes(extracted.stderr)
        assert extracted.returncode==0 and extracted.stdout==expected and expected
        fixtures[archive_name]={'archive':str(archive),'archive_sha256':sha(archive),'members':members,
            'unzip_argv':command,'unzip_sha256':sha(unzip),'exit_code':extracted.returncode,'board_sha256':sha(A/board),'independent_extractors_agree':True}
    dump(A/'fixtures-v1.json',fixtures)
    binary=M/Path(artifacts['hyperdrc']['executed_copy']).relative_to(V)
    for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
        stdout,stderr,result=execute(label,[str(binary),'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],True)
        assert 'skipping complex project fixture' not in stdout+stderr
        rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout,re.M)
        assert len(rows)==1 and sum(map(int,rows[0][1:3]))==1 and rows[0][3]=='0',rows
        gates[label]={'exit_code':result['exit_code'],'summary':rows[0],'external_stops':result['stops'],
            'elapsed_seconds':result['elapsed_seconds'],'performance_comparison':False}
        dump(V/'native-combination-candidate-gates-v1.json',gates)
assert all(sha(r['executed_copy'])==r['sha256'] for r in artifacts.values())
verify()
summary={'complete_for_declared_scope':True,'mode':mode,'focused':focused,'missing_claims_reproduced':missing,
    'gates':gates,'all_original_gates_passed':len(gates)==3 and all(r['exit_code']==0 for r in gates.values()),
    'commands':results,'artifacts':artifacts,'source_unchanged':True,'hypervoxel_deferred_by_user':True,
    'cache_admitted':False,'exact_ingress_admitted':False,'full_plan_complete':False,
    'lint_report_audit_downstream_distribution_gates_remain':True}
dump(V/('native-combination-'+mode+'-result-v1.json'),summary)
print(json.dumps({k:summary[k] for k in ['complete_for_declared_scope','mode','focused','gates','cache_admitted','exact_ingress_admitted']}),flush=True)
