# Fresh exact-track and circular-support combination probe

Target production base: 2564d20ed04e23c54ab8969b71ba2b0843efac63 in the
isolated validation repository. Hypervoxel is deferred by user instruction.
The original 35-file bundle remains rejected. Neither the E46 cache proposal
nor the E36 exact-track prototype is admitted by this experiment.

Owners: Hypercurve operation-local circular-support reuse and HyperDRC exact
KiCad track ingress/native aggregation. Properties P1, P4, P8-P9, P12-P20,
P25-P27 and P35-P39 apply. The missing contract is exact decimal/scientific
straight tracks with round caps, reusable native aggregation, preserved typed
failures and the existing full-project resource limits. This is a combination
experiment under T11; it is not permission to restore the rejected bundle.

First copy the unchanged E36 v4 independent stroke and aggregation tests into
a fresh source tree based on the current admitted source plus the unchanged
E46 cache proposal. Reproduce their missing claims alongside all 39 current
track failure tests. Record every terminal result, including expected failures;
no credit follows an assertion that did not execute. Do not change any existing
baseline test. Verify the source, compiler, dependency lock and inputs.

Only after that reproduction, prepare a second fresh source tree with exactly
the preserved E36 v4 patch plus the same unchanged E46 cache proposal. Preserve
its declared finite-rectangle to exact-capsule migration, diagnostic and report
source ownership changes, readiness version and unsupported-range test
migration. Do not silently claim report equality or semantic acceptance. The
known historical map_clone lint and unaudited 201-to-197 report change remain
open unless reproduced and resolved separately. No code correction is planned
in this first combination probe.

Run all 61 source/aggregation assertions in the combination, then the three
unchanged native release gates separately: full-board 120-second worker CPU,
copper-neck 60-second check-body wall, and Gerber smoke. Full original project
ZIPs, extraction results and all source test bodies remain unchanged. Verify
ZIP member content and independent Python/unzip board extraction before giving
gate credit. Missing fixtures or skipped workloads cannot pass this contract.
A failed gate rejects retention regardless of the focused test result. Continue
independent gates after a normal assertion failure, but stop on external resource
exhaustion. No concurrent builds or qualification workloads; one test worker.

Compare completed semantics independently of timing. The current source and
exact-track prototype represent different sets, so before/after elapsed time
is diagnostic and cannot establish a same-contract speedup. Cache cost claims
remain bounded by the original E46 corpus. A successful combination would still
need full downstream tests, strict Clippy, docs, an independent report migration
audit, actual consumers and the external distribution gate before admission.

Use the existing externally contained runner: 1,800 seconds per command, 8 GiB
child address space, two build jobs, 2 GiB available host memory, 512 MiB active
volume reserve, 64 GiB cumulative Disk B consumption and 64 MiB aggregate logs.
These are external controls, not internal total-work/heap/cancellation bounds.
Reuse only the still-open candidate target. Snapshot each executed native test
binary to a fresh immutable artifact path and hash physical paths separately.
Keep original checkout and closed evidence read-only, preserve every attempted
helper and outcome, and version corrections. Only current_work may change in
the ledger. Historical 27,093 missing paths remain unqualified. Do not claim
full-plan completion, cache admission, exact-track admission or a shipped path.
