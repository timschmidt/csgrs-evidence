"""Evaluate the same circle-envelope controls and original native workloads."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');T=M/'targets/circle-envelope-v1';A=V/'circle-envelope-candidate-artifacts-v1';R=N/'circle-envelope-candidate-v1'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,resources,reasons
assert not R.exists() and not A.exists();R.mkdir();A.mkdir()
prep=json.loads((W/'candidate-preparation-v1.json').read_text());bp=json.loads((N/'circle-envelope-baseline-v1/protocol-v1.json').read_text());br=json.loads((N/'circle-envelope-baseline-v1/result-v1.json').read_text());assert br['passed'];assert sha(br['artifact']['copy'])==br['artifact']['sha256']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'));rustfmt=str(Path(cargo).with_name('rustfmt'))
base=json.loads(gzip.decompress((N/'point-rational-native-facts-source-v1.json.gz').read_bytes()));pins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));commands={};artifacts={};summaries={}
path=prep['source_path'];raw=Path(prep['candidate_source']);assert sha(raw)==prep['candidate_source_sha256_before_format'];name='circle-envelope-candidate-format-v1';commands['format']=run(name,[rustfmt,'--edition','2024','--config','max_width=100,skip_children=true'],W,stdin=raw.read_bytes(),wall_seconds=60)
formatted=W/'candidate-formatted'/path;formatted.parent.mkdir(parents=True);shutil.copy2(N/'logs'/name/'stdout',formatted);overlays=dict(bp['overlays']);overlays[path]={'physical_path':str(formatted),'sha256':sha(formatted)}
assert formatted.read_text().split('#[cfg(test)]',1)[1]==Path(bp['overlays'][path]['physical_path']).read_text().split('#[cfg(test)]',1)[1]
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'preparation_sha256':sha(W/'candidate-preparation-v1.json'),'compiler_sha256':compiler['tool_sha256'],'source_root':str(S),'overlays':overlays,'open_baseline_target_reused':True,'baseline_executed_copy_preserved':br['artifact'],'acceptance_tests_byte_identical':True,'hypervoxel_excluded':True,'resource_contract_sha256':sha(N/'point-rational-equality-control-v1/retention-contract-v2.json'),'diagnostic_viability_only':True,'production_source_changed':False})
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(S/p)==h for p,h in base.items())
 assert all(sha(row['physical_path'])==row['sha256'] for row in overlays.values())
 assert sha(br['artifact']['copy'])==br['artifact']['sha256']
 assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
 assert not reasons(resources())
def execute(label,args,binary=False,allow_failure=False,wall_seconds=1800):
 verify();name='circle-envelope-candidate-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(V/'targets/circle-envelope-v1'),str(T),'--bind',str(scratch),str(scratch),'--chdir',str(scratch if binary else S)]
 for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
 for dest,row in overlays.items():argv+=['--ro-bind',row['physical_path'],str(S/dest)]
 if binary and 'hyperdrc-cli' in artifacts:argv+=['--ro-bind',artifacts['hyperdrc-cli']['copy'],str(T/'release/hyperdrc')]
 for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
 try:r=run(name,argv+args,S,target=T,wall_seconds=wall_seconds)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands)
  if r['stops'] or not allow_failure or r['exit_code']!=101:raise
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M);return out,err,r

def capture(out):
 for line in out.splitlines():
  if not line.startswith('{'):continue
  item=json.loads(line)
  if item.get('reason')!='compiler-artifact' or not item.get('executable'):continue
  target=item['target'];name=target['name']
  if name=='hyperdrc':name='hyperdrc-lib' if 'lib' in target['kind'] else ('hyperdrc-bin-tests' if item['profile']['test'] else 'hyperdrc-cli')
  if name=='hypercurve':name='hypercurve-lib'
  p=Path(item['executable']);physical=V/p.relative_to(M);copy=A/name;assert not copy.exists();shutil.copy2(physical,copy);assert sha(copy)==sha(physical);artifacts[name]={'copy':str(copy),'compiled_child_path':str(p),'compiled_physical_path':str(physical),'sha256':sha(copy),'bytes':copy.stat().st_size,'features':item['features']}
 dump(A/'executables-v1.json',artifacts)
def rows(out):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
# First rerun the identical baseline controls on the changed kernel.
out,_,_=execute('curve-build',[cargo,'test','--release','--locked','-p','hypercurve','--lib','--no-run','--message-format=json']);capture(out)
assert artifacts['hypercurve-lib']['features']==br['artifact']['features']
out,_,_=execute('support-tests',[artifacts['hypercurve-lib']['copy'],'curve_support::tests::','--nocapture','--test-threads=1'],binary=True,wall_seconds=60);summary=rows(out);assert len(summary)==1 and summary[0][:5]==('ok','11','0','0','0'),summary;summaries['support-tests']=summary
dump(R/'support-result-v1.json',{'passed':True,'tests':11,'summaries':summaries,'runtime_admitted':False})
out,_,_=execute('native-build',[cargo,'test','--release','--locked','-p','hyperdrc','--tests','--no-run','--message-format=json']);capture(out)
assert {'hyperdrc-cli','hyperdrc-lib','kicad_native_strokes','kicad_native_aggregation','kicad_track_failures','native_aggregation','native_aggregation_memory'}<=set(artifacts)
for name,count in {'kicad_native_strokes':10,'kicad_native_aggregation':12,'kicad_track_failures':39,'native_aggregation':13,'native_aggregation_memory':1}.items():
 out,_,_=execute(name,[artifacts[name]['copy'],'--nocapture','--test-threads=1'],binary=True,wall_seconds=60);summary=rows(out);assert summary==[('ok',str(count),'0','0','0','0')],summary;summaries[name]=summary
dump(R/'focused-result-v1.json',{'passed':True,'tests':86,'support_tests':11,'native_tests':75,'summaries':summaries,'runtime_admitted':False})
gates={}
for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
 out,err,r=execute(label,[artifacts['hyperdrc-lib']['copy'],'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],binary=True,allow_failure=True)
 assert 'skipping complex project fixture' not in out+err;summary=rows(out);assert len(summary)==1 and sum(map(int,summary[0][1:3]))==1 and summary[0][3:5]==('0','0'),summary
 gates[label]={'summary':summary,'exit_code':r['exit_code'],'process_elapsed_seconds':r['elapsed_seconds'],'assertion_diagnostic_lines':[line for line in (out+err).splitlines() if any(term in line.lower() for term in ['took','worker','seconds','budget','expected'])]};dump(R/'gates-progress-v1.json',gates)
verify();dump(R/'result-v1.json',{'focused_passed':True,'support_tests':11,'native_tests':75,'gates':gates,'gates_passed':all(v['exit_code']==0 for v in gates.values()),'commands':commands,'source_unchanged':True,'diagnostic_viability_only':True,'kernel_candidate_admitted':False,'exact_importer_admitted':False,'full_plan_complete':False});print(json.dumps({'support_tests':11,'native_tests':75,'gates':gates,'runtime_admitted':False}),flush=True)
