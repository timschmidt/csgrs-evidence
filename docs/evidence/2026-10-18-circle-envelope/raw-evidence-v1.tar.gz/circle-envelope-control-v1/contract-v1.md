# Retained-circle outer-envelope experiment

Target revision: 8c361463f3b0bd745aa3bb1f32571ab49beca771. The previous goal turn
made progress: current ingress failures, original resource gates and a complete
profile were recorded. All current implementation and E70 evidence hashes were
rechecked before this experiment. Hypervoxel remains excluded.

Correct the E70 attribution wording: the substring ::subcurve includes contact,
bounds, containment and line-image tests as well as actual subdivision. Its
23.762% inclusive weight is not subdivision cost, and the 15.846% normal-form
overlap is not a subdivision-only overlap. Preserve E70's raw profile, helper,
counts and historical report; publish a separately reproducible correction.
Actual named functions, not the broad substring, guide the next experiment.

Owner: Hypercurve CurveSupport2 conservative outer bounds. P3-P5, P8-P9,
P12-P20 and P35-P39 apply. The existing retained circular-conic certificate
already supplies an exact full-circle envelope after ordinary control bounds
fail. Test prioritizing the same certificate, using the same formula, before
expensive symbolic control-point comparisons. Do not add scalar precision work,
a second geometry representation, new cache state, policy or tolerance.

Domain: valid immutable retained circular rational Bezier supports, including
reversed/elevated charts, rational and symbolic radii, exact tiny/huge scales,
and their finite restrictions. The output is a conservative support envelope,
not a claim of the tightest box or of material topology. Keep range and pole
handling and the generic non-circular path. An unavailable radius certificate
must use the existing generic path; errors must not become empty geometry.

Missing acceptance coverage: independently specified rational points on a
quarter circle must lie in each resulting enclosure, including reversal,
degree elevation, translation and extreme scales. Preserve strict -> approximate
-> strict certainty. Keep non-circular controls and the complete existing
support-range, pole, native stroke, aggregation and source-failure tests.
Run the new tests unchanged on the baseline before changing the implementation.

Use read-only frozen source with pinned per-file overlays. Baseline overlays
add acceptance tests only; candidate overlays add the one coherent bounds change.
No production source is changed by this prototype. Use one new open Disk B
target, freezing copies of each executed binary before any subsequent rebuild.
All previously closed targets, helpers and artifacts remain read-only.

First evaluate focused semantics and the full existing support tests. Run the
unchanged 75 native ingress/aggregation checks and original complete two-board
worker-CPU 120-second, copper-neck body-wall 60-second and Gerber gates with the
unchanged exact importer. Wider envelopes can increase downstream work; retain
all unfavorable results. A single feasibility run is not a matched speedup or
admission. Retention additionally requires broader curve/native/modeling checks,
matched completed-work cost and allocation evidence, public/report compatibility,
and final integration checks. Exact importer admission remains separate.

Keep original cumulative free-space baselines: 16 GiB root, approved 72 GiB
Disk B, 8 GiB child address space, two jobs, 1800-second commands, 60-second
focused probes, 512 MiB filesystem and 2 GiB host reserves, 64 MiB cumulative
command logs. No limits are reset. These are external containment, not internal
heap or total-work bounds. No push or full-plan completion is claimed.
