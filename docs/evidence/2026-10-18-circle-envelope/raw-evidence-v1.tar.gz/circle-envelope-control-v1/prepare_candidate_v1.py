"""Prioritize the existing retained-circle envelope after baseline controls pass."""
import difflib,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';path='crates/hypercurve/src/curve_support.rs'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'circle-envelope-baseline-v1/result-v1.json').read_text());assert r['passed'] and r['new_tests_passed']==2 and r['existing_support_tests_passed']==9
protocol=json.loads((N/'circle-envelope-baseline-v1/protocol-v1.json').read_text());base=Path(protocol['overlays'][path]['physical_path']);assert sha(base)==protocol['overlays'][path]['sha256'];source=base.read_text();start=source.index('fn native_subcurve_outer_bounds(');end=source.index('pub(crate) fn retained_circular_support(',start)
replacement='''fn native_subcurve_outer_bounds(curve: &BezierSubcurve2) -> Classification<Aabb2> {
    // A retained circle equation already certifies an envelope for every
    // finite image point. Support scheduling needs a conservative box, so use
    // this construction evidence before comparing symbolic control points.
    // Active-range validation remains in subcurve_certified_outer_bounds.
    if let Some((_, circle)) = retained_circular_support(curve)
        && let Ok(radius) = circle.radius_squared.clone().sqrt()
    {
        return Classification::Decided(Aabb2::new_unchecked(
            crate::Point2::new(circle.center.x() - &radius, circle.center.y() - &radius),
            crate::Point2::new(circle.center.x() + &radius, circle.center.y() + &radius),
        ));
    }
    match curve {
        BezierSubcurve2::Quadratic(curve) => curve.control_hull_box(),
        BezierSubcurve2::Cubic(curve) => curve.control_hull_box(),
        BezierSubcurve2::RationalQuadratic(curve) => curve.certified_bounds(),
        BezierSubcurve2::Rational(curve) => curve.certified_bounds_classified(),
    }
}

'''
new=source[:start]+replacement+source[end:];assert new.split('#[cfg(test)]',1)[1]==source.split('#[cfg(test)]',1)[1]
out=W/'candidate-overlay'/path;assert not out.exists();out.parent.mkdir(parents=True);out.write_text(new)
patch=W/'candidate-v1.patch';assert not patch.exists();patch.write_text(''.join(difflib.unified_diff(source.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
G=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];head=subprocess.check_output(G+['rev-parse','HEAD'],cwd=O,text=True).strip();assert head=='a1ffc2de7151f0a49229f186001ceae04839d38f'
meta={'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'baseline_result_sha256':sha(N/'circle-envelope-baseline-v1/result-v1.json'),'baseline_protocol_sha256':sha(N/'circle-envelope-baseline-v1/protocol-v1.json'),'baseline_revision':'8c361463f3b0bd745aa3bb1f32571ab49beca771','current_revision':head,'intervening_commit_scope':'profile interpretation only; implementation bytes unchanged','source_path':path,'baseline_source_sha256':sha(base),'candidate_source':str(out),'candidate_source_sha256_before_format':sha(out),'production_change':'Move the existing exact retained-circle outer envelope before generic bounds; preserve generic fallback and range validation.','acceptance_test_module_byte_identical':True,'patch_sha256':sha(patch),'production_source_changed':False,'runtime_admitted':False}
p=W/'candidate-preparation-v1.json';assert not p.exists();p.write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n');print(json.dumps({'candidate':str(out),'unchanged_acceptance_tests':True,'runtime_admitted':False}))
