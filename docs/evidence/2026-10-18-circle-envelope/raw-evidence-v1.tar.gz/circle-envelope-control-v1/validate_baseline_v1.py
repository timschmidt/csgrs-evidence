"""Run unchanged circle-envelope acceptance controls on the current implementation."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');T=M/'targets/circle-envelope-v1';A=V/'circle-envelope-baseline-artifacts-v1';R=N/'circle-envelope-baseline-v1'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,resources,reasons
assert not R.exists() and not A.exists() and not (V/'targets/circle-envelope-v1').exists();R.mkdir();A.mkdir();(V/'targets/circle-envelope-v1').mkdir()
prep=json.loads((W/'baseline-preparation-v1.json').read_text());compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'));rustfmt=str(Path(cargo).with_name('rustfmt'))
base=json.loads(gzip.decompress((N/'point-rational-native-facts-source-v1.json.gz').read_bytes()));pins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));commands={};artifact=None
path='crates/hypercurve/src/curve_support.rs';raw=Path(prep['baseline_overlay'][path]['physical_path']);assert sha(raw)==prep['baseline_overlay'][path]['sha256_before_format']
name='circle-envelope-baseline-format-v1';r=run(name,[rustfmt,'--edition','2024','--config','max_width=100,skip_children=true'],W,stdin=raw.read_bytes(),wall_seconds=60);commands['format']=r
formatted=W/'baseline-formatted'/path;formatted.parent.mkdir(parents=True);shutil.copy2(N/'logs'/name/'stdout',formatted)
overlays=dict(prep['inherited_overlays']);overlays[path]={'physical_path':str(formatted),'sha256':sha(formatted)}
assert len(re.findall(r'#\[test\]\s*fn ',formatted.read_text()))==11
for row in overlays.values():assert sha(row['physical_path'])==row['sha256']
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'preparation_sha256':sha(W/'baseline-preparation-v1.json'),'compiler_sha256':compiler['tool_sha256'],'baseline_revision':prep['baseline_revision'],'source_root':str(S),'overlays':overlays,'new_target_initially_absent':True,'dependency_caches_reused':True,'new_test_count':2,'support_tests_expected':11,'hypervoxel_excluded':True,'production_change_prepared':False,'resource_contract_sha256':sha(N/'point-rational-equality-control-v1/retention-contract-v2.json')})
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(S/p)==h for p,h in base.items())
 assert all(sha(row['physical_path'])==row['sha256'] for row in overlays.values())
 if artifact:assert sha(artifact['copy'])==artifact['sha256']
 assert not reasons(resources())
def execute(label,args,binary=False):
 verify();name='circle-envelope-baseline-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(V/'targets/circle-envelope-v1'),str(T),'--bind',str(scratch),str(scratch),'--chdir',str(scratch if binary else S)]
 for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
 for dest,row in overlays.items():argv+=['--ro-bind',row['physical_path'],str(S/dest)]
 for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
 try:r=run(name,argv+args,S,target=T,wall_seconds=60 if binary else 1800)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands);raise
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M);return out
out=execute('build',[cargo,'test','--release','--locked','-p','hypercurve','--lib','--no-run','--message-format=json'])
rows=[json.loads(l) for l in out.splitlines() if l.startswith('{')];items=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='hypercurve'];assert len(items)==1
item=items[0];child=Path(item['executable']);physical=V/child.relative_to(M);copy=A/'hypercurve-lib';shutil.copy2(physical,copy);assert sha(copy)==sha(physical)
artifact={'copy':str(copy),'sha256':sha(copy),'compiled_child_path':str(child),'compiled_physical_path':str(physical),'bytes':copy.stat().st_size,'features':item['features']};dump(A/'executable-v1.json',artifact)
out=execute('support-tests',[str(copy),'curve_support::tests::','--nocapture','--test-threads=1'],binary=True)
summary=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M);assert len(summary)==1 and summary[0][:5]==('ok','11','0','0','0'),summary
verify();dump(R/'result-v1.json',{'passed':True,'new_tests_passed':2,'existing_support_tests_passed':9,'summary':summary,'commands':commands,'artifact':artifact,'source_unchanged':True,'production_change_prepared':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'baseline_support_tests_passed':11,'new_tests_passed':2,'runtime_admitted':False}),flush=True)
