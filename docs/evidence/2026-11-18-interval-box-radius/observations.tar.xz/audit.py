from pathlib import Path
import re
p=Path('interval-inventory.tsv')
path='crates/hypersolve/src/interval.rs'
source=Path(path).read_text().splitlines()
rows=[]
for line in p.read_text().splitlines():
 cols=line.split('\t')
 if cols[1]!=path or cols[3]=='rational_interval_product':
  rows.append(line);continue
 n=cols[3];cols[2]=str(next(i for i,l in enumerate(source,1) if re.match(r'(?:pub )?(?:struct|fn|enum) '+n+r'\b',l)))
 cols[8]='host / wasm32 with std';cols[10]='no serde derive or direct wire codec'
 cols[14]='interval_box_radius; hypersolve owner suite';cols[15]='hypersolve certification interval rows, box and Krawczyk benchmarks'
 if n=='VariableBall':
  desc=('SymbolId and exact Real radius','closed symmetric bounds around a separately supplied candidate','retains Real source','interval certifiers and Krawczyk routines')
 elif n.endswith('Error'):
  desc=('tag with SymbolId or source indices','typed validation or enclosure construction failure','scalar fields only','interval certifiers and box error formatting')
 elif n.endswith('Package') or n.endswith('Status'):
  desc=('discriminant only','polynomial package selection' if n.endswith('Package') else 'aggregate replay outcome','no owned collection','interval-box report and caller')
 elif n.endswith('Report'):
  desc=('VariableBall list and optional CandidateCertificationReport','original input, outcome and row evidence','Vec, optional owned message and row evidence','interval-box facade and caller')
 elif n.startswith('validate_'):
  desc=('exact Real sign and radius','validate in source order; last valid radius for each symbol wins','builds HashMap<SymbolId, Real>','matching Krawczyk certifier' if 'krawczyk' in n else 'affine and both quadratic interval certifiers')
 elif n.endswith('_message'):
  desc=('no endpoints; typed input error','formats diagnostic; preserves symbol or row index','owned String','interval-box facade')
 elif n=='certify_interval_box_candidate':
  desc=('supplied VariableBall list and row receipts','aggregate existing package result; point/box scope and approximate row receipt gaps','clones input list and retains optional report/message','public interval-box report API')
 else:
  desc=('exact Real center bindings and radii','bound retained polynomial residuals; candidate replay on other rows','symbol map and residual ball vector, plus row reports','interval-box facade and direct callers')
 cols[5:8]=desc[:3];cols[11]=desc[3]
 cols[13]='retain solver-owned evidence and domain validation'
 cols[16]='body and immediate callers audited at 97fe4e072; see interval-box-proof-scope.md'
 rows.append('\t'.join(cols))
p.write_text('\n'.join(rows)+'\n')
