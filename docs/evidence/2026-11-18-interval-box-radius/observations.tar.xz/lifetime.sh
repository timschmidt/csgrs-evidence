set -eu
s=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/lifetime-target"
cd "$s/lifetime"
for v in all-radii before fixed; do
 case "$v" in
 before) git -C "$s/wasm-repo" apply -R "$s/all-radii.patch";;
 fixed) git -C "$s/wasm-repo" switch --detach c9f1f9ac5;;
 esac
 cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/radius-lifetime" "$s/images/$v-lifetime"
 setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-lifetime" > "$s/logs/$v-lifetime" 2> "$s/logs/$v-headroom"
done
