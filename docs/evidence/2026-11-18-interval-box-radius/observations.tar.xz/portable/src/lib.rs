use hyperlimit::{compare_reals,PredicatePolicy};
use hyperreal::Real;
use hypersolve::{Constraint,Expr,Problem,VariableBall,SymbolId,certify_interval_box_candidate,context_from_problem,IntervalBoxCertificationPackage as P,IntervalBoxCertificationStatus as S};
#[unsafe(no_mangle)]
pub extern "C" fn box_verdict(case:u32,mode:u32,package:u32)->u32 {
 let policy=if mode==0 {PredicatePolicy::STRICT} else {PredicatePolicy::APPROXIMATE_512};
 let package=match package {0=>P::Affine,1=>P::UnivariateQuadratic,_=>P::MultivariateQuadratic};
 let radius=match case {0|4=>{
 let zero=(Real::e()+Real::one()).sin()-Real::e().sin()*Real::one().cos()-Real::e().cos()*Real::one().sin();
 let r=zero-Real::from(2).powi_i64(-2048).unwrap();
 let _=compare_reals(&r,&Real::zero(),PredicatePolicy::APPROXIMATE_512);
 if case==4 {r+Real::one()} else {r}
 },1=>Real::one(),2=>Real::zero(),_=>Real::from(-1)};
 let mut p=Problem::default();p.add_variable("x",Real::zero());
 p.add_constraint(Constraint::equality("zero",Expr::int(0)));
 let report=certify_interval_box_candidate(&p.analyze(),&context_from_problem(&p),&[VariableBall{symbol:SymbolId(0),radius}],package,policy);
 match report.status {S::Certified=>1,S::Violation=>2,S::Unknown=>3,S::InvalidInput=>{
 assert!(report.certification.is_none());if report.message.unwrap().contains("unknown variable radius sign"){4}else{5}
 }}
}
