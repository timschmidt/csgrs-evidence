const fs=require("node:fs"),assert=require("node:assert/strict");
(async()=>{
const module=await WebAssembly.compile(fs.readFileSync(process.argv[2]));
assert.deepEqual(WebAssembly.Module.imports(module),[]);
const fixed=process.argv[3]==="repaired";
for(let run=0;run<2;run++){
 const {exports}=await WebAssembly.instantiate(module);
 for(let cycle=0;cycle<2;cycle++)for(let pkg=0;pkg<3;pkg++)for(let mode=0;mode<2;mode++)for(let c=0;c<5;c++){
 const actual=exports.box_verdict(c,mode,pkg);
 assert.equal(actual,c===0 ? ((mode===0 || fixed)?4:1): c===3?5:1,JSON.stringify({pkg,mode,c,actual}));
 }
}
console.log("120 ordered calls in two fresh instances, zero imports, passed",process.argv[2]);
})().catch(e=>{console.error(e);process.exit(1)})
