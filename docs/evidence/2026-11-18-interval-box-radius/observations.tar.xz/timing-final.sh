set -eu
s=/dev/shm/interval-box-coverage
i=0
for v in before all-radii all-radii before; do
 i=$((i+1))
 CRITERION_HOME="$s/timing-final/$i-$v" setarch "$(uname -m)" -R taskset -c 2 "$s/images/$v-certification" --bench --noplot --warm-up-time 0.4 --measurement-time 1 --sample-size 25 'certify_(affine_krawczyk_box|univariate_quadratic_krawczyk_rows|multivariate_quadratic_krawczyk_square|interval_box_candidate_report|quadratic_interval_rows|multivariate_quadratic_interval_rows)' > "$s/logs/final-timing-$i-$v" 2>&1
done
