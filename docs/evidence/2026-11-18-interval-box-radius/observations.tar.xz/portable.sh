set -eu
s=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/wasm-target"
cd "$s/portable"
cargo +1.95.0 build --release --offline --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/box_radius_client.wasm" "$s/images/$1.wasm"
node check.cjs "$s/images/$1.wasm" "$2"
