set -eu
s=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/client-target"
cd "$s/client"
cargo +1.95.0 build --offline --release
cp "$CARGO_TARGET_DIR/release/box-coverage-client" "$s/images/$1-client"
"$s/images/$1-client" > "$s/logs/$1-client-rows"
