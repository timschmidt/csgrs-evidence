set -eu
s=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/lifetime-target"
cd "$s/usable"
for v in fixed before all-radii; do
 case "$v" in
 before) git -C "$s/wasm-repo" switch --detach 97fe4e072;;
 all-radii) git -C "$s/wasm-repo" apply "$s/all-radii.patch";;
 esac
 cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/radius-usable" "$s/images/$v-usable"
 python3 "$s/measure-rss.py" "$s/logs/$v-usable-rss" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-usable" > "$s/logs/$v-usable"
done
