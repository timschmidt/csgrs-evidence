from pathlib import Path
import json,hashlib,ast
s=Path(__file__).parent
evidence='docs/evidence/2026-11-18-interval-box-radius'
snap='e45bb6b625f68970563ac824dcdbfbfd41134243'
current='97fe4e072'
change='certified-variable-radius-domain'
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=Path('docs/research/interval-size-accounts.json')
budget=load(p);rows=load(s/'sizes.json')
assert all(v[-1] for a in rows.values() for v in a.values())
for name,a in rows.items():
 if not any(x[3] for x in a.values()):continue
 keys=['fixed','before','all-radii']
 wasm=name.endswith('wasm')
 ms={}
 for metric,(x,y,z,d,cum,passed) in sorted(a.items()):
  if not cum:continue
  caps=budget['existing_artifacts']['wasm_final_file_and_code' if wasm else 'native_final_file_and_allocated_sections']
  ms[metric]=dict(baseline=x,previous_retained=y,retained=z,incremental_growth_bytes=d,incremental_growth_percent=round(100*d/y,6),accepted_positive_growth_bytes=cum,remaining_cumulative_bytes=caps['cumulative_bytes']-cum,remaining_cumulative_percent=round(caps['cumulative_percent']-100*cum/x,6),caps=caps,passes_both_caps=passed)
 images=[s/'images'/(v+'-'+name) for v in keys]
 assert images[-1].stat().st_size+16*2**20<=64*2**20
 budget['accounts'].append(dict(artifact='interval-box qualification/'+name,role='Complete linked solver report client',target='wasm32-unknown-unknown' if wasm else 'x86_64-unknown-linux-gnu',toolchain='Rust 1.95.0',features='default' if wasm else 'dispatch-trace (see locked client manifest)',profile='release',baseline_commit=budget['baseline_commit'],previous_commit=current,source_snapshot=snap,baseline_sha256=sha(images[0]),previous_sha256=sha(images[1]),retained_sha256=sha(images[2]),metrics=ms,headroom=f'{64*2**20-images[-1].stat().st_size} bytes free in 64 MiB host qualification image allowance, 16 MiB required.',evidence=evidence))
budget['accepted_changes'].append(dict(id=change,benefit='Prevents a negative box radius from producing satisfaction or unique-root certificates under a terminal rounding policy.',sources=['crates/hypersolve/src/interval.rs'],production_implementation_changed=True,source_snapshot=snap,evidence=evidence))
write(p,budget)
m=Path('docs/research/interval-memory-accounts.json')
mb=load(m);assert not mb['accounts']
ns={'__file__':str(s/'lifetime-summary.py')}
exec((s/'lifetime-summary.py').read_text().split('vs=')[0],ns)
vs=[ns['collect'](v) for v in ['fixed','before','all-radii']]
mr=[];charged=[]
for i in range(60):
 key=(str(i),'HEAP');heap=[v[key] for v in vs]
 assert heap[0][-2]>=heap[1][-2]>=heap[2][-2] and all(h[-1]==0 for h in heap)
 for warm in [0,1]:
  key=(str(i),'STACK',str(warm))
  x,y,z=(v[key] for v in vs)
  inc=max(0,z-y);cum=max(0,y-x)+inc
  assert inc<=128 and 100*inc<=y and cum<=256 and 100*cum<=2*x and max(x,y,z)<16384
  r=dict(workload=i,temperature=['cold','warm'][warm],fixed=x,previous=y,retained=z,incremental_charge_bytes=inc,cumulative_charge_bytes=cum,remaining_cumulative_bytes=256-cum,remaining_cumulative_percent=round(2-100*cum/x,6))
  mr.append(r)
  if cum:charged.append(r)
write(s/'memory-rows.json',mr)
headrooms=[int(l.split()[-1]) for p in (s/'logs').glob('*-headroom*') for l in p.read_text().splitlines()]
assert min(headrooms)>2**20
mb['status']='One bounded native solver stack exception admitted. Each target and workload uses its own measured account.'
mb['accounts'].append(dict(id=change,source_snapshot=snap,previous_commit=current,baseline_commit=mb['baseline_commit'],target='x86_64-unknown-linux-gnu, Rust 1.95.0 release, System allocator, one guarded native worker',call_boundary='Construct problem and radii, warm approximate predicate for opaque inputs, certify, inspect status and destroy complete report. Thread startup and caller frames excluded from stack; guard and caller included in headroom.',workload_key='i = (0 report or 1 Krawczyk)*30 + (0 affine, 1 univariate quadratic, 2 multivariate quadratic)*10 + (0 STRICT or 1 APPROXIMATE_512)*5 + radius case (0 hidden negative, 1 one, 2 zero, 3 negative one, 4 opaque positive)',stack_caps=dict(incremental_bytes=128,incremental_percent_of_previous=1,cumulative_bytes=256,cumulative_percent_of_fixed=2,maximum_callee_stack_bytes=16384,thread_capacity_bytes=2097152,required_free_bytes=1048576,minimum_observed_free_bytes=min(headrooms)),heap_caps=dict(incremental_peak_requested_bytes=0,cumulative_peak_requested_bytes=0,maximum_peak_requested_bytes=16384,incremental_retained_bytes=0,cumulative_retained_bytes=0),max_observed_peak_requested_bytes=15036,retained_bytes_after_drop=0,measurement='Two sentinel patterns, cold and warm, 24 processes per revision. Positive differences between observed maxima charged separately even where individual samples vary. Full 120 rows in memory-rows.json in the archive. Zero-charge rows have full remaining allowance.',charged_stack_rows=charged,evidence=evidence))
mb['limitations']=[v for v in mb['limitations'] if not v.startswith('An empty ledger')]
write(m,mb)
print('charged rows',len(charged),'max incremental and cumulative',max(r['incremental_charge_bytes'] for r in mr),max(r['cumulative_charge_bytes'] for r in mr),'headroom',min(headrooms))
