set -eu
s=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/target"
cargo +1.95.0 bench --locked -p hypersolve --bench certification --features dispatch-trace --no-run --message-format=json > "$s/logs/$1-bench.json"
python3 - "$s" "$1" <<'PY'
import json,sys,shutil
from pathlib import Path
s=Path(sys.argv[1]); v=sys.argv[2]
r=next(r for l in (s/'logs'/(v+'-bench.json')).read_text().splitlines() if (r:=json.loads(l)).get('executable') and r['target']['name']=='certification')
shutil.copy2(r['executable'],s/'images'/(v+'-certification'))
PY
