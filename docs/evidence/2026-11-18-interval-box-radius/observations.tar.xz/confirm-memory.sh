set -eu
s=/dev/shm/interval-box-coverage
for i in $(seq 8 23); do
 for v in fixed before all-radii; do
  setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-lifetime" > "$s/logs/$v-lifetime-$i" 2> "$s/logs/$v-headroom-$i"
 done
done
