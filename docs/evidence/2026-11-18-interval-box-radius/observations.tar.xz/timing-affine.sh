set -eu
s=/dev/shm/interval-box-coverage
i=0
for v in all-radii before before all-radii before all-radii all-radii before; do
 i=$((i+1))
 CRITERION_HOME="$s/timing-affine/$i-$v" setarch "$(uname -m)" -R taskset -c 2 "$s/images/$v-certification" --bench --noplot --warm-up-time 1 --measurement-time 2 --sample-size 40 'certify_affine_krawczyk_box' > "$s/logs/affine-timing-$i-$v" 2>&1
done
