set -eu
s=/dev/shm/interval-box-coverage
i=0
for v in before radius radius before radius before before radius; do
 i=$((i+1))
 CRITERION_HOME="$s/timing/$i-$v" setarch "$(uname -m)" -R taskset -c 2 "$s/images/$v-certification" --bench --noplot --warm-up-time 1 --measurement-time 2 --sample-size 30 certify_interval_box_candidate_report > "$s/logs/timing-$i-$v" 2>&1
done
