from pathlib import Path
import json,wasmtime as wt,sys
s=Path(__file__).parent;cfg=wt.Config();cfg.consume_fuel=True;e=wt.Engine(cfg)
calls=json.loads((s/'final/calls.json').read_text())[0]
for t in sys.argv[1:]:
    store=wt.Store(e);mod=wt.Module.from_file(e,str(s/(t+'.wasm')));store.set_fuel(1000000)
    assert not mod.imports;ex=wt.Instance(store,mod,[]).exports(store);rows=[]
    for name,args,value in calls:
        store.set_fuel(1000000);actual=ex[name](store,*args);assert actual==int(value)
        rows.append([name,args,1000000-store.get_fuel()])
    (s/(t+'-fuel.json')).write_text(json.dumps(rows,separators=(',',':'))+'\n')
