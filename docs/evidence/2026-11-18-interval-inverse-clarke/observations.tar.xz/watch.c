#include <stdint.h>
#include <unicorn/unicorn.h>
#include <unicorn/arm.h>
struct measurement {
    uint64_t instructions;
    uint32_t minimum_sp;
};
static void observe(uc_engine *cpu, uint64_t address, uint32_t size, void *user) {
    struct measurement *m = user;
    uint32_t sp = 0;
    if (uc_reg_read(cpu, UC_ARM_REG_SP, &sp) != UC_ERR_OK) {
        uc_emu_stop(cpu);
        return;
    }
    m->instructions++;
    if (sp < m->minimum_sp) m->minimum_sp = sp;
}
int install(uc_engine *cpu, struct measurement *m) {
    uc_hook hook;
    return uc_hook_add(cpu, &hook, UC_HOOK_CODE, (void *)observe, m, 1, 0);
}
