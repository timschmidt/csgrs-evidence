set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
unset RUSTUP_TOOLCHAIN CARGO_TARGET_DIR CARGO_PROFILE_TEST_DEBUG CARGO_PROFILE_RELEASE_DEBUG RUSTFLAGS CARGO_ENCODED_RUSTFLAGS ALUMINA_AP_PASSWORD
export CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0
cd "$s/alumina-firmware"
git diff --exit-code -- crates/alumina-foc/src/lib.rs
trap 'git restore -- crates/alumina-foc/src/lib.rs' EXIT
for tag in both; do
    if test "$tag" = both; then git apply "$s/both.patch"; fi
    taskset -c 0-3,6-13,16-19 cargo +1.88.0 run --locked -p xtask -- build --board mks-esp32-foc-v1 --profile release > "$s/board-$tag.log" 2>&1
    file=$(sed -n 's/^board-qualified artifact: //p' "$s/board-$tag.log" | tail -1)
    test -f "$file"
    cp "$file" "$s/$tag-mks.elf"
done
