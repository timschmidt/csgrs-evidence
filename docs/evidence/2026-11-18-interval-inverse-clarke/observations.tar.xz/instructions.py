from pathlib import Path
from collections import defaultdict
import ctypes as ct, importlib.util, json, sys
from elftools.elf.elffile import ELFFile
p=Path('crates/hyperlattice-interval/conformance/alumina-foc/check-thumb.py')
spec=importlib.util.spec_from_file_location('thumb',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
s=Path(__file__).parent; tag=sys.argv[1]
class Measure(ct.Structure):
    _fields_=[('instructions',ct.c_uint64),('minimum_sp',ct.c_uint32)]
probe=ct.CDLL(str(s/'watch.so'))
probe.install.argtypes=[ct.c_void_p,ct.POINTER(Measure)]
with (s/(tag+'.elf')).open('rb') as f:
    elf=ELFFile(f)
    sections={sect.name:sect['sh_size'] for sect in elf.iter_sections() if sect['sh_flags']&2}
    segments=[(seg['p_vaddr'],seg.data()) for seg in elf.iter_segments(type='PT_LOAD')]
    entries={n:symbols[0]['st_value'] for n in m.CALLS if (symbols:=elf.get_section_by_name('.symtab').get_symbol_by_name(n))}
runs=json.loads((s/'final/calls.json').read_text())
rows=[]
for order,calls in enumerate(runs):
    cpu=m.Uc(m.UC_ARCH_ARM,m.UC_MODE_THUMB|m.UC_MODE_MCLASS)
    cpu.ctl_set_cpu_model(m.UC_CPU_ARM_CORTEX_M4)
    cpu.mem_map(m.FLASH,m.FLASH_BYTES,m.UC_PROT_READ|m.UC_PROT_EXEC)
    cpu.mem_map(m.RAM+4096,4096,m.UC_PROT_READ|m.UC_PROT_WRITE)
    for addr,data in segments:cpu.mem_write(addr,data)
    cpu.reg_write(m.UC_ARM_REG_SP,m.STACK_TOP)
    meas=Measure();assert probe.install(cpu._uch,ct.byref(meas))==0
    for run in range(2):
        for name,args,v in calls:
            if name not in entries:continue
            meas.minimum_sp=m.STACK_TOP;meas.instructions=0
            regs=[(r,x&0xffffffff) for r,x in zip(m.ARGUMENTS,args)]
            cpu.reg_write_batch([*regs,(m.UC_ARM_REG_LR,m.RETURN|1)])
            cpu.emu_start(entries[name],m.RETURN,count=1000000)
            pc,sp,lo,hi=cpu.reg_read_batch([m.UC_ARM_REG_PC,m.UC_ARM_REG_SP,m.UC_ARM_REG_R0,m.UC_ARM_REG_R1])
            value=(lo if name=='range_probe' else lo | (hi<<32))
            assert pc==m.RETURN and sp==m.STACK_TOP and value==int(v)%(1<<(32 if name=='range_probe' else 64))
            peak=m.STACK_TOP-meas.minimum_sp;assert 0<peak<=4096 and 0<meas.instructions<1000000
            rows.append([order,run,name,args,value,meas.instructions,peak])
(s/(tag+'-calls.json')).write_text(json.dumps(rows,separators=(',',':'))+'\n')
print(tag,len(rows),sections,max(r[-1] for r in rows),max(r[-2] for r in rows))
