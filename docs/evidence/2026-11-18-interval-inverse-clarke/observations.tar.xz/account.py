from pathlib import Path
import json
s=Path(__file__).parent
p=Path('docs/research/interval-size-accounts.json'); doc=json.loads(p.read_text());key='firmware_q30_modulation_rounding_test'
data=json.loads((s/'results.json').read_text())['contract']
names={'fixed':'fixed','preceding':'previous','retained':'lanes'}
account={'benefit':'Exact integration test of every common-mode and duty endpoint, closed limits and ordered range failures. Catches one-bit upper duty under-enclosure missed by the preceding owner suite.','evidence':'docs/evidence/2026-11-18-interval-inverse-clarke','toolchain':'Rust 1.88.0 x86_64-unknown-linux-gnu, locked alumina-firmware release q30_contract test executable, debug=0. Same absolute build path for all revisions.','firmware':{'fixed':'2d68e82b7341db7b747b20e4ad1455a4c1113a00','preceding':'96ac22cadef311f069d62bae4dfa5f3918cfc143','retained':(s/'fixture-revision').read_text().strip()},'csgrs':{'fixed':doc['baseline_commit'],'preceding_and_retained':'b4d7b78fc51446bf75cdb5672df392a1c168557e'},'caps':{'incremental_bytes':16384,'incremental_percent':1,'cumulative_bytes':32768,'cumulative_percent':2},'capacity_per_artifact':2**26,'required_free_per_artifact':2**24}
a={'sha256':{t:data[k]['sha256'] for t,k in names.items()},'metrics':{},'free_bytes':2**26-data['lanes']['bytes']}
for name,k in [('file','bytes'),('text','text')]:
 d={t:data[n][k] for t,n in names.items()};out=d.copy()
 for period,base,cap,pct in [('incremental','preceding',16384,1),('cumulative','fixed',32768,2)]:
    charge=d['retained']-d[base];assert 0<=charge<=cap and charge*100<=d[base]*pct
    out[period+'_charge']=charge;out['remaining_'+period+'_bytes']=cap-charge;out['remaining_'+period+'_percent']=round(pct-charge*100/d[base],6)
 a['metrics'][name]=out
assert a['free_bytes']>=2**24
account['artifacts']={'q30_contract':a}
assert key not in doc
doc[key]=account;p.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
