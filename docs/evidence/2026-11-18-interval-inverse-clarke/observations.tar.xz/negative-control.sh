set -eu
s=/dev/shm/interval-inverse-clarke; fw="$s/alumina-firmware"
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/fwnegative" CARGO_PROFILE_RELEASE_DEBUG=0
cd "$fw"
p=crates/alumina-foc/src/lib.rs; t=crates/alumina-foc/tests/q30_contract.rs
git diff --exit-code -- "$p"
trap 'git restore -- "$p"; cp "$s/retained-test.rs" "$t"' EXIT
git show "HEAD:$t" > "$t"
python3 - "$p" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text();a='div_ceil(scaled_upper, denominator)';assert s.count(a)==1
p.write_text(s.replace(a,'div_floor(scaled_upper, denominator)'))
PY
git diff -- "$p" > "$s/duty-mutation.patch"
cargo +1.88.0 test --release --locked -p alumina-foc > "$s/mutation-previous.log" 2>&1
cp "$s/retained-test.rs" "$t"
r=0
cargo +1.88.0 test --release --locked -p alumina-foc --test q30_contract > "$s/mutation-retained.log" 2>&1 || r=$?
test "$r" -eq 101
rg -q 'inverse_clarke_and_modulation_preserve_each_rounding_boundary .*FAILED' "$s/mutation-retained.log"
