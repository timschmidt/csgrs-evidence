from pathlib import Path
import sys,itertools,ctypes as c,json
s=Path(__file__).parent
class Sample(c.Structure):_fields_=[('ns',c.c_uint64),('checksum',c.c_int64)]
seq=['preceding','positive_divide']
first=int(sys.argv[1])%2; fns={}
for name in seq[::(-1 if first else 1)]:
 f=c.CDLL(str(s/(name+'.so'))).timed;f.argtypes=[c.c_uint32];f.restype=Sample;fns[name]=f
for r in range(30):
 for a in range(4):
    result={}
    for name in seq[::(-1 if (r+a+first)%2 else 1)]:result[name]=fns[name](a)
    assert len(set(v.checksum for v in result.values()))==1
    if r>=6:print(r,a,*[result[name].ns for name in seq])
