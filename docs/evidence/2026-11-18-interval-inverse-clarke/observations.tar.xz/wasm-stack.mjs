import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url);
const calls=JSON.parse(await readFile(new URL('final/calls.json',root)));
const output=[];
for (const name of process.argv.slice(2)) {
 const wat=await readFile(new URL(name+'.wat',root),'utf8');
 assert.doesNotMatch(wat,/memory\.grow/);
 const capacity=Number(/\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)/.exec(wat)[1]);
 const module=await WebAssembly.compile(await readFile(new URL(name+'.wasm',root)));
 assert.deepEqual(WebAssembly.Module.imports(module),[]);
 for (const order of [0,1]) for(const pattern of [0x55,0xaa]) {
  const {exports:api}=await WebAssembly.instantiate(module);
  for(const phase of ['cold','warm']) {
   const table={}; const stack=new Uint8Array(api.memory.buffer,0,capacity);
   for(const [fn,args,expected] of calls[order]){
     // Existing corpus stack peaks are below 1 KiB. Guard and inspect the full
     // stack when finished; refresh the top 4 KiB before each call.
     if(!Object.keys(table).length)stack.fill(pattern);
     else stack.fill(pattern,capacity-4096);
     const value=api[fn](...args);assert.equal(String(value),expected);
     const i=stack.subarray(capacity-4096).findIndex(b=>b!==pattern);
     assert.ok(i>0);
     const key=fn==='range_probe'?fn:fn+'/'+args[1];
     table[key]=Math.max(table[key]||0,4096-i);
   }
   assert.ok(stack.subarray(0,capacity-4096).every(v=>v===pattern));
   output.push({name,order,pattern,phase,table});
  }
 }
}
await writeFile(new URL('wasm-stack.json',root),JSON.stringify(output,null,2));
