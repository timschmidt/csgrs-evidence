from pathlib import Path
import subprocess as sp,hashlib,json,collections
from elftools.elf.elffile import ELFFile
s=Path(__file__).parent
def read(n):return json.loads((s/n).read_text())
def artifact(name):
 p=s/name
 result={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 if p.suffix!='.wasm':
    with p.open('rb') as f:result['text']=ELFFile(f).get_section_by_name('.text')['sh_size']
 return result
tags=['preceding','divide','multiply','affine','staged_fixed','positive_divide','both']
base=read('preceding-calls.json');fuel=read('preceding-fuel.json');oracle=read('preceding-corpus.json')
variants={}
for t in tags:
 rows=read(t+'-calls.json');fu=read(t+'-fuel.json')
 assert all(x[:5]==y[:5] for x,y in zip(rows,base,strict=True))
 assert all(x[:2]==y[:2] for x,y in zip(fu,fuel,strict=True))
 assert read(t+'-corpus.json')==oracle
 costs={}
 for action in (3,4):
    selected=[r for r in rows if r[:3]==[0,0,'output_word'] and r[3][1]==action and r[3][2]<4]
    # check.mjs reads lane zero again as an alias control. Count one call per (index, lane).
    words={tuple(r[3]):r for r in selected};assert len(words)==660
    costs[action]={'instructions':sum(r[-2] for r in words.values()),'stack_bytes':max(r[-1] for r in words.values())}
 variants[t]={'artifacts':{n:artifact(t+n) for n in ['-cost','-native-probe','-shared-probe','.wasm','.elf']},'thumb':costs,'thumb_work_increases':sum(x[-2]>y[-2] for x,y in zip(rows,base)),'thumb_stack_increases':sum(x[-1]>y[-1] for x,y in zip(rows,base)),'wasm_fuel_increases':sum(x[-1]>y[-1] for x,y in zip(fu,fuel))}
 for f in ['bench-'+t,t+'.so']:
    if (s/f).exists():variants[t]['artifacts'][f]=artifact(f)
st=read('wasm-stack.json')
by={t:[{k:v for k,v in r.items() if k!='name'} for r in st if r['name']==t] for t in ('preceding','both','positive_divide','divide')}
assert all(r==by['preceding'] for r in by.values())
kinds=read('modulation-types.json');mod={}
for m in ['thumb','wasm']:
 a=read('modulation-'+m+'-preceding.json');b=read('modulation-'+m+'-both.json');mod[m]={}
 for k in sorted(set(kinds)):
    z=[(x,y) for i,x,y in zip(kinds,a,b,strict=True) if i==k]
    mod[m][k]={'calls':len(z),'work':[sum(w[j][0] for w in z) for j in (0,1)],'max_work_increase':max(y[0]-x[0] for x,y in z)}
    if m=='thumb':mod[m][k].update(peak_stack=[max(w[j][1] for w in z) for j in (0,1)],max_stack_increase=max(y[1]-x[1] for x,y in z))
board=read('board-results.json')
for name in ['positive_divide','both']:
 assert board[name]['sections']==board['preceding']['sections']
 with (s/'preceding-mks.elf').open('rb') as a,(s/(name+'-mks.elf')).open('rb') as b:
    x,y=ELFFile(a),ELFFile(b);board[name]['differing_sections']=[p.name for p in x.iter_sections() if p.data()!=y.get_section_by_name(p.name).data()]
 assert '4190800B' in (s/('package-'+name+'.log')).read_text()
result={'corpus':oracle,'variants':variants,'modulation':mod,'modulation_images':{f:artifact(f) for t in ['both','preceding'] for f in ['modulation-'+t+'.elf','modulation-'+t+'.wasm']},'wasm_transform_stack_equal':True,'board':board,'paired_time':read('paired-results.json'),'contract':{t:artifact('contract-'+t) for t in ('previous','fixed','lanes','initial-witness','lean')}}
(s/'results.json').write_text(json.dumps(result,indent=2)+'\n')
