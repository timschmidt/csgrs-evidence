use std::io::{self, BufRead, Write};
use alumina_foc::{AlphaBeta, FocError, Q30, Q30Interval as I, inverse_clarke, space_vector_modulate};
fn print_result<const N:usize>(out:&mut impl Write,r:Result<[I;N],FocError>){
    match r {
        Ok(lanes)=>for x in lanes { write!(out,"{} {} ",x.lower().bits(),x.upper().bits()).unwrap(); },
        Err(FocError::Range)=>write!(out,"range").unwrap(),
        Err(FocError::ModulationRange)=>write!(out,"modulation").unwrap(),
        Err(e)=>panic!("{e:?}"),
    }
}
fn main(){
    let mut out=io::BufWriter::new(io::stdout().lock());
    for line in io::stdin().lock().lines(){
        let line=line.unwrap();
        let raw:Vec<i32>=line.split_ascii_whitespace().map(|x|x.parse().unwrap()).collect();
        let [a,b,c,d,l]=raw[..] else {panic!()};
        let lane=|x,y| I::new(Q30::from_bits(x),Q30::from_bits(y)).unwrap();
        let input=AlphaBeta{alpha:lane(a,b),beta:lane(c,d)};
        print_result(&mut out,inverse_clarke(input).map(|p|[p.a,p.b,p.c]));
        write!(out,"|").unwrap();
        print_result(&mut out,space_vector_modulate(input,Q30::from_bits(l)).map(|m|{
            let p=m.centered_phases; let d=m.duties; [m.common_mode,p.a,p.b,p.c,d.a,d.b,d.c]
        }));
        writeln!(out).unwrap();
    }
}
