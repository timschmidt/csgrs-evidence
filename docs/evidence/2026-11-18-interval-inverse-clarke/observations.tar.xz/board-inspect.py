from pathlib import Path
from elftools.elf.elffile import ELFFile
import json,hashlib,subprocess as sp
s=Path(__file__).parent
results={}
for name in ['preceding','positive_divide','both']:
 path=s/(name+'-mks.elf')
 with path.open('rb') as f:
    e=ELFFile(f);sections={}
    for sec in e.iter_sections():
        if not sec['sh_flags']&2:continue
        sections[sec.name]={'bytes':sec['sh_size'],'address':sec['sh_addr'],'flags':sec['sh_flags'],'type':sec['sh_type']}
        if sec['sh_type']!='SHT_NOBITS':sections[sec.name]['sha256']=hashlib.sha256(sec.data()).hexdigest()
    relevant=[(v.name,v['st_size']) for v in e.get_section_by_name('.symtab').iter_symbols() if any(k in v.name for k in ['inverse_clarke','space_vector_modulate'])]
 log=s/('package-'+name+'.log')
 with log.open('w') as f:
    p=sp.run([s/'espflash','save-image','--chip','esp32','--flash-size','4mb','--merge','--skip-padding',path,s/(name+'-mks.bin')],cwd=s/'alumina-firmware',stdout=f,stderr=sp.STDOUT)
 results[name]={'file':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sections':sections,'relevant_symbols':relevant,'package_exit':p.returncode,'executable':sum(v['bytes'] for v in sections.values() if v['flags']&4),'file_allocated':sum(v['bytes'] for v in sections.values() if v['type']!='SHT_NOBITS')}
(s/'board-results.json').write_text(json.dumps(results,indent=2)+'\n')
for k,v in results.items():print(k,v['file'],v['executable'],v['file_allocated'],v['package_exit'],v['relevant_symbols'])
