from pathlib import Path
import subprocess as sp,os
s=Path(__file__).parent;fw=s/'alumina-firmware';f=fw/'crates/alumina-foc/src/lib.rs'
old=f.read_text()
a='Q30Interval::HALF.checked_mul(value.alpha)?.checked_neg()?'
b='Q30Interval::HALF\n        .checked_mul(maximum.checked_add(minimum)?)?\n        .checked_neg()?'
insert='    /// Exact interval negation.'
assert old.count(a)==old.count(b)==old.count(insert)==1
new=old.replace(a,'value.alpha.negative_half()?').replace(b,'maximum.checked_add(minimum)?.negative_half()?')
new=new.replace(insert,'''    fn negative_half(self) -> Result<Self, FocError> {
        Self::from_fixed(self.fixed().div_integer(2))?.checked_neg()
    }

'''+insert)
try:
 f.write_text(new)
 (s/'both.patch').write_bytes(sp.check_output(['git','-C',fw,'diff','--','crates/alumina-foc/src/lib.rs']))
 with (s/'both-build.log').open('w') as out:
    for script in ['images.sh','corpus.sh']:sp.run(['bash',s/script,'both'],stdout=out,stderr=sp.STDOUT,check=True)
    for pkg,file,save in [('paired','libfoc_paired_measurement.so','both.so'),('bench','foc-inverse-completed','bench-both')]:
        sp.run(['cargo','+1.88.0','build','--release','--locked','--manifest-path',s/pkg/'Cargo.toml'],stdout=out,stderr=sp.STDOUT,check=True)
        (s/save).write_bytes((Path(os.environ['CARGO_TARGET_DIR'])/'release'/file).read_bytes());(s/save).chmod(0o755)
finally:f.write_text(old)
