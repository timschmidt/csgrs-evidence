use alumina_foc::{FocError,Q30,inverse_clarke,space_vector_modulate};
use interval_foc_conformance::samples::{self,Action};
use std::{hint::black_box,time::Instant};
fn main(){
    let inputs: Vec<_>=(0..165).map(samples::sample).collect();
    for r in 0..19 {
        for a in 0..4 {
            let begin=Instant::now(); let mut sum=0i64;
            for _ in 0..128 {
                for sample in &inputs {
                    let sample=black_box(sample);
                    let value=match a {
                        0=> i64::from(black_box(inverse_clarke(sample.stationary).unwrap()).c.lower().bits()),
                        1=> i64::from(black_box(space_vector_modulate(sample.stationary,Q30::ONE).unwrap()).duties.b.upper().bits()),
                        2=> match black_box(space_vector_modulate(sample.stationary,Q30::from_bits(1))) {Err(FocError::ModulationRange)=>-1,Ok(m)=>i64::from(m.duties.b.upper().bits()),Err(e)=>panic!("{e:?}")},
                        _=>black_box(samples::native(Action::Chain,*sample).unwrap()).digest(0xcbf29ce484222325) as i64,
                    };
                    sum=sum.wrapping_add(value);
                }
            }
            println!("{r} {a} {} {sum}",begin.elapsed().as_nanos());
        }
    }
}
