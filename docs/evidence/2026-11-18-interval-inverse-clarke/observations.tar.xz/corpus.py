from pathlib import Path
from collections import Counter
import subprocess as sp,sys,json,hashlib
from oracle import corpus,expected
s=Path(__file__).parent
def encoded(result):return result if isinstance(result,str) else ' '.join(str(n) for lane in result for n in lane)
def norm(result):return result if isinstance(result,str) else 'success'
cases=list(corpus());inputs=''.join(' '.join(map(str,(*a,*b,l)))+'\n' for a,b,l in cases)
rows=sp.check_output([sys.argv[2]],input=inputs,text=True).splitlines()
assert len(rows)==len(cases)
statuses=Counter()
for (a,b,l),row in zip(cases,rows):
    inv,mod=expected(a,b,l);actual=[part.strip() for part in row.split('|')]
    assert actual==[encoded(inv),encoded(mod)],((a,b,l),actual,(inv,mod))
    statuses[norm(inv)+'/'+norm(mod)]+=1
print(json.dumps({'cases':len(cases),'status':statuses,'fixture_sha256':hashlib.sha256(inputs.encode()).hexdigest(),'observations_sha256':hashlib.sha256(('\n'.join(rows)+'\n').encode()).hexdigest()}))
