set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/obs-target"
cargo +1.88.0 build --release --offline --manifest-path "$s/observer/Cargo.toml"
python3 -B "$s/corpus.py" "$1" "$CARGO_TARGET_DIR/release/inverse-clarke-observer" > "$s/$1-corpus.json"
