set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/target" CARGO_PROFILE_RELEASE_DEBUG=0
fw="$s/alumina-firmware"
p=crates/hyperlattice-interval/conformance/alumina-foc/wasm
cd "$s/csgrs"
git diff --exit-code -- "$p/lib.rs"
git -C "$fw" diff --exit-code -- crates/alumina-foc/src/lib.rs
trap 'git restore -- "$p/lib.rs"; git -C "$fw" restore -- crates/alumina-foc/src/lib.rs' EXIT
cat "$s/modulation.rs" >> "$p/lib.rs"
linker="$(rustc +1.88.0 --print sysroot)/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld"
for name in preceding both; do
    if test "$name" = both; then git -C "$fw" apply "$s/both.patch"; fi
    cargo +1.88.0 rustc --release --locked --lib --target thumbv7em-none-eabihf --manifest-path "$p/Cargo.toml" --crate-type staticlib
    "$linker" -flavor gnu --nmagic -Ttext=0x08000000 --gc-sections --strip-debug -e modulation_word "$CARGO_TARGET_DIR/thumbv7em-none-eabihf/release/libinterval_foc_wasm_consumer.a" -o "$s/modulation-$name.elf"
    cargo +1.88.0 build --release --locked --lib --target wasm32-unknown-unknown --manifest-path "$p/Cargo.toml"
    cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" "$s/modulation-$name.wasm"
done
