from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;root=Path.cwd();other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-inverse-clarke'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in s.iterdir():
 if p.is_file() and (p.suffix in ('.py','.c','.rs','.mjs','.sh','.patch','.log','.json','.txt') or p.name.startswith('timing-') or p.name in ('scope','fixture-revision','review-revision')):
    if p.name!='espflash-release.json':files[p.name]=p.read_bytes()
for name in ['observer','bench','paired','confirm','final']:
 for p in (s/name).rglob('*'):
    if p.is_file() and (p.suffix in ('.rs','.toml','.lock','.json','.sh','.py') or p.name.startswith('timing-')):
        files[str(p.relative_to(s))]=p.read_bytes()
for tag in ['preceding','divide','multiply','affine','staged_fixed','positive_divide','both','modulation-preceding','modulation-both']:
 for suffix in ['.elf','.wasm']:
    p=s/(tag+suffix);files[p.name]=p.read_bytes()
for n in ['review-tests.log','results.json','mutation-retained.log','retained-simulator.log','review-revision','modulation-thumb-both.json','final/calls.json','csgrs-fmt.log']:
 assert n in files
assert files['fixture-revision'].decode().strip()==git(root.parent/'alumina-firmware','rev-parse','HEAD').decode().strip()
files['commands.txt']=sp.check_output(['rustc','+1.88.0','-vV'])+sp.check_output(['node','--version'])+sp.check_output([s/'espflash','--version'])
archive=s/'record';archive.mkdir()
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
digests={k:sha(v) for k,v in sorted(files.items())}
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive inverse Clarke and downstream modulation qualification')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1])
