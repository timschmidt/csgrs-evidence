set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/target" CARGO_PROFILE_RELEASE_DEBUG=0
cd "$s/csgrs"
p=crates/hyperlattice-interval/conformance/alumina-foc
linker="$(rustc +1.88.0 --print sysroot)/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld"
cargo +1.88.0 rustc --release --locked --lib --target thumbv7em-none-eabihf --manifest-path "$p/wasm/Cargo.toml" --crate-type staticlib
"$linker" -flavor gnu --nmagic -Ttext=0x08000000 --gc-sections --strip-debug -e conformance_probe -u range_probe -u output_word "$CARGO_TARGET_DIR/thumbv7em-none-eabihf/release/libinterval_foc_wasm_consumer.a" -o "$s/$1.elf"
cargo +1.88.0 build --release --locked --lib --target wasm32-unknown-unknown --manifest-path "$p/wasm/Cargo.toml"
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" "$s/$1.wasm"
node "$p/wasm/check.mjs" "$s/$1.wasm"
cargo +1.88.0 build --release --locked --bins --manifest-path "$p/Cargo.toml"
for t in cost native-probe shared-probe; do cp "$CARGO_TARGET_DIR/release/$t" "$s/$1-$t"; done
