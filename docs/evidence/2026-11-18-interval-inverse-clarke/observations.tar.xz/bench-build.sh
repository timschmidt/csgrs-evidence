set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/host-target"
fw="$s/alumina-firmware"
git -C "$fw" diff --exit-code -- crates/alumina-foc/src/lib.rs
trap 'git -C "$fw" restore -- crates/alumina-foc/src/lib.rs' EXIT
for mode in preceding positive_divide; do
    if test "$mode" = positive_divide; then git -C "$fw" apply "$s/positive_divide.patch"; fi
    cargo +1.88.0 build --release --offline --manifest-path "$s/bench/Cargo.toml"
    cp "$CARGO_TARGET_DIR/release/foc-inverse-completed" "$s/bench-$mode"
done
