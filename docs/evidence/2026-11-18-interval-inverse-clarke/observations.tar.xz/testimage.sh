set -eu
s=/dev/shm/interval-inverse-clarke
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/fwtarget" CARGO_PROFILE_RELEASE_DEBUG=0
cd "$s/alumina-firmware"
cargo +1.88.0 test --release --locked -p alumina-foc --test q30_contract --no-run --message-format=json-render-diagnostics > "$s/test-$1.ndjson"
bin=$(jq -rs '[.[]|select(.reason=="compiler-artifact" and .target.name=="q30_contract" and .executable!=null)|.executable]|if length==1 then .[0] else error("test executable") end' "$s/test-$1.ndjson")
cp "$bin" "$s/contract-$1"
"$bin" > "$s/test-$1.log"
