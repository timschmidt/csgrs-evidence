from itertools import combinations_with_replacement
from collections import Counter
from pathlib import Path
from oracle import corpus,expected
import json
s=Path(__file__).parent
edges=sorted(set(n for a,b,l in corpus() for n in a))
limits=[-1,0,1,3,4,1<<30,2**31-1]
def ix(x):return edges.index(x[0])*11+edges.index(x[1])
calls=[]; types=[]
for a,b,l in corpus():
    x=expected(a,b,l)[1]; i=limits.index(l)*8
    success=not isinstance(x,str)
    calls.append(['modulation_word',[ix(a),ix(b),i+7],str(0 if success else {'range':1,'modulation':2}[x])])
    types.append('success-tag' if success else x)
    if success:
        for j,(lo,hi) in enumerate(x):
            calls.append(['modulation_word',[ix(a),ix(b),i+j],str((lo%2**32)+(hi%2**32)*2**32)])
            types.append('success-word')
(s/'modulation-calls-input.json').write_text(json.dumps(calls,separators=(',',':')))
(s/'modulation-types.json').write_text(json.dumps(types,separators=(',',':')))
print(Counter(types))
