
#[unsafe(no_mangle)]
pub extern "C" fn modulation_word(a: u32, b: u32, selector: u32) -> u64 {
    const EDGES: [i32;11] = [i32::MIN,i32::MIN+1,-(1<<30),-3,-1,0,1,3,1<<30,i32::MAX-1,i32::MAX];
    let lane = |packed:u32| Q30Interval::new(
        Q30::from_bits(EDGES[(packed/11) as usize]),
        Q30::from_bits(EDGES[(packed%11) as usize])
    ).unwrap();
    let limits = [-1,0,1,3,4,1<<30,i32::MAX];
    let value = AlphaBeta { alpha:lane(a), beta:lane(b) };
    match alumina_foc::space_vector_modulate(value,Q30::from_bits(limits[(selector/8) as usize])) {
        Ok(result) => {
            if selector%8 == 7 { return 0; }
            let c=result.centered_phases;
            let d=result.duties;
            let lanes=[result.common_mode,c.a,c.b,c.c,d.a,d.b,d.c];
            let x=lanes[(selector%8) as usize];
            u64::from(x.lower().bits() as u32) | (u64::from(x.upper().bits() as u32)<<32)
        }
        Err(FocError::Range) => 1,
        Err(FocError::ModulationRange) => 2,
        Err(_) => 3
    }
}
