from pathlib import Path
import statistics as st,json
s=Path(__file__).parent
reports={}
for name,target in [('paired','positive_divide'),('both','both')]:
  reports[target]={}
  for cpu in [4,5,14,15]:
    for a in range(4):
      details=[]
      for p in sorted(s.glob(f'{name}-{cpu}-*.log')):
        rows=[x.split() for x in p.read_text().splitlines()]
        pairs=[(int(x),int(y)) for _,k,x,y in rows if int(k)==a]
        if len(pairs)!=24:continue
        prev,cur=map(st.median,zip(*pairs))
        details.append({'prev_ns':prev,'candidate_ns':cur,'change_pct':100*(cur/prev-1)})
      if len(details)==4:
        pct=round(st.median(v['change_pct'] for v in details),3)
        reports[target][f'{cpu}/{a}']={'percent':pct,'processes':details}
    print(target,cpu,[reports[target].get(f'{cpu}/{a}',{}).get('percent') for a in range(4)])
(s/'paired-results.json').write_text(json.dumps(reports,indent=2)+'\n')
