from pathlib import Path
import subprocess as sp
s=Path(__file__).parent;fw=s/'alumina-firmware';rel='crates/alumina-foc/src/lib.rs';p=fw/rel
baseline=sp.check_output(['git','-C',fw,'show','HEAD:'+rel],text=True)
old='Q30Interval::HALF.checked_mul(value.alpha)?.checked_neg()?'
variants={
'positive_divide': 'Q30Interval::from_fixed(value.alpha.fixed().div_integer(2))?.checked_neg()?',
'staged_fixed': 'Q30Interval::from_fixed(Q30Interval::HALF.fixed().checked_mul(&value.alpha.fixed()).and_then(|half| half.checked_neg()))?',
}
try:
 for name,formula in variants.items():
    assert baseline.count(old)==1;p.write_text(baseline.replace(old,formula))
    (s/(name+'.patch')).write_bytes(sp.check_output(['git','-C',fw,'diff','--',rel]))
    with (s/(name+'-observer.log')).open('w') as f:sp.run(['bash',s/'corpus.sh',name],stdout=f,stderr=sp.STDOUT,check=True)
    with (s/(name+'-build.log')).open('w') as f:sp.run(['bash',s/'images.sh',name],stdout=f,stderr=sp.STDOUT,check=True)
finally:p.write_text(baseline)
