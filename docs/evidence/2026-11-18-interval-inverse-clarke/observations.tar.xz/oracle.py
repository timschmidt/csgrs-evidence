from itertools import product, combinations_with_replacement
from math import isqrt
from fractions import Fraction
S=1<<30
MIN=-(1<<31);MAX=(1<<31)-1
R=isqrt(3*S*S//4)
def on_grid(lo,hi):
    if not MIN<=lo<=hi<=MAX:raise OverflowError()
    return lo,hi
def outward(nums,den):
    return min(nums)//den,-(-max(nums)//den)
def half(x):return outward([-n for n in x],2)
def phases(a,b):
    # Keep the separate rounding of the two terms. Bracket the irrational factor on Q30.
    h=half(a);k=outward([x*y for x,y in product(b,(R,R+1))],S)
    return (a,on_grid(h[0]+k[0],h[1]+k[1]),on_grid(h[0]-k[1],h[1]-k[0]))
def modulation(ps,lim):
    # Compute independent interval images of the two order statistics at every vertex.
    points=list(product(*ps))
    maxima=list(map(max,points));minima=list(map(min,points))
    m=half(on_grid(min(maxima)+min(minima),max(maxima)+max(minima)))
    centered=[on_grid(x[0]+m[0],x[1]+m[1]) for x in ps]
    if any(lo < -lim or hi > lim for lo,hi in centered):return 'modulation'
    duties=[outward([(n+lim)*S for n in x],2*lim) for x in centered]
    return [m,*centered,*duties]
def expected(a,b,l):
    try:ps=phases(a,b)
    except OverflowError:return 'range','modulation' if l<=0 else 'range'
    if l<=0:return ps,'modulation'
    try:return ps,modulation(ps,l)
    except OverflowError:return ps,'range'
def corpus():
    edges=[MIN,MIN+1,-S,-3,-1,0,1,3,S,MAX-1,MAX]
    intervals=list(combinations_with_replacement(edges,2))
    for a,b,lim in product(intervals,intervals,(-1,0,1,3,4,S,MAX)):
        yield a,b,lim
if __name__=='__main__':
    for a,b,l in [((1,3),(0,0),4),((-3,-1),(0,0),4),((-3,1),(-1,3),10),((MIN,MIN),(0,0),MAX),((1,1),(1,1),3),((0,0),(MIN,MAX),MAX),((MIN,MIN),(MAX,MAX),MAX)]:
        print(a,b,l,expected(a,b,l))
