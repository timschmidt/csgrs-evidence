from pathlib import Path
from collections import defaultdict
import ctypes as ct,importlib.util,json,sys
s=Path(__file__).parent
calls=json.loads((s/'modulation-calls-input.json').read_text())
types=json.loads((s/'modulation-types.json').read_text())
tag=sys.argv[1]; mode=sys.argv[2];result=defaultdict(dict)
if mode=='thumb':
    # Reuse the measured Cortex-M4 runner and the ABI/memory verifier.
    src=(s/'instructions.py').read_text().split('with (s/(tag+')[0]
    exec(src)
    m.CALLS={'modulation_word':len(calls)}
    segments,entries=m.load_image(s/('modulation-'+tag+'.elf'))
    cpu=m.Uc(m.UC_ARCH_ARM,m.UC_MODE_THUMB|m.UC_MODE_MCLASS);cpu.ctl_set_cpu_model(m.UC_CPU_ARM_CORTEX_M4)
    cpu.mem_map(m.FLASH,m.FLASH_BYTES,m.UC_PROT_READ|m.UC_PROT_EXEC)
    cpu.mem_map(m.RAM+4096,4096,m.UC_PROT_READ|m.UC_PROT_WRITE)
    for addr,data in segments:cpu.mem_write(addr,data)
    cpu.reg_write(m.UC_ARM_REG_SP,m.STACK_TOP);measure=Measure()
    assert probe.install(cpu._uch,ct.byref(measure))==0
else:
    import wasmtime as wt
    cfg=wt.Config();cfg.consume_fuel=True;e=wt.Engine(cfg);store=wt.Store(e)
    mod=wt.Module.from_file(e,str(s/('modulation-'+tag+'.wasm')));assert not mod.imports
    store.set_fuel(1000000);fn=wt.Instance(store,mod,[]).exports(store)['modulation_word']
rows=[]
for (name,args,expected),kind in zip(calls,types,strict=True):
    if mode=='thumb':
        measure.minimum_sp=m.STACK_TOP;measure.instructions=0
        cpu.reg_write_batch([*zip(m.ARGUMENTS,args),(m.UC_ARM_REG_LR,m.RETURN|1)])
        cpu.emu_start(entries[name],m.RETURN,count=1000000)
        pc,sp,lo,hi=cpu.reg_read_batch([m.UC_ARM_REG_PC,m.UC_ARM_REG_SP,m.UC_ARM_REG_R0,m.UC_ARM_REG_R1])
        assert pc==m.RETURN and sp==m.STACK_TOP and 0<measure.instructions<1000000
        actual=lo+(hi<<32);work=measure.instructions;stack=m.STACK_TOP-measure.minimum_sp
    else:
        store.set_fuel(1000000);actual=fn(store,*args)%2**64;work=1000000-store.get_fuel();stack=None
    assert actual==int(expected),(args,actual,expected)
    rows.append([work,stack])
(s/('modulation-'+mode+'-'+tag+'.json')).write_text(json.dumps(rows,separators=(',',':'))+'\n')
print(mode,tag,len(rows))
