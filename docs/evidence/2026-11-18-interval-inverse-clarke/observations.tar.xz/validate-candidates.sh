set -eu
s=/dev/shm/interval-inverse-clarke; fw="$s/alumina-firmware"
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/fwnegative" CARGO_PROFILE_RELEASE_DEBUG=0
p=crates/alumina-foc/src/lib.rs
git -C "$fw" diff --exit-code -- "$p"
trap 'git -C "$fw" restore -- "$p"' EXIT
for tag in divide multiply affine positive_divide both; do
    git -C "$fw" apply "$s/$tag.patch"
    bash "$s/corpus.sh" "$tag" >> "$s/extra-corpus.log" 2>&1
    if test "$tag" = positive_divide || test "$tag" = both; then
        (cd "$fw" && cargo +1.88.0 test --release --locked -p alumina-foc -p alumina-sim) > "$s/$tag-sim-tests.log" 2>&1
    fi
    git -C "$fw" restore -- "$p"
done
