from pathlib import Path
import json,statistics as st
s=Path(__file__).parent;obs={}
for cpu in [4,5,14,15]:
 for a in range(4):
    d={}; sums=set()
    for name in ['preceding','positive_divide']:
        med=[]
        for f in sorted(s.glob(f'timing-{cpu}-*-{name}')):
            rows=[l.split() for l in f.read_text().splitlines()]
            v=[int(t)/21120 for i,k,t,z in rows if int(k)==a and int(i)>=3]
            assert len(v)==16
            sums.update(z for i,k,t,z in rows if int(k)==a)
            med.append(st.median(v))
        assert len(med)==4;d[name]=med
    assert len(sums)==1
    d['percent']=round(100*(st.median(d['positive_divide'])/st.median(d['preceding'])-1),3)
    obs[f'{cpu}/{a}']=d;print(cpu,a,d['percent'])
(s/'timings.json').write_text(json.dumps(obs,indent=2)+'\n')
