set -eu
s=/dev/shm/interval-inverse-clarke/confirm
core=$1
if test "$core" = 14 || test "$core" = 4; then order=(preceding positive_divide positive_divide preceding positive_divide preceding preceding positive_divide); else order=(positive_divide preceding preceding positive_divide preceding positive_divide positive_divide preceding); fi
for i in "${!order[@]}"; do t=${order[$i]}; taskset -c "$core" "$s/bench-$t" > "$s/timing-$core-$i-$t"; done
