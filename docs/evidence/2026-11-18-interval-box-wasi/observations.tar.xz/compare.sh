set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/target"
cd "$s/repo"
for stage in fixed preceding direct; do
 case $stage in
 fixed) git switch --detach c9f1f9ac5 ;;
 preceding) git switch --detach "$(cat "$s/preceding")"
 git apply "$s/witness.patch"
 if cargo test --locked -p hyperlattice-interval --features dyadic --test dyadic_subdivision >"$s/gap.log" 2>&1; then exit 1; fi
 rg -q 'test result: FAILED' "$s/gap.log" ;;
 direct) git apply "$s/box.patch"
 cargo test --locked -p hyperlattice-interval --features dyadic --test dyadic_subdivision >"$s/repaired.log" 2>&1 ;;
 esac
 cargo build --release --locked -p hyperdynamics --features reachability --example reachability > "$s/$stage-build.log" 2>&1
 cp "$CARGO_TARGET_DIR/release/examples/reachability" "$s/$stage.elf"
 "$s/$stage.elf" >"$s/$stage.out"
done
