set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/observed" CARGO_BUILD_JOBS=6
cd "$s/repo"
git restore crates/hyperlattice-interval/tests/dyadic_subdivision.rs
src=crates/hyperlattice-interval/src/subdivision.rs
for n in preceding direct nonempty; do
 git restore "$src"
 case $n in direct) git apply "$s/box.patch" ;; nonempty) git apply "$s/nonempty.patch" ;; esac
 for p in memory cover-probe; do
  if [ "$n" = preceding ]; then
   cargo metadata --offline --manifest-path "$s/$p/Cargo.toml" --format-version 1 >/dev/null
  fi
  cargo build --locked --release --manifest-path "$s/$p/Cargo.toml" > "$s/$n-$p-build.log" 2>&1
 done
 for i in 0 1 2; do "$CARGO_TARGET_DIR/release/split-lifetime" "$i"; done > "$s/$n-lifetime.txt"
 "$CARGO_TARGET_DIR/release/subdivision" > "$s/$n-covers.txt"
done
git restore "$src"
