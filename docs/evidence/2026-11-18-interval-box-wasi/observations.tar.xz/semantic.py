from pathlib import Path
import json
s=Path(__file__).parent
result={}
for n in ['preceding','direct','nonempty']:
    lines=(s/(n+'-covers.txt')).read_text().splitlines()
    life=(s/(n+'-lifetime.txt')).read_text().splitlines()
    semantic=[l for l in lines if l.startswith(('ROW|','DEFINITION|'))]
    if n=='preceding':base_semantic=semantic
    assert semantic==base_semantic
    work={f.split('|')[1]:int(f.split('|')[2]) for f in lines if f.startswith('ARITH|')}
    stack=[max(int(l.split('|')[-1]) for l in life if l.startswith('STACK|'+str(i)+'|')) for i in range(3)]
    allocations={l.split('|')[1]:list(map(int,l.split('|')[2:])) for l in lines if l.startswith('ALLOC|')}
    assert all(row[-1]==0 for row in allocations.values())
    assert all(l.endswith(', 0)') for l in life if l.startswith('HEAP|'))
    if n=='preceding':base_stack,base_alloc=stack,allocations
    assert stack==base_stack and {k:v[-2:] for k,v in allocations.items()}=={k:v[-2:] for k,v in base_alloc.items()}
    result[n]=dict(work=work,stack_bytes=stack,allocations=allocations)
(s/'complete-covers.json').write_text(json.dumps(result,indent=2)+'\n')
