set -eu
s=/dev/shm/interval-box-requalification
root=/mnt/development/csgrs
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/witness-target"
cd "$s/repo"
p=crates/hyperlattice-interval/tests/dyadic_subdivision.rs
git restore "$p" crates/hypersdf/tests/enclosure_subdivision.rs
for stage in fixed preceding mirrored; do
 case $stage in
 fixed) git switch --detach c9f1f9ac5 ;;
 preceding) git switch --detach "$(cat "$s/preceding")" ;;
 mirrored) python3 "$s/witness.py" "$PWD"; git diff -- "$p" > "$s/mirrored.patch";;
 esac
 cargo test --locked --release -p hyperlattice-interval --all-features --test dyadic_subdivision --message-format=json >"$s/manifest-$stage.jsonl" 2>"$s/mirror-build-$stage.log"
 file=$(python3 - "$s/manifest-$stage.jsonl" <<'PY'
import json,sys
for l in open(sys.argv[1]):
 if l.startswith('{') and (j:=json.loads(l)).get('executable'):print(j['executable'])
PY
 )
 cp "$file" "$s/$stage-test.elf"
done
src=crates/hyperlattice-interval/src/subdivision.rs
python3 - "$src" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text();old='Ok(Some([Self::new(left)?, Self::new(right)?]))'
assert s.count(old)==1
p.write_text(s.replace(old,'let mut children = [Self::new(left)?, Self::new(right)?];\n        if axis != 0 { children.swap(0, 1); }\n        Ok(Some(children))'))
PY
git diff -- "$src" > "$s/reversed.patch"
git restore "$p"
cargo test --locked --release -p hyperlattice-interval --all-features --lib --tests > "$s/reversed-before.log" 2>&1
git apply "$s/mirrored.patch"
if cargo test --locked --release -p hyperlattice-interval --all-features --test dyadic_subdivision >"$s/reversed-after.log" 2>&1; then exit 1; fi
rg -q 'exact_closed_partition_and_first_axis_geometry .* FAILED' "$s/reversed-after.log"
git restore "$src"
