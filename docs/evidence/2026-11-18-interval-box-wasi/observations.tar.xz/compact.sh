set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
cd "$s/oracle"
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_TARGET_DIR="$s/compact" CARGO_BUILD_JOBS=5
file=crates/hyperlattice-interval/tests/midpoint_radius.rs
for phase in preceding candidate; do
 if [ "$phase" = preceding ]; then git restore "$file"; else cp "/mnt/development/csgrs/$file" "$file"; fi
 cargo +1.95.0 test --locked --release --config 'profile.release.opt-level="z"' --config 'profile.release.lto="fat"' --config 'profile.release.codegen-units=1' -p hyperlattice-interval --target wasm32-wasip1 --features fixed,dyadic,float-enclosure-wasip1 --test midpoint_radius --no-run --message-format=json > "$s/compact-$phase.jsonl" 2>"$s/compact-$phase.log"
 f=$(python3 - "$s/compact-$phase.jsonl" <<'PY'
import sys,json
for l in open(sys.argv[1]):
 if (r:=json.loads(l)).get('executable'):print(r['executable'])
PY
 )
 cp "$f" "$s/compact-$phase.wasm"
 node /mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$f" --test-threads=1 --nocapture >"$s/compact-$phase-run.log" 2>&1
done
