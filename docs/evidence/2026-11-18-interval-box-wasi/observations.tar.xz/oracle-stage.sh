set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
v=$1
stage=$2
cd "$s/oracle"
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_TARGET_DIR="$s/oracle-$v" CARGO_BUILD_JOBS=4
features=fixed,dyadic,float-enclosure-wasip1
if [ "$stage" = fixed ]; then features=fixed,dyadic,float-enclosure; fi
cargo "+$v" test --locked --release -p hyperlattice-interval --no-default-features --features "$features" --target wasm32-wasip1 --test midpoint_radius --no-run --message-format=json >"$s/oracle-$stage-$v.jsonl" 2>"$s/oracle-$stage-$v.log"
f=$(python3 - "$s/oracle-$stage-$v.jsonl" <<'PY'
import sys,json
for l in open(sys.argv[1]):
 if (r:=json.loads(l)).get('executable'):print(r['executable'])
PY
)
cp "$f" "$s/$stage-$v-midpoint.wasm"
node /mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$f" --list >"$s/oracle-list-$stage-$v.log" 2>&1
if [ "$stage" = candidate ]; then node /mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$f" --test-threads=1 --nocapture > "$s/oracle-run-$v.log" 2>&1; fi
if [ "$v" = 1.95.0 ]; then
 cargo "+$v" test --locked --release -p hyperlattice-interval --all-features --test midpoint_radius --no-run --message-format=json > "$s/oracle-host-$stage.jsonl" 2>"$s/oracle-host-$stage.log"
 f=$(python3 - "$s/oracle-host-$stage.jsonl" <<'PY'
import sys,json
for l in open(sys.argv[1]):
 if (r:=json.loads(l)).get('executable'):print(r['executable'])
PY
 )
 cp "$f" "$s/host-$stage.elf"
 "$f" >"$s/oracle-host-run-$stage.log"
fi
