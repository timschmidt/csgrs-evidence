set -eu
s=/dev/shm/interval-box-requalification
cd "$s/oracle"
for stage in fixed preceding candidate; do
 case $stage in
 preceding) git switch --detach "$(cat "$s/preceding")" ;;
 candidate) cp /mnt/development/csgrs/crates/hyperlattice-interval/tests/midpoint_radius.rs crates/hyperlattice-interval/tests/ ;;
 esac
 pids=""
 for v in 1.88.0 1.95.0 stable; do bash "$s/oracle-stage.sh" "$v" "$stage" & pids="$pids $!"; done
 rc=0
 for p in $pids; do wait "$p" || rc=1; done
 test "$rc" -eq 0
done
