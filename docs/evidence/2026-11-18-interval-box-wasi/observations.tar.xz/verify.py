from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
s=Path(__file__).parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def tests(p):
    t=p.read_text()
    names=Counter(re.findall(r'^test (.+?) \.\.\. ok$',t,re.M))
    passed=sum(map(int,re.findall(r'^test result: ok\. (\d+) passed;',t,re.M)))
    assert passed and passed==sum(names.values()),p
    return names
report={}
for version in ['1.88.0','1.95.0','stable']:
    before=s/('old-'+version)
    after=s/('final-'+version)
    a,b=load(before/'report.json'),load(after/'report.json')
    groups=b.pop('lattice_guest_tests')
    assert a==b,(version,[k for k in a if a[k]!=b.get(k)])
    assert groups=={'arithmetic':60,'replay':3,'shape_replay':2}
    inventories={}
    for g,n in groups.items():
        hm=tests(s/f'host-{version}-{g}.log')
        gm=tests(after/f'wasi-lattice-{g}.log')
        full=tests(s/('extended-'+version)/f'wasi-lattice-{g}.log')
        omitted=Counter({'float_decomposition_and_reconstruction':1}) if g=='arithmetic' else Counter()
        assert full==hm and gm+omitted==hm and sum(gm.values())==n,(version,g,gm-hm,hm-gm)
        inventories[g]=dict(sorted(gm.items()))
    images={p.name:sha(p) for p in after.glob('*.wasm')}
    assert images=={p.name:sha(p) for p in before.glob('*.wasm')}
    assert len(images)==(4 if version=='1.88.0' else 5)
    report[version]={'tests':groups,'names':inventories,'images':images,'compiler':(after/'compiler.log').read_text().strip()}
a=load(s/'final-bare/report.json')
old=Path('/dev/shm/interval-lattice-coverage/wasm-bare/report.json')
assert a==load(old)
report['bare_1.95.0']=dict(report_equal=True,sha256=sha(s/'final-bare/report.json'))
for n in ['direct','nonempty']:
    assert (s/(n+'.out')).read_bytes()==(s/'preceding.out').read_bytes()
    assert '5 passed' in (s/('repaired.log' if n=='direct' else 'nonempty-test.log')).read_text()
    assert '1 passed' in (s/('sdf-'+n+'.log')).read_text()
    fails=load(s/'size-result.json')['failed'][n]
    assert set(fails)=={'functions','.relro_padding'}
assert 'Scalar(WorkExhausted)' in (s/'gap.log').read_text()
assert 'WorkExhausted' in (s/'sdf-gap.log').read_text()
assert 'Scalar(WorkExhausted)' in (s/'fail-guest-uncaptured.log').read_text() and 'RuntimeError: unreachable' in (s/'fail-guest-uncaptured.log').read_text()
assert (s/'exit23.log').read_text().splitlines()[-1]=='23'
assert tests(s/'reversed-before.log').total()==93
for tag in ['after','retry']: assert 'test result: FAILED' in (s/f'reversed-{tag}.log').read_text()
assert load(s/'all-witness-sizes.json')['failed']['mirrored'] and load(s/'all-witness-sizes.json')['failed']['retry']
(s/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
print('Validated 65 guest cases per compiler against their 66 native cases and the full 66-case experimental run, 14 byte-identical Preview 1 client images, unchanged bare report, two failure controls, and candidate gate outcomes.')
