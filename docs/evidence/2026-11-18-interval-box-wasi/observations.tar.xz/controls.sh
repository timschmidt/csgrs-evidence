set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_BUILD_JOBS=3
for v in 1.88.0 1.95.0 stable; do
 python3 "$s/old-driver.py" --toolchain "$v" --target wasm32-wasip1 --output "$s/old-$v" > "$s/old-$v.log" 2>&1
done
