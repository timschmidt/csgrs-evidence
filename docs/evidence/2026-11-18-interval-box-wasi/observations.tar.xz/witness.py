from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hyperlattice-interval/tests/dyadic_subdivision.rs'
t=p.read_text()
start=t.index('    let source =')
end=t.index('\n}',start)
body='''    for axis in 0..2 {
        let box_with_lane = |split_lane| {
            let mut lanes = [split_lane, d(9, 11, 0)];
            lanes.swap(0, axis);
            BoxN::new(lanes).unwrap()
        };
        let source = box_with_lane(d(-3, 4, 0));
        let [left, right] = source.bisect_axis(axis, &mut budget()).unwrap().unwrap();
        assert_eq!(left, box_with_lane(d(-6, 1, -1)));
        assert_eq!(right, box_with_lane(d(1, 8, -1)));
        assert_eq!(left.hull(&right, &mut budget()).unwrap(), source);
        assert_eq!(
            left.intersection(&right, &mut budget()).unwrap(),
            box_with_lane(d(1, 1, -1))
        );
        assert!(left.subset_of(&source, &mut budget()).unwrap());
        assert!(right.subset_of(&source, &mut budget()).unwrap());
    }'''
p.write_text(t[:start]+body+t[end:])
