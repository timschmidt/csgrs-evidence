from pathlib import Path
import subprocess
root=Path.cwd()
path='scripts/check_interval_wasm.py'
previous=(Path(__file__).parent/'preceding').read_text().strip()
code=subprocess.check_output(['git','show',previous+':'+path],text=True)
exec(compile(code,str(root/path),'exec'),{'__name__':'__main__','__file__':str(root/path)})
