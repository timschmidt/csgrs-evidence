set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/witness-target"
cd "$s/repo"
p=crates/hyperlattice-interval/tests/dyadic_subdivision.rs
git restore "$p"
python3 - "$p" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);t=p.read_text();a='    assert!(source.bisect_axis(1, &mut budget()).unwrap().is_some());'
assert t.count(a)==1
p.write_text(t.replace(a,'''    let [left, right] = source.bisect_axis(1, &mut budget()).unwrap().unwrap();
    assert_eq!(left, BoxN::new([d(-7, 9, 0), d(6, 11, -4)]).unwrap());
    assert_eq!(right, BoxN::new([d(-7, 9, 0), d(11, 16, -4)]).unwrap());'''))
PY
git diff -- "$p" > "$s/retry.patch"
cargo test --locked --release -p hyperlattice-interval --all-features --test dyadic_subdivision --message-format=json >"$s/manifest-retry.jsonl" 2>"$s/retry-build.log"
file=$(python3 - "$s/manifest-retry.jsonl" <<'PY'
import json,sys
for l in open(sys.argv[1]):
 if l.startswith('{') and (j:=json.loads(l)).get('executable'):print(j['executable'])
PY
)
cp "$file" "$s/test-sizes/retry.elf"
python3 "$s/test-sizes/metrics.py" fixed preceding mirrored retry
git apply "$s/reversed.patch"
if cargo test --locked --release -p hyperlattice-interval --all-features --test dyadic_subdivision >"$s/reversed-retry.log" 2>&1; then exit 1; fi
rg -q 'exhaustion_does_not_mutate_or_poison_retry .* FAILED' "$s/reversed-retry.log"
git restore crates/hyperlattice-interval/src/subdivision.rs
