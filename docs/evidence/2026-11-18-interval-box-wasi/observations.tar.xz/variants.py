from pathlib import Path
import subprocess,sys
s=Path(__file__).parent
p=Path('crates/hyperlattice-interval/src/subdivision.rs')
before=subprocess.check_output(['git','show','HEAD:'+str(p)],cwd=s/'repo',text=True)
# Exact nonsingleton bisection yields two nonempty scalar intervals. Every
# other lane comes from a nonempty canonical Cartesian product.
start=before.index('        let lane = &lanes[axis];')
end=before.index('\n    }',start)
body='''        let Some([left, right]) = lanes[axis].bisect(budget)? else {
            return Ok(None);
        };
        let mut child = |half| {
            let mut half = Some(half);
            let lanes = array_result(|i| {
                if i == axis {
                    Ok(half.take().expect("axis visited once"))
                } else {
                    lanes[i].checked_pow(1, budget)
                }
            })?;
            // Bisection and exact copies preserve nonempty scalar lanes.
            Ok::<_, hyperinterval::IntervalError>(Self { lanes: Some(lanes) })
        };
        Ok(Some([child(left)?, child(right)?]))'''
(s/'repo'/p).write_text(before[:start]+body+before[end:])
