set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/target"
cd "$s/repo"
src=crates/hyperlattice-interval/src/subdivision.rs
git restore "$src"
if cargo test --locked -p hypersdf --features enclosure-program --test enclosure_subdivision adaptive_cover_certifies_the_complete_dependency_cell >"$s/sdf-gap.log" 2>&1; then echo 'preceding SDF witness already passes'; fi
rg -q 'running 1 test' "$s/sdf-gap.log"
git apply "$s/box.patch"
cargo test --locked -p hypersdf --features enclosure-program --test enclosure_subdivision >"$s/sdf-direct.log" 2>&1
python3 "$s/variants.py"
git diff -- "$src" >"$s/nonempty.patch"
cargo test --locked -p hyperlattice-interval --features dyadic --test dyadic_subdivision >"$s/nonempty-test.log" 2>&1
cargo test --locked -p hypersdf --features enclosure-program --test enclosure_subdivision >"$s/sdf-nonempty.log" 2>&1
cargo build --release --locked -p hyperdynamics --features reachability --example reachability >"$s/nonempty-build.log" 2>&1
cp "$CARGO_TARGET_DIR/release/examples/reachability" "$s/nonempty.elf"
"$s/nonempty.elf" >"$s/nonempty.out"
cmp "$s/nonempty.out" "$s/preceding.out"
python3 "$s/metrics.py" fixed preceding direct nonempty
