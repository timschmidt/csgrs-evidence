import json,re,subprocess,sys,pathlib
s=pathlib.Path(__file__).parent
llvm=pathlib.Path(subprocess.check_output(['rustc','+1.95.0','--print','sysroot'],text=True).strip())/'lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-objdump'
all_rows={}
for v in ('1.88.0','1.95.0','stable'):
    rows={}
    for stage in ('fixed','preceding','candidate'):
        p=s/f'{stage}-{v}-midpoint.wasm'
        sec=subprocess.check_output([llvm,'-h',p],text=True)
        rows[stage]={'file':p.stat().st_size, 'code':int(re.search(r'^\s*\d+ CODE\s+([a-f0-9]+)',sec,re.M)[1],16)}
    rows['checks']={}
    for metric in ('file','code'):
        b,p,x=[rows[n][metric] for n in ('fixed','preceding','candidate')]
        d=max(0,x-p); cumul=max(0,p-b)+d
        rows['checks'][metric]={'incremental':d,'cumulative':cumul,'pass':d<=32768 and d<=p*0.06 and cumul<=49152 and cumul<=b*0.08}
    assert rows['candidate']['file']<=768*1024
    all_rows[v]=rows
print(json.dumps(all_rows,indent=2))
