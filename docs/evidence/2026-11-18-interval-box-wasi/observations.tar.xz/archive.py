from pathlib import Path
import subprocess as sp,hashlib,importlib.util,shutil,json,io,tarfile
s=Path(__file__).parent;root=Path('/mnt/development/csgrs');other=root.parent/'csgrs-evidence';record='docs/evidence/2026-11-18-interval-box-wasi'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
files={}
def add(p):files[str(p.relative_to(s))]=p.read_bytes()
for p in s.iterdir():
    if p.is_file() and (p.suffix in ('.sh','.py','.log','.txt','.patch','.out','.wat','.json') or p.name in ('scope','preceding','source-revision')):
        add(p)
for name in ('memory','cover-probe','empty-runner','standalone'):
    for p in (s/name).rglob('*'):
        if p.is_file():add(p)
for pattern in ('final-*','old-*','extended-*','empty-control'):
    for d in s.glob(pattern):
        if not d.is_dir():continue
        for p in d.iterdir():
            if p.is_file() and (p.name in ('commands.json','report.json') or p.suffix=='.log'):add(p)
assert 'No passing guest tests' in files['empty-control.log'].decode()
assert 'Validated 65' in files['verified.log'].decode()
assert git(root,'rev-parse','HEAD').decode().strip()==files['source-revision'].decode().strip()
files['node-version.txt']=sp.check_output(['node','--version'])
hashof=lambda b:hashlib.sha256(b).hexdigest()
digests={k:hashof(v) for k,v in sorted(files.items())}
archive=s/'record';archive.mkdir(exist_ok=True)
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
    for k,b in sorted(files.items()):
        i=tarfile.TarInfo(k);i.size=len(b);tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:
    assert {m.name:hashof(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not git(other,'status','--porcelain') and not (other/record).exists()
shutil.copytree(archive,other/record)
git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive WASI lattice test qualification and box subdivision remeasurements')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',root/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
row=m.manifest(str(other),rev)[1];idx=root/'docs/evidence-archive.tsv'
assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
(s/'evidence-revision').write_text(rev+'\n')
print(rev,row)
