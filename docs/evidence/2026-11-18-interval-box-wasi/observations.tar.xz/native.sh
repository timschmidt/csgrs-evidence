set -eu
s=/dev/shm/interval-box-requalification
. /dev/shm/interval-lattice-coverage/env
v=$1
export CARGO_TARGET_DIR="$s/native-$v" CARGO_BUILD_JOBS=4
for group in arithmetic replay shape_replay; do
 case $group in
 arithmetic) set -- --features fixed,dyadic,float-enclosure-wasip1 --lib --tests ;;
 *) set -- --features fixed,serde --test "$group" ;;
 esac
 cargo "+$v" test --locked --release -p hyperlattice-interval --no-default-features "$@" -- --test-threads=1 >"$s/host-$v-$group.log" 2>&1
done
