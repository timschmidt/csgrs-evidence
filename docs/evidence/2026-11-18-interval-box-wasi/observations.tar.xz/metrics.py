from pathlib import Path
import re,sys,subprocess,json,hashlib
s=Path(__file__).parent
def measure(p):
    def run(*cmd):return subprocess.check_output([*cmd,p],text=True)
    sections={}
    for line in run('readelf','-SW').splitlines():
        m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',line)
        if m and 'A' in m[3]:sections[m[1]]=int(m[2],16)
    regs=[]
    for line in run('readelf','-Ws').splitlines():
        r=line.split()
        if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit():
            start=int(r[1],16);regs.append((start,start+int(r[2])))
    hi=n=0
    for start,end in sorted(regs):
        n+=max(0,end-max(start,hi));hi=max(hi,end)
    return {**sections,'file':p.stat().st_size,'functions':n}
names=sys.argv[1:]
r={k:measure(s/(k+'.elf')) for k in names}
out={}
for k,v in r.items():
    if k in ['fixed','preceding']:continue
    out[k]={}
    for metric,x in v.items():
        b,p=r['fixed'][metric],r['preceding'][metric]
        cap=1024 if metric=='functions' else 4096
        percent=0.005 if metric=='functions' else 0.01
        extra=max(x-p,0)
        if extra>cap or extra>percent*p or (extra and (x-b>cap*4 or x-b>2*percent*b)):
            out[k][metric]=[b,p,x]
(s/'size-result.json').write_text(json.dumps({'bytes':r,'failed':out,'digests':{k:hashlib.sha256((s/(k+'.elf')).read_bytes()).hexdigest() for k in names}},indent=2)+'\n')
print(out)
