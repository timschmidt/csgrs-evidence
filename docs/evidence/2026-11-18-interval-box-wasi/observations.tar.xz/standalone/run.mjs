import { readFile } from "node:fs/promises";
import { WASI } from "node:wasi";
const [file, ...args] = process.argv.slice(2);
const wasi = new WASI({version:"preview1",args:[file,...args],env:{},preopens:{},returnOnExit:true});
const {instance} = await WebAssembly.instantiate(await readFile(file), {wasi_snapshot_preview1:wasi.wasiImport});
process.exitCode = wasi.start(instance);
