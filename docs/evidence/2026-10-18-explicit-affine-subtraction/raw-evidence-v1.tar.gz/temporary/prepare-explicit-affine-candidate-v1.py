"""Prepare the explicit-subtraction candidate after reproducing its baseline."""
import ast, difflib, json, sys
sys.dont_write_bytecode = True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs')
N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
W=N/'explicit-affine-control-v1'
sys.path.insert(0,str(N/'sign-cache-publication-control-v1'))
from validation_runner_v4_local import resources,reasons,sha
assert not reasons(resources())
baseline=json.loads((N/'explicit-affine-baseline-v1/result-v1.json').read_text())
assert baseline['summary']==[['FAILED','2','4','0','0','849']]
full=(N/'logs/explicit-affine-baseline-complete-unit-suite-v1/stdout').read_text()
assert 'test result: FAILED. 851 passed; 4 failed; 0 ignored' in full
algebra=(O/'crates/hyperreal/src/computable/node/algebra.rs').read_text()
start=algebra.index('        fn affine_offset_eq(left: &Computable, right: &Computable) -> bool {')
end=algebra.index('        fn commuted_add_pair_eq',start)
without=algebra[:start]+algebra[end:]
needle='    /// Add some other number to this number.\n'
assert without.count(needle)==1
helper='''    // Prove only cancellation of the symbolic terms. Ordinary sums retain
    // their shared operands and approximation caches. The zero-only caller
    // keeps addition's early offset check before comparing symbolic bases.
    pub(crate) fn rational_affine_difference(
        &self,
        other: &Self,
        zero_only: bool,
    ) -> Option<Rational> {
        let left_parts = self.rational_offset_parts(&mut 8);
        let right_parts = other.rational_offset_parts(&mut 8);
        let (left, left_scale, left_offset, right, right_scale, right_offset) =
            match (left_parts, right_parts) {
                (Some((left, scale, offset)), Some((right, other_scale, other_offset))) =>
                    (left, scale, offset, right, other_scale, other_offset),
                (Some((base, scale, offset)), None) =>
                    (base, scale, offset, other, Rational::one(), Rational::zero()),
                (None, Some((base, scale, offset))) =>
                    (self, Rational::one(), Rational::zero(), base, scale, offset),
                (None, None) => return None,
            };
        if zero_only && left_offset != right_offset {
            return None;
        }
        let same_term = if left_scale == right_scale {
            Self::internal_structural_eq(left, right)
        } else {
            Self::internal_structural_eq(
                &left.clone().multiply_rational(left_scale),
                &right.clone().multiply_rational(right_scale),
            )
        };
        same_term.then(|| left_offset - right_offset)
    }

'''
candidate=without.replace(needle,helper+needle)
needle='cancelled_pair.is_some_and(|(left, right)| affine_offset_eq(left, right))'
assert candidate.count(needle)==1
candidate=candidate.replace(needle,'cancelled_pair.is_some_and(|(left, right)| {\n            left.rational_affine_difference(right, true).is_some()\n        })')
addsub=(O/'crates/hyperreal/src/real/arithmetic/add_sub.rs').read_text()
needle='''        crate::trace_dispatch!("real", "sub", "generic-computable");
        let left = self.fold_ref();
        let right = other.fold_ref().negate();
        let computable = Computable::add(left, right);'''
assert addsub.count(needle)==1
changed=addsub.replace(needle,'''        let left = self.fold_ref();
        let right = other.fold_ref();
        if let Some(difference) = left.rational_affine_difference(&right, false) {
            crate::trace_dispatch!("real", "sub", "affine-offset-difference");
            return Self::Output::new(difference);
        }
        crate::trace_dispatch!("real", "sub", "generic-computable");
        let computable = Computable::add(left, right.negate());''')
for name,old,new in [('algebra_explicit_v1',algebra,candidate),('add_sub_explicit_v1',addsub,changed)]:
    p=W/(name+'.rs');assert not p.exists();p.write_text(new)
    p=W/(name+'.patch');assert not p.exists()
    p.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=name+'-baseline',tofile=name+'-candidate')))
s=(W/'baseline_v1.py').read_text()
s=s.replace('Compile the unchanged scalar implementation with missing owner acceptance tests.','Evaluate explicit affine subtraction while preserving ordinary addition.')
s=s.replace('explicit-affine-baseline','explicit-affine-candidate')
s=s.replace("overlays={O/'crates/hyperreal/src/real/mod.rs':W/'real_mod_tests_v1.rs'}","overlays={O/'crates/hyperreal/src/real/mod.rs':W/'real_mod_tests_v1.rs',O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_explicit_v1.rs',O/'crates/hyperreal/src/real/arithmetic/add_sub.rs':W/'add_sub_explicit_v1.rs'}")
s=s.replace("W/'real_mod_tests_v1.rs',W/'explicit_affine_tests_v1.rs'","W/'real_mod_tests_v1.rs',W/'explicit_affine_tests_v1.rs',W/'algebra_explicit_v1.rs',W/'add_sub_explicit_v1.rs'")
s=s.replace("assert len(rows)==1", "assert rows==[('ok','6','0','0','0','849')]")
s=s.replace("'runtime_source_changed':False,'candidate_prepared':False", "'main_runtime_source_changed':False,'isolated_runtime_source_changed':True,'candidate_prepared':True,'candidate_integrated':False,'runtime_admitted':False")
s=s.replace("'runtime_source_changed':False}),", "'main_runtime_source_changed':False,'isolated_runtime_source_changed':True}),")
s=s.replace("dump(R/'result-v1.json'", "assert 'test result: ok. 855 passed; 0 failed; 0 ignored' in (N/'logs/explicit-affine-candidate-complete-unit-suite-v1/stdout').read_text()\ndump(R/'result-v1.json'")
ast.parse(s)
p=W/'candidate_v1.py';assert not p.exists();p.write_text(s)
p=W/'candidate-preparation-v1.json';assert not p.exists()
p.write_text(json.dumps({'helper_sha256':sha(Path(__file__)),'candidate_sha256':{str(p):sha(p) for p in [W/'algebra_explicit_v1.rs',W/'add_sub_explicit_v1.rs',W/'candidate_v1.py']},'baseline_new_failures':4,'baseline_original_tests_passed':849,'production_source_changed':False,'scope':'Explicit Real subtraction; ordinary addition still accepts only its existing zero-cancellation cases.','resource_limits_unchanged':True},indent=2,sort_keys=True)+'\n')
print(json.dumps({'candidate_prepared':True,'production_source_changed':False}),flush=True)
