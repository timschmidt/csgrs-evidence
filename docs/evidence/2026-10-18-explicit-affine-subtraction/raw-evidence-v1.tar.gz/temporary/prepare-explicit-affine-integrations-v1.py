"""Prepare all Hyperreal integration tests against the explicit-subtraction candidate."""
import ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=N/'explicit-affine-control-v1'
p=W/'scalar-integration-contract-v1.md';assert not p.exists()
p.write_text("""# Scalar integration qualification

After the wider unit suites, compile the all-feature Hyperreal library and
its simple CLI in a fresh direct-rustc output directory. Compile and execute
every top-level Rust integration-test file under crates/hyperreal/tests,
unchanged, with the same complete feature configuration and pinned dependencies
as the all-feature unit build. Pin Cargo package metadata and the newly built
CLI path explicitly for tests using compile-time Cargo variables. No test file
may be omitted, modified, filtered, or silently skipped by this harness.

Retain all parent and nested process summaries and all failures. This is direct
compiler validation, not Cargo, documentation, minimum-compiler, Clippy or
distribution validation. Native full-workload and report gates remain open.
Every new command retains the original 1800-second suite/compile ceiling,
8-GiB child address-space limit, and unchanged storage/log baselines.
""")
script=r'''"""Run every unchanged scalar integration file in a pinned all-feature direct build."""
import gzip,json,os,re,sys,tomllib
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
units=json.loads((N/'explicit-affine-units-v1/result-v1.json').read_text());assert units['passed']
u=json.loads((N/'explicit-affine-units-v1/protocol-v1.json').read_text())
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text());os.environ.update(compiler['additional_environment'])
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
log=N/'logs/sign-cache-publication-main-v3-hyperreal-all-build/stdout'
needed=['num','proptest','rug','serde_json','toml','ciborium','serde'];externs={}
for line in log.read_text().splitlines():
 if not line.startswith('{'):continue
 row=json.loads(line);name=row.get('target',{}).get('name')
 if row.get('reason')!='compiler-artifact' or name not in needed:continue
 choices=[p for p in row['filenames'] if p.endswith('.rlib')]
 if choices:
  assert len(choices)==1 and sha(choices[0])==u['dependency_sha256'][choices[0]]
  externs[name]=choices[0]
assert set(externs)==set(needed);deps=Path(externs['num']).parent
A=Path('/tmp/csgrs-explicit-affine-integrations-20261018-v1');R=N/'explicit-affine-integrations-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir();(A/'scratch').mkdir()
crate=O/'crates/hyperreal';sources=sorted((crate/'tests').glob('*.rs'));assert len(sources)==24
features=['default','simple','cached-f32-approx','cached-f64-approx','dispatch-trace','serde']
overlays={O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_explicit_v1.rs',O/'crates/hyperreal/src/real/arithmetic/add_sub.rs':W/'add_sub_explicit_v1.rs'}
inputs={str(p):sha(p) for p in [*sources,*overlays.values(),W/'scalar-integration-contract-v1.md']}
metadata=tomllib.loads((crate/'Cargo.toml').read_text())['package']
commands={};artifacts={};summaries={}
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in inputs.items())
 assert all(sha(p)==h for p,h in u['dependency_sha256'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert all(sha(p)==h for p,h in artifacts.items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'inputs_sha256':inputs,'dependency_sha256':u['dependency_sha256'],'features':features,'test_sources':[str(p) for p in sources],'version':metadata['version'],'all_top_level_integration_files_selected':True,'direct_rustc_scope':True,'production_source_changed':False})
def execute(label,args):
 verify();name='explicit-affine-integrations-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(A/'scratch'),'--setenv','CARGO_PKG_VERSION',metadata['version'],'--setenv','CARGO_MANIFEST_DIR',str(crate),'--setenv','CARGO_BIN_EXE_hyperreal',str(A/'hyperreal')]
 for dest,source in overlays.items():argv+=['--ro-bind',str(source),str(dest)]
 r=run(name,argv+list(map(str,args)),O,wall_seconds=1800);commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 return (N/'logs'/name/'stdout').read_text()
def compile(name,source,output,kind):
 args=[compiler['additional_environment']['RUSTC'],'--crate-name',name,'--edition=2024','-C','opt-level=3','-D','warnings',source,'-o',output,'-L','dependency='+str(A),'-L','dependency='+str(deps)]
 args+=['--test'] if kind=='test' else ['--crate-type',kind]
 for feature in features:args+=['--cfg','feature="'+feature+'"']
 for dep,path in externs.items():args+=['--extern',dep+'='+path]
 if kind!='rlib':args+=['--extern','hyperreal='+str(A/'libhyperreal.rlib')]
 execute(name+'-'+kind+'-compile',args);artifacts[str(output)]=sha(output)
compile('hyperreal',crate/'src/lib.rs',A/'libhyperreal.rlib','rlib')
compile('hyperreal',crate/'src/main.rs',A/'hyperreal','bin')
for source in sources:
 output=A/(source.stem+'-tests')
 compile(source.stem,source,output,'test')
 out=execute(source.stem+'-run',[output,'--nocapture','--test-threads=1'])
 rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
 assert rows and all(row[0]=='ok' and row[2]=='0' for row in rows),rows
 summaries[source.name]=rows;dump(R/'summaries-v1.json',summaries)
verify()
dump(R/'result-v1.json',{'passed':True,'summaries':summaries,'parent_test_total':sum(int(rows[-1][1]) for rows in summaries.values()),'parent_ignored':sum(int(rows[-1][3]) for rows in summaries.values()),'commands':commands,'artifacts_sha256':artifacts,'all_top_level_test_files_run':True,'full_cargo_matrix':False,'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False})
print(json.dumps({'passed':True,'test_files':len(summaries),'parent_tests':sum(int(rows[-1][1]) for rows in summaries.values()),'runtime_admitted':False}),flush=True)
'''
ast.parse(script);p=W/'integrations_v1.py';assert not p.exists();p.write_text(script)
print('Prepared all scalar integration files; execution waits for wider units.')
