"""Analyze every matched replay result without interpreting process time as a speedup."""
import csv,hashlib,io,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
W=N/'explicit-affine-control-v1'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'explicit-affine-replay-v1/result-v1.json').read_text())
assert r['passed'] and len(r['allocation_outputs'])==10
alloc={}
for key,value in r['allocation_outputs'].items():
    rows=list(csv.DictReader(io.StringIO(value)))
    assert len(rows)==20 and len({v['representation'] for v in rows})==20
    rows=[{k:v if k=='representation' else int(v) for k,v in row.items()} for row in rows]
    assert all(v['iterations']==64 for v in rows)
    alloc[key]=rows
comparisons=[]
for i in range(5):
    a,b=alloc['baseline/'+str(i)],alloc['candidate/'+str(i)]
    assert [v['representation'] for v in a]==[v['representation'] for v in b]
    for before,after in zip(a,b):
        comparisons.append({'pair':i,'representation':before['representation'],'baseline':before,'candidate':after,'deltas':{k:after[k]-before[k] for k in before if k not in ('representation','iterations')}})
assert len(comparisons)==100
traces={};results={};inputs={}
for variant in ('baseline','candidate'):
    p=N/'logs'/('explicit-affine-replay-'+variant+'-probe-v1')/'stdout'
    inputs[str(p)]=sha(p);traces[variant]={};results[variant]=[]
    for line in p.read_text().splitlines():
        if line.startswith('RESULT,'):results[variant].append(line)
        if line.startswith('TRACE,'):
            _,case,phase,layer,op,path,count=line.split(',')
            traces[variant].setdefault(case,{}).setdefault(phase,{})['/'.join((layer,op,path))]=int(count)
assert results['baseline']==results['candidate'] and len(results['baseline'])==81
assert set(traces['baseline'])==set(traces['candidate']) and len(traces['baseline'])==27
quadratic=[]
for case in traces['baseline']:
    a=traces['baseline'][case]['repeated'];b=traces['candidate'][case]['repeated']
    q='computable/structural/quadratic-surd'
    quadratic.append({'case':case,'queries':8,'baseline':a.get(q,0),'candidate':b.get(q,0),'delta':b.get(q,0)-a.get(q,0)})
reduced=[v for v in quadratic if v['delta']<0]
assert len(reduced)==8 and all(v['baseline']==8 and v['candidate']==0 for v in reduced)
assert not any(v['delta']>0 for v in quadratic)
p=W/'replay-analysis-v1.json';assert not p.exists()
p.write_text(json.dumps({'helper_sha256':sha(Path(__file__)),'replay_result_sha256':sha(N/'explicit-affine-replay-v1/result-v1.json'),'probe_output_sha256':inputs,'consumer_summaries':{k:v for k,v in r['summaries'].items() if not k.endswith('rows')},'allocation_comparisons':comparisons,'allocation_rows_identical':all(not any(v['deltas'].values()) for v in comparisons),'native_comparison_results_identical':True,'comparison_pairs':27,'result_rows':81,'quadratic_projections':quadratic,'trace_counts':traces,'reduced_quadratic_projection_pairs':8,'speedup_claimed':False,'limitations':['Counts describe requested Rust allocation payload; no allocator-overhead or RSS bound follows.','Named dispatch events do not count all proof calls or establish total cost.','The complete probe workloads are matched; retained-difference phases still omit their construction and do not independently establish a speedup.','No full native resource gate, report migration or main-source integration was run in this replay.'],'runtime_admitted':False,'production_source_changed':False},indent=2,sort_keys=True)+'\n')
print(json.dumps({'allocation_comparisons':100,'allocation_rows_identical':all(not any(v['deltas'].values()) for v in comparisons),'reduced_projection_pairs':len(reduced),'runtime_admitted':False}),flush=True)
