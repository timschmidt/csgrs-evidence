"""Prepare a separate subtraction acceptance experiment; no main-source edits."""
import ast, hashlib, json, subprocess, sys
sys.dont_write_bytecode = True
from pathlib import Path
O = Path('/home/tim/Documents/GitHub/workspace/csgrs')
N = O.parent / 'csgrs-properties-validation-2026-10-17-v2'
W = N / 'explicit-affine-control-v1'
P = N / 'sign-cache-publication-control-v1'
sys.path.insert(0, str(P))
from validation_runner_v4_local import resources, reasons, sha
assert not reasons(resources())
assert not W.exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=O).decode().strip() == 'eae42f7c336f5de0d0ec3455a338a37a0617a108'
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], cwd=O)
W.mkdir()
(W / 'contract-v1.md').write_text("""# Explicit affine subtraction experiment

Parent revision: eae42f7c336f5de0d0ec3455a338a37a0617a108.
Owner: Hyperreal scalar construction and its shared affine recognizer.
Properties: P1-P5, P7-P9 and downstream P17-P20. Consumers include Real
subtraction, equality and ordering, and native Hypercurve offsets.

The proposed domain is explicit subtraction of rational affine expressions
whose symbolic terms can be proved identical using the existing bounded
recognizer. Their difference should retain the exact rational offset delta.
Equal mathematical forms without this structural proof may decline. Ordinary
Computable addition must retain its established graph and shared-cache contract.
Both rejected constructor prototypes stay rejected.

Reproduce missing public acceptance on this revision before implementation:
signed rational scaling, reversed sum operands, bare shared bases, unequal
bases and coefficients, cold and warmed inputs, and repeated composition.
Rational answers use independently derived integer/fraction oracles. Keep
all 849 original scalar units, especially shared-base preservation, unchanged.
The earlier different-radical zero-refinement failure remains an open observation.

Any implementation must reuse rational_offset_parts and the existing structural
identity proof. Its existing eight-visit budget per operand, 4096-bit binary
shift limit and 4097-bit individual scale limit remain. These are not bounds
on structural comparison cost, aggregate coefficient growth or heap memory.
Unsupported recognition falls back without caching a negative conclusion.
No approximation or new long-lived cache may be introduced.

Use fresh experiment directories with read-only existing dependencies and
read-only main source. Retain the original storage baselines: root 16 GiB,
Disk B 72 GiB, temporary 12 GiB, cumulative logs 96 MiB. Child address space
8 GiB, two jobs, focused tests 60 seconds, full compile/suite 1800 seconds.
No budget reset. External containment is required; no globally bounded-runtime
claim is made. Archive every adverse result and physical artifact independently.

Passing focused units is not admission. Before retention require unaffected
scalar behavior, native comparison replay, downstream qualification, and
like-for-like workload measurements where claiming reduced cost. Original
native full-board, copper-neck and report gates remain unchanged. No exact
importer, general cache, distribution or full-plan claim follows.
Hypervoxel remains outside scope.
""")
tests = r'''use super::Real;
use crate::{CertifiedRealOrdering, Rational};
use num::{BigInt, BigRational, One};
use std::cmp::Ordering;

#[test]
fn explicit_affine_subtraction_retains_exact_rational_results() {
    let bases = [
        Real::from(2).sqrt().unwrap(),
        Real::pi(),
        Real::one().sin(),
    ];
    for base in bases {
        for (n, d) in [(1, 1), (-1, 1), (-3, 1), (7, 11), (-1, 1024), (1024, 1)] {
            let scale = Rational::fraction(n, d).unwrap();
            // (5/8 - (-3/7)) * (n/d) = 59*n/(56*d), independently derived.
            let oracle = BigRational::new(BigInt::from(59 * n), BigInt::from(56 * d));
            let expected = Rational::from_bigint_fraction(
                oracle.numer().clone(), oracle.denom().magnitude().clone(),
            ).unwrap();
            for reverse_left in [false, true] {
                for reverse_right in [false, true] {
                    let affine = |offset: Rational, reversed| {
                        let offset = Real::new(offset);
                        let sum = if reversed { offset + &base } else { &base + offset };
                        sum * Real::new(scale.clone())
                    };
                    let left = affine(Rational::fraction(5, 8).unwrap(), reverse_left);
                    let right = affine(Rational::fraction(-3, 7).unwrap(), reverse_right);
                    assert_eq!((&left - &right).exact_rational(), Some(expected.clone()));
                    assert_eq!((&right - &left).exact_rational(), Some(-&expected));
                    let mut assigned = left.clone();
                    assigned -= &right;
                    assert_eq!(assigned.exact_rational(), Some(expected.clone()));
                    assert_eq!((left - right).exact_rational(), Some(expected.clone()));
                }
            }
        }
    }
}

#[test]
fn explicit_affine_subtraction_handles_bare_shared_bases() {
    let base = Real::from(7).sin();
    let delta = Rational::fraction(7, 11).unwrap();
    let shifted = &base + Real::new(delta.clone());
    assert_eq!((&shifted - &base).exact_rational(), Some(delta.clone()));
    assert_eq!((&base - &shifted).exact_rational(), Some(-delta));
}

#[test]
fn explicit_affine_subtraction_preserves_cold_and_warm_operands() {
    for warmed in [false, true] {
        let base = Real::from(7).sin();
        let left = &base + Real::from(100);
        let right = &base + Real::from(101);
        if warmed {
            left.certified_rational_interval(-32).unwrap();
            right.certified_rational_interval(-64).unwrap();
        }
        let before = (
            left.cached_rational_interval(-32),
            right.cached_rational_interval(-64),
        );
        for precision in [0, -128, 0] {
            assert_eq!((&left - &right).exact_rational(), Some(Rational::new(-1)));
            assert!(matches!(left.certified_cmp_until(&right, precision),
                CertifiedRealOrdering::Known { ordering: Ordering::Less, .. }));
        }
        assert_eq!(left.cached_rational_interval(-32), before.0);
        assert_eq!(right.cached_rational_interval(-64), before.1);
    }
}

#[test]
fn explicit_affine_subtraction_composes_without_a_symbolic_chain() {
    let base = Real::from(7).sin();
    let mut total = Real::zero();
    for i in 0..512 {
        let left = &base + Real::from(i + 1);
        let right = &base + Real::from(i);
        total += left - right;
        assert_eq!(total.exact_rational(), Some(Rational::new(i + 1)));
    }
    assert_eq!((total / Real::from(512)).unwrap().exact_rational(), Some(Rational::one()));
}

#[test]
fn explicit_affine_subtraction_keeps_unequal_symbolic_terms() {
    let sqrt_two = Real::from(2).sqrt().unwrap();
    let sqrt_three = Real::from(3).sqrt().unwrap();
    let left = &sqrt_two + Real::from(100);
    let right = &sqrt_three + Real::from(101);
    let difference = &left - &right;
    assert!(difference.exact_rational().is_none());
    assert!(matches!(difference.certified_cmp_until(&Real::zero(), -512),
        CertifiedRealOrdering::Known { ordering: Ordering::Less, .. }));
    let different_coefficient = &sqrt_two * Real::from(2) + Real::from(100);
    let difference = different_coefficient - left;
    assert!(difference.exact_rational().is_none());
    assert!(matches!(difference.certified_cmp_until(&Real::zero(), -512),
        CertifiedRealOrdering::Known { ordering: Ordering::Greater, .. }));
}

#[test]
fn explicit_affine_subtraction_declines_oversized_scale_recognition() {
    let base = Real::from(7).sin();
    let scale = Real::new(Rational::from_bigint((BigInt::one() << 8192_usize) + BigInt::one()));
    let left = (&base + Real::from(100)) * &scale;
    let right = (&base + Real::from(101)) * &scale;
    assert!((left - right).exact_rational().is_none());
}
'''
(W/'explicit_affine_tests_v1.rs').write_text(tests)
node = (O/'crates/hyperreal/src/real/mod.rs').read_text()
node += '\n#[cfg(test)]\nmod explicit_affine_tests { include!("' + str(W/'explicit_affine_tests_v1.rs') + '"); }\n'
(W/'real_mod_tests_v1.rs').write_text(node)
source=(N/'native-comparison-control-v1/owner_baseline_v1.py').read_text()
source=source.replace("A=Path('/tmp/csgrs-affine-owner-baseline-20261018-v1');R=N/'affine-owner-baseline-v1'", "A=Path('/tmp/csgrs-explicit-affine-baseline-20261018-v1');R=N/'explicit-affine-baseline-v1'")
source=source.replace("O/'crates/hyperreal/src/computable/node.rs':W/'node_affine_tests_v1.rs'", "O/'crates/hyperreal/src/real/mod.rs':W/'real_mod_tests_v1.rs'")
source=source.replace("W/'node_affine_tests_v1.rs',W/'affine_difference_tests_v1.rs'", "W/'real_mod_tests_v1.rs',W/'explicit_affine_tests_v1.rs'")
source=source.replace("W/'affine-owner-contract-v1.md'", "W/'contract-v1.md'")
source=source.replace('a62636b985186ff9041f6013b2f840adb3d391b9','eae42f7c336f5de0d0ec3455a338a37a0617a108')
source=source.replace("'affine-owner-baseline-'", "'explicit-affine-baseline-'")
source=source.replace("'affine_difference_tests::'", "'explicit_affine_tests::'")
source=source.replace('logs/affine-owner-baseline-tests-v1', 'logs/explicit-affine-baseline-tests-v1')
source=source.replace('assert len(rows)==1', "assert len(rows)==1\nexecute('complete-unit-suite',[binary,'--nocapture','--test-threads=1'],1800,True)")
source=source.replace("'candidate_prepared':False", "'candidate_prepared':False,'complete_suite_log':str(N/'logs/explicit-affine-baseline-complete-unit-suite-v1')")
ast.parse(source)
(W/'baseline_v1.py').write_text(source)
(W/'preparation-v1.json').write_text(json.dumps({
    'helper_sha256':sha(Path(__file__)),
    'inputs_sha256':{str(p):sha(p) for p in W.iterdir() if p.is_file()},
    'production_source_changed':False,
    'resources':resources(),
},indent=2,sort_keys=True)+'\n')
print(json.dumps({'control':str(W),'tests':6,'candidate_prepared':False}),flush=True)
