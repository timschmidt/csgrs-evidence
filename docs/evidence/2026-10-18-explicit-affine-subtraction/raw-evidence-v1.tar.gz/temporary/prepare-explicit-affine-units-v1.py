"""Prepare wider scalar and immediate downstream unit qualification."""
import ast,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=N/'explicit-affine-control-v1'
contract="""# Wider unit qualification

After the matched replay and allocation processes finish, run a direct
all-feature Hyperreal unit build with the same six new public tests and both
scalar implementation overlays. Also build and run all Hyperlimit and
Hypercurve unit tests against the matched candidate libraries, with the same
dispatch-trace/std configurations recorded in the replay contract.

All original test bodies, policies, fixture resolutions and ignore annotations
remain unchanged. Record every test result and existing ignore. This exercises
scalar serialization configurations and the predicate and curve consumers,
but does not replace Cargo integration tests, docs, Clippy, full native workloads,
report migration, main-source integration or distribution validation.

Every compiler/dependency/source input is pinned. Use a fresh temporary output
directory, read-only earlier artifacts and the unchanged containment contract.
Builds and complete unit suites retain the 1800-second limit and 8-GiB child
address-space limit. No validation runs concurrently with allocation pairs.
"""
p=W/'unit-contract-v1.md';assert not p.exists();p.write_text(contract)
source=r'''"""All-feature scalar and immediate downstream unit tests; direct compiler scope."""
import gzip,json,os,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
replay=json.loads((N/'explicit-affine-replay-v1/result-v1.json').read_text());assert replay['passed']
closed=json.loads(gzip.decompress((O/'docs/evidence/2026-10-18-sign-cache-publication/artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text());os.environ.update(compiler['additional_environment'])
frozen=json.loads((N/'explicit-affine-baseline-v1/protocol-v1.json').read_text())
deps=Path(frozen['verified_dependencies']['num']).parent
D=Path('/tmp/csgrs-explicit-affine-replay-20261018-v1/candidate')
A=Path('/tmp/csgrs-explicit-affine-units-20261018-v1');R=N/'explicit-affine-units-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir();(A/'scratch').mkdir()
overlays={O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_explicit_v1.rs',O/'crates/hyperreal/src/real/arithmetic/add_sub.rs':W/'add_sub_explicit_v1.rs',O/'crates/hyperreal/src/real/mod.rs':W/'real_mod_tests_v1.rs'}
inputs={str(p):sha(p) for p in [*overlays.values(),W/'explicit_affine_tests_v1.rs',W/'unit-contract-v1.md']}
externs={};dependency_pins=dict(frozen['dependency_pins'])
for label,names in {
 'hyperreal-all':['num','proptest','rug','serde_json','toml','ciborium','serde'],
 'hyperlimit':['proptest','serde_json','robust','apfp','geometry_predicates'],
 'hypercurve':['proptest','geo'],
}.items():
 log=N/'logs'/('sign-cache-publication-main-v3-'+label+'-build')/'stdout'
 assert sha(log)==closed[str(log)];dependency_pins[str(log)]=sha(log)
 externs[label]={}
 for line in log.read_text().splitlines():
  if not line.startswith('{'):continue
  row=json.loads(line);name=row.get('target',{}).get('name')
  if row.get('reason')!='compiler-artifact' or name not in names:continue
  paths=[Path(p) for p in row['filenames'] if p.endswith('.rlib')]
  if paths:
   assert len(paths)==1 and sha(paths[0])==closed[str(paths[0])]
   externs[label][name]=str(paths[0]);dependency_pins[str(paths[0])]=sha(paths[0])
 assert set(externs[label])==set(names)
commands={};artifacts={};summaries={}
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in inputs.items())
 assert all(sha(p)==h for p,h in dependency_pins.items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert all(sha(p)==h for p,h in replay['artifacts_sha256'].items())
 assert all(sha(p)==h for p,h in artifacts.items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'input_sha256':inputs,'dependency_sha256':dependency_pins,'read_only_replay_artifacts':replay['artifacts_sha256'],'source_pins_sha256':sha(P/'main-source-pins-v3.json.gz'),'overlays':{str(k):str(v) for k,v in overlays.items()},'direct_compiler_scope':True,'production_source_changed':False,'full_cargo_matrix':False})
def execute(label,args):
 verify();name='explicit-affine-units-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(A/'scratch')]
 for dest,src in overlays.items():argv+=['--ro-bind',str(src),str(dest)]
 r=run(name,argv+list(map(str,args)),O,wall_seconds=1800);commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 return (N/'logs'/name/'stdout').read_text()
for label,crate,features,needed in [
 ('hyperreal-all','hyperreal',['default','simple','cached-f32-approx','cached-f64-approx','dispatch-trace','serde'],[]),
 ('hyperlimit','hyperlimit',['std','dispatch-trace'],['hyperreal','hyperlattice']),
 ('hypercurve','hypercurve',['dispatch-trace'],['hyperreal','hyperlimit','hypersolve','num']),
]:
 binary=A/(label+'-units')
 args=[compiler['additional_environment']['RUSTC'],'--test','--crate-name',crate,'--edition=2024','-C','opt-level=3','-D','warnings',O/'crates'/crate/'src/lib.rs','-o',binary,'-L','dependency='+str(D),'-L','dependency='+str(deps)]
 for f in features:args+=['--cfg','feature="'+f+'"']
 all_externs=dict(externs[label])
 for dep in needed:all_externs[dep]=str(D/('lib'+dep+'.rlib')) if dep!='num' else frozen['verified_dependencies']['num']
 for dep,path in all_externs.items():args+=['--extern',dep+'='+path]
 execute(label+'-compile',args);artifacts[str(binary)]=sha(binary)
 out=execute(label+'-run',[binary,'--nocapture','--test-threads=1'])
 rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
 assert rows and all(r[0]=='ok' and r[2]=='0' for r in rows),rows
 summaries[label]={'features':features,'summaries':rows}
 dump(R/'summaries-v1.json',summaries)
dump(R/'result-v1.json',{'passed':True,'summaries':summaries,'commands':commands,'artifacts_sha256':artifacts,'production_source_changed':False,'runtime_admitted':False,'full_plan_complete':False,'full_cargo_qualification':False})
print(json.dumps({'passed':True,'summaries':summaries,'runtime_admitted':False}),flush=True)
'''
ast.parse(source)
p=W/'units_v1.py';assert not p.exists();p.write_text(source)
print('Prepared wider units; execution waits until allocation measurements finish.')
