"""Matched native consumer replay with fixed scalar allocation workloads."""
import csv,gzip,io,json,os,re,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';P=N/'sign-cache-publication-control-v1'
sys.path.insert(0,str(P))
from validation_runner_v4_local import run,dump,sha,resources,reasons
assert json.loads((N/'explicit-affine-candidate-v1/result-v1.json').read_text())['summary']==[['ok','6','0','0','0','849']]
frozen=json.loads((N/'explicit-affine-baseline-v1/protocol-v1.json').read_text())
libraries=frozen['verified_dependencies'];deps=Path(libraries['num']).parent
pins=json.loads(gzip.decompress((P/'main-source-pins-v3.json.gz').read_bytes()))
compiler=json.loads(Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1/cargo-preparation-protocol-v1.json').read_text())
os.environ.update(compiler['additional_environment'])
rustc=compiler['additional_environment']['RUSTC']
A=Path('/tmp/csgrs-explicit-affine-replay-20261018-v1');R=N/'explicit-affine-replay-v1'
assert not A.exists() and not R.exists();A.mkdir();R.mkdir();(A/'scratch').mkdir()
overlays={O/'crates/hyperreal/src/computable/node/algebra.rs':W/'algebra_explicit_v1.rs',O/'crates/hyperreal/src/real/arithmetic/add_sub.rs':W/'add_sub_explicit_v1.rs'}
probe=N/'native-comparison-control-v1/comparison_probe_v1.rs'
alloc=O/'crates/hyperreal/examples/allocation_profile.rs'
tests=[O/'crates/hypercurve/tests'/name for name in ['native_linear_stroke.rs','native_linear_stroke_contracts.rs','point_equality_contract.rs']]
inputs={str(p):sha(p) for p in [probe,alloc,*tests,*overlays.values(),W/'replay-contract-v1.md']}
commands={};artifacts={};summaries={};built={}
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in inputs.items())
 assert all(sha(p)==h for p,h in frozen['dependency_pins'].items())
 assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
 assert all(sha(p)==h for p,h in artifacts.items())
 assert not reasons(resources())
verify()
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'replay-contract-v1.md'),'input_sha256':inputs,'dependency_sha256':frozen['dependency_pins'],'compiler_tool_sha256':compiler['tool_sha256'],'source_pins_sha256':sha(P/'main-source-pins-v3.json.gz'),'runtime_overlays':{str(k):str(v) for k,v in overlays.items()},'features':{'hyperreal':['dispatch-trace'],'hyperlattice':[],'hyperlimit':['std','dispatch-trace'],'hypersolve':['dispatch-trace'],'hypercurve':['dispatch-trace']},'production_source_changed':False,'direct_rustc_build':True,'speedup_claimed':False})
def execute(variant,label,args,limit=1800):
 verify();name='explicit-affine-replay-'+variant+'-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(A/'scratch')]
 if variant=='candidate':
  for dest,source in overlays.items():argv+=['--ro-bind',str(source),str(dest)]
 r=run(name,argv+list(map(str,args)),O,wall_seconds=limit)
 commands[variant+'/'+label]=r;dump(R/'progress-v1.json',commands);verify()
 return (N/'logs'/name/'stdout').read_text()
features={'hyperreal':['dispatch-trace'],'hyperlattice':[],'hyperlimit':['std','dispatch-trace'],'hypersolve':['dispatch-trace'],'hypercurve':['dispatch-trace']}
requirements={'hyperreal':['num'],'hyperlattice':['hyperreal'],'hyperlimit':['hyperreal','hyperlattice'],'hypersolve':['hyperreal','hyperlattice','hyperlimit','num'],'hypercurve':['hyperreal','hyperlimit','hypersolve','num']}
for variant in ['baseline','candidate']:
 D=A/variant;D.mkdir();built[variant]={}
 for crate,needed in requirements.items():
  output=D/('lib'+crate+'.rlib')
  args=[rustc,'--crate-name',crate,'--crate-type','rlib','--edition=2024','-C','opt-level=3','-D','warnings',O/'crates'/crate/'src/lib.rs','-o',output,'-L','dependency='+str(D),'-L','dependency='+str(deps)]
  for feature in features[crate]:args+=['--cfg','feature="'+feature+'"']
  for dep in needed:args+=['--extern',dep+'='+str(built[variant][dep] if dep in built[variant] else libraries[dep])]
  execute(variant,'build-'+crate,args);artifacts[str(output)]=sha(output);built[variant][crate]=output
 for name,source,testing in [('probe',probe,False),('allocation',alloc,False)]+[(p.stem,p,True) for p in tests]:
  output=D/name
  args=[rustc,'--crate-name',name,'--edition=2024','-C','opt-level=3','-D','warnings',source,'-o',output,'-L','dependency='+str(D),'-L','dependency='+str(deps)]
  if testing:args+=['--test']
  for dep in ['hyperreal','hyperlimit','hypercurve']:args+=['--extern',dep+'='+str(built[variant][dep])]
  execute(variant,'compile-'+name,args);artifacts[str(output)]=sha(output)
 for source in tests:
  out=execute(variant,'test-'+source.stem,[D/source.stem,'--nocapture','--test-threads=1'])
  rows=re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',out,re.M)
  assert rows and all(r[0]=='ok' and r[2]=='0' for r in rows),rows
  summaries[variant+'/'+source.stem]=rows
 out=execute(variant,'probe',[D/'probe'],60)
 result_rows=[line for line in out.splitlines() if line.startswith('RESULT,')]
 assert len(result_rows)==81
 summaries[variant+'/probe_result_rows']=result_rows
dump(R/'consumer-result-v1.json',{'summaries':summaries,'artifacts_sha256':artifacts,'all_consumer_tests_passed':True,'matching_probe_results':summaries['baseline/probe_result_rows']==summaries['candidate/probe_result_rows'],'commands':commands,'runtime_admitted':False})
allocation={}
for ordinal in range(5):
 order=['baseline','candidate'] if ordinal%2==0 else ['candidate','baseline']
 for variant in order:
  out=execute(variant,'allocation-'+str(ordinal),[A/variant/'allocation','64'],60)
  allocation[variant+'/'+str(ordinal)]=out
  dump(R/'allocation-progress-v1.json',allocation)
verify()
dump(R/'result-v1.json',{'passed':True,'summaries':summaries,'allocation_outputs':allocation,'commands':commands,'artifacts_sha256':artifacts,'runtime_admitted':False,'main_source_changed':False,'full_plan_complete':False,'performance_speedup_claimed':False})
print(json.dumps({'passed':True,'summaries':{k:v for k,v in summaries.items() if not k.endswith('rows')},'allocation_processes':len(allocation),'runtime_admitted':False}),flush=True)
