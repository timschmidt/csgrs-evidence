# Scalar integration qualification

After the wider unit suites, compile the all-feature Hyperreal library and
its simple CLI in a fresh direct-rustc output directory. Compile and execute
every top-level Rust integration-test file under crates/hyperreal/tests,
unchanged, with the same complete feature configuration and pinned dependencies
as the all-feature unit build. Pin Cargo package metadata and the newly built
CLI path explicitly for tests using compile-time Cargo variables. No test file
may be omitted, modified, filtered, or silently skipped by this harness.

Retain all parent and nested process summaries and all failures. This is direct
compiler validation, not Cargo, documentation, minimum-compiler, Clippy or
distribution validation. Native full-workload and report gates remain open.
Every new command retains the original 1800-second suite/compile ceiling,
8-GiB child address-space limit, and unchanged storage/log baselines.
