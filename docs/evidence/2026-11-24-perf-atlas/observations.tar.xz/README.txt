Performance atlas, full sweep, 2026-11-24

Producer: csgrs commit bfffc8f6d (branch perf-atlas), command
  CARGO_TARGET_DIR=<scratch> scripts/perf-atlas/run.sh --out <dir>
Host: Intel Xeon E5-2680 v2 @ 2.80GHz (40 threads), Linux 6.12 x86_64,
rustc 1.100.0, release profile, seed default. Wall time 6565 s.

Files
  <crate>.json     raw atlas data for 9 crates (442 operations); each point is
                   [magnitude, median_ns, min_ns, max_ns, iters, status, reason]
  index.html       self-contained report rendered by scripts/perf-atlas/render.py
  run.log          progress log of the run
  highlights.txt   status counts, largest cliffs and valleys, grouped failures
                   and ceilings (anomaly rules from render.py: cliff >= 4x rise
                   between adjacent magnitudes, valley >= 2x below both neighbours)

Times come from one shared development host and are indicative; shapes,
cliffs and relative costs are what the record is for.
