from pathlib import Path
from collections import Counter
import ast,gzip,hashlib,json,math,re,statistics,time
s=Path(__file__).parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');done=load(s/'timing-completion.json');began=load(s/'timing-started.json');assert done['exit_code']==0 and done['seconds']<1800;assert sha((s/'timing.py').read_bytes())==began['driver_sha256'] and sha((s/'PROTOCOL.md').read_bytes())==began['protocol_sha256'] and sha((s/'builds.json').read_bytes())==began['builds_sha256'];calls=[n.func.attr for n in ast.walk(ast.parse((s/'timing.py').read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess'];assert calls==['Popen'];assert load(s/'build-verification-command.json')['exit_code']==0
commands=load(s/'timing-commands.json');assert len(commands)==done['commands']==59 and len({c['name'] for c in commands})==59;raws={}
for c in commands:
 stored=(s/'timing'/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and len(stored)==c['stored_bytes'] and sha(raw)==c['raw_sha256'] and len(raw)==c['raw_bytes'];assert c['exit_code']==0 and not c['timeout'];raws[c['name']]=raw.decode()
probe=json.loads(raws['affinity-aslr']);assert probe['affinity']==[0] and int(probe['personality'],16)&0x40000
hosts=list(s.glob('host-*.json'));assert len(hosts)==39 and all(not load(p)['competing'] for p in hosts);plan=load(s/'timing-plan.json');runs=load(s/'runs.json');assert len(plan)==len(runs)==done['benchmark_invocations']==19
builds=load(s/'builds.json');lookup={(b['label'],b['family']):b for b in builds};values={};sample_count=0;case_count=0;control_matches=0;source_hashes={}
for b in builds:
 raw=Path(b['image']['path']).read_bytes();assert len(raw)==b['image']['bytes'] and sha(raw)==b['image']['sha256']
for task,run in zip(plan,runs):
 for key,value in task.items():assert run[key]==value
 b=lookup[(run['label'],run['family'])];assert run['image']==b['image'] and len(run['cases'])==8;control=gzip.decompress((s/b['control_log']).read_bytes()).decode();text=raws[run['name']]
 if run['family']=='owner':expected=set(re.findall(r'^Testing (.+)\nSuccess$',control,re.M));assert len(expected)==15
 else:
  expected={f'cancellation/{reuse}/{case}/{policy}/{trace}' for case in range(2) for policy in ['strict','approx'] for reuse in ['reuse'] for trace in (['passive','active'] if 'trace' in run['family'] else ['passive'])};select=lambda raw:[line for line in raw.splitlines() if line.startswith(('CASE ','OUTPUT ','TRACE '))];assert select(text)==select(control);control_matches+=b['expected_cases']
 assert {c['id'] for c in run['cases']}==expected
 command=next(c for c in commands if c['name']==run['name']);argv=command['command'];assert argv[:5]==['taskset','-c','0','setarch','x86_64'] and argv[5]=='-R';assert argv[7:]==['--bench','--noplot','--sample-size','30','--warm-up-time','0.5','--measurement-time','1']+['^cancellation/reuse/[01]/(strict|approx)/(passive|active)$'];assert argv[6].endswith('/trace');assert not load(s/('host-'+run['name']+'-before.json'))['competing'] and not load(s/('host-'+run['name']+'-after.json'))['competing']
 measured={}
 for c in run['cases']:
  p=s/c['sample'];e=s/c['estimates'];assert sha(p.read_bytes())==c['sample_sha256'] and sha(e.read_bytes())==c['estimates_sha256'];sample=load(p);estimates=load(e);assert load(p.with_name('benchmark.json'))['full_id']==c['id'];assert len(sample['iters'])==len(sample['times'])==30;assert all(math.isfinite(x) and x>0 for x in sample['iters']+sample['times']);normalized=[t/i for t,i in zip(sample['times'],sample['iters'])];mean=estimates['mean'];median=estimates['median'];assert math.isclose(statistics.mean(normalized),mean['point_estimate'],rel_tol=1e-12) and math.isclose(statistics.median(normalized),median['point_estimate'],rel_tol=1e-12)
  for estimate in [mean,median]:
   ci=estimate['confidence_interval'];assert ci['confidence_level']==0.95 and 0<ci['lower_bound']<=ci['upper_bound'] and math.isfinite(ci['upper_bound']) and estimate['point_estimate']>0
  measured[c['id']]=dict(mean_ns=mean['point_estimate'],median_ns=median['point_estimate'],mean_ci95=mean['confidence_interval'],sample=c['sample'],sample_sha256=c['sample_sha256']);sample_count+=30;case_count+=1
 values[run['name']]=measured
assert case_count==done['case_invocations']==152 and sample_count==4560 and control_matches==608
comparisons=[]
common=[r for r in runs if not r['added']];identifiers=set(values[common[0]['name']]);assert len(common)==18 and len(identifiers)==8
orders=[['baseline','reference','candidate'],['reference','candidate','baseline'],['candidate','baseline','reference'],['candidate','reference','baseline'],['reference','baseline','candidate'],['baseline','candidate','reference']]
for block,order in enumerate(orders):assert [r['label'] for r in common if r['block']==block]==order
for reference in ['baseline','reference']:
 for identifier in sorted(identifiers):
  pairs=[]
  for block in range(6):
   a=next(r for r in common if r['block']==block and r['label']==reference);b=next(r for r in common if r['block']==block and r['label']=='candidate');base=values[a['name']][identifier];candidate=values[b['name']][identifier];ratio=candidate['mean_ns']/base['mean_ns'];pairs.append(dict(reference_run=a['name'],candidate_run=b['name'],reference_mean_ns=base['mean_ns'],candidate_mean_ns=candidate['mean_ns'],ratio=ratio,change_percent=100*(ratio-1),difference_ns=candidate['mean_ns']-base['mean_ns'],candidate_ci_entirely_slower=candidate['mean_ci95']['lower_bound']>base['mean_ci95']['upper_bound'],candidate_ci_entirely_faster=candidate['mean_ci95']['upper_bound']<base['mean_ci95']['lower_bound']))
  ratios=[p['ratio'] for p in pairs];comparisons.append(dict(reference=reference,id=identifier,pairs=pairs,median_paired_change_percent=100*(statistics.median(ratios)-1),min_paired_change_percent=min(p['change_percent'] for p in pairs),max_paired_change_percent=max(p['change_percent'] for p in pairs),median_difference_ns=statistics.median(p['difference_ns'] for p in pairs),slower_pairs=sum(r>1 for r in ratios),faster_pairs=sum(r<1 for r in ratios),separated_slower_pairs=sum(p['candidate_ci_entirely_slower'] for p in pairs),separated_faster_pairs=sum(p['candidate_ci_entirely_faster'] for p in pairs),admitted=False))
added=[dict(family=r['family'],cases=values[r['name']],correct_old_baseline=False) for r in runs if r['added']];assert len(comparisons)==16 and len(added)==1
summary=dict(commands=59,benchmark_invocations=19,case_invocations=152,samples=4560,common_cases=8,paired_process_comparisons=96,public_full_control_matches=608,host_boundary_records=39,by_reference={ref:dict(cases=8,all_six_slower=sum(c['reference']==ref and c['slower_pairs']==6 for c in comparisons),all_six_faster=sum(c['reference']==ref and c['faster_pairs']==6 for c in comparisons),median_change_range_percent=[min(c['median_paired_change_percent'] for c in comparisons if c['reference']==ref),max(c['median_paired_change_percent'] for c in comparisons if c['reference']==ref)],slower_pairs=sum(c['slower_pairs'] for c in comparisons if c['reference']==ref),faster_pairs=sum(c['faster_pairs'] for c in comparisons if c['reference']==ref)) for ref in ['baseline','reference']},producer_seconds=done['seconds'],seconds=time.monotonic()-start,within_process_confidence_not_cross_process_proof=True,runtime_allowance_introduced=False,full_runtime_and_memory_qualification_open=True,admitted=False,review_required=True)
for name,value in [('case-measurements.json',values),('paired-comparisons.json',comparisons),('added-costs.json',added),('runtime-summary.json',summary)]:save(name,value)
print(json.dumps(summary,indent=2))
