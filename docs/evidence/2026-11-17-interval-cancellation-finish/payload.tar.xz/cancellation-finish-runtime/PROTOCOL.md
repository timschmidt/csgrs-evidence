# Finish-borrow targeted runtime screen

Compare primary baselinee63cbf68, original publication8a454c860, and the new
finish-borrow candidate produced by cancellation-finish-borrow. Frozen old trace
images and unchanged consumer sources/locked dependencies come from the previous
runtime campaign. Build new trace and trace,cancel-retry images with the exact
same consumer path, RAM target, Rust1.95 locked/offline config, six build jobs and
isolated RAM Cargo metadata. Preserve old source/image identities and every prior
failure. Current primarya58c277 differs from the old base only in documentation.
No historical charge or old timing is replaced.

Require terminal successful functional qualification first. One1800second build
window,80directchildren,900perbuild/check and60Git. Build and --test the new two
images, exercise old two images, strict Clippy for both configurations, fmt and
source/hash restoration. Original fixture/observer functions and assertions stay
byte-identical. No allocator instrumentation or stack probe in runtime images.

This is a targeted screen of the two small workload sizes containing the prior
all-four-slower cases, with both policies and both passive/active tracing, reused
input: eight cases. It does not replace the full owner/complete-consumer runtime,
resource, distribution, WASM or admission obligations. Each iteration retains the
existing operation/output/trace materialization, assertions and cleanup contract.
Reused-input setup/teardown and debug printing remain outside timing; caches may
be warm. Every invocation still prints all32 public full control records.

Use six balanced permutations of baseline/reference/candidate:
ABC, BCA, CAB, CBA, BAC, ACB. Compare each reference to the candidate within its
block (six paired observations per case). Finish with one candidate-only added
retry invocation using the same eight-case filter; no old-success denominator.
30samples,0.5second warmup,1second requested measurement, no plots. CPU0, ASLR off,
identical shared executable slot/argv and CRITERION_HOME for all three sources.
Retain all raw samples and signs/intervals; no automatic nonregression judgment.

Separate1800second timing window,100directchildren at one Popen site,300per
benchmark/60hosttool. No concurrent owned builds/audits. Boundary host checks
reject competing compiler/routing work but do not prove continuous exclusivity.
No automatic retry or deadline reset. Per-command1GiBfiles,512MiBstage,
2.5GiBtmp/20GiBdevelopment reserves. Offline audit separately capped300seconds.
Queue1621335/start38218939 remains held and watcher3416600 terminal. No merge,
allowance increase, cleared count charge or release clearance follows this screen.
