from pathlib import Path
import gzip,hashlib,json,os,resource,shutil,signal,subprocess,time
s=Path(__file__).parent;out=s/'timing';slots=Path('/dev/shm/interval-cancellation-finish-runtime-slots');criterion=s/'criterion-current';start=time.monotonic();deadline=start+1800;commands=[];runs=[];sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];builds=load(s/'builds.json');lookup={(b['label'],b['family']):b for b in builds};env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR='/dev/shm/interval-cancellation-runtime-target',CARGO_BUILD_JOBS='6',CARGO_NET_OFFLINE='true',HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1',CRITERION_HOME=str(criterion));case_filter='^cancellation/reuse/[01]/(strict|approx)/(passive|active)$'
def guard_limits():
 f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();assert time.monotonic()<deadline and len(commands)<100;assert shutil.disk_usage('/tmp').free>=2560*1024**2 and shutil.disk_usage('/mnt/development').free>=20*1024**3;assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<512*1024**2

def run(name,args,cap=300):
 guard_limits();t=time.monotonic();p=out/(name+'.log');timed=False
 with p.open('wb') as log:
  child=subprocess.Popen(args,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(1024**3,hard)));save('timing-active.json',dict(producer=os.getpid(),child=child.pid,name=name,number=len(commands)+1,remaining=deadline-t))
  try:child.wait(timeout=min(cap,deadline-t))
  except BaseException as error:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
   if isinstance(error,subprocess.TimeoutExpired):timed=True
   else:raise
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();c=dict(name=name,command=args,cwd=str(out),exit_code=child.returncode,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_bytes=len(raw),raw_sha256=sha(raw),stored_bytes=len(stored),stored_sha256=sha(stored));commands.append(c);save('timing-commands.json',commands);save('timing-active.json',dict(producer=os.getpid(),child=None));assert child.returncode==0 and not timed,(name,child.returncode);return raw.decode()
def host(label):
 competing=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   name=(p/'comm').read_text().strip();f=(p/'stat').read_text().rsplit(')',1)[1].split()
   if (name in ['alumina-route','kicad-cli','rustc','clippy-driver','cargo'] or name.startswith('alumina-enclos')) and f[0] not in ['T','t','Z','X']:competing.append(dict(pid=int(p.name),comm=name,state=f[0],starttime=f[19],utime=f[11],stime=f[12]))
  except (FileNotFoundError,PermissionError,ProcessLookupError):pass
 save('host-'+label+'.json',dict(time=time.time(),competing=competing,proc_stat=Path('/proc/stat').read_text(),loadavg=Path('/proc/loadavg').read_text()));run('processes-'+label,['ps','-eo','pid,ppid,etimes,pcpu,comm'],cap=60);assert not competing,'Competing workload observed; no automatic retry'
assert not (s/'timing-started.json').exists() and not out.exists() and not slots.exists() and not criterion.exists();assert load(s/'build-completion.json')['exit_code']==0 and load(s/'build-completion.json')['source_restored'];assert load(s/'build-verification-command.json')['exit_code']==0;assert not Path('/proc/'+str(load(s/'build-started.json')['producer'])).exists();assert load(s.parent/'cancellation-standalone-byte-allowance/verification.json')['new_source_admission'] is False;out.mkdir();slots.mkdir();save('timing-started.json',dict(time=time.time(),producer=os.getpid(),driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes()),builds_sha256=sha((s/'builds.json').read_bytes()),environment_overrides={k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','HYPERSOLVE_SKIP_BENCHMARK_REPORTS','CRITERION_HOME']}))
try:
 host('preflight');raw=run('affinity-aslr',['taskset','-c','0','setarch','x86_64','-R','python3','-c','import os,json,pathlib; print(json.dumps({"affinity":sorted(os.sched_getaffinity(0)),"personality":pathlib.Path("/proc/self/personality").read_text().strip()}))'],cap=60);probe=json.loads(raw);assert probe['affinity']==[0] and int(probe['personality'],16)&0x40000
 plan=[]
 for block,order in enumerate([['baseline','reference','candidate'],['reference','candidate','baseline'],['candidate','baseline','reference'],['candidate','reference','baseline'],['reference','baseline','candidate'],['baseline','candidate','reference']]):
  for position,label in enumerate(order):plan.append(dict(family='trace',label=label,block=block,position=position,added=False))
 plan.append(dict(family='added-trace',label='candidate',block=0,position=0,added=True))
 save('timing-plan.json',plan)
 for task in plan:
  family=task['family'];label=task['label'];name=f"{family}-{task['block']}-{task['position']}-{label}";b=lookup[(label,family)];image=Path(b['image']['path']);assert sha(image.read_bytes())==b['image']['sha256'];assert not criterion.exists();host(name+'-before');slot=slots/'trace';shutil.copy2(image,slot);args=['taskset','-c','0','setarch','x86_64','-R',str(slot),'--bench','--noplot','--sample-size','30','--warm-up-time','0.5','--measurement-time','1']+[case_filter];raw=run(name,args);assert criterion.exists();destination=out/name;destination.mkdir();shutil.move(str(criterion),destination/'criterion');samples=sorted(destination.glob('criterion/**/new/sample.json'));assert len(samples)==8,(name,len(samples),8);rows=[]
  for p in samples:
   sample=load(p);metadata=load(p.with_name('benchmark.json'));assert len(sample['iters'])==len(sample['times'])==30 and all(x>0 for x in sample['iters']) and all(x>0 for x in sample['times']);rows.append(dict(id=metadata['full_id'],sample=str(p.relative_to(s)),sample_sha256=sha(p.read_bytes()),estimates=str(p.with_name('estimates.json').relative_to(s)),estimates_sha256=sha(p.with_name('estimates.json').read_bytes())))
  if family!='owner':
   selected=lambda text:[line for line in text.splitlines() if line.startswith(('CASE ','OUTPUT ','TRACE '))];control=gzip.decompress((s/b['control_log']).read_bytes()).decode();assert selected(raw)==selected(control) and len(selected(raw))==b['expected_cases']*3
  host(name+'-after');row=dict(task,name=name,image=b['image'],cases=rows,control_records_match=family!='owner',command_log=name+'.log.gz');runs.append(row);save('runs.json',runs);print(name,len(rows),'completed cases',flush=True)
 guard_limits();save('timing-completion.json',dict(exit_code=0,commands=len(commands),benchmark_invocations=len(runs),common_invocations=sum(not r['added'] for r in runs),added_invocations=sum(r['added'] for r in runs),case_invocations=sum(len(r['cases']) for r in runs),seconds=time.monotonic()-start,all_expected_samples=True,admitted=False,regression_judgment_pending=True));print('Focused runtime screen complete',flush=True)
except BaseException as error:save('timing-completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),benchmark_invocations=len(runs),seconds=time.monotonic()-start,automatic_retry=False,admitted=False));raise
