# Finish-borrow cancellation candidate

Owner: Hypersolve work_budget; P5/P6/P20/P36; interval plan14.4.
Current primary a58c2771849e57b961983f83efeb8a34cf7ca267 has the same kernel/build
sources as e63cbf68. Reproduce all eight existing publication tests plus a new
missing destructor-reentry witness on current primary before implementation.
The returned payload's destructor must run after removing the cancelled child,
with the parent usable and the frame borrow released; charge its admitted work
to the parent and permit fresh-token retry. The adapter witness remains unchanged.
No predicates, policy decisions, domain or resource allowances change.

Reference implementation8a454c860 performs the final exhaustion poll and scope
pop in separate TLS borrows. Retain it and all prior failures. The proposed
implementation factors the existing exhaustion decision into one owner helper,
used by both the public query and Scope::finish. The cancellable finish calls it
before pop, inside the existing borrow. Ordinary const-false finish does not poll.
Keep last-frame first-failure lookup before observe_cancellation, whose outermost
cancelled-token scan and propagation stay byte-identical. Active=true during
finish is an invariant of the live scope. No value is dropped under this borrow.
This removes redundant bookkeeping; it does not yet establish a runtime benefit.

Run nine publication tests on current primary (six expected failures, three
controls), the unchanged adapter regression (expected failure), and the same nine
tests on the original publication reference. After the final candidate edit run
all owner library tests under no-default/all-features, ordered-field integrations,
consumer budget/cancellation tests, strict affected Clippy/docs/examples/benches
and formatting. Preserve every command/output and original failure. Keep the
candidate on a separate branch and restore clean control4f41bd58 after success.
No merge/admission or new memory exception follows functional success.

One3600second producer window,160directchildren including six preparatory Git
reads,1200seconds per build/check,60Git. Use6buildjobs, offline locked Rust1.95,
isolated RAM Cargo metadata and existing standalone RAM target. Per-command
file bound1GiB, stage bound512MiB, tmpreserve2.5GiB, developmentreserve20GiB.
No automatic retry or deadline reset. Keep queue1621335/start38218939 held and
original watcher3416600 terminal. Runtime and memory campaigns, if justified,
need separately declared windows and complete consumer evidence; previous
historical count charges, adverse timing and all other gates remain intact.
