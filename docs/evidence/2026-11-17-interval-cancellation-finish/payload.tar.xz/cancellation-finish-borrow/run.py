from pathlib import Path
import gzip,hashlib,json,os,resource,shutil,signal,subprocess,time
s=Path(__file__).parent;r=Path('/dev/shm/interval-trace-materialization/csgrs');target=Path('/dev/shm/interval-cancellation-standalone-target');start=time.monotonic();deadline=start+3600;commands=[];names=set();sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];prepared=load(s/'prepared.json');base=prepared['base'];control='4f41bd58415d936968e1955dbd431f0cb5e988f0'
env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='6',CARGO_NET_OFFLINE='true',HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1')
def guard():
 f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();assert time.monotonic()<deadline and len(commands)+prepared['preparation_git_reads']<160;assert shutil.disk_usage('/mnt/development').free>=20*1024**3 and shutil.disk_usage('/tmp').free>=2560*1024**2;assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<512*1024**2

def run(name,args,work=r,cap=1200,expected=0,executable=None,extra_env=None):
 guard();assert name not in names;names.add(name);t=time.monotonic();p=s/(name+'.log');timed=False;child_env=env|(extra_env or {})
 with p.open('wb') as output:
  child=subprocess.Popen(args,cwd=work,env=child_env,executable=executable,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2 if executable else 1024**3,hard)));save('active.json',dict(producer=os.getpid(),child=child.pid,name=name,number=len(commands)+1,aggregate_direct_children=len(commands)+1+prepared['preparation_git_reads'],remaining=deadline-t))
  try:child.wait(timeout=min(cap,deadline-t))
  except BaseException as error:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
   if isinstance(error,subprocess.TimeoutExpired):timed=True
   else:raise
 raw=p.read_bytes();stored=gzip.compress(raw,compresslevel=1,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();c=dict(name=name,command=args,cwd=str(work),executable=executable,environment_additions=extra_env or {},exit_code=child.returncode,expected_exit_code=expected,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_bytes=len(raw),raw_sha256=sha(raw),stored_bytes=len(stored),stored_sha256=sha(stored));commands.append(c);save('commands.json',commands);save('active.json',dict(producer=os.getpid(),child=None));assert child.returncode==expected and not timed,(name,child.returncode,expected);assert not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines());return raw.decode()
def git(name,*args):return run(name,['git',*args],cap=60).strip()
assert not (s/'started.json').exists();guard();save('started.json',dict(time=time.time(),producer=os.getpid(),deadline_seconds=3600,direct_child_limit=160,preparation_git_reads=prepared['preparation_git_reads'],driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes()),prepared_sha256=sha((s/'prepared.json').read_bytes()),environment_overrides={k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','HYPERSOLVE_SKIP_BENCHMARK_REPORTS']}))
try:
 assert git('initial-head','rev-parse','HEAD')==control and git('initial-branch','branch','--show-current')=='interval-trace-materialization' and not git('initial-clean','status','--porcelain=v1')
 git('base-checkout','checkout','--detach',base)
 assert (r/'AGENTS.md').read_bytes()==Path('/mnt/development/csgrs/AGENTS.md').read_bytes()
 for i,v in enumerate(prepared['files']):assert sha((r/v['path']).read_bytes())==v['before_sha256']==sha((s/f'before-{i}.rs').read_bytes());assert sha((s/f'reference-{i}.rs').read_bytes())==v['reference_sha256']
 run('format-regression',['rustup','run','1.95.0','rustfmt','--edition','2024',str(s/'regression.rs')])
 git('witness-branch','checkout','-b','interval-cancellation-finish-witness')
 (r/prepared['files'][1]['path']).write_bytes((s/'reference-1.rs').read_bytes()+b'\n'+(s/'regression.rs').read_bytes())
 (r/prepared['files'][3]['path']).write_bytes((s/'reference-3.rs').read_bytes())
 git('witness-add','add',prepared['files'][1]['path'],prepared['files'][3]['path']);git('witness-commit','commit','-m','Exercise cancelled payload destruction with restored parent budget');witness_revision=git('witness-head','rev-parse','HEAD')
 raw=run('baseline-owner-regressions',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--no-default-features','--lib','cancellation_publication_'],expected=101);assert '3 passed; 6 failed' in raw
 run('baseline-adapter-regression',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypercurve','--test','work_budget','cancellation_at_publication_cannot_escape_as_a_provisional_value'],expected=101)
 git('reference-branch','checkout','-b','interval-cancellation-finish-reference')
 for i in [0,2]:(r/prepared['files'][i]['path']).write_bytes((s/f'reference-{i}.rs').read_bytes())
 p=r/'docs/MIGRATIONS.md';text=p.read_text();assert text.startswith('# Migrations\n\n');p.write_text('# Migrations\n\n'+(s/'migration.md').read_text()+text[len('# Migrations\n\n'):]);git('reference-add','add',*[prepared['files'][i]['path'] for i in [0,2]],'docs/MIGRATIONS.md');git('reference-commit','commit','-m','Retain original publication check as finish-borrow reference');reference_revision=git('reference-head','rev-parse','HEAD')
 raw=run('reference-owner-regressions',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--no-default-features','--lib','cancellation_publication_']);assert '9 passed; 0 failed' in raw
 git('candidate-branch','checkout','-b','interval-cancellation-finish-borrow')
 (r/prepared['files'][0]['path']).write_bytes((s/'candidate-0.rs').read_bytes())
 run('format-before-commit',['cargo','+1.95.0','fmt','--all','--','--check'])
 git('candidate-add','add',prepared['files'][0]['path']);git('candidate-commit','commit','-m','Poll cancellation inside the existing scope finish borrow');revision=git('candidate-head','rev-parse','HEAD');save('candidate.json',dict(base=base,witness_revision=witness_revision,reference_revision=reference_revision,revision=revision,files={v['path']:sha((r/v['path']).read_bytes()) for v in prepared['files']},admitted=False))
 for name,features in [('owner-no-default','--no-default-features'),('owner-all-features','--all-features')]:run(name,['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--lib',features])
 run('owner-resultants',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--test','ordered_field_resultant','--test','ordered_field_resultants'])
 run('adapter-tests',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypercurve','--test','work_budget','--test','cancellation_release'])
 run('owner-clippy',['cargo','+1.95.0','clippy','--locked','--offline','-p','hypersolve','--all-targets','--all-features','--','-D','warnings'])
 run('adapter-clippy',['cargo','+1.95.0','clippy','--locked','--offline','-p','hypercurve','--all-features','--test','work_budget','--test','cancellation_release','--','-D','warnings'])
 run('owner-consumer-docs',['cargo','+1.95.0','doc','--locked','--offline','--no-deps','--all-features','-p','hypersolve','-p','hypercurve'],extra_env={'RUSTDOCFLAGS':'-D warnings'})
 run('owner-examples-benches',['cargo','+1.95.0','check','--locked','--offline','--all-features','--examples','--benches','-p','hypersolve'])
 run('format',['cargo','+1.95.0','fmt','--all','--','--check']);git('whitespace','diff','--check');assert not git('candidate-clean','status','--porcelain=v1');patch=git('candidate-patch','diff',reference_revision,revision,'--',prepared['files'][0]['path']);(s/'candidate.patch').write_text(patch+'\n')
 git('restore-control','checkout','interval-trace-materialization');assert git('restored-head','rev-parse','HEAD')==control and not git('restored-clean','status','--porcelain=v1')
 save('completion.json',dict(exit_code=0,base=base,witness_revision=witness_revision,reference_revision=reference_revision,revision=revision,commands=len(commands),aggregate_direct_children=len(commands)+prepared['preparation_git_reads'],seconds=time.monotonic()-start,source_restored=True,admitted=False));print('Finish-borrow functional qualification complete',flush=True)
except BaseException as error:save('completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),aggregate_direct_children=len(commands)+prepared['preparation_git_reads'],seconds=time.monotonic()-start,automatic_retry=False,admitted=False));raise
finally:save('commands.json',commands)
