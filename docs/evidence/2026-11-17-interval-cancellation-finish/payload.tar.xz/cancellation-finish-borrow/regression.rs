#[test]
fn cancellation_publication_drops_result_after_restoring_parent() {
    struct Returned<'a>(&'a std::cell::Cell<bool>);
    impl Drop for Returned<'_> {
        fn drop(&mut self) {
            assert!(is_active(), "the enclosing budget must remain active");
            assert_eq!(exhaustion(), None, "the cancelled child must be removed");
            consume(WorkKind::RootRefinement, 1).unwrap();
            self.0.set(true);
        }
    }

    let dropped = std::cell::Cell::new(false);
    let outer = with_budget(
        WorkBudget {
            refinements: 1,
            promotions: 0,
        },
        || {
            let token = CancellationToken::new();
            let inner = with_cancellable_budget(WorkBudget::UNLIMITED, &token, || {
                token.cancel();
                Returned(&dropped)
            });
            assert!(
                dropped.get(),
                "the unpublished result must already be dropped"
            );
            assert_eq!(
                inner.result.err(),
                Some(BudgetExceeded {
                    kind: WorkKind::Cancellation,
                    limit: 0,
                    used: 0,
                    requested: 0,
                })
            );
            assert_eq!(inner.usage, WorkUsage::default());
            let fresh = CancellationToken::new();
            let retry = with_cancellable_budget(WorkBudget::ZERO, &fresh, || 61);
            assert_eq!(retry.result, Ok(61));
            assert_eq!(retry.usage, WorkUsage::default());
            assert_eq!(exhaustion(), None);
            67
        },
    );
    assert_eq!(outer.result, Ok(67));
    assert_eq!(outer.usage.refinements, 1);
    assert_eq!(outer.usage.promotions, 0);
    assert!(!is_active());
    assert_eq!(exhaustion(), None);
}
