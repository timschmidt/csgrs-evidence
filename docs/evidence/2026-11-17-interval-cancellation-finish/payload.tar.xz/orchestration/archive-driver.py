from pathlib import Path
import gzip,hashlib,importlib.util,io,json,shutil,subprocess,tarfile,time
root=Path('/tmp/interval-refactor');out=Path('/dev/shm/cancellation-finish-evidence');e=Path('/mnt/development/csgrs-evidence');main=Path('/mnt/development/csgrs');record='docs/evidence/2026-11-17-interval-cancellation-finish';dest=e/record;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());git=lambda *a:subprocess.check_output(['git','-C',str(e),*a]);start=time.monotonic();before=git('rev-parse','HEAD').decode().strip();stages=['cancellation-finish-borrow','cancellation-finish-runtime']
assert not out.exists() and not dest.exists() and not git('status','--porcelain=v1')
assert load(root/'cancellation-finish-borrow/completion.json')['exit_code']==load(root/'cancellation-finish-borrow/verification-command.json')['exit_code']==0
assert load(root/'cancellation-finish-runtime/build-completion.json')['exit_code']==load(root/'cancellation-finish-runtime/build-verification-command.json')['exit_code']==0
assert load(root/'cancellation-finish-runtime/timing-completion.json')['exit_code']==load(root/'cancellation-finish-runtime/analysis-command.json')['exit_code']==0
for stage,marker in [('cancellation-finish-borrow','started.json'),('cancellation-finish-runtime','build-started.json'),('cancellation-finish-runtime','timing-started.json')]:assert not Path('/proc/'+str(load(root/stage/marker)['producer'])).exists()
f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();out.mkdir();members={};origins=[]
def include(p,name):
 raw=p.read_bytes();assert name not in members;members[name]=raw;origins.append(dict(source=str(p),path=name,bytes=len(raw),sha256=sha(raw),mode=p.stat().st_mode&0o777))
for name in stages:
 for p in sorted((root/name).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:include(p,name+'/'+p.relative_to(root/name).as_posix())
for name in ['cancellation-finish-borrow-driver.log','cancellation-finish-runtime-build-driver.log','cancellation-finish-runtime-timing-driver.log']:
 include(root/name,'orchestration/'+name)
for p in sorted((root/'cancellation-standalone-runtime-corrected/consumer').iterdir()):
 if p.is_file():include(p,'consumer/'+p.name)
images=[]
for stage in stages[1:]:
 for b in load(root/stage/'builds.json'):
  v=b['image'];images.append((stage+'-'+b['label']+'-'+b['family'],v['path'],v['bytes'],v['sha256']))
assert len(images)==4
for name,path,length,digest in images:
 p=Path(path);raw=p.read_bytes();assert len(raw)==length and sha(raw)==digest;include(p,'images/'+name)
include(Path(__file__),'orchestration/archive-driver.py')
include(root/'cancellation-standalone-allowance-runtime-archive.json','baseline/prior-archive.json')
with tarfile.open(out/'payload.tar.xz','w:xz',preset=3,format=tarfile.PAX_FORMAT) as archive:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=next(o['mode'] for o in origins if o['path']==name);info.mtime=0;archive.addfile(info,io.BytesIO(raw))
(out/'origins.json.gz').write_bytes(gzip.compress((json.dumps(origins,indent=2)+'\n').encode(),mtime=0))
seen=set()
with tarfile.open(out/'payload.tar.xz','r:xz') as archive:
 for member in archive:
  assert member.isfile() and member.name in members and member.name not in seen;seen.add(member.name);raw=archive.extractfile(member).read();assert raw==members[member.name]
assert seen==members.keys()
for o in origins:assert sha(Path(o['source']).read_bytes())==o['sha256']
(out/'README.md').write_bytes((root/'cancellation-finish-archive-readme.md').read_bytes())
total=sum(p.stat().st_size for p in out.iterdir());free=shutil.disk_usage(e).free;assert free-3*total-20*1024**2>=20*1024**3,(total,free);shutil.copytree(out,dest);subprocess.run(['git','-C',str(e),'add','--sparse','--',record],check=True);subprocess.run(['git','-C',str(e),'diff','--cached','--check'],check=True);changed=git('diff','--cached','--name-only').decode().splitlines();assert changed and all(p.startswith(record+'/') for p in changed)
spec=importlib.util.spec_from_file_location('m',main/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False};rows=m.manifest(str(e),git('write-tree').decode().strip());assert len(rows)==2;subprocess.run(['git','-C',str(e),'commit','-m','Preserve cancellation finish-borrow candidate and runtime screen'],check=True,stdout=subprocess.PIPE);revision=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1') and m.manifest(str(e),revision)==rows;assert git('diff','--name-only',before,revision).decode().splitlines()==changed
for p in out.iterdir():assert git('show',revision+':'+record+'/'+p.name)==p.read_bytes()
_,count,size,digest=rows[1].split('\t');v=dict(previous_revision=before,revision=revision,record=record,row=rows[1],files=int(count),bytes=int(size),sha256=digest,payload_members=len(members),payload_raw_bytes=sum(map(len,members.values())),images=len(images),all_original_and_payload_hashes_verified=True,all_committed_files_verified=True,previous_archive_paths_unchanged=True,seconds=time.monotonic()-start);(root/'cancellation-finish-archive.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
