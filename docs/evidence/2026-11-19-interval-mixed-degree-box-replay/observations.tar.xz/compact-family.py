from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');t=p.read_text()
before='''        } else if let Some(affine) = &analysis.affine_residuals()[constraint_index] {
            let radius = affine_box_radius(analysis, affine, &radius_by_symbol);
            if !radius.definitely_zero() {
                affine_balls.push(CandidateResidualBall { active_row, radius });
            }
        }'''
assert t.count(before)==2
t=t.replace(before,'''        } else if let Some(ball) =
            varying_affine_ball(analysis, constraint_index, active_row, &radius_by_symbol)
        {
            affine_balls.push(ball);
        }''')
idx=t.index('// Preserve the existing quadratic receipts.')
t=t[:idx]+'''fn varying_affine_ball(
    analysis: &ProblemAnalysis<'_>,
    constraint_index: usize,
    active_row: usize,
    radii: &HashMap<SymbolId, Real>,
) -> Option<CandidateResidualBall> {
    if radii.is_empty() {
        return None;
    }
    let affine = analysis.affine_residuals()[constraint_index].as_ref()?;
    let radius = affine_box_radius(analysis, affine, radii);
    (!radius.definitely_zero()).then_some(CandidateResidualBall { active_row, radius })
}

'''+t[idx:]
p.write_text(t)
