use hypersolve::{Problem,Expr,SymbolId,Constraint,VariableBall,IntervalBoxCertificationPackage,certify_interval_box_candidate,certify_quadratic_interval_candidate,certify_multivariate_quadratic_interval_candidate,context_from_problem};
use hyperreal::Real;
use hyperlimit::PredicatePolicy;
fn r(i:i64)->Real{Real::from(i)}
fn univariate_quadratic_problem(row_count: usize) -> Problem {
    let x = Expr::symbol(SymbolId(0), "x");
    let mut problem = Problem::default();
    problem.add_variable("x", r(3));
    for index in 0..row_count {
        let scale = index as i64 + 1;
        problem.add_constraint(Constraint::equality(
            format!("quadratic {index}"),
            x.clone() * x.clone() * Expr::int(scale) - x.clone() * Expr::int(2 * scale)
                + Expr::int(scale),
        ));
    }
    problem
}
fn multivariate_quadratic_problem(row_count: usize) -> Problem {
    let x = Expr::symbol(SymbolId(0), "x");
    let y = Expr::symbol(SymbolId(1), "y");
    let mut problem = Problem::default();
    problem.add_variable("x", r(3));
    problem.add_variable("y", r(5));
    for index in 0..row_count {
        let scale = index as i64 + 1;
        problem.add_constraint(Constraint::equality(
            format!("mixed quadratic {index}"),
            x.clone() * y.clone() * Expr::int(scale) + x.clone().powi(2) * Expr::int(scale + 1)
                - y.clone() * Expr::int(scale + 2)
                + Expr::int(scale),
        ));
    }
    problem
}

#[repr(C)] struct Timespec { sec:i64, ns:i64 }
unsafe extern "C" { fn clock_gettime(clock:i32,t:*mut Timespec)->i32; }
fn now()->i64 { let mut t=Timespec{sec:0,ns:0};assert_eq!(unsafe{clock_gettime(3,&mut t)},0);t.sec*1000000000+t.ns }
fn main(){
 let args=std::env::args().collect::<Vec<_>>();let count=args[2].parse::<usize>().unwrap();
 let p=if args[1]=="multi"{multivariate_quadratic_problem(16)}else{univariate_quadratic_problem(16)};
 let a=p.analyze();let c=context_from_problem(&p);
 let policy=if args[3]=="strict"{PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512};
 macro_rules! run {($call:expr)=>{{
   #[cfg(feature="trace")]{hyperreal::dispatch_trace::reset();let report=$call;let trace=hyperreal::dispatch_trace::take_trace();println!("{report:?}\n{trace:?}");}
   #[cfg(not(feature="trace"))]{for _ in 0..10{drop(std::hint::black_box($call));}let t=now();for _ in 0..count{drop(std::hint::black_box($call));}println!("{}",now()-t);}
 }}}
 match args[1].as_str(){
  "uni"=>run!(certify_quadratic_interval_candidate(&a,&c,&[VariableBall{symbol:SymbolId(0),radius:r(1)}],policy).unwrap()),
  "report"=>run!(certify_interval_box_candidate(&a,&c,&[VariableBall{symbol:SymbolId(0),radius:r(1)}],IntervalBoxCertificationPackage::UnivariateQuadratic,policy)),
  "multi"=>run!(certify_multivariate_quadratic_interval_candidate(&a,&c,&[VariableBall{symbol:SymbolId(0),radius:r(1)},VariableBall{symbol:SymbolId(1),radius:r(1)}],policy).unwrap()),_=>unreachable!()
 }
}
