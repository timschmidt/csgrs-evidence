from pathlib import Path
p=Path('crates/hypersolve/src/certification.rs')
t=p.read_text();start=t.index('    let mut report = certify_candidate(analysis, context);',t.index('pub fn certify_candidate_with_residual_balls'));end=t.index('\nfn normalize_residual',start)
block=t[start:end]
assert 'for ball in balls {' in block
block=block.replace('    let mut report = certify_candidate(analysis, context);','''    let mut report = certify_candidate(analysis, context);
    apply_residual_balls(&mut report, balls, policy);
    report
}

pub(crate) fn apply_residual_balls(
    report: &mut CandidateCertificationReport,
    balls: &[CandidateResidualBall],
    policy: PredicatePolicy,
) {''').replace('recompute_report_counts(&mut report);\n    report','recompute_report_counts(report);')
p.write_text(t[:start]+block+t[end:])
p=Path('crates/hypersolve/src/interval.rs');t=p.read_text()
start=t.index('            let mut radius = Real::zero();',t.index('pub fn certify_affine_interval_candidate'));end=t.index('            residual_balls.push',start)
body=t[start:end]
t=t[:start]+'''            let radius = affine_box_radius(analysis, affine, &radius_by_symbol);
'''+t[end:]
ix=t.index('/// Certify a candidate interval box and retain')
t=t[:ix]+'''fn affine_box_radius(
    analysis: &ProblemAnalysis<'_>,
    affine: &crate::AffineResidual,
    radius_by_symbol: &HashMap<SymbolId, Real>,
) -> Real {
'''+ '\n'.join(line[8:] for line in body.rstrip().splitlines())+'''
    radius
}

'''+t[ix:]
old='''            residual_balls.push(CandidateResidualBall { active_row, radius });
        }
        active_row += 1;'''
new='''            residual_balls.push(CandidateResidualBall { active_row, radius });
        } else if let Some(affine) = &analysis.affine_residuals()[constraint_index] {
            let radius = affine_box_radius(analysis, affine, &radius_by_symbol);
            if !radius.definitely_zero() {
                affine_balls.push(CandidateResidualBall { active_row, radius });
            }
        }
        active_row += 1;'''
start=t.index('pub fn certify_quadratic_interval_candidate')
end=t.index('fn validate_variable_balls',start)
sub=t[start:end]
assert sub.count(old)==2
sub=sub.replace('let mut residual_balls = Vec::new();','let mut residual_balls = Vec::new();\n    let mut affine_balls = Vec::new();').replace(old,new)
old='''    if residual_balls.is_empty() {
        return Ok(certify_candidate(analysis, context));
    }
    Ok(certify_candidate_with_residual_balls(
        analysis,
        context,
        &residual_balls,
        policy,
    ))'''
assert sub.count(old)==2
sub=sub.replace(old,'''    Ok(certify_mixed_degree_balls(analysis, context, &residual_balls, &affine_balls, policy))''')
sub+='''// Preserve the existing quadratic receipts. An affine row with a varying
// residual needs evidence for the whole interval, even if its center is zero.
fn certify_mixed_degree_balls(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    quadratic_balls: &[CandidateResidualBall],
    affine_balls: &[CandidateResidualBall],
    policy: PredicatePolicy,
) -> crate::CandidateCertificationReport {
    let mut report = if quadratic_balls.is_empty() {
        certify_candidate(analysis, context)
    } else {
        certify_candidate_with_residual_balls(analysis, context, quadratic_balls, policy)
    };
    if !affine_balls.is_empty() {
        crate::certification::apply_residual_balls(&mut report, affine_balls, policy.certified_only());
    }
    report
}

'''
p.write_text(t[:start]+sub+t[end:])
