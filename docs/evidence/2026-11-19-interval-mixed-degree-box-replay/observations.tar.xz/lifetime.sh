set -eu
for v in base family; do
 if [ "$v" = family ]; then git -C "$s/mem-tree" switch -q --detach interval-quadratic-affine-enclosures; fi
 for tc in stable 1.95.0; do (
   export CARGO_TARGET_DIR="$s/mem-$tc" CARGO_BUILD_JOBS=4
   for b in lifetime usable; do
     cargo +"$tc" run --release --locked --manifest-path "$s/lifetime-src/$b/Cargo.toml" > "$s/$v-$tc-$b.txt" 2> "$s/logs/$v-$tc-$b.build" || exit 1
   done
 ) & done
 wait
 for tc in stable 1.95.0; do test "$(wc -l < "$s/$v-$tc-usable.txt")" = 72; done
done
