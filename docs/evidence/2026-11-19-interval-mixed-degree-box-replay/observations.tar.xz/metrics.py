from pathlib import Path
import hashlib,io,json,re,subprocess,sys
d=Path(__file__).resolve().parent
def leb(f):
 n=k=0
 while True:
    b=f.read(1)[0];n|=(b&127)<<k
    if b<128:return n
    k+=7
def metrics(p):
 raw=p.read_bytes()
 v={'file':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if raw[:4]==b'\x00asm':
    f=io.BytesIO(raw);f.read(8)
    while kind:=f.read(1):
        size=leb(f);block=io.BytesIO(f.read(size))
        if kind==b'\x0a':
            v['code']=size
            count=leb(block);body_sum=0
            for _ in range(count):
                n=leb(block);body_sum+=n;assert len(block.read(n))==n
            assert block.read()==b'';v['functions']=body_sum
 else:
    v['code']=int(re.search(r'^\.text\s+(\d+)',subprocess.check_output(['size','-A',p],text=True),re.M)[1])
    ranges=[]
    for ln in subprocess.check_output(['nm','-S','--radix=d','--defined-only',p],text=True).splitlines():
        x=ln.split(maxsplit=3)
        if len(x)==4 and x[2] in ('t','T'):ranges.append((int(x[0]),int(x[0])+int(x[1])))
    hi=total=0
    for a,b in sorted(ranges):
        total+=max(0,b-max(hi,a));hi=max(b,hi)
    v['functions']=total
 return v
