import json,os,sys
from pathlib import Path
s=Path(os.environ['s']);phase=sys.argv[1]
out={}; issues=[]
for tc in ['1.95.0','stable']:
 for arch in ['native','wasi']:
  load=lambda v:json.loads((s/f'{v}-{tc}-{arch}.json').read_text())
  b=load('base');a=load(phase)
  assert set(b)<=set(a)
  for name,v in a.items():
   key='/'.join([tc,arch,name])
   post={k:v[k] for k in ['file','code','functions']};o=out[key]={'current':post,'slot_remaining':64*1024**2-v['file']}
   assert o['slot_remaining']>=16*1024**2
   if name not in b:continue
   before=b[name];delta=o['delta']={k:v[k]-before[k] for k in post}
   bs=before.get('sections',{});cs=v.get('sections',{})
   secs=o['allocated_section_deltas']={k:cs.get(k,0)-bs.get(k,0) for k in sorted(set(bs)|set(cs)) if bs.get(k,0)!=cs.get(k,0)}
   for k,step in (delta|secs).items():
    if step<=0: continue
    den=before[k] if k in post else bs.get(k,0)
    max_b,rate=(1024,5) if arch=='wasi' else (1024,.5) if k=='functions' else (4096,1)
    if step>max_b or step*100>rate*den:
     issues.append(dict(target=key,metric=k,before=den,increment=step,absolute_limit=max_b,percent_limit=rate))
(s/f'{phase}-comparison.json').write_text(json.dumps({'targets':out,'step_failures':issues},indent=2)+'\n')
print(len(out),'targets,',len(issues),'failed step metrics on',len(set(i['target'] for i in issues)),'commands')
for arch in ['native','wasi']:
 rows=[i for i in issues if '/'+arch+'/' in i['target']]
 print(arch, len(rows),'metric failures')
 for r in sorted(rows,key=lambda i:-i['increment'])[:5]:print(r)
