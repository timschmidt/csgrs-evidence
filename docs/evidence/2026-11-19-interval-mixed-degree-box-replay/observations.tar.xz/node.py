import base64,hashlib,json,os,tarfile,urllib.request
from pathlib import Path
s=Path(os.environ['s']);url='https://registry.npmjs.org/node-linux-x64/24.22.3'
dist=json.load(urllib.request.urlopen(url))['dist'];path=s/'tmp/node.tgz'
urllib.request.urlretrieve(dist['tarball'],path)
assert 'sha512-'+base64.b64encode(hashlib.sha512(path.read_bytes()).digest()).decode()==dist['integrity']
with tarfile.open(path) as t:(s/'node/node').write_bytes(t.extractfile('package/bin/node').read())
(s/'node/node').chmod(0o755);path.unlink()
