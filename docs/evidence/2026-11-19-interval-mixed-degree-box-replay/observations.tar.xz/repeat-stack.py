import ast,concurrent.futures,json,os,pathlib,subprocess,time
s=pathlib.Path(os.environ['s'])
def run(job):
 tag,tc,idx=job
 p=s/f'stack-{tag}-{tc}'
 while not p.exists():time.sleep(2)
 res=subprocess.run([p],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 stack={};heap={};free=[]
 for line in res.stdout.splitlines():
  a=line.split('|')
  if a[0]=='STACK': stack['/'.join(a[1:3])]=max(int(a[-1]),stack.get('/'.join(a[1:3]),0))
  else:heap[a[1]]=ast.literal_eval(a[-1])
 for line in res.stderr.splitlines():
  if line.startswith('HEADROOM '):free.append(int(line.split()[-1]))
 assert len(heap)==72 and len(stack)==144 and len(free)==288
 return {'toolchain':tc,'variant':tag,'repeat':idx,'stack':stack,'heap':heap,'minimum_free':min(free)}
jobs=[]
for i in range(24):
 for tc in ['1.95.0','stable']:
  for tag in (['base','sparse'] if i%2==0 else ['sparse','base']):jobs.append((tag,tc,i))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,jobs))
(s/'stack-repeat.json').write_text(json.dumps(rows,separators=(',',':'))+'\n')
out={}
for tc in ['1.95.0','stable']:
 sets=[[r for r in rows if r['toolchain']==tc and r['variant']==t] for t in ['base','sparse']]
 assert all(len(v)==24 for v in sets)
 account={}
 for key in sets[0][0]['stack']:
  b,a=[max(r['stack'][key] for r in v) for v in sets]
  account[key]=[b,a,a-b]
 room=[min(r['minimum_free'] for r in v) for v in sets]
 heap=[]
 for i in range(72):
  peaks=[max(r['heap'][str(i)][-2] for r in v) for v in sets]
  assert all(r['heap'][str(i)][-1]==0 for v in sets for r in v)
  heap.append(peaks)
 out[tc]={'stack':account,'minimum_remaining_stack':room,'heap_peaks':heap}
 for n,ids in [('registered',range(60)),('mixed',range(60,72))]:
  vals=[account[f'{i}/{w}'] for i in ids for w in [0,1]]
  failures=[v for v in vals if v[2]>min(v[0]/100,128)]
  print(tc,n,'max increase',max(v[-1] for v in vals),'past incremental limit',len(failures),'min remaining',room,'peak requested differences',set(heap[i][1]-heap[i][0] for i in ids))
(s/'stack-repeat-summary.json').write_text(json.dumps(out,indent=2)+'\n')
