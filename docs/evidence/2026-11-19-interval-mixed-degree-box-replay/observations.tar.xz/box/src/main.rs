use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::g1_join_problem;
use hypersolve::{certify_interval_box_candidate, context_from_problem, IntervalBoxCertificationPackage as Package, IntervalBoxCertificationStatus as Status, VariableBall};
fn axial(x: i32) -> Point2 { Point2::new(x.into(), 0.into()) }

fn main() {
    let mut failures = 0;
    let mut rows = 0;
    for target in [-3, 2] {
        let join = g1_join_problem(axial(0), axial(0), axial(0), axial(target));
        let analysis = join.problem.analyze();
        let mut context = context_from_problem(&join.problem);
        for center in [-3, -1, 0, 1, 3] {
            context.bind(join.tangent_x_symbol, center.into());
            for radius in [0, 2] {
                let lo = target * (center - radius);
                let hi = target * (center + radius);
                let expected = if lo.min(hi) > 0 { Status::Certified } else if lo.max(hi) <= 0 { Status::Violation } else { Status::Unknown };
                let balls = [VariableBall { symbol: join.tangent_x_symbol, radius: radius.into() }];
                for package in [Package::Affine, Package::UnivariateQuadratic, Package::MultivariateQuadratic] {
                    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
                        let r = certify_interval_box_candidate(&analysis, &context, &balls, package, policy);
                        let proof = r.certification.as_ref().unwrap();
                        let valid = r.status == expected && proof.rows.len() == 4 && proof.all_satisfied() == (expected == Status::Certified) && proof.has_certified_violation() == (expected == Status::Violation);
                        rows += 1;
                        if !valid { failures += 1; println!("{package:?} {policy:?} target={target} center={center} r={radius} expected {expected:?}, got {:?}", r.status); }
                    }
                }
            }
        }
    }
    println!("{rows} whole-box G1 outcomes; {failures} incorrect");
    assert_eq!(failures, 0);
}
