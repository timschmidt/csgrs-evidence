import subprocess
from pathlib import Path
p=Path('crates/hypersolve/src/certification.rs');t=subprocess.check_output(['git','show','4c4385b48:'+str(p)],text=True)
i=t.index('    let mut report = certify_candidate(analysis, context);',t.index('pub fn certify_candidate_with_residual_balls'))
j=t.index('    recompute_report_counts(&mut report);',i)
body=t[i:j].split('    for ball in balls {',1)[1]
assert body.endswith('\n    }\n')
t=t[:i]+'''    certify_ball_groups(analysis, context, balls, &[], policy)
}

pub(crate) fn certify_ball_groups(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    balls: &[CandidateResidualBall],
    certified_balls: &[CandidateResidualBall],
    policy: PredicatePolicy,
) -> CandidateCertificationReport {
    let mut report = certify_candidate(analysis, context);
    for (group, policy) in [(balls, policy), (certified_balls, policy.certified_only())] {
        for ball in group {'''+ '\n'.join('    '+line if line.strip() else line for line in body[:-len('\n    }\n')].split('\n'))+'''
        }
    }
'''+t[j:]
p.write_text(t)
p=Path('crates/hypersolve/src/interval.rs');t=p.read_text()
i=t.index('fn certify_mixed_degree_balls(');j=t.index('fn validate_variable_balls(',i)
t=t[:i]+'''fn certify_mixed_degree_balls(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    mut balls: Vec<CandidateResidualBall>,
    radii: &HashMap<SymbolId, Real>,
    policy: PredicatePolicy,
) -> crate::CandidateCertificationReport {
    let quadratic_count = balls.len();
    if !radii.is_empty() && analysis.facts().affine_form_active_rows != 0
        && analysis.facts().structural_jacobian_nonzeros != 0
    {
        append_varying_affine_balls(analysis, radii, &mut balls);
    }
    if balls.is_empty() {
        return certify_candidate(analysis, context);
    }
    let (quadratic, affine) = balls.split_at(quadratic_count);
    crate::certification::certify_ball_groups(analysis, context, quadratic, affine, policy)
}

#[inline(never)]
fn append_varying_affine_balls(
    analysis: &ProblemAnalysis<'_>,
    radii: &HashMap<SymbolId, Real>,
    balls: &mut Vec<CandidateResidualBall>,
) {
    for (active_row, (constraint, affine)) in analysis.problem().constraints.iter()
        .zip(analysis.affine_residuals()).filter(|(constraint, _)| constraint.active).enumerate() {
        if let Some(affine) = affine && !affine.is_constant() {
            let radius = affine_box_radius(analysis, affine, radii);
            if !radius.definitely_zero() {
                balls.push(CandidateResidualBall { active_row, radius });
            }
        }
    }
}

'''+t[j:]
t=t.replace('(active_row, (constraint, affine))','(active_row, (_, affine))')
t=t.replace('        &residual_balls,\n        &radius_by_symbol,','        residual_balls,\n        &radius_by_symbol,')
p.write_text(t)
