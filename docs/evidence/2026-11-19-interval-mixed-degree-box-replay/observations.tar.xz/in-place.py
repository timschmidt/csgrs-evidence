from pathlib import Path
import subprocess
p=Path('crates/hypersolve/src/certification.rs');t=subprocess.check_output(['git','show','HEAD:'+str(p)],text=True)
start=t.index('        let Some(center) = row.signed_residual.as_ref() else {');end=t.index('\n    }\n    recompute_report_counts',start)
body=t[start:end].replace('            continue;','            return;').replace('&ball.radius','radius')
t=t[:start]+'''        apply_residual_ball(row, &ball.radius, policy);'''+t[end:]
idx=t.index('fn normalize_residual')
t=t[:idx]+'''pub(crate) fn apply_residual_ball(
    row: &mut CertifiedCandidateRow,
    radius: &Real,
    policy: PredicatePolicy,
) {
'''+ '\n'.join(line[4:] if line.startswith('    ') else line for line in body.splitlines())+'\n}\n\n'+t[idx:]
t=t.replace('fn recompute_report_counts(', 'pub(crate) fn recompute_report_counts(')
p.write_text(t)
p=Path('crates/hypersolve/src/interval.rs');t=p.read_text()
t=t.replace('    let mut affine_balls = Vec::new();\n','')
old='''        } else if let Some(ball) =
            varying_affine_ball(analysis, constraint_index, active_row, &radius_by_symbol)
        {
            affine_balls.push(ball);
        }'''
assert t.count(old)==2
t=t.replace(old,'        }').replace('        &affine_balls,','        &radius_by_symbol,')
i=t.index('fn varying_affine_ball(');j=t.index('// Preserve the existing quadratic receipts.',i);t=t[:i]+t[j:]
t=t.replace('    affine_balls: &[CandidateResidualBall],','    radii: &HashMap<SymbolId, Real>,')
i=t.index('    if !affine_balls.is_empty()');j=t.index('\n    report\n}',i)
t=t[:i]+'''    if radii.is_empty() || analysis.facts().affine_form_active_rows == 0 {
        return report;
    }
    let mut changed = false;
    for row in &mut report.rows {
        if let Some(affine) = &analysis.affine_residuals()[row.constraint_index] {
            let radius = affine_box_radius(analysis, affine, radii);
            if !radius.definitely_zero() {
                crate::certification::apply_residual_ball(row, &radius, policy.certified_only());
                changed = true;
            }
        }
    }
    if changed {
        crate::certification::recompute_report_counts(&mut report);
    }'''+t[j:]
p.write_text(t)
