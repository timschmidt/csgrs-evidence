import collections, json, os, re
from pathlib import Path
s=Path(os.environ['s'])
def read(name):return json.loads((s/name).read_text())
def hash_rows(tc,phase):
 return read(f'{phase}-runs-{tc}/report.json')
checks={}
for phase in ['base','strict','family','sparse']:
 for tc in ['1.95.0','stable']:
  guest=s/f'{phase}-runs-{tc}/report.json';log=s/f'logs/{phase}-native-runs-{tc}'
  if not guest.is_file() or not log.is_file():continue
  r=hash_rows(tc,phase);ordinary={}
  for chunk in re.split(r'^\s*Running ',log.read_text(),flags=re.M)[1:]:
   suite=chunk.partition(' (')[0].strip(); names=re.findall(r'^test ([^\s]+) \.\.\. ok\s*$',chunk,re.M)
   result=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',chunk,re.M)
   if not result: continue
   n,fail,ignore=map(int,result[-1]);assert fail==0 and ignore==0
   ordinary[suite]=n
  checks[f'{phase}/{tc}']={'direct_guest_tests':sum(map(len,r['guest'].values())),'guest_suites':len(r['guest']),'fresh_parents':sum(map(len,r['fresh_replays'].values())),'fresh_child_calls':sum(sum(x.values()) for x in r['fresh_replays'].values()),'host_only':sum(map(len,r['host_only'].values())),'dispatch_windows':sum(r['dispatch_windows'].values()),'native_ordinary':ordinary,'native_total':sum(ordinary.values())}
  if phase!='base':
   before=hash_rows(tc,'base')
   for cat in ['fresh_replays','host_only','dispatch_windows','replay_records']:
    assert before[cat]==r[cat],cat
   for n,vals in before['guest'].items():assert vals==r['guest'][n],n
(s/'run-totals.json').write_text(json.dumps(checks,indent=2)+'\n')
for k,v in checks.items():print(k,v['native_total'],len(v['native_ordinary']),v['direct_guest_tests'],v['guest_suites'],v['fresh_child_calls'])
