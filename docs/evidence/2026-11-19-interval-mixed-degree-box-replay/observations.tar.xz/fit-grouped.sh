set -eu
until [ -f "$s/fit-sparse-stable-wasi.json" ] && [ -f "$s/fit-sparse-1.95.0-wasi.json" ] && [ "$(git -C "$s/family" branch --show-current)" = interval-quadratic-affine-enclosures ]; do sleep 3; done
git -C "$s/family" switch -q --detach interval-quadratic-affine-ball-groups
for tc in stable 1.95.0; do python3 "$s/fit.py" "$tc" grouped > "$s/logs/fit-grouped-$tc" 2>&1 & done
wait
git -C "$s/family" switch -q interval-quadratic-affine-enclosures
