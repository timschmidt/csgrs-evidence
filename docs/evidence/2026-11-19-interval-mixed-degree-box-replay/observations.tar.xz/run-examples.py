import json,os,subprocess,sys
from pathlib import Path
s=Path(os.environ['s']);phase=sys.argv[1]
for tc in ['stable','1.95.0']:
 for name in ['basic','enclosed_program','krawczyk_certificate','owned_program']:
  outputs={}
  for arch in ['native','wasi']:
   bins=json.loads((s/f'{phase}-{tc}-{arch}-bins.json').read_text());p=bins['example/'+name]
   cmd=[p] if arch=='native' else ['node',str(s/'tree/crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),p]
   with (s/f'logs/{phase}-examples-warnings').open('ab') as err:
    v=subprocess.check_output(cmd,cwd=s/'tree/crates/hypersolve',stderr=err)
   (s/f'logs/{phase}-{tc}-{arch}-example-{name}').write_bytes(v)
   outputs[arch]=v
  assert outputs['native']==outputs['wasi'],(tc,name)
print(phase,'16 native and WASI release example executions matched')
