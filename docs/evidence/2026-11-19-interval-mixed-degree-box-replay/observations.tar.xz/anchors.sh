set -eu
export CARGO_TARGET_DIR="$s/anchor-target" CARGO_BUILD_JOBS=6
for tag in fixed registered; do
 if [ "$tag" = fixed ]; then ref=c9f1f9ac5; else ref=4d4b472e6; fi
 git -C "$s/mem-tree" switch -q --detach "$ref"
 cargo +1.95.0 build --release --locked --manifest-path "$s/lifetime-src/lifetime/Cargo.toml" > "$s/logs/$tag-anchor-build" 2>&1
 ln "$CARGO_TARGET_DIR/release/radius-lifetime" "$s/anchor-$tag"
done
git -C "$s/mem-tree" switch -q interval-quadratic-affine-sparse
