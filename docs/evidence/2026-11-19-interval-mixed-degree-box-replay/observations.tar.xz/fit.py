import concurrent.futures,json,os,pathlib,re,subprocess,sys
from metrics import metrics
s=pathlib.Path(os.environ['s']);tc,phase=sys.argv[1:]
env=os.environ|{'CARGO_TARGET_DIR':str(s/('family-target' if tc=='stable' else 'family-bench-'+tc)),'CARGO_BUILD_JOBS':'5','CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':f'--sysroot {s}/sysroot-{tc}'}
for arch in ['native','wasi']:
 cmd=['cargo','+'+tc,'build','--locked','--release','-p','hypersolve','--all-features','--test','real_representations','--test','interval_quadratic_extrema','--test','smoke','--bench','certification','--message-format=json-render-diagnostics']
 if arch=='wasi':cmd+=['--target','wasm32-wasip1']
 name=f'fit-{phase}-{tc}-{arch}'
 with (s/f'logs/{name}.jsonl').open('w') as out,(s/f'logs/{name}.build').open('w') as err:subprocess.run(cmd,cwd=s/'family',env=env,stdout=out,stderr=err,check=True)
 bins={r['target']['name']:r['executable'] for l in (s/f'logs/{name}.jsonl').read_text().splitlines() if (r:=json.loads(l)).get('executable')}
 assert len(bins)==4
 data={}
 for n,file in bins.items():
  p=pathlib.Path(file);v=data[n]=metrics(p)
  if arch=='native':
   txt=subprocess.check_output(['readelf','-WS',p],text=True)
   v['sections']={m[1]:int(m[2],16) for l in txt.splitlines() if (m:=re.search(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\w+)',l)) and 'A' in m[3]}
   if phase=='sparse' and n=='certification':os.link(p,s/('bench-sparse-'+tc))
 (s/f'{name}.json').write_text(json.dumps(data,indent=2)+'\n')
