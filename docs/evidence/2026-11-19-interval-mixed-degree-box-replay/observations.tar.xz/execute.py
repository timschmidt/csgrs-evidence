import json, os, runpy, sys
from pathlib import Path
s=Path(os.environ['s']);phase,tc=sys.argv[1:]
root=s/'tree/crates/hyperinterval/conformance'
sys.path.insert(0,str(root))
import wasi_libtest
def from_release_build(cargo,selection,env):
    assert cargo[0:3]==['cargo','+'+tc,'test'] and '--all-features' in cargo and selection==['--lib','--tests']
    arch='wasi' if 'wasm32-wasip1' in cargo else 'native'
    saved=json.loads((s/f'{phase}-{tc}-{arch}-bins.json').read_text())
    return {key.split('/',1)[1]:v for key,v in saved.items() if key.startswith(('lib/','test/'))}
wasi_libtest.build_tests=from_release_build
sys.argv=[str(root/'wasi-solver.py'),'--toolchain',tc,'--output',str(s/f'{phase}-runs-{tc}')]
runpy.run_path(sys.argv[0],run_name='__main__')
