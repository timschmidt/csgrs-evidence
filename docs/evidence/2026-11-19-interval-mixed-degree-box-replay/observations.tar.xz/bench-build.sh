set -eu
cd "$s/family"
for tag in family base; do
  if [ "$tag" = base ]; then git switch --quiet --detach 4c4385b48; fi
  for tc in stable 1.95.0; do (
    export CARGO_TARGET_DIR="$s/family-bench-$tc" CARGO_BUILD_JOBS=5
    if [ "$tc" = stable ]; then export CARGO_TARGET_DIR="$s/family-target"; fi
    cargo +"$tc" build --release --locked -p hypersolve --all-features --bench certification --message-format=json-render-diagnostics > "$s/logs/bench-$tag-$tc.jsonl" 2> "$s/logs/bench-$tag-$tc.build"
    python3 - "$tag" "$tc" <<'PY'
import json,sys,os,pathlib
s=pathlib.Path(os.environ['s']);tag,tc=sys.argv[1:]
rows=[json.loads(l) for l in (s/f'logs/bench-{tag}-{tc}.jsonl').read_text().splitlines()]
bin,=[r['executable'] for r in rows if r.get('executable')]
os.link(bin,s/f'bench-{tag}-{tc}')
PY
  ) & done
  wait
  test -x "$s/bench-$tag-stable" && test -x "$s/bench-$tag-1.95.0"
done
git switch --quiet interval-quadratic-affine-enclosures
