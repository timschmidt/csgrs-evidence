set -eu
for tag in base sparse; do
 if [ "$tag" = base ]; then rev=4c4385b48; else rev=interval-quadratic-affine-sparse; fi
 git -C "$s/family" switch -q --detach "$rev"
 for tc in stable 1.95.0; do python3 "$s/fit.py" "$tc" "$tag" > "$s/logs/fit-$tag-$tc" 2>&1 & done
 wait
 for tc in stable 1.95.0; do test -s "$s/fit-$tag-$tc-wasi.json"; done
done
git -C "$s/family" switch -q interval-quadratic-affine-enclosures
