from pathlib import Path
import subprocess,hashlib,sys,tomllib,os
s=Path(os.environ['s'])
for tool in ('1.95.0','stable'):
 root=Path(subprocess.check_output(['rustc','+'+tool,'--print','sysroot'],text=True).strip())
 entry=tomllib.loads((root/'lib/rustlib/multirust-channel-manifest.toml').read_text())['pkg']['rust-std']['target']['wasm32-wasip1']
 dest=s/('sysroot-'+tool)/'lib/rustlib';dest.mkdir(parents=True,exist_ok=True)
 name='wasm32-wasip1'
 for p in (root/'lib/rustlib').iterdir():
  if p.name!=name and not (dest/p.name).exists():(dest/p.name).symlink_to(p)
 if (dest/name).exists():continue
 archive=s/entry['xz_url'].split('/')[-1]
 subprocess.run(['curl','--fail','-sS','--retry','2','--max-time','45','-o',archive,entry['xz_url']],check=True)
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==entry['xz_hash']
 prefix=archive.name.removesuffix('.tar.xz')+'/rust-std-'+name+'/lib/rustlib/'+name
 subprocess.run(['tar','xJf',archive,'-C',dest,'--strip-components=4',prefix],check=True)
 assert (dest/name/'lib').is_dir()
