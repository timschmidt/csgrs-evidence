import json,os,pathlib,statistics,subprocess,sys,time
s=pathlib.Path(os.environ['s']);tc,core=sys.argv[1:];rows=[]
for variant in ['sparse','family']:
 for tag in ['base',variant]:
  while not (s/f'clock-{tag}-{tc}-plain').exists():time.sleep(2)
 for case in ['uni','report','multi']:
  for policy in ['strict','approximate']:
   times=[]
   for i in range(8):
    labels=['control',variant,'base'] if i%2==0 else ['base',variant,'control'];r={}
    for label in labels:
     exe=s/f'clock-{"base" if label=="control" else label}-{tc}-plain'
     val=subprocess.check_output(['taskset','-c',core,exe,case,'300',policy],text=True);r[label]=int(val)
    times.append(r)
   deltas=[100*(r[variant]/((r['base']+r['control'])/2)-1) for r in times]
   spread=[100*abs(r['base']-r['control'])/((r['base']+r['control'])/2) for r in times]
   rows.append({'variant':variant,'case':case,'policy':policy,'triples_ns':times,'median_percent':statistics.median(deltas),'median_control_spread':statistics.median(spread)})
(s/f'paired-cpu-{tc}.json').write_text(json.dumps(rows,indent=2)+'\n')
