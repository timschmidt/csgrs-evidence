import hashlib,json,os,re
from pathlib import Path
s=Path(os.environ['s']);out={}
for tag in ['strict','family','sparse']:
 p=s/f'{tag}-comparison.json'
 if not p.exists():continue
 d=json.loads(p.read_text());data={}
 for tc in ['1.95.0','stable']:
  for arch in ['native','wasi']:
   group=f'{tc}/{arch}'
   items={k:v for k,v in d['targets'].items() if k.startswith(group+'/') and 'delta'in v}
   issues=[r for r in d['step_failures'] if r['target'] in items]
   assert len(items)==88
   data[group]={'pairs':len(items),'screen_failures':len(issues),'affected_commands':len({r['target'] for r in issues}),'max_delta':{k:max(r['delta'][k] for r in items.values()) for k in ['file','code','functions']},'minimum_free_slot':min(r['slot_remaining'] for r in items.values())}
 out[tag]=data
for tag in ['base','sparse','grouped']:
 data={}
 for tc in ['1.95.0','stable']:
  for arch in ['native','wasi']:
   p=s/f'fit-{tag}-{tc}-{arch}.json'
   if not p.exists():continue
   a=json.loads(p.read_text());b=json.loads((s/f'fit-base-{tc}-{arch}.json').read_text())
   data[f'{tc}/{arch}']={n:[v[k]-b[n][k] for k in ['file','code','functions']] for n,v in a.items()}
 out['fit-'+tag]=data
traces={}
for tc in ['1.95.0','stable']:
 for tag in ['family','sparse']:
  results={}
  for w in ['uni','report','multi']:
   for policy in ['strict','approximate']:
    k=f'{w}-{policy}';paths=[s/f'logs/trace-{v}-{tc}-{k}' for v in ['base',tag]]
    if not all(p.is_file() for p in paths): continue
    base,cand=[p.read_bytes() for p in paths]
    assert b'TraceSnapshot' in base and len(base)>1000
    results[k]={'match':base==cand,'base_sha256':hashlib.sha256(base).hexdigest(),'trial_sha256':hashlib.sha256(cand).hexdigest(),'bytes':len(cand)}
  traces[f'{tag}/{tc}']=results
out['unchanged_traces']=traces
(s/'qualification-summary.json').write_text(json.dumps(out,indent=2)+'\n')
print([(k,len(v),sum(x['match'] for x in v.values())) for k,v in traces.items()])
