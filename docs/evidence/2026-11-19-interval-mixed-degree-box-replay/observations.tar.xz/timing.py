import json,os,statistics,subprocess,sys
from pathlib import Path
s=Path(os.environ['s']);tc,core,trial=sys.argv[1:];names=['certify_quadratic_interval_rows','certify_interval_box_candidate_report','certify_multivariate_quadratic_interval_rows']
rows=[]
for i in range(6):
 result={}
 for tag in (['control',trial,'base'] if i%2==0 else ['base',trial,'control']):
  home=s/'timing'/trial/tc/str(i)/tag;home.mkdir(parents=True,exist_ok=True)
  env=os.environ|{'CRITERION_HOME':str(home),'RAYON_NUM_THREADS':'1'}
  with (home/'log').open('w') as log:
   subprocess.run(['taskset','-c',core,str(s/f'bench-{tag if tag!="control" else "base"}-{tc}'),'--bench','^('+'|'.join(names)+')$','--noplot','--warm-up-time','0.13','--measurement-time','0.32','--sample-size','20','--nresamples','2000'],cwd=s,env=env,stdout=log,stderr=log,check=True)
  result[tag]={}
  for n in names:
   d=json.loads((home/n/'new/sample.json').read_text())
   result[tag][n]=statistics.median(t/k for t,k in zip(d['times'],d['iters']))
 rows.append(result)
decoded={}
for n in names:
 ds=[(r[trial][n]/((r['control'][n]+r['base'][n])/2)-1)*100 for r in rows]
 controls=[abs(r['control'][n]/r['base'][n]-1)*100 for r in rows]
 decoded[n]={'median_percent':statistics.median(ds),'pair_deltas':ds,'median_absolute_control_spread':statistics.median(controls)}
(s/f'timing-{trial}-{tc}.json').write_text(json.dumps({'rows':rows,'differences':decoded},indent=2)+'\n')
