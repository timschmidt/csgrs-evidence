set -eu
for v in sparse base family; do
 case $v in
 sparse) ref=interval-quadratic-affine-sparse;;
 base) ref=4c4385b48;;
 family) ref=interval-quadratic-affine-enclosures;;
 esac
 git -C "$s/mem-tree" switch -q --detach "$ref"
 for tc in stable 1.95.0; do (
  set -eu
  export CARGO_TARGET_DIR="$s/mem-$tc" CARGO_BUILD_JOBS=4
  cargo +"$tc" build --release --manifest-path "$s/lifetime-src/lifetime/Cargo.toml" > "$s/logs/stack-repeat-$v-$tc.build" 2>&1
  ln "$CARGO_TARGET_DIR/release/radius-lifetime" "$s/stack-$v-$tc"
  for mode in plain trace; do
   args=()
   if [ "$mode" = trace ]; then args=(--features trace); fi
   cargo +"$tc" build --release --manifest-path "$s/time-client/Cargo.toml" "${args[@]}" > "$s/logs/thread-time-build-$v-$tc-$mode" 2>&1
   ln "$CARGO_TARGET_DIR/release/measure-box-replay" "$s/clock-$v-$tc-$mode"
   if [ "$mode" = trace ]; then
    for w in uni report multi; do for p in strict approximate; do
     "$s/clock-$v-$tc-$mode" "$w" 1 "$p" > "$s/logs/trace-$v-$tc-$w-$p"
    done; done
   fi
  done
 ) & done
 wait
 for tc in stable 1.95.0; do test -s "$s/logs/trace-$v-$tc-multi-approximate"; done
done
git -C "$s/mem-tree" switch -q interval-quadratic-affine-sparse
