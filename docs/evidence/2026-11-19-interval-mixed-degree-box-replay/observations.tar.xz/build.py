import os,sys,pathlib,subprocess,json,concurrent.futures,re
from metrics import metrics
s=pathlib.Path(os.environ['s'])
phase,tc,arch=sys.argv[1:]
target='wasm32-wasip1' if arch=='wasi' else 'x86_64-unknown-linux-gnu'
env=os.environ | {'CARGO_TARGET_DIR':str(s/f'target-{tc}-{arch}'),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':f'--sysroot {s}/sysroot-{tc}','CARGO_BUILD_JOBS':'8','HYPERSOLVE_REPLAY_DRIVER':str(s/'tree/crates/hyperinterval/conformance/wasi-solver.py')}
cmd=['cargo','+'+tc,'build','--release','--locked','-p','hypersolve','--all-features','--tests','--examples','--benches']
if arch=='wasi':cmd+=['--target',target]
cmd+=['--message-format=json-render-diagnostics']
prefix=f'{phase}-{tc}-{arch}'
with (s/'logs'/f'{prefix}.jsonl').open('w') as out,(s/'logs'/f'{prefix}.build').open('w') as err:
 subprocess.run(cmd,cwd=s/'tree',env=env,stdout=out,stderr=err,check=True)
bins={}
for line in (s/'logs'/f'{prefix}.jsonl').read_text().splitlines():
 r=json.loads(line)
 if r.get('executable') and r['target']['src_path'].startswith(str(s/'tree/crates/hypersolve/')):
  kind=r['target']['kind'][0];name=kind+'/'+r['target']['name']
  assert name not in bins
  bins[name]=r['executable']
def measure(pair):
 name,filename=pair
 d=metrics(pathlib.Path(filename))
 if arch=='native':
  out=subprocess.check_output(['readelf','-WS',filename],text=True)
  sections={}
  for line in out.splitlines():
   m=re.search(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\w+)',line)
   if m and 'A' in m[3]:sections[m[1]]=int(m[2],16)
  assert sections['.text']==d['code']; d['sections']=sections
 return name,d
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 result=dict(sorted(pool.map(measure,bins.items())))
assert len(result)>=71,len(result)
(s/f'{prefix}.json').write_text(json.dumps(result,indent=2)+'\n')
(s/f'{prefix}-bins.json').write_text(json.dumps(bins,indent=2)+'\n')
print(prefix,len(result),'linked commands',flush=True)
