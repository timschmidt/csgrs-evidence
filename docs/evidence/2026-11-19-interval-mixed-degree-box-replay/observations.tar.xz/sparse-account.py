import ast,json,os
from pathlib import Path
s=Path(os.environ['s'])
def load(v,tc):
 rows={};heap={};usable={}
 for line in (s/f'{v}-{tc}-lifetime.txt').read_text().splitlines():
  cell=line.split('|')
  if cell[0]=='STACK':
   _,i,w,p,n=cell;rows[int(i),int(w),int(p)]=int(n)
  elif cell[0]=='HEAP':
   _,i,vals=cell;heap[int(i)]=ast.literal_eval(vals)
 for line in (s/f'{v}-{tc}-usable.txt').read_text().splitlines():
  i,r,u=line.split('|');usable[int(i)]=(ast.literal_eval(r),ast.literal_eval(u))
 assert len(rows)==288 and len(heap)==len(usable)==72
 return rows,heap,usable
out={}
for tc in ['stable','1.95.0']:
 b,bh,bu=load('base',tc);a,ah,au=load('sparse',tc)
 for cp,ids in [('registered',range(60)),('mixed',range(60,72))]:
  res=out[f'{tc}/{cp}']={};cells=[]
  for i in ids:
   for w in [0,1]:
    peak=lambda d:max(d[i,w,p] for p in [85,170])
    before,after=peak(b),peak(a);d=after-before
    cells.append({'case':i,'warm':w,'before':before,'after':after,'delta':d,'percent':100*d/before})
  res['stack']=cells
  res['heap']={i:{'before':bh[i],'after':ah[i],'before_usable':bu[i][1],'after_usable':au[i][1]} for i in ids}
  assert all(not (bh[i][-1] or ah[i][-1] or bu[i][1][-1] or au[i][1][-1]) for i in ids)
  bad=[x for x in cells if x['percent']>1]
  print(tc,cp,'stack pairs',len(cells),'increases',sum(r['delta']>0 for r in cells),'past 1%',len(bad),'max increase',max(r['delta'] for r in cells),'witness',max(cells,key=lambda r:r['percent']),'requested heap delta range',min(ah[i][-2]-bh[i][-2] for i in ids),max(ah[i][-2]-bh[i][-2] for i in ids))
(s/'sparse-memory.json').write_text(json.dumps(out,indent=2)+'\n')
