set -eu
arch=$1
cd "$s/combined"
export CARGO_TARGET_DIR="$s/composed-$arch" CARGO_BUILD_JOBS=4
for tc in stable 1.95.0; do
  args=()
  if [ "$arch" = wasi ]; then args=(--target wasm32-wasip1 --config 'target.wasm32-wasip1.runner=["node","/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs"]'); fi
  export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-$tc"
  cargo +"$tc" test --locked --release --all-features -p hyperpath --test g1_solver_boundary -p hypersolve --test quadratic_affine_box --test open_half_line "${args[@]}" > "$s/logs/combined-final-$tc-$arch" 2>&1
done
