import json,os,subprocess
from pathlib import Path
s=Path(os.environ['s'])
ref=subprocess.check_output(['git','-C','../csgrs-evidence','rev-parse','HEAD'],text=True).strip()
stack=json.loads((s/'cumulative-stack.json').read_bytes())
total=max(v['cumulative'] for v in stack.values())
over=sum(v['cumulative_remaining']<0 for v in stack.values())
over_new=sum(v['cumulative_remaining']<0 and v['step'] for v in stack.values()) if over else 0
p=Path('INTERVAL_REFACTOR_PROGRESS.md');t=p.read_text()
old='native and WASI inventories matched across all 71 solver test executables'
assert t.count(old)==1
t=t.replace(old,'native and WASI inventories matched across all 72 current solver test executables')
old='nine solver zero-tangent outcomes and the measured extraction stack excess remain open'
assert t.count(old)==1
t=t.replace(old,'solver zero-tangent and varying affine-box verdicts remain open alongside the measured extraction stack excess')
t+='''
## Phases 7 and 11, generated tangent models over variable boxes

On `4c4385b48`, a generated axial G1 model produced 36 incorrect whole-box
verdicts in 120 independent cases. For example, target tangent `(2, 0)`
and candidate tangent `(x, 0)` with `x` in `[-1, 3]` have dot products
from −2 to 6. Both quadratic packages could certify orientation using the
center alone. The affine package enclosed this varying row. The strict
residual trial `7433a54bd` corrected the twelve singleton outcomes, leaving
24 incorrect crossing-box results. A new public example on the primary branch
exercises the supported affine enclosure and explains the scope of fallback
rows. Both Rust 1.95 and 1.99 passed the doctests and strict rustdoc build.
[Public box API](crates/hypersolve/src/interval.rs) ·
[Solver proof scope](docs/research/interval-box-proof-scope.md)

The mixed-degree trial independently encloses an affine row using the sum
of absolute source coefficients times their variable radii. It retains the
source constraint index, normalized residual, policy-qualified sign and
aggregate counts. The combined branch `interval-g1-box-composition` at
`c112d08f6` passed all 180 generated G1 box checks and the mixed-degree,
open half-line and hidden-sign regressions on both compilers and targets.
The 12 unchanged owner report/trace comparisons per implementation matched
byte for byte.

A full linked comparison covered 88 existing Hypersolve commands on each of
four compiler/target combinations. The unchanged revision ran 1,543 native
tests. The strict-row, in-place affine and source-dependency trials each ran
1,545. Each trial ran 1,521 direct WASI tests, 17 native parents making 26
fresh guest calls and five native platform cases, and matched all 4,212
Horner dispatch windows. This qualifies the measured trials, including their
new test executable. Release coordination and the binary limits still block
the strict-row migration. Its Rust 1.99 Linux representation test grew by
4,304 file bytes against a 4,096-byte incremental cap.

Source-dependency checks removed the first affine implementation's
256–272-byte stack increase on constant-only controls. With 24 fresh
processes on each side per compiler, maximum positive stack changes across
the 60 registered workloads were 48 bytes on Rust 1.95 and 40 on Rust 1.99.
Every paired requested-heap peak matched. The 12 additional mixed-workload
cells had unchanged measured stack maxima. For the registered Rust 1.95
account, the largest cumulative stack debit in the trial reconstruction was
TOTAL bytes. COUNT of 120 cold/warm rows exceeded a cumulative limit.
The raw account preserves every positive charge and the fixed references.

The source-dependency trial `1bcfa0a2e` still added 8,704 Linux file bytes
and 13,305 WASI file bytes to the Rust 1.95 owner certification benchmark.
The grouped-ball alternative `580b8617e` added 14,136 and 13,493 file bytes
respectively. Neither change was admitted. The public scope documentation
and four reviewed inventory rows are retained. The inventory now contains
431 reviews and 7,354 scan rows. Evidence commit `REV` includes the
independent source oracles, release measurements, full test inventories,
stack accounts, paired timings and trial patches.
[Evidence index](docs/evidence-archive.tsv)
'''.replace('REV',ref).replace('TOTAL',str(total)).replace('COUNT of 120',str(over)+' of 120')
p.write_text(t)
p=Path('docs/research/interval-box-proof-scope.md')
with p.open('a') as f:f.write('''
## Varying affine rows in the quadratic packages

On `4c4385b48` the quadratic residual selectors admit structural degree
two. A linear row may have a retained affine form and still receive only
point replay in either quadratic package. For a generated G1 join, take
a fixed target tangent `(2, 0)` and a candidate `(x, 0)` over
`[-1, 3]`. Endpoints agree, the cross product vanishes and the dot product
takes both signs. Each quadratic package reported `Certified` at center 1
under both policies. The affine package returned `Unknown`. This exposure is
independent of whether orientation excludes the zero tangent.

The trial at `1bcfa0a2e` reuses the affine source to compute the exact
projected radius for varying rows. The quadratic evidence remains available
on the same mixed problem. Independent four-corner and symbolic-face
expectations check row indices, signed residuals, certainty, and the public
aggregate. The combined path/solver branch `c112d08f6` also requires a strict
dot product. Its generated-box corpus passed all 180 checks on Linux and
WASI with Rust 1.95 and 1.99. The earlier cubic coverage and approximate
receipt findings above are separate. The implementation remains under review
because final linked executables exceed their size limits.
[Qualification and measurements](../../INTERVAL_REFACTOR_PROGRESS.md#phases-7-and-11-generated-tangent-models-over-variable-boxes)
''')
p=Path('docs/research/axis-projection-owner.md')
with p.open('a') as f:f.write('''
The full `7433a54bd` solver trial ran 1,545 ordinary native tests on each
compiler and matched the native/WASI replay and dispatch controls. Its Linux
representation test on Rust 1.99 grew by 4,304 bytes against the 4,096-byte
file cap. A generated model subsequently consumed by quadratic interval replay
also exposed 24 incorrect crossing-box verdicts after the strict-row repair.
The paired trial with Hypersolve's affine enclosure corrects those verdicts.
[Mixed-degree proof coverage](interval-box-proof-scope.md#varying-affine-rows-in-the-quadratic-packages)
''')
