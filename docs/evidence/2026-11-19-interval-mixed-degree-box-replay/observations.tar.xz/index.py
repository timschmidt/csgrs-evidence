import sys,io,json,lzma,subprocess,hashlib,tarfile
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
import evidence_archive as archive
repo='../csgrs-evidence'; name='docs/evidence/2026-11-19-interval-mixed-degree-box-replay'
def git(*args):return subprocess.check_output(['git','-C',repo,*args])
rev=git('rev-parse','HEAD').decode().strip()
want=json.loads(lzma.decompress(git('show',f'{rev}:{name}/members.sha256.json.xz')))
found={}
with tarfile.open(fileobj=io.BytesIO(git('show',f'{rev}:{name}/observations.tar.xz')),mode='r:xz') as tar:
 for member in tar:
  assert member.isfile() and member.name not in found
  found[member.name]=hashlib.sha256(tar.extractfile(member).read()).hexdigest()
assert want==found
archive.ROOTS={name:False}
_,row=archive.manifest(repo,rev)
p=Path('docs/evidence-archive.tsv')
assert name not in p.read_text()
with p.open('a') as f:f.write(row+'\n')
print(rev,len(found),row)
