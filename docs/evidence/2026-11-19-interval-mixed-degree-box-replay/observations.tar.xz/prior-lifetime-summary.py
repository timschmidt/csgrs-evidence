from pathlib import Path
import ast,json
s=Path(__file__).parent
def collect(v):
 rows={}
 for p in sorted((s/'logs').glob(v+'-lifetime*')):
  for line in p.read_text().splitlines():
   kind,idx,rest=line.split('|',2)
   if kind=='HEAP':
    row=ast.literal_eval(rest); key=(idx,kind);rows.setdefault(key,[]).append(row)
   else:
    warm,pattern,peak=rest.split('|');key=(idx,kind,warm); rows.setdefault(key,[]).append(int(peak))
 return {k:tuple(max(col) for col in zip(*vals)) if k[1]=='HEAP' else max(vals) for k,vals in rows.items()}
vs=[collect(v) for v in ['fixed','before','all-radii']]
for j in range(2):
 diff=[(k,vs[j][k],vs[j+1][k]) for k in vs[j] if vs[j][k]!=vs[j+1][k]]
 print('pair',j,'heap changes',[(i[0][0],i[1][-2],i[2][-2]) for i in diff if i[0][1]=='HEAP'])
 print('stack positive',[(i[0],i[1],i[2]) for i in diff if i[0][1]=='STACK' and i[2]>i[1]])
print('max stack',[max(v[k] for k in v if k[1]=='STACK') for v in vs])
print('max heap',[max(v[k][-2] for k in v if k[1]=='HEAP') for v in vs])
