set -eu
tc=$1
phase=$2
for arch in native wasi; do
  while [ ! -s "$s/$phase-$tc-$arch-bins.json" ]; do
    if rg -q 'Traceback' "$s/logs/$phase-$tc-$arch.runner"; then exit 1; fi
    sleep 2
  done
done
python3 "$s/execute.py" "$phase" "$tc" > "$s/logs/$phase-wasi-runs-$tc" 2>&1
cd "$s/tree"
export CARGO_TARGET_DIR="$s/target-$tc-native" CARGO_BUILD_JOBS=9
cargo +"$tc" test --release --locked -p hypersolve --all-features --lib --tests -- --test-threads=1 > "$s/logs/$phase-native-runs-$tc" 2>&1
