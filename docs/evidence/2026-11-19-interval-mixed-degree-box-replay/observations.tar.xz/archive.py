import hashlib,io,os,tarfile,lzma,json
from pathlib import Path
s=Path(os.environ['s'])
e=Path('/mnt/development/csgrs-evidence/docs/evidence/2026-11-19-interval-mixed-degree-box-replay')
e.mkdir(parents=True,exist_ok=True)
paths=set()
for pat in ['*.py','*.sh','*.md','*.json','*.txt','*.patch','env','versions','logs/*','patches/*','*-runs-*/*.log','*-runs-*/report.json','timing/**/new/sample.json']:
 paths.update(p for p in s.glob(pat) if p.is_file())
for sub in ['box','time-client','lifetime-src']:
 for p in (s/sub).rglob('*'):
  if p.is_file() and ('target' not in p.parts and (p.name in ('Cargo.toml','Cargo.lock') or p.suffix in ('.rs','.c'))):paths.add(p)
manifest={}
with tarfile.open(e/'observations.tar.xz','w:xz',preset=5) as tar:
 for p in sorted(paths):
  n=p.relative_to(s).as_posix();assert not p.is_symlink()
  data=p.read_bytes()
  assert not data.startswith((b'\x7fELF',b'\x00asm')),n
  info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644
  manifest[n]=hashlib.sha256(data).hexdigest();tar.addfile(info,io.BytesIO(data))
(e/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()))
print(len(manifest),'members',sum(p.stat().st_size for p in e.iterdir()),'compressed bytes')
