import ast,concurrent.futures,json,os,subprocess,time
from pathlib import Path
s=Path(os.environ['s'])
def run(job):
 name,idx=job
 p=s/('anchor-'+name)
 while not p.exists():time.sleep(1)
 res=subprocess.run([p],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);rows={};heap={}
 for line in res.stdout.splitlines():
  v=line.split('|');case=int(v[1])
  if case>=60:continue
  if v[0]=='STACK':
   key='/'.join(v[1:3]);rows[key]=max(rows.get(key,0),int(v[-1]))
  else:heap[v[1]]=ast.literal_eval(v[-1])
 assert len(rows)==120 and len(heap)==60
 return dict(tag=name,repeat=idx,stack=rows,heap=heap)
jobs=[(tag,idx) for idx in range(24) for tag in ['fixed','registered','latest']]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: raw=list(pool.map(run,jobs))
(s/'anchor-repeats.json').write_text(json.dumps(raw,separators=(',',':'))+'\n')
summary=json.load(open(s/'stack-repeat-summary.json'))['1.95.0']
older={f'{r["workload"]}/{int(r["temperature"]=="warm")}':r for r in json.load(open(s/'prior-registered-stack.json'))}
last={'/'.join(map(str,r['key'][1:])):r for r in json.load(open(s/'prior-latest-stack.json')) if r['key'][0]=='STACK'}
out={}
for k,old in older.items():
 vals=[max(r['stack'][k] for r in raw if r['tag']==tag) for tag in ['fixed','registered','latest']]
 b,a,d=summary['stack'][k];prev=last[k]
 # Carry the published cumulative debit; historical reconstructions can only raise it.
 historical=max(prev['cumulative'], max(old['cumulative_charge_bytes'],max(0,vals[1]-vals[0]))+max(0,vals[2]-vals[1]))
 intervening=max(0,b-min(prev['candidate'],vals[2]))
 increment=max(0,a-b);cum=historical+intervening+increment
 denom=min(old['fixed'],vals[0]);allowed=min(256,denom*2//100)
 out[k]={'fixed_archived':old['fixed'],'fixed_same_harness':vals[0],'registered':vals[1],'latest_same_harness':vals[2],'latest_published_charge':prev['cumulative'],'carried_charge':historical,'intervening_charge':intervening,'before':b,'trial':a,'step':increment,'cumulative':cum,'step_remaining':min(128,b//100)-increment,'cumulative_remaining':allowed-cum}
(s/'cumulative-stack.json').write_text(json.dumps(out,indent=2)+'\n')
print('registered cases',len(out),'max step',max(r['step'] for r in out.values()),'max total debit',max(r['cumulative'] for r in out.values()),'excess cumulative',sum(r['cumulative_remaining']<0 for r in out.values()),'new charge on over-cap rows',sum(r['cumulative_remaining']<0 and r['step']>0 for r in out.values()))
