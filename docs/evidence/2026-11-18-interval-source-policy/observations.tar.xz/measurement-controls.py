from pathlib import Path
import subprocess
import shutil

s=Path('/dev/shm/interval-source-policy')
owner=Path.cwd()/'crates/hyperinterval/conformance/alumina-measurements/wasm'
base=(owner/'src/lib.rs').read_text()
manifest=(owner/'Cargo.toml').read_text()
for path in ('../../../../../../alumina-interface/crates/alumina-interface-core', '../../../../hyperreal'):
    manifest=manifest.replace(f'"{path}"',f'"{(owner/path).resolve()}"')
target=s/'measurement-target/wasm32-unknown-unknown/release/interval_measurement_wasm.wasm'
original=s/'measured-control.wasm'
shutil.copyfile(target,original)
for name, old, new, diagnostic in [
    ('duplicate-endpoint','value.lower(), value.upper()', 'value.lower(), value.lower()', 'measurement(-32, 1, 1)'),
    ('unexpected-status','Err(BoundaryError::NegativeUncertainty) => 0,','Err(BoundaryError::NegativeUncertainty) => u64::MAX - 1,','unexpected kernel error for (-32, -4, 1)')]:
    work=s/name
    (work/'src').mkdir(parents=True)
    assert base.count(old)==1
    (work/'src/lib.rs').write_text(base.replace(old,new))
    (work/'Cargo.toml').write_text(manifest)
    shutil.copyfile(owner/'Cargo.lock',work/'Cargo.lock')
    with (s/'logs'/('build-'+name)).open('w') as out:
        subprocess.run(['cargo','+1.95.0','build','--locked','--target','wasm32-unknown-unknown','--release','--manifest-path',work/'Cargo.toml'], stdout=out,stderr=subprocess.STDOUT,check=True)
    result=subprocess.run(['node',owner/'check.mjs',target],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (s/'logs'/('red-'+name)).write_text(result.stdout)
    assert result.returncode!=0 and diagnostic in result.stdout, result.stdout
    print(name, diagnostic,flush=True)
subprocess.run(['node',owner/'check.mjs',original],check=True)
