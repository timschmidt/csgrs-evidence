from contextlib import contextmanager
from pathlib import Path
import hashlib
import subprocess

scratch = Path('/dev/shm/interval-source-policy')
trees = scratch / 'trees'
ui = trees / 'alumina-interface'
foc = trees / 'csgrs/crates/hyperlattice-interval/conformance/alumina-foc'
firmware = trees / 'alumina-firmware'
out = scratch / 'logs'

@contextmanager
def replace(path, old, new):
    before = path.read_bytes()
    text = before.decode()
    assert old in text, (path, old)
    path.write_text(text.replace(old, new))
    try:
        yield
    finally:
        path.write_bytes(before)

def probe(name, args, expected):
    result = subprocess.run(['bash', 'scripts/audit-source-policy.sh', *args], cwd=ui,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out/name).write_text(result.stdout)
    assert result.returncode != 0 and expected in result.stdout, (name, result.stdout[-2000:])
    print(name, 'rejected', result.returncode, expected, flush=True)

with replace(ui/'Cargo.toml', '../alumina-firmware', '../wrong/alumina-firmware'):
    # Point the duplicate firmware at the canonical geometry workspace too.
    # The lock contains the same names and versions at both locations.
    with replace(ui/'Cargo.toml', '../csgrs', '../wrong/csgrs'):
        probe('red-alternate', [], 'resolved to')

for root, name in [(ui, 'interface'), (foc, 'foc-native'), (foc/'wasm', 'foc-wasm')]:
    lock = root/'Cargo.lock'
    before=lock.read_bytes()
    start=before.index(b'name = "alumina-foc"')
    stop=before.index(b'[[package]]', start)
    section=before[start:stop].decode()
    assert section.count(' "hyperinterval",\n') == 1
    with replace(lock, section, section.replace(' "hyperinterval",\n', '')):
        stale=lock.read_bytes()
        probe('red-lock-'+name, ['--coordinated'], '--locked')
        assert lock.read_bytes() == stale
        print(name, 'stale lock unchanged', hashlib.sha256(stale).hexdigest(), flush=True)
    assert lock.read_bytes() == before

manifest=firmware/'crates/alumina-foc/Cargo.toml'
for name, license_field, expected in [('gpl','license = "GPL-3.0-only"', 'GPL-family dependency rejected'),
                                       ('none','', 'missing license metadata rejected')]:
    with replace(manifest, 'license.workspace = true', license_field):
        probe('red-license-'+name, [], expected)
