"""Stage only the closed exact-track evidence and permitted ledger value."""
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';E=O/'docs/evidence/2026-10-17-native-track-revisit'
BASE='7abc7128c00ad1b4bbb10ddd24dc968c39dfdd8a';GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)
def sha(p):
    with Path(p).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def span(raw):
    start=re.search(rb'"current_work"\s*:\s*',raw).end();_,count=json.JSONDecoder().raw_decode(raw[start:].decode());return start,start+len(raw[start:].decode()[:count].encode())
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--cached','--name-only')
checkpoint=json.loads((E/'checkpoint-v1.json').read_text());assert all(sha(O/p)==h for p,h in checkpoint['evidence_files_sha256'].items())
assert sha(O/'docs/properties-status.json')==checkpoint['ledger_after_sha256']
raw=(O/'docs/properties-status.json').read_bytes();ref=git('show','9025de62:docs/properties-status.json');s,e=span(raw);rs,re_=span(ref);assert (raw[:s],raw[e:])==(ref[:rs],ref[re_:])
assert sha(O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py')=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
files={str(p.relative_to(O)):sha(p) for p in E.rglob('*') if p.is_file()};files['docs/properties-status.json']=sha(O/'docs/properties-status.json')
assert git('diff','--name-only').decode().splitlines()==['docs/properties-status.json']
git('add','--',str(E.relative_to(O)),'docs/properties-status.json');git('diff','--cached','--check')
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(files)
for p,h in files.items():assert hashlib.sha256(git('show',':'+p)).hexdigest()==h
receipt=N/'track-revisit-stage-verification-v1.json';assert not receipt.exists();receipt.write_text(json.dumps({'parent':BASE,'files':files,'staged_blobs_verified':True,'staged_whitespace_exit':0},indent=2,sort_keys=True)+'\n')
print(json.dumps({'staged_files':len(files),'all_staged_blobs_verified':True,'receipt':str(receipt)}),flush=True)
