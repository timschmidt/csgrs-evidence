"""Isolate the exact-track importer on the committed flat aggregation baseline."""
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';W=Path(__file__).resolve().parent
S=N/'native-track-revisit-source-v1';T=N/'targets/native-track-revisit-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import sha,dump,GIT,reasons,resources
assert not reasons(resources())
assert json.loads((N/'native-track-revisit-baseline-v1/result-v1.json').read_text())['current_gaps_reproduced']
def git(args,cwd=O,stdin=None):return subprocess.run(GIT+args,cwd=cwd,env=dict(os.environ,GIT_LFS_SKIP_SMUDGE='1'),input=stdin,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip();assert head=='7abc7128c00ad1b4bbb10ddd24dc968c39dfdd8a'
assert not git(['diff','HEAD','--name-only'])
assert not S.exists() and not T.exists()
git(['worktree','add','--no-checkout','-b','codex/native-track-revisit-20261017',str(S),head])
sparse=N/'native-aggregation-control-v1/sparse-selection-v1.txt'
shutil.copy2(sparse,W/'sparse-selection-v1.txt')
git(['sparse-checkout','set','--no-cone','--stdin'],S,sparse.read_bytes());git(['checkout','codex/native-track-revisit-20261017'],S)
basepins=json.loads(gzip.decompress((N/'native-aggregation-flat-integration-source-v1.json.gz').read_bytes()));normalizations={}
for p,h in basepins.items():
    if p=='docs/properties-status.json':h=sha(O/p)
    assert sha(O/p)==h
    if sha(S/p)!=h:
        assert (S/p).read_bytes()==(O/p).read_bytes().replace(b'\r\n',b'\n'),p
        normalizations[p]={'checkout_sha256':sha(S/p),'preserved_sha256':h};shutil.copy2(O/p,S/p)
old=O/'docs/evidence/2026-10-17-kicad-native-strokes/candidate-changes-v4'
changed=['crates/hyperdrc/src/kicad/tracks.rs','crates/hyperdrc/tests/kicad_track_failures.rs']
added=['crates/hyperdrc/tests/kicad_native_strokes.rs','crates/hyperdrc/tests/kicad_native_aggregation.rs']
shutil.copy2(O/changed[1],W/'original-kicad_track_failures.rs')
for p in changed+added:shutil.copy2(old/p,S/p)
assert set(git(['diff','--name-only'],S).decode().splitlines())==set(changed)
assert not git(['diff','--check'],S)
tracked=git(['ls-files','-z'],S).decode().split('\0')[:-1]
pins={p:sha(S/p) for p in tracked if (S/p).is_file()}
for p in added:pins[p]=sha(S/p)
inv=N/'native-track-revisit-source-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
(W/'candidate-tracked-v1.patch').write_bytes(git(['diff','--binary'],S))
dump(W/'preparation-v1.json',{'revision':head,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'source_root':str(S),'target':str(T),'source_inventory':str(inv),'source_inventory_sha256':sha(inv),'source_files':len(pins),'production_changed_files':[changed[0]],'changed_test_files':[changed[1]],'added_archived_tests':added,'archived_changes_sha256':{p:sha(old/p) for p in changed+added},'normalized_checkout_files':normalizations,'cache_proposal_present':False,'admitted':False})
print(json.dumps({'source_files':len(pins),'production_changed_files':[changed[0]]}),flush=True)
