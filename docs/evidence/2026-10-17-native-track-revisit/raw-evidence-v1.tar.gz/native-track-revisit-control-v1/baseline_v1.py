"""Reproduce exact-track gaps with the qualified main-revision libraries."""
import gzip,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;A=N/'native-track-revisit-baseline-v1';T=N/'targets/native-aggregation-flat-integration-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha,GIT
assert not A.exists();A.mkdir()
head=subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip();assert head=='7abc7128c00ad1b4bbb10ddd24dc968c39dfdd8a'
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
pins=json.loads(gzip.decompress((N/'native-aggregation-flat-integration-source-v1.json.gz').read_bytes()));pins.pop('docs/properties-status.json')
assert all(sha(O/p)==h for p,h in pins.items())
libs={};searches=set()
for line in (N/'logs/aggregation-flat-integration-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hyperdrc','hyperlimit','hypercurve'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libs[r['target']['name']]=p
assert len(libs)==3
inputs={k:{'path':p,'sha256':sha(p)} for k,p in libs.items()};commands={};outcomes={}
def execute(label,args,expected_code=0):
    name='track-revisit-baseline-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--ro-bind',str(T),str(T),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    try:r=run(name,argv+args,O,target=T,wall_seconds=60)
    except RuntimeError:r=json.loads((N/'logs'/name/'result.json').read_text())
    commands[label]=r;dump(A/'progress-v1.json',commands)
    assert r['exit_code']==expected_code and not r['stops'],r
    return (N/'logs'/name/'stdout').read_text(),(N/'logs'/name/'stderr').read_text()
archive=O/'docs/evidence/2026-10-17-kicad-native-strokes/candidate-changes-v4/crates/hyperdrc/tests'
for name in ['kicad_native_strokes','kicad_native_aggregation']:
    source=A/(name+'.rs');shutil.copy2(archive/(name+'.rs'),source)
    binary=A/name;args=[compiler['additional_environment']['RUSTC'],'--edition=2024','--test','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
    for path in sorted(searches):args+=['-L',path]
    for dep,path in sorted(libs.items()):args+=['--extern',dep+'='+path]
    execute(name+'-compile',args)
    out,err=execute(name+'-run',[str(binary),'--test-threads=1','--nocapture'],101)
    rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
    assert len(rows)==1 and rows[0][0]=='FAILED' and rows[0][3:]==('0','0','0')
    if name=='kicad_native_aggregation':assert rows[0][1:3]==('9','3')
    outcomes[name]={'summary':rows,'failures':re.findall(r'^test ([^ ]+) \.\.\. FAILED$',out,re.M),'source_sha256':sha(source),'binary_sha256':sha(binary)}
artifacts=json.loads((N/'native-aggregation-flat-integration-artifacts-v1/executables-v1.json').read_text());record=artifacts['kicad_track_failures'];assert sha(record['executed_copy'])==record['sha256']
out,err=execute('existing-failures',[record['executed_copy'],'--test-threads=1','--nocapture'])
assert '39 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in out
outcomes['existing_failures']={'passed':39,'artifact':record,'source_sha256':sha(O/'crates/hyperdrc/tests/kicad_track_failures.rs')}
assert all(sha(O/p)==h for p,h in pins.items()) and all(sha(v['path'])==v['sha256'] for v in inputs.values())
dump(A/'result-v1.json',{'revision':head,'source_files_verified':len(pins),'source_inventory_sha256':sha(N/'native-aggregation-flat-integration-source-v1.json.gz'),'libraries':inputs,'commands':commands,'outcomes':outcomes,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'current_gaps_reproduced':True})
print(json.dumps(outcomes),flush=True)
