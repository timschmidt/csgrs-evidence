"""Measure public Point2 equality on fixed exact inputs before any change."""
import json,os,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
W=Path(__file__).resolve().parent;A=N/'native-track-revisit-point-cost-v1';T=N/'targets/native-aggregation-flat-integration-v1'
sys.path.insert(0,str(N/'control'))
from validation_runner_v3 import run,dump,sha
assert (N/'native-track-revisit-gates-result-v1.json').exists()
assert not A.exists();A.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
libs={};searches=set()
for line in (N/'logs/aggregation-flat-integration-compile-v1/stdout').read_text().splitlines():
    try:r=json.loads(line)
    except json.JSONDecodeError:continue
    if r.get('reason')=='build-script-executed':searches.update(r.get('linked_paths',[]))
    if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['hypercurve','hyperreal'] and not r['profile']['test']:
        for p in r['filenames']:
            if p.endswith('.rlib'):libs[r['target']['name']]=p
assert len(libs)==2;inputs={k:{'path':p,'sha256':sha(p)} for k,p in libs.items()};commands={};rows=[]
source=W/'point_equality_cost_v1.rs';binary=A/'point-equality-cost';source_sha=sha(source)
def execute(label,args):
    name='track-revisit-point-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(V),str(M),'--bind',str(N),str(N),'--ro-bind',str(O),str(O),'--ro-bind',str(T),str(T),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    try:r=run(name,argv+args,O,target=T,wall_seconds=60)
    except RuntimeError:r=json.loads((N/'logs'/name/'result.json').read_text())
    commands[label]=r;dump(A/'progress-v1.json',commands)
    return r,(N/'logs'/name/'stdout').read_text()
args=[compiler['additional_environment']['RUSTC'],'--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(T/'release/deps')]
for path in sorted(searches):args+=['-L',path]
for dep,path in sorted(libs.items()):args+=['--extern',dep+'='+path]
r,out=execute('compile',args);assert r['exit_code']==0 and not r['stops']
for case in ['integer','shared','same-x','decimal','non-dyadic','subrange','superrange','large-coefficients','symbolic']:
    r,out=execute(case,[str(binary),case])
    parsed=[json.loads(line) for line in out.splitlines() if line.startswith('{')];rows+=parsed
    if r['exit_code']==0:assert len(parsed)==2 and all(p['case']==case for p in parsed)
    dump(A/'rows-v1.json',rows)
assert sha(source)==source_sha and all(sha(v['path'])==v['sha256'] for v in inputs.values())
dump(A/'result-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'point-equality-probe-contract-v1.md'),'source_sha256':source_sha,'binary_sha256':sha(binary),'libraries':inputs,'commands':commands,'rows':rows,'implementation_changed':False,'optimization_benchmark':False,'all_cases_completed':all(r['exit_code']==0 and not r['stops'] for r in commands.values())})
print(json.dumps(rows),flush=True)
