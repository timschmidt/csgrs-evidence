use hypersolve::work_budget::{
    BudgetExceeded, CancellationToken, WorkBudget, WorkKind, consume, exhaustion,
    observe_coefficient_bits, with_budget, with_cancellable_budget, with_coefficient_bit_limit,
};

fn verify(error: BudgetExceeded, limit: u64, requested: u64) {
    assert_eq!(error.kind, WorkKind::CoefficientGrowth);
    assert_eq!(error.used, 0);
    assert_eq!((error.limit as u64, error.requested as u64), (limit, requested));
    assert_eq!(error.to_string(), format!("coefficient growth limit exceeded: {requested} bits against a limit of {limit}"));
}

fn main() {
    let limits = [0, 1, u32::MAX as u64 - 1, u32::MAX as u64, 1_u64 << 32, (1_u64 << 32) + 1, 1_u64 << 63, u64::MAX - 1, u64::MAX];
    for &limit in &limits {
        for &bits in &limits {
            let enclosing = with_coefficient_bit_limit(limit, || {
                assert_eq!(observe_coefficient_bits(limit), Ok(()));
                let inner = with_budget(WorkBudget::UNLIMITED, || {
                    consume(WorkKind::RootRefinement, 3).unwrap();
                    if bits <= limit {
                        observe_coefficient_bits(bits).unwrap();
                        assert!(exhaustion().is_none());
                    } else {
                        let error = observe_coefficient_bits(bits).unwrap_err();
                        verify(error,limit,bits);
                        assert_eq!(exhaustion(),Some(error));
                        assert_eq!(consume(WorkKind::AlgebraicPromotion, 1),Err(error));
                        assert_eq!(with_budget(WorkBudget::ZERO, || 7).result, Err(error));
                    }
                });
                assert_eq!(inner.usage.refinements,3);
                if bits > limit { verify(inner.result.unwrap_err(),limit,bits); }
                else { inner.result.unwrap(); }
            });
            assert_eq!(enclosing.usage.refinements,3);
            if bits > limit { verify(enclosing.result.unwrap_err(),limit,bits); }
            else { enclosing.result.unwrap(); }
            assert!(exhaustion().is_none());
            with_coefficient_bit_limit(bits,|| observe_coefficient_bits(bits)).result.unwrap().unwrap();
        }
    }
    let cancellation=CancellationToken::new();
    cancellation.cancel();
    let failed=with_cancellable_budget(WorkBudget::UNLIMITED,&cancellation,|| observe_coefficient_bits(u64::MAX));
    assert_eq!(failed.result.unwrap_err().kind, WorkKind::Cancellation);
    println!("81 ordered comparisons with nested scope, exhaustion propagation, independent retry, and cancellation passed");
}
