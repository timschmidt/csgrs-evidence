from pathlib import Path
import os,json,re
from metrics import metrics
s=Path(os.environ['s']);r={}
for tc in ('1.95.0','stable'):
 for target,suffix in [('native','libbudget_scope_client.so'),('wasm','budget_scope_client.wasm')]:
  a,b=[metrics(s/f'{tag}-format-{tc}-{suffix}') for tag in ('control','display')];key=f'{tc}-{target}';r[key]={'previous':a,'retained':b,'deltas':{m:b[m]-a[m] for m in ('file','code','functions')}}
  for m in ('file','code','functions'):assert b[m]-a[m]<=min(4096,a[m]//100),(key,m)
  assert b['file']<16*1024**2
  if target=='wasm':
   z={}
   for tag in ('control','display'):
    rows={}
    for line in (s/'logs'/f'{tag}-format-stack-{tc}').read_text().splitlines():
     depth,_,warm,pattern,peak=map(int,line.split());rows.setdefault(f'{depth}/{warm}',[]).append(peak)
    z[tag]={case:max(vals) for case,vals in rows.items()}
   assert all(z['display'][k]<=v for k,v in z['control'].items())
   r[key]['stack']=z
(s/'public-images.json').write_text(json.dumps(r,indent=2)+'\n')
for k,x in r.items():print(k,x['deltas'])
