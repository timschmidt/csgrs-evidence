set -eu
cd "$s/bench-src"
export CARGO_TARGET_DIR="$s/bench-target" CARGO_BUILD_JOBS=5
for v in control display;do
 if test "$v" = control;then git show HEAD:crates/hypersolve/src/work_budget.rs > crates/hypersolve/src/work_budget.rs;else cp /mnt/development/csgrs/crates/hypersolve/src/work_budget.rs crates/hypersolve/src/work_budget.rs;fi
 cargo +1.95.0 build --locked --release -p csgrs --bench successive_operations --no-default-features --features curve,stl-io,obj-io --message-format=json-render-diagnostics > "$s/logs/$v-feedback.jsonl" 2>"$s/logs/$v-feedback.build"
 python3 - "$v" <<'PY'
from pathlib import Path
import json,os,sys,shutil
s=Path(os.environ['s']);v=sys.argv[1];p=next(r['executable'] for r in map(json.loads,(s/'logs'/f'{v}-feedback.jsonl').read_text().splitlines()) if r.get('executable'));shutil.copy2(p,s/(v+'-feedback'))
PY
 SUCCESSIVE_OPERATIONS_RAW="$s/logs/$v-feedback.tsv" "$s/$v-feedback" '((A-B)-C)+D feedback' > "$s/logs/$v-feedback.run" 2>&1
done
