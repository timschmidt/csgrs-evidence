set -eu
tc=$1
case "$tc" in stable) archive="$s/display-wasi";; *) archive="$s/display-wasi-$tc";; esac
while ! test -f "$archive/report.json";do sleep 2;done
export CARGO_TARGET_DIR="$s/qualification-$tc" CARGO_BUILD_JOBS=4 CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot=$s/sysroot-$tc"
python3 "$s/resource-time.py" "$s/qualification-rss-$tc.json" python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$tc" --output "$s/rss-wasi-$tc" > "$s/logs/display-compiled-job-$tc" 2>&1
