set -eu
cd "$s/src"
for tc in 1.95.0 stable;do
 t=wasm32-wasip1
 export CARGO_TARGET_DIR="$s/target-$tc-$t" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot=$s/sysroot-$tc"
 python3 "$s/resource-time.py" "$s/logs/display-fixture-rss-$tc" bash -c '
  p=$(cargo +"$1" test --locked --release -p hypersolve --all-features --target wasm32-wasip1 --test coefficient_bit_budget --no-run --message-format=json-render-diagnostics | python3 -c "import json,sys;print(next(row[\"executable\"] for row in map(json.loads,sys.stdin) if row.get(\"executable\")))")
  "$s/node/node" "$s/src/crates/hyperlattice-interval/conformance/run-wasi-test.mjs" "$p" --test-threads=1
 ' _ "$tc" >"$s/logs/display-fixture-rss-$tc.run" 2>&1
done
