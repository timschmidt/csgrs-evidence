import csv,io,json,os
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s'])
def rows(v):
 text=(s/'logs'/f'{v}-feedback.tsv').read_text();return list(csv.DictReader(io.StringIO('\n'.join(x for x in text.splitlines() if not x.startswith('#'))),delimiter='\t'))
c,n=[rows(t) for t in ('control','display')]
assert len(c)==len(n)==6
dif={}
for old,new in zip(c,n):
 assert old['step']==new['step'] and old['outcome']==new['outcome']=='certified'
 diff={k:(old[k],new[k]) for k in old if old[k]!=new[k] and k not in ('step_ns','validation_ns','drop_ns')}
 if diff:dif[old['step']]=diff
data={'steps':len(c),'differences':dif,'images':{v:metrics(s/(v+'-feedback')) for v in ('control','display')}}
(s/'feedback-review.json').write_text(json.dumps(data,indent=2)+'\n');assert not dif,dif
