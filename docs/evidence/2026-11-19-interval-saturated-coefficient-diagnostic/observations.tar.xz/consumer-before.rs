use hypersolve::work_budget::{
    consume, exhaustion, observe_coefficient_bits, with_budget, with_coefficient_bit_limit,
    BudgetExceeded, WorkBudget, WorkKind,
};
use std::hint::black_box;
#[inline(never)]
fn scope(depth: u32, observation: u64) -> Result<(), BudgetExceeded> {
    if depth == 1 {
        consume(WorkKind::RootRefinement, 1)?;
        return observe_coefficient_bits(black_box(observation));
    }
    with_budget(WorkBudget::UNLIMITED, || scope(depth - 1, observation)).result?
}
#[unsafe(no_mangle)]
pub extern "C" fn run_scope(iterations: u32, depth: u32, deny: u32) -> u64 {
    let mut sum = 0;
    for _ in 0..iterations {
        let value = if deny != 0 { 33 } else { 32 };
        let outcome = black_box(with_coefficient_bit_limit(black_box(32), || scope(black_box(depth), value)));
        sum += outcome.usage.refinements as u64;
        match outcome.result {
            Ok(Ok(())) => assert!(deny==0),
            Err(e) => { assert!(deny!=0); assert_eq!(e.kind,WorkKind::CoefficientGrowth); sum += e.requested as u64; }
            Ok(Err(_)) => panic!("failed scope published"),
        }
        assert!(exhaustion().is_none());
    }
    sum
}
