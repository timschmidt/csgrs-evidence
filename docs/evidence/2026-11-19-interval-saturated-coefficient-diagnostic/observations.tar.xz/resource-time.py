import json,resource,subprocess,sys,time
from pathlib import Path
t=time.monotonic();r=subprocess.run(sys.argv[2:]);a=resource.getrusage(resource.RUSAGE_CHILDREN)
Path(sys.argv[1]).write_text(json.dumps({'max_rss_bytes':a.ru_maxrss*1024,'wall_seconds':time.monotonic()-t,'exit':r.returncode})+'\n');sys.exit(r.returncode)
