set -eu
for ((i=0;i<300;i++));do
 if test "$(find "$s" -maxdepth 1 -name 'control-render-*.json' | wc -l)" -eq 4;then break;fi
 sleep 1
done
test "$(find "$s" -maxdepth 1 -name 'control-render-*.json' | wc -l)" -eq 4
cd "$s/src"
python3 "$s/display-source.py" "$s/src"
rustfmt +1.95.0 --edition 2024 crates/hypersolve/src/work_budget.rs crates/hypersolve/tests/coefficient_bit_budget.rs
git diff > "$s/display.patch"
cmp crates/hypersolve/src/work_budget.rs /mnt/development/csgrs/crates/hypersolve/src/work_budget.rs
cmp crates/hypersolve/tests/coefficient_bit_budget.rs /mnt/development/csgrs/crates/hypersolve/tests/coefficient_bit_budget.rs
python3 "$s/render.py" display > "$s/logs/display-render" 2>&1 &
p=$!
python3 "$s/fixture.py" display "$s/src" > "$s/logs/display-fixture" 2>&1 &
q=$!
python3 "$s/measure.py" display > "$s/logs/display-builds" 2>&1 &
r=$!
wait "$p"; wait "$q";wait "$r"
