set -eu
cd "$s/src"
python3 - <<'PY'
import os
from pathlib import Path
s=Path(os.environ['s'])
p=s/'client/src/bin/render.rs';x=p.read_text().replace('let (message,row)=allocations::once','let (_,row)=allocations::once').replace('            text\n','            drop(black_box(text));\n').replace('{message}','after_drop').replace('        drop(message);\n','');(p.parent/'renderdrop.rs').write_text(x)
p=s/'render.py';x=p.read_text().replace("'render'","'renderdrop'").replace("'render.wasm'","'renderdrop.wasm'").replace('-render-', '-renderdrop-')
(s/'renderdrop.py').write_text(x)
PY
git show HEAD:crates/hypersolve/src/work_budget.rs > crates/hypersolve/src/work_budget.rs
python3 "$s/renderdrop.py" control
cp /mnt/development/csgrs/crates/hypersolve/src/work_budget.rs crates/hypersolve/src/work_budget.rs
python3 "$s/renderdrop.py" display
