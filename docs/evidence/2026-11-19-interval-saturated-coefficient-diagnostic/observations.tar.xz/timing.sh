set -eu
stage=$1
for tc in 1.95.0 stable;do
 for cpu in 4 15;do python3 "$s/time-budget.py" "$tc" "$stage" "$cpu" > "$s/logs/$stage-native-timing-$tc-$cpu" 2>&1 & done
 for cpu in 8 19;do taskset -c "$cpu" "$s/node/node" "$s/time-budget.cjs" "$s" "$tc" "$stage" "$cpu" > "$s/logs/$stage-wasm-timing-$tc-$cpu" 2>&1 & done
 for p in $(jobs -p);do wait "$p";done
done
