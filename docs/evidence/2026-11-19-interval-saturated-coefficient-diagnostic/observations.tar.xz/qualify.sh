set -eu
root=$1
cd "$root"
for tc in 1.95.0 stable;do
 (
  export CARGO_TARGET_DIR="$s/qualification-$tc" CARGO_BUILD_JOBS=6
  cargo +"$tc" test --release --locked -p hypersolve --all-features > "$s/logs/display-$tc-owner" 2>&1
  cargo +"$tc" clippy --locked --release -p hypersolve --all-targets --all-features -- -D warnings > "$s/logs/display-$tc-clippy" 2>&1
  RUSTDOCFLAGS="-D warnings" cargo +"$tc" doc --release --locked -p hypersolve --no-deps --all-features > "$s/logs/display-$tc-doc" 2>&1
  cargo +"$tc" test --locked --release -p hypersolve --no-default-features --test coefficient_bit_budget > "$s/logs/display-$tc-minimal" 2>&1
 ) &
done
(
 export CARGO_TARGET_DIR="$s/qualification-1.95.0" CARGO_BUILD_JOBS=5
 cargo +1.95.0 test --release --locked -p hyperbrep --test work_budget > "$s/logs/display-downstream-brep" 2>&1
 cargo +1.95.0 test --release --locked -p hypercurve --test hypercurve_open_path_compositions coefficient_bit_limit_stops_the_stalled_filleted_hyperbola_bevel_stroke -- --exact > "$s/logs/display-downstream-curve" 2>&1
) &
fail=0;for p in $(jobs -p);do wait "$p" || fail=1;done;exit "$fail"
