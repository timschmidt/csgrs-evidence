import os,time,subprocess,sys
from pathlib import Path
s=Path(os.environ['s']);src=s/'src'
# Only start after all control builds/runs are complete at this same source path.
for _ in range(480):
 if len(list(s.glob('control-*.json')))==8 and (s/'logs/control-stable-x86_64-unknown-linux-gnu-receipt-boundaries').exists():break
 time.sleep(1)
else:raise SystemExit('baseline missing')
subprocess.run([sys.executable,s/'compact.py',src],check=True)
subprocess.run(['rustfmt','+1.95.0','--edition','2024','crates/hypersolve/src/work_budget.rs'],cwd=src,check=True)
(s/'compact.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=src))
ps=[]
for name,cmd in [('builds',[sys.executable,s/'measure.py','compact']),('memory',[sys.executable,s/'profile.py','compact']),('oracles',['bash',s/'observe.sh','compact'])]:
 with (s/'logs'/('compact-'+name)).open('w') as out: ps.append(subprocess.Popen(cmd,cwd=src,stdout=out,stderr=subprocess.STDOUT))
assert all(p.wait()==0 for p in ps)
