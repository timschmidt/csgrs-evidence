import hashlib,json,os,re,statistics,subprocess
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s']);out={}
for tag in ('control','compact','display'):
 p=s/(tag+'-certification');m=metrics(p)
 for sec in ['.text','.rodata']:
  f=s/'tmp'/f'{tag}{sec}';subprocess.run(['objcopy','--dump-section',sec+'='+str(f),p,'/dev/null'],check=True);m[sec]=hashlib.sha256(f.read_bytes()).hexdigest();f.unlink()
 out[tag]=m
for target in ['compact','display']:
 q={}
 for cpu in [6,16]:
  rows={v:[] for v in ('control',target)}
  for p in sorted((s/'logs').glob(f'owner-{target}-{cpu}-*')):
   unit='µs';large=re.search(r'time:\s+\[[\d.]+ µs ([\d.]+) µs',p.read_text())
   if large:rows[p.name.split('-')[-1]].append(float(large[1]))
  assert all(len(v)==4 for v in rows.values());q[str(cpu)]={n:statistics.median(v) for n,v in rows.items()}|{'samples':rows}
 out[target+'-timing']=q
(s/'owner-review.json').write_text(json.dumps(out,indent=2)+'\n')
for k in ('control','display'):print(k,out[k]['.text'],out[k]['code'],out[k]['file'])
print(out['display-timing'])
