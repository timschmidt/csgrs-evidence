import json,os,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s']);tag=sys.argv[1];root=Path(sys.argv[2])
def run(job):
 v,t=job;key=f'{v}-{t}'
 env=os.environ|{'CARGO_TARGET_DIR':str(s/f'target-{v}-{t}'),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot='+str(s/('sysroot-'+v)),'CARGO_BUILD_JOBS':'4'}
 command=['cargo','+'+v,'test','--locked','--release','--all-features','-p','hypersolve','--no-run','--target',t,'--test','coefficient_bit_budget','--message-format=json-render-diagnostics']
 with (s/'logs'/f'{tag}-fixture-{key}.build').open('w') as log:r=subprocess.check_output(command,cwd=root,env=env,text=True,stderr=log)
 [p]=[Path(row['executable']) for row in map(json.loads,r.splitlines()) if row.get('executable')]
 (s/f'{tag}-fixture-{key}.json').write_text(json.dumps(metrics(p))+'\n')
 cmd=[str(p)] if t.startswith('x86') else [str(s/'node/node'),str(root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),str(p)]
 with (s/'logs'/f'{tag}-fixture-{key}.run').open('w') as f:r=subprocess.run([*cmd,'--test-threads=1','--nocapture'],env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 expected=(tag=='display-red' and t.startswith('wasm'))
 assert bool(r.returncode)==expected,(r.returncode,key,tag)
 if expected:
  txt=(s/'logs'/f'{tag}-fixture-{key}.run').read_text();assert 'denial_above_the_word_ceiling_keeps_the_strict_inequality' in txt and '4294967295 bits against a limit of 4294967295' in txt
with ThreadPoolExecutor(4) as pool:list(pool.map(run,[(v,t) for v in ('1.95.0','stable') for t in ('x86_64-unknown-linux-gnu','wasm32-wasip1')]))
