from pathlib import Path
import sys
root=Path(sys.argv[1]);p=root/'crates/hypersolve/src/work_budget.rs';x=p.read_text()
a='''/// zero `used`, and the observed coefficient's bit length as `requested`.'''
assert a in x;x=x.replace(a,a+'''
/// On 32-bit targets each count above `usize::MAX` saturates in the receipt.
/// If both fields reach that ceiling, the observation exceeded the actual
/// limit and only a lower bound on that limit is available.''')
a='''        if self.kind == WorkKind::CoefficientGrowth {
            return write!('''
assert a in x;x=x.replace(a,'''        if self.kind == WorkKind::CoefficientGrowth {
            if usize::BITS == 32 && self.limit == usize::MAX && self.requested == usize::MAX {
                return formatter.write_str(
                    "coefficient growth exceeded a limit of at least 4294967295 bits",
                );
            }
            return write!(''')
p.write_text(x)
p=root/'crates/hypersolve/README.md';x=p.read_text();a='''On 32-bit targets the error currently
saturates each reported count above `usize::MAX`, including in its display.''' ;assert a in x;p.write_text(x.replace(a,'''On 32-bit targets the error fields saturate
above `usize::MAX`. When both fields reach that ceiling the message reports
that the observation exceeded a limit of at least 4,294,967,295 bits.'''))
p=root/'crates/hypersolve/tests/coefficient_bit_budget.rs';x=p.read_text();a='''                            assert_eq!(denied.used, 0);''';assert x.count(a)==1
p.write_text(x.replace(a,'''                            let limit = if bits > outer { outer } else { inner };
                            if let Ok(limit) = usize::try_from(limit) {
                                assert_eq!(denied.limit, limit);
                            }
                            if let Ok(bits) = usize::try_from(bits) {
                                assert_eq!(denied.requested, bits);
                            }
'''+a))
