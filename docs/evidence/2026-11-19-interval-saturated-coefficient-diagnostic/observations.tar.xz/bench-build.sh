set -eu
cd "$s/bench-src"
for tag in control compact;do
 if test "$tag" = compact;then python3 "$s/compact.py" "$s/bench-src";fi
 CARGO_TARGET_DIR="$s/bench-target" cargo +1.95.0 build --release --locked -p hypersolve --all-features --bench certification --message-format=json-render-diagnostics > "$s/logs/$tag-bench.jsonl" 2>"$s/logs/$tag-bench-build"
 python3 - "$tag" <<'PY'
import os,sys,shutil,json
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1];p=next(r['executable'] for r in map(json.loads,(s/'logs'/(tag+'-bench.jsonl')).read_text().splitlines()) if r.get('executable'));shutil.copy2(p,s/(tag+'-certification'))
PY
done
