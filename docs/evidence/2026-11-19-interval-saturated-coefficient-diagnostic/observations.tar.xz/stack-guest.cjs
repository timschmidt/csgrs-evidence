const fs=require('fs'),assert=require('node:assert/strict');
const bytes=fs.readFileSync(process.argv[2]);
let pos=8;
function uleb(){let value=0,shift=0;do{const b=bytes[pos++];value+=(b&127)*2**shift;shift+=7;if(b<128)return value}while(shift<36);throw Error('bad ULEB')}
let top;
while(pos<bytes.length){
 const k=bytes[pos++],len=uleb(),end=pos+len;
 if(k===6){
  assert(uleb()>=1);assert.equal(bytes[pos++],0x7f);assert.equal(bytes[pos++],1);
  assert.equal(bytes[pos++],0x41);top=uleb();assert.equal(bytes[pos++],0x0b);
 }
 pos=end;
}
assert.equal(top,1048576);
(async()=>{
 const mod=await WebAssembly.compile(bytes);
 for(const d of [1,4,32])for(const deny of [0,1])for(const warm of [0,1])for(const pat of [0xa5,0x5a]){
  const api=(await WebAssembly.instantiate(mod,{})).exports;
  if(warm)assert.equal(api.run_scope(1,d,deny),BigInt(1+33*deny));
  new Uint8Array(api.memory.buffer,0,top).fill(pat);
  assert.equal(api.run_scope(1,d,deny),BigInt(1+33*deny));
  const first=new Uint8Array(api.memory.buffer,0,top).findIndex(b=>b!==pat);
  assert(first>0 && first<top);
  console.log(d,deny,warm,pat,top-first);
 }
})().catch(e=>{console.error(e);process.exitCode=1});
