set -eu
tag=$1
case "$tag" in index) python3 "$s/owner-index.py" "$s/src";; esac
cd "$s/src"
rustfmt +1.95.0 --edition 2024 crates/hypersolve/src/work_budget.rs
git diff > "$s/$tag.patch"
python3 "$s/measure.py" "$tag" > "$s/logs/$tag-builds" 2>&1 &
p=$!
python3 "$s/profile.py" "$tag" > "$s/logs/$tag-memory" 2>&1 &
q=$!
bash "$s/observe.sh" "$tag" > "$s/logs/$tag-oracles" 2>&1 &
r=$!
wait "$p";wait "$q";wait "$r"
