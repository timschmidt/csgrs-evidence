from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,sys,subprocess
from metrics import metrics
s=Path(os.environ['s']);tag=sys.argv[1]
def run(v):
 for t in ('x86_64-unknown-linux-gnu','wasm32-wasip1'):
  env=os.environ|{'CARGO_TARGET_DIR':str(s/f'fast-target-{v}'),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot='+str(s/('sysroot-'+v))}
  with (s/'logs'/f'{tag}-render-{v}-{t}.build').open('w') as f:subprocess.run(['cargo','+'+v,'build','--release','--locked','--manifest-path',s/'client/Cargo.toml','--bin','render','--target',t],env=env,check=True,stderr=f)
  wasm=t.startswith('wasm');binary=s/f'fast-target-{v}'/t/'release'/('render.wasm' if wasm else 'render')
  rows={}
  for case in ('ordinary','word','observed','equal','both','largest'):
   cmd=[str(s/'node/node'),str(s/'src/crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),str(binary)] if wasm else [str(binary)]
   out=subprocess.check_output([*cmd,case],env=env,stderr=subprocess.DEVNULL,text=True)
   for ln in out.strip().splitlines():
    parts=ln.split(' ',8);assert len(parts)==9 and parts[1]==case
    rows[(case+'/'+parts[0])]=dict(zip(['alloc','free','realloc','traffic','peak','retained'],map(int,parts[2:8])))|{'display':parts[-1]}
  (s/f'{tag}-render-{v}-{t}.json').write_text(json.dumps({'metrics':metrics(binary),'samples':rows},indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(run,['1.95.0','stable']))
