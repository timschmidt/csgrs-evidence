from pathlib import Path
import sys
root=Path(sys.argv[1])
p=root/'crates/hypersolve/tests/coefficient_bit_budget.rs';x=p.read_text().replace('                            assert_eq!(denied.used, 0);','''                            assert_eq!(denied.limit, if bits > outer { outer } else { inner });
                            assert_eq!(denied.requested, bits);
                            assert_eq!(denied.used, 0);''')
assert x.count('if bits > outer { outer } else { inner }')==1
x=x.replace('for request in [23, usize::MAX as u64] {','for request in [23, u64::from(u32::MAX), 1 << 32, (1 << 32) + 1, 1 << 63, u64::MAX] {')
p.write_text(x)
p=root/'crates/hypersolve/README.md';x=p.read_text();old='''The limit and
observed bit count are compared as `u64`. On 32-bit targets the error currently
saturates each reported count above `usize::MAX`, including in its display.''';assert old in x
p.write_text(x.replace(old,'''The error preserves both the configured limit and the observed bit count as
`u64`, including in its display on 32-bit targets.'''))
p=root/'docs/MIGRATIONS.md';x=p.read_text();k='# Migrations\n';assert x.startswith(k);p.write_text(x.replace(k,k+'''
## Full-width Hypersolve budget receipts (2026-11-19)

`hypersolve::work_budget::BudgetExceeded` now exposes `limit` and `requested`
as `u64`. Its `used` field and the refinement and promotion counters in
`WorkUsage` remain `usize`. Coefficient bit budgets already accept a `u64`
limit and observation. On 32-bit targets a denial above `usize::MAX` now
reports both original counts through the public fields and `Display`.
Hypercurve and Hyperbrep re-export the same receipt.

Store the two diagnostic fields as `u64`. Code that needs a platform-sized
count can use `usize::try_from(receipt.requested)` and handle overflow. Use
a lossless conversion of platform-sized work counts when constructing a
receipt or comparing its limit with a work counter. Unsuffixed integer
literals in receipt constructors continue to infer the field type.
''',1))
p=root/'crates/hypersolve/CHANGELOG.md';x=p.read_text();k='## [0.4.0] - Unreleased\n';assert k in x
p.write_text(x.replace(k,k+'''
- Preserve full-width coefficient limits and requests in budget errors on
  32-bit targets. The public `BudgetExceeded::limit` and `requested` fields
  now use `u64`. [Caller migration](../../docs/MIGRATIONS.md)
''',1))
