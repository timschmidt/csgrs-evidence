from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/tests/coefficient_bit_budget.rs';x=p.read_text()
at=x.index('#[test]\nfn materialized_product')
x=x[:at]+'''#[test]
fn denial_above_the_word_ceiling_keeps_the_strict_inequality() {
    let ceiling = u64::from(u32::MAX);
    for (limit, request) in [
        (ceiling, ceiling + 1),
        (ceiling + 1, ceiling + 2),
        (u64::MAX - 1, u64::MAX),
    ] {
        let denied = with_coefficient_bit_limit(limit, || observe_coefficient_bits(request))
            .result
            .unwrap_err();
        assert_eq!(denied.kind, WorkKind::CoefficientGrowth);
        let expected = if usize::BITS == 32 {
            "coefficient growth exceeded a limit of at least 4294967295 bits".to_owned()
        } else {
            format!("coefficient growth limit exceeded: {request} bits against a limit of {limit}")
        };
        assert_eq!(denied.to_string(), expected);
    }
}

'''+x[at:]
p.write_text(x)
