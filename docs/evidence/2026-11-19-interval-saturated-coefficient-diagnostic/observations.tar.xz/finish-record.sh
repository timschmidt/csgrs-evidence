set -eu
while ! test -f "$s/cgroup-events-1.95.0";do sleep 2;done
python3 "$s/account.py"
python3 "$s/summarize.py"
python3 "$s/publish.py"
python3 "$s/register.py"
python3 "$s/progress.py"
git diff --check
python3 - <<'PY'
import json,os
from pathlib import Path
s=Path(os.environ['s']);r=Path('/mnt/development/csgrs');key='saturated_coefficient_diagnostic';n=json.loads((s/'accepted-record.json').read_text())
idx=(r/'docs/evidence-archive.tsv').read_text().splitlines()
assert idx.count(n['row'])==1
for f in ['size','memory']:
 d=json.loads((r/f'docs/research/interval-{f}-accounts.json').read_text())[key]
 assert len(d['targets'])==4 and d['evidence_commit']==n['commit'] and d['source'].startswith('e5f757ad1')
assert (r/'INTERVAL_REFACTOR_PROGRESS.md').read_text().count('## Phase 7 coefficient denials at the 32-bit reporting ceiling')==1
PY
git add -- INTERVAL_REFACTOR_PROGRESS.md docs/research/interval-size-accounts.json docs/research/interval-memory-accounts.json docs/evidence-archive.tsv
git -c gc.auto=0 commit -m "Record coefficient diagnostic costs and full-width trials"
git status --short
