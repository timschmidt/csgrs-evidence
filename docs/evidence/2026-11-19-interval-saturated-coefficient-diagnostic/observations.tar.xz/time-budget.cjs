const fs=require('fs'),path=require('path'),{performance}=require('perf_hooks');
const [s,tc,stage,cpu]=process.argv.slice(2);
(async()=>{
 const mods=await Promise.all(['control',stage].map(async n=>(await WebAssembly.instantiate(fs.readFileSync(path.join(s,n+'-'+tc+'-budget_scope_client.wasm')),{})).instance.exports));
 let seed=116;function random(){seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296}
 const output={};
 const med=a=>{const v=[...a].sort((a,b)=>a-b);return (v[(v.length-1)>>1]+v[v.length>>1])/2};
 for(const d of [1,4,32])for(const deny of [0,1]){
  const size=Math.floor(4000/d),want=BigInt(size*(1+33*deny)),raw=[];
  for(let i=0;i<16;i++) for(const m of mods) if(m.run_scope(size,d,deny)!==want)throw Error('wrong warmup');
  for(let i=0;i<240;i++){
   const group=[[],[]];
   for(const j of(random()<0.5?[0,1,1,0]:[1,0,0,1])){
    const t=performance.now(),val=mods[j].run_scope(size,d,deny),elapsed=performance.now()-t;
    if(val!==want)throw Error('wrong result');
    group[j].push(elapsed*1e6/size)
   }
   raw.push(group.map(a=>(a[0]+a[1])/2))
  }
  const ratio=raw.map(([a,b])=>100*(b/a-1));
  const bootstrap=Array.from({length:2500},()=>med(ratio.map(()=>ratio[Math.floor(random()*ratio.length)]))).sort((a,b)=>a-b);
  output[d+'/'+deny]={raw,median:med(ratio),confidence:[bootstrap[62],bootstrap[2437]]};
 }
 fs.writeFileSync(path.join(s,stage+'-runtime-'+tc+'-wasm-'+cpu+'.json'),JSON.stringify(output)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
