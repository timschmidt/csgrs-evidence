#include <assert.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "stack.c"
typedef uint64_t (*Scope)(uint32_t,uint32_t,uint32_t);
typedef struct { Scope call; uint32_t depth; uint32_t denial; } Sample;
static void consume_scope(void *ctx) {
    Sample *v = ctx;
    assert(v->call(1,v->depth,v->denial)==1+33*v->denial);
}
int main(int argc, char **argv) {
    assert(argc==2);
    void *lib=dlopen(argv[1],RTLD_NOW);
    if(!lib){fprintf(stderr,"%s\n",dlerror());return 1;}
    Sample sample={.call=(Scope)dlsym(lib,"run_scope")};
    assert(sample.call);
    const unsigned depths[]={1,4,32},patterns[]={0xa5,0x5a};
    for(unsigned i=0;i<3;i++)for(unsigned j=0;j<2;j++)
        for(unsigned warm=0;warm<2;warm++)for(unsigned k=0;k<2;k++) {
            sample.depth=depths[i];sample.denial=j;
            size_t peak=measure_stack(consume_scope,&sample,warm,patterns[k]);
            printf("%u %u %u %u %zu\n",sample.depth,j,warm,patterns[k],peak);
        }
    return 0;
}
