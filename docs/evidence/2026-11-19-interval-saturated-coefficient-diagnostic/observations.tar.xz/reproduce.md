# Hypersolve coefficient denial on a 32-bit target

Use independent checkouts of csgrs at 282fec460 in a disposable directory
under /mnt/development. Set s, TMPDIR, CARGO_HOME, GMP_MPFR_SYS_CACHE and
CARGO_TARGET_DIR there. Keep each baseline and candidate for a measurement
at the same source path and build with the locked dependencies. The captured
env identifies this run's paths. It is host-specific. The observed toolchains
were 1.95.0 and stable 1.99.0, with Node 22.23.5. The WASI runner is the
repository's crates/hyperlattice-interval/conformance/run-wasi-test.mjs.
get-wasi.py verifies the target-standard-library archive against the installed
compiler's manifest when the Preview 1 sysroot is unavailable.

## Denial and output

Apply display-test.py on the preceding checkout and run the release
coefficient_bit_budget test, with --test-threads=1 --nocapture, on x86_64 and
wasm32-wasip1. The latter must show the contradictory equal-count message.
Use display.patch on the original checkout for the full retained change.
fixture.py also captures final file, code and function sizes. Run the six
external observation cases in render.py. The allocation probe ends with the
message materialized. drop.sh repeats the measurements with the message
dropped after the retry. The cold run includes initial TLS frame allocation.
The warm run starts with that capacity retained and records allocation deltas.
The lower-bound case has the same failed operation and independent retry on
each revision. Its rendered output intentionally differs.

measure.py builds five named solver test executables and six release examples
on the two native/WASI targets. account.py carries the archived target charges
and debits only positive changes. The consolidated stable native trivariate
test already exceeded its historical file budget, and can take no further
file charge. The expanded coefficient integration test retains the full
previous fixture charge and its 16 MiB file ceiling within a 64 MiB
qualification slot. Solver clients require std and are absent from the
Alumina firmware lockfile. No device flash allocation was made.

format-clients.sh builds the additional formatted-error consumer on the two
bare wasm32 and native compilers. format-cost.sh and format-reverse.cjs
exercise complete materialization, checksum, destruction and retry. The
JavaScript stack probe reads global zero's initial stack pointer and fills the
lower 1 MiB linear stack with two independent patterns before calling the
public consumer, on fresh or primed instances. It excludes JavaScript host
frames. The work-only native probe in stack.c (2 MiB pthread, one protected
guard page, 512-byte observer exclusion) is separate from the formatted WASM
probe. Run the full ordinary solver tests and the independent WASI inventories
using qualify.sh and wasi-solver.py. The owner Criterion sample and feedback.sh
exercise a resultant and all six certified feedback steps. Keep compared
benchmark executable names and raw TSV destinations equal length when measuring
the process allocator's live-at-start counter.

## Full-width trials

The compact, suffix, index and transparent patches are independent alternatives
against the preceding source. The maintained public receipt oracle and the
separate receipt-boundaries and observe clients cover all u64 inputs selected
by the fixtures. measure.py, profile.py and observe.sh record each gate.
The bare Wasm consumer's comparable timings use ordinary count 32 or 33,
independent of the newly correct wide receipt. timing.sh uses interleaved
orders on two pinned cores per target. The standalone consumer/src/lib.rs
also includes the later formatted case; for the original ordinary-work
trials use consumer-before.rs. The candidates were not merged. Their cost
evidence confers no new allowance. Historical rejected implementations and
their accounts remain in the 18 November coefficient-budget-width record.
