from pathlib import Path
import sys
root=Path(sys.argv[1])
f=root/'crates/hypersolve/src/work_budget.rs';x=f.read_text()
for old,new,count in [
 ('pub limit: usize,','pub limit: u64,',1),('pub requested: usize,','pub requested: u64,',1),
 ('            requested,\n','            requested: requested as u64,\n',1),
 ('                    limit,\n','                    limit: limit as u64,\n',1),
 ('requested: amount,','requested: amount as u64,',1),
 ('max_coefficient_bits: Option<u64>,','max_coefficient_bits: u64,',2),
 ('enter(budget, None, None, operation)','enter(budget, None, u64::MAX, operation)',1),
 ('enter(budget, Some(cancellation.clone()), None, operation)','enter(budget, Some(cancellation.clone()), u64::MAX, operation)',1),
 ('enter(WorkBudget::UNLIMITED, None, Some(bits), operation)','enter(WorkBudget::UNLIMITED, None, bits, operation)',1),
 ('frame.max_coefficient_bits.is_some_and(|limit| bits > limit)','bits > frame.max_coefficient_bits',1),
 ('let limit = frames[index].max_coefficient_bits.unwrap_or(0);','let limit = frames[index].max_coefficient_bits;',1),
 ('limit: usize::try_from(limit).unwrap_or(usize::MAX),','limit,',1),
 ('requested: usize::try_from(bits).unwrap_or(usize::MAX),','requested: bits,',1),
 ]:
 assert x.count(old)==count,(old,x.count(old));x=x.replace(old,new)
x=x.replace('    cancellation: Option<CancellationToken>,\n    max_coefficient_bits: u64,\n}', '    cancellation: Option<CancellationToken>,\n    // All observable bit counts fit in u64, so MAX admits the unrestricted domain.\n    max_coefficient_bits: u64,\n}')
f.write_text(x)
for name,olds in [
 ('crates/hyperbrep/tests/work_budget.rs',[('denied.limit, single.usage.refinements','denied.limit, single.usage.refinements as u64')]),
 ('crates/hypersolve/tests/trivariate_arithmetic.rs',[('exceeded.limit, promotions','exceeded.limit, promotions as u64')]),
 ('crates/hypersolve/tests/coefficient_bit_budget.rs',[('denied.limit as u64','denied.limit'),('denied.requested as u64','denied.requested')]),
]:
 f=root/name;x=f.read_text()
 for old,new in olds: assert old in x;x=x.replace(old,new)
 f.write_text(x)
