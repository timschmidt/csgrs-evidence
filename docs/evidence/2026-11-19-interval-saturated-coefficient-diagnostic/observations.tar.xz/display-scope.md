Owner Hypersolve work_budget Display, P6/P19/P30. On 32-bit systems two
maximal public count fields on a coefficient-growth denial entail a true
limit >= (2^32-1), a request > (2^32-1), and request > limit. The previous
text claims equal counts. The independent public corpus will exercise limits
at and above the exact word maximum, nested denial, sticky replay and retry,
including the largest valid pair. Existing representable receipts retain
their rejection, fields and text. Keep numeric and API limitations explicit.
For this smaller independent repair keep all existing per-image caps in
caps.json and existing cumulative charges. The registered coefficient test
already has its full-file cumulative charge and 16 MiB ceiling within the
64 MiB slot, with 16 MiB minimum remaining. Limit incremental file, section,
and function growth of this fixture to 16 KiB AND 1% each, 32 KiB AND 2%
for this series of added receipt assertions, carrying prior charges. For
the formatted-error lifetime on the identifiable overflow branch require
zero additional allocations above control and at most 128 bytes AND 5%
comparable peak or retained heap growth; keep all ordinary memory limits.
Distinguish the corrected text from an exact count pair.
