from pathlib import Path
import ctypes as c,os,random,time,json,statistics,sys
s=Path(os.environ['s']);tc,stage=sys.argv[1:3];cpu=int(sys.argv[3]);os.sched_setaffinity(0,{cpu})
libs=[c.CDLL(str(s/(v+'-'+tc+'-libbudget_scope_client.so'))) for v in ('control',stage)]
funcs=[v.run_scope for v in libs]
for f in funcs:f.argtypes=[c.c_uint32]*3;f.restype=c.c_uint64
rng=random.Random(116);out={}
for d in [1,4,32]:
 for deny in [0,1]:
  batch=2000//d;want=batch*(1+deny*33);rows=[]
  for f in funcs:assert f(batch,d,deny)==want
  for _ in range(240):
   groups=[[],[]]
   for i in ([0,1,1,0] if rng.randrange(2) else [1,0,0,1]):
    t=time.thread_time_ns();result=funcs[i](batch,d,deny);elapsed=time.thread_time_ns()-t
    assert result==want;groups[i].append(elapsed/batch)
   rows.append([statistics.mean(r) for r in groups])
  ratio=[100*(b/a-1) for a,b in rows];boot=sorted(statistics.median(rng.choices(ratio,k=len(ratio))) for _ in range(2500))
  out[f'{d}/{deny}']=dict(raw=rows,median=statistics.median(ratio),confidence=[boot[62],boot[-63]])
(s/(stage+'-runtime-'+tc+'-native-'+str(cpu)+'.json')).write_text(json.dumps(out)+'\n')
