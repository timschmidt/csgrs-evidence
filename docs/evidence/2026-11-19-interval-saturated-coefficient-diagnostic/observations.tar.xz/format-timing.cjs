const fs=require('fs'),path=require('path'),assert=require('node:assert/strict'),{performance}=require('perf_hooks');
const [s,tc,second,cpu]=process.argv.slice(2), labels=['control',second];
const median=a=>{const v=[...a].sort((a,b)=>a-b);return (v[v.length>>1]+v[(v.length-1)>>1])/2};
let seed=149;function rand(){seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296}
function hash(str){let n=0n;for(const b of Buffer.from(str))n=BigInt.asUintN(64,n*31n+BigInt(b));return n}
(async()=>{
const modules=await Promise.all(labels.map(async v=>(await WebAssembly.instantiate(fs.readFileSync(path.join(s,v+'-format-'+tc+'-budget_scope_client.wasm')),{})).instance.exports));
const result={};
for(const c of [1,4,32]){
 const pair=c==1?[31,32]:c==4?[4294967294,4294967295]:[4294967295,4294967295];
 const expects=labels.map(v=>hash(v==='display' && c===32?'coefficient growth exceeded a limit of at least 4294967295 bits':`coefficient growth limit exceeded: ${pair[1]} bits against a limit of ${pair[0]}`));
 const run=j=>BigInt.asUintN(64,modules[j].render_scope(512,c,0));
 for(let i=0;i<32;i++)for(let j=0;j<2;j++)assert.equal(run(j),expects[j]);
 let rows=[];
 for(let i=0;i<320;i++){
  let group=[[],[]];
  for(const j of(rand()<0.5?[0,1,1,0]:[1,0,0,1])){
    const t=performance.now(),val=run(j),delta=(performance.now()-t)*1e6/512;
    assert.equal(val,expects[j]);group[j].push(delta);
  }
  rows.push(group.map(r=>(r[0]+r[1])/2));
 }
 const ratio=rows.map(([a,b])=>100*(b/a-1));result[c]={rows,median:median(ratio)};
}
fs.writeFileSync(path.join(s,second+'-format-runtime-'+tc+'-'+cpu+'.json'),JSON.stringify(result)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
