import json,os
from pathlib import Path
from record import record
s=Path(os.environ['s'])
items=set()
for p in s.iterdir():
 if p.is_file() and (p.suffix in ('.md','.sh','.rs','.py','.c','.cjs','.json','.patch') or p.name.startswith(('cgroup-peak-','cgroup-events-')) or p.name=='env'):
  if p.name != 'accepted-record.json':items.add(p)
for rel in ['prior/shared.rs','consumer/Cargo.lock','consumer/Cargo.toml','consumer/src/lib.rs','client/Cargo.lock','client/Cargo.toml']:
 p=s/rel;assert p.is_file(),p;items.add(p)
items.update(p for p in (s/'client/src').rglob('*') if p.is_file())
items.update(p for p in (s/'logs').iterdir() if p.is_file() and p.suffix!='.jsonl')
for d in ['display-wasi','display-wasi-1.95.0','cgroup-wasi-stable','cgroup-wasi-1.95.0']:
 items.add(s/d/'report.json')
 if d.startswith('display'):
  items.update(p for p in (s/d).iterdir() if p.is_file())
assert all(p.is_file() and p.stat().st_size<12*1024**2 and p.is_relative_to(s) for p in items)
result=record('saturated-coefficient-diagnostic',sorted(items),'Archive coefficient receipt and bounded-format qualification');(s/'accepted-record.json').write_text(json.dumps(result,indent=2)+'\n');print(result['commit'],result['members'])
