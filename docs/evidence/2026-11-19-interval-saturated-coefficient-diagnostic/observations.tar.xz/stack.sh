set -eu
tag=$1
for tc in stable 1.95.0;do
 "$s/native-stack" "$s/$tag-$tc-libbudget_scope_client.so" > "$s/logs/$tag-$tc-native-stack"
 "$s/node/node" "$s/stack-guest.cjs" "$s/$tag-$tc-budget_scope_client.wasm" > "$s/logs/$tag-$tc-guest-stack"
done
