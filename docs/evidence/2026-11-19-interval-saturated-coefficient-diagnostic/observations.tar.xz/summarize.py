from pathlib import Path
import os,json,re,subprocess
s=Path(os.environ['s']);summary={}
for tc in ('1.95.0','stable'):
 tc_log=lambda name:(s/'logs'/f'display-{tc}-{name}').read_text()
 test_counts=lambda x:sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',x)))
 assert test_counts(tc_log('owner'))==1545
 assert test_counts(tc_log('minimal'))==4
 assert re.search(r'Finished .release. profile',tc_log('clippy')) and 'error:' not in tc_log('clippy')
 assert 'Generated ' in tc_log('doc') and 'error:' not in tc_log('doc')
 wasm=(s/'logs'/('display-wasi' if tc=='stable' else 'display-wasi-1.95.0')).read_text()
 assert '1519 direct WASI tests, 17 native parents with fresh WASI children, 5 native platform tests. 4212 Horner dispatch windows' in wasm
 scoped=(s/'logs'/f'display-scoped-{tc}').read_text()
 assert '1519 direct WASI tests' in scoped and 'Compiling ' not in scoped
 summary[tc]={'native_tests':1544,'native_doctests':1,'minimal':4,'clippy_all_targets_all_features':True,'rustdoc_warnings_denied':True,'direct_wasi_tests':1519,'fresh_guest_parents':17,'native_platform_tests':5,'dispatch_windows':4212,'prepared_job_peak_bytes':int((s/f'cgroup-peak-{tc}').read_text())}
for k,n in [('brep',7),('curve',1)]:
 text=(s/'logs'/f'display-downstream-{k}').read_text();assert test_counts(text)==n
summary['downstream']={'brep_tests':7,'curve_tests':1,'feedback_steps':json.loads((s/'feedback-review.json').read_text())['steps']}
assert (s/'logs/display-fmt').stat().st_size==0
(s/'qualification.json').write_text(json.dumps(summary,indent=2)+'\n')
