from pathlib import Path
import struct,hashlib,json,os
s=Path(os.environ['s'])
def read(p):
 b=p.read_bytes();off=struct.unpack_from('<Q',b,40)[0];size,count,nam=struct.unpack_from('<HHH',b,58)
 rows=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(count)];t=rows[nam];names=b[t[4]:t[4]+t[5]]
 return {names[r[0]:].split(b'\0',1)[0].decode():b[r[4]:r[4]+r[5]] for r in rows if r[2]&2 and r[1]!=8}
a=read(s/'control-certification');b=read(s/'display-certification');assert a.keys()==b.keys()
res={k:{'size':[len(a[k]),len(b[k])],'sha256':[hashlib.sha256(a[k]).hexdigest(),hashlib.sha256(b[k]).hexdigest()],'different_byte_count':sum(x!=y for x,y in zip(a[k],b[k]))+abs(len(a[k])-len(b[k]))} for k in a}
(s/'owner-loaded-sections.json').write_text(json.dumps(res,indent=2)+'\n');print([(k,v['different_byte_count']) for k,v in res.items() if v['different_byte_count']])
