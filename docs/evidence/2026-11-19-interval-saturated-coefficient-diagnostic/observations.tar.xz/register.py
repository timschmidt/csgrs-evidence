import json,os,re,subprocess
from pathlib import Path
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
def read(p):return json.loads(p.read_text())
def append(path,key,v):
 text=path.read_text();assert text.endswith('\n}\n') and key not in json.loads(text)
 snippet=json.dumps({key:v},indent=2,ensure_ascii=False)[2:-2]
 new=text[:-3]+',\n'+snippet+'\n}\n';assert json.loads(new)[key]==v;path.write_text(new)
source=subprocess.check_output(['git','-C',root,'rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','-C',root,'show','-s','--format=%s',source],text=True).strip()=='Report the lower bound for saturated coefficient denials'
e=read(s/'accepted-record.json');record=e['record'];base={'source':source,'previous':'282fec460','evidence':record,'evidence_commit':e['commit']}
sz=read(s/'size-review.json');pub=read(s/'public-images.json');st={};mem={}
for key,v in sz.items():
 tc,target=key.split('-',1);slot=67108864;fmt=pub[tc+('-wasm' if target.startswith('wasm') else '-native')]
 st[key]={'registered_legacy_images':len(v['legacy']),'maximum_positive_legacy_step':{m:max(row[m][4] for row in v['legacy'].values()) for m in ('file','code','functions')},'minimum_legacy_slot_headroom':v['minimum_slot_headroom'],'fixture':v['fixture'],'fixture_free_slot_bytes':v['fixture_headroom'],'public_render_file_code_functions':v['render'],'additional_external_client':{m:[fmt['previous'][m],fmt['retained'][m]] for m in ('file','code','functions')}}
 a,b=[read(s/f'{tag}-render-{key}.json')['samples'] for tag in ('control','display')]
 d=read(s/f'display-renderdrop-{key}.json')['samples']
 mem[key]={'heap':{state:{m:[a['both/'+state][m],b['both/'+state][m]] for m in ('peak','retained','alloc','realloc')}|{'live_after_drop':d['both/'+state]['retained']} for state in ('cold','warm')}}
 if 'stack' in fmt:
  mem[key]['bare_wasm_stack_bytes_by_case_and_warmth']=fmt['stack']
  peak=int((s/f'cgroup-peak-{tc}').read_text());prev=read(root/'docs/research/interval-memory-accounts.json')['produced_tensor_coefficient_qualification']['targets'][tc]
  inc=max(0,peak-prev['measured_peak_bytes']);carry=prev['cumulative_positive_job_bytes']+inc;assert carry<=1073741824-268435456
  mem[key]['compiled_job']={'previous_peak':prev['measured_peak_bytes'],'new_peak':peak,'previous_charge':prev['cumulative_positive_job_bytes'],'positive_step':inc,'cumulative_charge':carry,'free_after_charge':1073741824-carry}
append(root/'docs/research/interval-size-accounts.json','saturated_coefficient_diagnostic',base|{
 'benefit':'A simultaneous 32-bit ceiling in a coefficient denial now reports a justified lower bound. The executable suite also checks both individually representable counts across the 512 nested triples.',
 'program_budget':'Carry the historical c9f1f9ac5 solver and legacy accounts, the 063cb703d nested suite and the c73863d18 produced-denominator test file charge. The 282fec460 matched release is the preceding revision. The new standalone formatted-error clients use their first matched 282fec460 images as their workload baseline.',
 'caps':'Legacy file, executable code and defined-function bytes: 4096 bytes and 1% incremental, 8192 bytes and 2% cumulative (earlier target-specific caps and exhausted accounts remain binding). New fixture assertions: 16384 bytes and 1% incremental, 32768 bytes and 2% for the new assertion series, retaining historical full image charges and the 16 MiB ceiling. Standalone clients: 4096 bytes and 1% incremental, 8192 bytes and 2% cumulative, at most 16 MiB file.',
 'capacity_bytes':67108864,'required_headroom_bytes':16777216,'targets':st,'raw':'size-review.json contains all 44 per-image comparable accounts. public-images.json contains both bare modules and both native libraries. The 1.95 native owner benchmark has identical loaded bytes outside its build ID. No firmware links Hypersolve in the measured program.'})
append(root/'docs/research/interval-memory-accounts.json','saturated_coefficient_diagnostic',base|{
 'scope':'Release public Hypersolve denial, owned formatted message, nested scopes, sticky failure, cleanup and independent retry. The six inputs include ordinary, word ceiling, one or two saturated counts and the largest new denial. Warm runs begin with the thread-local frame storage already allocated.',
 'caps':'No comparable heap or stack debit. Retain earlier charges. The two prepared native/WASI qualification jobs retain the 1 GiB cgroup limit, zero swap and 256 MiB minimum headroom. Bare wasm32 has a 1 MiB linear stack and 512 KiB minimum headroom. Each target, input and cold/warm state stands alone.',
 'targets':mem,'raw':'*-render-*.json materialize the output. *-renderdrop-*.json end after its destruction. public-images.json gives the high watermarks for two fill patterns. Unretained full-width trials remain separate.'})
