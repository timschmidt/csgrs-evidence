from pathlib import Path
import os,json,statistics,re
from metrics import metrics
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
def read(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
caps=read(s/'caps.json');carried=read(s/'carried-accounts.json')['targets'];legacy=read(s/'carried-univariate.json')
size=read(root/'docs/research/interval-size-accounts.json');prior_fixture=size['produced_tensor_coefficient_budget']['targets']
res={};trials={}
for key,limits in caps.items():
 base=read(s/f'control-{key}.json');new=read(s/f'display-{key}.json');out={}
 for n,start in base.items():
  a=carried[key]['artifacts'].get(n,{}).get('charges',{})
  prior_native=(legacy.get(f'crates/hypersolve/examples/{n}.rs',{}) if key=='1.95.0-x86_64-unknown-linux-gnu' else {})
  rows={}
  for m in ('file','code','functions'):
   previous=a.get(m,{});other=prior_native.get({'file':'file','code':'text','functions':'named_text'}[m],{})
   old=max(previous.get('cumulative_charge',0),other.get('cumulative_lower_bound',0))
   step=new[n][m]-start[m];charge=max(0,step);cum=old+charge
   # The ordinary target budgets in force are sufficient for this localized fix.
   step_cap=min(4096,start[m]//100)
   denom=previous.get('fixed',other.get('fixed',start[m]))
   cum_cap=min(previous.get('cumulative_cap',other.get('caps',{}).get('cumulative_bytes',8192)),denom*2//100)
   rows[m]=[start[m],new[n][m],round(100*step/start[m],5),old,charge,cum,step_cap,cum_cap,cum_cap-cum]
   assert charge<=step_cap and (cum<=cum_cap or charge==0),(key,n,m,rows[m])
  out[n]=rows
 assert min(64*1024**2-r['file'] for r in new.values())>=16*1024**2
 before=read(s/f'fixture-base-fixture-{key}.json');test=read(s/f'display-fixture-{key}.json');pf=prior_fixture[key]
 fixture={}
 for m,oldkey in [('file','cumulative_file_charge'),('code','executable_code_bytes'),('functions','function_bytes')]:
  old=pf[oldkey]
  # The preceding final file already incorporates intervening build differences.
  carry=max(old,before[m]);delta=max(0,test[m]-before[m]);cumulative=carry+delta
  step_cap=min(16384,before[m]//100);absolute=16*1024**2
  assert delta<=step_cap and cumulative<=absolute and cumulative>=test[m]
  fixture[m]={'historical':old,'preceding':before[m],'retained':test[m],'carry':carry,'step':delta,'cumulative':cumulative,'step_cap':step_cap,'cumulative_ceiling':absolute,'remaining':absolute-cumulative}
 renderbase=read(s/f'control-render-{key}.json');render=read(s/f'display-render-{key}.json')
 for n,prev in renderbase['samples'].items():
  cur=render['samples'][n]
  for m in ('peak','retained','traffic','alloc','realloc'):
   assert cur[m]<=prev[m],(key,n,m,cur[m],prev[m])
 res[key]={'legacy':out,'minimum_slot_headroom':min(64*1024**2-r['file'] for r in new.values()),'fixture':fixture,'fixture_headroom':64*1024**2-test['file'],'render':{m:[renderbase['metrics'][m],render['metrics'][m]] for m in ('file','code','functions')}}
 for tag in ('compact','suffix','index','transparent'):
  cand=read(s/f'{tag}-{key}.json');over=[(n,m,cand[n][m]-base[n][m],cap['incremental_bytes']) for n,ms in limits.items() for m,cap in ms.items() if (cand[n][m]-base[n][m])>min(cap['incremental_bytes'],cap['incremental_percent']*base[n][m]/100)]
  old=read(s/f'control-{key}-lifetime.json');nn=read(s/f'{tag}-{key}-lifetime.json');overmem=[]
  for o in old:
   c=next(v for v in nn if all(o[k]==v[k] for k in ('mode','depth','state')))
   for m in ('peak','retained','alloc','realloc'):
    cap=min(128,o[m]//20) if m in ('peak','retained') else 0
    if c[m]-o[m]>cap:overmem.append([o['mode'],o['depth'],o['state'],m,o[m],c[m],cap])
  trials.setdefault(tag,{})[key]={'size_failure':over,'heap_failure':overmem}
save(s/'size-review.json',res);save(s/'trials-review.json',trials)
