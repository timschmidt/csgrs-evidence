from pathlib import Path
import json,os,subprocess
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
def read(p):return json.loads(p.read_text())
q=read(s/'qualification.json');n=read(s/'accepted-record.json');c=subprocess.check_output(['git','-C',root,'rev-parse','--short=9','HEAD'],text=True).strip()
p=root/'INTERVAL_REFACTOR_PROGRESS.md';t=p.read_text();old='Quadratic alpha and univariate quadratic Krawczyk rows require certified comparisons | preserve coefficient-growth diagnostic counts'
new='Quadratic alpha and univariate quadratic Krawczyk rows require certified comparisons. Simultaneously saturated coefficient receipts display a proven lower bound | preserve coefficient-growth diagnostic counts'
assert t.count(old)==1;t=t.replace(old,new)
t+=f'''
## Phase 7 coefficient denials at the 32-bit reporting ceiling

On `282fec460`, an observed coefficient of 4,294,967,297 bits against a
4,294,967,296-bit ceiling correctly exhausted its scope on WASI. Its error
claimed that 4,294,967,295 bits exceeded 4,294,967,295. In `{c}` the
message preserves the known inequality and gives the configured limit's
lower bound when both fields reach the reporting ceiling. The regression
covers a limit exactly at the 32-bit maximum, a larger limit and the
largest possible denied `u64` observation. The 512 nested triples also
check the exact value of each independently representable field. The public
fields still saturate on 32-bit targets. A single saturated request can
still appear as the word maximum in the message.
[Public tests](crates/hypersolve/tests/coefficient_bit_budget.rs)

Both Rust 1.95.0 and 1.99.0 passed 1,544 native solver tests and the
doctest, the minimal-feature coefficient suite, all-target all-feature
Clippy, and Rustdoc with warnings denied. Each WASI qualification passed
1,519 direct tests, 17 native parents with fresh guest children, five
native platform cases and 4,212 matched Horner dispatch windows. Seven
Hyperbrep budget tests and the filleted-hyperbola Hypercurve stroke passed.
The six-step feedback benchmark preserved every semantic and allocation
column. Outside the build ID, all loaded native certification-benchmark
sections matched. Its timings varied while the machine was compiling.

Materializing the corrected WASI message used 77 fewer requested bytes
and two fewer reallocations. The warm measurement after the message was
dropped returned to zero. A cold run retained the same 224-byte frame
capacity. The bare-Wasm client grew by 104 file bytes and 43 code bytes on
both compilers. Its warm corrected-message stack fell by 32 bytes.
Two opposing measurement orders on two cores gave 43–49% lower times
for the corrected message, including checksum, destruction and retry.
The independent equal-result controls varied with instance order.
Across 44 registered release images the largest file increase was 144
bytes. The expanded coefficient suite grew by 3,216–5,705 file bytes.
[Size accounts](docs/research/interval-size-accounts.json) ·
[Memory accounts](docs/research/interval-memory-accounts.json)

Four independent source trials preserved the full `u64` counts in the
81-pair public oracle on both compilers and targets. Storing the
unrestricted internal ceiling as `u64::MAX` held the WASI frame heap
constant. The wider receipt still added 520 bytes of stack for 32 nested
unlimited scopes in that trial. Sharing one receipt by failing-frame index
reduced native cost, but slowed WASM. Eliding redundant unlimited child
frames sped up deep nesting, while a single successful WASM scope remained
18–23% slower. The shared denial-loop trial exceeded both WASI solver
unit-test image budgets. The full-width public-field migration remains open.
The trials consume no production allowance. Evidence commit `{n['commit']}`.
[Evidence index](docs/evidence-archive.tsv)
'''
p.write_text(t)
