set -eu
cd "$s/consumer-src"
git restore -- crates/hypersolve/src/work_budget.rs crates/hypersolve/tests/coefficient_bit_budget.rs crates/hypersolve/tests/trivariate_arithmetic.rs crates/hyperbrep/tests/work_budget.rs
for v in control display;do
 if test "$v" = display;then cp /mnt/development/csgrs/crates/hypersolve/src/work_budget.rs crates/hypersolve/src/work_budget.rs;fi
 for tc in 1.95.0 stable;do
  (
   for t in wasm32-unknown-unknown x86_64-unknown-linux-gnu;do
    CARGO_TARGET_DIR="$s/consumer-target-$tc" cargo +"$tc" build --offline --release --manifest-path "$s/consumer/Cargo.toml" --target "$t" > "$s/logs/$v-format-$tc-$t.build" 2>&1
    if test "$t" = x86_64-unknown-linux-gnu;then f=libbudget_scope_client.so;else f=budget_scope_client.wasm;fi
    cp "$s/consumer-target-$tc/$t/release/$f" "$s/$v-format-$tc-$f"
   done
  ) &
 done
 fail=0;for p in $(jobs -p);do wait "$p" || fail=1;done;test "$fail" -eq 0
done
