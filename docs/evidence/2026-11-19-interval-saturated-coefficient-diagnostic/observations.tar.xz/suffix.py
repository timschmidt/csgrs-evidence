from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/work_budget.rs';x=p.read_text()
k='// The outermost cancelled scope exhausts itself'
assert x.count(k)==1
x=x.replace(k,'''// Callers check the innermost frame before making a new denial. A previous
// failure marks every nested frame, including children entered after it.
#[cold]
fn exhaust(frames: &mut [Frame], error: BudgetExceeded) -> BudgetExceeded {
    for frame in frames {
        frame.exhausted = Some(error);
    }
    error
}

'''+k)
a='''    let error = BudgetExceeded::cancelled(requested);
    for frame in &mut frames[index..] {
        frame.exhausted.get_or_insert(error);
    }
    frames.last().and_then(|frame| frame.exhausted)'''
assert x.count(a)==1;x=x.replace(a,'    Some(exhaust(&mut frames[index..], BudgetExceeded::cancelled(requested)))')
a='''                for frame in &mut frames[index..] {
                    frame.exhausted = Some(error);
                }
                return Err(error);'''
assert a in x;x=x.replace(a,'                return Err(exhaust(&mut frames[index..], error));')
a='''        for frame in &mut frames[index..] {
            frame.exhausted.get_or_insert(error);
        }
        Err(frames
            .last()
            .and_then(|frame| frame.exhausted)
            .unwrap_or(error))'''
assert a in x;x=x.replace(a,'        Err(exhaust(&mut frames[index..], error))')
p.write_text(x)
