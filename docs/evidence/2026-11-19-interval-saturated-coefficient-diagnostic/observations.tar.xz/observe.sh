set -eu
stage=$1
for tc in 1.95.0 stable; do
 export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot=$s/sysroot-$tc" CARGO_TARGET_DIR="$s/fast-target-$tc"
 for t in wasm32-wasip1 x86_64-unknown-linux-gnu;do
  cargo +"$tc" build --locked --release --manifest-path "$s/client/Cargo.toml" --bins --target "$t" > "$s/logs/$stage-$tc-$t.oracles-build" 2>&1
  for binary in observe receipt-boundaries; do
   p="$CARGO_TARGET_DIR/$t/release/$binary"; cmd=("$p")
   if test "$t" = wasm32-wasip1;then cmd=("$s/node/node" "/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs" "$p.wasm");fi
   log="$s/logs/$stage-$tc-$t-$binary"
   if "${cmd[@]}" > "$log" 2>&1; then
     test "$stage:$t" != control:wasm32-wasip1
   else
     test "$stage:$t" = control:wasm32-wasip1
     if test "$binary" = observe;then rg -q 'limit=4294967295 requested=4294967295 expected=4294967296,4294967297' "$log";fi
   fi
  done
 done
done
