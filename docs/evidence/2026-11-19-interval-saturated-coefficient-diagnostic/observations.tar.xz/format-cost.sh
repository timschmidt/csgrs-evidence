set -eu
for tc in 1.95.0 stable; do
 for v in control display; do
   for ((i=0;i<500;i++));do test -f "$s/$v-format-$tc-budget_scope_client.wasm" && break; sleep 1;done
   "$s/node/node" "$s/format-stack.cjs" "$s/$v-format-$tc-budget_scope_client.wasm" > "$s/logs/$v-format-stack-$tc"
   for cpu in 8 19; do taskset -c "$cpu" "$s/node/node" "$s/format-timing.cjs" "$s" "$tc" "$v" "$cpu" > "$s/logs/$v-format-timing-$tc-$cpu" 2>&1 & done
   fail=0;for p in $(jobs -p);do wait "$p" || fail=1;done;test "$fail" -eq 0
 done
done
