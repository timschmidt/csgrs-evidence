from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/work_budget.rs';x=p.read_text()
a='    enter(budget, None, u64::MAX, operation)'
assert x.count(a)==1
x=x.replace(a,'''    if budget == WorkBudget::UNLIMITED && is_active() {
        // An enclosing frame starts no later, so it will deny an overflowing
        // unit first. A child without a limit or cancellation token observes
        // exactly the work charged to that frame during its callback.
        let start = STACK.with_borrow(|stack| stack.frames.last().expect("active budget").usage);
        let value = operation();
        return STACK.with_borrow(|stack| {
            let end = stack.frames.last().expect("active budget").usage;
            BudgetOutcome {
                usage: WorkUsage {
                    refinements: end.refinements - start.refinements,
                    promotions: end.promotions - start.promotions,
                },
                result: match stack.exhaustion() {
                    Some(error) => Err(error),
                    None => Ok(value),
                },
            }
        });
    }
    enter(budget, None, u64::MAX, operation)''')
p.write_text(x)
