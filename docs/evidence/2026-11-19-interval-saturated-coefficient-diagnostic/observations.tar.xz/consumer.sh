set -eu
for tag in control compact;do
 if test "$tag" = compact;then python3 "$s/compact.py" "$s/consumer-src";fi
 for tc in 1.95.0 stable; do
  for t in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
   CARGO_TARGET_DIR="$s/consumer-target-$tc" CARGO_BUILD_JOBS=5 cargo +"$tc" build --manifest-path "$s/consumer/Cargo.toml" --release --offline --target "$t" >> "$s/logs/$tag-consumer-$tc" 2>&1
   if test "$t" = x86_64-unknown-linux-gnu;then f=libbudget_scope_client.so;else f=budget_scope_client.wasm;fi
   cp "$s/consumer-target-$tc/$t/release/$f" "$s/$tag-$tc-$f"
  done
 done
done
