from pathlib import Path
import sys
for item in sys.argv[1:]:
 p=Path(item);x=p.read_text();a='coefficient growth limit exceeded: observed bit length exceeds a limit of at least 4294967295 bits';assert a in x;p.write_text(x.replace(a,'coefficient growth exceeded a limit of at least 4294967295 bits'))
