set -eu
tag=$1
cd "$s/consumer-src"
git restore -- crates/hypersolve/src/work_budget.rs crates/hypersolve/tests/coefficient_bit_budget.rs crates/hypersolve/tests/trivariate_arithmetic.rs crates/hyperbrep/tests/work_budget.rs
git apply "$s/$tag.patch"
for tc in 1.95.0 stable;do
 for t in x86_64-unknown-linux-gnu wasm32-unknown-unknown;do
  (
   CARGO_TARGET_DIR="$s/consumer-target-$tc" CARGO_BUILD_JOBS=3 cargo +"$tc" build --manifest-path "$s/consumer/Cargo.toml" --release --offline --target "$t" > "$s/logs/$tag-consumer-$tc-$t" 2>&1
   if test "$t" = x86_64-unknown-linux-gnu;then f=libbudget_scope_client.so;else f=budget_scope_client.wasm;fi
   cp "$s/consumer-target-$tc/$t/release/$f" "$s/$tag-$tc-$f"
  ) &
 done
done
fail=0;for p in $(jobs -p);do wait "$p" || fail=1;done;exit "$fail"
