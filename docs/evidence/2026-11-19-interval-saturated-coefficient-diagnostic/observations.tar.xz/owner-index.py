import os,sys,subprocess
from pathlib import Path
s=Path(os.environ["s"])
root=Path(sys.argv[1])
f=root/"crates/hypersolve/src/work_budget.rs"
# Replay the earlier single-owner implementation on current source, preserving
# all changes since the earlier experiment outside the replaced section.
now=f.read_text();old=(s/'prior/shared.rs').read_text()
k='struct Frame {'
i=now.index(k);j=old.index(k);x=now[:i]+old[j:]
for a,b in [
 ('max_coefficient_bits: Option<u64>', 'max_coefficient_bits: u64'),
 ('enter(budget, None, None, operation)', 'enter(budget, None, u64::MAX, operation)'),
 ('enter(budget, Some(cancellation.clone()), None, operation)', 'enter(budget, Some(cancellation.clone()), u64::MAX, operation)'),
 ('enter(WorkBudget::UNLIMITED, None, Some(bits), operation)','enter(WorkBudget::UNLIMITED, None, bits, operation)'),
 ('frame.max_coefficient_bits.is_some_and(|limit| bits > limit)', 'bits > frame.max_coefficient_bits'),
 ('stack.frames[index].max_coefficient_bits.unwrap_or(0)','stack.frames[index].max_coefficient_bits')]:
 assert a in x,a;x=x.replace(a,b)
f.write_text(x)
