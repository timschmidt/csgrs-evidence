import json,os,sys,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent
root=s/'src'

from metrics import metrics
stage=sys.argv[1]
def build(job):
 v,t=job
 env=os.environ|{'CARGO_BUILD_JOBS':'5','CARGO_TARGET_DIR':str(s/f'target-{v}-{t}')}
 env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/('sysroot-'+v))
 stem=s/'logs'/f'{stage}-{v}-{t}'
 suites=['ordered_field_resultant','selected_polynomial_fields','expression_program','trivariate_arithmetic']
 cmd=['cargo','+'+v,'test','--locked','--release','--all-features','-p','hypersolve','--no-run','--target',t,'--lib',*[arg for n in suites for arg in ('--test',n)],'--message-format=json-render-diagnostics']
 rows={}
 with Path(str(stem)+'.build-log').open('w') as log:
  for args in [cmd,['cargo','+'+v,'build','--locked','--release','--all-features','-p','hypersolve','--target',t,'--examples','--message-format=json-render-diagnostics']]:
   out=subprocess.check_output(args,cwd=root,env=env,stderr=log,text=True)
   for row in map(json.loads,out.splitlines()):
    if p:=row.get('executable'):
     rows[row['target']['name']]=metrics(Path(p))
     if row['target']['name'] in ('hypersolve','trivariate_arithmetic') and stage!='control':
      prefix=[p] if not t.startswith('wasm') else [str(s/'node/node'),str(root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),p]
      commands=[['work_budget::tests::coefficient_bit_','--test-threads=1']] if row['target']['name']=='hypersolve' else [['--test-threads=1','--skip','fresh_process']]
      for options in commands:
       with Path(str(stem)+'.'+row['target']['name']+'.run').open('w') as run:subprocess.run([*prefix,*options],stdout=run,stderr=subprocess.STDOUT,check=True)
 (s/f'{stage}-{v}-{t}.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(stage,v,t,len(rows),flush=True)
with ThreadPoolExecutor(4) as pool:list(pool.map(build,[(v,t) for v in ['stable','1.95.0'] for t in ['wasm32-wasip1','x86_64-unknown-linux-gnu']]))
