set -eu
tc=$1
if test "${2:-}" = measured;then
 export CARGO_TARGET_DIR="$s/qualification-$tc" CARGO_BUILD_JOBS=4 CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot=$s/sysroot-$tc"
 group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
 test "$(cat "$group/memory.max")" = 1073741824
 test "$(cat "$group/memory.swap.max")" = 0
 python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$tc" --output "$s/cgroup-wasi-$tc"
 cp "$group/memory.peak" "$s/cgroup-peak-$tc"
 cp "$group/memory.events" "$s/cgroup-events-$tc"
else
 while ! test -f "$s/rss-wasi-$tc/report.json";do sleep 2;done
 systemd-run --user --scope -q -p MemoryMax=1G -p MemorySwapMax=0 -- bash "$s/cgroup.sh" "$tc" measured
fi
