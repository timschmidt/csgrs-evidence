set -eu
s=/dev/shm/interval-flow-coverage
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/release-target" CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_BUILD_JOBS=8
cd "$s/control"
for pkg in hyperdynamics hyperphysics; do
    case "$pkg" in hyperdynamics) t=expression_field;; hyperphysics) t=certified_flow;; esac
    cargo test --release --locked -p "$pkg" --all-features --test "$t" --no-run --message-format=json-render-diagnostics > "$s/$1-$t.ndjson"
    bin=$(jq -rs --arg t "$t" '[.[] | select(.reason=="compiler-artifact" and .target.name==$t and .executable!=null) | .executable] | if length==1 then .[0] else error("test executable") end' "$s/$1-$t.ndjson")
    cp "$bin" "$s/$1-$t"
done
