from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;root=Path.cwd();other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-dynamics-coverage'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for path in s.iterdir():
    if path.is_file() and (path.suffix in {'.py','.sh','.patch','.json','.txt','.log'} or path.name=='scope'):
        files[path.name]=path.read_bytes()
meta=json.loads((s/'account.json').read_text());assert meta['source']==git(root,'rev-parse','HEAD').decode().strip()
for name in ['stable-before','stable-final','nightly-before','nightly-final']:
    directory=Path((s/(name+'.log')).read_text().splitlines()[0].removeprefix('Coverage artifacts in '))
    files[name+'/uncovered.txt']=(directory/'uncovered.txt').read_bytes()
    assert files[name+'.json']==(directory/'summary.json').read_bytes()
assert all(name in files for name in ('scope','clippy.log','all.log','minimal.log','docs.log','fmt.log','mutant-admission.log','overflow-mutation.log'))
files['revision.txt']=(meta['source']+'\n').encode()
archive=s/'record';archive.mkdir()
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
digests={k:sha(v) for k,v in sorted(files.items())}
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive Hyperdynamics coverage, budget mutations and linked harness sizes')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1])
