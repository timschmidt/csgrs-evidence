from pathlib import Path
import hashlib, json, subprocess, sys
s=Path(__file__).parent
def read(t,rev):
    path=s/(rev+'-'+t)
    rows=subprocess.check_output(['size','-A','-d',path],text=True).splitlines()
    text,=[int(row.split()[1]) for row in rows if row.startswith('.text ')]
    return {'file':path.stat().st_size,'text':text,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
account={'fixed':'c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb','preceding':'a7dd0ccd8',
         'evidence':'docs/evidence/2026-11-18-interval-dynamics-coverage','toolchain':'Rust 1.95.0, x86_64-unknown-linux-gnu, release, all features, test executables',
         'benefit':'Executable graph budget composition, aggregate overflow and provenance admission at the physical consumer boundary.',
         'caps':{'incremental_bytes':16384,'incremental_percent':1,'cumulative_bytes':32768,'cumulative_percent':2},
         'capacity_per_artifact':67108864,'required_free_per_artifact':16777216,'artifacts':{}}
for t in ['expression_field','certified_flow']:
    values={rev:read(t,rev) for rev in ['fixed','preceding','candidate']}
    metrics={}
    for key in ['file','text']:
        f,p,c=[d[key] for d in values.values()]
        inc=max(0,c-p);total=max(0,p-f)+inc
        metrics[key]={'fixed':f,'preceding':p,'retained':c,'incremental_charge':inc,'cumulative_charge':total,
                'remaining_incremental_bytes':16384-inc,'remaining_cumulative_bytes':32768-total,
                'remaining_incremental_percent':round(1-100*inc/p,6),'remaining_cumulative_percent':round(2-100*total/f,6)}
        print(t,key,f,p,c,inc,total,flush=True)
        assert inc<=16384 and inc*100<=p and total<=32768 and total*100<=2*f
    headroom=67108864-values['candidate']['file'];assert headroom>=16777216
    account['artifacts'][t]={'sha256':{k:v['sha256'] for k,v in values.items()},'metrics':metrics,'free_bytes':headroom}
if 'write' in sys.argv:
    account['source']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    path=Path('docs/research/interval-size-accounts.json');ledger=json.loads(path.read_text())
    assert 'dynamics_graph_budget_replay' not in ledger
    ledger['dynamics_graph_budget_replay']=account;path.write_text(json.dumps(ledger,indent=2)+'\n')
(s/'account.json').write_text(json.dumps(account,indent=2)+'\n')
