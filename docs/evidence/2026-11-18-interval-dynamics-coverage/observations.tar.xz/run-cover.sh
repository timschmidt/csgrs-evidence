set -eu
s=/dev/shm/interval-flow-coverage
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/$1-target"
if test "$1" = nightly; then
  export RUSTUP_HOME="$s/rustup" RUSTUP_TOOLCHAIN=nightly RUSTFLAGS=-Zcoverage-options=branch CARGO_BUILD_JOBS=8
fi
shift
python3 -B "$@" || {
  code=$?
  exit "$code"
}
