set -eu
s=/dev/shm/interval-flow-coverage
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/mutant-target"
cd "$s/mutant"
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hyperphysics/tests/certified_flow.rs')
s=p.read_text()
a=s.index('    assert!(matches!(\n        PointMassDynamics3::new',s.index('fn force_provenance_shares'))
b=s.index('    let mut exact',a)
p.write_text(s[:a]+'''    let incorrectly_admitted = PointMassDynamics3::new(Real::one(), forces.clone(), &mut small).unwrap();
    assert_eq!(incorrectly_admitted.provenance(), forces.provenance);
'''+s[b:])
PY
cargo test --locked -p hyperphysics --all-features --test certified_flow force_provenance_shares > "$s/mutant-admission.log" 2>&1
git restore -- crates/hyperdynamics/src/field/budget_adapter.rs
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hyperdynamics/src/field/budget_adapter.rs')
s=p.read_text()
p.write_text(s.replace('self.graph.check_entries(counts)','self.graph.check_entries(&[counts.iter().copied().fold(0usize, usize::wrapping_add)])'))
PY
git diff -- crates/hyperdynamics/src/field/budget_adapter.rs > "$s/overflow-mutation.patch"
result=0
cargo test --locked -p hyperdynamics --all-features --test expression_field > "$s/overflow-mutation.log" 2>&1 || result=$?
test "$result" -eq 101
rg -q 'check_entries\(&\[usize::MAX, 1\]\)' "$s/overflow-mutation.log"
