set -eu
s=/dev/shm/interval-flow-coverage
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/mutant-target" CARGO_BUILD_JOBS=8
root=$PWD
cd "$s/mutant"
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hyperdynamics/src/field/budget_adapter.rs')
s=p.read_text()
old='self.graph.check_entries(counts)'
assert s.count(old)==1
p.write_text(s.replace(old,'for count in counts { self.graph.check_entries(core::slice::from_ref(count))?; }\n        Ok(())'))
PY
git diff -- crates/hyperdynamics/src/field/budget_adapter.rs > "$s/mutation.patch"
for stage in previous candidate; do
  if test "$stage" = candidate; then
    for file in crates/hyperdynamics/tests/expression_field.rs crates/hyperphysics/tests/certified_flow.rs; do cp "$root/$file" "$file"; done
  fi
  for pkg in hyperdynamics hyperphysics; do
    if test "$pkg" = hyperdynamics; then t=expression_field; else t=certified_flow; fi
    result=0
    cargo test --locked -p "$pkg" --all-features --test "$t" >"$s/mutant-$stage-$t.log" 2>&1 || result=$?
    if test "$stage" = candidate; then
      test "$result" -eq 101
      rg -q '1 failed;' "$s/mutant-$stage-$t.log"
    else
      test "$result" -eq 0
    fi
  done
done
