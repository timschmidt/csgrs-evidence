from pathlib import Path
import hashlib, json, subprocess
s=Path(__file__).parent
def coverage(name):
    log=(s/(name+'.log')).read_text()
    assert log.splitlines()[-1]=='Production coverage is below 100% on the instrumented metrics.'
    directory=Path(log.splitlines()[0].removeprefix('Coverage artifacts in '))
    raw=(directory/'summary.json').read_bytes(); out=json.loads(raw)
    assert not out['llvm_diagnostics'] and out['profiles']>0 and (directory/'uncovered.txt').stat().st_size
    (s/(name+'.json')).write_bytes(raw)
    return out
before=coverage('original');after=coverage('compat')
for k in ['files','production','command','excluded_test_modules','without_records','rustc']:
    assert before[k]==after[k],k
assert before['command'][4]=='hyperinterval'
for build in ['stable','nightly']:
    old,new=[coverage(build+'-'+phase) for phase in ['before','final']]
    assert old['command']==new['command'] and new['command'][4]=='hyperdynamics'
    for k in ['files','production']:assert old[k].keys()==new[k].keys()
    for m,row in new['production'].items():assert row['count']==old['production'][m]['count'] and row['covered']>=old['production'][m]['covered']
    f='src/field/budget_adapter.rs'
    assert old['files'][f]['functions']['covered']==0 and new['files'][f]['functions']['covered']==5
    assert new['production']['functions']['covered']-old['production']['functions']['covered']==5
    assert bool(new['production']['branches']['count'])==(build=='nightly')
    print(build,new['production'],len(new['objects']),new['profiles'])
