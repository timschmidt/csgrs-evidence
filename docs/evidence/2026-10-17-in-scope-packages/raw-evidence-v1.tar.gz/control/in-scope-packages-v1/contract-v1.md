# In-scope package preparation after the user scope correction

Hypervoxel is deferred by explicit user instruction. Preserve all existing
features and dependencies; do not claim a successful whole-workspace release.
The root metadata graph, including optional path dependencies, identifies 14
publishable members whose complete local dependency closures avoid the deferred
crate. Five other in-scope packages retain their release blockers: HyperSDF,
CSGRS, CSGRS FFI, HyperDRC and Hypercircuit. The selection file lists every edge.
No workspace manifest or supported input domain is narrowed by this selection.

Relevant property P37 and T12; owning layer each selected crate's packaging
boundary. First complete the running MSRV qualification and preserve its result.
Use Cargo's native multi-package assembly and verification for the explicit
14-package selection, with all features. A new isolated worktree may combine
the already admitted Hyperreal package correction with the unchanged three-file
Hypercurve cache candidate; retain byte identities for both and leave the old
candidate worktree static. Reproduce and retain any newly encountered package
failure. No publish, source replacement, hidden registry mirroring, optional
feature removal or undeclared path override may substitute for a package pass.

Compare every actual nongenerated archive member to that prepared source and
retain normalized manifests, locks, VCS metadata, package identities, hashes,
full raw commands and outputs. Check that Cargo successfully builds the actual
extractions before claiming package verification; --no-verify and file lists
are not sufficient. Native staging of unpublished selected packages qualifies
prepublication buildability only, not availability to a public external user.
Root modeling's shipped consumer boundary remains blocked and explicit.

Use the unchanged validation_runner_v2 resource contract and separate fresh
Disk B target. Keep source, fixtures, policy and feature semantics intact.
Record the permitted preparation as a package graph check, not a performance
comparison, full test matrix, cache admission or full-plan completion.
