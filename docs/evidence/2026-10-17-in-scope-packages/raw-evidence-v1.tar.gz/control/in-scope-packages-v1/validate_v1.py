# Use native Cargo staging and archive builds for the explicit in-scope closure.
import gzip,hashlib,json,os,re,sys,tarfile,tomllib
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent;R=V/'checkout-release-candidate-v1'
T=V/'target-in-scope-packages-v1';M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
assert not T.exists() and not (V/'in-scope-package-protocol-v1.json').exists()
assert not reasons(resources())
prep=json.loads((V/'in-scope-package-preparation-v1.json').read_text())
selection=json.loads((W/'selection-v1.json').read_text());packages=selection['eligible_packages']
assert len(packages)==14 and len(selection['blocked_in_scope_packages'])==5
assert sha(W/'contract-v1.md')==prep['contract_sha256']
assert sha(W/'selection-v1.json')==prep['selection_sha256']
inventory=V/'release-candidate-source-inventory-v1.json.gz'
assert sha(inventory)==prep['source_inventory_sha256']
pins=json.loads(gzip.decompress(inventory.read_bytes()))
assert all(sha(R/p)==h for p,h in pins.items())
for name,row in packages.items():
    manifest=tomllib.loads((R/'crates'/name/'Cargo.toml').read_text())
    assert manifest['package']['name']==name and manifest['package']['version']==row['version']
    assert set(row['local_dependencies'])<=set(packages),(name,row['local_dependencies'])
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ.update(CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
command=[cargo,'package','--locked','--offline','--allow-dirty','--all-features']
for name in sorted(packages):command+=['-p',name]
name='in-scope-package-build-v1'
mapped={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/T.relative_to(V)),
    'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),
    'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
    '--bind',str(V),str(M),'--chdir',str(M/R.relative_to(V))]
for key,value in mapped.items():argv+=['--setenv',key,value]
argv+=command
dump(V/'in-scope-package-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),
    'contract_sha256':sha(W/'contract-v1.md'),'selection_sha256':sha(W/'selection-v1.json'),
    'preparation_sha256':sha(V/'in-scope-package-preparation-v1.json'),
    'source_inventory_sha256':sha(inventory),'tool_sha256':compiler['tool_sha256'],
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),'command':command,
    'environment':{'CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'},
    'selected_packages':packages,'blocked_in_scope_packages':selection['blocked_in_scope_packages'],
    'source_worktree':str(R),'target':str(T),'native_archive_build_verification_enabled':True,
    'hypervoxel_deferred_by_user':True,'cache_candidate_admitted':False,
    'whole_workspace_package_success_claim':False,'publication_or_public_availability_claim':False})
failure=None
try:result=run(name,argv,R,target=T)
except RuntimeError as error:
    result=json.loads((V/'logs'/name/'result.json').read_text())
    failure={'category':'resource_exhaustion' if result['stops'] else 'package_command_failed',
        'exit_code':result['exit_code'],'stops':result['stops'],'exception_type':type(error).__name__}
assert all(sha(R/p)==h for p,h in pins.items())
physical={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(T.rglob('*.crate'))}
dump(V/'in-scope-package-physical-archives-v1.json',physical)
if failure:
    dump(V/'in-scope-package-result-v1.json',{'diagnostic_run_complete':True,'selected_package_builds_passed':False,
        'command':result,'failure':failure,'physical_archives':physical,'source_unchanged':True,
        'hypervoxel_deferred_by_user':True,'cache_candidate_admitted':False,'release_qualified':False,'full_plan_complete':False})
    print(json.dumps({'selected_package_builds_passed':False,'failure':failure,'physical_archives':len(physical)}),flush=True)
    sys.exit(0)
final=list((T/'package').glob('*.crate'))
assert {p.name for p in final}=={n+'-'+r['version']+'.crate' for n,r in packages.items()}
text=(V/'logs'/name/'stdout').read_text()+'\n'+(V/'logs'/name/'stderr').read_text()
assert not re.search(r'^\s*(Compiling|Checking|Verifying|Packaging) hypervoxel\b',text,re.M)
assert all(re.search(r'^\s*Verifying '+re.escape(n)+r' v'+re.escape(r['version'])+r'\b',text,re.M)
           for n,r in packages.items())
inspections={}
for name,row in packages.items():
    prefix=name+'-'+row['version'];archive=T/'package'/(prefix+'.crate');source_root=R/'crates'/name
    members={};normalized=None
    with tarfile.open(archive,'r:gz') as source:
        for member in source:
            path=PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert path.parts[0]==prefix and len(path.parts)>1
            relative=str(PurePosixPath(*path.parts[1:]));assert relative not in members
            data=source.extractfile(member).read();digest=hashlib.sha256(data).hexdigest()
            original=source_root/('Cargo.toml' if relative=='Cargo.toml.orig' else relative)
            generated=relative in ['Cargo.toml','Cargo.lock','.cargo_vcs_info.json']
            if not generated:assert original.is_file() and sha(original)==digest,(name,relative)
            if relative=='Cargo.toml':normalized=tomllib.loads(data.decode())
            members[relative]={'bytes':len(data),'sha256':digest,'source_bytes_verified':not generated}
    assert normalized and normalized['package']['name']==name and normalized['package']['version']==row['version']
    assert not any(key in normalized for key in ['workspace','patch','replace'])
    for table in [normalized,*normalized.get('target',{}).values()]:
        for kind in ['dependencies','build-dependencies','dev-dependencies']:
            for dependency,value in table.get(kind,{}).items():
                assert not isinstance(value,dict) or 'path' not in value,(name,kind,dependency)
    inspections[name]={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,
        'members':members,'active_manifest_without_workspace_patches_or_paths':True,
        'nongenerated_members_equal_source_bytes':True,'native_cargo_build_verification_passed':True}
assert inspections['hypercurve']['members']['src/circle_support_cache_tests.rs']['sha256']==prep['cache_overlay_sha256']['crates/hypercurve/src/circle_support_cache_tests.rs']
assert not any(p.startswith('benchmarks/checkpoints/') and p.endswith('.tar.gz') for p in inspections['hyperreal']['members'])
(V/'in-scope-package-members-v1.json.gz').write_bytes(gzip.compress((json.dumps(inspections,sort_keys=True)+'\n').encode(),mtime=0))
assert all(sha(p)==row['sha256'] for p,row in physical.items())
assert all(sha(R/p)==h for p,h in pins.items())
warnings=[line for line in text.splitlines() if re.match(r'^\s*warning:',line)]
dump(V/'in-scope-package-result-v1.json',{'diagnostic_run_complete':True,'selected_package_builds_passed':True,
    'command':result,'selected_package_count':len(packages),'verified_final_archives':len(final),
    'independently_hashed_physical_archive_paths':len(physical),'warnings':warnings,
    'all_nongenerated_members_verified':True,'normalized_manifests_verified':True,'source_unchanged':True,
    'native_cargo_temporary_staging_only':True,'hypervoxel_deferred_by_user':True,
    'blocked_in_scope_packages':selection['blocked_in_scope_packages'],
    'whole_workspace_package_success_claim':False,'publication_or_public_availability_claim':False,
    'cache_candidate_admitted':False,'release_qualified':False,'full_plan_complete':False})
print(json.dumps({'selected_package_builds_passed':True,'verified_archives':len(final),
    'physical_archive_paths':len(physical),'warnings':warnings,'cache_candidate_admitted':False,
    'release_qualified':False}),flush=True)
