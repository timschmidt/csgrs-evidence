# Combine the admitted packaging correction with the unchanged cache proposal.
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path,PurePosixPath
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import GIT,dump,reasons,resources,sha
W=Path(__file__).resolve().parent;D=V/'paper-worktree-v1';C=V/'checkout-candidate-v1'
R=V/'checkout-release-candidate-v1';branch='codex/circle-support-packages-20261017'
BASE='ab85891beceb3c3eb82ab19ea646613f22226fc5'
assert not R.exists() and not (V/'in-scope-package-preparation-v1.json').exists()
assert not reasons(resources())
assert json.loads((V/'msrv-commit-verification-v1.json').read_text())['commit']==BASE
assert json.loads((V/'msrv-in-scope-result-v1.json').read_text())['complete_for_declared_scope']
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_LFS_SKIP_SMUDGE='1')
def git(args,cwd=D,stdin=None):
    return subprocess.run(GIT+args,cwd=cwd,env=env,input=stdin,capture_output=True,check=True).stdout
assert git(['rev-parse','HEAD']).decode().strip()==BASE
assert not git(['status','--porcelain=v1'])
assert not git(['branch','--list',branch])
original=json.loads(gzip.decompress((V/'candidate-source-inventory-v1.json.gz').read_bytes()))
pins={p:h for p,h in original.items() if not p.startswith('crates/comparisons/')}
changes=json.loads((V/'hyperreal-package-source-after-v1.json').read_text())['changed_files']
assert set(changes)=={'Cargo.lock','crates/hyperreal/Cargo.toml','crates/hyperreal/README.md','crates/hyperreal/tests/readme_metadata.rs'}
updates={p:row['after'] for p,row in changes.items()}
updates['docs/properties-status.json']=sha(D/'docs/properties-status.json')
changed_since_candidate=set(git(['diff','--name-only','fc23195a16f45fb396a5dd731feb6c7310d8ce7c',BASE,
    '--','.',':(exclude)docs/evidence']).decode().splitlines())
assert changed_since_candidate==set(updates),changed_since_candidate
assert all(sha(C/p)==h for p,h in pins.items())
assert all(sha(D/p)==h for p,h in updates.items())
expected=pins|updates
patterns=set()
for p in expected:
    parts=PurePosixPath(p).parts
    if parts[0]=='docs':patterns.add('/'+p)
    elif parts[0]=='crates':
        patterns.add('/'+p if len(parts)==2 else '/crates/'+parts[1]+'/')
    else:patterns.add('/'+parts[0]+('/' if len(parts)>1 else ''))
assert not any('/comparisons/' in p or p.startswith('/docs/evidence/') for p in patterns)
selection=('\n'.join(sorted(patterns))+'\n').encode()
(W/'sparse-selection-v1.txt').write_bytes(selection)
git(['worktree','add','--no-checkout','-b',branch,str(R),BASE])
git(['sparse-checkout','set','--no-cone','--stdin'],R,selection)
git(['checkout',branch],R)
assert git(['rev-parse','HEAD'],R).decode().strip()==BASE
assert not git(['status','--porcelain=v1'],R)
overlay=['crates/hypercurve/README.md','crates/hypercurve/src/curve_intersection.rs',
    'crates/hypercurve/src/circle_support_cache_tests.rs']
for p,h in expected.items():
    if p not in overlay:assert (R/p).is_file() and not (R/p).is_symlink() and sha(R/p)==h,p
for p in overlay:
    shutil.copy2(C/p,R/p);assert sha(R/p)==pins[p]
assert all(sha(R/p)==h for p,h in expected.items())
status=git(['status','--porcelain=v1','--untracked-files=all'],R).decode().splitlines()
assert {line[3:] for line in status}==set(overlay),status
patch=git(['diff','--binary'],R);(W/'candidate-tracked-v1.patch').write_bytes(patch)
shutil.copy2(R/overlay[2],W/'circle_support_cache_tests-v1.rs')
(V/'release-candidate-source-inventory-v1.json.gz').write_bytes(gzip.compress((json.dumps(expected,sort_keys=True)+'\n').encode(),mtime=0))
dump(V/'in-scope-package-preparation-v1.json',{'helper_sha256':sha(Path(__file__)),
    'contract_sha256':sha(W/'contract-v1.md'),'selection_sha256':sha(W/'selection-v1.json'),
    'base_revision':BASE,'worktree':str(R),'requested_branch':branch,
    'head_branch':git(['branch','--show-current'],R).decode().strip(),
    'source_inventory_sha256':sha(V/'release-candidate-source-inventory-v1.json.gz'),
    'source_files_verified':len(expected),'cache_overlay_sha256':{p:pins[p] for p in overlay},
    'admitted_package_updates_sha256':updates,'all_other_source_matches_retained_candidate':True,
    'prior_candidate_unchanged':True,'hypervoxel_deferred_by_user':True,
    'hypervoxel_source_materialized_only_for_unchanged_workspace_resolution':True,
    'new_production_source_edits':False,'candidate_admitted':False,'release_qualified':False})
assert all(sha(C/p)==h for p,h in pins.items())
assert git(['rev-parse','HEAD']).decode().strip()==BASE and not git(['status','--porcelain=v1'])
print(json.dumps({'prepared':str(R),'source_files_verified':len(expected),'overlay_files':len(overlay),
    'prior_candidate_unchanged':True,'candidate_admitted':False}),flush=True)
