import csv,json,sys,statistics as st
from pathlib import Path
s=Path(__file__).parent
out={}
for stage in sys.argv[1:] or ['shared']:
 for suite,cores in [('trig_cost',[3,5]),('tangent_cost',[13,15])]:
  observations={}
  for v in ['base',stage]:
   for core in cores:
    p=s/f'time-final-pair-{v}-{core}-{suite}.csv'
    rows={}
    for row in list(csv.reader(p.open()))[1:]:
     k=tuple(row[:3]);rows.setdefault(k,[]).append((int(row[-3]),int(row[-2]),int(row[-1])))
    assert len(rows)==78 and all(len(sam)==20 for sam in rows.values()),(p,len(rows))
    observations[v,core]=rows
  ratios={}
  for k in observations['base',cores[0]]:
   rs=[]
   for core in cores:
    a,b=[observations[v,core][k] for v in ['base',stage]];assert {q[1:] for q in a}=={q[1:] for q in b}
    rs.append(st.median(q[0] for q in b)/st.median(q[0] for q in a))
   ratios['/'.join(k)]=rs
  out[stage,suite]=ratios
  slower=[(k,rs) for k,rs in ratios.items() if min(rs)>1.03]
  print(stage,suite,'median',st.median(st.geometric_mean(rs) for rs in ratios.values()),'slow on both',len(slower),'largest',sorted(slower,key=lambda x:-min(x[1]))[:5])
(s/('timing-review-'+'-'.join(sys.argv[1:] or ['shared'])+'.json')).write_text(json.dumps({str(k):v for k,v in out.items()},indent=2)+'\n')
