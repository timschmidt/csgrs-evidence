set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
mv "$s/src" "$s/src-current"
mkdir "$s/src"
git archive c9f1f9ac5 | tar -xmC "$s/src"
python3 "$s/artifacts-fixed.py" fixed > "$s/logs/fixed-images.log" 2>&1 &
image_pid=$!
python3 "$s/life.py" fixed > "$s/logs/fixed-lifetime.log" 2>&1 &
life_pid=$!
wait "$image_pid"; wait "$life_pid"
mv "$s/src" "$s/src-fixed"
mv "$s/src-current" "$s/src"
for p in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/trigonometry.rs crates/hyperinterval/src/tangent.rs crates/hyperinterval/tests/periodic_ingress.rs; do cp "$p" "$s/src/$p"; done
python3 "$s/artifacts.py" final > "$s/logs/final-images.log" 2>&1 &
image_pid=$!
python3 "$s/life.py" final > "$s/logs/final-lifetime.log" 2>&1 &
life_pid=$!
wait "$image_pid"; wait "$life_pid"
