set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for n in trig_cost tangent_cost; do path="crates/hyperinterval/conformance/$n.rs"; git show "$(cat "$s/base"):$path" > "$s/src/$path"; done
for variant in inline borrowed; do
 for path in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/tangent.rs crates/hyperinterval/src/trigonometry.rs; do cp "$s/$variant-fast-${path##*/}" "$s/src/$path"; done
 rustfmt --edition 2024 "$s/src/crates/hyperinterval/src/tangent.rs" "$s/src/crates/hyperinterval/src/trigonometry.rs"
 python3 "$s/artifacts.py" "$variant" > "$s/logs/$variant-images.log" 2>&1 &
 img=$!
 python3 "$s/life.py" "$variant" > "$s/logs/$variant-lifetime.log" 2>&1 &
 life=$!
 wait "$img"; wait "$life"
done
