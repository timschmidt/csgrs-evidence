from pathlib import Path
import ctypes as C,time,sys,csv,random,statistics as st
s=Path(__file__).parent
def lib(stage):
 x=C.CDLL(str(s/('official-'+stage+'.so')));P=C.c_void_p;U=C.c_uint
 x.setup.argtypes=[U];x.setup.restype=P;x.release.argtypes=[P];x.release.restype=None
 x.batch.argtypes=[P,U,C.c_int,U,U];x.batch.restype=C.c_uint64;return x
libs=[lib(v) for v in sys.argv[2:4]]
rows=[]
for k in range(13):
 for op in range(4):
  for prec in [-16,-64,-256]:
   for mode in [0]:
    rows.append((k,op,prec,mode))
# Repeat the full suite with interleaved load orders on independent CPU sockets.
random.Random(127469).shuffle(rows)
def timed(lib,p,op,prec,count,mode):
 start=time.thread_time_ns();r=lib.batch(p,op,prec,count,mode);return time.thread_time_ns()-start,r
with (s/('ordered-'+sys.argv[1]+'-'+sys.argv[2]+'-'+sys.argv[3]+'.csv')).open('w') as out:
 w=csv.writer(out);w.writerow(['source','operation','precision','mode','block','batch','base_ns','final_ns','base_receipt','final_receipt'])
 for k,op,prec,mode in rows:
  ptr=[x.setup(k) for x in libs]
  def go(i,n):return timed(libs[i],ptr[i],op,prec,n,mode)
  for i in [0,1]:go(i,4)
  a,b=go(0,8),go(1,8);assert (a[1]&7)==(b[1]&7)
  assert a[1]==b[1]
  n=max(1,min(32768,int(1e6*8/max(a[0],b[0],1))))
  for block in range(20):
   order=(0,1,1,0) if block%2==0 else (1,0,0,1)
   log=[[],[]]
   for i in order:log[i].append(go(i,n))
   assert len({r for _,r in log[0]})==len({r for _,r in log[1]})==1
   w.writerow([k,op,prec,mode,block,n,*[sum(v for v,_ in x) for x in log],*[x[0][1] for x in log]])
  for x,p in zip(libs,ptr):x.release(p)
