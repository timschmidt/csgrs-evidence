set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
python3 "$s/qimages.py" qbase > "$s/logs/qbase-images.log" 2>&1
cp crates/hyperreal/src/rational/arithmetic/queries_conversion.rs "$s/qsrc/crates/hyperreal/src/rational/arithmetic/queries_conversion.rs"
cp crates/hyperreal/tests/reduction_input_bits.rs "$s/qsrc/crates/hyperreal/tests/reduction_input_bits.rs"
python3 "$s/qimages.py" qfinal > "$s/logs/qfinal-images.log" 2>&1
