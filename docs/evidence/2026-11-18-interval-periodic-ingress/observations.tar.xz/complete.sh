set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for p in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/trigonometry.rs crates/hyperinterval/src/tangent.rs crates/hyperinterval/tests/periodic_ingress.rs crates/hyperreal/tests/reduction_input_bits.rs; do cp "$p" "$s/src/$p"; done
python3 "$s/artifacts.py" complete > "$s/logs/complete-images.log" 2>&1 &
a=$!
python3 "$s/legacy-complete.py" > "$s/logs/legacy-complete.log" 2>&1 &
b=$!
python3 "$s/life.py" complete > "$s/logs/complete-life.log" 2>&1
python3 "$s/clean.py" complete > "$s/logs/complete-clean.log" 2>&1
python3 "$s/complete-room.py" > "$s/logs/complete-room.log" 2>&1
wait "$a"; wait "$b"
