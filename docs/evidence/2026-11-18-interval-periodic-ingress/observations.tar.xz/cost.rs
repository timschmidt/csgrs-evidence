use hyperinterval::{RationalInterval,DyadicBudget};
use hyperreal::{Rational,ExactDyadicLine2};
#[path="/dev/shm/interval-periodic-ingress/allocations.rs"] mod allocations;
fn coordinate(span:f64,y:f64)->Rational {
 if span==0. { return Rational::from(y as i64); }
 let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
 let (_,xy)=line.intersection_point_f64([0.,y],[span,y]).unwrap();
 xy[0].exact_rational_ref().unwrap().clone()
}
fn main(){
 for span in [0.,6.,281474976710662.] {
 for shape in ["point","mixed","equal","range"] {
 for op in 0..4 {
 for kind in ["denied","work","completed"] {
 let v=coordinate(span,3.);
 let iv=match shape {"point"=>RationalInterval::point(v),"mixed"=>RationalInterval::new(Rational::from(2),v).unwrap(),"equal"=>RationalInterval::new(coordinate(10.,3.),v).unwrap(),_=>RationalInterval::new(coordinate(10.,2.),v).unwrap()};
 for rep in 0..2 {
 let mut w= match kind {"denied"=>DyadicBudget::new(0,100),"work"=>DyadicBudget::new(4096,1),_=>DyadicBudget::new(4096,1<<45)};
 let stats=allocations::once(||{
 let r=match op {0=>iv.sin(-8,&mut w).map(|v|{std::hint::black_box(v);}),1=>iv.cos(-8,&mut w).map(|v|{std::hint::black_box(v);}),2=>iv.tan(-8,&mut w).map(|v|{std::hint::black_box(v);}),_=>iv.cot(-8,&mut w).map(|v|{std::hint::black_box(v);})};
 if kind=="completed" {r.unwrap()}else{assert!(r.is_err())}
 });
 println!("{span:e},{shape},{op},{kind},{rep},{},{},{},{},{},{},{}",w.remaining_work(),stats.allocations,stats.deallocations,stats.reallocations,stats.allocated_bytes,stats.peak_live_bytes,stats.live_bytes);
 }
 }}}}
}
