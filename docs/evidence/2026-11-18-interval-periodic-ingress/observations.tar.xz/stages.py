from pathlib import Path
import shutil,sys,subprocess as sp
s=Path(__file__).parent;r=s/'src';root=Path('/mnt/development/csgrs')
for p in ('crates/hyperreal/src/rational/arithmetic/queries_conversion.rs','crates/hyperinterval/src/trigonometry.rs','crates/hyperinterval/src/tangent.rs'):
 back=s/('shared-'+Path(p).name)
 if sys.argv[1]=='save':shutil.copy2(r/p,back)
 elif sys.argv[1]=='shared':shutil.copy(back,r/p)
 elif sys.argv[1]=='control':(r/p).write_bytes(sp.check_output(['git','show',(s/'base').read_text().strip()+':'+p],cwd=root))
