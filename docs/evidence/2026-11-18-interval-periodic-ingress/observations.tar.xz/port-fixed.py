from pathlib import Path
s=Path(__file__).parent
p=s/'src/crates/hyperinterval/Cargo.toml';candidate=Path('/mnt/development/csgrs')/p.relative_to(s/'src')
text=candidate.read_text();sig='[target.wasm32-wasip1.dev-dependencies]';start=text.index(sig);end=text.index('\n\n',start)
assert sig not in p.read_text()
p.write_text(p.read_text()+'\n'+text[start:end]+'\n')
