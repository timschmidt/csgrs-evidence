from pathlib import Path
import csv,statistics as st,json
s=Path(__file__).parent
def compare(p,base,final,keys):
 d={}
 with p.open() as f:
  for r in csv.DictReader(f):d.setdefault('/'.join(r[k] for k in keys),[]).append(int(r[final])/int(r[base]))
 return {k:st.median(v) for k,v in d.items() if len(v)==20}
sets=[compare(s/f'paired-complete-{c}.csv','base_ns','final_ns',['source','operation','precision','mode']) for c in [2,12]]
print('paired median',*[st.median(t.values()) for t in sets])
print('both>3%',[(k,*[round(t[k],3) for t in sets]) for k in sets[0] if min(t[k] for t in sets)>1.03])
def system(t):
 sets=[]
 for name,core in [('copy',3),('copy',13),('complete',7),('complete',17)]:
  def read(stage):
   with (s/f'full-{name}-{core}-{stage}-{t}.csv').open() as f:return list(csv.DictReader(f))
  a,b=read('base'),read('final');d={}
  for x,y in zip(a,b):
   k='/'.join(x[v]for v in ['backend','case','precision']);d.setdefault(k,[]).append(int(y['elapsed_ns'])/int(x['elapsed_ns']))
  sets.append({k:st.median(v)for k,v in d.items() if len(v)==20})
 ks=set.intersection(*(set(d) for d in sets));print(t,len(ks),'all>3',[(k,[round(t[k],3)for t in sets]) for k in sorted(ks) if min(t[k]for t in sets)>1.03]);print('sine', [t.get('rational/sin_wide/-256') for t in sets])
system('trig_cost');system('tangent_cost')
