import os,subprocess as sp,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent
def lane(cpu):
 for suite in ['trig_cost','tangent_cost']:
  a,b=os.pipe();c,d=os.pipe()
  os.write(d if cpu in (8,18) else b,b'x')
  ps=[]
  for stage,reader,writer in [('base',a,d),('final',c,b)]:
   cmd=[s/(('base' if cpu in (8,18) else stage)+'-stable-'+suite)];env=os.environ|{'LD_PRELOAD':str(s/'paired-clock.so'),'TURN_READER':str(reader),'TURN_WRITER':str(writer)}
   out=(s/f'check-linked-{cpu}-{stage}-{suite}.csv').open('w')
   ps.append(sp.Popen(cmd,env=env,stdout=out,pass_fds=(reader,writer),preexec_fn=lambda:os.sched_setaffinity(0,{cpu})))
   out.close()
  for fd in [a,b,c,d]:os.close(fd)
  try:assert [p.wait(timeout=600)for p in ps]==[0,0]
  finally:
   for p in ps:
    if p.poll() is None:p.kill()
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,[8,18,4,14]))
