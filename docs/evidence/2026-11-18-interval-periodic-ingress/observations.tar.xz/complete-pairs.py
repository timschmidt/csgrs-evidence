import os,subprocess as sp,sys,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent
def lane(job):
 variant,cpu=job
 for suite in ['trig_cost','tangent_cost']:
  end=time.monotonic()+600
  while not (s/(variant+"-stable-"+suite)).is_file():
   assert time.monotonic()<end;time.sleep(2)
  a,b=os.pipe();c,d=os.pipe()
  os.write(b if cpu<10 else d,b'x')
  ps=[]
  for stage,reader,writer in [('base',a,d),('final',c,b)]:
   cmd=[s/(('base' if stage=='base' else variant)+'-stable-'+suite)];env=os.environ|{'LD_PRELOAD':str(s/'paired-clock.so'),'TURN_READER':str(reader),'TURN_WRITER':str(writer)}
   out=(s/f'full-{variant}-{cpu}-{stage}-{suite}.csv').open('w')
   ps.append(sp.Popen(cmd,env=env,stdout=out,pass_fds=(reader,writer),preexec_fn=lambda:os.sched_setaffinity(0,{cpu})))
   out.close()
  for fd in [a,b,c,d]:os.close(fd)
  try:assert [p.wait(timeout=600)for p in ps]==[0,0]
  finally:
   for p in ps:
    if p.poll() is None:p.kill()
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,[('complete',7),('complete',17)]))
