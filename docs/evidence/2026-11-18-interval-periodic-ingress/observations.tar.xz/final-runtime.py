import csv,json,statistics as st
from pathlib import Path
s=Path(__file__).parent
def rd(path):
 d={}
 for r in csv.DictReader(path.open()):
  k='/'.join(r[t]for t in ['backend','case','precision'])
  d.setdefault(k,[]).append((int(r['elapsed_ns']),int(r['completed_images']),int(r['work_units_per_image'])))
 assert len(d)==78 and all(len(v)==20 for v in d.values()),path
 return d
def suite(pattern,cores,label):
 out={}
 for ex in ['trig_cost','tangent_cost']:
  rows={}
  for c in cores:
   a,b=[rd(s/(pattern.format(c=c,stage=v,suite=ex)))for v in ['base','final']]
   for k,q in a.items():
    assert all(x[1:]==y[1:]for x,y in zip(q,b[k]))
    rows.setdefault(k,[]).append(st.median(y[0]/x[0] for x,y in zip(q,b[k])))
  out[ex]=dict(median_by_core=[st.median(v[i]for v in rows.values())for i in range(len(cores))],above_3_percent_on_all_cores={k:v for k,v in rows.items()if min(v)>1.03},all=rows)
 return out
result={}
for label,cores in [('copy',[3,13]),('complete',[7,17]),('inline',[3,13]),('borrowed',[5,15]),('canonical',[5,15])]:
 result[label]=suite('full-'+label+'-{c}-{stage}-{suite}.csv',cores,label)
for label,cores,p in [('first',[7,17],'linked'),('first-repeat',[4,14],'check-linked'),('identical-control',[8,18],'check-linked')]:
 result[label]=suite(p+'-{c}-{stage}-{suite}.csv',cores,label)
(s/'retained-runtime.json').write_text(json.dumps(result,indent=1)+'\n')
for name in ['copy','complete','first','first-repeat','identical-control']:
 print(name,[(t,r['median_by_core'],r['above_3_percent_on_all_cores']) for t,r in result[name].items()])
