from pathlib import Path
import os,subprocess as sp,json,sys,re
s=Path(__file__).parent;r=s/'src';repo=Path('/mnt/development/csgrs')
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
def measure(stage):
 env=os.environ|{'CARGO_TARGET_DIR':str(s/'legacy-target')}
 cmd=['cargo','+1.95.0','build','--release','--locked','--no-default-features','--features','integer,fixed,rational,dyadic,float-enclosure','-p','hyperinterval','--example','tangent_cost','--message-format=json-render-diagnostics']
 with (s/'logs'/('legacy-'+stage+'.build')).open('w') as log:
  records=sp.check_output(cmd,cwd=r,env=env,stderr=log,text=True)
 [b]=[Path(x['executable']) for x in map(json.loads,records.splitlines()) if x.get('executable')]
 v=metrics(b);v.update({k:int(n) for k,n in re.findall(r'^(\.got|\.rela\.dyn)\s+(\d+)',sp.check_output(['size','-A',b],text=True),re.M)})
 (s/('legacy-'+stage+'.json')).write_text(json.dumps(v,indent=2)+'\n')
for phase in ['fixed','base','final']:
 if phase=='fixed':
  (s/'src').rename(s/'src-current')
  (s/'src-fixed').rename(s/'src')
 if phase=='base':
  (s/'src').rename(s/'src-fixed')
  (s/'src-current').rename(s/'src')
  sp.run([sys.executable,s/'stages.py','control'],check=True)
 if phase=='final':
  for n in ['crates/hyperreal/src/rational/arithmetic/queries_conversion.rs','crates/hyperinterval/src/tangent.rs','crates/hyperinterval/src/trigonometry.rs']:
   (r/n).write_bytes((repo/n).read_bytes())
 measure(phase)
