from pathlib import Path
import json,csv,re
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs')
def read(name):return json.loads((s/name).read_text())
def dump(name,data):(s/name).write_text(json.dumps(data,indent=1)+'\n')
versions=['1.95.0','stable'];targets=['native','wasm32-wasip1'];kinds=['file','code','functions']
program=json.loads((repo/'docs/research/interval-size-accounts.json').read_text())
hist=json.loads(Path('/dev/shm/interval-scalar-replay/per-image.json').read_text())['rows']
def account(f,x,y,prior,ia,ip,ca,cp):
 inc=max(0,y-x);charge=prior+inc
 lim,bound=min(ia,int(x*ip/100)),min(ca,int(f*cp/100))
 assert inc<=lim and charge<=bound,(f,x,y,prior,inc,charge,lim,bound)
 return [f,x,y,prior,inc,charge,lim-inc,bound-charge]
cols=['fixed','preceding','candidate','prior_positive','increment','cumulative_positive','remaining_incremental','remaining_cumulative']
size_rows={};size_short={}
for v in versions:
 fixed,base,final=[read(name+'-'+v+'.json') for name in ('fixed','base','final')]
 size_rows[v]={};size_short[v]={}
 for t in targets:
  sr={};size_rows[v][t]=sr
  for n,y in final[t].items():
   x=base[t][n];z=fixed[t].get(n,x)
   assert 64*2**20-y['file']>=16*2**20
   if n=='periodic_refinement':
    assert all(x[m]==program['periodic_refinement_suite']['targets'][v][t][m] for m in kinds)
    assert y['file']<4*2**20
   sr[n]={}
   for m in kinds:
    ia,ip,ca,cp=4096,1,8192,2
    f0=z[m];prior=max(0,x[m]-f0)
    if v=='1.95.0' and t=='native' and n in ('trigonometry','tangent'):
     old=program['accounts'][54 if n=='trigonometry' else 55]['metrics'][dict(file='file',code='executable_code',functions='named_text')[m]]
     prior=max(prior,old['accepted_positive_growth_bytes']+max(0,x[m]-f0-(old['retained']-old['baseline'])))
     ca,cp=old['caps']['cumulative_bytes'],old['caps']['cumulative_percent']
    if n=='tangent':
     h=hist[v][t][n][m]
     prior=max(prior,max(0,h[0]-f0)+h[5]+max(0,x[m]-h[2]))
    sr[n][m]=account(f0,x[m],y[m],prior,ia,ip,ca,cp)
  size_short[v][t]=dict(max_positive_step_bytes={m:max(r[m][4] for r in sr.values()) for m in kinds},min_remaining_cumulative_bytes={m:min(r[m][7] for r in sr.values()) for m in kinds},minimum_free_slot_bytes=min(64*2**20-y['file'] for y in final[t].values()))
legacy={}
x,y,z=[read('legacy-'+n+'.json') for n in ('base','final','fixed')]
for m,pk in [('file','file'),('functions','function_union'),('.got','.got'),('.rela.dyn','.rela.dyn')]:
 old=program['accounts'][68]['metrics'][pk];caps=old['caps']
 prior=old['accepted_positive_growth_bytes']+max(0,(x[m]-z[m])-(old['retained']-old['baseline']))
 legacy[m]=account(z[m],x[m],y[m],prior,caps['incremental_bytes'],caps['incremental_percent'],caps['cumulative_bytes'],caps['cumulative_percent'])
dump('size-details.json',dict(columns=cols,ordinary=size_rows,legacy=legacy))
ep='docs/evidence/2026-11-18-interval-periodic-ingress'
entry=dict(source=(s/'revision').read_text().strip(),preceding=(s/'base').read_text().strip(),fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',evidence=ep,scope='Rational periodic ingress. Four existing all-feature release consumers and the existing combined refinement suite on native x86-64 Linux and wasm32-wasip1. Follows each prior account, including the legacy tangent_cost feature set. size-details.json carries each positive charge, cap remainder and named metric.',absolute_incremental_cap=4096,relative_incremental_percent=1,ordinary_cumulative_cap=8192,ordinary_cumulative_percent=2,ci_slot_bytes=64*2**20,required_free_bytes=16*2**20,targets=size_short,legacy_tangent_cost=dict(columns=cols,metrics=legacy),new_test_file_cap=4*2**20,new_tests={})
for v in ['1.88.0',*versions]:
 data=read('images-'+v+'.json');entry['new_tests'][v]={}
 for t,r in data.items():
  assert r['file']<=4*2**20 and r['job']['passes']==(0 if v=='1.88.0' else 3)
  entry['new_tests'][v][t]=dict(file=r['file'],code=r['code'],functions=r['functions'],remaining_file_cap=4*2**20-r['file'],free_slot_bytes=64*2**20-r['file'])
dump('size-entry.json',entry)
details={};memshort={}
for v in versions:
 details[v]={};memshort[v]={}
 for t,triple in [('native','x86_64-unknown-linux-gnu'),('wasm32-wasip1','wasm32-wasip1')]:
  max_step=[0]*3;max_tot=[0]*3;max_usage=[0]*3;increases=[0]*3
  details[v][t]={}
  for run,old in [('life','control'),('clean','base')]:
   def rows(stage):
    r={}
    for line in csv.reader((s/f'{run}-{stage}-{v}-{triple}.csv').open()):
     kk=','.join(line[:4]);kk+=(',ownership' if line[4]=='0' else ',operation') if run=='clean' else ''
     vals=list(map(int,line[5:]));r[kk]=list(map(max,zip(vals,r[kk]))) if kk in r else vals
    assert len(r)==(144 if run=='life' else 288)
    return r
   f,x,y=[rows(stage) for stage in ['fixed',old,'final']]
   data={};details[v][t][run]=data
   for k in y:
    data[k]={}
    for i,(n,col,ia,ca) in enumerate([('stack',0,128,256),('peak_heap',5,64,128),('retained_heap',6,32,64)]):
     if n=='stack' and k.endswith('ownership'):continue
     a,b,c=[r[k][col] for r in [f,x,y]]
     assert min(a,b,c)>=0
     q=account(a,b,c,max(0,b-a),ia,2,ca,4)
     data[k][n]=q;max_step[i]=max(max_step[i],q[4]);max_tot[i]=max(max_tot[i],q[5]);max_usage[i]=max(max_usage[i],c);increases[i]+=int(q[4]>0)
  free=2*2**20-4096-max_usage[0] if t=='native' else min(r[1] for folder in ['life','life-clean'] for r in read('room-'+v+'-'+folder+'.json'))
  assert free>=256*1024
  memshort[v][t]=dict(metric_order=['stack','peak_requested_heap','retained_requested_heap'],max_incremental_bytes=max_step,max_cumulative_positive_bytes=max_tot,workloads_with_positive_step=increases,max_observed_bytes=max_usage,minimum_stack_headroom_bytes=free)
dump('memory-details.json',dict(columns=cols,by_target=details))
memory=dict(source=entry['source'],preceding=entry['preceding'],fixed=entry['fixed'],evidence=ep,scope='Four rational periodic calls, ordinary and generated sources, native and guest execution, denial, completed outputs and retries. memory-details.json lists both dependency locks and every per-workload account. Includes separate whole-ownership epochs from fresh processes through input/output destruction. Compiler and OS job peaks are separate.',metric_order=['stack','temporary requested heap peak','retained requested heap'],absolute_incremental_bytes=[128,64,32],relative_incremental_percent=2,absolute_cumulative_bytes=[256,128,64],relative_cumulative_percent=4,required_stack_headroom_bytes=256*1024,targets=memshort,test_job_capacity_bytes=256*2**20,test_job_reserve_bytes=64*2**20,whole_scalar_capacity_bytes=2**30,whole_scalar_reserve_bytes=2**28,jobs={})
prior=json.loads((repo/'docs/research/interval-memory-accounts.json').read_text())['periodic_refinement_qualification']['targets']
for v in ['1.88.0',*versions]:
 d=read('images-'+v+'.json')
 log=(s/'logs'/f'warm-{v}.log').read_text()
 assert 'oom_kill 0' in log and '\nmax 0\n' in log and 'memory.swap.max 0' in log
 peak=int(re.search(r'^memory.peak (\d+)',log,re.M)[1]);old=prior[v]['whole_scalar_job']['cumulative_positive_charge_bytes'];p=max(peak,old)
 assert p+2**28<=2**30
 report=Path('/dev/shm/interval-scalar-replay')/('accepted-'+v)/'report.json'
 rep=json.loads(report.read_text());assert len(rep['fresh_replays'])==5
 dump(f'final-report-{v}.json',rep)
 memory['jobs'][v]=dict(compiled_test_job_peaks={t:r['job']['peak'] for t,r in d.items()},whole_warmed_peak=peak,previous_cumulative_positive=old,incremental_positive=p-old,cumulative_positive=p,remaining_above_required_reserve=2**30-2**28-p,direct_guest_passes=sum(map(len,rep['guest'].values())),native_required=len(rep['host_required']),fresh_guest_replays=len(rep['fresh_replays']))
dump('memory-entry.json',memory)
