from pathlib import Path
import sys
s=Path(__file__).parent;root=s/'src'
for n in ['trigonometry','tangent']:
 p=root/'crates/hyperinterval/src'/(n+'.rs');t=p.read_text();a=t.index('        budget.reserve(\n            a.numerator()');b=t.index('\n    }\n}',a)
 t=t[:a]+'''        with_rational_sources(a, b, budget, |left, right, budget| {
            range(left, right, function, precision, budget)
        })'''+t[b:]
 if n=='trigonometry':
  i=t.index('pub(crate) struct Reduced')
  t=t[:i]+'''// The source selection and series use the exact ratio, including common
// factors. Admit the stored widths before copying either endpoint.
#[cfg(feature = "rational")]
pub(crate) fn with_rational_sources<T>(
    left: &hyperreal::Rational,
    right: &hyperreal::Rational,
    budget: &mut DyadicBudget,
    evaluate: impl FnOnce(Source<'_>, Source<'_>, &mut DyadicBudget) -> Result<T, IntervalError>,
) -> Result<T, IntervalError> {
    let (ls, ln, ld) = left.ratio_parts();
    let (rs, rn, rd) = right.ratio_parts();
    budget.reserve(ln.bits().max(ld.bits()).max(rn.bits()).max(rd.bits()), 4, false)?;
    evaluate(
        Source { n: &BigInt::from_biguint(ls, ln.clone()), d: &BigInt::from(ld.clone()), e: 0 },
        Source { n: &BigInt::from_biguint(rs, rn.clone()), d: &BigInt::from(rd.clone()), e: 0 },
        budget,
    )
}
'''+t[i:]
 else:t=t.replace('use crate::trigonometry::{', '#[cfg(feature = "rational")]\nuse crate::trigonometry::with_rational_sources;\nuse crate::trigonometry::{')
 p.write_text(t)
