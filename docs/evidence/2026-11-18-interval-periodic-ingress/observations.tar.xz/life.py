import os,sys,subprocess as sp
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent
def lane(job):
 v,t=job;target=s/('life-target-'+v);env=os.environ|{'CARGO_TARGET_DIR':str(target)}
 cmd=['cargo','+'+v,'build','--locked','--release','--target',t]
 with (s/'logs'/f'life-{sys.argv[1]}-{v}-{t}.log').open('w') as log:
  sp.run(cmd,cwd=s/'life',env=env,stdout=log,stderr=log,check=True)
  b=target/t/'release/periodic-input-lifetime';cmd=[b] if t.startswith('x86') else ['node',s/'stack-wasi.mjs',b.with_suffix('.wasm')]
  with (s/f'life-{sys.argv[1]}-{v}-{t}.csv').open('w') as out:sp.run(cmd,env=env,stdout=out,stderr=log,check=True)
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,[(v,t) for v in ['1.95.0','stable'] for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']]))
