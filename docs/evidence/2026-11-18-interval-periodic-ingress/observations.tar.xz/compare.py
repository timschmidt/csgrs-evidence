import csv,json,sys
from pathlib import Path
s=Path(__file__).parent
def read(p):
 data={}
 for row in csv.reader(p.open()):
  key=tuple(row[:4]);numbers=[int(x) for x in row[5:]]
  if key not in data:data[key]=numbers
  else:data[key]=list(map(max,zip(numbers,data[key])))
 assert len(data)==144
 return data
for stage in sys.argv[1:] or ['shared']:
 summary={}
 for a in sorted(s.glob('life-control-*.csv')):
  if not (b:=s/a.name.replace('-control-','-'+stage+'-')).exists():continue
  x,y=read(a),read(b);bad=[];hi=[0]*7;lo=None
  for k in x:
   delta=[j-i for i,j in zip(x[k],y[k])];hi=list(map(max,zip(hi,delta)))
   if delta[0]>min(128,x[k][0]*.02) or delta[5]>min(64,x[k][5]*.02) or delta[6]>min(32,x[k][6]*.02):
    bad.append([k,x[k],y[k],delta])
  summary[a.stem[13:]]={'violations':len(bad),'max_increment':hi,'examples':bad[:4],'maximum_stack':max(p[0] for p in y.values())}
  print(a.name,stage,len(bad),hi, bad[:1])
 (s/(stage+'-resource-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
