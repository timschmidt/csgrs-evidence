set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
python3 "$s/clean.py" final
python3 "$s/stages.py" control
python3 "$s/clean.py" base
mv "$s/src" "$s/src-current"
mv "$s/src-fixed" "$s/src"
python3 "$s/clean.py" fixed
mv "$s/src" "$s/src-fixed"
mv "$s/src-current" "$s/src"
for p in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/{trigonometry,tangent}.rs crates/hyperinterval/tests/periodic_ingress.rs; do cp "$p" "$s/src/$p"; done
