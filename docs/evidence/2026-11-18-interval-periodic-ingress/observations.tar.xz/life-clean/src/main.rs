mod allocations;
use hyperinterval::{DyadicBudget,IntervalError,RationalInterval};
use hyperreal::{Rational,ExactDyadicLine2};
use std::{ffi::c_void,hint::black_box};
#[cfg(not(target_arch="wasm32"))]
unsafe extern "C" {fn measure_stack(cb:unsafe extern "C" fn(*mut c_void),ctx:*mut c_void,warm:i32,pattern:u8)->usize;}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="scope")]
unsafe extern "C" {fn mark(start:u32,pattern:u32)->u32;}
fn coord(span:f64,y:f64)->Rational{
 let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
 let (_,p)=line.intersection_point_f64([0.,y],[span,y]).unwrap();
 p[0].exact_rational_ref().unwrap().clone()
}
struct Case{iv:RationalInterval, op:u8, mode:u8, heap:Option<allocations::AllocationStats>}
unsafe extern "C" fn run(ctx:*mut c_void) {
 let c=unsafe{&mut *ctx.cast::<Case>()};
 let h=allocations::once(||{
  let go=|b:&mut DyadicBudget| match c.op {
   0=>c.iv.sin(-8,b).map(|i|{black_box(i);}),1=>c.iv.cos(-8,b).map(|i|{black_box(i);}),
   2=>c.iv.tan(-8,b).map(|i|{black_box(i);}),_=>c.iv.cot(-8,b).map(|i|{black_box(i);}),
  };
  if c.mode!=0 { assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted));}
  if c.mode!=1 { go(&mut DyadicBudget::new(4096,1<<40)).unwrap(); }
 }); c.heap=Some(h);
}
fn main(){
 let args:Vec<_>=std::env::args().skip(1).collect();
 let shape:u8=args[0].parse().unwrap();let op:u8=args[1].parse().unwrap();
 let mode:u8=args[2].parse().unwrap();let warm:bool=args[3].parse().unwrap();
 let origin:bool=args[4].parse().unwrap();
 let pat=85u8;
 let setup=||{ let iv=match shape{
  0=>RationalInterval::point(Rational::from(3)),
  1=>RationalInterval::new(Rational::from(2),Rational::from(3)).unwrap(),
  2=>RationalInterval::point(coord(6.,3.)),
  3=>RationalInterval::new(coord(6.,3.),coord(10.,3.)).unwrap(),
  4=>RationalInterval::new(Rational::from(2),coord(281474976710662.,3.)).unwrap(),
  _=>RationalInterval::new(Rational::fraction(-1,7).unwrap(),Rational::fraction(17,11).unwrap()).unwrap()
 };
 Case{iv,op,mode,heap:None}
 };
 // For complete ownership, include input construction, repeated operation and
 // output/input destruction inside one allocation epoch, without nested counters.
 if origin {
  let h=allocations::once(||{
   let c=setup();
   let invoke=||{
    let go=|b:&mut DyadicBudget|match op{
     0=>c.iv.sin(-8,b).map(|i|{black_box(i);}),1=>c.iv.cos(-8,b).map(|i|{black_box(i);}),
     2=>c.iv.tan(-8,b).map(|i|{black_box(i);}),_=>c.iv.cot(-8,b).map(|i|{black_box(i);})};
    if mode!=0{assert_eq!(go(&mut DyadicBudget::new(0,100)),Err(IntervalError::SizeExhausted))}
    if mode!=1{go(&mut DyadicBudget::new(4096,1<<40)).unwrap()}
   };
   if warm{invoke()}invoke();drop(black_box(c));
  });
  println!("{shape},{op},{mode},{warm},0,0,{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);return;
 }
 let mut c=setup();let ctx=(&mut c as *mut Case).cast();
 #[cfg(not(target_arch="wasm32"))] let stack=unsafe{measure_stack(run,ctx,i32::from(warm),pat)};
 #[cfg(target_arch="wasm32")] let stack=unsafe{if warm{run(ctx)};mark(1,pat.into());run(ctx);mark(0,pat.into()) as usize};
 let h=c.heap.unwrap();
 println!("{shape},{op},{mode},{warm},{pat},{stack},{},{},{},{},{},{}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);

}
