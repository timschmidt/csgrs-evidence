set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for stage in control bounded inline borrowed; do
 python3 "$s/fast.py" "$stage" > "$s/logs/fast-$stage.log" 2>&1
done
