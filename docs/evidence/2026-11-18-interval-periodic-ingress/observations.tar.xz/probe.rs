use hyperinterval::{DyadicBudget,RationalInterval};
use hyperreal::{ExactDyadicLine2,Rational,dispatch_trace};

fn coordinate(span:f64, y:f64) -> Rational {
 let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
 let (_, xy)=line.intersection_point_f64([0.,y],[span,y]).unwrap();
 let r=xy[0].exact_rational_ref().unwrap();
 r.clone()
}

#[test]
fn probe(){
 for span in [6.,10.,281474976710662.,1.5_f64*2_f64.powi(500)] {
  for op in 0..4 {
   let x=coordinate(span,3.); let (_,n,d)=x.ratio_parts();
   println!("span={span:e} n={n} d={d} widths {} {}",n.bits(),d.bits());
   let x=RationalInterval::point(x);let mut w=DyadicBudget::new(0,100);
   dispatch_trace::reset();
   let error=dispatch_trace::with_recording(||match op {0=>x.sin(-8,&mut w).map(|_|()),1=>x.cos(-8,&mut w).map(|_|()),2=>x.tan(-8,&mut w).map(|_|()),_=>x.cot(-8,&mut w).map(|_|())});
   let tr=dispatch_trace::take_trace();
   println!("{op} {error:?} remaining {} trace {:?}",w.remaining_work(),tr.dispatch);
  }
 }
}
