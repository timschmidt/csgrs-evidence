from pathlib import Path
import os,sys,subprocess as sp,shutil,json
s=Path(__file__).parent;r=s/'src';repo=Path('/mnt/development/csgrs');stage=sys.argv[1]
rev=(s/('base' if stage=='control' else 'revision')).read_text().strip()
files=['crates/hyperreal/src/rational/arithmetic/queries_conversion.rs','crates/hyperinterval/src/trigonometry.rs','crates/hyperinterval/src/tangent.rs']
for name in files:(r/name).write_bytes(sp.check_output(['git','show',rev+':'+name],cwd=repo))
if stage in ('inline','borrowed'):
 p=r/files[0];t=p.read_text().replace('    pub fn reduction_input_bits(', '    #[inline]\n    pub fn reduction_input_bits(');p.write_text(t)
 p=r/files[1];t=p.read_text().replace('pub(crate) fn reserve_rational_sources(', '#[inline]\npub(crate) fn reserve_rational_sources(');p.write_text(t)
if stage=='borrowed':
 p=r/files[1];t=p.read_text()
 a=t.index('pub(crate) fn reserve_rational_sources');j=t.index('\nimpl DyadicInterval',a)
 t=t[:a]+'''pub(crate) fn rational_sources<'a>(
    left: &'a hyperreal::Rational,
    right: &'a hyperreal::Rational,
    budget: &mut DyadicBudget,
) -> Result<[RationalParts<'a>; 2], IntervalError> {
    let mut parts = [left.ratio_parts(), right.ratio_parts()];
    let [(_, an, ad), (_, bn, bd)] = parts;
    budget.reserve(an.bits().max(ad.bits()).max(bn.bits()).max(bd.bits()), 4, false)?;
    let widths = [left.reduction_input_bits(), right.reduction_input_bits()];
    for width in widths {
        if width != 0 {
            budget.reserve(width, 3, true)?;
        }
    }
    for ((value, width), slot) in [left, right].into_iter().zip(widths).zip(&mut parts) {
        if width != 0 {
            *slot = (value.sign(), value.numerator(), value.denominator());
        }
    }
    Ok(parts)
}

#[cfg(feature="rational")]
type RationalParts<'a> = (num_bigint::Sign, &'a num_bigint::BigUint, &'a num_bigint::BigUint);
'''+t[j:]
 p.write_text(t)
 for name in files[1:]:
  p=r/name;t=p.read_text().replace('use crate::trigonometry::reserve_rational_sources;', 'use crate::trigonometry::rational_sources;')
  a=t.index('        reserve_rational_sources(a, b, budget)?;');j=t.index('        range(',a)
  t=t[:a]+'''        let [(left_sign, left_num, left_den), (right_sign, right_num, right_den)] =
            rational_sources(a, b, budget)?;
        let an = BigInt::from_biguint(left_sign, left_num.clone());
        let ad = BigInt::from(left_den.clone());
        let bn = BigInt::from_biguint(right_sign, right_num.clone());
        let bd = BigInt::from(right_den.clone());
'''+t[j:];p.write_text(t)
for name in files:shutil.copy(r/name,s/(stage+'-fast-'+Path(name).name))
for n in ['trig_cost','tangent_cost']:
 p=r/f'crates/hyperinterval/conformance/{n}.rs'
 t=sp.check_output(['git','show',rev+':'+str(p.relative_to(r))],cwd=repo,text=True)
 t=t.replace('        let dyadic =','        if case != "wide" {continue;}\n        let dyadic =').replace('for sample in 0..20','for sample in 0..40').replace('for _ in 0..128','for _ in 0..4096').replace('for _ in 0..16','for _ in 0..4096')
 t=t.replace('},128,{units}', '},4096,{units}').replace('},16,{units}', '},4096,{units}')
 p.write_text(t)
env=os.environ|{'CARGO_TARGET_DIR':str(s/'target')}
sp.run(['cargo','+stable','build','--release','--locked','--all-features','-p','hyperinterval','--example','trig_cost','--example','tangent_cost'],cwd=r,env=env,check=True)
for n in ['trig_cost','tangent_cost']:shutil.copy2(s/'target/release/examples'/n,s/(stage+'-wide-'+n))
