set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
export CARGO_TARGET_DIR="$s/timing-target"
for stage in base final; do
 for n in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/{tangent,trigonometry}.rs; do
  if test "$stage" = base; then git show "HEAD:$n" > "$s/timing-src/$n"; else cp "$n" "$s/timing-src/$n"; fi
 done
 cargo +stable build --manifest-path "$s/timing/Cargo.toml" --offline --release > "$s/logs/$stage-timing-build.log" 2>&1
 cp "$CARGO_TARGET_DIR/release/libperiodic_paired_timing.so" "$s/timing-$stage.so"
done
