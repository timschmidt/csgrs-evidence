from pathlib import Path
import csv,io,re
p=Path('interval-inventory.tsv')
rows=list(csv.DictReader(p.open(),delimiter='\t'));fields=list(rows[0])
files={f'crates/hyperinterval/src/{n}.rs' for n in ('tangent','trigonometry')}
files.add('crates/hyperreal/src/rational/arithmetic/queries_conversion.rs')
for path in files:
 lines=Path(path).read_text().splitlines()
 def loc(sym):
  return [i+1 for i,t in enumerate(lines) if re.match(r'\s*(?:pub(?:\(crate\))? )?fn '+sym+r'\b',t)]
 def add(sym,desc,vis,platform,allocation,endpoint,consumers,bench,test):
  base=next(r for r in rows if r['path']==path);new=base.copy()
  new.update(symbol=sym,line=str(loc(sym)[0]),kind='fn',endpoint_representation=endpoint,semantics=desc,allocation=allocation,platform=platform,visibility=vis,serialization='no wire state',consumers=consumers,disposition='retain in owning layer',baseline_tests=test,baseline_benchmarks=bench,review_status='body and periodic callers reviewed against stored rational ingress witnesses')
  rows.insert(rows.index(base),new)
 for sym in {r['symbol'] for r in rows if r['path']==path and r['review_status']=='lexical candidate; not yet audited'}:
  rr=[r for r in rows if r['path']==path and r['symbol']==sym and r['review_status']=='lexical candidate; not yet audited']
  positions=loc(sym)
  if len(rr)!=len(positions):continue
  for r,line in zip(rr,positions):r['line']=str(line)
 if path.endswith('queries_conversion.rs'):
  add('reduction_input_bits','maximum stored operand width for a possible deferred reduction; independent of cache warmth','pub','Hyperreal std','borrowed width and tag reads','stored rational magnitudes','Hyperinterval rational periodic ingress','paired periodic client','hyperinterval/tests/periodic_ingress.rs')
 if path.endswith('trigonometry.rs'):
  add('reserve_rational_sources','paired copy and normalization admission before either canonical accessor','pub(crate)','rational + dyadic','no allocations','stored rational magnitudes','RationalInterval sin, cos, tan and cot','trig_cost; tangent_cost','hyperinterval/tests/periodic_ingress.rs')
 if path.endswith(('trigonometry.rs','tangent.rs')):
  for r in rows:
   if r['path']!=path or r['symbol'] not in ('sin','cos','tan','cot') or int(r['line'])!=loc(r['symbol'])[1]:continue
   r.update(endpoint_representation='exact rational to outward dyadic',semantics='certified periodic image with stored-width admission',allocation='budgeted bigint operations and possible Hyperreal endpoint reduction',platform='rational + dyadic',serialization='no new wire state',consumers='public RationalInterval operation',disposition='retain in owning layer',baseline_tests='hyperinterval/tests/periodic_ingress.rs; '+Path(path).name,baseline_benchmarks='trig_cost' if r['symbol'] in ('sin','cos') else 'tangent_cost',review_status='rational ingress reviewed; phase and output use existing certified kernels')
with p.open('w',newline='') as out:
 w=csv.DictWriter(out,fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
