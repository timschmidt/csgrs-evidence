set -eu
s=/dev/shm/interval-periodic-ingress
for cpu in 7 17; do (
 for pair in 'final base' 'base control' 'base final'; do
  taskset -c "$cpu" python3 "$s/ordered.py" "$cpu" $pair
 done
) & done
wait
