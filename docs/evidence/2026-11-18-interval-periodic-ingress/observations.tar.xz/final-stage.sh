mv "$s/src" "$s/src-fixed"
mv "$s/src-current" "$s/src"
for p in crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hyperinterval/src/trigonometry.rs crates/hyperinterval/src/tangent.rs crates/hyperinterval/tests/periodic_ingress.rs; do cp "$p" "$s/src/$p"; done
python3 "$s/artifacts.py" final > "$s/logs/final-images.log" 2>&1 &
image_pid=$!
python3 "$s/life.py" final > "$s/logs/final-lifetime.log" 2>&1 &
life_pid=$!
wait "$image_pid"; wait "$life_pid"
