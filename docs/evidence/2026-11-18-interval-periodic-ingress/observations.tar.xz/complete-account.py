from pathlib import Path
import json
s=Path(__file__).parent
p=(s/'accounts.py').read_text().replace("(s/'revision').read_text()","(s/'complete-revision').read_text()")
p=p.replace("('fixed','base','final')","('fixed','base','complete')").replace("('base','final','fixed')","('base','complete','fixed')").replace("['fixed',old,'final']","['fixed',old,'complete']")
p=p.replace("read('room-'","read('complete-room-'").replace("read('images-'","read('complete-tests-'").replace("f'warm-{v}.log'","f'whole-complete-{v}.log'").replace("dump(f'final-report-","dump(f'retained-report-")
p=p.replace("'size-details.json'","'complete-size-details.json'").replace("'memory-details.json'","'complete-memory-details.json'").replace("size-details.json carries","complete-size-details.json carries").replace("memory-details.json lists","complete-memory-details.json lists")
p=p.replace("'size-entry.json'","'retained-size-entry.json'").replace("'memory-entry.json'","'retained-memory-entry.json'")
exec(compile(p,str(s/'accounts.py'),'exec'))
for key in ('size','memory'):
 fn=s/('retained-'+key+'-entry.json');entry=json.loads(fn.read_text());data={}
 for v in ['1.95.0','stable']:
  x=json.loads((s/f'query-images-{v}.json').read_text());d={};data[v]=d
  for lane,r in x.items():
   assert r['job']['passes']==2 and r['file']<4*2**20 and r['job']['peak']+64*2**20<=256*2**20
   if key=='memory':d[lane]=dict(peak_process_bytes=r['job']['peak'],remaining_above_reserve=256*2**20-64*2**20-r['job']['peak'])
   else:d[lane]=dict(file=r['file'],code=r['code'],functions=r['functions'],remaining_file_allowance=4*2**20-r['file'],free_ci_slot=64*2**20-r['file'])
 entry['scalar_query_test']=dict(scope='Native Hyperreal integration executable and the identical maintained Rust fixture in a portable WASI consumer. Both with and without trace. Same new-test file/job caps.',targets=data)
 fn.write_text(json.dumps(entry,indent=1)+'\n')
