#define _GNU_SOURCE
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
int clock_gettime(clockid_t clock,struct timespec *now) {
    return syscall(SYS_clock_gettime,clock==CLOCK_MONOTONIC ? CLOCK_THREAD_CPUTIME_ID : clock,now);
}
