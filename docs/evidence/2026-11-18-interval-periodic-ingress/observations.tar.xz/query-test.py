from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,os,subprocess as sp,time
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs');sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
def lane(v):
 rows={}
 for target in ['native','wasm32-wasip1']:
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('qtest-target-'+v)),'CARGO_BUILD_JOBS':'4'};args=[]
  if target!='native':
   args+=['--target',target];env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-'+v+'/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
  for trace in ['plain','trace']:
   f='hyperinterval/rational,hyperinterval/dyadic'+(',hyperreal/dispatch-trace' if trace=='trace' else '')
   opts=['--release','--locked','--no-default-features','-p','hyperreal','-p','hyperinterval','--features',f,'--test','reduction_input_bits','--test','periodic_refinement',*args]
   with (s/'logs'/f'query-{v}-{target}-{trace}.build').open('w') as log:
    data=sp.check_output(['cargo','+'+v,'test',*opts,'--no-run','--message-format=json-render-diagnostics'],cwd=repo,env=env,stderr=log,text=True)
    [exe]=[Path(x['executable'])for x in map(json.loads,data.splitlines())if x.get('executable') and x['target']['name']=='reduction_input_bits']
    sp.run(['cargo','+'+v,'clippy',*opts,'--','-D','warnings'],cwd=repo,env=env,stdout=log,stderr=log,check=True)
   ri=metrics(exe);assert ri['file']<4*2**20
   log=sp.check_output(['systemd-run','--user','--scope','-q','-p','MemoryMax=256M','-p','MemorySwapMax=0','--','python3',s/'query-job.py',v,target+'-'+trace,str(exe)],cwd=repo,env=env,text=True)
   ri['job']=json.loads(log);rows[target+'-'+trace]=ri
 (s/f'query-images-{v}.json').write_text(json.dumps(rows,indent=2)+'\n')
with ThreadPoolExecutor(2)as pool:list(pool.map(lane,['1.95.0','stable']))
