Each of 156 linked release cost cases completed with identical work and
completion counts for 20 paired samples per core. On the two final-build
cores the wide rational sine ratios at precision −256 were 0.996 and
0.973, compared with 1.030–1.086 for the earlier implementation across
four cores. Across all cases, final per-core suite medians ranged from
1.009 to 1.017. Byte-identical controls on separate cores ranged from
0.994 to 1.012. No individual case measured more than 3% slower on both
final-build cores. A separate direct comparison of 152 warm, cold and
refusal workloads had a median ratio of 0.983 on each of two cores.
These measurements resolve the earlier wide-sine slowdown. Smaller
runtime differences remain within the resolution of this comparison.
