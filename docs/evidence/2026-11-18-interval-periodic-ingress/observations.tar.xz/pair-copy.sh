set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for v in copy canonical; do
 python3 "$s/pair-copy.py" "$v"
 python3 "$s/artifacts.py" "$v" > "$s/logs/$v-images.log" 2>&1 &
 a=$!
 python3 "$s/life.py" "$v" > "$s/logs/$v-life.log" 2>&1 &
 b=$!
 wait "$a"; wait "$b"
done
