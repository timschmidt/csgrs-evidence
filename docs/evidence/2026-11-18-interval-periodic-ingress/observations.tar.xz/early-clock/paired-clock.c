#define _GNU_SOURCE
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
static int rfd,wfd,turn;
__attribute__((constructor)) static void configure(void) {
    rfd=atoi(getenv("TURN_READER")); wfd=atoi(getenv("TURN_WRITER"));
}
int clock_gettime(clockid_t id,struct timespec *now) {
    if(id!=CLOCK_MONOTONIC)return syscall(SYS_clock_gettime,id,now);
    char ch=42;
    if(turn==0) {
        ssize_t n; do {n=read(rfd,&ch,1);} while(n<0 && errno==EINTR);
        if(n!=1)_exit(120);
        turn=1;return syscall(SYS_clock_gettime,CLOCK_THREAD_CPUTIME_ID,now);
    }
    int rc=syscall(SYS_clock_gettime,CLOCK_THREAD_CPUTIME_ID,now);
    turn=0;if(write(wfd,&ch,1)!=1)_exit(121);return rc;
}
