from pathlib import Path
import csv,json,statistics as st
s=Path(__file__).parent
def summary(p,reverse=False):
 d={}
 for r in csv.DictReader(p.open()):
  k='/'.join(r[a] for a in ('source','operation','precision','mode'))
  x,y=map(int,(r['base_ns'],r['final_ns']))
  d.setdefault(k,[]).append(x/y if reverse else y/x)
 assert all(len(v)==20 for v in d.values())
 return {k:st.median(v) for k,v in d.items()}
sets={}
for name in ('paired','official'):
 data=[summary(s/f'{name}-{c}.csv') for c in (7,17)]
 assert len(data[0])==(152 if name=='paired' else 156)
 sets[name]=dict(per_core_median=[st.median(x.values()) for x in data],slow_in_both={k:[x[k] for x in data] for k in data[0] if min(x[k] for x in data)>1.03})
ordered=[summary(s/f'ordered-{c}-{o}.csv',o=='final-base') for c in (7,17) for o in ['final-base','base-final']]
initial=[summary(s/f'official-{c}.csv') for c in (7,17)]
controls=[summary(s/f'ordered-{c}-base-control.csv') for c in (7,17)]
sets['official_all_orders']=dict(slow_on_both_cpus_and_all_arrangements=[k for k in initial[0] if min(x[k] for x in initial+ordered)>1.03],control_minmax_ratio_by_core=[[min(x.values()),max(x.values())] for x in controls])
def bench(path):
 d={}
 for r in csv.DictReader(path.open()):
  k='/'.join(r[x] for x in ['backend','case','precision'])
  d.setdefault(k,[]).append([int(r[x]) for x in ('elapsed_ns','completed_images','work_units_per_image')])
 assert len(d)==78 and all(len(v)==20 for v in d.values()),path
 return d
for suite in ('trig_cost','tangent_cost'):
 pair={}
 for c in (7,17):
  a,b=[bench(s/f'linked-{c}-{v}-{suite}.csv')for v in ['base','final']]
  for k in a:
   assert all(x[1:]==y[1:] for x,y in zip(a[k],b[k]))
   pair.setdefault(k,[]).append(st.median(y[0]/x[0] for x,y in zip(a[k],b[k])))
 sets['matched_linked_'+suite]=dict(median_by_core=[st.median(q[i]for q in pair.values())for i in range(2)],slow_on_both={k:v for k,v in pair.items()if min(v)>1.03},all=pair)
(s/'cost-review.json').write_text(json.dumps(sets,indent=2)+'\n')
