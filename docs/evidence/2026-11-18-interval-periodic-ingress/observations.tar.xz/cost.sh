set -eu
. /dev/shm/interval-scalar-replay/env
s=/dev/shm/interval-periodic-ingress
cd "$s/src"
export CARGO_TARGET_DIR="$s/target"
cargo build --release --locked -p hyperinterval --all-features --example ingress_cost
"$CARGO_TARGET_DIR/release/examples/ingress_cost" > "$s/$1-cost.csv"
