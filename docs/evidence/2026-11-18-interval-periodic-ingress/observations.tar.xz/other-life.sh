set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for v in bounded outlined cold; do
 python3 "$s/variants.py" "$v"
 rustfmt --edition 2024 "$s/src/crates/hyperinterval/src/tangent.rs" "$s/src/crates/hyperinterval/src/trigonometry.rs"
 python3 "$s/life.py" "$v"
 python3 "$s/compare.py" "$v"
done
