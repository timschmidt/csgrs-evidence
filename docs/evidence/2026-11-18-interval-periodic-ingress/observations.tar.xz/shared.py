from pathlib import Path
s=Path(__file__).parent;r=s/'src';p=r/'crates/hyperinterval/src'
b=(p/'trigonometry.rs').read_text()
keep=b[b.index('// Reserve both'):b.index('pub(crate) struct Reduced')]
t=(s/'raw-trigonometry.rs').read_text()
i=t.index('// The source selection');j=t.index('pub(crate) struct Reduced',i)
start=keep.index('pub(crate) fn'); code=keep[keep.index('    let (_, ln'):keep.index('    Ok(())')]
template=t[i:j]
a=template.index('    let (ls,');z=template.index('    evaluate(',a)
code=code+'''    let (ls, ln, ld) = (left.sign(), left.numerator(), left.denominator());
    let (rs, rn, rd) = (right.sign(), right.numerator(), right.denominator());
'''
t=t[:i]+keep[:keep.index('#[cfg')]+template[template.index('#[cfg'):a]+code+template[z:]+t[j:]
(p/'trigonometry.rs').write_text(t);(p/'tangent.rs').write_text((s/'raw-tangent.rs').read_text())
