use hyperinterval::{RationalInterval,DyadicBudget,DomainCoverage,IntervalError};
use hyperreal::{ExactDyadicLine2,Rational};
use std::hint::black_box;
fn coordinate(span:f64,y:f64)->Rational{
 let line=ExactDyadicLine2::from_f64([0.,0.],[span,span]).unwrap();
 let (_,p)=line.intersection_point_f64([0.,y],[span,y]).unwrap();
 p[0].exact_rational_ref().unwrap().clone()
}
fn source(k:u32)->RationalInterval{match k{
 0=>RationalInterval::empty(),1=>RationalInterval::point(Rational::from(0)),
 2=>RationalInterval::new(Rational::from(-4),Rational::from(4)).unwrap(),
 3=>RationalInterval::point(Rational::from(3)),
 4=>RationalInterval::new(Rational::fraction(8,7).unwrap(),Rational::fraction(10,7).unwrap()).unwrap(),
 5=>RationalInterval::point(coordinate(6.,3.)),
 6=>RationalInterval::new(coordinate(6.,3.),coordinate(10.,3.)).unwrap(),
 _=>RationalInterval::new(Rational::from(2),coordinate(281474976710662.,3.)).unwrap(),
}}
struct Input{iv:RationalInterval,case:u32}
#[unsafe(no_mangle)] pub extern "C" fn setup(k:u32)->*mut std::ffi::c_void{ Box::into_raw(Box::new(Input{iv:source(k),case:k})).cast() }
#[unsafe(no_mangle)] pub unsafe extern "C" fn release(iv:*mut std::ffi::c_void){drop(unsafe{Box::from_raw(iv.cast::<Input>())});}
#[unsafe(no_mangle)] pub unsafe extern "C" fn batch(iv:*mut std::ffi::c_void,op:u32,p:i32,count:u32,mode:u32)->u64{
 let iv=unsafe{&*iv.cast::<Input>()};let mut receipt=0;
 for _ in 0..count {
  let made;let input=if mode==1{made=source(iv.case);&made}else{black_box(&iv.iv)};
  let mut b=if mode==2{DyadicBudget::new(0,100)}else{DyadicBudget::new(8192,1<<50)};
  let r=match op{0=>input.sin(p,&mut b).map(|x|black_box(x).domain),1=>input.cos(p,&mut b).map(|x|black_box(x).domain),2=>input.tan(p,&mut b).map(|x|black_box(x).domain),_=>input.cot(p,&mut b).map(|x|black_box(x).domain)};
  let state=match r{Ok(DomainCoverage::Complete)=>1,Ok(DomainCoverage::Partial)=>2,Err(IntervalError::EmptyDomain)=>3,Err(IntervalError::SizeExhausted)=>4,_=>panic!("unexpected result {r:?}")};
  receipt=black_box((b.remaining_work()<<3)+state);
 }
 receipt
}
