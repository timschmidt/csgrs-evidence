from pathlib import Path
import sys,subprocess as sp,shutil
s=Path(__file__).parent;r=s/'src';repo=Path('/mnt/development/csgrs');stage=sys.argv[1]
files=['crates/hyperreal/src/rational/arithmetic/queries_conversion.rs','crates/hyperinterval/src/trigonometry.rs','crates/hyperinterval/src/tangent.rs'];rev=(s/'revision').read_text().strip()
for n in files:(r/n).write_bytes(sp.check_output(['git','show',rev+':'+n],cwd=repo))
p=r/files[0];t=p.read_text().replace('    pub fn reduction_input_bits(', '    #[inline]\n    pub fn reduction_input_bits(')
if stage=='canonical':
 a=t.index('    /// Borrow the stored sign')
 t=t[:a]+'''    /// Borrow the canonical signed ratio, reducing a generated coordinate on
    /// first access if needed. Budgeted consumers can inspect the stored
    /// ratio and [\x60Self::reduction_input_bits\x60] before requesting this view.
    pub fn reduced_ratio_parts(&self) -> (Sign, &BigUint, &BigUint) {
        self.canonicalized_ref().ratio_parts()
    }

'''+t[a:]
p.write_text(t)
for f in files[1:]:
 p=r/f;t=p.read_text()
 i=t.index('        let (an, ad, bn, bd)');j=t.index('        range(',i)
 t=t[:i]+'''        let (an, ad) = signed_rational_source(a);
        let (bn, bd) = signed_rational_source(b);
'''+t[j:]
 if f.endswith('/trigonometry.rs'):
  i=t.index('impl DyadicInterval {');body='''let (sign, numerator, denominator) = value.reduced_ratio_parts();''' if stage=='canonical' else '''let (sign, numerator, denominator) = if value.reduction_input_bits() == 0 {
        value.ratio_parts()
    } else {
        (value.sign(), value.numerator(), value.denominator())
    };'''
  t=t[:i]+'''#[cfg(feature = "rational")]
#[inline]
pub(crate) fn signed_rational_source(value: &hyperreal::Rational) -> (BigInt, BigInt) {
    '''+body+'''
    (BigInt::from_biguint(sign, numerator.clone()), BigInt::from(denominator.clone()))
}

'''+t[i:]
 else:t=t.replace('use crate::trigonometry::reserve_rational_sources;', 'use crate::trigonometry::{reserve_rational_sources, signed_rational_source};')
 p.write_text(t)
for f in files:
 p=r/f;sp.run(['rustfmt','--edition','2024',p],check=True);shutil.copy(p,s/(stage+'-'+p.name))
