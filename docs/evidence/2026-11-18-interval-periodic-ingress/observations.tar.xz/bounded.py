from pathlib import Path
s=Path(__file__).parent;r=s/'src'
p=r/'crates/hyperreal/src/rational/arithmetic/queries_conversion.rs'
t=p.read_text();i=t.index('    /// Borrow the stored sign')
p.write_text(t[:i]+'''    /// Width of the largest stored magnitude that may need reduction to
    /// expose the canonical numerator and denominator. Already reduced
    /// storage returns zero. The bound ignores cache warmth so a budgeted
    /// caller can charge the same work on a fresh or repeated evaluation.
    /// Inspecting it does not reduce the fraction or allocate.
    pub fn reduction_input_bits(&self) -> u64 {
        if self.is_internally_unreduced() {
            self.numerator.bits().max(self.denominator.bits())
        } else {
            0
        }
    }

'''+t[i:])
p=r/'crates/hyperinterval/src/trigonometry.rs'
t=(s/'raw-trigonometry.rs').read_text()
i=t.index('// The source selection')
j=t.index('pub(crate) struct Reduced',i)
t=t[:i]+'''// Reserve both source copies and any deferred reductions before either
// canonical accessor can allocate. Each possible reduction is charged for
// a GCD and two divisions, independently of cache warmth or shared storage.
#[cfg(feature = "rational")]
pub(crate) fn reserve_rational_sources(
    left: &hyperreal::Rational,
    right: &hyperreal::Rational,
    budget: &mut DyadicBudget,
) -> Result<(), IntervalError> {
    let (_, ln, ld) = left.ratio_parts();
    let (_, rn, rd) = right.ratio_parts();
    budget.reserve(ln.bits().max(ld.bits()).max(rn.bits()).max(rd.bits()), 4, false)?;
    for value in [left, right] {
        let bits = value.reduction_input_bits();
        if bits != 0 {
            budget.reserve(bits, 3, true)?;
        }
    }
    Ok(())
}

'''+t[j:]
i=t.index('        with_rational_sources(a,')
j=t.index('\n    }\n}',i)
base=p.read_text()
body=base[base.index('        let (an, ad, bn, bd)'):base.index('\n    }\n}',base.index('        let (an, ad, bn, bd)'))]
p.write_text(t[:i]+'        reserve_rational_sources(a, b, budget)?;\n'+body+t[j:])
p=r/'crates/hyperinterval/src/tangent.rs';t=p.read_text()
i=t.index('        budget.reserve(\n            a.numerator()');j=t.index('        let (an, ad, bn, bd)',i)
p.write_text(('#[cfg(feature = "rational")]\nuse crate::trigonometry::reserve_rational_sources;\n'.join(t.split('use crate::trigonometry::{',1)) if False else (t[:i]+'        reserve_rational_sources(a, b, budget)?;\n'+t[j:])).replace('use crate::trigonometry::{','#[cfg(feature = "rational")]\nuse crate::trigonometry::reserve_rational_sources;\nuse crate::trigonometry::{'))
