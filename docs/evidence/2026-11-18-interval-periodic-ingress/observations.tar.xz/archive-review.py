from pathlib import Path
import json,importlib.util
s=Path(__file__).parent
spec=importlib.util.spec_from_file_location('writer','/dev/shm/interval-budget-receipt/width-record.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.s=s
items=set()
for pat in ['README.md','scope.md','base','revision','complete-revision','timing-conclusion.md','*.rs','*.csv','*.py','*.sh','*.c','*.mjs','*.tsv','*.txt','*.json','logs/*','corpus-*/*','early-clock/*','package-client/tests/*','package-client/Cargo.*','complete-package-client/Cargo.*','complete-package-client/tests/*','portable-query/Cargo.*','portable-query/tests/*']:
 items.update(p for p in s.glob(pat) if p.is_file() and p.name not in {'fixed-metadata.json','portable-meta.json'})
for folder in ['life','life-clean','timing']:
 items.update(p for p in (s/folder).rglob('*') if p.is_file())
assert not any('target' in p.relative_to(s).parts for p in items)
print(json.dumps(m.record('periodic-ingress',items,'Archive periodic source admission, cold and warm lifetimes and measured allowances')))
