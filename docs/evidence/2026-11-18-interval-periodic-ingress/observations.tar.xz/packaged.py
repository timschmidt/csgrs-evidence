import os,shutil,subprocess as sp,tomllib,json
from pathlib import Path
s=Path(__file__).parent;root=Path('/mnt/development/csgrs');reg=s/'registry';reg.mkdir(exist_ok=True)
orig=Path(os.environ['CARGO_HOME'])/'registry'
cache=next((orig/'cache').glob('index.crates.io-*'))
idx=next((orig/'index').glob('index.crates.io-*'))/'.cache'
def rel(n):return '1/'+n if len(n)==1 else '2/'+n if len(n)==2 else '3/'+n[0]+'/'+n if len(n)==3 else n[:2]+'/'+n[2:4]+'/'+n
for pkg in tomllib.loads((root/'Cargo.lock').read_text())['package']:
 if 'source' not in pkg:continue
 n=pkg['name'];f=cache/(n+'-'+pkg['version']+'.crate');p=reg/'index'/rel(n)
 if not f.exists() or not (idx/rel(n)).exists():continue
 link=reg/f.name
 if not link.exists():link.symlink_to(f)
 if p.exists():continue
 p.parent.mkdir(parents=True,exist_ok=True)
 data=[v for v in (idx/rel(n)).read_bytes().split(b'\0') if v.startswith(b'{"name":')]
 assert data;p.write_bytes(b'\n'.join(data)+b'\n')
for n in ('autocfg','num','num-bigint','num-rational','num-traits','num-complex','num-integer','num-iter'):
 for file in cache.glob(n+'-*.crate'):
  if not (reg/file.name).exists():(reg/file.name).symlink_to(file)
shutil.copytree(s/'package-target/package/tmp-registry',reg,dirs_exist_ok=True)
ext=s/'package-client';(ext/'tests').mkdir(parents=True,exist_ok=True)
(ext/'Cargo.toml').write_text('''[package]
name="periodic-registry-client"
version="0.0.0"
edition="2024"
[workspace]
[features]
default=["dyadic","rational","dispatch-trace"]
dyadic=["hyperinterval/dyadic"]
rational=["hyperinterval/rational"]
dispatch-trace=["hyperinterval/dispatch-trace"]
[dependencies]
hyperreal={version="=0.14.0",default-features=false}
hyperinterval={version="=0.1.0",default-features=false}
''')
shutil.copy(root/'crates/hyperinterval/tests/periodic_ingress.rs',ext/'tests/periodic.rs')
env=os.environ|{'CARGO_HOME':str(s/'package-home'),'CARGO_TARGET_DIR':str(s/'package-client-target')}
cfg=['--config','source.crates-io.replace-with="local"','--config','source.local.local-registry="'+str(reg)+'"']
for v in ['1.95.0','stable']:
 cmd=['cargo','+'+v,*cfg]
 with (s/'logs'/f'packaged-{v}.log').open('w') as log:
  sp.run(cmd+['test','--offline','--release'],cwd=ext,env=env,stdout=log,stderr=log,check=True)
 m=json.loads(sp.check_output(cmd+['metadata','--offline','--locked','--format-version','1'],cwd=ext,env=env))
 for x in m['packages']:
  if x['name'] in ['hyperreal','hyperinterval']:
   assert x['source'].startswith('registry+') and Path(x['manifest_path']).is_relative_to(s/'package-home')
