from pathlib import Path
import sys,shutil
s=Path(__file__).parent;p=s/'src/crates/hyperinterval/src'
for name in ['trigonometry','tangent']:
 t=(s/f'bounded-{name}.rs').read_text()
 if sys.argv[1]=='outlined' and name=='trigonometry':
  t=t.replace('pub(crate) fn reserve_rational_sources(', '#[inline(never)]\npub(crate) fn reserve_rational_sources(')
 if sys.argv[1]=='cold':
  # Canonical work exactly reuses the original frame. Charge a separate guard
  # only on generated coordinates with a possible reduction.
  base=(Path('/mnt/development/csgrs/crates/hyperinterval/src')/(name+'.rs')).read_text()
  i=base.index('        budget.reserve(\n            a.numerator()')
  j=base.index('        let (an, ad, bn, bd)',i)
  t=t.replace('        reserve_rational_sources(a, b, budget)?;','''        if a.reduction_input_bits() != 0 || b.reduction_input_bits() != 0 {
            reserve_rational_sources(a, b, budget)?;
        } else {
'''+base[i:j]+'''        }''')
  if name=='trigonometry':
   t=t.replace('pub(crate) fn reserve_rational_sources(', '#[cold]\n#[inline(never)]\npub(crate) fn reserve_rational_sources(')
 (p/(name+'.rs')).write_text(t)
