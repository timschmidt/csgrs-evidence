set -eu
s=/dev/shm/interval-periodic-ingress
. /dev/shm/interval-scalar-replay/env
for toolchain in 1.95.0 stable; do for target in wasm32-wasip1 x86_64-unknown-linux-gnu; do test "$(wc -l < "$s/life-shared-$toolchain-$target.csv")" -eq 288; done; done
python3 "$s/stages.py" control
python3 "$s/life.py" control
python3 "$s/stages.py" shared
