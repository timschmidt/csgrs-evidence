import hashlib,json,subprocess,tarfile
from pathlib import Path
s=Path(__file__).parent;root=Path('/mnt/development/csgrs');rev=(s/'complete-revision').read_text().strip()
out={}
for pkg,files in [('hyperinterval',['src/trigonometry.rs','src/tangent.rs']),('hyperreal',['src/rational/arithmetic/queries_conversion.rs'])]:
 p,=list((s/'complete-package-target/package').glob(pkg+'-*.crate'))
 out[p.name]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source=rev,verified_files=files)
 with tarfile.open(p) as tar:
  for file in files:
   assert tar.extractfile(p.stem+'/'+file).read()==subprocess.check_output(['git','-C',root,'show',rev+':crates/'+pkg+'/'+file])
(s/'complete-package-hashes.json').write_text(json.dumps(out,indent=2)+'\n')
