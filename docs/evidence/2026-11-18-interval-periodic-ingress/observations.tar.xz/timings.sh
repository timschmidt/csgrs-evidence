set -eu
s=/dev/shm/interval-periodic-ingress
run() {
 for stage in "$2" "$3"; do
  taskset -c "$1" "$s/$stage-stable-$4" > "$s/time-$stage-$1-$4.csv"
 done
}
run 3 base shared trig_cost &
a=$!
run 5 shared base trig_cost &
b=$!
run 13 base shared tangent_cost &
c=$!
run 15 shared base tangent_cost &
d=$!
wait "$a" "$b" "$c" "$d"
