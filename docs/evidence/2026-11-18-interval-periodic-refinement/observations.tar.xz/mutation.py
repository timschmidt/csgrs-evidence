from pathlib import Path
s=Path(__file__).parent
for n,token in [('trigonometry','                }\n            }\n        }\n        working = working.checked_mul(2)'),('tangent','                }\n            }\n        }\n        working = working.checked_mul(2)')]:
 p=s/'src/crates/hyperinterval/src'/f'{n}.rs';t=p.read_text();assert t.count(token)==1
 p.write_text(t.replace(token,token.replace('                }\n','                }\n                return Err(IntervalError::EmptyDomain);\n',1)))
