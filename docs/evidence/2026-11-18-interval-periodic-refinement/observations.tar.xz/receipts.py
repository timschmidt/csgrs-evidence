from pathlib import Path
import os,sys,subprocess as sp,json
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs');src=s/'public-src'
f=Path('crates/hyperinterval/tests/periodic_refinement.rs')
t=(repo/f).read_text().replace('let cost = start - work.remaining_work();','let cost = start - work.remaining_work();\n    println!("debit {cost}");').replace('let mut prefix = cost;', 'let mut prefix = cost;').replace('        steps += 1;', '        steps += 1;').replace('    assert_eq!(\n        evaluate(&mut DyadicBudget::new(4096, cost)).unwrap(),','    println!("sweep {steps} cost {cost}");\n    assert_eq!(\n        evaluate(&mut DyadicBudget::new(4096, cost)).unwrap(),')
assert t.count('println!("sweep')==1;(src/f).write_text(t)
sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr');base=['cargo','+stable','test','--locked','--release','-p','hyperinterval','--all-features','--test','periodic_refinement','--no-run','--message-format=json-render-diagnostics']
out={}
for target in ('native','wasm32-wasip1'):
 env=os.environ|{'CARGO_TARGET_DIR':str(s/'receipt-target')};cmd=base.copy()
 if target!='native':
  cmd+=['--target',target]
  env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-stable/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
 build=sp.check_output(cmd,cwd=src,env=env,text=True)
 [exe]=[x['executable'] for x in map(json.loads,build.splitlines()) if x.get('executable')]
 run=([exe] if target=='native' else ['node',str(src/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe])+['--test-threads=1','--nocapture']
 with (s/'logs'/f'receipt-{target}.log').open('w') as log:sp.run(run,stdout=log,stderr=sp.STDOUT,check=True)
 import re
 log=(s/'logs'/f'receipt-{target}.log').read_text();out[target]=re.findall(r'(?:debit \d+|sweep \d+ cost \d+)',log)
 assert len(out[target])==22
assert out['native']==out['wasm32-wasip1']
(s/'debits.json').write_text(json.dumps(out['native'],indent=2)+'\n')
