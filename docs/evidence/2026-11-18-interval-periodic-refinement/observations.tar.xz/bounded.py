import os,sys,time,subprocess as sp,json
from pathlib import Path
s=Path(__file__).parent
v,t,exe=sys.argv[1:];expected=3 if v=='1.88.0' else 4
group=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
root=Path('/mnt/development/csgrs')
command=([exe] if t=='native' else ['node',str(root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe])+['--test-threads=1']
start=time.monotonic()
data=sp.check_output(command,cwd=root,stderr=sp.STDOUT,text=True);(s/'logs'/f'{v}-{t}.run').write_text(data)
assert f'test result: ok. {expected} passed; 0 failed;' in data
peak=int((group/'memory.peak').read_text());cap=int((group/'memory.max').read_text());events=(group/'memory.events').read_text()
assert cap==256*2**20 and peak+64*2**20<=cap and (group/'memory.swap.max').read_text().strip()=='0' and all(q.split()[1]=='0' for q in events.splitlines())
print(json.dumps(dict(seconds=time.monotonic()-start,peak=peak,headroom=cap-peak,cmd=command,events=events,passes=expected)))
