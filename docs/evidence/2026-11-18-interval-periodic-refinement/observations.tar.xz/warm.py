"""Allow an existing cold build cache to be reused at the identical absolute path."""
import os,runpy,sys
from pathlib import Path
s=Path('/dev/shm/interval-scalar-replay')
driver=Path('crates/hyperinterval/conformance/wasi-tests.py').resolve()
v=sys.argv[1]
output=s/('accepted-'+v);cold=Path(__file__).parent/('previous-job-'+v)
assert (output/'report.json').is_file() and not cold.exists()
output.rename(cold)
mkdir=Path.mkdir
def reuse_cache(self,*args,**kwargs):
 result=mkdir(self,*args,**kwargs)
 if self==output:
  for name in ('target','gmp-cache'):
   if (cold/name).exists():(cold/name).rename(output/name)
  Path.mkdir=mkdir
 return result
Path.mkdir=reuse_cache
sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
sys.path.insert(0,str(driver.parent))
sys.argv=[str(driver),'--toolchain',v,'--cc',str(sdk/'bin/clang-18'),'--sysroot',str(sdk),'--output',str(output)]
runpy.run_path(str(driver),run_name='__main__')
