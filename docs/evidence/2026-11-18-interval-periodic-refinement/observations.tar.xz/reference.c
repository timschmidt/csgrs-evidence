#include <mpfr.h>
#include <stdio.h>
#include <stdlib.h>

typedef int (*operation)(mpfr_ptr, mpfr_srcptr, mpfr_rnd_t);
static void endpoint(mpfr_ptr out, mpfr_srcptr arg, operation op, int upper, unsigned int scale) {
    mpfr_t lo, hi;
    mpfr_inits2(512, lo, hi, (mpfr_ptr)0);
    op(lo, arg, MPFR_RNDD);
    op(hi, arg, MPFR_RNDU);
    mpfr_mul_2ui(lo, lo, scale, MPFR_RNDD);
    mpfr_mul_2ui(hi, hi, scale, MPFR_RNDU);
    if (upper) { mpfr_ceil(lo, lo); mpfr_ceil(hi, hi); }
    else { mpfr_floor(lo, lo); mpfr_floor(hi, hi); }
    if (!mpfr_equal_p(lo,hi)) abort();
    mpfr_set(out, lo, MPFR_RNDN);
    mpfr_clears(lo, hi, (mpfr_ptr)0);
}
static void cells(const char *name, unsigned long divisor, operation op, int decreasing, int pole) {
    mpfr_t lo,hi,x,y,a,b;
    mpfr_inits2(512,lo,hi,x,y,a,b,(mpfr_ptr)0);
    mpfr_const_pi(lo, MPFR_RNDD); mpfr_const_pi(hi, MPFR_RNDU);
    mpfr_div_ui(lo,lo,divisor,MPFR_RNDD); mpfr_div_ui(hi,hi,divisor,MPFR_RNDU);
    mpfr_mul_2ui(lo,lo,48,MPFR_RNDD); mpfr_mul_2ui(hi,hi,48,MPFR_RNDU);
    mpfr_floor(lo,lo); mpfr_floor(hi,hi);
    if (!mpfr_equal_p(lo, hi)) abort();
    for (int i=-1;i<=1;i++) {
        mpfr_add_si(x,lo,i,MPFR_RNDN); mpfr_add_ui(y,x,1,MPFR_RNDN);
        mpfr_div_2ui(x,x,48,MPFR_RNDN); mpfr_div_2ui(y,y,48,MPFR_RNDN);
        endpoint(a, decreasing ? y : x, op, 0, 8);
        endpoint(b, decreasing ? x : y, op, 1, 8);
        mpfr_printf("%s %.0Rf %+d %s %.0Rf %.0Rf\n",name,lo,i,pole && i==0 ? "split-above-below" : "finite",a,b);
    }
    mpfr_clears(lo,hi,x,y,a,b,(mpfr_ptr)0);
}
int main(void) {
    mpfr_t x, value;
    mpfr_inits2(512,x,value,(mpfr_ptr)0);
    for (int k=1;k<=2;k++) {
        mpfr_set_ui(x,k,MPFR_RNDN); mpfr_div_2ui(x,x,1,MPFR_RNDN);
        endpoint(value,x,mpfr_sin,0,4); mpfr_printf("sweep sin_lower %d/2 %.0Rf\n",k,value);
        endpoint(value,x,mpfr_tan,0,4); mpfr_printf("sweep tan_lower %d/2 %.0Rf\n",k,value);
    }
    mpfr_set_ui(x,2,MPFR_RNDN); endpoint(value,x,mpfr_tan,1,4);
    mpfr_printf("sweep tan_upper 2 %.0Rf\n",value);
    mpfr_clears(x,value,(mpfr_ptr)0);
    cells("sin_pi6",6,mpfr_sin,0,0); cells("cos_pi3",3,mpfr_cos,1,0);
    cells("tan_pi4",4,mpfr_tan,0,0); cells("cot_pi4",4,mpfr_cot,1,0);
    cells("tan_pi2",2,mpfr_tan,0,1); cells("cot_pi",1,mpfr_cot,1,1);
}
