from pathlib import Path
import json,importlib.util
s=Path(__file__).parent
spec=importlib.util.spec_from_file_location('writer','/dev/shm/interval-budget-receipt/width-record.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.s=s
items=set()
for glob in ('README.md','scope.md','base','revision','*.tsv','*.json','*.py','*.sh','reference.c','versions.txt','logs/*','whole-*/*','corpus-*/*'):
 items.update(p for p in s.glob(glob) if p.is_file())
print(json.dumps(m.record('periodic-refinement',items,'Archive directed periodic cell references, full work-boundary sweeps and resource accounts')))
