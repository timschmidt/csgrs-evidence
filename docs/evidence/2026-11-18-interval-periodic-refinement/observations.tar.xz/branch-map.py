from collections import defaultdict
from pathlib import Path
import json,re
s=Path(__file__).parent
def observations(stage):
 log=(s/'logs'/('branch-'+stage+'.log')).read_text()
 d=Path(re.search(r'^Coverage artifacts in (.+)$',log,re.M)[1]);data=defaultdict(lambda:[False,False])
 current=''
 for line in (d/'uncovered.txt').open():
  if line.startswith('/') and line.strip().endswith('.rs:'):
   current=line.strip().split('/crates/hyperinterval/')[1][:-1]
  if hit:=re.search(r'Branch \((\d+):(\d+)\): \[True: (\S+), False: ([^\]]+)\]',line):
   obj=data[current+':'+hit[1]+':'+hit[2]];obj[0]|=hit[3]!='0';obj[1]|=hit[4]!='0'
 return data
a,b=(observations(stage) for stage in ('base','candidate'))
assert a.keys()==b.keys()
res={'newly_taken_source_branch_directions':{k:[a[k],b[k]] for k in a if a[k]!=b[k]},'remaining_source_locations_with_an_uncovered_direction':{k:v for k,v in b.items() if not all(v)}}
(s/'branch-locations.json').write_text(json.dumps(res,indent=2)+'\n')
print(res['newly_taken_source_branch_directions'])
