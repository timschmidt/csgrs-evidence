set -eu
s=/dev/shm/interval-phase-neighbors
. /dev/shm/interval-scalar-replay/env
export CARGO_TARGET_DIR=/dev/shm/interval-fixed-hull/coverage
repo=$PWD
mkdir -p "$s/coverage-src"
git archive "$(cat "$s/base")" | tar -xmC "$s/coverage-src"
cd "$s/coverage-src"
for stage in base candidate; do
 if test "$stage" = candidate; then cp "$repo/crates/hyperinterval/tests/periodic_refinement.rs" crates/hyperinterval/tests/; fi
 set +e
 python3 scripts/interval_coverage.py > "$s/logs/coverage-$stage.log" 2>&1
 result=$?
 set -e
 if test "$result" -ne 0; then rg -q '^Production coverage is below 100% on the instrumented metrics.$' "$s/logs/coverage-$stage.log"; fi
 dir=$(sed -n 's/^Coverage artifacts in //p' "$s/logs/coverage-$stage.log")
 cp "$dir/summary.json" "$s/coverage-$stage.json"
done
