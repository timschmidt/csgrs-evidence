from pathlib import Path
import re,json,hashlib,subprocess as sp
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs');ep='docs/evidence/2026-11-18-interval-periodic-refinement'
def read(p):return json.loads((s/p).read_text())
def save(n,v):(s/n).write_text(json.dumps(v,indent=2)+'\n')
rev=(s/'revision').read_text().strip();base=(s/'base').read_text().strip()
file='crates/hyperinterval/tests/periodic_refinement.rs'
source=sp.check_output(['git','show',rev+':'+file],cwd=repo,text=True)
assert (repo/file).read_text()==source
# Check the committed grids against the directed reference, independently of libtest.
t=re.sub(r'(?<=\d)_(?=\d)','',source);compact=re.sub(r'\s+','',t)
groups={}
for line in (s/'reference.tsv').read_text().splitlines():
 row=line.split()
 if row[0]=='sweep':continue
 name,floor,offset,shape,lo,hi=row
 groups.setdefault((name,floor),[]).append((int(offset),shape,lo,hi))
assert len(groups)==6
for (name,floor),rows in groups.items():
 assert [i for i,*_ in rows]==[-1,0,1]
 values=[]
 for _,kind,lo,hi in rows:
  if name.startswith(('sin','cos')):values.append(f'({lo},{hi})')
  elif kind=='finite':values.append(f'Finite({lo},{hi})')
  else:values.append('Split{below:'+hi+',above:'+lo+'}')
 # rustfmt may introduce a trailing comma on multiline struct literals.
 normalized=compact.replace(',}','}').replace(',]',']')
 key=('true' if name.startswith(('cos','cot')) else 'false')+','+floor+',['+','.join(values)+']'
 assert key in normalized,(name,key)
assert (s/'reference.tsv').read_text().startswith('sweep sin_lower 1/2 7\nsweep tan_lower 1/2 8\nsweep sin_lower 2/2 13\nsweep tan_lower 2/2 24\nsweep tan_upper 2 -34\n')
coverage={}
for compiler,key in [('stable','coverage'),('nightly','branch')]:
 a,b=[read(f'{key}-{v}.json') for v in ('base','candidate')]
 assert a['rustc']==b['rustc'] and a['files'].keys()==b['files'].keys() and b['llvm_diagnostics']==a['llvm_diagnostics']==''
 for n in a['files']:
  for k in ('lines','regions','functions','branches'):
   x,y=[z['files'][n][k] for z in (a,b)]
   assert x['count']==y['count'] and x['covered']<=y['covered']
 coverage[compiler]={k:[v['covered'],b['production'][k]['covered'],v['count']] for k,v in a['production'].items()}
coverage['columns']=['baseline covered','retained covered','total']
save('coverage-delta.json',coverage)
prior=json.loads((repo/'docs/research/interval-memory-accounts.json').read_text())['whole_scalar_wasi_qualification']
size={};memory={}
for v in ('1.88.0','1.95.0','stable'):
 data=read('images-'+v+'.json');size[v]={};memory[v]={}
 for target,img in data.items():
  assert img['file']<=4*2**20 and 64*2**20-img['file']>=16*2**20
  size[v][target]={k:img[k] for k in ('file','code','functions','sha256')}
  size[v][target].update(remaining_file_allowance_bytes=4*2**20-img['file'],free_slot_bytes=64*2**20-img['file'])
  q=img['job'];assert q['headroom']>=64*2**20 and q['passes']==(3 if v=='1.88.0' else 4)
  memory[v][target]=dict(complete_new_job_peak_bytes=q['peak'],above_reserve_bytes=q['headroom']-64*2**20,elapsed_seconds=round(q['seconds'],3))
 # The new combined test suite is in the standard conformance job's direct inventory.
 official=Path('/dev/shm/interval-scalar-replay')/('accepted-'+v)
 report=json.loads((official/'report.json').read_text())
 assert len(report['guest']['periodic_refinement'])==q['passes']
 assert len(report['fresh_replays'])==5
 (s/f'whole-{v}-report.json').write_text(json.dumps(report,indent=2)+'\n')
 log=(s/'logs'/f'full-{v}.log').read_text()
 assert 'memory.max 1073741824' in log and 'memory.swap.max 0' in log and '\noom 0\noom_kill 0\n' in log and '\nmax 0\n' in log
 peak=int(re.search(r'^memory.peak (\d+)',log,re.M)[1]);hist=prior['targets'][v]['registered_whole_job_charge_bytes'];charge=max(0,peak-hist)
 assert hist+charge+prior['required_headroom_bytes']<=prior['capacity_bytes']
 memory[v]['whole_scalar_job']=dict(previous_positive_charge_bytes=hist,measured_peak_bytes=peak,incremental_positive_charge_bytes=charge,cumulative_positive_charge_bytes=hist+charge,remaining_above_required_reserve_bytes=prior['capacity_bytes']-prior['required_headroom_bytes']-hist-charge,direct_guest_passes=sum(map(len,report['guest'].values())),native_cases=len(report['host_required']),fresh_replay_count=len(report['fresh_replays']))
save('size-entry.json',dict(source=rev,preceding=base,evidence=ep,scope='New combined periodic-refinement integration test executable. Register each complete per-target file, emitted code and nonoverlapping function size. Existing test and production accounts carry forward.',file_cap_bytes=4*2**20,ci_slot_bytes=64*2**20,required_free_slot_bytes=16*2**20,targets=size))
save('memory-entry.json',dict(source=rev,evidence=ep,scope='One freshly instantiated compiled test job, sequential cases, inside a swap-disabled Linux cgroup, including native or Node/WASI startup through process exit. Separately charge the complete warmed scalar conformance job against its existing register. Production heap and stack accounts carry forward.',single_test_job_capacity_bytes=256*2**20,single_test_job_reserved_bytes=64*2**20,whole_job_capacity_bytes=prior['capacity_bytes'],whole_job_reserved_bytes=prior['required_headroom_bytes'],targets=memory))
for name in ('trigonometry','tangent'):
 for target in ('native','wasm32-wasip1'):
  assert '0 failed;' in (s/'logs'/f'control-{name}-{target}-{name}.log').read_text()
  for test in ('rational_source_exhaustion_preserves_the_pole_and_extremum','work_exhaustion_through_critical_point_and_pole_images'):
   log=(s/'logs'/f'control-{name}-{target}-{test}.log').read_text();assert all(q in log for q in (test,'Err(WorkExhausted)','Ok(RangeEnclosure'))
for n in ('solver','dynamics'):
 assert '0 failed;' in (s/'logs'/(n+'.log')).read_text()
receipts=read('debits.json')
assert sum(int(x.split()[1]) for x in receipts if x.startswith('sweep '))==1374 and max(int(x.split()[1]) for x in receipts if x.startswith('debit '))==341095460
print(coverage)
