from pathlib import Path
import subprocess as sp
s=Path(__file__).parent;root=Path('/mnt/development/csgrs')
for n in ['trigonometry','tangent']:
 name=f'crates/hyperinterval/src/{n}.rs';p=s/'src'/name;t=sp.check_output(['git','show',(s/'base').read_text().strip()+':'+name],cwd=root,text=True)
 if n=='tangent':
  k='                if (left_pole || left.is_some())'
  t=t.replace(k,'                if !left_pole && !right_pole && left.is_none() && right.is_none() { return Err(IntervalError::EmptyDomain); }\n'+k)
 else:
  assert t.count('if let (Some(left), Some(right)) = (')==1
  t=t.replace('if let (Some(left), Some(right)) = (','let endpoints = (').replace('evaluate(right, function, precision, working, budget)?,\n                ) {','evaluate(right, function, precision, working, budget)?,\n                );\n                if matches!(endpoints, (None, None)) { return Err(IntervalError::EmptyDomain); }\n                if let (Some(left), Some(right)) = endpoints {')
 p.write_text(t)
