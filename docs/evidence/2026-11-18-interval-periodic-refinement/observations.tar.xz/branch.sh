set -eu
s=/dev/shm/interval-phase-neighbors
. /dev/shm/interval-fixed-hull/env
export RUSTUP_HOME=/dev/shm/interval-flow-coverage/rustup RUSTUP_TOOLCHAIN=nightly RUSTFLAGS=-Zcoverage-options=branch
export CARGO_TARGET_DIR="$s/nightly-target"
repo=$PWD
mkdir -p "$s/nightly-src"
git archive "$(cat "$s/base")" | tar -xmC "$s/nightly-src"
cd "$s/nightly-src"
for stage in base candidate; do
 if test "$stage" = candidate; then cp "$repo/crates/hyperinterval/tests/periodic_refinement.rs" crates/hyperinterval/tests/; fi
 set +e
 python3 scripts/interval_coverage.py > "$s/logs/branch-$stage.log" 2>&1
 result=$?
 set -e
 if test "$result" -ne 0; then rg -q '^Production coverage is below 100% on the instrumented metrics.$' "$s/logs/branch-$stage.log"; fi
 dir=$(sed -n 's/^Coverage artifacts in //p' "$s/logs/branch-$stage.log")
 cp "$dir/summary.json" "$s/branch-$stage.json"
done
