from pathlib import Path
import subprocess as sp
s=Path(__file__).parent;root=Path('/mnt/development/csgrs')
for n in ['trigonometry','tangent']:
 name=f'crates/hyperinterval/src/{n}.rs';p=s/'src'/name;t=sp.check_output(['git','show',(s/'base').read_text().strip()+':'+name],cwd=root,text=True)
 if n=='trigonometry':
  old='let (minimum, maximum) = extrema(&left.index, &right.index, function, budget)?;'
  new='let Ok((minimum, maximum)) = extrema(&left.index, &right.index, function, budget) else { return complete(whole(precision, budget)?); };'
 else:
  old='let (first, second) = extrema(';new='let Ok((first, second)) = extrema('
  assert t.count('                )?;\n                let interior')==1
  t=t.replace('                )?;\n                let interior','                ) else { return whole(); };\n                let interior')
 assert t.count(old)==1;p.write_text(t.replace(old,new))
