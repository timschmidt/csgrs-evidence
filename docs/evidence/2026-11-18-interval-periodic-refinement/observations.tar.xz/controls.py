from pathlib import Path
import subprocess as sp,sys,os,json
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs');src=s/'src';sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
v='stable'
def restore(name):
 f='crates/hyperinterval/src/'+name+'.rs'
 (src/f).write_bytes(sp.check_output(['git','show',(s/'base').read_text().strip()+':'+f],cwd=repo))
for name in ('trigonometry','tangent'):
 sp.run([sys.executable,str(s/'partial.py')],check=True)
 restore('tangent' if name=='trigonometry' else 'trigonometry')
 for target in ('native','wasm32-wasip1'):
  env=os.environ|dict(CARGO_TARGET_DIR=str(s/'target'),CARGO_BUILD_JOBS='6')
  cmd=['cargo','+'+v,'test','--locked','--release','-p','hyperinterval','--all-features','--test',name,'--test','periodic_refinement','--no-run','--message-format=json-render-diagnostics']
  if target!='native':
   cmd+=['--target',target]
   env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-stable/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
  out=sp.check_output(cmd,cwd=src,env=env,text=True)
  for row in map(json.loads,out.splitlines()):
   if not row.get('executable'):continue
   suite=row['target']['name'];exe=row['executable']
   command=([exe] if target=='native' else ['node',str(src/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe])+['--test-threads=1']
   if target!='native' and suite=='tangent':command+=['--skip','replay_then_another_pole_operation_in_fresh_process']
   cases = ['rational_source_exhaustion_preserves_the_pole_and_extremum','work_exhaustion_through_critical_point_and_pole_images'] if suite=='periodic_refinement' else [None]
   for case in cases:
    log=s/'logs'/f'control-{name}-{target}-{case or suite}.log'
    call=command+(['--nocapture','--exact',case] if case else [])
    with log.open('w') as dest:ret=sp.run(call,stdout=dest,stderr=sp.STDOUT).returncode
    content=log.read_text()
    if case:assert ret and 'Err(WorkExhausted)' in content and 'Ok(RangeEnclosure' in content and case in content,log
    else:assert ret==0 and '0 failed;' in content
