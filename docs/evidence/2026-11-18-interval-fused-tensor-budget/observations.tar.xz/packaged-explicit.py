from pathlib import Path
import hashlib,json,os,shutil,subprocess,tomllib
s=Path(__file__).resolve().parent;r=s/'explicit-checkout';p=s/'packaged-explicit-client';p.mkdir(exist_ok=True);(p/'src').mkdir(exist_ok=True)
pkgs={}
for name in ['hyperreal','hyperlattice','hyperlimit','hypersolve']:
 entry=next(x for x in (s/'package-explicit/package').glob(name+'-*') if x.is_dir() and (x/'Cargo.toml').is_file() and tomllib.loads((x/'Cargo.toml').read_text())['package']['name']==name)
 pkgs[name]=entry
assert (pkgs['hypersolve']/'src/tensor_resultant.rs').read_bytes()==(r/'crates/hypersolve/src/tensor_resultant.rs').read_bytes()
text=(s/'tensor-client/Cargo.toml').read_text().replace('tensor-budget-client','packaged-tensor-client').replace('path="../tensor-src/crates/hyperreal"','version="=0.14.0"').replace('path="../tensor-src/crates/hypersolve"','version="=0.4.0"')
text+='\n[patch.crates-io]\n'+''.join(f'{n}={{path="{d}"}}\n' for n,d in pkgs.items())
(p/'Cargo.toml').write_text(text)
for f in ['allocations.rs','main.rs']:shutil.copy((s/'tensor-client-explicit.rs') if f=='main.rs' else (s/'tensor-client/src'/f),p/'src'/f)
env=os.environ|{'CARGO_TARGET_DIR':str(s/'packaged-explicit-target'),'CARGO_BUILD_JOBS':'4'}
subprocess.run(['cargo','generate-lockfile','--offline'],cwd=p,env=env,check=True)
meta=json.loads(subprocess.check_output(['cargo','metadata','--offline','--locked','--format-version','1'],env=env,cwd=p))
for row in meta['packages']:
 if row['name'] in pkgs:assert Path(row['manifest_path']).parent==pkgs[row['name']]
for v in ['1.95.0','stable']:
 with (s/'logs'/f'packaged-explicit-{v}.run').open('w') as log:
  subprocess.run(['cargo','+'+v,'run','--offline','--locked','--release','--','fused'],cwd=p,env=env,check=True,stdout=log)
 lines=(s/'logs'/f'packaged-explicit-{v}.run').read_text().splitlines();assert len([l for l in lines if l.startswith('RECORD')])==128
print('Packaged public client completed for both compilers.')
