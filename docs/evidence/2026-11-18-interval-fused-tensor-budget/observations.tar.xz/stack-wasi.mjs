import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {WASI} from 'node:wasi';
const [binary,...args]=process.argv.slice(2), wasi=new WASI({version:'preview1',args:[binary,...args],env:{},returnOnExit:true});
let instance,start,base,reserve;
const mark=(on,pattern)=>{
 const api=instance.exports, sp=api.__stack_pointer.value, low=api.__stack_low.value, mem=new Uint8Array(api.memory.buffer);
 if(on){assert(sp>low+4096);start=sp;base=low;reserve=sp-low;mem.fill(pattern,low,sp);return 0;}
 assert.equal(sp,start);assert.equal(low,base);
 const first=mem.subarray(low,sp).findIndex(v=>v!==pattern);
 assert(first>262144 && first<reserve);return reserve-first;
};
({instance}=await WebAssembly.instantiate(await readFile(binary),{wasi_snapshot_preview1:wasi.wasiImport,scope:{mark}}));
process.exitCode=wasi.start(instance);
