from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,sys
s=Path(__file__).resolve().parent;stage=sys.argv[1];p=(s/'tensor-client/src/bin');p.mkdir(exist_ok=True);(p/'explicit-oracle.rs').write_bytes((s/'explicit-oracle.rs').read_bytes())
def run(job):
 v,t=job;env=os.environ|{'CARGO_TARGET_DIR':str(s/f'tensor-target-{v}-{t}'),'CARGO_BUILD_JOBS':'4'};file=s/'logs'/f'oracle-{stage}-{v}-{t}.log'
 with file.open('w') as out:
  subprocess.run(['cargo','+'+v,'build','--release','--locked','--manifest-path',s/'tensor-client/Cargo.toml','--bin','explicit-oracle','--target',t],stdout=out,stderr=out,env=env,check=True)
  x=Path(env['CARGO_TARGET_DIR'])/t/'release/explicit-oracle'
  cmd=[x] if 'wasm' not in t else ['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',s/'src/crates/hyperlattice-interval/conformance/run-wasi-test.mjs',x.with_suffix('.wasm')]
  subprocess.run(cmd,stdout=out,stderr=out,check=True)
with ThreadPoolExecutor(4) as pool:list(pool.map(run,[(v,t) for v in ('1.95.0','stable') for t in ('wasm32-wasip1','x86_64-unknown-linux-gnu')]))
