mod allocations;
use hyperreal::Real;
use hypersolve::{DenseTensorPolynomial as T,work_budget::{with_budget,WorkBudget,with_coefficient_bit_limit,WorkKind}};
use std::{env,ffi::c_void,hint::black_box};
#[cfg(not(target_arch="wasm32"))]
unsafe extern "C" {fn measure_stack(callback:unsafe extern "C" fn(*mut c_void),ctx:*mut c_void,warm:i32,pattern:u8)->usize;}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="scope")]
unsafe extern "C" {fn mark(start:u32,pattern:u32)->u32;}
struct Case { input:T, expected:T, mode:u8, limit:u64, correct:bool, heap:Option<allocations::AllocationStats> }
unsafe extern "C" fn complete(ctx:*mut c_void){
 let c=unsafe{&mut *ctx.cast::<Case>()};
 let (_,h)=allocations::once(||{
  let run=||T::sum_products(black_box(&[(&c.input,&c.input,false)])).and_then(check_materialized);
  let product=match c.mode {
   0=>run().unwrap(),
   1=>with_budget(WorkBudget::UNLIMITED,run).result.unwrap().unwrap(),
   2=>with_coefficient_bit_limit(c.limit,run).result.unwrap().unwrap(),
   3=>{
    let attempt=with_coefficient_bit_limit(c.limit-1,run);
    if c.correct{
     let e=attempt.result.unwrap_err();assert_eq!(e.kind,WorkKind::CoefficientGrowth);
     assert_eq!((e.limit as u64,e.requested as u64),(c.limit-1,c.limit));black_box(e.to_string());
    }else{assert_eq!(attempt.result.unwrap().as_ref(),Some(&c.expected));}
    with_coefficient_bit_limit(c.limit,run).result.unwrap().unwrap()
   },_=>unreachable!()
  };
  assert_eq!(product,c.expected);black_box(product);
 });c.heap=Some(h);
}
fn check_materialized(t: T) -> Option<T> {
    use hypersolve::work_budget::{is_active, observe_coefficient_bits};
    if is_active() {
        let bits=t.coefficients().iter().filter_map(Real::exact_rational_ref)
            .map(|q|q.numerator().bits()+q.denominator().bits()).max().unwrap_or(0);
        observe_coefficient_bits(bits).ok()?;
    }
    Some(t)
}

fn main(){
 let a:Vec<_>=env::args().collect();let n:usize=a[2].parse().unwrap();let mode=a[3].parse().unwrap();let warm:bool=a[4].parse().unwrap();let pattern:u8=a[5].parse().unwrap();
 let input=T::try_new(vec![n],vec![Real::from(16);n]).unwrap();
 let expected=T::try_new(vec![2*n-1],(0..2*n-1).map(|i|Real::from(256*(i+1).min(2*n-i-1) as i64)).collect()).unwrap();
 let mut c=Case{input,expected,mode,correct:a[1]=="final",limit:u64::from((256*n).ilog2()+2),heap:None};
 let ctx=(&mut c as *mut Case).cast();
 #[cfg(not(target_arch="wasm32"))]let stack=unsafe{measure_stack(complete,ctx,i32::from(warm),pattern)};
 #[cfg(target_arch="wasm32")]let stack=unsafe{if warm{complete(ctx);}mark(1,u32::from(pattern));complete(ctx);mark(0,u32::from(pattern)) as usize};
 let h=c.heap.unwrap();println!("OBS {n} {mode} {warm} {pattern} {stack} {} {} {} {} {} {}",h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes);
}
