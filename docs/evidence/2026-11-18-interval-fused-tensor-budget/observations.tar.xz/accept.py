from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,subprocess,sys
s=Path(__file__).resolve().parent
sys.path.insert(0,'/dev/shm/interval-solver-library')
from metrics import metrics
r=Path('/mnt/development/csgrs');tag=sys.argv[1];root=Path(sys.argv[2]) if len(sys.argv)>2 else r
def run(job):
 v,t=job;iswasm=t.startswith('wasm')
 env=os.environ|{'CARGO_TARGET_DIR':str(s/f'{os.environ.get("BUDGET_TEST_TARGET","target")}-{v}-{t}'),'CARGO_BUILD_JOBS':'5'}
 cmd=['cargo','+'+v,'test','--release','--locked','-p','hypersolve','--all-features','--test','coefficient_bit_budget','--target',t,'--no-run','--message-format=json-render-diagnostics']
 stem=s/'logs'/f'{tag}-{v}-{t}-fixture'
 with Path(str(stem)+'.build').open('w') as log:build=subprocess.check_output(cmd,cwd=root,env=env,stderr=log,text=True)
 bins=[Path(x['executable']) for x in map(json.loads,build.splitlines()) if x.get('executable')]
 assert len(bins)==1
 command=['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',str(r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),str(bins[0])] if iswasm else [str(bins[0])]
 p=subprocess.run([*command,'--test-threads=1','--nocapture'],capture_output=True,text=True)
 Path(str(stem)+'.log').write_text(p.stdout+p.stderr)
 if tag.startswith('mut-'):
  assert p.returncode and ('FAILED' in p.stdout or 'assertion' in p.stderr or 'unwrap' in p.stderr), (p.stdout,p.stderr)
 else:
  assert p.returncode==0 and f'{2 if tag=="proof" else 3} passed; 0 failed' in p.stdout
 return v+'-'+t,metrics(bins[0])
jobs=[(v,t) for v in ('1.95.0','stable') for t in ('wasm32-wasip1','x86_64-unknown-linux-gnu')]
with ThreadPoolExecutor(4) as pool:result=dict(pool.map(run,jobs))
(s/(tag+'-fixture-sizes.json')).write_text(json.dumps(result,indent=2)+'\n')
