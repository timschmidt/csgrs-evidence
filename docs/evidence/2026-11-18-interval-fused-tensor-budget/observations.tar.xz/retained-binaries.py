from pathlib import Path
import sys,os,json
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');d=r/'crates/hyperinterval/conformance'
sys.path.insert(0,str(d));from wasi_libtest import build_tests,TARGET
from metrics import metrics
def build(v):
 env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/full-wasi-'+v,'CARGO_BUILD_JOBS':'4'}
 base=['cargo','+'+v,'test','--release','--locked','-p','hypersolve','--all-features'];data={}
 for t in (TARGET,'x86_64-unknown-linux-gnu'):
  cmd=[*base,'--target',t] if t==TARGET else base
  ev=dict(env)
  if t==TARGET:ev.pop('HYPERSOLVE_REPLAY_DRIVER',None)
  else:ev['HYPERSOLVE_REPLAY_DRIVER']=str(d/'wasi-solver.py')
  names=build_tests(cmd,['--test','coefficient_bit_budget'],ev)
  p=Path(names['coefficient_bit_budget']);q=metrics(p);q.update(free_slot_bytes=64*2**20-q['file'])
  assert q['file']<=16*2**20 and q['free_slot_bytes']>=16*2**20
  data[v+'-'+t]=q
 return data
with ThreadPoolExecutor(2) as pool:data={n:q for row in pool.map(build,('1.95.0','stable')) for n,q in row.items()}
(s/'retained-binaries.json').write_text(json.dumps(data,indent=2)+'\n')
