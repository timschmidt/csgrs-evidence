from pathlib import Path
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
tp=Path('crates/hypersolve/src/tensor_resultant.rs');wp=Path('crates/hypersolve/src/work_budget.rs')
t=(r/tp).read_text();a=t.index('    let mut target_index',t.index('fn embedded_flat_index('));b=t.index('\n}',a)
t=t[:a]+t[a:b].replace('(0..source_dimensions.len())','(1..source_dimensions.len())').replace('    Some(target_index)','    // The remaining quotient is the leading exponent of this validated index.\n    let leading_stride = target_strides.first().copied().unwrap_or(0);\n    target_index.checked_add(source_index.checked_mul(leading_stride)?)')+t[b:]
(s/'fused-axis.rs').write_text(t)
for d in ('tensor-src','src'):
 (s/d/wp).write_bytes((r/wp).read_bytes());(s/d/tp).write_text(t)
(s/'tensor-axis.py').write_text((s/'tensor-lazy.py').read_text().replace('lazy','axis'))
