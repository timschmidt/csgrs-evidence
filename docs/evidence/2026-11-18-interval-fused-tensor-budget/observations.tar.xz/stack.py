from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,json,shutil,sys
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');w=s/'stack-src'
def stage(tag):
 if tag in ('fixed','control'):
  rev='c9f1f9ac5' if tag=='fixed' else 'd2c8cf7df';subprocess.run(['tar','-xmC',w],input=subprocess.check_output(['git','archive',rev],cwd=r),check=True)
 else:shutil.copy(r/'crates/hypersolve/src/tensor_resultant.rs' if tag=='final' else s/f'fused-{tag}.rs',w/'crates/hypersolve/src/tensor_resultant.rs')
 if tag=='fixed':subprocess.run(['cargo','generate-lockfile','--offline','--manifest-path',s/'stack-client/Cargo.toml'],check=True)
 def run(job):
  v,t=job;env=os.environ|{'CARGO_TARGET_DIR':str(s/f'stack-target-{v}-{t}'),'CARGO_BUILD_JOBS':'3'}
  with (s/'logs'/f'stack-{tag}-{v}-{t}.build').open('w') as l:subprocess.run(['cargo','+'+v,'build','--locked','--release','--target',t,'--manifest-path',s/'stack-client/Cargo.toml'],env=env,stdout=l,stderr=l,check=True)
  p=Path(env['CARGO_TARGET_DIR'])/t/'release/tensor-stack-client'
  cmd=[p] if not t.startswith('wasm') else ['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',s/'stack-wasi.mjs',p.with_suffix('.wasm')]
  if t=='wasm32-wasip1':shutil.copy(p.with_suffix('.wasm'),s/'images'/f'stack-{tag}-{v}.wasm')
  rows=[]
  for n in (2,64):
   for mode in range(4):
    for state in ('true','false'):
     for pattern in (85,170):
      args=[tag if tag in ('fixed','control') else 'final',str(n),str(mode),state,str(pattern)]
      run=subprocess.run([*cmd,*args],text=True,capture_output=True)
      if run.returncode:raise ValueError([v,t,args,run.stderr,run.stdout])
      row=run.stdout.strip().split();assert len(row)==12 and row[0]=='OBS',row
      rows.append(dict(zip(('n','mode','warm','pattern','stack','alloc','free','realloc','traffic','peak','live'),[int(x) if i!=2 else x for i,x in enumerate(row[1:])])))
  (s/f'stack-{tag}-{v}-{t}.json').write_text(json.dumps(rows,indent=1)+'\n')
 jobs=[(v,t) for v in ['1.95.0','stable'] for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']]
 if os.environ.get('STACK_PILOT'):jobs=[('stable','wasm32-wasip1')]
 with ThreadPoolExecutor(4) as pool:list(pool.map(run,jobs))
for tag in sys.argv[1:] or ['fixed','control','final']:stage(tag)
