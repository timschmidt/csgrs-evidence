from pathlib import Path
import subprocess,sys,json
s=Path(__file__).parent;r=Path('/mnt/development/csgrs/crates/hypersolve');p=r/'scripts/coverage.sh';stage=sys.argv[1]
t=p.read_text();a=t.index('threshold="${minimum_production_line_coverage}"')
a=t.index("'",a)+1;b=t.index("\n    ' \""+chr(36)+"{text_report}\"",a)
program=t[a:b];obs={};source=r/'src/tensor_resultant.rs'
for name,case,threshold in [('empty','',85),('empty_source',str(source)+':\n',85),('exact_threshold',str(source)+':\n1|1|covered\n2|0|missed\n',50),('below_threshold',str(source)+':\n1|1|covered\n2|0|missed\n',51)]:
 run=subprocess.run(['awk','-F|','-v','prefix='+str(r)+'/','-v','threshold='+str(threshold),program],input=case,text=True,capture_output=True)
 obs[name]={'status':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
 expected=0 if name=='exact_threshold' or stage=='old' and name in ('empty','empty_source') else 2
 assert run.returncode==expected,(stage,name,run.returncode,expected,run.stderr)
(s/f'coverage-denominator-{stage}.json').write_text(json.dumps(obs,indent=2)+'\n')
