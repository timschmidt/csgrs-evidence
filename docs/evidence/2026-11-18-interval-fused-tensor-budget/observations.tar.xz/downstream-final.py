import json,os,shutil,subprocess,sys,csv
from pathlib import Path
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');w=s/'downstream-src';w.mkdir(exist_ok=True)
assert w.exists()
env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/downstream-target','CARGO_BUILD_JOBS':'7'}
sys.path.insert(0,'/dev/shm/interval-solver-library');from metrics import metrics
measures={};rows={}
images=s/'images';images.mkdir(exist_ok=True)
saved=s/'logs'/'control-successive.tsv'
lines=saved.read_text().splitlines();assert lines[-1]=='# completed'
rows['control']=[{k:v for k,v in x.items() if k not in ('step_ns','validation_ns','drop_ns')} for x in csv.DictReader((l for l in lines if not l.startswith('#')),delimiter='\t')]
for stage in ['always']:
 if stage=='always':shutil.copy(r/'crates/hypersolve/src/tensor_resultant.rs',w/'crates/hypersolve/src/tensor_resultant.rs')
 for name,args in [('successive_operations',['build','-p','csgrs','--bench','successive_operations','--no-default-features','--features','curve,stl-io,obj-io']),('hypercurve_open_path_compositions',['test','--no-run','-p','hypercurve','--test','hypercurve_open_path_compositions','--features','svg'])]:
  with (s/'logs'/f'{stage}-{name}.build').open('w') as log:out=subprocess.check_output(['cargo','+1.95.0',*args,'--locked','--release','--message-format=json-render-diagnostics'],stderr=log,cwd=w,env=env,text=True)
  exe=next(Path(x['executable']) for x in map(json.loads,out.splitlines()) if x.get('executable') and x['target']['name']==name)
  measures[stage+'-'+name]=metrics(exe)
  p=images/(name if name=='successive_operations' else 'always-'+name);shutil.copy(exe,p)
  if name=='successive_operations':
   out=images/'rows.tsv';env['SUCCESSIVE_OPERATIONS_RAW']=str(out)
   with (s/'logs'/f'{stage}-successive.run').open('w') as log:subprocess.run(['taskset','-c','18',str(p),'((A-B)-C)+D feedback'],stdout=log,stderr=log,env=env,check=True)
   saved=s/'logs'/f'{stage}-successive.tsv';out.replace(saved);lines=saved.read_text().splitlines();assert lines[-1]=='# completed'
   vals=list(csv.DictReader((l for l in lines if not l.startswith('#')),delimiter='\t'))
   assert len(vals)==6 and all(x['outcome']=='certified' and x['manifold']=='yes' for x in vals)
   rows[stage]=[{k:v for k,v in x.items() if k not in ('step_ns','validation_ns','drop_ns')} for x in vals]
  else:
   for test in ['coefficient_bit_limit_stops_the_stalled_filleted_hyperbola_bevel_stroke','generated_nurbs_rational_trims_replay_before_exact_inverse_location']:
    path=s/'logs'/f'{stage}-{test}.run'
    with path.open('w') as log:subprocess.run([p,'--exact',test,'--nocapture'],check=True,stdout=log,stderr=log,cwd=w,env=env)
    assert '1 passed; 0 failed;' in path.read_text()
assert rows['control']==rows['always']
(s/'downstream-always.json').write_text(json.dumps(measures,indent=2)+'\n')
