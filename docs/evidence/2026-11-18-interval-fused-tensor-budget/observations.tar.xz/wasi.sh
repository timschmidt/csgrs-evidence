set -eu
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-budget-receipt
v=$1
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" CARGO_BUILD_JOBS=6 CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/full-wasi-$v" PYTHONDONTWRITEBYTECODE=1
python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$v" --output "$s/retained-$v"
