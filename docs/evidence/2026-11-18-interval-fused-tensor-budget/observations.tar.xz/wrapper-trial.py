from pathlib import Path
import subprocess
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');tp='crates/hypersolve/src/tensor_resultant.rs'
base=subprocess.check_output(['git','-C',r,'show','9202bfaec:'+tp]).decode()
p=(s/'fused-explicit.rs').read_text()
docs=p[p.index("    /// Checks this tensor's"):p.index('    pub fn within_coefficient_bit_limit')]
i=base.index('\n#[cfg(test)]\nmod tests')
wrapper='\nimpl DenseTensorPolynomial {\n'+docs+'    #[inline]\n    pub fn check_coefficient_bit_limit(self) -> Option<Self> {\n        self.within_coefficient_bit_limit()\n    }\n}\n'
text=base[:i]+wrapper+base[i:]
(s/'fused-wrapper.rs').write_text(text)
(s/'src'/tp).write_text(text)
