set -eu
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-budget-receipt
v=$1
export CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/matrix-x86_64-unknown-linux-gnu-$v" CARGO_BUILD_JOBS=5 CARGO_PROFILE_DEV_DEBUG=0
cargo +"$v" fmt --all -- --check
cargo +"$v" clippy --locked -p hypersolve --all-targets --all-features -- -D warnings
cargo +"$v" clippy --locked -p hypersolve --all-targets --no-default-features -- -D warnings
cargo +"$v" clippy --locked -p hypersolve --target wasm32-wasip1 --all-features --tests -- -D warnings
RUSTDOCFLAGS='-D warnings' cargo +"$v" doc --locked -p hypersolve --all-features --no-deps
cargo +"$v" test --locked -p hypersolve --release --all-features --lib --tests --target x86_64-unknown-linux-gnu
cargo +"$v" test --locked -p hypersolve --no-default-features --test coefficient_bit_budget
cargo +"$v" test --locked -p hypersolve --doc --all-features
echo PASS
