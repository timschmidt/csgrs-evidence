set -eu
s=/dev/shm/interval-budget-receipt
. /dev/shm/interval-horner-readmission/env
export HYPERSOLVE_SKIP_BENCHMARK_REPORTS=1
for cpu in 7 16; do
  for stage in preceding filter filter preceding; do
    k="$s/filter-criterion-$cpu-$stage"
    if test -e "$k"; then k="$k-repeat"; fi
    CRITERION_HOME="$k" taskset -c "$cpu" setarch x86_64 -R "$s/images/$stage-certification" --bench '^resultant_tensor_polynomial_univariate_constraint$' --sample-size 50 --warm-up-time 1 --measurement-time 3 --noplot >> "$s/logs/filter-benchmark-$cpu-$stage.log" 2>&1
    test -n "$(find "$k" -name sample.json -print -quit)"
  done
done
