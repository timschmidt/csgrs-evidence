from pathlib import Path
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
tp=Path('crates/hypersolve/src/tensor_resultant.rs');wp=Path('crates/hypersolve/src/work_budget.rs')
w=(r/wp).read_text();k=w.index('/// The innermost scope')
w=w[:k]+'''/// Whether a coefficient observation can exhaust a scope or report an existing failure.
pub(crate) fn needs_coefficient_observation() -> bool {
    is_active() && FRAMES.with_borrow(|frames| {
        frames.last().is_some_and(|frame| frame.exhausted.is_some())
            || frames.iter().any(|frame| frame.max_coefficient_bits.is_some() || frame.cancellation.is_some())
    })
}

'''+w[k:]
t=(r/tp).read_text();a=t.index('fn within_coefficient_bit_limit(');t=t[:a]+t[a:].replace('if !crate::work_budget::is_active()','if !crate::work_budget::needs_coefficient_observation()',1)
(s/'scope-work.rs').write_text(w);(s/'fused-scope.rs').write_text(t)
# Only the separate public-client tree is idle at this point.
(s/'tensor-src'/wp).write_text(w);(s/'tensor-src'/tp).write_text(t)
(s/'tensor-scope.py').write_text((s/'tensor-lazy.py').read_text().replace('lazy','scope'))
