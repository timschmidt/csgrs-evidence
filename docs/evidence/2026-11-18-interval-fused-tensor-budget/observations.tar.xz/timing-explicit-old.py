from pathlib import Path
import os,subprocess,shutil,statistics,resource,json,time
s=Path(__file__).resolve().parent
# Leave two physical cores available for the paired checks, restricting only our
# own shell process groups for the builds and tests in this specific scratch directory.
reserve={5,14,25,34};groups=set();this=os.getpgrp();adjusted=0
for d in Path('/proc').glob('[0-9]*'):
 try:
  pid=int(d.name);cl=(d/'cmdline').read_bytes().split(b'\0')
  if (pid==os.getpgid(pid) and pid!=this and len(cl)>2 and cl[0] in (b'/bin/bash',b'bash') and b'/dev/shm/interval-budget-receipt' in cl[2]):
   groups.add(pid)
 except (OSError,IndexError):pass
for d in Path('/proc').glob('[0-9]*'):
 try:
  if os.getpgid(int(d.name)) not in groups:continue
  for th in (d/'task').iterdir():
   tid=int(th.name);mask=os.sched_getaffinity(tid)
   if mask&reserve and mask-reserve:os.sched_setaffinity(tid,mask-reserve);adjusted+=1
 except OSError:pass
print('build/test process groups',len(groups),'threads restricted',adjusted,flush=True)
rows=[];summary={}
dest=s/'timed-explicit-old';dest.mkdir(exist_ok=True);p=dest/'tensor-budget-client'
def usage():
 a=resource.getrusage(resource.RUSAGE_CHILDREN);return a.ru_utime+a.ru_stime
for v in ['1.95.0','stable']:
 for mode in ['plain','work','bits']:
  entries=[]
  for cpu in [5,14]:
   for rep in range(16):
    pair={}
    for stage in (['control','explicit-old'] if rep%2==0 else ['explicit-old','control']):
     shutil.copy(s/'images'/f'consumer-{stage}-{v}',p)
     cmd=['taskset','-c',str(cpu),'setarch',os.uname().machine,'-R',p,'time',mode]
     # Each row contains two whole-process samples. Both validate and drop every output.
     wall=[];cpu_times=[]
     for _ in range(2):
      before=usage();out=int(subprocess.check_output(cmd,text=True));cpu_times.append(usage()-before);wall.append(out)
     rows.append(dict(compiler=v,mode=mode,cpu=cpu,rep=rep,stage=stage,ns=wall,process_cpu_seconds=cpu_times))
     pair[stage]=sum(wall)
    entries.append(pair['explicit-old']/pair['control'])
  summary[v+'-'+mode]={'median':statistics.median(entries),'cpu5':statistics.median(entries[:16]),'cpu14':statistics.median(entries[16:]),'pairs':entries}
  print(v,mode,summary[v+'-'+mode]['cpu5'],summary[v+'-'+mode]['cpu14'],flush=True)
(s/'timing-explicit-old.json').write_text(json.dumps({'rows':rows,'summary':summary},indent=2)+'\n')
