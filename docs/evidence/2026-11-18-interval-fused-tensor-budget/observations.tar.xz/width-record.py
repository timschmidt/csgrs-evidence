from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
def record(tag,items,msg):
 record='docs/evidence/2026-11-18-interval-'+tag
 files={str(p.relative_to(s)):p.read_bytes() for p in items}
 sha={k:h(v) for k,v in sorted(files.items())};tmp=s/('archive-'+tag);tmp.mkdir(exist_ok=True)
 with tarfile.open(tmp/'observations.tar.xz','w:xz') as tar:
  for k,b in sorted(files.items()):
   m=tarfile.TarInfo(k);m.size=len(b);tar.addfile(m,io.BytesIO(b))
 with tarfile.open(tmp/'observations.tar.xz','r|xz') as tar:assert {m.name:h(tar.extractfile(m).read()) for m in tar}==sha
 (tmp/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(sha,indent=1).encode()))
 size=sum(p.stat().st_size for p in tmp.iterdir())
 assert shutil.disk_usage(e).free-(e/'.git/index').stat().st_size-3*size-1048576>20*1024**3
 assert not git(e,'status','--porcelain') and not (e/record).exists()
 shutil.copytree(tmp,e/record);git(e,'add','--sparse','--',record)
 assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
 git(e,'-c','gc.auto=0','commit','-m',msg);head=git(e,'rev-parse','HEAD').decode().strip()
 for p in tmp.iterdir():assert git(e,'show',head+':'+record+'/'+p.name)==p.read_bytes()
 spec=importlib.util.spec_from_file_location('registry',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
 row=m.manifest(str(e),head)[1];idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
 with idx.open('a') as f:f.write(row+'\n')
 return dict(commit=head,row=row,members=len(files),record=record)
if __name__=='__main__':
 tag='coefficient-budget-width';items=set()
 for name in ['review.json','review.py','measure.py','metrics.py','profile.py','candidate.py','shared.py','active.py','outline.py','state.py','client-check.sh','wide.rs','shared.rs','active.rs','outlined.rs','state.rs','before-native.log','before-guest.log','scope.md','width-reproduce.md','width-record.py','width-accounts.json','proof-revision','predecessor','nested-fixture.rs','proof-fixture-sizes.json','accept.py']:
  items.add(s/name)
 for name in ['wide','shared','outlined','active','state','control']:
  items.update(s.glob(name+'-*.json'))
  for ext in ['*.build-log','*.lifetime-build','*.hypersolve.run','*.trivariate_arithmetic.run','*.build','*.run']:
   items.update((s/'logs').glob(name+'-'+ext))
 for name in ['proof','mut-innermost','mut-narrow']:
  items.update((s/'logs').glob(name+'-*-fixture.*'))
 items.update(p for p in (s/'client').rglob('*') if p.is_file())
 assert not any('target' in p.relative_to(s/'client').parts for p in items if p.is_relative_to(s/'client'))
 for v in ('1.95.0','stable'):
  for t in ('x86_64-unknown-linux-gnu','wasm32-wasip1'):
   assert '2 passed; 0 failed;' in (s/'logs'/f'proof-{v}-{t}-fixture.log').read_text()
   for stage in ['wide','shared','outlined','active','state']:
    assert '81 ordered comparisons' in (s/'logs'/f'{stage}-{v}-{t}-public.run').read_text()
 rev=(s/'proof-revision').read_text().strip()
 assert git(r,'show',rev+':crates/hypersolve/tests/coefficient_bit_budget.rs')==(s/'nested-fixture.rs').read_bytes()
 assert all(any(t['incremental_size_failures'] for t in q.values()) for q in json.loads((s/'review.json').read_text()).values())
 print(json.dumps(record(tag,items,'Archive full-width work budget witnesses and five linked repair trials')))
