from pathlib import Path
import os,subprocess,sys
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');w=s/'mutant-src'
tp='crates/hypersolve/src/tensor_resultant.rs';wp='crates/hypersolve/src/work_budget.rs';fixture='crates/hypersolve/tests/coefficient_bit_budget.rs'
t=subprocess.check_output(['git','-C',r,'show','9202bfaec:'+tp]).decode()
k='value.numerator().bits() + value.denominator().bits()'
assert t.count(k)==1
(w/tp).write_text(t.replace(k,'value.numerator().bits()'))
(w/wp).write_bytes(subprocess.check_output(['git','-C',r,'show','9202bfaec:'+wp]))
(w/fixture).write_bytes((s/'proof-src'/fixture).read_bytes())
env=os.environ|{'BUDGET_TEST_TARGET':'mut-target'}
subprocess.run([sys.executable,s/'accept.py','mut-denominator',w],env=env,check=True)
