import csv,json,statistics,subprocess,os,sys
from pathlib import Path
s=Path(__file__).resolve().parent;results={};raw=[]
for comp in ['1.95.0','stable']:
 for mode in ['plain','work','bits']:
  block=[]
  for cpu in [3,17]:
   for rep in range(8):
    values={}
    for label in (['control','fused'] if rep%2==0 else ['fused','control']):
     p=s/'images'/f'consumer-{label}-{comp}'
     value=int(subprocess.check_output(['taskset','-c',str(cpu),p,'time',mode],text=True))
     raw.append([comp,mode,cpu,rep,label,value]);values[label]=value
    block.append(values['fused']/values['control'])
  results[comp+'-'+mode]=dict(ratios=block,median=statistics.median(block))
(s/'timing.json').write_text(json.dumps({'results':results,'raw':raw},indent=2)+'\n')
for k,v in results.items():print(k,v['median'])
