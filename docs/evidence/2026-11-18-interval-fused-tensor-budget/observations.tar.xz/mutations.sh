set -eu
s=/dev/shm/interval-budget-receipt
. /dev/shm/interval-horner-readmission/env
export BUDGET_TEST_TARGET=mut-target
mkdir -p "$s/mutant-src"
if ! test -f "$s/mutant-src/Cargo.toml"; then git archive d2c8cf7df | tar -xmC "$s/mutant-src"; fi
testfile=crates/hypersolve/tests/coefficient_bit_budget.rs
cp "$testfile" "$s/mutant-src/$testfile"
for mut in narrow innermost unguarded partial; do
  cp crates/hypersolve/src/tensor_resultant.rs "$s/mutant-src/crates/hypersolve/src/tensor_resultant.rs"
  git show d2c8cf7df:crates/hypersolve/src/work_budget.rs > "$s/mutant-src/crates/hypersolve/src/work_budget.rs"
  python3 - "$s" "$mut" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]);p=s/'mutant-src/crates/hypersolve/src/work_budget.rs';text=p.read_text()
mut=sys.argv[2]
if mut in ('narrow','innermost'):
 a,b=('is_some_and(|limit| bits > limit)','is_some_and(|limit| bits as u32 > limit as u32)') if mut=='narrow' else ('.position(|frame| frame.max_coefficient_bits','.rposition(|frame| frame.max_coefficient_bits')
 assert text.count(a)==1;p.write_text(text.replace(a,b))
else:
 p=s/'mutant-src/crates/hypersolve/src/tensor_resultant.rs';text=p.read_text();a=text.index('    pub fn sum_products(');b=text.index('    /// Embeds a trivariate',a);body=text[a:b]
 if mut=='unguarded':
  assert body.count('result.within_coefficient_bit_limit()')==1
  body=body.replace('result.within_coefficient_bit_limit()','Some(result)')
 else:
  a1=body.index('        }\n        result.within_coefficient_bit_limit()')
  body=body[:a1]+'            result = result.within_coefficient_bit_limit()?;\n'+body[a1:]
 p.write_text(text[:a]+body+text[b:])
PY
  python3 "$s/accept.py" "mut-$mut" "$s/mutant-src"
done
