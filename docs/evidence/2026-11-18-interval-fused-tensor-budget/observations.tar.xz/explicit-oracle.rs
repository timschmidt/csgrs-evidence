use hyperreal::Real;
use hypersolve::{DenseTensorPolynomial as Tensor, work_budget::*};

fn coordinates(dims: &[usize]) -> Vec<Vec<usize>> {
    let mut rows = vec![Vec::new()];
    for &n in dims {
        rows = rows.into_iter().flat_map(|prefix| (0..n).map(move |i| {
            let mut exponent = prefix.clone();
            exponent.push(i);
            exponent
        })).collect();
    }
    rows
}
fn main() {
    let mut cases = 0;
    for rank in 0..=4 {
        for mask in 0..(1 << rank) {
            let a: Vec<usize> = (0..rank).map(|i| 1+(mask>>i & 1)).collect();
            let b: Vec<usize> = a.iter().map(|v| 4-v).collect();
            let dims: Vec<_> = a.iter().zip(&b).map(|(a,b)| a+b-1).collect();
            let pa=coordinates(&a);
            let pb=coordinates(&b);
            let av:Vec<_>=(0..pa.len()).map(|i|i as i64 % 7 - 3).collect();
            let bv:Vec<_>=(0..pb.len()).map(|i|(i as i64*3)%11-5).collect();
            let ta=Tensor::try_new(a,av.iter().copied().map(Real::from).collect()).unwrap();
            let tb=Tensor::try_new(b,bv.iter().copied().map(Real::from).collect()).unwrap();
            let mut sums=std::collections::BTreeMap::new();
            for (xa,ca) in pa.iter().zip(&av) {
                for (xb,cb) in pb.iter().zip(&bv) {
                    let idx:Vec<_>=xa.iter().zip(xb).map(|(a,b)|a+b).collect();
                    *sums.entry(idx).or_insert(0i64)+=ca*cb;
                }
            }
            for negative in [false,true] {
                let expected=Tensor::try_new(dims.clone(),coordinates(&dims).iter().map(|e|Real::from(if negative{-sums[e]}else{sums[e]})).collect()).unwrap();
                let terms=[(&ta,&tb,negative)];
                let max=sums.values().map(|x|u64::from(65-x.unsigned_abs().leading_zeros())).max().unwrap();
                let denied=with_coefficient_bit_limit(max-1,||Tensor::sum_products(&terms).and_then(Tensor::within_coefficient_bit_limit));
                assert_eq!(denied.result.unwrap_err().requested as u64,max);
                let retry=with_coefficient_bit_limit(max,||Tensor::sum_products(&terms).and_then(Tensor::within_coefficient_bit_limit));
                assert_eq!(retry.result.unwrap().unwrap(),expected);
                cases+=1;
            }
            let cancel=with_coefficient_bit_limit(1,||Tensor::sum_products(&[(&ta,&tb,true),(&tb,&ta,false)]).and_then(Tensor::within_coefficient_bit_limit));
            assert_eq!(cancel.result.unwrap(),Tensor::zero(dims.clone()));
        }
    }
    let t=Tensor::try_new(vec![1],vec![Real::from(2)]).unwrap();
    let op=||Tensor::sum_products(&[(&t,&t,false)]).and_then(Tensor::within_coefficient_bit_limit);
    let token=CancellationToken::new();
    let cancelled=with_cancellable_budget(WorkBudget::UNLIMITED,&token,||{
        token.cancel();
        let inner=with_budget(WorkBudget::UNLIMITED,||assert!(op().is_none()));
        assert_eq!(inner.result.unwrap_err().kind,WorkKind::Cancellation);
    });
    assert_eq!(cancelled.result.unwrap_err().kind,WorkKind::Cancellation);
    let exhausted=with_coefficient_bit_limit(0,||{
        let failure=observe_coefficient_bits(1).unwrap_err();
        assert_eq!(with_budget(WorkBudget::UNLIMITED,||assert!(op().is_none())).result,Err(failure));
    });
    assert_eq!(exhausted.result.unwrap_err().requested,1);
    assert_eq!(with_budget(WorkBudget::UNLIMITED,op).result.unwrap().unwrap().coefficients(),&[Real::from(4)]);
    println!("{cases} exact signed mixed-rank products, 31 zero sums, sticky and asynchronous-token scope checks passed");
}
