set -eu
s=/dev/shm/interval-budget-receipt
v=$1
. /dev/shm/interval-horner-readmission/env
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" CARGO_BUILD_JOBS=6 CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/full-wasi-$v" PYTHONDONTWRITEBYTECODE=1
if test "$2" = warm; then
  python3 "$s/warm.py" "$v"
  systemd-run --user --scope -q -p MemoryMax=1G -p MemorySwapMax=0 -- bash "$s/limited.sh" "$v" scoped
else
  group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
  printf 'memory.max '; cat "$group/memory.max"
  printf 'memory.swap.max '; cat "$group/memory.swap.max"
  date -u +%s.%N
  python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$v" --output "$s/final-wasi-$v"
  date -u +%s.%N
  printf 'memory.peak '; cat "$group/memory.peak"
  cat "$group/memory.events"
fi
