import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { WASI } from 'node:wasi';
const [binary,...args]=process.argv.slice(2), wasi=new WASI({version:'preview1',args:[binary,...args],env:{},returnOnExit:true});
let instance,start;
const mark=(on,pattern)=>{
 const api=instance.exports, sp=api.__stack_pointer.value, base=api.__stack_low.value;
 if(on){start=sp;api.budget_min.value=sp;return 0;}
 assert.equal(sp,start);const minimum=api.budget_min.value;
 assert(minimum>base+262144 && minimum<start);
 console.log('GUEST',start,base,minimum,minimum-base);
 return start-minimum;
};
({instance}=await WebAssembly.instantiate(await readFile(binary),{wasi_snapshot_preview1:wasi.wasiImport,scope:{mark}}));
process.exitCode=wasi.start(instance);
