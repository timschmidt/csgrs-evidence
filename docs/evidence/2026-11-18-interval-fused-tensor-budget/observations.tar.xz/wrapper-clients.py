from pathlib import Path
import subprocess,sys
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
tp=Path('crates/hypersolve/src/tensor_resultant.rs')
src=s/'tensor-client/src/main.rs';backup=s/'tensor-client-original.rs'
if not backup.exists():backup.write_bytes(src.read_bytes())
script=(s/'tensor-lazy.py').read_text()
for stage in ['wrapper-old','wrapper']:
 txt=backup.read_text()
 if stage=='manual':
  t=subprocess.check_output(['git','-C',r,'show','9202bfaec:'+str(tp)]);(s/'tensor-src'/tp).write_bytes(t)
  helper='''fn check(t: Tensor) -> Option<Tensor> {
    use hypersolve::work_budget::{is_active, observe_coefficient_bits};
    if is_active() {
        let bits=t.coefficients().iter().filter_map(Real::exact_rational_ref)
            .map(|q|q.numerator().bits()+q.denominator().bits()).max().unwrap_or(0);
        observe_coefficient_bits(bits).ok()?;
    }
    Some(t)
}
'''
  txt=txt.replace('fn main(){',helper+'\nfn main(){')
 else:(s/'tensor-src'/tp).write_bytes((s/'fused-wrapper.rs').read_bytes())
 if stage in ['manual','wrapper']:
  pre='check' if stage=='manual' else 'Tensor::check_coefficient_bit_limit'
  for p in ['Tensor::sum_products(black_box(&terms))','Tensor::sum_products(&terms)']:
   txt=txt.replace(p,p+'.and_then('+pre+')')
 src.write_text(txt);(s/f'tensor-client-{stage}.rs').write_text(txt)
 code=script.replace('lazy',stage).replace("'--release','--locked'","'--release','--bin','tensor-budget-client','--locked'")
 if stage=='wrapper-old':code=code.replace("[*command,'fused']","[*command,'control']")
 fp=s/f'run-client-{stage}.py';fp.write_text(code)
 subprocess.run([sys.executable,fp],check=True)
src.write_bytes(backup.read_bytes())
