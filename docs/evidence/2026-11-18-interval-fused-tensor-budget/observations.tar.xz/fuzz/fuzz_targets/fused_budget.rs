#![no_main]
use hyperreal::Real;
use hypersolve::{DenseTensorPolynomial as Tensor,work_budget::{WorkKind,with_coefficient_bit_limit,exhaustion}};
use libfuzzer_sys::fuzz_target;
fuzz_target!(|input:&[u8]|{
 if input.len()<5{return}
 let n=(input[0]as usize%4)+1;let m=(input[1]as usize%4)+1;
 let word=|i:usize|i64::from(input[(i+3)%input.len()] as i8);
 let lhs:Vec<_>=(0..n).map(word).collect();
 let rhs:Vec<_>=(n..n+m).map(word).collect();
 let signs=input[2]&3;
 let left=Tensor::try_new(vec![n],lhs.iter().copied().map(Real::from).collect()).unwrap();
 let right=Tensor::try_new(vec![m],rhs.iter().copied().map(Real::from).collect()).unwrap();
 let run=||Tensor::sum_products(&[(&left,&right,signs&1!=0),(&right,&left,signs&2!=0)]);
 let factor=match signs{0=>2,3=>-2,_=>0};
 let mut expected=vec![0i64;n+m-1];
 for(i,x)in lhs.iter().enumerate(){for(j,y)in rhs.iter().enumerate(){expected[i+j]+=factor*x*y;}}
 let bits=expected.iter().map(|v|65-u64::from(v.unsigned_abs().leading_zeros())).max().unwrap();
 let a=with_coefficient_bit_limit(bits-1,run).result.unwrap_err();
 assert_eq!((a.kind,a.limit as u64,a.requested as u64),(WorkKind::CoefficientGrowth,bits-1,bits));
 assert!(exhaustion().is_none());
 let r=with_coefficient_bit_limit(bits,run).result.unwrap().unwrap();
 assert_eq!(r.dimensions(), &[n+m-1]);assert_eq!(r.coefficients(),expected.into_iter().map(Real::from).collect::<Vec<_>>());
});
