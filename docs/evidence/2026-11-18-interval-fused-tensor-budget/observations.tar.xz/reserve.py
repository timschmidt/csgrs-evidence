from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import re,json,subprocess,sys
s=Path(__file__).resolve().parent;n='/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node'
def run(job):
 tag,v=job;name=f'stack-{tag}-{v}';p=s/'images'/(name+'.wasm')
 wat=subprocess.check_output(['wasm-dis',p],text=True)
 pattern=r'(?m)^(\s*)\(global\.set \$__stack_pointer(?=\s)'
 assert len(re.findall(pattern,wat))>0 and 'budget_min' not in wat
 text=re.sub(pattern,r'\1(call $budget_stack_set',wat.rstrip())
 assert re.search(pattern,text) is None and text.endswith(')')
 text=text[:-1]+'''
 (global $budget_min (mut i32) (i32.const 1048576))
 (export "budget_min" (global $budget_min))
 (func $budget_stack_set (param $sp i32)
  (global.set $__stack_pointer (local.get $sp))
  (if (i32.lt_u (local.get $sp) (global.get $budget_min))
    (then (global.set $budget_min (local.get $sp)))))
)'''
 w=s/'images'/(name+'.wat');instrument=s/'images'/(name+'-tracked.wasm');w.write_text(text)
 subprocess.run(['wasm-as',w,'--all-features','-o',instrument],check=True)
 result=[]
 for size in ('2','64'):
  for mode in ('0','1','2','3'):
   for warm in ('false','true'):
    out=subprocess.check_output([n,'--no-warnings',s/'reserve.mjs',instrument,'control' if tag in ('fixed','control') else 'final',size,mode,warm,'85'],text=True).splitlines()
    assert len(out)==2 and out[0].startswith('GUEST ') and out[1].startswith('OBS '),out
    entry,base,minimum,headroom=map(int,out[0].split()[1:]);peak=int(out[1].split()[5]);assert peak==entry-minimum
    result.append(dict(size=int(size),mode=int(mode),warm=warm,reserved=peak,entry=entry,base=base,headroom=headroom))
 (s/f'reservations-{tag}-{v}.json').write_text(json.dumps(result,indent=1)+'\n')
with ThreadPoolExecutor(4) as pool:list(pool.map(run,[(t,v) for t in sys.argv[1:] for v in ('stable','1.95.0')]))
