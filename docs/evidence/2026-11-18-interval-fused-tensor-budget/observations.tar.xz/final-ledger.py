from pathlib import Path
import json,sys,re
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
stage=sys.argv[1]
def read(p):return json.loads((s/p).read_text())
def emit(name,v):(s/f'final-ledger-{name}.json').write_text(json.dumps(v,indent=2)+'\n')
prior=read('width-accounts.json');ref='docs/evidence/2026-11-18-interval-fused-tensor-budget'
rev=(s/(stage+'-revision')).read_text().strip()
full=read(stage+'-fixture-sizes.json');prev=prior['targets']
out={}
for t,v in sorted(full.items()):
 b=prev[t];free=prior['capacity_bytes']-v['file']
 assert free>=prior['required_slot_headroom_bytes'] and v['file']<=prior['file_ceiling']
 out[t]=dict(file_bytes=v['file'],executable_code_bytes=v['code'],function_bytes=v['functions'],previous_file_bytes=b['file'],added_test_file_charge=max(0,v['file']-b['file']),cumulative_file_charge=b['file']+max(0,v['file']-b['file']),free_slot_bytes=free)
size=dict(source=rev,evidence=ref,workload='Expanded public coefficient-budget integration suite with a produced rational denominator, nested denial, recovery and exact reuse. The preceding width suite remains in full.',capacity_bytes=prior['capacity_bytes'],file_ceiling=prior['file_ceiling'],required_slot_headroom_bytes=prior['required_slot_headroom_bytes'],charge_rule='Additional mathematical workload in the same test executable. Keep the entire earlier charge and add positive growth. The archived automatic variants do not consume production allowance.',targets=out)
if stage=='wrapper':
 ordinary=read('tensor-review.json')['wrapper'];legacy=read('wrapper-review.json')
 comparable={}
 for t,art in ordinary.items():
  assert all(q['incremental_room']>=0 and q['cumulative_room']>=0 for row in art.values() for q in row.values() if isinstance(q,dict))
  comparable[t]={'accounted_images':len(art),'maximum_file_increment':max(q['file']['increment'] for q in art.values()),'minimum_slot_headroom':min(q['free_slot_bytes'] for q in art.values())}
 assert all(not q['cumulative_exceeded'] and not q['incremental_exceeded'] for vals in legacy.values() for q in vals.values())
 size.update(qualified_api='Explicit materialized-tensor observer. Existing operations require their own automatic instrumentation.',ordinary_release_accounts=comparable,existing_feature_matched_artifacts=len(legacy),charges='All nonnegative increments with the original denominators, fixed baselines and prior charges are in tensor-review.json and wrapper-review.json in the evidence archive.')
emit('size',size)
if stage!='wrapper':sys.exit()
memory={}
for tc in ('1.95.0','stable'):
 for arch in ('wasm32-wasip1','x86_64-unknown-linux-gnu'):
  tag=tc+'-'+arch
  b,v=[read(f'stack-{name}-{tag}.json') for name in ('manual','wrapper')]
  fields=('stack','alloc','realloc','free','traffic','peak','live')
  assert all([(x['n'],x['mode'],x['warm'],x['pattern']) for x in obs]==[(x['n'],x['mode'],x['warm'],x['pattern']) for x in b] for obs in [v])
  metrics={}
  for f in fields:
   inc=max(max(0,y[f]-x[f]) for x,y in zip(b,v));metrics[f]={'peak_observation':max(x[f] for x in v),'greatest_positive_increment':inc}
   for x,y in zip(b,v):
    cap=min(32,x[f]//100) if f=='stack' else min(128,x[f]//20) if f in ('peak','live') else 0
    assert y[f]-x[f]<=cap,(tag,f,x,y,cap)
  memory[tag]=metrics
  if 'wasm' in arch:
   base,cur=[read(f'reservations-{st}-{tc}.json') for st in ['manual','wrapper']]
   for x,y in zip(base,cur):assert y['reserved']-x['reserved']<=min(32,x['reserved']//100) and y['headroom']>=262144
   metrics.update(guest_minimum_headroom=min(q['headroom'] for q in cur),guest_maximum_reserved=max(q['reserved'] for q in cur))
emit('memory',dict(source=rev,evidence=ref,workload='Explicit check against an independently coded public observation of the identical coefficients. Both include materialization, sticky failure, retry and drop. Cold and warm 2- and 64-coefficient products on one thread.',caps='Per workload 32 B and 1% incremental, 64 B and 2% cumulative touched or reserved stack. Temporary and retained requested heap 128 B and 5% incremental, 256 B and 10% cumulative. Allocation counts and traffic have zero allowance. Reserves 512 KiB on the 2 MiB native thread and 256 KiB on the 1 MiB guest stack.',targets=memory))
