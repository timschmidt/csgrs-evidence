from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,shutil,subprocess,sys
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs')
sys.path.insert(0,'/dev/shm/interval-solver-library');from metrics import metrics
def run(job):
 stage,v,t=job;env=os.environ|{'CARGO_TARGET_DIR':str(s/f'tensor-target-{v}-{t}'),'CARGO_BUILD_JOBS':'4'}
 stem=s/'logs'/f'consumer-{stage}-{v}-{t}';cmd=['cargo','+'+v,'build','--release','--locked','--manifest-path',s/'tensor-client/Cargo.toml','--target',t]
 with Path(str(stem)+'.build').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=log,check=True)
 p=Path(env['CARGO_TARGET_DIR'])/t/'release/tensor-budget-client'
 if t=='wasm32-wasip1':
  p=p.with_suffix('.wasm');command=['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs',p]
 else:
  command=[p];shutil.copy(p,s/'images'/f'consumer-{stage}-{v}')
 with Path(str(stem)+'.run').open('w') as log:subprocess.run([*command,'fused'],env=env,stdout=log,stderr=log,check=True)
 return v+'-'+t,metrics(p)
data={'control':json.loads((s/'consumer-sizes.json').read_text())['control']}
for stage in ('lazy',):
 jobs=[(stage,v,t) for v in ('1.95.0','stable') for t in ('wasm32-wasip1','x86_64-unknown-linux-gnu')]
 with ThreadPoolExecutor(4) as pool:data[stage]=dict(pool.map(run,jobs))
(s/'consumer-lazy-sizes.json').write_text(json.dumps(data,indent=2)+'\n')
for key in data['control']:
 def lines(stage):
  return [l for l in (s/'logs'/f'consumer-{stage}-{key}.run').read_text().splitlines() if l.startswith(('RECORD','HEAP'))]
 a,b=map(lines,['control','lazy']);assert len(a)==256 and len(b)==256 and a==b,key
print('Matched all 128 complete trace records and 128 allocation records per target and compiler.')
