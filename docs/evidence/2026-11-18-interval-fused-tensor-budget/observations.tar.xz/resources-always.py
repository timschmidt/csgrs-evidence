from pathlib import Path
import json
s=Path(__file__).resolve().parent
out={};failure=[]
for v in ['1.95.0','stable']:
 for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
  tag=v+'-'+t
  def read(stage):return json.loads((s/f'stack-{stage}-{tag}.json').read_text())
  stages=[read(x) for x in ['fixed','control','always']];groups={}
  for stage in stages:
   for x in stage:
    key=(x['n'],x['mode'],x['warm'])
    groups.setdefault(key,[])
  for key in groups:
   obs=[[x for x in stage if (x['n'],x['mode'],x['warm'])==key] for stage in stages]
   assert all(len(q)==2 and {r['pattern'] for r in q}=={85,170} for q in obs)
   metrics={}
   for m in ('stack','peak','live','alloc','realloc','free','traffic'):
    a,b,c=[max(x[m] for x in q) for q in obs]
    delta=c-b;pos=max(0,delta);prior=max(0,b-a);cum=prior+pos
    if m=='stack':ic=min(32,b//100);cc=min(64,a*2//100)
    elif m in ('peak','live'):ic=min(128,b//20);cc=min(256,a//10)
    else:ic=cc=0
    if key[1]!=3 and pos and (pos>ic or cum>cc):failure.append([tag,*key,m,a,b,c,ic,cc])
    metrics[m]=dict(fixed=a,preceding=b,retained=c,delta=delta,prior=prior,cumulative=cum,inc_cap=ic,cum_cap=cc)
   groups[key]=metrics
  out[tag]=[dict(size=k[0],mode=k[1],warm=k[2],metrics=data) for k,data in groups.items()]
(s/'qualified-resources.json').write_text(json.dumps({'rows':out,'failures':failure},indent=1)+'\n')
print(failure)
for tag,rs in out.items():
 print(tag,'largest stack',max(r['metrics']['stack']['retained'] for r in rs),'peak heap',max(r['metrics']['peak']['retained'] for r in rs),'largest positive comparable stack',max(r['metrics']['stack']['delta'] for r in rs if r['mode']!=3))
