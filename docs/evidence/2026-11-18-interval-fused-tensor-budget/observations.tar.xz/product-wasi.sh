set -eu
s=/dev/shm/interval-budget-receipt;v=$1
while ! test -s "$s/retained-revision"; do sleep 4; done
while ! rg -q '^memory.peak [0-9]+' "$s/logs/explicit-limited-$v.log"; do sleep 4; done
cd /mnt/development/csgrs
taskset -c 0-4,8-12,18-24,28-32,38-39 bash "$s/limited-product.sh" "$v" warm
