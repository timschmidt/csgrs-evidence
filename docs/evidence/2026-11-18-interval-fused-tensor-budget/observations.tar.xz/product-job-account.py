from pathlib import Path
import json,re
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
prior=json.loads((r/'docs/research/interval-memory-accounts.json').read_text())['whole_solver_wasi_qualification'];rows={}
for v,b in prior['targets'].items():
 t=(s/'logs'/f'product-limited-{v}.log').read_text()
 assert '1514 direct WASI tests' in t and '4212 Horner dispatch windows' in t and 'memory.swap.max 0' in t and '\noom_kill 0\n' in t
 p=int(re.search(r'^memory.peak (\d+)$',t,re.M)[1]);times=[float(d) for d in re.findall(r'^\d{10}\.\d+$',t,re.M)];assert len(times)==2
 prev=b['retained_peak_bytes'];charge=max(0,p-prev)
 cap=prior['capacity_bytes'];reserve=prior['required_headroom_bytes']
 assert p+reserve<=cap
 rows[v]=dict(previous_job_peak_bytes=prev,measured_peak_bytes=p,incremental_positive_job_bytes=charge,cumulative_positive_job_bytes=prev+charge,headroom_bytes=cap-p,headroom_above_reserve_bytes=cap-reserve-p,elapsed_seconds=round(times[1]-times[0],3))
out=dict(source=(s/'product-revision').read_text().strip(),evidence='docs/evidence/2026-11-18-interval-fused-tensor-budget',workload='Compiled whole Hypersolve native/WASI qualification job with the additional width and rational-denominator cases. Warm Cargo lookup, children and cleanup inside a fresh swap-disabled Linux cgroup. Compilation is outside this account.',capacity_bytes=cap,required_headroom_bytes=reserve,charge='Keep the previously registered full peak plus positive growth. This is a test workload account. All production stack and heap accounts carry forward.',targets=rows)
(s/'final-ledger-memory.json').write_text(json.dumps(out,indent=2)+'\n')
