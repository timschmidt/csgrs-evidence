set -eu
s=/dev/shm/interval-budget-receipt
v=$1;cd "$s/product-checkout"
. /dev/shm/interval-horner-readmission/env
export CARGO_BUILD_JOBS=3 CARGO_TARGET_DIR="$s/mut-target-$v-x86_64-unknown-linux-gnu" CARGO_PROFILE_DEV_DEBUG=0
cargo +"$v" fmt --all -- --check
cargo +"$v" clippy --locked -p hypersolve --all-targets --all-features -- -D warnings
cargo +"$v" clippy --locked -p hypersolve --target wasm32-wasip1 --no-default-features --tests -- -D warnings
RUSTDOCFLAGS='-D warnings' cargo +"$v" doc --locked -p hypersolve --all-features --no-deps
cargo +"$v" test --locked -p hypersolve --no-default-features --test coefficient_bit_budget
cargo +"$v" test --locked -p hypersolve --doc --all-features
echo PASS
