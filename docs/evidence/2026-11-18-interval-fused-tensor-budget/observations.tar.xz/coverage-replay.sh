#!/usr/bin/env bash
set -euo pipefail

repo_dir="/mnt/development/csgrs/crates/hypersolve"
target_dir="${CARGO_TARGET_DIR:-${repo_dir}/target/coverage}"
if [[ "${target_dir}" != /* ]]; then
    target_dir="${repo_dir}/${target_dir}"
fi
profile_dir="${target_dir}/profraw"
profile_data="${target_dir}/hypersolve.profdata"
report_dir="${target_dir}/html"
text_report="${target_dir}/coverage.txt"
object_manifest="${target_dir}/test-objects.txt"
minimum_production_line_coverage="${HYPERSOLVE_MIN_PRODUCTION_LINE_COVERAGE:-85}"
target_triple="$(rustc -vV | sed -n 's/^host: //p')"
llvm_bin="$(rustc --print sysroot)/lib/rustlib/${target_triple}/bin"
llvm_cov="${llvm_bin}/llvm-cov"
llvm_profdata="${llvm_bin}/llvm-profdata"

if [[ ! -x "${llvm_cov}" || ! -x "${llvm_profdata}" ]]; then
    echo "coverage requires rustup component add llvm-tools-preview" >&2
    exit 1
fi
if ! command -v jq >/dev/null 2>&1; then
    echo "coverage requires jq to read Cargo's test-artifact manifest" >&2
    exit 1
fi


cd "${repo_dir}"
mapfile -t test_objects < <(sort -u "${object_manifest}")
if [[ ${#test_objects[@]} -eq 0 ]]; then
    echo "Cargo did not report any test executables" >&2
    exit 1
fi

primary_object="${test_objects[0]}"
object_args=()
for object in "${test_objects[@]:1}"; do
    object_args+=(--object "${object}")
done

# Select owned sources so Cargo cache, toolchain and workspace paths cannot
# change the denominator. Dedicated test directories remain outside it.
mapfile -d '' -t source_files < <(find src -type f -name '*.rs' ! -path '*/tests/*' -print0)
if [[ ${#source_files[@]} -eq 0 ]]; then
    echo "no Hypersolve source files found for coverage" >&2
    exit 1
fi

echo "Instrumented Rust source (inline #[cfg(test)] code included):"
"${llvm_cov}" report \
    "${primary_object}" \
    "${object_args[@]}" \
    --instr-profile="${profile_data}" \
    --sources "${source_files[@]}"

"${llvm_cov}" show \
    "${primary_object}" \
    "${object_args[@]}" \
    --instr-profile="${profile_data}" \
    --format=html \
    --output-dir="${report_dir}" \
    --show-instantiations=false \
    --show-line-counts-or-regions \
    --sources "${source_files[@]}"

# LLVM combines production code with inline unit-test modules. Derive a
# physical executable-line view that stops only at an explicit test-gated
# `mod tests` boundary; isolated `#[cfg(test)]` imports/helpers remain harmless.
echo
echo "Production executable lines (trailing inline test modules excluded):"
"${llvm_cov}" show \
    "${primary_object}" \
    "${object_args[@]}" \
    --instr-profile="${profile_data}" \
    --format=text \
    --show-instantiations=false \
    --show-line-counts-or-regions \
    --sources "${source_files[@]}" >"${text_report}"
awk -F'|' -v prefix="${repo_dir}/" -v threshold="${minimum_production_line_coverage}" '
        /^\/.*[.]rs:$/ {
            file = $0
            sub(/:$/, "", file)
            boundary = 999999
            source_line_number = 0
            pending_cfg_test = 0
            in_cfg_attribute = 0
            cfg_attribute_start = 0
            cfg_attribute_has_test = 0
            while ((getline source_line < file) > 0) {
                source_line_number++
                if (in_cfg_attribute != 0) {
                    if (source_line ~ /(^|[^[:alnum:]_])test([^[:alnum:]_]|$)/) {
                        cfg_attribute_has_test = 1
                    }
                    if (source_line ~ /\)\][[:space:]]*$/) {
                        in_cfg_attribute = 0
                        if (cfg_attribute_has_test != 0) {
                            pending_cfg_test = cfg_attribute_start
                        }
                    }
                    continue
                }
                if (source_line ~ /^[[:space:]]*#\[cfg\(/) {
                    cfg_attribute_start = source_line_number
                    cfg_attribute_has_test = source_line ~ /(^|[^[:alnum:]_])test([^[:alnum:]_]|$)/
                    if (source_line ~ /\)\][[:space:]]*$/) {
                        if (cfg_attribute_has_test != 0) {
                            pending_cfg_test = cfg_attribute_start
                        }
                    } else {
                        in_cfg_attribute = 1
                    }
                    continue
                }
                if (pending_cfg_test != 0 && source_line ~ /^[[:space:]]*$/) {
                    continue
                }
                if (pending_cfg_test != 0 && source_line ~ /^[[:space:]]*mod[[:space:]]+tests[[:space:]]*\{/) {
                    boundary = pending_cfg_test
                    break
                }
                if (pending_cfg_test != 0) {
                    pending_cfg_test = 0
                }
            }
            close(file)
            files[file] = 1
            boundaries[file] = boundary
            next
        }
        file != "" && $1 ~ /^[[:space:]]*[0-9]+$/ {
            line = $1 + 0
            count = $2
            gsub(/[[:space:]]/, "", count)
            if (line < boundaries[file] && count != "") {
                total[file]++
                if (count != "0") {
                    hit[file]++
                }
            }
        }
        END {
            for (file in files) {
                order[++file_count] = file
            }
            for (left = 1; left <= file_count; left++) {
                for (right = left + 1; right <= file_count; right++) {
                    if (order[left] > order[right]) {
                        temporary = order[left]
                        order[left] = order[right]
                        order[right] = temporary
                    }
                }
            }
            printf "%-42s %8s %8s %8s %9s\n", "Source", "Lines", "Hit", "Missed", "Coverage"
            for (row = 1; row <= file_count; row++) {
                file = order[row]
                relative = substr(file, length(prefix) + 1)
                missed = total[file] - hit[file]
                coverage = total[file] ? 100 * hit[file] / total[file] : 100
                printf "%-42s %8d %8d %8d %8.2f%%\n", relative, total[file], hit[file], missed, coverage
                sum += total[file]
                sum_hit += hit[file]
            }
            coverage = 100 * sum_hit / sum
            printf "%-42s %8d %8d %8d %8.2f%%\n", "TOTAL", sum, sum_hit, sum - sum_hit, coverage
            if (coverage < threshold) {
                printf "production line coverage %.4f%% is below required %.4f%%\n", coverage, threshold > "/dev/stderr"
                exit 2
            }
        }
    ' "${text_report}"

echo "Production coverage threshold: ${minimum_production_line_coverage}%"
echo "HTML report: ${report_dir}/index.html"
echo "Annotated text report: ${text_report}"
