set -eu
s=/dev/shm/interval-budget-receipt
. /dev/shm/interval-horner-readmission/env
export HYPERSOLVE_SKIP_BENCHMARK_REPORTS=1
for cpu in 3 17; do
  for stage in preceding candidate candidate preceding; do
    k="$s/criterion-$cpu-$stage"
    if test -e "$k"; then k="$k-repeat"; fi
    CRITERION_HOME="$k" taskset -c "$cpu" "$s/images/$stage-certification" --bench '^resultant_tensor_polynomial_univariate_constraint$' --sample-size 30 --warm-up-time 0.5 --measurement-time 1 --noplot >> "$s/logs/benchmark-$cpu-$stage.log" 2>&1
    test -n "$(find "$k" -name sample.json -print -quit)"
  done
done
