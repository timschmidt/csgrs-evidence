from pathlib import Path
import sys,os
d=Path('/mnt/development/csgrs/crates/hyperinterval/conformance')
sys.path.insert(0,str(d));from wasi_libtest import build_tests,TARGET
base=['cargo','+'+sys.argv[1],'test','--release','--locked','-p','hypersolve','--all-features']
env=os.environ.copy();env.pop('HYPERSOLVE_REPLAY_DRIVER',None)
g=build_tests([*base,'--target',TARGET],['--lib','--tests'],env)
n=build_tests(base,['--lib','--tests'],env|{'HYPERSOLVE_REPLAY_DRIVER':str(d/'wasi-solver.py')})
assert g.keys()==n.keys() and len(g)==71
