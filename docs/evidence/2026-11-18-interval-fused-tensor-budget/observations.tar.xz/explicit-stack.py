from pathlib import Path
import subprocess,sys
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
t=s/'stack-client/src/main.rs';canonical=s/'stack-client-original.rs'
if not canonical.exists():canonical.write_bytes(t.read_bytes())
tp='crates/hypersolve/src/tensor_resultant.rs';wp='crates/hypersolve/src/work_budget.rs'
(s/'stack-src'/wp).write_bytes((r/wp).read_bytes())
manual='''fn check_materialized(t: T) -> Option<T> {
    use hypersolve::work_budget::{is_active, observe_coefficient_bits};
    if is_active() {
        let bits=t.coefficients().iter().filter_map(Real::exact_rational_ref)
            .map(|q|q.numerator().bits()+q.denominator().bits()).max().unwrap_or(0);
        observe_coefficient_bits(bits).ok()?;
    }
    Some(t)
}
'''
for stage in ['manual','explicit']:
 if stage=='manual':
  base=subprocess.check_output(['git','-C',r,'show','9202bfaec:'+tp]);(s/'fused-manual.rs').write_bytes(base)
  suffix='check_materialized'
 else:suffix='T::within_coefficient_bit_limit'
 txt=canonical.read_text().replace('black_box(&[(&c.input,&c.input,false)]));','black_box(&[(&c.input,&c.input,false)])).and_then('+suffix+');')
 if stage=='manual':txt=txt.replace('fn main(){',manual+'\nfn main(){')
 t.write_text(txt);(s/('stack-client-'+stage+'.rs')).write_text(txt)
 subprocess.run([sys.executable,s/'stack.py',stage],check=True)
t.write_bytes(canonical.read_bytes())
