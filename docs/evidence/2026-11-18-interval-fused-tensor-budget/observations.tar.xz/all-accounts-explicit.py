from pathlib import Path
import json
d=Path(__file__).resolve().parent
manifest=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
old={a['artifact']:a for a in manifest['accounts']}
all_rows={stage:json.loads((d/stage/'all-accounted.json').read_text()) for stage in ['fixed','preceding','explicit']}
assert all(set(x)==set(all_rows['fixed']) for x in all_rows.values())
features={s:json.loads((d/s/'all-features.json').read_text()) for s in ['preceding','explicit']}
assert features['preceding']==features['explicit']
out={}
for name in sorted(all_rows['fixed']):
    if set(features['preceding'][name])!=set(old[name]['features']):continue
    checks={}
    for metric in ['file','text','named_text']:
        f,b,c=[all_rows[s][name][metric] for s in ('fixed','preceding','explicit')]
        budget=old[name]['metrics'][metric]
        prior=max(budget['accepted_positive_growth_bytes'],max(0,b-f))
        inc=max(0,c-b)
        cumulative=prior+inc
        limits=budget['caps']
        checks[metric]=dict(fixed=f,preceding=b,candidate=c,delta=c-b,prior_charge_lower_bound=prior,
                            cumulative_lower_bound=cumulative,caps=limits,
                            incremental_exceeded=inc>limits['incremental_bytes'] or inc*100>b*limits['incremental_percent'],
                            cumulative_exceeded=cumulative>limits['cumulative_bytes'] or cumulative*100>f*limits['cumulative_percent'])
    out[name]=checks
(d/'explicit-review.json').write_text(json.dumps(out,indent=2)+'\n')
fail=[n for n,m in out.items() if any(q['incremental_exceeded'] for q in m.values())]
print('matched',len(out),'incremental failures',len(fail))
for name in ['crates/hypersolve/benches/certification.rs','crates/hypersolve/examples/allocation_profile.rs','crates/hypersolve/src/lib.rs']:
 print(name,{k:(q['delta'],q['caps']['incremental_bytes'],q['incremental_exceeded']) for k,q in out[name].items()})
