from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys
d=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
w=d/'all-src'
account=json.loads((r/'docs/research/interval-size-accounts.json').read_text())
ledger={x['artifact']:x for x in account['accounts'] if x['target']=='x86_64-unknown-linux-gnu'}
env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/target-all','CARGO_BUILD_JOBS':'9'}
def metrics(p):
    def run(*cmd):return subprocess.check_output([*cmd,p],text=True)
    sec={}
    for ln in run('readelf','-SW').splitlines():
        m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',ln)
        if m:sec[m[1]]=int(m[2],16)
    values={}
    for l in run('nm','-S','--defined-only').splitlines():
        m=re.match(r'([0-9a-f]+) ([0-9a-f]+) [tT] ',l)
        if m:
            a,n=m.groups();n=int(n,16)
            assert a not in values or values[a]==n
            values[a]=n
    return dict(file=p.stat().st_size,text=sec.get('.text',0),named_text=sum(values.values()),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def build(stage):
    w.mkdir(exist_ok=True)
    if stage in ('fixed','preceding'):
        rev={'fixed':'c9f1f9ac5','preceding':'d2c8cf7df'}[stage]
        if stage=='preceding':shutil.rmtree(w);w.mkdir()
        with subprocess.Popen(['git','-C',r,'archive',rev],stdout=subprocess.PIPE) as git:
            subprocess.run(['tar','xf','-','-m','-C',w],stdin=git.stdout,check=True)
            assert git.wait()==0
    else:
        shutil.copy(r/'crates/hypersolve/src/tensor_resultant.rs' if stage=='candidate' else d/f'fused-{stage}.rs',w/'crates/hypersolve/src/tensor_resultant.rs')
    dest=d/stage;dest.mkdir(exist_ok=True)
    cmd=['cargo','+1.95.0','build','--locked','-p','hypersolve','-p','hyperdynamics','-p','hyperlattice-interval','--all-features','--release','--benches','--examples','--message-format=json']
    with (dest/'all-build.jsonl').open('w') as out,(dest/'all-build.log').open('w') as err:
        subprocess.run(cmd,env=env,cwd=w,stdout=out,stderr=err,check=True)
def collect(stage):
    dest=d/stage;dest.mkdir(exist_ok=True)
    artifacts={}
    features={}
    for row in map(json.loads,(dest/'all-build.jsonl').read_text().splitlines()):
        exe=row.get('executable')
        if exe:
            name=str(Path(row['target']['src_path']).relative_to(w))
            if name not in ledger:continue
            features[name]=row['features']
            artifacts[name]=metrics(Path(exe))
    (dest/'all-features.json').write_text(json.dumps(features,indent=2)+'\n')
    (dest/'all-accounted.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    selected=next(Path(row['executable']) for row in map(json.loads,(dest/'all-build.jsonl').read_text().splitlines()) if row.get('executable') and row['target']['name']=='certification')
    if stage!='fixed':shutil.copy(selected,d/'images'/f'{stage}-certification')
    print(stage,len(artifacts),artifacts.get('crates/hypersolve/benches/certification.rs'),flush=True)
for arg in sys.argv[1:] or ['fixed','preceding','candidate']:
    stage=arg.removesuffix('-built')
    if arg==stage:build(stage)
    collect(stage)
