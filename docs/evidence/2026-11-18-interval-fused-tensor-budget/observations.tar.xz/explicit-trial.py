from pathlib import Path
import subprocess
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
wp=Path('crates/hypersolve/src/work_budget.rs');tp=Path('crates/hypersolve/src/tensor_resultant.rs')
base=subprocess.check_output(['git','-C',r,'show','9202bfaec:'+str(tp)]).decode()
marker='''    // Reports the largest exact rational coefficient to an active coefficient
    // bit limit; an oversized product is unavailable, never truncated.
    fn within_coefficient_bit_limit'''
pub='''    /// Checks this tensor's stored exact rational coefficients against every active
    /// coefficient bit limit. Each size is numerator bits plus denominator bits.
    /// Symbolic coefficients retain their exact representation.
    ///
    /// An exceeded limit, prior exhaustion, or observed cancellation returns
    /// `None` and leaves the failure on the responsible work scope. Without an
    /// active scope the original tensor is returned directly. Call this before
    /// using a result from a construction such as [`Self::sum_products`] when
    /// that construction does not report its own coefficient sizes.
    pub fn within_coefficient_bit_limit'''
assert base.count(marker)==1
(s/'fused-explicit.rs').write_text(base.replace(marker,pub));(s/'tensor-src'/tp).write_text(base);(s/'tensor-src'/wp).write_bytes((r/wp).read_bytes())
x=s/'tensor-client/src/bin/explicit-oracle.rs'
t=(s/'joint-oracle.rs').read_text();t=t.replace('Tensor::sum_products(&terms)','Tensor::sum_products(&terms).and_then(Tensor::within_coefficient_bit_limit)').replace('Tensor::sum_products(&[(&ta,&tb,true),(&tb,&ta,false)])','Tensor::sum_products(&[(&ta,&tb,true),(&tb,&ta,false)]).and_then(Tensor::within_coefficient_bit_limit)').replace('Tensor::sum_products(&[(&t,&t,false)])','Tensor::sum_products(&[(&t,&t,false)]).and_then(Tensor::within_coefficient_bit_limit)')
x.write_text(t);(s/'explicit-oracle.rs').write_text(t)
