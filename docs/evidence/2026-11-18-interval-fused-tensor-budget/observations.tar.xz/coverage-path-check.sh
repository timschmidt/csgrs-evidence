set -eu
s=/dev/shm/interval-budget-receipt
. /dev/shm/interval-horner-readmission/env
repo_dir="$s/coverage layout/tests/owner"
mkdir -p "$repo_dir/src" "$repo_dir/relocated cargo/registry/src/local"
cat > "$repo_dir/relocated cargo/registry/src/local/dep.rs" <<'RS'
pub fn value() -> usize { 17 }
RS
cat > "$repo_dir/src/main.rs" <<'RS'
#[path = "../relocated cargo/registry/src/local/dep.rs"]
mod dependency;
fn main() { assert_eq!(dependency::value(), 17); }
RS
cd "$repo_dir"
mapfile -d '' -t source_files < <(find src -type f -name '*.rs' ! -path '*/tests/*' -print0)
for v in 1.95.0 stable; do
  llvm="$(rustc +"$v" --print sysroot)/lib/rustlib/x86_64-unknown-linux-gnu/bin"
  rustc +"$v" -C instrument-coverage src/main.rs -o "owner-$v"
  LLVM_PROFILE_FILE="$repo_dir/$v.profraw" "./owner-$v"
  "$llvm/llvm-profdata" merge -sparse "$v.profraw" -o "$v.profdata"
  "$llvm/llvm-cov" export "owner-$v" --instr-profile="$v.profdata" --sources "${source_files[@]}" |
    jq -e '[.data[].files[].filename] as $files | ($files|length)==1 and ($files[0]|endswith("/src/main.rs"))'
  "$llvm/llvm-cov" export "owner-$v" --instr-profile="$v.profdata" |
    jq -e '[.data[].files[].filename] as $files | ($files|length)==2 and ($files|any(endswith("dep.rs")))'
  echo "$v owner selected with a relocated dependency and spaces under a tests directory"
done
