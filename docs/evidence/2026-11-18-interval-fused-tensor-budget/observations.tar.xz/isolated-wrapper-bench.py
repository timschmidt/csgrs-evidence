from pathlib import Path
import subprocess,shutil,os,json,statistics,time
s=Path(__file__).parent
p=s/'wrapper-certification';d=s/'paired-criterion-data'
# Numeric samples are written at one invariant executable and output path.
env=os.environ|{'CRITERION_HOME':str(d),'HYPERSOLVE_SKIP_BENCHMARK_REPORTS':'1'}
rows=[]
for cpu in (5,14):
 for i,stage in enumerate(['preceding','wrapper','wrapper','preceding']*3):
  shutil.copy(s/'images'/f'{stage}-certification',p)
  cmd=['taskset','-c',str(cpu),'setarch','x86_64','-R',p,'--bench','^resultant_tensor_polynomial_univariate_constraint$','--sample-size','40','--warm-up-time','0.7','--measurement-time','1.5','--noplot','--discard-baseline']
  log=s/'logs'/f'isolated-wrapper-bench-{cpu}-{i}-{stage}.log'
  with log.open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=f,check=True)
  # --discard-baseline leaves numerical results in stdout but skips writing new rows.
  import re
  val=re.search(r'time:\s*\[([.\d]+) µs ([.\d]+) µs ([.\d]+) µs\]',log.read_text()).groups()
  rows.append(dict(cpu=cpu,stage=stage,sample=i,lower_us=float(val[0]),point_us=float(val[1]),upper_us=float(val[2])))
  (s/'isolated-wrapper-benchmark.json').write_text(json.dumps(rows,indent=2)+'\n')
for cpu in (5,14):
 print(cpu,{st:statistics.median(r['point_us'] for r in rows if r['stage']==st and r['cpu']==cpu) for st in ['preceding','wrapper']})
