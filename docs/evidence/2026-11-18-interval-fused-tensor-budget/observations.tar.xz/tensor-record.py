from pathlib import Path
import importlib.util,json,subprocess
s=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('writer',s/'width-record.py');writer=importlib.util.module_from_spec(spec);spec.loader.exec_module(writer)
items=set()
def take(pattern):items.update(p for p in s.glob(pattern) if p.is_file())
for pat in ['scope.md','tensor-reproduce.md','source-revision','predecessor','proof-revision','resources*.py','resources.json','qualified-resources.*','stack.py','stack-wasi.mjs','reserve.py','reserve.mjs','measure.py','metrics.py','tensor-*.py','fused-*.rs','lazy-*.rs','lazy-trial.py','axis-trial.py','scope-trial.py','scope-work.rs','joint-oracle.*','all-accounts*.py','all-artifacts.py','*all-budget-review.json','tensor-review.json','timing*.py','timing*.json','bench*.sh','downstream*.py','downstream*.json','tensor-*-*.json','consumer*.json','consumer*summary.log','proof-fixture-sizes.json','qualified-fixture-sizes.json','reservations-*.json','stack-*.json','warm.py','quality.sh','wasi.sh','limited*.sh','mutations.sh','accept.py','packaged-final.py','width-record.py','scope-resource-review.json']:
 take(pat)
for stage in ('always','control','fixed','preceding','filter','borrow','axis','scope','candidate'):
 for p in ('all-accounted.json','all-features.json','all-build.log'):
  take(stage+'/'+p)
for p in ('tensor-client','stack-client','packaged-final-client','fuzz'):
 for ext in ('Cargo.lock','Cargo.toml','build.rs','*.c','src/**/*.rs','fuzz_targets/*.rs'):
  take(p+'/'+ext)
take('fuzz-corpus/*')
for p in ('qualified-wasi-stable','qualified-wasi-1.95.0'):take(p+'/*')
for p in ('qualified-criterion*','filter-criterion*','criterion*'):
 for ext in ('new/sample.json','new/estimates.json'):take(p+'/**/'+ext)
for ext in ('qualified-*','package-final.log','packaged-final*','mut-*-fixture.*','fuzzer-final.log','coverage-final.log','*benchmark*','always-*','control-successive*','control-hypercurve*','control-coefficient_bit*','control-generated_nurbs*','oracle-*','*timing.log','*accounted.log','consumer-*','tensor-*','stack-*','downstream*.log','*client.log','fused-red.log','*scope.log','*axis.log'):
 take('logs/'+ext)
take('fused-red.log');take('control-*-wasm32-wasip1.json');take('control-*-x86_64-unknown-linux-gnu.json')
for r in ('scope','axis','filter','always'):
 take(r+'-review.json')
take('primary-verification.log');take('checked-product.rs');take('higher-rank-oracle.log')
for stage in ('explicit','wrapper','product','manual'):
 for pat in (stage+'*.rs',stage+'*.py',stage+'*.json',stage+'-revision','fused-'+stage+'.rs','stack-client-'+stage+'.rs','tensor-client-'+stage+'.rs','run-'+stage+'.py','run-client-'+stage+'*.py','logs/'+stage+'*','logs/measure-'+stage+'.log','logs/packaged-'+stage+'*','logs/package-'+stage+'.log','logs/mut-denominator-*','logs/same-path-bench*','logs/isolated-*','logs/timing-*','logs/oracle-*','logs/stack-*','logs/reserved-*','logs/downstream-*','logs/product-*','compare*bench.py','isolated-*bench.py','same-path-benchmark.json','isolated-*benchmark.json','explicit-benchmark.json','wrapper-benchmark.json',stage+'/all-accounted.json',stage+'/all-features.json',stage+'/all-build.log','downstream-'+stage+'.json','packaged-'+stage+'.py','limited-'+stage+'.sh'):take(pat)
for pat in ('product-wasi-*/*','explicit-wasi-*/report.json','explicit-wasi-*/coefficient_bit_budget.log','explicit-wasi-digests.json'):take(pat)
for pat in ('retained-binaries.py','retained-binaries.json','logs/retained-binaries.log','product-job-account.py','product-quality.sh','product-wasi.sh','tensor-record.py','retained-revision','product-revision','wrapper-revision','explicit-revision','stack-client-*.rs','tensor-client-*.rs','final-ledger*.json','final-ledger.py','checked-product.rs','product-mutant.py','graded-runs.json','explicit-fixture.rs','product-qualification.md','product-fixture-sizes.json','wrapper-fixture-sizes.json','scope-resource-review.json','explicit-resource-accounts.json','wrapper-resource-accounts.json','stack-client-original.rs','tensor-client-original.rs','docs-only-verification.log'):take(pat)
rev=(s/'source-revision').read_text().strip()
assert (s/'fused-always.rs').read_bytes()==writer.git(writer.r,'show',rev+':crates/hypersolve/src/tensor_resultant.rs')
for tc in ('1.95.0','stable'):
 assert (s/'logs'/f'qualified-quality-{tc}.log').read_text().endswith('PASS\n')
 l=(s/'logs'/f'qualified-limited-final-{tc}.log').read_text()
 assert '1514 direct WASI tests' in l and 'oom_kill 0' in l
 for target in ('x86_64-unknown-linux-gnu','wasm32-wasip1'):
  assert '3 passed; 0 failed;' in (s/'logs'/f'qualified-{tc}-{target}-fixture.log').read_text()
assert 'Done 10000 runs' in (s/'logs/fuzzer-final.log').read_text()
for tc in ('1.95.0','stable'):
 assert (s/'logs'/f'product-quality-{tc}.log').read_text().endswith('PASS\n')
 assert '1514 direct WASI tests' in (s/'logs'/f'product-limited-{tc}.log').read_text()
 for arch in ('wasm32-wasip1','x86_64-unknown-linux-gnu'):
  assert '3 passed; 0 failed' in (s/'logs'/f'product-{tc}-{arch}-fixture.log').read_text()
  assert 'panicked' in (s/'logs'/f'mut-denominator-{tc}-{arch}-fixture.log').read_text()
assert 'below required 85.0000%' in (s/'logs/coverage-unscoped.log').read_text()
assert 'Production coverage threshold: 85%' in (s/'logs/coverage-report-replay.log').read_text()
assert 'Production coverage threshold: 85%' in (s/'logs/coverage-retained.log').read_text()
for pat in ('logs/coverage-unscoped.log','logs/coverage-report-replay.log','logs/coverage-retained.log','coverage-*.sh','coverage-owned-comparison.json','coverage-account.py','coverage-revision','guard-revision','coverage-denominator*.json','coverage-denominator.py','logs/coverage-path-check.log'):take(pat)
assert '1 passed; 0 failed;' in next((s/'logs').glob('always-generated_nurbs*')).read_text()
assert all(not (p.is_symlink() or p.stat().st_size>8_000_000) for p in items)
print(json.dumps(writer.record('fused-tensor-budget',items,'Archive signed tensor budget witnesses, design comparisons and resource measurements')))
