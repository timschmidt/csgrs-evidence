mod allocations;
use hyperreal::{Real,dispatch_trace};
use hypersolve::{DenseTensorPolynomial as Tensor,work_budget::{WorkBudget,WorkKind,with_budget,with_coefficient_bit_limit}};
use std::{hint::black_box,env};
fn ratio(n:i64,d:i64)->Real{(Real::from(n)/Real::from(d)).unwrap()}
fn tensor(raw:&[i64])->Tensor{
 Tensor::try_new(vec![raw.len()],raw.iter().map(|n|ratio(*n,4)).collect()).unwrap()
}
fn bits(n:i64)->u64{
 let abs=n.unsigned_abs();
 let cancel=abs.trailing_zeros().min(4);
 u64::from((abs>>cancel).checked_ilog2().map_or(0,|k|k+1) + (5-cancel))
}
fn main(){
 let args: Vec<_>=env::args().collect();let corrected=args[1]=="fused";
 if args[1]=="time" {
   let a=tensor(&[1,2,3,4]);let b=tensor(&[2,0,-3]);let terms=[(&a,&b,false),(&b,&a,true)];
   let expected=Tensor::zero(vec![6]).unwrap();
   let run=||Tensor::sum_products(black_box(&terms)).unwrap();
   let clock=std::time::Instant::now();
   for _ in 0..4000 {
    let product=match args[2].as_str() {
     "plain"=>run(),
     "work"=>with_budget(WorkBudget::UNLIMITED,run).result.unwrap(),
     "bits"=>with_coefficient_bit_limit(100,run).result.unwrap(),
     _=>unreachable!()
    };assert_eq!(black_box(&product),&expected);drop(product);
   }
   println!("{}",clock.elapsed().as_nanos());return;
 }
 for seed in 0..32i64 {
  let a:Vec<_>=(0..4).map(|i|(seed*7+i*5)%19-9).collect();
  let b:Vec<_>=(0..3).map(|i|(seed*3+i*7)%23-11).collect();
  let c:Vec<_>=(0..2).map(|i|(seed+i*9)%13-6).collect();
  let (x,y,z)=(tensor(&a),tensor(&b),tensor(&c));
  for subtract in [false,true] {
   let terms=[(&x,&y,false),(&z,&y,subtract)];
   let mut nums=[0i64;6];for (left,sgn) in [(&a,1),(&c,if subtract{-1}else{1})] {for (i,p) in left.iter().enumerate(){for (j,q) in b.iter().enumerate(){nums[i+j]+=sgn*p*q;}}}
   let max=nums.iter().map(|n|bits(*n)).max().unwrap();
   let expected=Tensor::try_new(vec![6],nums.iter().map(|n|ratio(*n,16)).collect()).unwrap();
   let run=||Tensor::sum_products(&terms).unwrap();
   for scoped in [false,true] {
    let op=||if scoped{with_coefficient_bit_limit(max,run).result.unwrap()}else{run()};
    dispatch_trace::reset();
    let actual=dispatch_trace::with_recording(op);
    let trace=dispatch_trace::take_trace();
    assert_eq!(actual,expected);
    println!("RECORD {seed} {subtract} {scoped} {nums:?} {max} {trace:?}");
    let (_,h)=allocations::once(||{let p=op();assert_eq!(p,expected);drop(black_box(p));});
    println!("HEAP {seed} {subtract} {scoped} {:?}",(h.allocations,h.deallocations,h.reallocations,h.allocated_bytes,h.peak_live_bytes,h.live_bytes));
   }
   let denied=with_coefficient_bit_limit(max-1,||Tensor::sum_products(&terms));
   if corrected{
    let e=denied.result.unwrap_err();assert_eq!(e.kind,WorkKind::CoefficientGrowth);
    assert_eq!((e.limit as u64,e.used,e.requested as u64),(max-1,0,max));
   }else{
    assert_eq!(denied.result.unwrap(),Some(expected.clone()));
   }
   let retry=with_coefficient_bit_limit(max,run);assert_eq!(retry.result,Ok(expected));
  }
 }
}
