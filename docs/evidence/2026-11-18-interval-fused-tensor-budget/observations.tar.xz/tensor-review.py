from pathlib import Path
import json,statistics
s=Path(__file__).resolve().parent
def read(p):return json.loads((s/p).read_text())
prev=read('../interval-solver-library/accounts-review.json')['targets']
out={}
for stage in ['always','borrow','filter','slice','borrow-cold','lazy','axis','scope','explicit','wrapper']:
 data={}
 for p in s.glob('tensor-'+stage+'-*.json'):
  tag=p.stem.removeprefix('tensor-'+stage+'-')
  if tag not in prev:continue
  base=read('control-'+tag+'.json');old=prev[tag];cur=read(p)
  comp={}
  for n,q in cur.items():
   row={}
   for k in ('file','code','functions'):
    b=base[n][k];v=q[k];delta=v-b;inc=max(0,delta)
    if n in old['artifacts']:
     oq=old['artifacts'][n]['charges'][k];fixed=oq['fixed'];prior=oq['cumulative_charge']
     # Match builds done from the same path for the current increment.
     # Historical charges come from the preceding registered release qualification.
    else:
     assert n in old['equal_example_hashes'] or (n=='trivariate_arithmetic' and 'wasm' in tag)
     fixed=b;prior=0
    ic=min(4096,b//100);cc=min(8192,fixed*2//100)
    row[k]=dict(fixed=fixed,preceding=b,observed=v,delta=delta,prior=prior,increment=inc,cumulative=prior+inc,incremental_room=ic-inc,cumulative_room=max(0,cc-prior)-inc,caps=[ic,cc])
   row['free_slot_bytes']=64*2**20-q['file'];comp[n]=row
  data[tag]=comp
 out[stage]=data
(s/'tensor-review.json').write_text(json.dumps(out,indent=1)+'\n')
for stage,data in out.items():
 fail=[(t,n,k,q['delta']) for t,d in data.items() for n,row in d.items() for k,q in row.items() if isinstance(q,dict) and min(q['incremental_room'],q['cumulative_room'])<0]
 print(stage,len(data),len(fail),fail[:3])
for stage in ['qualified','filter']:
 for p in sorted(s.glob(stage+'-benchmark-never')):pass
 for cpu in [7,16]:
  d={}
  for var in ['preceding','always' if stage=='qualified' else 'filter']:
   ds=[json.loads(f.read_text())['median']['point_estimate'] for f in sorted(s.glob(f'{stage}-criterion-{cpu}-{var}*/**/new/estimates.json'))]
   if ds:d[var]=[round(x,2) for x in ds]
  print(stage,cpu,d)
