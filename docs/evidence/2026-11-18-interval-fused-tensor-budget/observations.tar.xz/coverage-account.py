from pathlib import Path
import json,re
s=Path(__file__).parent
def parse(name):
 t=(s/'logs'/name).read_text().split('Production executable lines (trailing inline test modules excluded):')[-1]
 # The unscoped log merged stdout and stderr and split a single data row.
 t=re.sub(r'production line coverage [\d.]+% is below required [\d.]+%\n','',t)
 pattern=r'^(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([\d.]+)%$'
 return {m[1]:tuple(map(int,m.group(2,3,4))) for m in re.finditer(pattern,t,re.M)}
old=parse('coverage-unscoped.log');new=parse('coverage-report-replay.log')
expected={n:q for n,q in old.items() if n.startswith('src/')}
observed={n:q for n,q in new.items() if n!='TOTAL'}
assert expected and expected==observed,(len(expected),len(observed),set(expected)^set(observed),[(n,v,observed.get(n)) for n,v in expected.items() if v!=observed.get(n)][:3])
assert len(old)>len(expected) and int(old['TOTAL'][1])/old['TOTAL'][0]<.85 and new['TOTAL'][1]/new['TOTAL'][0]>=.85
assert tuple(sum(row[i] for row in expected.values()) for i in range(3))==new['TOTAL']
(s/'coverage-owned-comparison.json').write_text(json.dumps(dict(owner_files=len(expected),before_total=old['TOTAL'],scoped_total=new['TOTAL'],identical_owner_rows=expected),indent=1)+'\n')
print(len(expected),old['TOTAL'],new['TOTAL'])
