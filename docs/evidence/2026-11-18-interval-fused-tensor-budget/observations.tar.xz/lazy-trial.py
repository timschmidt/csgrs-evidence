from pathlib import Path
import shutil
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
wp=Path('crates/hypersolve/src/work_budget.rs');tp=Path('crates/hypersolve/src/tensor_resultant.rs')
w=(r/wp).read_text()
a=w.index('    if !is_active()',w.index('pub fn observe_coefficient_bits('))
b=w.index('\nfn enter',a)
c=w[a:b]
anchor='        let Some(index) = frames'
fn=c.replace(anchor,'        let bits = std::cell::LazyCell::new(bits);\n'+anchor).replace('|limit| bits > limit','|limit| *bits > limit').replace('usize::try_from(bits)','usize::try_from(*bits)')
w=w[:a]+'    observe_coefficient_bits_with(|| bits)\n}\n\n#[inline]\npub(crate) fn observe_coefficient_bits_with(bits: impl FnOnce() -> u64) -> Result<(), BudgetExceeded> {\n'+fn+w[b:]
t=(r/tp).read_text()
a=t.index('        if !crate::work_budget::is_active()',t.index('fn within_coefficient_bit_limit'));b=t.index('\n    }',a)
body=t[a:b];body=body[body.index('        let bits = self'):body.index('            .ok()')].replace('        let bits = self','        crate::work_budget::observe_coefficient_bits_with(|| self').replace('.unwrap_or(0);\n        crate::work_budget::observe_coefficient_bits(bits)','.unwrap_or(0))')
t=t[:a]+body+'\n            .ok()\n            .map(|()| self)'+t[b:]
(s/'lazy-work.rs').write_text(w);(s/'lazy-tensor.rs').write_text(t)
for d in ('tensor-src','src'):
 (s/d/wp).write_text(w);(s/d/tp).write_text(t)
p=(s/'tensor-final.py').read_text().replace("'always'","'lazy'").replace('consumer-always-sizes','consumer-lazy-sizes')
p='\n'.join(l for l in p.splitlines() if "shutil.copy(r/'crates/hypersolve" not in l)+'\n'
(s/'tensor-lazy.py').write_text(p)
