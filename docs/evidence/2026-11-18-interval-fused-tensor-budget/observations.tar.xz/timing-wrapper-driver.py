from pathlib import Path
import sys,subprocess
s=Path(__file__).parent
for previous,current in [('control','wrapper-old'),('manual','wrapper')]:
 t=(s/'timing-lazy.py').read_text().replace("'control'",repr(previous)).replace("'lazy'",repr(current)).replace('timing-lazy.json','timing-'+current+'.json').replace('timed-lazy','timed-'+current)
 script=s/('timing-'+current+'.py');script.write_text(t)
 with (s/'logs'/('timing-'+current+'.log')).open('w') as l:subprocess.run([sys.executable,script],stdout=l,stderr=l,check=True)
