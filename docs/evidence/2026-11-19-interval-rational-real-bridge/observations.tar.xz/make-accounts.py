from pathlib import Path
import json,os
w=Path(os.environ['w'])
test=json.loads((w/'test-costs.json').read_text())
def append_record(which,data):
 p=Path('docs/research/interval-'+which+'-accounts.json');s=p.read_text()
 key='real_rational_enclosure_2026_11_19'
 assert key not in json.loads(s)
 block=json.dumps({key:data},indent=2)
 out=s.rstrip()[:-1].rstrip()+',\n'+block[2:]+'\n'
 assert json.loads(out)[key]==data
 p.write_text(out)
paired={}
for sub,fn in [('checked_scalar','bridge/api-sizes.json'),('existing_ball','history/bridge-sizes.json')]:
 r=json.loads((w/fn).read_text())
 for suffix,a in r.items():
  for n,v in a.items(): assert v[1]==v[2], (suffix,n)
 paired[sub]={s:a['file'][2] for s,a in r.items()}
record=os.environ['rec']
append_record('size',{
 'revision':'4ad0c199c','preceding':'0426a60b6','existing_ball_fixed':'c9f1f9ac5',
 'record':record,'matched_release_image_bytes':paired,
 'production_incremental_bytes':0,
 'cumulative_account':'No additional charge on existing images. The fixed-to-preceding padding increases of 96 B each for the ordinary, guarded and usable-allocation ball clients remain in their own accounts. Detailed fixed, preceding and final section sizes are archived.',
 'new_qualification_slot_bytes_per_target':16777216,'minimum_free_bytes_per_target':4194304,
 'standalone_test':{k:{'file_bytes':v['image_bytes']['file'],'code_bytes':v['image_bytes'].get('code',v['image_bytes'].get('.text')),'first_positive_charge_bytes':v['image_bytes']['file'],'free_bytes':v['free_bytes']} for k,v in test.items()}})
p=json.loads((w/'bridge/profiles.json').read_text())
s=p['api'];a=p['base']
for k in ['heap','stack','usable','traces']:assert s[k]==a[k]
append_record('memory',{
 'revision':'4ad0c199c','preceding':'0426a60b6','record':record,
 'scope':'Rust 1.95 release, 20 single-worker complete rational enclosure and rescaling workloads, including scalar cancellation and retry.',
 'guarded_native_stack_bytes':max(s['stack'].values()),'minimum_worker_headroom_bytes':s['headroom'],
 'peak_requested_heap_bytes':max(x[4] for x in s['heap'].values()),'peak_usable_heap_bytes':max(x[1] for x in s['usable'].values()),
 'post_drop_requested_bytes':max(x[5] for x in s['heap'].values()),'post_drop_usable_bytes':max(x[2] for x in s['usable'].values()),
 'per_workload_incremental_and_new_cumulative_heap_and_stack_charges_bytes':0,
 'bare_wasm_max_linear_memory_bytes':max(int(l.split()[-1]) for l in (w/'bridge/logs/api-wasm').read_text().splitlines()),
 'standalone_test_process_high_water_KiB':{k:v['process_high_water_KiB'] for k,v in test.items()},
 'test_process_scope':'Three fresh single-thread runs per binary. WASI process high water includes Node and its WebAssembly engine.'})
