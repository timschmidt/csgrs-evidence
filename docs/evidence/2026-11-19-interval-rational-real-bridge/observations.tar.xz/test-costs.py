import os,json,subprocess,sys
from pathlib import Path
w=Path(os.environ['w']);sys.path.insert(0,str(w/'history'))
from image_metrics import sizes
from wasm_metrics import wasm
r={}
for kind,_list in [('native','final-native-artifacts'),('wasi','final-artifacts')]:
 for ix,l in enumerate((w/'logs'/_list).read_text().splitlines()):
  size,path=l.split(' ',1);p=Path(path);tag=f"{kind}-{['1.95.0','1.99.0'][ix]}"
  rss=[]
  for attempt in range(3):
   rssfile=w/'logs'/f'peak-{tag}-{attempt}'
   cmd=[p,'--test-threads=1']
   if kind=='wasi':cmd=['node','--no-warnings','crates/hyperlattice-interval/conformance/run-wasi-test.mjs',*cmd]
   log=subprocess.check_output(['python3',w/'bridge/measure-rss.py',rssfile,*cmd],text=True)
   assert 'ok. 4 passed; 0 failed' in log;rss.append(int(rssfile.read_text().split()[0]))
  metrics=sizes(p) if kind=='native' else dict(file=p.stat().st_size,code=wasm(p))
  assert int(size)==metrics['file'] and metrics['file']<=12*1024**2
  r[tag]={'image_bytes':metrics,'slot_bytes':16*1024**2,'minimum_free_bytes':4*1024**2,'free_bytes':16*1024**2-metrics['file'],'process_high_water_KiB':rss}
(w/'test-costs.json').write_text(json.dumps(r,indent=2)+'\n')
