use hyperinterval::{BallRelation,RealBall};
use hyperreal::{Real,Rational};
use std::{alloc::{GlobalAlloc,Layout,System},hint::black_box,sync::atomic::{AtomicUsize,Ordering::Relaxed},time::Instant};
struct Counter;
static BYTES:AtomicUsize=AtomicUsize::new(0);
static PEAK:AtomicUsize=AtomicUsize::new(0);
static CALLS:AtomicUsize=AtomicUsize::new(0);
fn record(n:usize){let total=BYTES.fetch_add(n,Relaxed)+n;PEAK.fetch_max(total,Relaxed);CALLS.fetch_add(1,Relaxed);}
unsafe impl GlobalAlloc for Counter{
 unsafe fn alloc(&self,l:Layout)->*mut u8{let p=unsafe{System.alloc(l)};if !p.is_null(){record(l.size())};p}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){BYTES.fetch_sub(l.size(),Relaxed);unsafe{System.dealloc(p,l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{let q=unsafe{System.realloc(p,l,n)};if !q.is_null(){BYTES.fetch_sub(l.size(),Relaxed);record(n)};q}
}
#[global_allocator] static ALLOC:Counter=Counter;
fn ratio(n:i64,d:u64)->Rational{Rational::fraction(n,d).unwrap()}
fn fixture(k:usize)->(RealBall,Real,i32,BallRelation){
 use BallRelation::*;
 let root=||Real::from(2).sqrt().unwrap();
 match k{
  0=>(RealBall::new(Real::from(2),ratio(1,2)).unwrap(),Real::from(ratio(9,4)),-4,Contained),
  1=>(RealBall::new(Real::from(2),ratio(1,2)).unwrap(),Real::from(3),0,Excluded),
  2=>(RealBall::point(root()),Real::from(ratio(7,5)),0,Unresolved),
  3=>(RealBall::point(root()),Real::from(ratio(7,5)),-64,Excluded),
  4=>(RealBall::new(Real::zero(),ratio(1,3)).unwrap(),Real::from(ratio(-1,3)),0,Contained),
  5=>(RealBall::new(Real::zero(),ratio(1,8)).unwrap(),root()*Real::from(ratio(1,32)),0,Contained),
  6=>(RealBall::point(Real::zero()),Real::from(ratio(1,3)),i32::MIN,Excluded),
  7=>(RealBall::new(Real::zero(),ratio(1,3)).unwrap(),Real::from(ratio(1,3)),i32::MAX,Contained),
  _=>unreachable!()
 }
}
fn main(){
 let args:Vec<_>=std::env::args().collect();let k:usize=args[1].parse().unwrap();let repetitions:usize=args[2].parse().unwrap();
 let initial=BYTES.load(Relaxed);PEAK.store(initial,Relaxed);let calls=CALLS.load(Relaxed);let start=Instant::now();
 let (ball,point,p,expected)=fixture(k);
 #[cfg(feature="trace")] hyperreal::dispatch_trace::reset();
 let mut n=0;
 let mut evaluate=||{for _ in 0..repetitions{let r=black_box(&ball).classify_point(black_box(&point),p).unwrap();assert_eq!(r,expected);n+=usize::from(r!=BallRelation::Unresolved)+1;}};
 #[cfg(feature="trace")] hyperreal::dispatch_trace::with_recording(evaluate);
 #[cfg(not(feature="trace"))] evaluate();
 drop((ball,point));let t=start.elapsed().as_nanos();let peak=PEAK.load(Relaxed)-initial;let keep=BYTES.load(Relaxed) as i64-initial as i64;let requests=CALLS.load(Relaxed)-calls;
 println!("row {k} {n} {t} {peak} {keep} {requests}");
 #[cfg(feature="trace")] println!("trace {:?}",hyperreal::dispatch_trace::take_trace().dispatch);
}
