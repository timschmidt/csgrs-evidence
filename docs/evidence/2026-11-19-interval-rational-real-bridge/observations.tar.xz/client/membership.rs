#![cfg(feature = "real-ball")]

use hyperinterval::{BallRelation, IntervalError, RationalInterval, RealBall};
use hyperreal::{Rational, Real};
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};

#[test]
fn reflected_ball_enclosures_keep_both_closed_endpoints_after_composition() {
    let third = Rational::fraction(1, 3).unwrap();
    let source = RealBall::new(Real::from(-1), Rational::one()).unwrap();
    let reflected = source.affine(&(-&third), &Real::from(third.clone()));
    // Reflecting and scaling [-2, 0] and then translating by 1/3 gives [1/3, 1].
    let doubled = reflected.add(&reflected);
    let difference = doubled.sub(&reflected);
    let cases = [(&reflected, 2, 1), (&doubled, 4, 2), (&difference, 2, 3)];
    for (ball, numerator, radius_numerator) in cases {
        let center = Rational::fraction(numerator, 3).unwrap();
        let radius = Rational::fraction(radius_numerator, 3).unwrap();
        assert_eq!(ball.center().exact_rational_ref(), Some(&center));
        assert_eq!(ball.radius(), &radius);
        for precision in [0, -7, -8, -128, 0] {
            // At 2^precision spacing, the fractional grid position is (n * 2^-p mod 3) / 3.
            let residue = numerator * if precision % 2 == 0 { 1 } else { 2 } % 3;
            let grid = Rational::from(2).powi(precision.into()).unwrap();
            let lower = &center - &grid * Rational::fraction(residue, 3).unwrap() - &radius;
            let upper = &center + &grid * Rational::fraction(3 - residue, 3).unwrap() + &radius;
            assert_eq!(
                ball.to_rational(precision).unwrap(),
                RationalInterval::new(lower, upper).unwrap()
            );
        }
    }
}

#[test]
fn unavailable_symbolic_displacement_can_be_retried_in_both_orders() {
    for warm in [false, true] {
        let mut root = Real::from(2).sqrt().unwrap();
        if warm {
            assert!(root.certified_rational_interval(-64).is_some());
        }
        let stop = Arc::new(AtomicBool::new(true));
        root.abort(stop.clone());
        let zero_ball = RealBall::point(Real::zero());
        let root_ball = RealBall::point(root.clone());
        assert_eq!(
            zero_ball.classify_point(&root, -64),
            Err(IntervalError::EnclosureUnavailable)
        );
        assert_eq!(
            root_ball.classify_point(&Real::zero(), -64),
            Err(IntervalError::EnclosureUnavailable)
        );
        stop.store(false, Ordering::Relaxed);
        assert_eq!(
            zero_ball.classify_point(&root, -64).unwrap(),
            BallRelation::Excluded
        );
        assert_eq!(
            root_ball.classify_point(&Real::zero(), -64).unwrap(),
            BallRelation::Excluded
        );
    }
}

#[test]
fn exact_rational_displacements_decide_closed_ball_membership_on_coarse_grids() {
    let center = Rational::fraction(-5, 7).unwrap();
    for numerator in [0, 1, 5] {
        let ball = RealBall::new(
            Real::from(center.clone()),
            Rational::fraction(numerator, 3).unwrap(),
        )
        .unwrap();
        for offset in -11_i64..=11 {
            // The displacement is offset/6 and the radius is numerator/3.
            let expected = if offset.abs() <= 2 * numerator {
                BallRelation::Contained
            } else {
                BallRelation::Excluded
            };
            let point = Real::from(&center + Rational::fraction(offset, 6).unwrap());
            for precision in [0, -24, 4] {
                assert_eq!(
                    ball.classify_point(&point, precision),
                    Ok(expected),
                    "radius={numerator}/3 displacement={offset}/6 precision={precision}"
                );
            }
        }
    }
}

#[test]
fn membership_uses_the_rational_scale_of_a_symbolic_displacement() {
    let root = Real::from(2).sqrt().unwrap();
    let point = &root * Real::from(Rational::fraction(1, 32).unwrap());
    let ball = RealBall::new(Real::zero(), Rational::fraction(1, 8).unwrap()).unwrap();
    // 1 < sqrt(2) < 2. At precision zero the computable root's
    // one-unit enclosure, scaled by 1/32, already fits in the ball.
    let singleton = RealBall::point(Real::zero());
    let narrow = RealBall::new(Real::zero(), Rational::fraction(1, 24).unwrap()).unwrap();
    for point in [point.clone(), -point] {
        assert_eq!(ball.classify_point(&point, 0), Ok(BallRelation::Contained));
        assert_eq!(
            singleton.classify_point(&point, -2),
            Ok(BallRelation::Excluded)
        );
        // sqrt(2)/32 > 1/24 since 2 > (4/3)^2. The coarser
        // rational bounds still straddle the radius, so refinement matters.
        assert_eq!(
            narrow.classify_point(&point, 0),
            Ok(BallRelation::Unresolved)
        );
        assert_eq!(
            narrow.classify_point(&point, -12),
            Ok(BallRelation::Excluded)
        );
    }
}
