set -euo pipefail
q=$(cd "$(dirname "$0")" && pwd)
repo=/mnt/development/csgrs
for version in fixed before direct; do
  case $version in
    fixed|before)
      rev=c9f1f9ac5
      if test "$version" = before; then rev=0426a60b6; fi
      # Clean tracked-source snapshot, preserving the common build paths and locks.
      test "$q" = /mnt/development/ball-membership.DrnGv3dN/history
      rm -rf "$q/csgrs"
      mkdir "$q/csgrs"
      git -C "$repo" archive "$rev" | tar -xm -C "$q/csgrs";;
    direct) cp "$q/../direct.rs" "$q/csgrs/crates/hyperinterval/src/real_ball.rs";;
  esac
  for kind in trace native wasm life usable test; do
    bash "$q/build.sh" "$version" "$kind" >"$q/logs/build-$version-$kind" 2>&1 || { tail -20 "$q/logs/build-$version-$kind"; exit 1; }
  done
done
python3 "$q/metrics.py"
