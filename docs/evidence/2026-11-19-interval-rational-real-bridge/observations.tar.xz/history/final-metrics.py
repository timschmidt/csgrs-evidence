from pathlib import Path
import ast,json
from image_metrics import sizes
from wasm_metrics import wasm
s=Path(__file__).resolve().parent
log=s/'logs'
def profile(v):
 stack={};heap={}; usable={}
 for i in range(1,17):
  for line in (log/f'{v}-life-{i}').read_text().splitlines():
   r=line.split('|')
   if r[0]=='STACK':
    key=','.join(r[1:3]);stack[key]=max(stack.get(key,0),int(r[-1]))
   if r[0]=='HEAP':
    row=ast.literal_eval(r[-1]); assert heap.setdefault(r[1],row)==row
 for line in (log/f'{v}-usable').read_text().splitlines():
  k,_,s=line.split('|');usable[k]=ast.literal_eval(s)
 traces={r[1]:r[2:] for line in (log/f'{v}-trace').read_text().splitlines() if (r:=line.split('|'))[0]=='TRACE'}
 headroom=min(int(l.split()[-1]) for i in range(1,17) for l in (log/f'{v}-guard-{i}').read_text().splitlines())
 return dict(stack=stack,heap=heap,usable=usable,traces=traces,headroom=headroom,rss=(log/f'{v}-rss').read_text().strip())
profiles={v:profile(v) for v in ['fixed','before','direct','outlined','bridge','fallback']}
new={4,5,6,7,8,9,10,11,18,19}
for v in ['direct','outlined','bridge','fallback']:
 out={}; ctrl=[]
 for suffix in ['-native','-test','.wasm','-trace','-life','-usable']:
  vals=[]
  for version in ['fixed','before',v]:
   p=s/'images'/(version+suffix)
   vals.append(sizes(p) if suffix!='.wasm' else dict(file=p.stat().st_size,code=wasm(p)))
  a,b,c=vals
  out[suffix]={}
  for k in a.keys()|b.keys()|c.keys():
   x,y,z=(d.get(k,0) for d in vals)
   bi,pi,bc,pc=(1024,5,4096,10) if suffix=='.wasm' else ((1024,.5,4096,1) if k=='function_union' else (4096,1,16384,2))
   d=max(0,z-y);t=max(0,y-x)+d
   ok=d<=bi and 100*d<=pi*y and t<=bc and 100*t<=pc*x
   out[suffix][k]=[x,y,z,d,t,ok]
   if not ok:ctrl.append((suffix,k,x,y,z))
 a,b,c=[profiles[w] for w in ['fixed','before',v]]
 stackfail=[];heapdiff=[];tracediff=[]
 for k in b['stack']:
  x,y,z=[q['stack'][k] for q in [a,b,c]];d=max(0,z-y);t=max(0,y-x)+d
  if d>128 or d*100>y or t>256 or t*100>2*x:stackfail.append((k,x,y,z))
 for k in b['heap']:
  if b['heap'][k][4]!=c['heap'][k][4]:heapdiff.append((k,c['heap'][k][4]-b['heap'][k][4]))
  if b['traces'][k][1]!=c['traces'][k][1]:tracediff.append(int(k))
 print(v,'sizes fail',ctrl,'stack fail',stackfail,'heap peak changes',heapdiff,'control trace changes',sorted(set(tracediff)-new),'new trace changes',sorted(set(tracediff)&new),'headroom',c['headroom'])
 (s/f'{v}-sizes.json').write_text(json.dumps(out,indent=2)+'\n')
(s/'profiles.json').write_text(json.dumps(profiles,indent=2)+'\n')
