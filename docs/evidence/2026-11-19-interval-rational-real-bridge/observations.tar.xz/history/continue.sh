set -euo pipefail
q=$(cd "$(dirname "$0")" && pwd)
repo=/mnt/development/csgrs
while ! test -s "$q/direct-sizes.json"; do
 if test -s "$q/logs/qualification-result" && ! rg -q 'sizes fail' "$q/logs/qualification-result"; then cat "$q/logs/qualification-result"; exit 1; fi
 sleep 2
done
cp "$repo/crates/hyperinterval/src/rational.rs" "$q/csgrs/crates/hyperinterval/src/rational.rs"
for v in outlined bridge; do
 x="$q/../outlined.rs"
 if test "$v" = bridge;then x="$q/../pre-ball.rs"; fi
 cp "$x" "$q/csgrs/crates/hyperinterval/src/real_ball.rs"
 for kind in trace native wasm life usable test; do
  bash "$q/build.sh" "$v" "$kind" > "$q/logs/build-$v-$kind" 2>&1 || { tail -20 "$q/logs/build-$v-$kind"; exit 1; }
 done
done
python3 "$q/all-metrics.py"
