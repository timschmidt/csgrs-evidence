set -eu
q=$(cd "$(dirname "$0")" && pwd)
# Both builds and the four archived witness runs must finish before timing.
while ! grep -q 'test result: ok' "$q/logs/fallback-rational-suite" 2>/dev/null; do
 if test -s "$q/logs/fallback-run"; then cat "$q/logs/fallback-run";exit 1;fi
 sleep 2
done
python3 "$q/timing.py" &
first=$!
python3 "$q/timing2.py" &
second=$!
wait "$first"
wait "$second"
