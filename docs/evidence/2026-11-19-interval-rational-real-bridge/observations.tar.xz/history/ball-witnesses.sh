set -euo pipefail
q=$(cd "$(dirname "$0")" && pwd)
source "$q/../env"
cd "$q/csgrs"
cp "$w/old/real_ball_boundary.rs" crates/hyperinterval/tests/real_ball_boundary.rs
cp "$w/ball-expanded.rs" crates/hyperinterval/tests/real_ball_enclosure.rs
for v in before direct outlined; do
 case "$v" in before) p=pre-ball;;*) p=$v;; esac
 cp "$w/$p.rs" crates/hyperinterval/src/real_ball.rs
 export CARGO_TARGET_DIR="$q/target-owner"
 for suite in real_ball_enclosure real_ball_boundary;do
  args=()
  if test "$suite" = real_ball_boundary;then args=(--skip symbolic_membership_preserves_uncertainty_and_cancellation_on_retry);fi
  status=0
  cargo +1.95.0 test --release --locked -p hyperinterval --features real-ball --test "$suite" -- "${args[@]}" > "$q/logs/$v-original-$suite" 2>&1 || status=$?
  if test "$v" = before;then test "$status" = 101 && rg -q 'test result: FAILED.' "$q/logs/$v-original-$suite";else test "$status" = 0;fi
 done
 status=0
 cargo +1.95.0 test --release --locked -p hyperinterval --features real-ball --test real_ball_boundary -- symbolic_membership_preserves_uncertainty_and_cancellation_on_retry --exact > "$q/logs/$v-signal" 2>&1 || status=$?
 test "$status" = 101 && rg -q 'left: Ok\(Excluded\)' "$q/logs/$v-signal"
done
