use hyperinterval::{RationalInterval,IntervalError};
use hyperreal::{Real,Rational};
use std::sync::{Arc,atomic::{AtomicBool,Ordering}};
pub fn fixture(i:u32)->(u32,Real,i32) {
    let scale=Rational::fraction(if i%2==0{-1}else{1},3).unwrap();
    let p=[-16,-64,0,-96,-24][(i/4) as usize];
    let point=if i%4<2 {Real::from(&scale * Rational::from(7))} else {Real::from(scale)*Real::from(2).sqrt().unwrap()};
    (i,point,p)
}
pub fn observe(i:&u32,v:&Real,p:i32)->u32{
    let mut reader=v.clone();
    if *i>=12 && i%4>=2 {
        if *i>=16 {enclosure(&reader,p).unwrap();}
        let stop=Arc::new(AtomicBool::new(true));
        reader.abort(stop.clone());
        assert_eq!(enclosure(&reader,p),Err(IntervalError::EnclosureUnavailable));
        stop.store(false,Ordering::Relaxed);
    }
    let result=enclosure(&reader,p).unwrap();
    let restored=result.scale(&Rational::from(if i%2==0{-3}else{3}));
    if i%4<2 {assert_eq!(restored,RationalInterval::point(Rational::from(7)));1} else {
        let (lo,hi)=restored.bounds().unwrap();
        assert!(lo>=&Rational::zero() && lo*lo < Rational::from(2) && hi*hi>Rational::from(2));
        2
    }
}
#[unsafe(no_mangle)]
pub extern "C" fn ball_verdict(i:u32)->u32 {let (a,b,p)=fixture(i);observe(&a,&b,p)}
fn enclosure(point: &Real, p: i32) -> Result<RationalInterval, IntervalError> {
    RationalInterval::from_real(point, p)
}
