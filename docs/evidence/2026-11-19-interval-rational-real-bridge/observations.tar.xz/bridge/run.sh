set -euo pipefail
s=$(cd "$(dirname "$0")" && pwd)
source "$s/../env"
for stage in base api; do
 cat "$s/common" "$s/$stage-fn" > "$s/client/src/lib.rs"
 if test "$stage" = api;then cp /mnt/development/csgrs/crates/hyperinterval/src/rational.rs "$s/csgrs/crates/hyperinterval/src/rational.rs";fi
 for kind in trace native wasm life usable; do
   bash "$s/build.sh" "$stage" "$kind" > "$s/logs/build-$stage-$kind" 2>&1 || { tail -25 "$s/logs/build-$stage-$kind"; exit 1; }
 done
done
