Phase 3 certified rational point enclosures and closed-ball membership, November 2026.
Retained code and original four-test public suite: 4ad0c199c. Preceding: 0426a60b6.
The bridge feature is hyperreal. The rational-only build retains its original surface.
The scalar supplies certified rational bounds; Hyperinterval validates order, owns
the endpoints and supports subsequent exact set arithmetic. The scalar sets the
computable precision, cancellation and cache contract. It does not bound total work.
The MPFR case checks both directed 512-bit endpoints of pi at three scales and
five requests. The other two mathematical tests include independent square
relations, opposite signs, exact rationals at extreme precisions, and cold/warm
cancellation and retry. The fourth test compares complete checked-call dispatch
receipts at three scales and precisions. Test intermediates in portable-* are
the separate first three portable tests; the complete suite has four tests.
final-native-artifacts and final-artifacts refer to the complete registered suite.
The complete production and instrumented clients used Rust 1.95.0 release.
Production-only consumers are compared on the same final code. No runtime trend
is inferred from single-process times when comparing different binaries.

For reproducibility create a private directory under /mnt/development; set TMPDIR,
Cargo target/cache and GMP_MPFR_SYS_CACHE there. The recorded env and shell
commands assume a csgrs repo at /mnt/development/csgrs. Absolute temporary paths
in transcripts identify the original run. Source snapshots are identified by git
commit. Directory "history" contains the original twenty membership fixtures,
complete allocator, RSS and guarded stack observers, build driver, two trial
sources and their archived predecessor witnesses. In a fresh scratch area, put
a clean git-archive checkout of each revision in history/csgrs, and run
bash history/build.sh STAGE KIND for native, trace, wasm, life, usable and test.
The fixed stage is c9f1f9ac5, before is 0426a60b6, direct replaces real_ball.rs
with direct.rs, outlined combines outlined.rs with the retained rational.rs,
and bridge applies the retained rational.rs only. The historical test image
always builds the unmodified real_bridge.rs on the appropriate source revision.
Run history/all-metrics.py after restoring the recorded stage images and logs.
An additional, discarded change to the MPFR test in real_bridge.rs was priced
as expanded-test; the final separate libtest carries the MPFR case instead.

Directory "bridge" contains the same complete-lifetime instruments around a new
consumer. Stage base: 0426a60b6, client/src/lib.rs = common + base-fn.
Stage api: 4ad0c199c, client/src/lib.rs = common + api-fn. Build both from the
same checkout path and Cargo lock. Native, trace, life, usable and wasm are
five separately linked and executed targets. The clients reconstruct signed
scaled symbolic or rational fixtures and then consume the resulting interval
by scaling, checking its endpoints, and dropping all state. Twenty independent
fixtures, two invocations in the heap observer, 16 guarded processes, and two
stack paint patterns per temperature. WASM validates twenty per repetition
twice on each of two instances. stack.mjs uses the owner's wasm-dis/wasm-as
instrumentation; invoke node bridge/stack.mjs IMAGE DISASSEMBLY. Output records
both complete-call reservations and writes. Before and after modules are
byte-identical. Full native and WASI registered tests additionally exercise
GMP/MPFR; the Debian WASI libc, Clang 19 wasm32 builtins, and lld were
downloaded and unpacked into this run's scratch directory. The WASI test RSS
samples include the Node engine and all RSS samples include process startup.
The guarded trace and heap/stack data are independent of the portable smoke
observer. Trial status and immutable program accounts are in the main ledger.

All images have hashes or final section sizes in this record; build caches and
executables are disposable. Use Python 3, both recorded Rust compilers, Node,
Clang 19, readelf, objcopy, GNU coreutils, Binaryen and working Linux setarch/
taskset support. The original historical accounting script reports fixed-to-before
debt even when the measured source change incurs zero incremental growth.

The rational-only trial uses the displaced-scalar fallback from 4f05060aa,
recompiled against the same current source and qualification harness. Compare
history/images/{before,fallback}-native with timing.py and timing2.py, after
building is complete. These run 18 alternating pairs each on CPUs 3 and 5 with
ASLR disabled and 2,000 fresh or warm calls per row. The full WASI suite report
identifies each original test requiring native OS support, the independent
guest replays, and 450 matched rational dispatch windows.
