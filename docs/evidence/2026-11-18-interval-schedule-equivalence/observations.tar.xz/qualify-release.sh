set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export CARGO_TARGET_DIR="$s/release" CARGO_BUILD_JOBS=6
cargo +1.95.0 test --release --locked -p hyperpath --all-features --test schedule_equivalence >"$s/logs/release-test" 2>&1
cargo +1.95.0 run --release --locked -p hyperpath --example certified_schedule >"$s/logs/certified-schedule" 2>&1
