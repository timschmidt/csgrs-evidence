set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export CARGO_TARGET_DIR="$s/fuzz-target" CARGO_BUILD_JOBS=5
cargo +1.95.0 fmt --all -- --check
rustfmt +1.95.0 --edition 2024 --check crates/hyperpath/fuzz/fuzz_targets/schedule_equivalence.rs
cargo +1.95.0 clippy --locked --manifest-path crates/hyperpath/fuzz/Cargo.toml --bin schedule_equivalence -- -D warnings
python3 -B scripts/test-interval-inventory.py
git diff --check
