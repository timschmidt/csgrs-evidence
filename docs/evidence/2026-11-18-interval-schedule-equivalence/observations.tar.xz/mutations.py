from pathlib import Path
import subprocess,shutil,sys,os
s=Path(__file__).resolve().parent
root=s/'control'
def run(name,*args):
    with (s/'logs'/name).open('wb') as f:
        return subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT).returncode
for rel in ['tests/schedule_equivalence.rs','tests/support/schedule_equivalence.rs', *('fuzz/seeds/schedule_equivalence/'+p.name for p in Path('crates/hyperpath/fuzz/seeds/schedule_equivalence').iterdir())]:
    src=Path('crates/hyperpath')/rel
    dest=root/src
    dest.parent.mkdir(exist_ok=True,parents=True)
    shutil.copyfile(src,dest)
p=root/'crates/hyperpath/src/routing/lookahead.rs'
orig=p.read_text()
cases={'braking-entry':('for edge in (0..route.len()).rev()', 'for edge in (1..route.len()).rev()'), 'acceleration-row':('travel_budget.clone() - (end_sq.clone() - start_sq.clone())','travel_budget.clone() - (start_sq.clone() - end_sq.clone())'), 'reversal-stop':('CornerLookaheadJoinClass::ReversalStop => Real::zero(),','CornerLookaheadJoinClass::ReversalStop => max_feed_rate.clone(),')}
args=['cargo','+1.95.0','test','--locked','-p','hyperpath','--test','schedule_equivalence']
assert run('mutation-control',*args)==0
try:
    for name,(a,b) in cases.items():
        assert orig.count(a)==1
        p.write_text(orig.replace(a,b))
        assert run(name+'.patch','git','diff','--',str(p))==0
        assert run('mutation-'+name,*args)==101
        msg=(s/'logs'/('mutation-'+name)).read_text()
        assert 'test result: FAILED.' in msg and 'panicked at' in msg
        print(name, 'detected',flush=True)
finally:
    p.write_text(orig)
assert run('mutation-restored',*args)==0
