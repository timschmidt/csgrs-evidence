from pathlib import Path
import subprocess as sp,itertools,json,os,re,shutil,hashlib,tomllib
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent
co=s/'mem-checkout'; app=s/'memclient';target=Path(os.environ['CARGO_TARGET_DIR'])
fixed='c9f1f9ac'; curr='7c3cd54d6'; extract='f8dd6e1b2'
if not co.exists():sp.run(['git','worktree','add','--quiet','--detach',str(co),fixed],check=True)
assert sp.check_output(['git','-C',co,'rev-parse','HEAD']).strip()==sp.check_output(['git','rev-parse',fixed]).strip()
(app/'Cargo.toml').write_text('[package]\nname="schedule-memory"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\n'+''.join(f'{dep}={{path="{co}/crates/{dep}"}}\n' for dep in ['hyperpath','hyperlimit','hyperreal']))
original=(s/'logs/client-current.lock').read_text().replace('name = "schedule-example"','name = "schedule-memory"')
(app/'Cargo.lock').write_text(original)
def vendor(t):
    return {(p['name'],p['version'],p['checksum']) for p in tomllib.loads(t)['package'] if 'source' in p}
for stage in ['fixed','current','extraction']:
    if stage=='current':sp.run(['git','-C',co,'checkout','--quiet','--detach',curr],check=True)
    if stage=='extraction':sp.run(['git','-C',co,'apply','-'],input=sp.check_output(['git','diff','--binary',extract+'^',extract]),check=True)
    sp.run(['cargo','+1.95.0','metadata','--offline','--format-version','1'],cwd=app,stdout=sp.DEVNULL,check=True)
    locked=(app/'Cargo.lock').read_text()
    assert vendor(locked)==vendor(original)
    (s/'logs'/('memory-'+stage+'.lock')).write_text(locked)
    sp.run(['cargo','+1.95.0','build','--locked','--release'],cwd=app,check=True)
    exe=target/'release/schedule-memory'
    def one(args):
        spans,policy,warm,pattern,rep=args
        # Each process has one measuring worker; RSS is Linux whole-process VmHWM in KiB.
        raw=sp.check_output([str(exe),str(spans),policy,str(warm),str(pattern)],stderr=sp.STDOUT,text=True)
        rows=[[int(i) for i in re.findall(r'-?\d+',line)] for line in raw.splitlines() if line.startswith('ROW')]
        assert len(rows)==5
        head=[int(i) for i in re.search(r'^HEADROOM (.+)$',raw,re.M).group(1).split()]
        assert head[-1]>=1024**2
        return dict(spans=spans,policy=policy,warm=warm,pattern=pattern,rep=rep,rows=rows,stack=head[3],headroom=head[4],rss_kib=int(re.search(r'^RSS (\d+)$',raw,re.M)[1]))
    cases=itertools.product((2,6),('strict','approx'),(0,1),(90,165),range(3))
    with ThreadPoolExecutor(max_workers=4) as pool: observations=list(pool.map(one,cases))
    (s/'logs'/('memory-'+stage+'.json')).write_text(json.dumps({'image':hashlib.sha256(exe.read_bytes()).hexdigest(),'observations':observations},separators=(',',':'))+'\n')
