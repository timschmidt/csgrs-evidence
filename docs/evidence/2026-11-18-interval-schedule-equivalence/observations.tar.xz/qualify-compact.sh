set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export PATH="/tmp/interval-refactor/tools/bin:$PATH" CARGO_BUILD_JOBS=8
export CARGO_TARGET_DIR="$s/compact-target"
export RUSTFLAGS="-C link-arg=-Wl,--compress-debug-sections=zlib"
mkdir -p "$s/compact-corpus"
cp crates/hyperpath/fuzz/seeds/schedule_equivalence/* "$s/compact-corpus/"
cargo +nightly fuzz run --fuzz-dir crates/hyperpath/fuzz --target-dir "$CARGO_TARGET_DIR" schedule_equivalence "$s/compact-corpus" -- -runs=10000 -max_len=15 -timeout=10 -rss_limit_mb=4096 -seed=20261118 -artifact_prefix="$s/artifacts/" >"$s/logs/compact-campaign" 2>&1
