from pathlib import Path
import subprocess as sp
s=Path(__file__).resolve().parent
for config in ['compact-target','fuzz-target']:
    exe=s/config/'x86_64-unknown-linux-gnu/release/schedule_equivalence'
    # Use a PC owned by the oracle and resolve it in the measured binary.
    symbols=sp.check_output(['nm','-nC',str(exe)],text=True)
    symbol=next(l for l in symbols.splitlines() if 'schedule_equivalence::oracle::Path>::check_report' in l and 'closure' not in l)
    output=sp.check_output(['addr2line','-e',str(exe),symbol.split()[0]],text=True).strip()
    assert 'schedule_equivalence.rs:' in output and '??' not in output
    print(config,symbol,output)
