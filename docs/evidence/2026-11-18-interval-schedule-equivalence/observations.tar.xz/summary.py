from pathlib import Path
import re,json,hashlib,subprocess
s=Path(__file__).resolve().parent
logs=s/'logs'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
native=[p for p in (s/'release/release/deps').glob('schedule_equivalence-*') if p.suffix!='.d']
assert len(native)==1
def image(p):
    return dict(file_bytes=p.stat().st_size, sha256=digest(p),qualification_capacity_bytes=64*1024**2,required_free_bytes=16*1024**2,remaining_bytes=64*1024**2-p.stat().st_size)
def tests(name):
    text=(logs/name).read_text()
    assert 'FAILED' not in text
    return sum(int(n) for n in re.findall(r'test result: ok\. (\d+) passed',text))
def campaign(name):
    text=(logs/name).read_text()
    m=re.search(r'#(\d+)\s+DONE\s+cov: (\d+) ft: (\d+) corp: (\d+)/(\d+)b lim: (\d+) exec/s: \d+ rss: (\d+)Mb',text)
    assert m and 'Done 10000 runs in' in text
    return dict(zip(('runs','coverage','features','corpus_entries','corpus_bytes','max_len','rss_mb'),map(int,m.groups())))
images={'release-test':image(native[0])}
for label,d in [('asan-uncompressed','fuzz-target'),('asan-compressed','compact-target')]:
    p=s/d/'x86_64-unknown-linux-gnu/release/schedule_equivalence'
    images[label]=image(p)
    (logs/(label+'-sections')).write_bytes(subprocess.check_output(['readelf','-SW',str(p)]))
    assert '.debug_info' in (logs/(label+'-sections')).read_text()
assert images['release-test']['remaining_bytes']>=16*1024**2
assert images['asan-compressed']['remaining_bytes']>=16*1024**2
assert images['asan-uncompressed']['remaining_bytes']<16*1024**2
result={'images':images,'tests':{k:tests(k) for k in ['owner-all','owner-min','release-test','stable','rebased-path-tests','mutation-control','mutation-restored']},'campaigns':{n:campaign(n) for n in ['fuzz-campaign','compact-campaign']}}
(logs/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
