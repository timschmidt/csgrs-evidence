set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export PATH="/tmp/interval-refactor/tools/bin:$PATH" CARGO_TARGET_DIR="$s/fuzz-target" CARGO_BUILD_JOBS=8
cargo +nightly fuzz run --target-dir "$s/fuzz-target" --fuzz-dir crates/hyperpath/fuzz schedule_equivalence "$s/corpus" -- -runs=10000 -max_len=15 -max_total_time=240 -timeout=10 -rss_limit_mb=4096 -seed=20261118 -artifact_prefix="$s/artifacts/" >"$s/logs/fuzz-campaign" 2>&1
