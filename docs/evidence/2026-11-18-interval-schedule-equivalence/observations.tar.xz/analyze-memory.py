from pathlib import Path
import json,itertools
s=Path(__file__).resolve().parent
files=[json.loads((s/'logs'/f'memory-{label}.json').read_text())['observations'] for label in ['fixed','current','extraction']]
assert all(len(v)==48 for v in files)
groups=[]
for spans,policy,warm in itertools.product((2,6),('strict','approx'),(0,1)):
    sets=[[o for o in v if (o['spans'],o['policy'],o['warm'])==(spans,policy,warm)] for v in files]
    assert all(len(samples)==6 for samples in sets)
    met={}
    def add(name,get,absolute,percentage):
        vals=[max(get(v) for v in samples) for samples in sets]
        x,y,z=vals
        increment=max(0,z-y)
        cum=max(0,y-x)+increment
        met[name]=dict(values=vals,increment=increment,cumulative=cum,passes=increment<=absolute and cum<=absolute and increment*100<=y*percentage and cum*100<=x*percentage)
    add('whole_call_stack',lambda v:v['stack'],128,1)
    for i in range(5):
        add('peak_requested_'+str(i),lambda v:v['rows'][i][5],512,2)
        add('live_requested_'+str(i),lambda v:v['rows'][i][6],0 if i==4 else 256,2)
    assert all(v['rows'][-1][5]<=2*1024**2 for samples in sets for v in samples)
    def ranges(fn):
        return [[min(fn(v) for v in samples),max(fn(v) for v in samples)] for samples in sets]
    extras={k:ranges(fn) for k,fn in {
        'postdrop_live_requested':lambda v:v['rows'][-1][6],
        'postdrop_live_usable':lambda v:v['rows'][-1][9],
        'peak_usable':lambda v:v['rows'][-1][8],
        'usable_traffic':lambda v:v['rows'][-1][7],
        'alloc_events':lambda v:v['rows'][-1][1],
        'free_events':lambda v:v['rows'][-1][2],
        'realloc_events':lambda v:v['rows'][-1][3],
        'requested_traffic':lambda v:v['rows'][-1][4],
        'rss_kib':lambda v:v['rss_kib'],
        'headroom':lambda v:v['headroom']}.items()}
    groups.append(dict(spans=spans,policy=policy,warm=warm,metrics=met,observations=extras))
(s/'logs/memory-comparison.json').write_text(json.dumps(groups,indent=2)+'\n')
for g in groups:
 m=g['metrics']
 print(g['spans'],g['policy'],g['warm'],m['whole_call_stack']['values'],m['peak_requested_4']['values'],[(k,v['increment'],v['cumulative']) for k,v in m.items() if not v['passes']])
