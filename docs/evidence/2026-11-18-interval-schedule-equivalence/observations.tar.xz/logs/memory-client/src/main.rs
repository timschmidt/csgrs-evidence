mod allocation;
use allocation::{AllocationStats,observe};
use hyperlimit::{Point2,PredicatePolicy};
use hyperpath::{LinePathSegment, FeedPathElement, TangentSpan, LookaheadFeedPlanningLimits, plan_lookahead_feed_schedule, certify_lookahead_feed_schedule};
use std::ffi::c_void;
unsafe extern "C" {fn measure_stack(call:extern "C" fn(*mut c_void),data:*mut c_void,warm:i32,pattern:u8)->usize;}
struct Job { six:bool, policy:PredicatePolicy, rows:[Option<AllocationStats>;5] }
extern "C" fn worker(ptr:*mut c_void) {
    let job=unsafe { &mut *ptr.cast::<Job>() };
    let (_, cleanup)=observe(||{
        let ps=if job.six {&[(0,0),(3,4),(-1,7),(-4,3),(-1,7),(5,15),(9,12)][..]}else{&[(0,0),(8,0),(10,0)][..]};
        let point=|(x,y):(i64,i64)|Point2::new(x.into(),y.into());
        let lines:Vec<_>=ps.windows(2).map(|ab|LinePathSegment::new(point(ab[0]),point(ab[1]),job.policy).unwrap()).collect();
        let spans:Vec<_>=lines.iter().map(TangentSpan::from_line_segment).collect();
        let route:Vec<_>=lines.into_iter().map(FeedPathElement::Line).collect();
        let limits=LookaheadFeedPlanningLimits{maximum_entry_feed:0.into(),maximum_corner_feeds:vec![10.into();route.len()-1],corner_radii:vec![3.into();route.len()-1],maximum_exit_feed:0.into()};
        job.rows[0]=Some(AllocationStats::snapshot());
        let plan=plan_lookahead_feed_schedule(&route,&spans,&limits,10.into(),1.into(),job.policy).unwrap();
        assert!(plan.all_satisfied());
        job.rows[1]=Some(AllocationStats::snapshot());
        let replay=certify_lookahead_feed_schedule(&route,&spans,&plan.schedule,10.into(),1.into(),job.policy).unwrap();
        assert!(replay.all_satisfied());
        job.rows[2]=Some(AllocationStats::snapshot());
        let mut edited=plan.schedule.clone();
        edited.entry_feed=11.into();
        let bad=certify_lookahead_feed_schedule(&route,&spans,&edited,10.into(),1.into(),job.policy).unwrap();
        assert_eq!(bad.first_unsatisfied_span(), Some(0));
        job.rows[3]=Some(AllocationStats::snapshot());
        drop((bad,edited,replay,plan,limits,route,spans));
    });
    job.rows[4]=Some(cleanup);
}
fn main(){
    let args:Vec<_>=std::env::args().collect();
    let mut job=Job{six:args[1]=="6",policy:if args[2]=="strict"{PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512},rows:[None;5]};
    let stack=unsafe{measure_stack(worker, (&raw mut job).cast(), args[3].parse().unwrap(),args[4].parse().unwrap())};
    for (i,row) in job.rows.iter().enumerate(){let r=row.unwrap();println!("ROW {i} {:?} {:?}",r.values(),r.usable());}
    println!("STACK {stack}");
    let proc=std::fs::read_to_string("/proc/self/status").unwrap();
    let hwm=proc.lines().find(|l|l.starts_with("VmHWM:")).unwrap().split_whitespace().nth(1).unwrap();
    println!("RSS {hwm}");
}
