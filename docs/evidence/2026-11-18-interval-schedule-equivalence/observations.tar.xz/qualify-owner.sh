set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export CARGO_TARGET_DIR="$s/native" CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=8
cargo +1.95.0 test --locked -p hyperpath --all-targets --all-features >"$s/logs/owner-all" 2>&1
cargo +1.95.0 test --locked -p hyperpath --no-default-features >"$s/logs/owner-min" 2>&1
cargo +1.95.0 test --locked -p hyperpath --doc --all-features >"$s/logs/owner-doc" 2>&1
cargo +1.95.0 clippy --locked -p hyperpath --all-features --all-targets -- -D warnings >"$s/logs/clippy" 2>&1
RUSTDOCFLAGS="-D warnings" cargo +1.95.0 doc --locked -p hyperpath --no-deps --all-features >"$s/logs/doc" 2>&1
