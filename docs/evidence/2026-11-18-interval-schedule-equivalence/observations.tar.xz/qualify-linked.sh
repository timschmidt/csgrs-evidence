set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export CARGO_TARGET_DIR="$s/linked-target" CARGO_BUILD_JOBS=5
python3 "$s/linked.py" >"$s/logs/linked" 2>&1
