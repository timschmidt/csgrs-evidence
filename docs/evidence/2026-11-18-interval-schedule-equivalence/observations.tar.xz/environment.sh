export CARGO_HOME=/dev/shm/interval-axis-cost/cargo-home
export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/owner-target
export TMPDIR=/dev/shm/interval-bisection/tmp
export CARGO_NET_OFFLINE=true
export CARGO_INCREMENTAL=0
