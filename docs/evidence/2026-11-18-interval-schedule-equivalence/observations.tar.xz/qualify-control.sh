set -eu
. /dev/shm/interval-bisection/env
s=/dev/shm/interval-schedule-equivalence
export CARGO_TARGET_DIR="$s/control-target" CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=6
python3 "$s/mutations.py"
