from pathlib import Path
import subprocess as sp, shutil, json, hashlib, os, re
s=Path(__file__).resolve().parent
checkout=s/'linked-control'
client=s/'standalone'
targets=['x86_64-unknown-linux-gnu','wasm32-unknown-unknown']
extract='f8dd6e1b251e9377f4010268f1ab00824df77a58'
def cmd(args,at=client,**kw):
    return sp.run(args,cwd=at,check=True,**kw)
def ileb(data,pos):
    n=0; shift=0
    while True:
        val=data[pos]; pos+=1
        n|=(val&127)<<shift
        if val<128: return n,pos
        shift+=7
def inspect(target):
    p=Path(os.environ['CARGO_TARGET_DIR'])/target/'release'/('schedule-example'+('.wasm' if target.startswith('wasm') else ''))
    b=p.read_bytes()
    out={'file_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    if target.startswith('wasm'):
        off=8
        while off<len(b):
            sid=b[off];size,off=ileb(b,off+1)
            if sid==10:out['code_bytes']=size
            off+=size
        assert off==len(b) and out['code_bytes']>0
        cmd(['node','-e','const b=require("fs").readFileSync(process.argv[1]);const m=new WebAssembly.Module(b);for(let i=0;i<2;i++){if(new WebAssembly.Instance(m,{}).exports.main(0,0)!==0)process.exit(1)}',str(p)])
    else:
        cmd([str(p)])
        sizes={}
        for line in sp.check_output(['size','-A',str(p)],text=True).splitlines():
            cols=line.split()
            if len(cols)==3 and cols[0].startswith('.'):sizes[cols[0]]=int(cols[1])
        out.update(sections=sizes)
        ranges=[]
        for line in sp.check_output(['nm','-S','--defined-only',str(p)],text=True).splitlines():
            fields=line.split(None,3)
            if len(fields)==4 and fields[2] in ('t','T','w','W'):
                a=int(fields[0],16); z=int(fields[1],16)
                ranges.append((a,a+z))
        end=0; union=0
        for a,z in sorted(ranges):
            union+=max(0,z-max(a,end));end=max(end,z)
        out['defined_function_range_union_bytes']=union
    return out
rows={'current':{t:inspect(t) for t in targets}}
patch=sp.check_output(['git','diff','--binary',extract+'^',extract])
cmd(['git','apply','--check','-'],checkout,input=patch)
cmd(['git','apply','-'],checkout,input=patch)
shutil.copyfile(client/'Cargo.lock',s/'logs/client-current.lock')
cmd(['cargo','+1.95.0','generate-lockfile','--offline'])
shutil.copyfile(client/'Cargo.lock',s/'logs/client-extraction.lock')
rows['rebased_extraction']={}
for t in targets:
    for pkg in ['hyperpath','schedule-example']:
        cmd(['cargo','+1.95.0','clean','--release','--target',t,'-p',pkg])
    cmd(['cargo','+1.95.0','build','--locked','--release','--target',t])
    rows['rebased_extraction'][t]=inspect(t)
(s/'logs/extraction-linked.json').write_text(json.dumps(rows,indent=2)+'\n')
