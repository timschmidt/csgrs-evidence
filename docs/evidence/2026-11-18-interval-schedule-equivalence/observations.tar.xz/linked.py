"""Build the public example as a native/WASM client at one physical path twice."""
from pathlib import Path
import shutil,subprocess,hashlib,json,os
s=Path(__file__).resolve().parent
checkout=s/'linked-control'
cwd=Path.cwd()
client=s/'standalone'
def run(*cmd,cwd=client):
    subprocess.run(cmd,cwd=cwd,check=True)
run('git','worktree','add','--quiet','--detach',str(checkout),'7c3cd54d6',cwd=cwd)
client.mkdir()
(client/'src').mkdir()
deps=['hyperpath','hyperlimit','hyperreal']
(client/'Cargo.toml').write_text('[package]\nname="schedule-example"\nversion="0.0.0"\nedition="2024"\n[dependencies]\n'+''.join(f'{dep}={{path="{checkout}/crates/{dep}"}}\n' for dep in deps))
shutil.copyfile(checkout/'crates/hyperpath/examples/certified_schedule.rs',client/'src/main.rs')
shutil.copyfile(checkout/'Cargo.lock',client/'Cargo.lock')
run('cargo','+1.95.0','metadata','--offline','--format-version','1','--no-deps')
run('cargo','+1.95.0','build','--offline','--release')
rows=[]
for rev in ('preceding','proposed'):
    if rev=='proposed':
        files=['fuzz/Cargo.toml','fuzz/README.md','tests/schedule_equivalence.rs','tests/support/schedule_equivalence.rs','fuzz/fuzz_targets/schedule_equivalence.rs',*['fuzz/seeds/schedule_equivalence/'+p.name for p in (cwd/'crates/hyperpath/fuzz/seeds/schedule_equivalence').iterdir()]]
        for f in files:
            rel=Path('crates/hyperpath')/f
            dest=checkout/rel
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(cwd/rel,dest)
    for target in ('x86_64-unknown-linux-gnu','wasm32-unknown-unknown'):
        # Rebuild consumer and owner for each image at the same paths.
        for pkg in ['hyperpath','schedule-example']:
            run('cargo','+1.95.0','clean','--release','--target',target,'-p',pkg)
        run('cargo','+1.95.0','build','--locked','--release','--target',target)
        file=Path(os.environ['CARGO_TARGET_DIR'])/target/'release'/('schedule-example'+('.wasm' if target.startswith('wasm') else ''))
        if target.startswith('x86'):
            run(str(file))
        b=file.read_bytes()
        rows.append(dict(revision=rev,target=target,file_bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(s/'logs/public-client.json').write_text(json.dumps(rows,indent=2)+'\n')
for i in (0,1):
    assert rows[i]['sha256']==rows[i+2]['sha256'], rows
