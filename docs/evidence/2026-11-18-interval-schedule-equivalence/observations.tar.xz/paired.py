"""Compare the public receipts of current production and the rebased, unretained extraction."""
from pathlib import Path
import subprocess as sp,shutil,hashlib,json,lzma
s=Path(__file__).resolve().parent
root=s/'migration'
head='7c3cd54d6'
reject='f8dd6e1b251e9377f4010268f1ab00824df77a58'
def run(args,cwd=root,**kw):
    return sp.run(args,cwd=cwd,check=True,**kw)
sp.run(['git','worktree','add','--quiet','--detach',str(root),head],check=True)
patch=sp.check_output(['git','diff','--binary',reject+'^',reject])
rows={}
for which in ('current','extraction'):
    if which=='extraction':
        run(['git','apply','--check','-'],input=patch)
        run(['git','apply','-'],input=patch)
    hyper=Path('crates/hyperpath')
    for f in [hyper/'tests/schedule_equivalence.rs',hyper/'tests/support/schedule_equivalence.rs',*sorted((hyper/'fuzz/seeds/schedule_equivalence').iterdir())]:
        dest=root/f
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(f,dest)
    p=root/hyper/'tests/support/schedule_equivalence.rs'
    code=p.read_text()
    marker='        assert_eq!(row.constraint_index, i);'
    assert code.count(marker)==1
    p.write_text(code.replace(marker,'        println!("RECEIPT {i} {name} {kind:?} {:?}", row.status);\n'+marker))
    log=s/('paired-'+which+'.log')
    with log.open('wb') as f:
        run(['cargo','+1.95.0','test','--locked','-p','hyperpath','--test','schedule_equivalence','--','--nocapture','--test-threads=1'],stdout=f,stderr=sp.STDOUT)
    content=log.read_bytes()
    assert b'test result: ok. 2 passed;' in content
    receipts=b''.join(line[line.index(b'RECEIPT '):] for line in content.splitlines(keepends=True) if b'RECEIPT ' in line)
    out=s/'logs'/('paired-'+which+'.xz')
    out.write_bytes(lzma.compress(receipts))
    rows[which]={'rows':receipts.count(b'\n'),'bytes':len(receipts),'sha256':hashlib.sha256(receipts).hexdigest(),'checkout':head,'patch':None if which=='current' else reject}
    assert rows[which]['rows']>1000
(s/'logs/paired.json').write_text(json.dumps(rows,indent=2)+'\n')
assert rows['current']['sha256']==rows['extraction']['sha256']
with (s/'logs/rebased-path-tests').open('wb') as f:
    run(['cargo','+1.95.0','test','--locked','-p','hyperpath','--all-targets','--all-features'],stdout=f,stderr=sp.STDOUT)
