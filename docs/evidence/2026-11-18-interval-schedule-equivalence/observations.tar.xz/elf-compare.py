import hashlib,struct,zlib,json
from pathlib import Path
s=Path(__file__).resolve().parent
def sections(which):
    b=(s/which/'x86_64-unknown-linux-gnu/release/schedule_equivalence').read_bytes()
    at=struct.unpack_from('<Q',b,40)[0]; stride,n,strings=struct.unpack_from('<HHH',b,58)
    entries=[struct.unpack_from('<IIQQQQIIQQ',b,at+i*stride) for i in range(n)]
    strings=entries[strings]; names=b[strings[4]:strings[4]+strings[5]]
    out={}
    for name,kind,flags,address,off,size,*rest in entries:
        name=names[name:names.index(0,name)].decode()
        if name=='.text' or name.startswith('.debug_') or 'sancov' in name:
            raw=b[off:off+size]
            if flags&0x800:
                alg,_,length,align=struct.unpack_from('<IIQQ',raw)
                assert alg==1
                raw=zlib.decompress(raw[24:])
                assert len(raw)==length
            out[name]=dict(size=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressed=bool(flags&0x800))
    return out
data={k:sections(k) for k in ['fuzz-target','compact-target']}
(s/'logs/elf-comparison.json').write_text(json.dumps(data,indent=2)+'\n')
for name,v in data['fuzz-target'].items():
    other=data['compact-target'][name]
    print(name,v['sha256']==other['sha256'],v['size'],other['size'])
