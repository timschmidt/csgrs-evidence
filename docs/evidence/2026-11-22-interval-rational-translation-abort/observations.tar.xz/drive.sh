set -eu
H=/tmp/claude-1000/-mnt-development/374ec7d8-3b58-4db7-a419-a5fe884f8bb0/scratchpad/rrb/history
W=/mnt/development/.size-acct
mkdir -p "$W/images" "$W/logs" "$W/tmp"
cp -r "$H/client" "$H/life" "$H/usable" "$W/" 2>/dev/null || true
export TMPDIR="$W/tmp" CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=8 GMP_MPFR_SYS_CACHE="$W/gmp"
for st in 4ad0c199c 61c84c882 3664c7d08 62b99e887 ee5df2136; do
  rm -rf "${W:?}/csgrs"; mkdir "$W/csgrs"
  git -C /mnt/development/csgrs archive "$st" | tar x -m -C "$W/csgrs"
  for k in native wasm life usable; do
    export CARGO_TARGET_DIR="$W/target-$k"
    case $k in
      native) (cd "$W/client" && cargo +1.95.0 build --locked --release --bin ball-client) > "$W/logs/$st-$k.build" 2>&1
              cp "$CARGO_TARGET_DIR/release/ball-client" "$W/images/$st-native"
              setarch "$(uname -m)" -R taskset -c 3 "$W/images/$st-native" > "$W/logs/$st-native.run";;
      wasm) (cd "$W/client" && cargo +1.95.0 build --locked --release --target wasm32-unknown-unknown --lib) > "$W/logs/$st-$k.build" 2>&1
              cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/ball_client.wasm" "$W/images/$st.wasm";;
      life|usable) (cd "$W/$k" && cargo +1.95.0 build --locked --release) > "$W/logs/$st-$k.build" 2>&1
              cp "$CARGO_TARGET_DIR/release/ball-$k" "$W/images/$st-$k";;
    esac
    echo "$st $k ok"
  done
done
