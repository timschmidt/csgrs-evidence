Size accounting for the two rational-translation abort-flag changes, 22 November 2026.
3664c7d08: RealBall::classify_point reattaches the point's abort flag (preceding 61c84c882).
ea846698d: Hyperreal add/sub, offset certificate and cached pi minus three carry the sole
refining operand's flag (preceding 62b99e887). ee5df2136 differs from ea846698d only in
crates/hyperreal/benchmarks.md.

Ball membership client. Sources, Cargo.lock and observer crates are history/client, history/life
and history/usable in docs/evidence/2026-11-19-interval-rational-real-bridge/observations.tar.xz.
drive.sh rebuilt them with Rust 1.95.0 at c9f1f9ac5, 4ad0c199c, 61c84c882, 3664c7d08, 62b99e887
and ee5df2136 from git-archive checkouts at one path (/mnt/development/.size-acct/csgrs), one
target directory per kind. The c9f1f9ac5 stage ran first with archive mtimes; later stages were
extracted with tar -m, because archive mtimes made cargo reuse stale crates (first attempt failed
to compile at 4ad0c199c and was discarded). Native verdict output (logs/*-native.run) is identical
from 61c84c882 onward. stage-sizes.json lists file, .text, function_union and selected sections
(image_metrics.py and wasm_metrics.py from the 2026-11-19 record) with SHA-256 for every image.
Images and build caches were deleted after measurement.

caps-declared.json was written before the stage section sizes and Interface results were read.
Both changes were already merged, so the admission is retroactive.

Interface. interface/abort-size.yml ran on a temporary alumina-interface branch (deleted):
Interface ef5061183, firmware 9c874b2b8, Rust 1.100.0, trunk 0.21.14 release --locked (succeeded
at every stage), wasm-opt 133 -Oz per Trunk.toml. interface/run-45030377592.log is the full job log.
The deployed Pages build pins csgrs 20330cd30 and does not yet include either change.
