import sys
p, orig, name = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(orig).read()
M = {
 "no-tail-radius": ("let error = constant::<N>(|_, _| radius.clone())?;", "let error = constant::<N>(|_, _| zero.clone())?; let _ = &radius;"),
 "tube-without-zero-hull": ("&term.hull(&zero_matrix, &mut budget.arithmetic)?,", "&term,"),
 "compose-on-right": ("&local_end.mul_matrix(previous, &mut budget.arithmetic)?,", "&previous.mul_matrix(&local_end, &mut budget.arithmetic)?,"),
 "no-duration": ("|x, b| x.mul(h, b))?;", "|x, _| Ok(x.clone()))?; let _ = h;"),
 "no-geometric-factor": (""".div(
                    &one.sub(q, &mut budget.arithmetic)?,
                    precision,
                    &mut budget.arithmetic,
                )?
""", ""),
}
a, b = M[name]
assert s.count(a) == 1, name
open(p, 'w').write(s.replace(a, b))
