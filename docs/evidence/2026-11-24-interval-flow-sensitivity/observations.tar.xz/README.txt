Certified whole-horizon initial-state sensitivity, 24 November 2026

Phase 13 (plan 10.7). Rebuilds the 15 November prototype
(docs/evidence/2026-11-15-interval-flow-sensitivity), which was rejected on size
with its correctness corpus unfinished. Under the 24 November size policy,
size never blocks a new capability; this record completes the corpus.

Base: csgrs main 4ad38d77c. Feature: hyperdynamics `flow-sensitivity` = ["field"].
API: EvolutionReport::sensitivity(self: &Arc<Self>, SensitivityOptions, &mut
EnclosureBudget) -> Result<FlowSensitivity<N>, SensitivityError>.

Changes from the prototype
- Matrix scaling uses a private entry map over Hyperinterval's scalar
  multiplication; the public IntervalMatrix::scale was rejected on latency
  (docs/research/matrix-scale-reconsideration.md) and is not reintroduced.
- Series terms and composed products are regridded outward to the policy grid,
  so bit sizes stay bounded over long horizons.
- A borrowed &Arc receiver: a failed call leaves the caller's source in place.
- Empty Picard segments map to the empty derivative set.

Files
  source/                         src/field/sensitivity.rs, tests/ and examples/
                                  flow_sensitivity.rs from crates/hyperdynamics
  flow_sensitivity-tests.log      8 tests, all passing
  mutations.txt, mutation-*.log   five deliberate defects, each caught
  mutate.py                       the mutation driver
  pendulum-example.txt            example output (Liouville determinant check)
  validation-stable-and-1.95.0.txt  hyperdynamics workflow commands, both toolchains
  release-example-sizes.txt       --all-features release examples, base vs candidate
  atlas-quick-sensitivity.json    quick perf-atlas sweeps of the new operation

Corpus: exact uncertain shear (derivative and tube); exponential, Riccati
(per initial point) and oscillator against independent rational references;
a noncommuting time-dependent triangular field whose certified entry excludes
the commuting shortcut exp(∫A); truncated series (0, 1, 2, 8 terms) and a
2^-4 grid; stopped prefixes, no-segment stops, reversed and non-point time
with and without empty boxes, valid empty, identity and N = 0; exact graph and
scalar work thresholds (exact amount passes, one less fails), entry and
scalar-bit exhaustion, cancellation, cleanup (Arc count) and retry equality;
zero scalar dispatch; fresh-process serde replay with corrupted controls.

Atlas note: the quick sweeps were taken before the atlas job was changed to
report failure reasons; timing is unaffected. Nonlinear series stop where the
source Picard evolution itself stops with SizeExhausted (exact Cartesian
endpoint growth, as in the existing "Picard integrate by horizon" sweep).
Not run locally: the WASI conformance (no Node on this host); CI runs it.
