use hyperinterval::{DyadicBudget as B, DyadicInterval as D, ExtendedInterval as E, IntervalError, IntervalSet2 as S};
type Extended=E<D>;
type Set=S<D>;
fn interval(a:i32,b:i32,e:i32)->D {D::new(a.into(),b.into(),e).unwrap()}
fn extended(x:D,kind:u32)->Extended {
 match kind%5 {0=>E::from_finite(x),1=>{let (n,e)=x.lower().unwrap();E::above(D::point(n.clone(),e).unwrap()).unwrap()},2=>{let (n,e)=x.upper().unwrap();E::below(D::point(n.clone(),e).unwrap()).unwrap()},3=>E::entire(),_=>E::empty()}
}
fn ext_query(a:&Extended,b:&Extended,w:&mut B)->Result<bool,IntervalError>{
 Ok(!a.is_empty()&&!b.is_empty()&&!a.strictly_left_of(b,w)?&&!b.strictly_left_of(a,w)?)
}
pub enum Input { Finite(D,D),Extended(Extended,Extended),Union(Set,Set) }
impl Input {
 pub fn make(kind:u32,a:i32,b:i32,e:i32,c:i32,d:i32,f:i32,shape:u32)->Self {
 let x=interval(a,b,e); let y=interval(c,d,f);
 match kind {
 0=>Self::Finite(x,y),1=>Self::Extended(extended(x,shape),extended(y,shape/5)),
 _=>{let mut w=B::new(128,4096);let first=extended(x.clone(),shape);let second=extended(y.clone(),shape/5);
     let left=S::new(first,extended(y,shape/25),&mut w).unwrap();
     let right=S::new(second,extended(x,shape/125),&mut w).unwrap();Self::Union(left,right)}
 }}
 pub fn compare(&self,w:&mut B)->Result<bool,IntervalError>{
 match self {
 Self::Finite(a,b)=>{
 #[cfg(feature="direct")]
 {a.overlaps(b,w)}
 #[cfg(not(feature="direct"))]
 {ext_query(&E::from_finite(a.clone()),&E::from_finite(b.clone()),w)}
 },
 Self::Extended(a,b)=>ext_query(a,b,w),
 Self::Union(a,b)=>{for x in a.components(){for y in b.components(){if ext_query(x,y,w)?{return Ok(true)}}}Ok(false)}}

 }
}
#[no_mangle]
pub extern "C" fn overlap(kind:u32,a:i32,b:i32,e:i32,c:i32,d:i32,f:i32,shape:u32,bits:u32,work:u32)->u32{
 let x=Input::make(kind,a,b,e,c,d,f,shape);let mut budget=B::new(bits.into(),work.into());
 let code=match x.compare(&mut budget){Ok(false)=>0,Ok(true)=>1,Err(IntervalError::SizeExhausted)=>2,Err(IntervalError::WorkExhausted)=>3,Err(_)=>4};
 code + 8*(work-budget.remaining_work() as u32)
}
