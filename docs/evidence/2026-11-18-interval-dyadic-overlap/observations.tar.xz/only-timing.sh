set -eu
t=/dev/shm/interval-overlap
for n in 1 2 3 4 5 6; do
 if [ $((n % 2)) -eq 1 ]; then variants="finite-current finite"; else variants="finite finite-current"; fi
 for v in $variants; do taskset -c 18 "$t/builds/$v-native" > "$t/logs/only-timing-$n-$v"; done
done
