set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$t/lifetime-target"
build(){
 label=$1;shift
 (cd "$t/lifetime" && cargo +1.95.0 build --release --offline "$@") > "$t/logs/$label-life-build" 2>&1
 cp "$CARGO_TARGET_DIR/release/overlap-lifetime" "$t/builds/$label-life"
 for i in 1 2 3; do "$t/builds/$label-life"; done > "$t/logs/$label-stack" 2> "$t/logs/$label-headroom"
}
build on-use --features direct
git -C "$t/repo" restore --staged crates/hyperinterval/src/dyadic_overlap.rs
git -C "$t/repo" apply -R "$t/on-use.patch"
build current
git -C "$t/repo" switch --detach c9f1f9ac5
build fixed
git -C "$t/repo" switch --detach 67b0a2e74
git -C "$t/repo" apply "$t/on-use.patch"
