set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$t/probe-target"
wide(){
 (cd "$t/probe" && cargo +1.95.0 run --release --offline --example wide "${@:2}") > "$t/logs/$1-wide" 2>&1
}
bash "$t/build-only.sh" component
wide component --features direct
python3 "$t/metrics.py" component
git -C "$t/repo" apply -R "$t/component.patch"
wide current
git -C "$t/repo" switch --detach c9f1f9ac5
bash "$t/probe-build.sh" fixed > "$t/logs/fixed-probe" 2>&1
bash "$t/build-only.sh" fixed
wide fixed
git -C "$t/repo" switch --detach 67b0a2e74
git -C "$t/repo" apply "$t/component.patch"
