set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR=/dev/shm/interval-bisection/scalar-target
cd "$t/repo"
cargo +1.95.0 build --release --locked -p hyperinterval --features 'integer,fixed,rational,dyadic,float-enclosure' --example order_cost --example division_cost --example tangent_cost --example fractional_power_cost > "$t/logs/$1-build" 2>&1
for name in order_cost division_cost tangent_cost fractional_power_cost; do
 cp "$CARGO_TARGET_DIR/release/examples/$name" "$t/builds/$1-$name"
 "$t/builds/$1-$name" > "$t/logs/$1-$name"
done
