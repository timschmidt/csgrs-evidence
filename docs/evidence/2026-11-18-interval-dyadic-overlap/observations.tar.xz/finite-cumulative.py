from metrics import s,t,wasm,sizes
import json
obs={}
for suffix in ['-native','.wasm','-order_cost','-division_cost','-tangent_cost','-fractional_power_cost']:
 names=('finite-fixed','finite-current','finite') if suffix in ['-native','.wasm'] else ('fixed','current','finite')
 ps=[t/(n+suffix) for n in names]
 vals=[dict(file=p.stat().st_size,code=wasm(p)) if suffix=='.wasm' else sizes(p) for p in ps]
 rows={}
 for k in sorted(set().union(*vals)):
  f,b,a=[v.get(k,0) for v in vals]
  inc=max(0,a-b);prior=max(0,b-f);total=prior+inc
  ib,ip,cb,cp=(1024,5,4096,10) if suffix=='.wasm' else (1024,.5,4096,1) if k=='function_union' else (4096,1,16384,2)
  rows[k]=dict(fixed=f,before=b,after=a,prior=prior,increment=inc,cumulative=total,remaining_incremental=max(0,min(ib,int(b*ip/100))-inc),remaining_cumulative=min(cb,int(f*cp/100))-total,passes=(inc<=ib and 100*inc<=b*ip and total<=cb and 100*total<=f*cp))
  if not rows[k]['passes']: print('FAIL',suffix,k,f,b,a,prior,inc,total)
 obs[suffix]=rows
 print(suffix,'file',rows['file'],'largest image',max(p.stat().st_size for p in ps))
(s/'finite-sizes.json').write_text(json.dumps(obs,indent=2)+'\n')
