set -eu
. /dev/shm/interval-bisection/env
t=/dev/shm/interval-overlap
cargo +1.95.0 test --locked -p hyperinterval -p hyperlattice-interval --all-features > "$t/primary-logs/owner" 2>&1
cargo +1.95.0 test --locked -p hyperdynamics --features reachability --test reachability > "$t/primary-logs/dynamics" 2>&1
cargo +1.95.0 clippy --locked -p hyperinterval --all-features --all-targets -- -D warnings > "$t/primary-logs/clippy" 2>&1
RUSTDOCFLAGS='-D warnings' cargo +1.95.0 doc --locked -p hyperinterval --all-features --no-deps > "$t/primary-logs/doc" 2>&1
cargo +1.88.0 test --locked -p hyperinterval --no-default-features --features dyadic --test dyadic_set_relations > "$t/primary-logs/msrv" 2>&1
cargo +1.88.0 clippy --locked -p hyperinterval --no-default-features --features dyadic --lib -- -D warnings > "$t/primary-logs/msrv-clippy" 2>&1
cargo +1.95.0 check --locked -p hyperinterval --no-default-features --features dyadic --target wasm32-unknown-unknown > "$t/primary-logs/wasm-lib" 2>&1
