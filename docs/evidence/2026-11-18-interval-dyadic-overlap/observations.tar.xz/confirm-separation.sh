set -eu
t=/dev/shm/interval-overlap
for cpu in 4 14 24; do
 for i in $(seq 1 10); do
  if [ $((i % 2)) -eq 1 ]; then order='finite-current separation'; else order='separation finite-current'; fi
  for v in $order; do taskset -c "$cpu" "$t/builds/$v-native" > "$t/confirm-separation/$cpu-$i-$v"; done
 done
done
