//! Exact intersection queries on borrowed dyadic bounds and components.

use crate::extended_dyadic::{bounds, compare};
use crate::{DyadicBudget, DyadicInterval, ExtendedInterval, IntervalError, IntervalSet2};
use core::cmp::Ordering;

impl DyadicInterval {
    /// Whether the closed intervals share a real point, including a common
    /// endpoint. Empty intervals never overlap. Finite endpoint comparisons
    /// share the supplied budget without expanding an irrelevant exponent gap.
    #[inline]
    pub fn overlaps(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        let (Some((a, b, e)), Some((c, d, f))) = (self.bounds(), other.bounds()) else {
            return Ok(false);
        };
        Ok(!crate::dyadic_order::compare(b, e, c, f, budget)?.is_lt()
            && !crate::dyadic_order::compare(d, f, a, e, budget)?.is_lt())
    }

    /// Whether the exact intersection is empty, including an empty operand.
    #[inline]
    pub fn disjoint(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        Ok(!self.overlaps(other, budget)?)
    }
}

impl ExtendedInterval<DyadicInterval> {
    // Both components are nonempty. Equal denotes intersection, including
    // endpoint contact. A strict order identifies the component to advance.
    #[inline]
    fn component_order(
        &self,
        other: &Self,
        budget: &mut DyadicBudget,
    ) -> Result<Ordering, IntervalError> {
        let (a, b) = bounds(self).expect("nonempty component");
        let (c, d) = bounds(other).expect("nonempty component");
        if compare(b, c, budget)?.is_lt() {
            Ok(Ordering::Less)
        } else if compare(d, a, budget)?.is_lt() {
            Ok(Ordering::Greater)
        } else {
            Ok(Ordering::Equal)
        }
    }

    /// Whether the closed intervals share a finite real point. Ray endpoints
    /// are included. Empty intervals never overlap, including with themselves.
    #[inline]
    pub fn overlaps(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        Ok(!self.is_empty() && !other.is_empty() && self.component_order(other, budget)?.is_eq())
    }

    /// Whether the represented real sets have empty intersection.
    #[inline]
    pub fn disjoint(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        Ok(!self.overlaps(other, budget)?)
    }
}

impl IntervalSet2<DyadicInterval> {
    /// Whether any two closed components share a point. Gaps in either
    /// operand remain excluded. Sorted components require at most three pair
    /// comparisons, all sharing the same budget.
    #[inline]
    pub fn overlaps(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        let mut left = self.components();
        let mut right = other.components();
        while let (Some((a, rest_a)), Some((b, rest_b))) = (left.split_first(), right.split_first())
        {
            match a.component_order(b, budget)? {
                Ordering::Less => left = rest_a,
                Ordering::Greater => right = rest_b,
                Ordering::Equal => return Ok(true),
            }
        }
        Ok(false)
    }

    /// Whether the two unions have empty intersection.
    #[inline]
    pub fn disjoint(&self, other: &Self, budget: &mut DyadicBudget) -> Result<bool, IntervalError> {
        Ok(!self.overlaps(other, budget)?)
    }
}
