from pathlib import Path
import hashlib,json,subprocess,shutil
t=Path(__file__).parent;d=t/'binary-deltas';d.mkdir(exist_ok=True)
idx={}
suf=['-fractional_power_cost','-division_cost','-order_cost','-tangent_cost','-life','-native','.wasm']
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
for p in sorted((t/'builds').iterdir()):
 tail=next(k for k in suf if p.name.endswith(k))
 base=t/'builds'/('current'+tail)
 if p.name==base.name:
  out=d/p.name;shutil.copy2(p,out)
 else:
  out=d/(p.name+'.zst')
  subprocess.run(['zstd','-q','-f','-10','--patch-from',base,p,'-o',out],check=True)
  v=t/'delta-verify';subprocess.run(['zstd','-q','-d','-f','--patch-from',base,out,'-o',v],check=True)
  assert sha(v)==sha(p)
 idx[p.name]=[p.stat().st_size,sha(p),out.name,None if p.name==base.name else base.name]
(t/'binary-index.json').write_text(json.dumps(idx,indent=2)+'\n')
