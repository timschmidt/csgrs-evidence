set -eu
. /dev/shm/interval-bisection/env
t=/dev/shm/interval-overlap
cargo +1.95.0 test --locked -p hyperinterval -p hyperlattice-interval --all-features > "$t/logs/final-owner" 2>&1
cargo +1.95.0 test --locked -p hyperdynamics --features reachability --test reachability > "$t/logs/final-dynamics" 2>&1
cargo +1.95.0 clippy --locked -p hyperinterval --all-features --all-targets -- -D warnings > "$t/logs/final-clippy" 2>&1
RUSTDOCFLAGS='-D warnings' cargo +1.95.0 doc --locked -p hyperinterval --all-features --no-deps > "$t/logs/final-doc" 2>&1
cargo +1.88.0 test --locked -p hyperinterval --no-default-features --features dyadic --test dyadic_overlap > "$t/logs/final-msrv" 2>&1
cargo +1.88.0 clippy --locked -p hyperinterval --no-default-features --features dyadic --lib -- -D warnings > "$t/logs/final-msrv-clippy" 2>&1
cargo +1.95.0 check --locked -p hyperinterval --no-default-features --features dyadic --target wasm32-unknown-unknown > "$t/logs/final-wasm-lib" 2>&1
