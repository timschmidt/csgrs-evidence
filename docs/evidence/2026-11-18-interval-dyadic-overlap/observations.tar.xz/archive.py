from pathlib import Path
import hashlib, io, tarfile, shutil, subprocess, importlib.util, json, sys
s=Path(sys.argv[1]); name='docs/evidence/2026-11-18-interval-'+sys.argv[2]
main=Path.cwd();repo=main.parent/'csgrs-evidence'
def git(*args): return subprocess.check_output(['git','-C',repo,*args])
assert not git('status','--porcelain').strip()
assert not (repo/name).exists()
dirs='logs binary-deltas primary-logs corpus probe lifetime finite-probe finite-lifetime confirm confirm-call confirm-separation'.split()
files=sorted({*filter(Path.is_file,s.iterdir()),*(p for d in dirs for p in (s/d).rglob('*') if p.is_file())})
digest=lambda data:hashlib.sha256(data).hexdigest()
hashes={p.relative_to(s).as_posix():digest(p.read_bytes()) for p in files}
out=s/'archive'
out.mkdir()
packed=out/'observations.tar.xz'
with tarfile.open(packed,'w:xz',preset=6) as t:
 for p in files:
  content=p.read_bytes();info=tarfile.TarInfo(p.relative_to(s).as_posix())
  info.size=len(content);info.mode=p.stat().st_mode&0o777;t.addfile(info,io.BytesIO(content))
with tarfile.open(packed,mode='r|xz') as t: assert {m.name:digest(t.extractfile(m).read()) for m in t}==hashes
(out/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
assert shutil.disk_usage(repo).free-3*sum(p.stat().st_size for p in out.iterdir())-20*1024**2 >= 20*1024**3
shutil.copytree(out,repo/name)
git('add','--sparse','--',name)
assert all(p.startswith(name+'/') for p in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive '+sys.argv[2]+' qualification')
rev=git('rev-parse','HEAD').decode().strip()
for p in out.iterdir():assert p.read_bytes()==git('show',rev+':'+name+'/'+p.name)
spec=importlib.util.spec_from_file_location('manifest',main/'scripts/evidence_archive.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.ROOTS={name:False}
rows=module.manifest(str(repo),rev);assert len(rows)==2
index=main/'docs/evidence-archive.tsv';assert name not in index.read_text()
with index.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1],len(files))
