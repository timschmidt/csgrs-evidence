#![cfg(feature="dyadic")]
use hyperinterval::{DyadicBudget,DyadicInterval as D,IntervalError};
#[test]
fn disjoint_singletons_exhaust_common_grid(){
 let a=D::point(1.into(),i32::MIN).unwrap();let b=D::point(1.into(),i32::MAX).unwrap();
 assert_eq!(a.intersection(&b,&mut DyadicBudget::new(128,4096)),Err(IntervalError::SizeExhausted));
 assert_eq!(a.strictly_left_of(&b,&mut DyadicBudget::new(128,4096)),Err(IntervalError::SizeExhausted));
}
