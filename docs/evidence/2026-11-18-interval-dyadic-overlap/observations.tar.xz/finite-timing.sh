set -eu
t=/dev/shm/interval-overlap
for n in 1 2 3 4 5 6; do
 if [ $((n % 2)) -eq 1 ]; then variants='current finite-ends'; else variants='finite-ends current'; fi
 for v in $variants; do taskset -c 18 "$t/builds/$v-native" > "$t/logs/finite-timing-$n-$v"; done
done
