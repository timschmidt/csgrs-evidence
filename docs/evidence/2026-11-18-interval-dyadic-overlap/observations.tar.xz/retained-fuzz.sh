set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export PATH=/tmp/interval-refactor/tools/bin:$PATH CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/fuzz-target
cd crates/hyperinterval
for f in dyadic_arithmetic; do
 cargo +nightly fuzz run "$f" "$t/corpus/$f" -- -runs=15000 -max_len=24 -seed=20261118 > "$t/logs/retained-fuzz-$f" 2>&1
done
