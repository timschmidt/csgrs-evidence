set -eu
t=/dev/shm/interval-overlap
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$t/finite-lifetime-target"
build(){
 label=$1;shift
 (cd "$t/finite-lifetime" && cargo +1.95.0 build --release --offline "$@") > "$t/logs/$label-life-build" 2>&1
 (cd "$t/finite-probe" && cargo +1.95.0 run --offline --release --example wide "$@") > "$t/logs/$label-wide" 2>&1
 cp "$CARGO_TARGET_DIR/release/overlap-lifetime" "$t/builds/$label-life"
 for i in 1 2 3; do "$t/builds/$label-life"; done > "$t/logs/$label-stack" 2> "$t/logs/$label-headroom"
}
build finite-order --features direct

git -C "$t/repo" apply -R "$t/finite-order.patch"
build finite-current
git -C "$t/repo" switch --detach c9f1f9ac5
build finite-fixed
git -C "$t/repo" switch --detach 67b0a2e74
git -C "$t/repo" apply "$t/finite-order.patch"
