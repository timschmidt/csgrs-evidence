from pathlib import Path
from collections import Counter
from fractions import Fraction
import copy,gzip,hashlib,json,time
from resource_accounting import charges
s=Path(__file__).parent;root=s.parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');old=root/'cancellation-standalone-history';previous=root/'cancellation-standalone-consumer-separated';proposal=root/'cancellation-standalone-byte-allowance';assert load(s/'analysis-command.json')['exit_code']==0
inputs=[s/'accounts.json',s/'size-accounts.json',old/'accounts.json',old/'size-accounts.json',old/'verification.json',proposal/'caps.json',proposal/'verification.json',previous/'observations.json',previous/'commands.json',s/'observations.json',s/'commands.json'];save('history-started.json',{'time':time.time(),'script_sha256':sha(Path(__file__).read_bytes()),'inputs':{str(p):sha(p.read_bytes()) for p in inputs},'subprocesses':0,'limit_seconds':300})
try:
 historical=load(old/'accounts.json');prior={tuple(a['key']):a for a in historical};accounts=copy.deepcopy(load(s/'accounts.json'));sources={str(old/'accounts.json'):sha((old/'accounts.json').read_bytes()),str(old/'size-accounts.json'):sha((old/'size-accounts.json').read_bytes())};floors=[]
 def merge(e,olde,added):
  observations=[];prior_charges={}
  if not added:
   for c in olde['changes']:
    before=c['before'];after='reference' if c['after']=='candidate' else c['after'];p=c.get('prior');obs={'before':before,'after':after,'charge':c['positive_charge'],'denominator':olde['denominator'],'previous_pass':c['incremental_pass'],'source':'previous reconciled publication boundary'};observations.append(obs)
    if p:observations.append({'before':before,'after':after,'charge':p['charge'],'denominator':p['denominator'],'previous_pass':c['incremental_pass'],'source':p['source']})
   observations.extend(dict(o,before='fixed',after='primary') for o in olde.get('historical_observations',[]))
   for before,after in [('fixed','primary'),('primary','reference')]:
    choices=[o for o in observations if (o['before'],o['after'])==(before,after)]
    if choices:
     p=max(choices,key=lambda o:(o['charge'],-o['denominator']));prior_charges[before,after]={'charge':p['charge'],'denominator':p['denominator'],'source':'prior publication path; all observations retained separately'}
  labels=['reference','candidate'] if added else ['fixed','primary','reference','candidate'];e['observed_gate']=copy.deepcopy({k:e[k] for k in ['changes','denominator','cumulative_positive_charge','incremental_pass','cumulative_pass']});e.update(charges(e['values'],labels,e['absolute_cap'],e['percent_cap'],prior_charges));e['historical_observations']=observations;e['historical_original_gate']=copy.deepcopy(olde);e['historical_obligations_pass']=all(o['charge']<=e['absolute_cap'] and o['charge']*100<=e['percent_cap']*o['denominator'] for o in observations);e['incremental_pass'] &= e['historical_obligations_pass'];e['cumulative_pass'] &= e['historical_obligations_pass']
  if 'total_pass' in e:
   total=e['total_limit'];e['historical_absolute_values']=olde['values'];e['total_pass'] &= total is None or max(olde['values'].values())<=total
  return observations
 def failures(a):
  kept=[f for f in a['failures'] if not any(f==metric+':'+test for metric in a['metrics'] for test in ['total','incremental','cumulative'])]
  for metric,e in a['metrics'].items():
   for test in ['total','incremental','cumulative']:
    if e.get(test+'_pass') is False:kept.append(metric+':'+test)
  a['failures']=kept
 for a in accounts:
  olda=prior[tuple(a['key'])];a['observed_failures']=a['failures'].copy();a['historical_account_failures']=olda['failures'];a['prior_account_reconciliation_pending']=False
  for metric,e in a['metrics'].items():floors.append({'key':a['key'],'metric':metric,'observations':merge(e,olda['metrics'][metric],a['added_functionality'])})
  failures(a)
 sizes=copy.deepcopy(load(s/'size-accounts.json'));old_sizes={(a['features'],a['kind']):a for a in load(old/'size-accounts.json')}
 for a in sizes:
  olda=old_sizes[a['features'],a['kind']];a['prior_account_reconciliation_pending']=False
  for metric,e in a['metrics'].items():merge(e,olda['metrics'][metric],'cancel-retry' in a['features'])
  a['historical_headroom_pass']=olda['headroom_pass'];a['headroom_pass'] &= olda['headroom_pass']
 # Bind every historical successful source/domain to this campaign's exact output.
 old_commands={c['log']:c for c in load(previous/'commands.json')};old_rows={(o['label'],o['features'],o['kind'],tuple(o['args']),o['repeat'],o['smoke']):o for o in load(previous/'observations.json')};new_commands={c['log']:c for c in load(s/'commands.json')};compared=[]
 for o in load(s/'observations.json'):
  if o['label']=='candidate' or o['expected_exit_code']:continue
  key=('candidate' if o['label']=='reference' else o['label'],o['features'],o['kind'],tuple(o['args']),o['repeat'],o['smoke']);old_o=old_rows[key];pair=[]
  for stage,c in [(s,new_commands[o['log']]),(previous,old_commands[old_o['log']])]:
   stored=(stage/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and sha(raw)==c['raw_sha256'] and c['exit_code']==0;pair.append(b'\n'.join(line for line in raw.splitlines() if line.startswith((b'OUTPUT ',b'TRACE '))))
  assert pair[0] and pair[0]==pair[1];compared.append({'new_log':o['log'],'previous_log':old_o['log'],'full_output_trace_sha256':sha(pair[0])})
 assert len(compared)==3288
 # Apply the already declared byte proposal to these newly reconciled accounts.
 caps=copy.deepcopy(load(proposal/'caps.json'));caps['candidate']='1abfbc3fc80c52d7d57be26ac031ef824ca92d9d';caps['original_proposal']={'source':str(proposal/'caps.json'),'sha256':sha((proposal/'caps.json').read_bytes())};revised=copy.deepcopy(accounts);changed=0
 for a in revised:
  a['original_failures']=a['failures'].copy();key=a['key'];history=isinstance(key[1],str);case=key[2] if history else key[1];trace=key[4] if history else key[3]
  for metric,e in a['metrics'].items():
   rules=[r for r in caps['rules'] if not a['added_functionality'] and key[0]=='trace' and r['case']==case and r['trace']==trace and metric in r['metrics']]
   if not rules:continue
   rule=rules[0];changed+=1;e['original_gate']={k:copy.deepcopy(e[k]) for k in ['absolute_cap','percent_cap','incremental_pass','cumulative_pass','historical_obligations_pass']};e['absolute_cap']=rule['absolute_bytes']*(rule['history_absolute_scale'] if history else 1);e['percent_cap']=rule['relative_percent'];ok=lambda n,d:d>=0 and n<=e['absolute_cap'] and Fraction(n*100)<=Fraction(str(e['percent_cap']))*d
   for c in e['changes']:
    c['original_incremental_pass']=c['incremental_pass'];c['incremental_pass']=ok(c['positive_charge'],e['denominator']) and (not c['prior'] or ok(c['prior']['charge'],c['prior']['denominator']))
   e['historical_obligations_pass']=all(ok(o['charge'],o['denominator']) for o in e['historical_observations']);e['incremental_pass']=all(c['incremental_pass'] for c in e['changes']) and e['historical_obligations_pass'];e['cumulative_pass']=ok(e['cumulative_positive_charge'],e['denominator']) and e['historical_obligations_pass'];e['remaining_absolute']=e['absolute_cap']-e['cumulative_positive_charge'];e['remaining_relative_bytes']=e['denominator']*e['percent_cap']/100-e['cumulative_positive_charge']
  failures(a)
 assert changed==72
 summary={'accounts':len(accounts),'observed_failed_accounts':sum(bool(a['failures']) for a in load(s/'accounts.json')),'historical_failed_accounts':sum(bool(a['failures']) for a in accounts),'proposed_failed_accounts':sum(bool(a['failures']) for a in revised),'proposed_failed_metrics':dict(Counter(f for a in revised for f in a['failures'])),'historical_exact_output_trace_matches':len(compared),'historical_metric_records':len(floors),'historical_positive_observations':sum(o['charge']>0 for f in floors for o in f['observations']),'revised_byte_metrics':changed,'size_failed_metrics':sum(e['incremental_pass'] is False or e['cumulative_pass'] is False for a in sizes for e in a['metrics'].values()),'size_headroom_pass':all(a['headroom_pass'] for a in sizes),'new_source_admission':False,'accepted_memory_exceptions':0,'all_previous_values_denominators_charges_verdicts_retained':True,'seconds':time.monotonic()-start}
 for name,value in [('historical-accounts.json',accounts),('historical-size-accounts.json',sizes),('historical-floors.json',floors),('historical-output-comparisons.json',compared),('proposed-caps.json',caps),('proposed-accounts.json',revised),('history-summary.json',summary)]:save(name,value)
 assert time.monotonic()-start<300;save('history-completion.json',{'exit_code':0,'seconds':time.monotonic()-start,'subprocesses':0});print(json.dumps(summary,indent=2))
except BaseException as error:save('history-completion.json',{'exit_code':1,'error':repr(error),'seconds':time.monotonic()-start,'automatic_retry':False});raise
