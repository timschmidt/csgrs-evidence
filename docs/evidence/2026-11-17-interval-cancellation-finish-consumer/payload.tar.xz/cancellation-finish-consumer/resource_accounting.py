from collections import Counter
import ast

def fields(raw):
 out={}
 for line in raw.splitlines():
  tag,_,value=line.partition(' ')
  if tag in ['ALLOCATION','USABLE','CLEANUP','USABLE_CLEANUP','INPUT_CLEANUP','INPUT_USABLE_CLEANUP','SETUP','TEARDOWN']:
   out[tag]=ast.literal_eval('['+value.replace(') (','), (')+']') if tag in ['SETUP','TEARDOWN'] else ast.literal_eval(value)
  elif tag=='STACK':out[tag]=int(value)
  elif tag=='HEADROOM':out[tag]=list(map(int,value.split()))
 return out

def history(raw,kind):
 f=fields(raw);m=Counter();live=[0,0];cycles=[];negative=[]
 def epoch(requested,usable,phase):
  for j,(prefix,v,traffic,peak,retained) in enumerate([('requested',requested,3,4,5),('usable',usable,0,1,2)]):
   observed=live[j]+v[peak];live[j]+=v[retained];m[prefix+'_peak']=max(m[prefix+'_peak'],observed);m[prefix+'_traffic']+=v[traffic]
   if observed<0 or live[j]<0:negative.append(dict(phase=phase,kind=prefix,peak=observed,live=live[j]))
  for name,idx in [('allocations',0),('deallocations',1),('reallocations',2)]:m[name]+=requested[idx]
 if kind=='reused':
  epoch(*f['SETUP'],'setup')
  for prefix,v in zip(['requested','usable'],live):m[prefix+'_input_retained']=v
 for line in raw.splitlines():
  if not line.startswith('CYCLE '):continue
  _,number,values=line.split(' ',2);assert int(number)==len(cycles)
  op,usable,drop,du=ast.literal_eval('['+values.replace(') (','), (')+']');before=live.copy();epoch(op,usable,'operation:'+number)
  for prefix,v in zip(['requested','usable'],live):m[prefix+'_retained']=max(m[prefix+'_retained'],v)
  epoch(drop,du,'cleanup:'+number);cycles.append(dict(cycle=int(number),increment=[live[i]-before[i] for i in range(2)],live=live.copy()))
  if kind=='reused':
   for prefix,v in zip(['requested','usable'],live):m[prefix+'_input_retained']=max(m[prefix+'_input_retained'],v)
 assert len(cycles)==32
 if kind=='reused':epoch(*f['TEARDOWN'],'teardown')
 for prefix,v in zip(['requested','usable'],live):m[prefix+'_persistent']=v
 return dict(metrics=dict(m),cycles=cycles,negative=negative,no_retention_after_cycle_two=all(c['increment']==[0,0] for c in cycles[2:]))

def limits(metric,case,is_history):
 scale=32 if is_history else 1
 count=metric in ['allocations','deallocations','reallocations'];traffic=metric.endswith('traffic');persistent=metric.endswith('persistent');retained=metric.endswith('retained');stack='stack' in metric
 cap,percent=(256,4) if stack else (16*scale,1) if count else (4096*scale,2) if traffic else (512,2) if retained or persistent else (4096,2)
 total=None if count else (65536 if case==3 else 32768) if stack else 32768 if persistent else (256 if case==3 else 16)*1024**2*scale if traffic else (8 if case==3 else 1)*1024**2
 return cap,percent,total

def charges(values,labels,cap,percent,prior):
 denominator=values[labels[0]]
 passed=lambda charge,base:base>=0 and charge<=cap and charge*100<=percent*base
 changes=[]
 for before,after in zip(labels,labels[1:]):
  delta=values[after]-values[before];p=prior.get((before,after));charge=max(0,delta,p['charge'] if p else 0)
  entry=dict(before=before,after=after,delta=delta,positive_charge=charge,prior=p,incremental_pass=passed(charge,denominator) and (not p or passed(p['charge'],p['denominator'])))
  changes.append(entry)
 cumulative=sum(c['positive_charge'] for c in changes)
 return dict(denominator=denominator,absolute_cap=cap,percent_cap=percent,changes=changes,cumulative_positive_charge=cumulative,remaining_absolute=cap-cumulative,remaining_relative_bytes=denominator*percent/100-cumulative,incremental_pass=all(c['incremental_pass'] for c in changes),cumulative_pass=passed(cumulative,denominator))
