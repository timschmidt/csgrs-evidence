from pathlib import Path
import gzip,hashlib,json,os,re,resource,shutil,signal,subprocess,time
s=Path(__file__).parent;h=s.parent/'cancellation-standalone-consumer-separated/consumer';r=Path('/dev/shm/interval-trace-materialization/csgrs');target=Path('/dev/shm/interval-cancellation-standalone-consumer-target');art=Path('/dev/shm/interval-cancellation-finish-consumer-images');start=time.monotonic();deadline=start+5400;commands=[];builds=[];observations=[];refs={};outputs={};sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');control='4f41bd58415d936968e1955dbd431f0cb5e988f0';hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];boundaries=load(s/'boundaries.json');env=os.environ|dict(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home',CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='6',CARGO_NET_OFFLINE='true',HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1')
def run(name,args,work=h,cap=900,expected=0,executable=None):
 f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();assert time.monotonic()<deadline and len(commands)<6500;assert shutil.disk_usage('/tmp').free>=2560*1024**2 and shutil.disk_usage('/mnt/development').free>=20*1024**3
 if len(commands)%50==0:assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<512*1024**2
 assert name not in {c['name'] for c in commands};t=time.monotonic();p=s/(name+'.log');timed=False
 with p.open('wb') as out:
  child=subprocess.Popen(args,cwd=work,executable=executable,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,((64*1024**2 if executable else 1024**3),hard)));save('active.json',dict(producer=os.getpid(),child=child.pid,name=name,number=len(commands)+1,remaining=deadline-t))
  try:child.wait(timeout=min(cap,deadline-t))
  except BaseException as error:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
   if isinstance(error,subprocess.TimeoutExpired):timed=True
   else:raise
 raw=p.read_bytes();stored=gzip.compress(raw,compresslevel=1,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();c=dict(name=name,command=args,cwd=str(work),executable=executable,exit_code=child.returncode,expected_exit_code=expected,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_bytes=len(raw),raw_sha256=sha(raw),stored_bytes=len(stored),stored_sha256=sha(stored));commands.append(c)
 if len(commands)%50==0 or not executable or child.returncode!=expected:save('commands.json',commands)
 save('active.json',dict(producer=os.getpid(),child=None));assert child.returncode==expected and not timed,(name,child.returncode,expected)
 if not executable:assert not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines())
 return raw.decode(),c

def git(name,*args):return run(name,['git',*args],work=r,cap=60)[0].strip()
def metrics(path,name):
 sections,_=run(name+'-size',['size','-A',str(path)],cap=60);sizes={a[0]:int(a[1]) for line in sections.splitlines() if len(a:=line.split())==3 and a[0].startswith('.')};symbols,_=run(name+'-nm',['nm','-S','--defined-only',str(path)],cap=60);addresses={}
 for line in symbols.splitlines():
  m=re.match(r'([0-9a-f]+) ([0-9a-f]+) [tT] ',line)
  if m:
   address,n=m.groups();n=int(n,16);assert address not in addresses or addresses[address]==n;addresses[address]=n
 listing,_=run(name+'-objdump',['objdump','-h',str(path)],cap=60);allocated=executable=0;lines=listing.splitlines()
 for i,line in enumerate(lines[:-1]):
  fields=line.split()
  if len(fields)>=7 and fields[0].isdigit():
   n=int(fields[2],16);flags=lines[i+1]
   if 'ALLOC' in flags:allocated+=n
   if 'CODE' in flags:executable+=n
 hashes={}
 for section in ['.text','.rodata','.data']:
  if section not in sizes:continue
  temporary=art/(name+section+'.section');run(name+'-dump-'+section[1:],['objcopy','--dump-section',section+'='+str(temporary),str(path),'/dev/null'],cap=60);hashes[section]=sha(temporary.read_bytes());temporary.unlink()
 return dict(path=str(path),file=path.stat().st_size,sha256=sha(path.read_bytes()),text=sizes.get('.text',0),rodata=sizes.get('.rodata',0),data=sizes.get('.data',0),bss=sizes.get('.bss',0),named_text=sum(addresses.values()),allocated=allocated,executable=executable,sections=sizes,section_hashes=hashes)
def compare(row,kind,args,raw):
 full='\n'.join(x for x in raw.splitlines() if x.startswith(('OUTPUT ','TRACE ')));output='\n'.join(x for x in raw.splitlines() if x.startswith('OUTPUT '));assert full and output
 key=(row['features'],kind,tuple(args));plain=(row['features'].replace(',cancel-retry','').replace('cancel-retry',''),kind,tuple(args))
 if key in refs:assert refs[key]==full,('output/trace mismatch',row['label'],key)
 else:refs[key]=full
 if plain in outputs:assert outputs[plain]==output,('retry output mismatch',row['label'],key)
 else:outputs[plain]=output

def observe(row,kind,args,repeat,smoke=False):
 name='-'.join([row['label'],row['features'].replace(',','-') or 'default',kind,*args,str(repeat)]);expected=101 if row['reproduction'] else 0;raw,c=run(name,['cancellation-'+kind+'-control',*args],cap=60,expected=expected,executable=row['artifacts'][kind]['path'])
 if expected:assert 'publication cancellation must discard completed output' in raw
 else:compare(row,kind,args,raw)
 observations.append(dict(label=row['label'],features=row['features'],kind=kind,args=args,repeat=repeat,smoke=smoke,expected_exit_code=expected,log=c['log']))

def build(label,revision,features):
 name=label+'-'+(features.replace(',','-') or 'default');args=['cargo','+1.95.0','build','--release','--locked','--offline','--bins']
 if features:args+=['--features',features]

 if label=='candidate':run(name+'-build',args)
 row=dict(label=label,revision=revision,features=features,reproduction=label=='primary' and 'cancel-retry' in features,artifacts={},sources={p.name:sha(p.read_bytes()) for p in h.iterdir() if p.is_file()})
 for kind in ['resource','lifetime','reused']:
  path=art/(name+'-'+kind);assert not path.exists()
  if label=='candidate':source=target/'release'/('cancellation-'+kind)
  else:
   previous=next(b for b in load(s.parent/'cancellation-standalone-consumer-separated/builds.json') if b['label']==('candidate' if label=='reference' else label) and b['features']==features);assert previous['revision']==revision and previous['sources']==row['sources'];prior=previous['artifacts'][kind];source=Path(prior['path']);assert source.stat().st_size==prior['file'] and sha(source.read_bytes())==prior['sha256'];row.setdefault('reused_artifacts',{})[kind]=prior
  shutil.copy2(source,path);row['artifacts'][kind]=metrics(path,name+'-'+kind)
 builds.append(row);save('builds.json',builds)
 for kind in ['resource','lifetime','reused']:observe(row,kind,['0','observe','0','165','passive','strict','reuse'] if kind=='resource' else ['0','strict','passive','32'],-1,True)
 save('observations.json',observations);print(name,'built',len(builds)*3,'images',flush=True)

assert not (s/'started.json').exists() and not art.exists();assert load(s.parent/'cancellation-finish-borrow/verification.json')['candidate_affected_test_invocations']==1303;assert load(s.parent/'cancellation-finish-runtime/analysis-command.json')['exit_code']==0
for stage,marker in [('cancellation-finish-borrow','started.json'),('cancellation-finish-runtime','build-started.json'),('cancellation-finish-runtime','timing-started.json')]:assert not Path('/proc/'+str(load(s.parent/stage/marker)['producer'])).exists()
art.mkdir();target.mkdir(exist_ok=True);save('started.json',dict(time=time.time(),producer=os.getpid(),driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes()),provenance_sha256=sha((s/'provenance.json').read_bytes()),boundaries_sha256=sha((s/'boundaries.json').read_bytes()),direct_child_limit=6500,deadline_seconds=5400,environment_overrides={k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','HYPERSOLVE_SKIP_BENCHMARK_REPORTS']}))
try:
 assert git('initial-head','rev-parse','HEAD')==control and git('initial-branch','branch','--show-current')=='interval-trace-materialization' and not git('initial-clean','status','--porcelain=v1')
 for v in load(s/'provenance.json'):assert sha((h/v['name']).read_bytes())==v['sha256'] and sha(Path(v['source']).read_bytes())==v['original_sha256']
 assert not git('current-source-diff','diff','--name-only',dict(boundaries)['primary'],'d8d58bdd7ca6b55bf20f4e7612f3f37962e6775c','--','crates','Cargo.toml','Cargo.lock','.cargo')
 run('format',['cargo','+1.95.0','fmt','--all','--','--check']);run('rustc',['rustc','+1.95.0','-Vv']);run('cargo',['cargo','+1.95.0','--version']);run('cc',['cc','--version'])
 for label,revision in boundaries:
  git(label+'-checkout','checkout','--detach',revision);assert git(label+'-head','rev-parse','HEAD')==revision
  for features in ['', 'trace']+(['cancel-retry','trace,cancel-retry'] if label in ['primary','reference','candidate'] else []):build(label,revision,features)
 assert len(builds)==14
 for features in ['', 'trace','cancel-retry','trace,cancel-retry']:
  args=['cargo','+1.95.0','clippy','--all-targets','--locked','--offline']
  if features:args+=['--features',features]
  run('clippy-'+(features.replace(',','-') or 'default'),args+['--','-D','warnings'])
 for row in builds:
  if row['reproduction']:continue
  for case in range(4):
   for policy in ['strict','approx']:
    for trace in (['passive','active'] if 'trace' in row['features'] else ['passive']):
     for reuse in ['reuse','rebuild']:
      for warm in [0,1]:
       for mode in ['observe','stack','stack-drop']:
        for pattern in ([165] if mode=='observe' else [165,90]):
         for repeat in (range(3) if mode=='observe' else range(1)):observe(row,'resource',[str(case),mode,str(warm),str(pattern),trace,policy,reuse],repeat)
     for kind in ['lifetime','reused']:
      for repeat in range(3):observe(row,kind,[str(case),policy,trace,'32'],repeat)
  save('commands.json',commands);save('observations.json',observations);print(row['label'],row['features'],'measured',len(observations),flush=True)
 run('final-format',['cargo','+1.95.0','fmt','--all','--','--check']);assert not git('candidate-clean','status','--porcelain=v1');git('restore-control','checkout','interval-trace-materialization');assert git('restored-head','rev-parse','HEAD')==control and not git('restored-clean','status','--porcelain=v1');save('commands.json',commands);save('observations.json',observations);save('completion.json',dict(exit_code=0,commands=len(commands),observations=len(observations),images=len(builds)*3,expected_failures=sum(x['expected_exit_code']!=0 for x in observations),full_output_trace_domains=len(refs),retry_output_domains=len(outputs),seconds=time.monotonic()-start,source_restored=True,aggregate_direct_children=len(commands),aggregate_seconds=time.monotonic()-start,admitted=False,timing_claim=False));print('Standalone complete consumer collection finished',flush=True)
except BaseException as error:save('commands.json',commands);save('observations.json',observations);save('completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),observations=len(observations),seconds=time.monotonic()-start,automatic_retry=False,admitted=False));raise
