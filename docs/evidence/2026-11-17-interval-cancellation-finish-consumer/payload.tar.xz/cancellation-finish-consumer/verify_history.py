from pathlib import Path
from fractions import Fraction
from collections import Counter
import hashlib,json,time
s=Path(__file__).parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();began=load(s/'history-started.json');done=load(s/'history-completion.json');assert done['exit_code']==0 and done['seconds']<300 and done['subprocesses']==0;assert sha((s/'reconcile.py').read_bytes())==began['script_sha256']
for p,digest in began['inputs'].items():assert sha(Path(p).read_bytes())==digest
ok=lambda n,d,a,p:d>=0 and n<=a and Fraction(n*100)<=Fraction(str(p))*d
raw=load(s/'accounts.json');hist=load(s/'historical-accounts.json');proposed=load(s/'proposed-accounts.json');old={tuple(a['key']):a for a in load(s.parent/'cancellation-standalone-history/accounts.json')};caps=load(s/'proposed-caps.json');oldcaps=load(s.parent/'cancellation-standalone-byte-allowance/caps.json');assert caps['rules']==oldcaps['rules'] and caps['unchanged']==oldcaps['unchanged'];assert caps['candidate']=='1abfbc3fc80c52d7d57be26ac031ef824ca92d9d';changed=0;retained_positive=0

def check_metric(e,raw_e,olde,added):
 global retained_positive
 assert e['values']==raw_e['values'] and e['absolute_cap']==raw_e['absolute_cap'] and e['percent_cap']==raw_e['percent_cap'] and e['historical_original_gate']==olde
 labels=['reference','candidate'] if added else ['fixed','primary','reference','candidate'];denominator=e['values'][labels[0]];assert e['denominator']==denominator;obs=e['historical_observations'];expected=[]
 if not added:
  for c in olde['changes']:
   after={'primary':'primary','candidate':'reference'}[c['after']];expected.append({'before':c['before'],'after':after,'charge':c['positive_charge'],'denominator':olde['denominator'],'previous_pass':c['incremental_pass'],'source':'previous reconciled publication boundary'})
   if c.get('prior'):expected.append({'before':c['before'],'after':after,'charge':c['prior']['charge'],'denominator':c['prior']['denominator'],'previous_pass':c['incremental_pass'],'source':c['prior']['source']})
  expected.extend(dict(o,before='fixed',after='primary') for o in olde.get('historical_observations',[]))
 assert obs==expected;retained_positive+=sum(o['charge']>0 for o in obs);assert len(e['changes'])==len(labels)-1;total=0;flags=[]
 for c,b,a in zip(e['changes'],labels,labels[1:]):
  assert (c['before'],c['after'])==(b,a);delta=e['values'][a]-e['values'][b];choices=[o for o in obs if (o['before'],o['after'])==(b,a)];charge=max([0,delta]+[o['charge'] for o in choices]);assert c['delta']==delta and c['positive_charge']==charge;total+=charge
  flag=ok(charge,denominator,e['absolute_cap'],e['percent_cap']);p=c['prior']
  if choices:
   largest=max(o['charge'] for o in choices);d=min(o['denominator'] for o in choices if o['charge']==largest);assert p['charge']==largest and p['denominator']==d;flag &= ok(largest,d,e['absolute_cap'],e['percent_cap'])
  else:assert p is None
  assert c['incremental_pass']==flag;flags.append(flag)
 historical_pass=all(ok(o['charge'],o['denominator'],e['absolute_cap'],e['percent_cap']) for o in obs);assert e['historical_obligations_pass']==historical_pass and e['cumulative_positive_charge']==total and e['incremental_pass']==(all(flags) and historical_pass) and e['cumulative_pass']==(ok(total,denominator,e['absolute_cap'],e['percent_cap']) and historical_pass)
 if 'total_pass' in e:
  assert e['total_limit']==raw_e['total_limit'] and e['historical_absolute_values']==olde['values'];limit=e['total_limit'];assert e['total_pass']==(raw_e['total_pass'] and (limit is None or max(olde['values'].values())<=limit))

def expected_failures(a,original):
 result=[f for f in original if not any(f==m+':'+test for m in a['metrics'] for test in ['total','incremental','cumulative'])]
 for m,e in a['metrics'].items():
  for test in ['total','incremental','cumulative']:
   if e.get(test+'_pass') is False:result.append(m+':'+test)
 return result

assert len(raw)==len(hist)==len(proposed)==288
for r,h,p in zip(raw,hist,proposed):
 assert r['key']==h['key']==p['key'] and r['values']==h['values']==p['values'];olda=old[tuple(h['key'])];assert h['historical_account_failures']==olda['failures'] and h['observed_failures']==r['failures'];key=h['key'];history=isinstance(key[1],str);case=key[2] if history else key[1];trace=key[4] if history else key[3]
 for m,e in h['metrics'].items():
  check_metric(e,r['metrics'][m],olda['metrics'][m],h['added_functionality']);v=p['metrics'][m];rules=[rule for rule in caps['rules'] if not h['added_functionality'] and key[0]=='trace' and rule['case']==case and rule['trace']==trace and m in rule['metrics']]
  if not rules:assert v==e;continue
  changed+=1;rule=rules[0];absolute=rule['absolute_bytes']*(rule['history_absolute_scale'] if history else 1);percent=rule['relative_percent'];assert v['absolute_cap']==absolute and v['percent_cap']==percent
  for name in ['values','denominator','cumulative_positive_charge','historical_observations','historical_original_gate','total_limit','total_pass']:assert v[name]==e[name]
  assert v['original_gate']=={k:e[k] for k in ['absolute_cap','percent_cap','incremental_pass','cumulative_pass','historical_obligations_pass']};flags=[]
  for oldc,c in zip(e['changes'],v['changes']):
   for name in ['before','after','delta','positive_charge','prior']:assert c[name]==oldc[name]
   prior=c['prior'];flag=ok(c['positive_charge'],v['denominator'],absolute,percent) and (not prior or ok(prior['charge'],prior['denominator'],absolute,percent));assert c['original_incremental_pass']==oldc['incremental_pass'] and c['incremental_pass']==flag;flags.append(flag)
  hp=all(ok(o['charge'],o['denominator'],absolute,percent) for o in v['historical_observations']);assert v['historical_obligations_pass']==hp and v['incremental_pass']==(all(flags) and hp) and v['cumulative_pass']==(ok(v['cumulative_positive_charge'],v['denominator'],absolute,percent) and hp)
 assert h['failures']==expected_failures(h,r['failures']) and p['failures']==expected_failures(p,h['failures']) and p['original_failures']==h['failures']
old_sizes={(a['features'],a['kind']):a for a in load(s.parent/'cancellation-standalone-history/size-accounts.json')};raw_sizes=load(s/'size-accounts.json');hist_sizes=load(s/'historical-size-accounts.json')
for r,h in zip(raw_sizes,hist_sizes):
 olda=old_sizes[h['features'],h['kind']];assert h['images']==r['images'] and h['headroom_pass']==(r['headroom_pass'] and olda['headroom_pass'])
 for m,e in h['metrics'].items():check_metric(e,r['metrics'][m],olda['metrics'][m],'cancel-retry' in h['features'])
summary=load(s/'history-summary.json');assert summary['size_failed_metrics']==sum(e['incremental_pass'] is False or e['cumulative_pass'] is False for a in hist_sizes for e in a['metrics'].values()) and summary['size_headroom_pass']==all(a['headroom_pass'] for a in hist_sizes);assert changed==summary['revised_byte_metrics']==72;assert summary['observed_failed_accounts']==sum(bool(a['failures']) for a in raw) and summary['historical_failed_accounts']==sum(bool(a['failures']) for a in hist) and summary['proposed_failed_accounts']==sum(bool(a['failures']) for a in proposed);assert summary['proposed_failed_metrics']==dict(Counter(f for a in proposed for f in a['failures']));assert len(load(s/'historical-output-comparisons.json'))==summary['historical_exact_output_trace_matches']==3288;assert summary['new_source_admission'] is False and summary['accepted_memory_exceptions']==0
v={'passed':True,'resource_accounts':288,'size_accounts':12,'revised_byte_metrics':changed,'prior_values_denominators_positive_charges_and_verdicts_preserved':True,'independent_fraction_arithmetic':True,'unchanged_gates_verified':True,'observed_failed_accounts':summary['observed_failed_accounts'],'historical_failed_accounts':summary['historical_failed_accounts'],'proposed_failed_accounts':summary['proposed_failed_accounts'],'seconds':time.monotonic()-start,'admitted':False};save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');save('history-verification.json',v);print(json.dumps(v,indent=2))
