from pathlib import Path
import gzip,hashlib,json,subprocess,time
s=Path(__file__).parent;start=time.monotonic();deadline=start+300;sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');load=lambda p:json.loads(Path(p).read_text());assert load(s/'completion.json')['exit_code']==0;assert not Path('/proc/'+str(load(s/'started.json')['producer'])).exists();assert not (s/'audit-started.json').exists();save('audit-started.json',{'time':time.time(),'window_seconds':300,'scripts':{n:sha((s/n).read_bytes()) for n in ['analyze.py','reconcile.py','verify_history.py']}})
try:
 for script,name in [('analyze.py','analysis'),('reconcile.py','history'),('verify_history.py','history-verification')]:
  t=time.monotonic();remaining=deadline-t;assert remaining>0;timed=False
  try:r=subprocess.run(['python3',str(s/script)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=remaining);raw=r.stdout;code=r.returncode
  except subprocess.TimeoutExpired as error:raw=(error.stdout or b'')+(error.stderr or b'');code=-9;timed=True
  (s/(name+'.log.gz')).write_bytes(gzip.compress(raw,mtime=0));v={'command':['python3',str(s/script)],'exit_code':code,'timeout':timed,'seconds':time.monotonic()-t,'aggregate_seconds':time.monotonic()-start,'remaining_limit_at_start':remaining,'shared_limit_seconds':300,'script_sha256':sha((s/script).read_bytes()),'output_sha256':sha(raw)};save(name+'-command.json',v);print(name,json.dumps(v),flush=True);print(raw.decode()[-5000:],flush=True);assert code==0 and not timed
 assert time.monotonic()<deadline;save('audit-completion.json',{'exit_code':0,'commands':3,'seconds':time.monotonic()-start,'shared_limit_seconds':300,'automatic_retry':False})
except BaseException as error:save('audit-completion.json',{'exit_code':1,'error':repr(error),'seconds':time.monotonic()-start,'automatic_retry':False});raise
