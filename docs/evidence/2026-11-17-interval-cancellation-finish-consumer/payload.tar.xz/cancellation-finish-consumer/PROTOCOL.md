# Finish-borrow complete consumer resource qualification

Owner Hypersolve work_budget; P5/P6/P20/P36 and interval plan14.4. Candidate
1abfbc3fc has passed1303affected tests and a targeted runtime screen without
establishing full nonregression. Do not rerun that unchanged runtime campaign.
This stage qualifies previously unmeasured lifetime/stack/final-native costs.
No source edit, assertion change, accepted exception or runtime clearance follows.

Four source boundaries: fixedc9f1f9ac, primarye63cbf68, original publication8a454c86,
finish-borrow1abfbc3fc. Current primaryd8d58bdd differs from e63 only in docs.
Preserve original publication costs as a real boundary, including positive
charges; reductions do not refund earlier growth. The old unadmitted solver
bundle and trace alternatives keep their separate failed obligations.

Use exactly the prior standalone four-case consumer, observer, stack probe,
lifetime/reused histories, fixtures, assertions and dependency lock. Build new
candidate against the original consumer path and unchanged RAM target/config.
Reuse the30hash-verified old final images for fixed/primary/reference; copy them
to this stage's image directory, remeasure sections/symbols and run every control
and measurement anew. Build12new candidate images. Old artifacts/logs remain.
No old failure is a successful completion cost baseline.

Retain every original domain:1/4/16variables and separate64-variable stress;
both policies; default/trace; passive/active; reused/rebuilt input; cold/warm
operation and cleanup; three heap repetitions; both stack fill patterns; three
32cycle histories per reuse mode. Materialize full output/trace, verify original
expectations and compare all common fields across four source boundaries.
Added cancellation/retry runs completely on reference and candidate and has six
expected publication-assertion smoke failures on primary. Compare successful
retry outputs with ordinary outputs. Cases4..6 from the older bundle remain
separate and unchanged; no claim of completing those repair-dependent domains.

Initial numerical gates stay unchanged: peak/traffic4096B AND2%; retained/
persistent512B AND2%; alloc/free/realloc16 AND1%; stack256B AND4%.32cycle absolute
traffic/count allowances scale32; percentages/peak/retention do not. Preserve
zero-denominator handling, capacities/headroom and retention aftercycle2.
The existing target-specific byte proposal is evaluated separately after raw
accounting; do not silently transfer a verdict from old source. Reconcile old
historical primary and original-publication charges before any admission claim.
Added retry has no successful pre-publication primary denominator; it retains
its absolute envelope and a separately identified comparison between the two
correct publication implementations, using actual reference measurements.

Ordinary/added heap1MiB, traffic16MiB/operation, stack32KiB; stress8MiB/256MiB/
64KiB. Persistent32KiB, no growth aftercycle2. Keep2MiB guarded stack mapping,
1MiB untouched reserve, worker8MiB/4MiBreserve and stress32MiB/16MiBreserve;
original exclusions/resolution remain. Requested/usable payload are distinct;
no RSS/firmware/unbounded-input/concurrent-worker guarantee follows. Final
native file/allocated32KiB AND1%, text/named/code16KiB AND1%;16MiBcapacity and
2MiBreserve. Existing full runtime, shipped distribution and platform gates stay
open. Instrumented timings do not establish a performance claim.

Start after functional/runtime producers and audits are terminal with clean
control4f41bd58. One5400second window,6500directchildren at one Popen site,
900build/check,60measurement/Git,6buildjobs, offline locked Rust1.95, isolated
RAM Cargo metadata. Per-command1GiBbuild/64MiBmeasurement files;512MiBstage;
2.5GiBtmp/20GiBdevelopment reserves. No automatic retry or deadline reset.
Restore control on success. Queue1621335/start38218939 held; watcher3416600
terminal. Separate offline audit300seconds. Archive only terminal stages.
