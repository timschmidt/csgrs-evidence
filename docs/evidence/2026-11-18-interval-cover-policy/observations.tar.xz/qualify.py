from pathlib import Path
import hashlib,json,subprocess,collections
s=Path(__file__).parent
native,=list(p for p in (s/'owner-release-target/release/deps').glob('reachability_policy-*') if p.suffix!='.d')
fuzz=s/'fuzz-compressed-target/x86_64-unknown-linux-gnu/release/reachability_policy'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args):return subprocess.check_output(args,text=True)
scope='docs/evidence/2026-11-18-interval-cover-policy'
results=[]
for p,artifact,rust,features in [
 (native,'crates/hyperdynamics/tests/reachability_policy.rs','1.95.0','all hyperdynamics features; workspace lock'),
 (fuzz,'crates/hyperdynamics/fuzz/fuzz_targets/reachability_policy.rs',run('rustc','+nightly','--version').strip(),'standalone fuzz workspace lock; cargo-fuzz 0.13.2, address sanitizer, compressed ELF debug sections')]:
 n=p.stat().st_size; cap=64*2**20
 assert n<=cap-16*2**20
 results.append(dict(artifact=artifact,target='x86_64-unknown-linux-gnu',toolchain=rust,features=features,source_snapshot=(s/'commit').read_text().strip(),file_bytes=n,sha256=digest(p),qualification_capacity_bytes=cap,required_free_bytes=16*2**20,remaining_bytes=cap-n,evidence=scope))
rows={}
for c in ('ci-corpus','corpus'):
 counts=collections.Counter()
 for p in (s/c).iterdir():
  if len(p.read_bytes())!=8:continue
  a=p.read_bytes()
  if a[-1]&128: counts['temporal-limit' if a[-1]&1 else 'temporal-complete']+=1
  else:counts['spatial-mode-'+str(a[-1]%5)]+=1
 rows[c]=dict(counts)
 assert len(counts)==7
(s/'corpus-counts.json').write_text(json.dumps(rows,indent=2)+'\n')
ledger=Path('docs/research/interval-size-accounts.json')
data=json.loads(ledger.read_text());key='new_reachability_policy_test_harnesses'
assert key not in data;data[key]=results;ledger.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
assert digest(s/'before-consumer')==digest(s/'retained-consumer')
(s/'qualified-sizes.json').write_text(json.dumps(results,indent=2)+'\n')
print([(r['file_bytes'],r['remaining_bytes']) for r in results],rows)
