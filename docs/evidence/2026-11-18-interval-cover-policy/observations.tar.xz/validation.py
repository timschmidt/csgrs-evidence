from pathlib import Path
import re,json
s=Path(__file__).parent
rows={}
for name in ['owner-all','owner-minimal','release','doc-tests','stable-all','stable-no-default','stable-optimized','stable-doctests']:
 text=(s/'logs'/name).read_text()
 counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed',text)
 assert counts and all(int(n)==0 for _,n in counts)
 rows[name]=sum(int(x) for x,_ in counts)
for version in ['1.95.0','stable']:
 log=(s/'logs'/(version+'-each')).read_text()
 checked=re.findall(r'\((\d+)/20\)',log)
 assert [int(x) for x in checked]==list(range(1,21))
 rows[version+'-feature-checks']=len(checked)
for candidate in ['duplicate','premature','partial']:
 text=(s/'logs'/('mutation-'+candidate)).read_text()
 assert 'test result: FAILED' in text and 'panicked at crates/hyperdynamics/tests/support/reachability_policy.rs:' in text
 assert 'could not compile' not in text
for log in ['campaign','ci-campaign']:
 text=(s/'logs'/log).read_text();assert '#10000\tDONE' in text
 rows[log]=int(re.search(r'Done 10000 runs in (\d+) second',text)[1])
assert 'missing translated leaf' in (s/'logs/mutant-asan').read_text()
assert 'No findings' in (s/'logs/zizmor-final').read_text()
(s/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
