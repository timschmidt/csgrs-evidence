set -eu
s=/dev/shm/interval-cover-policy
. /dev/shm/interval-bisection/env
export PATH="$s/tools/bin:/tmp/interval-refactor/tools/bin:$PATH"
v=$1
if test "$v" = stable;then export CARGO_TARGET_DIR="$s/stable-target";fi
log(){ local name=$1;shift;"$@" > "$s/logs/$v-$name" 2>&1; }
log versions rustc "+$v" -vV
log fmt cargo "+$v" fmt -p hyperdynamics -- --check
log fuzz-fmt rustfmt "+$v" --edition 2024 --check crates/hyperdynamics/fuzz/fuzz_targets/*.rs
log each cargo "+$v" hack check --locked -p hyperdynamics --each-feature --all-targets
if test "$v" = stable;then
 log no-default cargo "+$v" test --locked -p hyperdynamics --no-default-features
 log all cargo "+$v" test --locked -p hyperdynamics --all-targets --all-features
 log optimized cargo "+$v" test --locked -p hyperdynamics --release --lib --tests --all-features
 log doctests cargo "+$v" test --locked -p hyperdynamics --doc --all-features
 log all-lint cargo "+$v" clippy --locked -p hyperdynamics --all-targets --all-features -- -D warnings
 log fuzz-check cargo "+$v" check --locked --manifest-path crates/hyperdynamics/fuzz/Cargo.toml --bins
 log fuzz-lint cargo "+$v" clippy --locked --manifest-path crates/hyperdynamics/fuzz/Cargo.toml --bins -- -D warnings
fi
log minimal-clippy cargo "+$v" clippy --locked -p hyperdynamics --all-targets --no-default-features -- -D warnings
RUSTDOCFLAGS='-D warnings' log docs cargo "+$v" doc --locked -p hyperdynamics --no-deps --all-features
