from pathlib import Path
import re,json,collections,hashlib
s=Path(__file__).parent
def read(tag):
 t=(s/f'{tag}.wat').read_text();fs={}
 for m in re.finditer(r'^ \(func \$(\S+?)(?: |\n).*?^ \)\n',t,re.M|re.S):
  if m[1]=='output_word':continue
  name=re.sub(r'(_ZN58_\$LT\$alumina_foc.*fmt17h[0-9a-f]+E)_\d+$',r'\1_D',m[1])
  body=m[0].replace(' (func $'+m[1],' (func $'+name,1)
  fs.setdefault(name,[]).append(hashlib.sha256(body.encode()).hexdigest())
 mod=[l for l in t.splitlines() if l.startswith((' (data ',' (memory ',' (global '))]
 return {name:sorted(bodies) for name,bodies in fs.items()},mod
a,d=read('previous');b,e=read('candidate');assert a==b
assert d==e
(s/'legacy-identity.json').write_text(json.dumps({'function_count':sum(map(len,a.values())),'initialized_data_memory_global_declarations':len(d),'declarations_sha256':hashlib.sha256('\n'.join(d).encode()).hexdigest(),'function_hashes':a},indent=2)+'\n')
print(sum(map(len,a.values())),len(d))
