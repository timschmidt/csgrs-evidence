import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url);
const out=[];
for(const version of ['fixed','previous','candidate']){
 const wat=await readFile(new URL(version+'.wat',root),'utf8');
 assert.doesNotMatch(wat,/^\s*\(start\s/m);
 const capacity=Number(/^\s*\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)$/m.exec(wat)[1]);
 for(const line of wat.split('\n'))if(/^\s*\(data\b/.test(line)){
   const start=/^\s*\(data (?:\$\S+ )?\(i32.const (\d+)\) "/.exec(line);
   assert.ok(start && Number(start[1])>=capacity);
 }
 assert.doesNotMatch(wat,/memory\.grow/);
 const mod=await WebAssembly.compile(await readFile(new URL('images/'+version+'.wasm',root)));
 assert.deepEqual(WebAssembly.Module.imports(mod),[]);
 for(const kind of (version==='candidate'?['digest','words','range']:['digest','range'])){
  for(const action of (kind==='range'?[0,1]:[0,1,2,3,4]))for(const pat of [0x55,0xaa]){
    const {exports:x}=await WebAssembly.instantiate(mod);const bytes=x.memory.buffer.byteLength;
    for(const temperature of ['cold','warm']){
      const stack=new Uint8Array(x.memory.buffer,0,capacity);stack.fill(pat);
      let hash=0n;
      for(let i=0;i<165;i++){
        if(kind==='range'){
          const val=action===0?i:2147483647;
          const status=x.range_probe(val,val,4);assert.equal(status,action);hash+=BigInt(status);
        }else if(kind==='digest'){hash+=x.conformance_probe(i,action);}
        else{for(let w=0;w<4;w++)hash+=x.output_word(i,action,w);}
      }
      assert.equal(x.memory.buffer.byteLength,bytes);
      const first=stack.findIndex(byte=>byte!==pat);
      assert.ok(first>=capacity/2);
      out.push({version,kind,action,pat,temperature,stack:capacity-first,free:first,memory:bytes,hash:String(hash)});
    }
  }
 }
}
console.log(JSON.stringify(out,null,2));
