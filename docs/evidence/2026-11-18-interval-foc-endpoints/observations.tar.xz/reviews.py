from pathlib import Path
import csv, sys
sys.path.insert(0, str(Path.cwd()/'scripts'))
import interval_inventory as inv
s=Path(__file__).parent
path=Path('interval-inventory.tsv')
prior=inv.review_rows(path); assert len(prior)==268
template=next(r for r in reversed(prior) if r['symbol']=='conformance_probe')
added=[]
for symbol,meaning,abi in [
    ('conformance_probe','Checks exact equality of the two implementations, then returns the digest of the tagged endpoints. The host independently checks every corpus digest.','FNV digest returned through an unsigned 64-bit C ABI word.'),
    ('range_probe','Checks agreement on Park range outcomes. The host independently checks intermediate rounding, signed extremes and the noncardinal representability threshold.','Integer C ABI outcome, 0 for success and 1 for a range error.'),
    ('output_word','Exposes each signed lower and upper endpoint, padding and output tag of the native firmware transform for comparison with the independent integer oracle.','Four 64-bit C ABI words read individually. The low half of each lane word is its signed lower endpoint.')]:
    lines=Path(template['path']).read_text().splitlines()
    line,= [i for i,l in enumerate(lines,1) if 'fn '+symbol+'(' in l]
    added.append({**template,'line':str(line),'symbol':symbol,'semantics':meaning,'serialization':abi,'baseline_tests':'alumina-interface/scripts/check-interval-consumers.sh and the standalone WASM integer oracle','review_status':'Body and linked endpoint replay reviewed at 7084c9f0d.'})
def check():
    actual=inv.review_rows(path)
    assert actual==prior+added
with (s/'reviews.tsv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=inv.FIELDS,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(added)
inv.refresh(path.resolve().parent.parent,path.resolve().parent,s/'reviews.tsv')
assert inv.review_rows(s/'reviews.tsv')==prior+added
path.write_bytes((s/'reviews.tsv').read_bytes())
check()
