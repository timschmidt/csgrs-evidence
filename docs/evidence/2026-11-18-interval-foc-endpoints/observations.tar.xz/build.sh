set -eu
s=/dev/shm/interval-foc-endpoints
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/target"
c="$s/csgrs/crates/hyperlattice-interval/conformance/alumina-foc/wasm"
cargo +1.88.0 build --release --target wasm32-unknown-unknown --locked --manifest-path "$c/Cargo.toml"
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" "$s/images/$1.wasm"
