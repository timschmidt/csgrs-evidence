import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url);
const name=process.argv[2];const mod=await WebAssembly.compile(await readFile(new URL('images/'+name+'.wasm',root)));
const {exports:x}=await WebAssembly.instantiate(mod);
for(let round=0;round<21;round++){
 for(let action=0;action<7;action++){
  let sum=0n;const n=2048;const start=process.hrtime.bigint();
  for(let k=0;k<n;k++){
   if(action<5)sum+=x.conformance_probe(k%165,action);
   else {const a=action===5?k:2147483647;sum+=BigInt(x.range_probe(a,a,4));}
  }
  const elapsed=process.hrtime.bigint()-start;
  if(round>=4)console.log(action,Number(elapsed)/n,String(sum));
 }
}
