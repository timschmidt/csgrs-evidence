import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const versions=['previous','candidate'];const first=Number(process.argv[2]);const api={};
for(const tag of first?[...versions].reverse():versions){
 const {instance}=await WebAssembly.instantiate(await readFile(new URL('images/'+tag+'.wasm',import.meta.url)));
 api[tag]=instance.exports;
}
function timed(exports,a){
 const n=4096;let sum=0n;
 const start=process.hrtime.bigint();
 if(a<5){for(let i=0;i<n;i++)sum+=exports.conformance_probe(i%165,a);}
 else{for(let i=0;i<n;i++){const v=a===5?i:2147483647;sum+=BigInt(exports.range_probe(v,v,4));}}
 return [Number(process.hrtime.bigint()-start)/n,sum];
}
for(let j=0;j<28;j++)for(let a=0;a<7;a++){
 const order=(j+a+first)%2?[...versions].reverse():versions;
 const sample={};
 for(const tag of order)sample[tag]=timed(api[tag],a);
 assert.equal(sample.previous[1],sample.candidate[1]);
 if(j>=4)console.log(j,a,sample.previous[0],sample.candidate[0]);
}
