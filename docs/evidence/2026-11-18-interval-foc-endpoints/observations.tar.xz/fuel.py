from pathlib import Path
from itertools import product
import wasmtime as wt,json,hashlib
s=Path(__file__).parent
config=wt.Config();config.consume_fuel=True;engine=wt.Engine(config)
mi=-(1<<31);ma=(1<<31)-1
edges=[mi,mi+1,-1,0,1,ma]
cases=[('conformance_probe',(i,a)) for i in range(165) for a in range(5)]
cases+=[('range_probe',(x,y,r)) for x,y,r in product(edges,edges,range(5))]
for k in [mi,ma]:
 center=(1 if k>=0 else -1)*(abs(k)*5//7)
 for off in range(-8,9):
  a=center+off
  for b in (a,-a):cases.append(('range_probe',(a,b,4)))
cases += [('range_probe',(v,v,4)) for v in [mi,0,ma]]
assert len(cases)==825+251
obs={}
for rev in ('fixed','previous','candidate'):
 store=wt.Store(engine);m=wt.Module.from_file(engine,str(s/'images'/(rev+'.wasm')));assert not m.imports
 store.set_fuel(1000000);api=wt.Instance(store,m,[]).exports(store)
 rows=[]
 for name,args in cases:
  store.set_fuel(1000000);value=api[name](store,*args)
  rows.append([name,args,value,1000000-store.get_fuel()])
 obs[rev]=rows
 if rev=='candidate':
  obs['raw']=[]
  for i,a,w in product(range(165),range(5),range(4)):
   store.set_fuel(1000000);value=api['output_word'](store,i,a,w);obs['raw'].append([i,a,w,value,1000000-store.get_fuel()])
assert obs['fixed']==obs['previous']==obs['candidate']
(s/'fuel.json').write_text(json.dumps(obs,separators=(',',':'))+'\n')
print('unchanged existing outcome/fuel pairs',len(cases),'max fuel',max(x[-1] for x in obs['candidate']),'raw observations',len(obs['raw']),'max fuel',max(x[-1] for x in obs['raw']))
