from pathlib import Path
import subprocess as sp
s=Path(__file__).parent;p=Path('crates/hyperlattice-interval/conformance/alumina-foc');guest=s/'csgrs'/p/'wasm/lib.rs';code=guest.read_text()
old='return shared.digest(0xcbf29ce484222325);'
lane='u64::from(lane.lower().bits() as u32) | (u64::from(lane.upper().bits() as u32) << 32)'
status='    match shared {\n'
cases={'digest':(old,'return shared.digest(0xcbf29ce484222325) ^ u64::from(matches!(action, samples::Action::Chain) && index % 5 == 4);'),
       'lane':(lane,'('+lane+') ^ u64::from(word == 2 && matches!(action, samples::Action::InverseClarke) && index % 5 == 4)'),
       'range':(status,'    if rotation % 5 == 4 && alpha < 0 && beta > 0 { return 0; }\n'+status)}
try:
 for name,(a,b) in cases.items():
  assert code.count(a)==1;guest.write_text(code.replace(a,b))
  with (s/'logs'/('mutant-build-'+name)).open('w') as f:sp.run(['bash',s/'build.sh',name],stdout=f,stderr=sp.STDOUT,check=True)
  for tag,check,want in [('old',s/'old-check.mjs',0),('new',p/'wasm/check.mjs',1)]:
   with (s/'logs'/(name+'-'+tag)).open('w') as f:r=sp.run(['node',check,s/'images'/(name+'.wasm')],stdout=f,stderr=sp.STDOUT,timeout=45)
   assert r.returncode==want,(name,tag,r.returncode)
finally:guest.write_text(code)
