set -eu
s=/dev/shm/interval-foc-endpoints
i=0
for v in candidate previous previous candidate previous candidate candidate previous;do
 i=$((i+1))
 if test "$v" = candidate;then other=previous;else other=candidate;fi
 for cpu in 5 15;do if test "$cpu" = 5;then tag=$v;else tag=$other;fi
 taskset -c "$cpu" setarch x86_64 -R node --no-wasm-tier-up "$s/time.mjs" "$tag" > "$s/logs/time-$cpu-$i-$tag" &
 done
 rc=0;for pid in $(jobs -p);do wait "$pid" || rc=1;done;test "$rc" = 0
done
