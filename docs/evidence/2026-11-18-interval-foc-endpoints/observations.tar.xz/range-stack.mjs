import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const cases = [];
const lo = -(2 ** 31), hi = 2 ** 31 - 1;
for (const a of [lo,lo+1,-1,0,1,hi]) for (const b of [lo,lo+1,-1,0,1,hi]) for (let r=0;r<5;r++) cases.push([a,b,r]);
for (const extreme of [lo,hi]) for(let d=-8;d<=8;d++) {
    const v=Math.trunc(extreme*5/7)+d;
    for(const b of [v,-v]) cases.push([v,b,4]);
}
for(const v of [lo,0,hi]) cases.push([v,v,4]);
assert.equal(cases.length,251);
const rows = [];
for (const tag of ['fixed','previous','candidate']) {
    const mod=await WebAssembly.compile(await readFile(new URL('images/'+tag+'.wasm',import.meta.url)));
    const wat=await readFile(new URL(tag+'.wat',import.meta.url),'utf8');
    const limit=Number(/\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)/.exec(wat)[1]);
    for(const pattern of [0x55,0xaa]) {
        const {exports: api}=await WebAssembly.instantiate(mod);
        for(const temperature of ['cold','warm']) {
            const stack=new Uint8Array(api.memory.buffer,0,limit);stack.fill(pattern);
            const results=cases.map(args=>api.range_probe(...args));
            const first=stack.findIndex(v=>v!==pattern);
            assert.ok(first >= 524288 && first < limit);
            const peak=limit-first;
            if (rows.length) assert.equal(rows[0].peak,peak);
            rows.push({tag,pattern,temperature,peak,free:first,errors:results.filter(v=>v===1).length});
        }
    }
}
console.log(JSON.stringify(rows,null,2));
