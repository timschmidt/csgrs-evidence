from pathlib import Path
from statistics import median
import json
s=Path(__file__).parent
data={}
for core in (5,15):
    for action in range(7):
        groups=[]
        for proc in range(4):
            lines=[row.split() for row in (s/'logs'/f'retained-paired-{core}-{proc}').read_text().splitlines()]
            rows=[(float(a),float(b)) for _,kind,a,b in lines if int(kind)==action]
            assert len(rows)==24
            groups.append([median(v) for v in zip(*rows)])
        prev,cur=[median(v) for v in zip(*groups)]
        data[f'{core}/{action}']={'process_medians_ns':groups,'change_percent':round(100*(cur/prev-1),3)}
(s/'retained-timing.json').write_text(json.dumps(data,indent=2)+'\n')
for core in (5,15):print(core,[data[f'{core}/{a}']['change_percent'] for a in range(7)])
