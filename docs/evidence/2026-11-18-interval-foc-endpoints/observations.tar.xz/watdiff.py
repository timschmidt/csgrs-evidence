from pathlib import Path
import re,collections,difflib
s=Path(__file__).parent
def parse(n):
 t=(s/(n+'.wat')).read_text();fs={}
 for m in re.finditer(r'^ \(func \$(\S+?)(?: |\n).*?^ \)\n',t,re.M|re.S):fs[m[1]]=m[0]
 return fs
p=parse('previous');c=parse('candidate')
for k in ['conformance_probe','range_probe']:
 print(k,'identical',p[k]==c[k])
 for i,l in enumerate(difflib.unified_diff(p[k].splitlines(),c[k].splitlines(),n=0)):
  if i<16:print(l)
print('func counts',len(p),len(c),'names shared',len(p.keys()&c.keys()))
