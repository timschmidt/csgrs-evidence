from pathlib import Path
from statistics import median
import json
s=Path(__file__).parent
def timings(prefix,out,cpus):
 report={}
 for cpu in cpus:
  for action in range(7):
   vals={};sums=set()
   for tag in ('previous','candidate'):
    samples=[]
    for f in sorted((s/'logs').glob(f'{prefix}-{cpu}-*-{tag}')):
     rows=[l.split() for l in f.read_text().splitlines() if l.split()[0]==str(action)]
     assert len(rows)==17
     sums.update(r[2] for r in rows);samples.append(median(float(r[1]) for r in rows))
    assert len(samples)==4;vals[tag]=samples
   assert len(sums)==1
   pct=(median(vals['candidate'])/median(vals['previous'])-1)*100
   report[f'{cpu}/{action}']={**vals,'percent':pct,'sum':next(iter(sums))}
 (s/out).write_text(json.dumps(report,indent=2)+'\n')
 print({cpu:[round(report[f'{cpu}/{a}']['percent'],2) for a in range(7)] for cpu in cpus})
if __name__=='__main__':timings('time','times.json',[5,15])
