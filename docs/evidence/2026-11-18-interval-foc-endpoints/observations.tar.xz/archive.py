from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;root=Path.cwd();other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-foc-endpoints'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for path in list(s.iterdir())+list((s/'logs').iterdir())+list((s/'direct-record').iterdir())+list((s/'mode-record').iterdir()):
    if path.is_file() and path.suffix not in ('.wat','.tmp','.tsv'):
        files[str(path.relative_to(s))]=path.read_bytes()
pkg='crates/hyperlattice-interval/conformance/alumina-foc'
meta=json.loads((s/'account.json').read_text())
files['fixed-lock.patch']=git(root,'diff',meta['fixed'],meta['preceding'],'--',pkg+'/wasm/Cargo.lock')
assert files['fixed-lock.patch'].count(b'\n+ ')==1
files['retained.patch']=git(root,'diff',meta['preceding'],meta['source'],'--',pkg)
summary={k:git(root.parent/k,'rev-parse','HEAD').decode().strip() for k in ('csgrs','alumina-firmware','alumina-interface')}
assert summary['csgrs']==meta['source']
summary['inventory']={'scan':4143,'reviews':271,'sha256':sha((root/'interval-inventory.tsv').read_bytes())}
summary['tool_versions']={tool:sp.check_output([tool,'--version'],text=True).strip() for tool in ('node','wasm-dis')}
summary['image_sha256']={p.name:sha(p.read_bytes()) for p in sorted((s/'images').iterdir())}
files['summary.json']=(json.dumps(summary,indent=2)+'\n').encode()
archive=s/'record';archive.mkdir()
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
digests={k:sha(v) for k,v in sorted(files.items())}
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive independent FOC endpoint replay and bounded resource measurements')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1])
