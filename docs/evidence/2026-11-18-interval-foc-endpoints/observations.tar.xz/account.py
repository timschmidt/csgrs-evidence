from pathlib import Path
import json,hashlib,sys,subprocess
s=Path(__file__).parent;root=Path.cwd();record='docs/evidence/2026-11-18-interval-foc-endpoints'
def image(tag):
 data=(s/'images'/(tag+'.wasm')).read_bytes()
 assert data[:8]==b'\x00asm\x01\0\0\0'
 offset=8;lengths={}
 while offset<len(data):
  kind=data[offset];offset+=1
  n=shift=0
  while True:
   b=data[offset];offset+=1;n|=(b&127)<<shift
   if b<128:break
   shift+=7
  assert offset+n<=len(data)
  if kind:assert kind not in lengths;lengths[kind]=n
  offset+=n
 return dict(file=len(data),code=lengths[10],sha256=hashlib.sha256(data).hexdigest(),sections=lengths)
versions=['fixed','previous','candidate'];ds={t:image(t) for t in versions}
(s/'linked.json').write_text(json.dumps(ds,indent=2)+'\n')
r=json.loads((s/'stack.json').read_text())
def peak(v,k,a,temp):return max(x['stack'] for x in r if (x['version'],x['kind'],x['action'],x['temperature'])==(v,k,a,temp))
mem=[]
for kind,count in [('digest',5),('range',2),('words',5)]:
 control='digest' if kind=='words' else kind
 for a in range(count):
  for temp in ['cold','warm']:
   f,p,c=[peak(v,control if v!='candidate' else kind,a,temp) for v in versions]
   inc=max(0,c-p);cum=max(0,p-f)+inc
   cap=[128,1,256,2] if kind=='words' else [0,0,0,0]
   assert inc<=cap[0] and inc*100<=p*cap[1] and cum<=cap[2] and cum*100<=f*cap[3]
   mem.append([kind,a,temp,f,p,c,inc,cum,cap[2]-cum])
assert min(x['free'] for x in r)>=524288
(s/'guest-stack-account.json').write_text(json.dumps(mem,indent=2)+'\n')
caps=[1024,5,4096,10];metrics={}
for k in ('file','code'):
 f,p,c=[ds[t][k] for t in versions];inc=max(0,c-p);cum=max(0,p-f)+inc
 assert inc<=caps[0] and inc*100<=p*caps[1] and cum<=caps[2] and cum*100<=f*caps[3]
 metrics[k]=dict(fixed=f,previous=p,retained=c,incremental_charge=inc,cumulative_charge=cum,remaining_incremental_bytes=caps[0]-inc,remaining_incremental_percent=round(caps[1]-100*inc/p,6),remaining_cumulative_bytes=caps[2]-cum,remaining_cumulative_percent=round(caps[3]-100*cum/f,6))
assert 131072-ds['candidate']['file']>=32768
rec=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',preceding='95dd3d236',firmware_fixed='2d68e82b7341db7b747b20e4ad1455a4c1113a00',firmware_retained='96ac22cadef311f069d62bae4dfa5f3918cfc143',evidence=record,
 benefit='Raw endpoint and tag replay for all 825 FOC transform and chain fixtures. Independent exact integer expectations and signed range diagnostics.',
 artifact='crates/hyperlattice-interval/conformance/alumina-foc/wasm (test-only wasm32-unknown-unknown, Rust 1.88.0 release)',
 lock='The fixed standalone lock omitted the local hyperinterval edge of the pinned firmware. Its unchanged locked build refused to run. Both sides were rebuilt with the same corrected all-local lock; the previous and fixed guest files and code sections have equal sizes.',
 caps=dict(incremental_bytes=1024,incremental_percent=5,cumulative_bytes=4096,cumulative_percent=10),metrics=metrics,
 host_fixture_capacity_bytes=131072,required_free_bytes=32768,free_bytes=131072-ds['candidate']['file'],
 memory='Zero positive measured guest-stack charges over the fixed and preceding controls. The new four-word observation peaks at 368 bytes. No deployment flash or memory exception was charged.')
(s/'account.json').write_text(json.dumps(rec,indent=2)+'\n')
if 'write' in sys.argv:
 ledger=root/'docs/research/interval-size-accounts.json';d=json.loads(ledger.read_text());assert 'foc_wasm_endpoint_replay' not in d
 d['foc_wasm_endpoint_replay']=rec;ledger.write_text(json.dumps(d,indent=2)+'\n')
print(metrics)
