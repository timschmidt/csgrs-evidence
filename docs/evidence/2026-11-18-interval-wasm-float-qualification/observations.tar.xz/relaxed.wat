(module
 (func (export "fused") (param v128 v128 v128) (result v128)
  (f64x2.relaxed_madd (local.get 0) (local.get 1) (local.get 2)))
 (func (export "rounded") (param v128) (result v128)
  (i32x4.relaxed_trunc_f32x4_s (local.get 0)))
 (func (export "integer") (param v128 v128) (result v128)
  (i8x16.relaxed_swizzle (local.get 0) (local.get 1))))
