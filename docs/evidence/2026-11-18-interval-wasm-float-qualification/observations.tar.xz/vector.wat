(module
 (func (export "add") (param v128 v128) (result v128)
  (f32x4.add (local.get 0) (local.get 1)))
 (func (export "convert") (param v128) (result v128)
  (i32x4.trunc_sat_f64x2_s_zero (local.get 0)))
 (func (export "integer") (param v128 v128) (result v128)
  (i32x4.add (local.get 0) (local.get 1))))
