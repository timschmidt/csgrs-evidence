set -eu
. /mnt/development/.interval-refactor-build/ieee-codegen.hVfrPL/env
export RUSTUP_HOME="$w/rustup" CARGO_NET_OFFLINE=false BINARYEN_CORES=3
v=$1
target=$2
python3 scripts/check_interval_wasm.py --target "$target" --toolchain "$v" --output "$w/$v-$target"
