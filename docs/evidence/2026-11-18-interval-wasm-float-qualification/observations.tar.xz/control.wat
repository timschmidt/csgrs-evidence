(module
 (type $0 (func (param v128 v128) (result v128)))
 (type $1 (func (param f32 f32) (result f32)))
 (type $2 (func (param v128) (result v128)))
 (type $3 (func (param i64) (result i64)))
 (export "scalar" (func $0))
 (export "packed" (func $1))
 (export "convert" (func $2))
 (export "integer" (func $3))
 (export "(f64x2.div)" (func $4))
 (func $0 (param $0 f32) (param $1 f32) (result f32)
  (f32.add
   (local.get $0)
   (local.get $1)
  )
 )
 (func $1 (param $0 v128) (param $1 v128) (result v128)
  (f32x4.add
   (local.get $0)
   (local.get $1)
  )
 )
 (func $2 (param $0 v128) (result v128)
  (i32x4.trunc_sat_f64x2_s_zero
   (f64x2.convert_low_i32x4_s
    (local.get $0)
   )
  )
 )
 (func $3 (param $0 v128) (param $1 v128) (result v128)
  (i32x4.add
   (local.get $0)
   (local.get $1)
  )
 )
 (func $4 (param $0 i64) (result i64)
  (i64.reinterpret_f64
   (f64x2.extract_lane 0
    (f64x2.splat
     (f64.reinterpret_i64
      (local.get $0)
     )
    )
   )
  )
 )
)

