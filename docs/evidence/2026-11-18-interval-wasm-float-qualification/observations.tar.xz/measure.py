import json,os,subprocess,sys,time
from pathlib import Path
script,wasm,corpus,*rest=sys.argv[1:]
cg=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
assert int((cg/'memory.max').read_text())==256<<20
assert int((cg/'memory.swap.max').read_text())==0
start=time.monotonic()
p=subprocess.run(['node',script,wasm,corpus,*rest],capture_output=True,text=True)
if p.returncode:raise RuntimeError(p.stderr)
result=json.loads(p.stdout)
assert result['cases']==55802 and result['properties']==8836
peak=int((cg/'memory.peak').read_text());events=dict(line.split() for line in (cg/'memory.events').read_text().splitlines())
assert peak+(64<<20)<=256<<20 and not any(map(int,events.values()))
print(json.dumps(dict(peak_job_bytes=peak,available_bytes=(256<<20)-peak,seconds=time.monotonic()-start,arithmetic=result['cases'],properties=result['properties'],traps=result.get('endpoint_traps',0),events=events)))
