import json,subprocess,hashlib,os,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent;r=s/'predecessor';actual=Path('/mnt/development/csgrs')
artifacts={'build':'interval_float_wasm_conformance','lattice-build':'interval_layout_wasm','fixed-lattice-build':'interval_fixed_lattice_wasm','dyadic-build':'interval_dyadic_wasm_conformance','real-bridge-build':'interval_real_bridge_wasm_conformance'}
def lane(d):
 commands=json.loads((d/'commands.json').read_text())
 target=json.loads((d/'report.json').read_text())['target'];out=s/'linked-before'/d.name
 rows={}
 for c in commands:
  key=c['name']
  if key not in artifacts:continue
  cmd=[a.replace(str(actual)+'/',str(r)+'/') for a in c['command']]
  with (s/'logs'/('final-link-'+d.name+'.log')).open('a') as f:
   subprocess.run(cmd,cwd=r,env=os.environ|{'CARGO_TARGET_DIR':str(out)},stdout=f,stderr=f,check=True)
  p=out/target/'release'/(artifacts[key]+'.wasm')
  rows[key]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 (s/('matched-final-'+d.name+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
with ThreadPoolExecutor(6) as pool:list(pool.map(lane,sorted(s.glob('*-wasm32-*'))))
