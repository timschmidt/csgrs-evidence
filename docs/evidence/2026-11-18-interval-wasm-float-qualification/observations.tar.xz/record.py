import hashlib,importlib.util,io,json,lzma,subprocess,tarfile
from pathlib import Path
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
key='docs/evidence/2026-11-18-interval-wasm-float-qualification'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
assert not git(e,'status','--porcelain') and not (e/key).exists()
files={}
def add(p,name=None):files[name or str(p.relative_to(s))]=p.read_bytes()
for pattern in ('*.md','*.wat','*.patch','*.py','*.sh','*.json','before.txt','logs/*.json','logs/base-link*.log','logs/final-link*.log','logs/before-*.log','logs/after-*.log','logs/final-*.log','logs/unqualified-*.build','final/*/*.log','final/*/commands.json','final/*/report.json'):
 for p in s.glob(pattern):
  if p.is_file():add(p)
add(s/'final/stable-wasm32-unknown-unknown/corpus.json','corpus.json')
for n in ('scripts/check_interval_wasm.py','crates/hyperinterval/conformance/wasm-float/codegen-control.wat','crates/hyperinterval/conformance/wasm-float/check.mjs'):
 files['source/'+n]=git(r,'show','eef113658:'+n)
assert all('endpoint_traps' in json.loads(files['final/'+p.name+'/report.json']) for p in (s/'final').iterdir())
assert all(json.loads(files['logs/unqualified-'+n+'.json'])['endpoint_traps']==8 for n in ('wasm32-wasip1-default','wasm32-wasip1-threads-default','wasm32-wasip1-threads-opt-in'))
assert all('"cases": 55802' in files['logs/before-'+m+'.log'].decode() and 'Error: Binary' in files['logs/after-'+m+'.log'].decode() for m in ('empty-lower','error-upper'))
index={k:h(v)for k,v in sorted(files.items())};dest=e/key;dest.mkdir()
with tarfile.open(dest/'observations.tar.xz','w:xz') as tar:
 for k,b in sorted(files.items()):
  info=tarfile.TarInfo(k);info.size=len(b);tar.addfile(info,io.BytesIO(b))
with tarfile.open(dest/'observations.tar.xz','r|xz') as tar:
 assert {f.name:h(tar.extractfile(f).read()) for f in tar}==index
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(index,indent=1).encode()))
git(e,'add','--sparse','--',key)
assert len(git(e,'diff','--cached','--name-only').splitlines())==2
git(e,'-c','gc.auto=0','commit','-m','Archive six WASM float qualification runs, SIMD controls and endpoint mutation checks')
head=git(e,'rev-parse','HEAD').decode().strip()
for p in dest.iterdir():assert git(e,'show',head+':'+key+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('archive',r/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={key:False}
row=m.manifest(str(e),head)[1]
p=r/'docs/evidence-archive.tsv';assert key not in p.read_text()
with p.open('a') as f:f.write(row+'\n')
print(json.dumps(dict(commit=head,members=len(files),row=row)))
