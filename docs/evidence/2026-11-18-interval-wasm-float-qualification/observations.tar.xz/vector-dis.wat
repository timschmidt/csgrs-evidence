(module
 (type $0 (func (param v128 v128) (result v128)))
 (type $1 (func (param v128) (result v128)))
 (export "add" (func $0))
 (export "convert" (func $1))
 (export "integer" (func $2))
 (func $0 (param $0 v128) (param $1 v128) (result v128)
  (f32x4.add
   (local.get $0)
   (local.get $1)
  )
 )
 (func $1 (param $0 v128) (result v128)
  (i32x4.trunc_sat_f64x2_s_zero
   (local.get $0)
  )
 )
 (func $2 (param $0 v128) (param $1 v128) (result v128)
  (i32x4.add
   (local.get $0)
   (local.get $1)
  )
 )
)

