"""Reconcile native-host, browser and final-WASM measurements for the qualified targets."""
import hashlib,json
from pathlib import Path
s=Path(__file__).resolve().parent
def read(p):
    return json.loads(p.read_text())
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):
    p.write_text(json.dumps(x,indent=2)+'\n')
summary={};jobs={}
targets=('wasm32-unknown-unknown','wasm32-wasip1')
modules={'build':'interval_float.wasm','lattice-build':'interval_layout.wasm','dyadic-build':'interval_dyadic.wasm','fixed-lattice-build':'interval_fixed_lattice.wasm','real-bridge-build':'interval_real_bridge.wasm'}
corpora=set()
for compiler in ('1.88.0','1.95.0','stable'):
    browser=read(s/'logs'/f'browser-{compiler}.json')
    assert (browser['cases'],browser['properties'],browser['endpoint_traps'])==(55802,8836,24)
    for target in targets:
        lane=f'{compiler}-{target}'
        d=s/'final'/lane
        r=read(d/'report.json')
        commands=read(d/'commands.json')
        assert all(cmd['exit_code']==0 for cmd in commands)
        assert (r['cases'],r['properties'],r['endpoint_traps'])==(55802,8836,24)
        assert r['codegen_control']==read(s/'controls.json')['control']['final']
        assert not r['imports'] and not r['memory_grow'] and not r['floating_arithmetic'] and not r['dyadic_floating_arithmetic']
        assert r['fixed_lattice']['calls']==172284
        assert (r['lattice']['floating_chains'],r['lattice']['fixed_chains'],r['dyadic']['dyadic_egress_cases'])==(612,612,56)
        assert r['real_bridge']['executed']==(compiler!='1.88.0')
        if compiler!='1.88.0':assert r['real_bridge']['calls']==4
        if target.endswith('wasip1'):
            assert r['lattice_guest_tests']=={'arithmetic':60,'replay':3,'shape_replay':2}
        assert len(r['guest_stack'])==4
        assert all(row['stackBytes']-row['reservedBytes']>=256*1024 for row in r['guest_stack'])
        assert digest(d/'corpus.json')==r['corpus_sha256']
        corpora.add(r['corpus_sha256'])
        old=read(s/f'before-{lane}.json');current=read(s/f'matched-final-{lane}.json')
        assert old==current and len(old)==(4 if compiler=='1.88.0' else 5),lane
        assert all(digest(d/modules[k])==digest(s/lane/modules[k]) for k in old)
        summary[lane]=dict(completed_commands=len(commands),linked_images_equal_at_matched_path=len(old),
            matched_artifacts=old,final_runner_artifacts={k:digest(d/modules[k]) for k in old},
            primitive_file_bytes=r['binary_bytes'],codegen_control=r['codegen_control'],endpoint_traps=r['endpoint_traps'],
            max_reserved_stack_bytes=max(x['reservedBytes'] for x in r['guest_stack']),guest_linear_bytes=r['guest_stack'][0]['linearBytes'])
        a,b=[read(s/'logs'/f'cgroup-{stage}-{lane}.json') for stage in ('parent','final')]
        assert a['traps']==0 and b['traps']==24 and not any(int(n) for n in b['events'].values())
        previous=a['peak_job_bytes'];now=b['peak_job_bytes'];positive=max(0,now-previous);charged=previous+positive
        assert charged+(64<<20)<=(256<<20)
        jobs[lane]=dict(preceding_peak_bytes=previous,measured_peak_bytes=now,positive_change_bytes=positive,
                        cumulative_charged_peak_bytes=charged,remaining_above_reserve_bytes=(192<<20)-charged)
assert len(corpora)==1
save(s/'summary.json',summary)
save(s/'host-account.json',dict(source='eef113658',preceding='1fb7b8a1f',evidence='docs/evidence/2026-11-18-interval-wasm-float-qualification',
    scope='New host-process account for one sequential Node primitive verifier from startup through result publication and exit, including 24 isolated endpoint traps. Independent from the existing guest stack and allocator accounts. Paired measurements use the identical module, corpus and Node runtime; cgroup peaks include the measuring Python process.',
    capacity_bytes=256<<20,reserve_bytes=64<<20,swap_bytes=0,targets=jobs))
