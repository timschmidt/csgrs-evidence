(module
 (type $0 (func (param v128 v128 v128) (result v128)))
 (type $1 (func (param v128) (result v128)))
 (type $2 (func (param v128 v128) (result v128)))
 (export "fused" (func $0))
 (export "rounded" (func $1))
 (export "integer" (func $2))
 (func $0 (param $0 v128) (param $1 v128) (param $2 v128) (result v128)
  (f64x2.relaxed_madd
   (local.get $0)
   (local.get $1)
   (local.get $2)
  )
 )
 (func $1 (param $0 v128) (result v128)
  (i32x4.relaxed_trunc_f32x4_s
   (local.get $0)
  )
 )
 (func $2 (param $0 v128) (param $1 v128) (result v128)
  (i8x16.relaxed_swizzle
   (local.get $0)
   (local.get $1)
  )
 )
)

