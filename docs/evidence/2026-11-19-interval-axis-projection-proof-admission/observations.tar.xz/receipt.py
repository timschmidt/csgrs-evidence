from pathlib import Path
import os,re
s=Path(os.environ['s'])
p=Path('crates/hyperpath/src/routing/axis_projection.rs');t=p.read_text()
t=t.replace('use hyperlimit::{PredicatePolicy, Sign,','use hyperlimit::{Certainty, PredicateOutcome, PredicatePolicy, Sign,')
t=t.replace('    let policy = policy.certified_only();\n','')
t=re.sub(r'((?:classify_real_sign|compare_reals)\([^\n]+?\))\.value\(\)',r'certified_value(\1)',t)
t=t.replace('fn require_positive(','''fn certified_value<T>(outcome: PredicateOutcome<T>) -> Option<T> {
    match outcome {
        PredicateOutcome::Decided {
            value,
            certainty: Certainty::Filtered | Certainty::Exact,
            ..
        } => Some(value),
        PredicateOutcome::Decided { .. } | PredicateOutcome::Unknown { .. } => None,
    }
}

fn require_positive(''')
(s/'src'/p).write_text(t)
