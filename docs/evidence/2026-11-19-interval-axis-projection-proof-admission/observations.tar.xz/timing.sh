set -eu
while test "$(find "$s/images" -maxdepth 1 -name 'after-*-time-*' | wc -l)" -lt 4;do sleep 1;done
for mode in default passive active;do
 python3 "$s/time-check.py" after 1.95.0 "$mode" > "$s/logs/time-1.95.0-$mode" 2>&1 & p=$!
 python3 "$s/time-check.py" after stable "$mode" > "$s/logs/time-stable-$mode" 2>&1 & q=$!
 wait "$p"; wait "$q"
done
