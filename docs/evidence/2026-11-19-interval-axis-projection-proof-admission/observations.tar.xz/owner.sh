set -eu
v=$1
cd "$s/src"
for tc in 1.95.0 stable;do
 (
 export CARGO_TARGET_DIR="$s/cost-$tc" CARGO_BUILD_JOBS=5
 cargo +"$tc" build --locked --offline --release -p hyperpath --all-features --bench path_predicates --example certified_schedule --message-format=json-render-diagnostics > "$s/logs/$v-owner-$tc.jsonl" 2>"$s/logs/$v-owner-$tc"
 python3 - "$v" "$tc" <<'PY'
import os,json,sys,shutil
from pathlib import Path
s=Path(os.environ['s']);v,tc=sys.argv[1:]
for row in map(json.loads,(s/'logs'/f'{v}-owner-{tc}.jsonl').read_text().splitlines()):
 if img:=row.get('executable'):shutil.copy2(img,s/'images'/f"{v}-{tc}-{row['target']['name']}")
PY
 ) &
done
err=0;for p in $(jobs -p);do wait "$p" || err=1;done;exit "$err"
