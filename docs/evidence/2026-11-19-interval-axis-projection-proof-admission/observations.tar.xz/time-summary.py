from pathlib import Path
import statistics as st,json,os
s=Path(os.environ['s']);res={}
for p in sorted((s/'timings').glob('*.json')):
 rows=json.loads(p.read_text());tab={}
 for cpu,data in rows.items():
  tab[cpu]={}
  for k in next(iter(data.values()))['samples']:
   by={v:[st.median(r['samples'][k]) for r in data.values() if r['label']==v] for v in ('before','after')}
   tab[cpu][k]=100*(st.median(by['after'])/st.median(by['before'])-1)
 res[p.stem]=tab
 print(p.stem,[[round(x,1) for x in row.values()] for row in tab.values()])
(s/'timing-summary.json').write_text(json.dumps(res,indent=2)+'\n')
