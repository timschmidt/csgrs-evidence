from pathlib import Path
import os
s=Path(os.environ['s'])
file=Path('crates/hyperpath/src/routing/axis_projection.rs')
t=file.read_text()
t=t.replace('    let mut rows = Vec::with_capacity','    let mut problem = Problem::default();\n    let mut rows = Vec::with_capacity')
t=t.replace('                certification: certify_projection_row(\n','                certification: certify_projection_row(\n                    &mut problem,\n')
t=t.replace('fn certify_projection_row(\n','fn certify_projection_row(\n    problem: &mut Problem,\n')
at=t.index('    let mut problem = Problem::default();',t.index('fn certify_projection_row('))
t=t[:at]+t[at:].replace('    let mut problem = Problem::default();\n','',1)
t=t.replace('    certify_problem(problem)','''    let report = certify_problem(problem);
    // Keep the buffers for the next row. Its variables and constraints are
    // independent and its report owns all replay evidence.
    problem.constraints.clear();
    problem.variables.clear();
    report''',1)
t=t.replace('    certify_problem(problem)','    certify_problem(&problem)').replace('fn certify_problem(problem: Problem)','fn certify_problem(problem: &Problem)').replace('context_from_problem(&problem);','context_from_problem(problem);')
(s/'src'/file).write_text(t)
