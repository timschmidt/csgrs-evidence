set -eu
for tc in 1.95.0 stable;do
 (
 CARGO_TARGET_DIR="$s/cost-$tc" cargo +"$tc" build --offline --release --target wasm32-unknown-unknown --manifest-path "$s/wasm/Cargo.toml" >"$s/logs/$1-wasm-$tc" 2>&1
 cp "$s/cost-$tc/wasm32-unknown-unknown/release/axis_replay.wasm" "$s/images/$1-$tc.wasm"
 ) &
done
err=0;for pid in $(jobs -p);do wait "$pid" || err=1;done;exit "$err"
