from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,itertools,json,os,subprocess,sys
s=Path(os.environ['s']);v=sys.argv[1]
def sample(arg):
 tc,(n,k),policy,mode=arg
 img=s/'images'/f"{v}-{tc}-memory-{'normal' if mode=='default' else 'trace'}"
 out={}
 for pattern in ('control','90','165'):
  cmd=['setarch','x86_64','-R',str(img),str(n),str(k),policy,mode,pattern]
  ans=subprocess.check_output(cmd)
  if pattern=='control':
   out['output_bytes']=len(ans);out['out_sha256']=hashlib.sha256(ans).hexdigest()
   out['trace_sha256']=[hashlib.sha256(line).hexdigest() for line in ans.splitlines() if line.startswith(b'TRACE ')]
  else:out[pattern]=ans.decode().splitlines()
 return [f'{tc}/{n}/{k}/{policy}/{mode}',out]
with ThreadPoolExecutor(4) as pool:
 rec=dict(pool.map(sample,itertools.product(('1.95.0','stable'),((1,1),(4,3),(32,8)),('strict','approx'),('default','passive','active'))))
(s/f'{v}-memory.json').write_text(json.dumps(rec,indent=1)+'\n')
