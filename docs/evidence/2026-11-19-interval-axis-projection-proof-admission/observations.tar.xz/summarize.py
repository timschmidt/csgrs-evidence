import os,json,subprocess,hashlib,platform
from pathlib import Path
s=Path(os.environ['s']);r=Path('/mnt/development/csgrs')
def cmd(*c):return subprocess.check_output(c,text=True,stderr=subprocess.STDOUT).strip()
p={'revisions':{x:cmd('git','-C',str(r.parent/x),'rev-parse','HEAD') for x in ('csgrs','alumina-interface','alumina-firmware')},'base':cmd('git','rev-parse','143c712e5'),'program':cmd('git','rev-parse','c9f1f9ac5'),'guard_trial':(s/'proof-commit').read_text().strip(),'host':platform.platform(),'rust':{tc:cmd('rustc','+'+tc,'-Vv') for tc in ('stable','1.95.0')},'node':cmd(str(s/'node/node'),'--version'),'wasm_bindgen':cmd(str(s/'wasm-bindgen'),'--version'),'wasm_opt':cmd('wasm-opt','--version')}
(s/'revisions.json').write_text(json.dumps(p,indent=1)+'\n')
