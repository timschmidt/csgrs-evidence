set -eu
until test "$(find "$s/images" -name 'decisions-*' | wc -l)" = 14;do sleep 2;done
cp /mnt/development/csgrs/crates/hyperpath/src/routing/axis_projection.rs "$s/src/crates/hyperpath/src/routing/axis_projection.rs"
python3 - <<'PY'
from pathlib import Path
import os
p=Path(os.environ['s'])/'src/crates/hyperpath/src/routing/axis_projection.rs'
t=p.read_text();assert t.count('let mut problem = Problem::default();')==2
p.write_text(t.replace('let mut problem = Problem::default();','let mut problem = Problem {\n        variables: Vec::with_capacity(3),\n        constraints: Vec::with_capacity(3),\n    };'))
PY
git -C "$s/src" diff > "$s/capacity.patch"
bash "$s/build-cost.sh" capacity & one=$!
bash "$s/wasm.sh" capacity & two=$!
bash "$s/owner.sh" capacity & three=$!
wait "$one"; wait "$two";wait "$three"
python3 "$s/memory.py" capacity > "$s/logs/capacity-memory" 2>&1
for tc in 1.95.0 stable;do "$s/node/node" "$s/guest.cjs" after "$s/images/capacity-$tc.wasm" > "$s/logs/capacity-guest-$tc";done
