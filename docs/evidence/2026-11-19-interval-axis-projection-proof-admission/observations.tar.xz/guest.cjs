const fs=require('node:fs'),assert=require('node:assert/strict');
const [tag,file]=process.argv.slice(2);
(async()=>{
 const mod=await WebAssembly.compile(fs.readFileSync(file));
 const result=[];
 for(const warm of [0,1])for(const approx of [0,1])for(let c=0;c<9;c++){
  const api=(await WebAssembly.instantiate(mod,{})).exports;
  const actual=api.run(c,approx,warm);
  const expected=([10,10,10,10,10,1,11,2,1])[c];
  result.push({c,warm,approx,actual,expected});if(tag==='after'||!approx||c>=5)assert.equal(actual,expected);
 }
 if(tag==='before')for(let warm=0;warm<=1;warm++){const get=c=>result.find(r=>r.c===c&&r.warm===warm&&r.approx===1).actual;assert.equal(get(0),1);assert.equal(get(1),1);assert.equal(get(2),12);}
 console.log(JSON.stringify(result));
})().catch(e=>{console.error(e);process.exitCode=1});
