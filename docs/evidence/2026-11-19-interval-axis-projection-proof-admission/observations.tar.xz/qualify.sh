set -eu
tc=$1
if test "$tc" = stable;then export CARGO_TARGET_DIR="$s/main-stable";fi
cargo +"$tc" test --release --locked --offline -p hyperpath --all-features > "$s/logs/hyperpath-$tc" 2>&1
cargo +"$tc" clippy --release --locked --offline -p hyperpath --all-targets --all-features -- -D warnings > "$s/logs/clippy-$tc" 2>&1
RUSTDOCFLAGS="-D warnings" cargo +"$tc" doc --release --locked --offline -p hyperpath --all-features --no-deps > "$s/logs/doc-$tc" 2>&1
cargo +"$tc" test --release --locked --offline -p hyperpath --no-default-features --test axis_projection_certainty > "$s/logs/minimal-$tc" 2>&1
