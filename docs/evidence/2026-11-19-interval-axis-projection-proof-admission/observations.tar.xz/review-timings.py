from pathlib import Path
import os,sys,json,statistics as st,random
s=Path(os.environ['s']);tag=sys.argv[1];out={}
for f in sorted(s.glob('contract-'+tag+'-*.json')):
 result={}
 for mode,data in json.loads(f.read_text()).items():
  result[mode]={}
  for k in data[0]['before'][0]:
   z=[100*(st.mean(x[k] for x in g[tag])/st.mean(x[k] for x in g['before'])-1) for g in data]
   rng=random.Random(2229);bs=sorted(st.median(rng.choices(z,k=len(z))) for _ in range(2000))
   result[mode][k]=[round(v,3) for v in (st.median(z),bs[49],bs[-50])]
 print(f.name,{m:[v[0] for v in d.values()] for m,d in result.items()})
 out[f.stem]=result
(s/('latency-'+tag+'.json')).write_text(json.dumps(out,indent=1)+'\n')
