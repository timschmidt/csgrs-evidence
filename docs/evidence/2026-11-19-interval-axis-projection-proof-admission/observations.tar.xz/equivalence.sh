set -eu
v=$1
for tc in 1.95.0 stable;do
 (
  if test "$tc" = stable;then export CARGO_TARGET_DIR="$s/main-stable";fi
  cargo +"$tc" test --locked --release --offline -p hyperpath --all-features --test schedule_equivalence --message-format=json > "$s/logs/$v-equivalence-$tc.jsonl" 2>"$s/logs/$v-equivalence-$tc"
  python3 - "$v" "$tc" <<'PY'
import os,json,sys,shutil
from pathlib import Path
s=Path(os.environ['s']);v,tc=sys.argv[1:]
for line in (s/'logs'/f'{v}-equivalence-{tc}.jsonl').read_text().splitlines():
 if not line.startswith('{'):continue
 a=json.loads(line)
 if a.get('executable'):shutil.copy2(a['executable'],s/f'{v}-schedule-equivalence-{tc}')
PY
 ) &
done
rc=0;for p in $(jobs -p);do wait "$p" || rc=1;done;exit "$rc"
