#[allow(dead_code)]
mod oracle {
    include!("/mnt/development/csgrs/crates/hyperpath/tests/support/schedule_equivalence.rs");

    pub fn audit(data: &[u8]) {
        let path = Path::decode(data);
        let count = data.len().saturating_sub(3).div_euclid(2).min(6);
        if count == 0 {
            assert!(path.is_none());
            return;
        }
        let p = path.unwrap();
        let flags = data[0];
        let mut point = (i64::from(data[2]), -i64::from(flags));
        assert_eq!(p.points[0], point);
        assert_eq!(p.points.len(), count + 1);
        assert_eq!(p.radii.len(), count - 1);
        assert_eq!(p.lengths.len(), count);
        assert_eq!(p.directions.len(), count);
        assert_eq!(p.caps.len(), count + 1);
        assert_eq!(p.caps[0], i64::from(data[2] % 16));
        assert_eq!(p.global, i64::from(data[1] % 16) + 1);
        assert_eq!(p.acceleration, i64::from(data[1] / 16) + 1);
        for j in 0..count {
            let a = data[3 + 2 * j];
            let b = data[4 + 2 * j];
            let direction = a / 64;
            let length = i64::from(a % 64) + 1;
            let (mut dx, mut dy) = if flags % 2 == 0 { (1, 0) } else { (3, 4) };
            for _ in 0..direction {
                (dx, dy) = (-dy, dx);
            }
            point = (point.0 + dx * length, point.1 + dy * length);
            assert_eq!(p.points[j + 1], point);
            assert_eq!(p.directions[j], direction);
            assert_eq!(
                p.lengths[j],
                if flags % 2 == 0 { length } else { 5 * length }
            );
            assert_eq!(p.caps[j + 1], i64::from(b % 16));
            if j + 1 < count {
                assert_eq!(p.radii[j], i64::from(b / 16));
            }
        }
    }
}
fn main() {
    let mut checked = 0;
    let mut data = [0u8; 21];
    for length in 0..=data.len() {
        oracle::audit(&data[..length]);
        checked += 1;
    }
    for slot in 0..8 {
        for a in 0..=255u8 {
            for b in 0..=255u8 {
                data[0] = a;
                data[1] = b;
                data[2] = a ^ b;
                data[3 + 2 * slot] = a;
                data[4 + 2 * slot] = b;
                for len in [4 + 2 * slot, 5 + 2 * slot, 6 + 2 * slot, 21] {
                    oracle::audit(&data[..len]);
                    checked += 1;
                }
            }
        }
    }
    println!("{checked} decoded inputs matched the independent byte grammar");
}
