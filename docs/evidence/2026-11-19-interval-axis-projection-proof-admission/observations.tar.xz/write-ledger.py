from pathlib import Path
import os,json,subprocess
s=Path(os.environ['s']);root=Path('/mnt/development/csgrs')
a=json.loads((s/'archive-result.txt').read_text());rev=a['commit'];ref=a['record'];sources=json.loads((s/'revisions.json').read_text());src=sources['revisions']['csgrs']
obs=json.loads((s/'decoder-cost.json').read_text())
ledger=root/'docs/research/interval-size-accounts.json';existing=ledger.read_text();end=existing.rfind('\n}');assert end>=0
entry={'source':src,'previous':'6aafc02603225949d2c9a2da3e6a2617b24bfa87','scope':'Phase 11 schedule-equivalence test and fuzz byte decoder. Rust 1.99 strict all-target Clippy now passes. Production code is unchanged.','evidence':ref,'evidence_commit':rev,'program_baseline':'Keep the previously registered d8eb6fa0c harness accounts. No positive change in final file, executable code or defined function bytes on any measured target. Earlier charges stay reserved.','limits':'64 MiB for each complete executable, 16 MiB reserved. No size exception spent.','targets':obs}
key='schedule_equivalence_decoder_compatibility';assert key not in json.loads(existing)
ledger.write_text(existing[:end]+',\n  '+json.dumps(key)+': '+json.dumps(entry,indent=2).replace('\n','\n  ')+existing[end:])
verified=json.loads(ledger.read_text());assert verified.pop(key)==entry and verified==json.loads(existing)
num=len(json.loads((s/'decoder-corpus.json').read_text()))
with (root/'INTERVAL_REFACTOR_PROGRESS.md').open('a') as f:f.write(f'''
## Phase 0 inventory and Phase 11 path proofs

Commits `ba98a61b5` and `6aafc0260` restore the three named Hyperpath
source modules to the scanner and record 53 body reviews. A Rust syntax-tree
walk agreed on all 137 declarations across routing, tangent, solve and affine
projection. The nine scanner tests passed. Two refreshes preserved all 418
manual records. The direct and solver G1 oracle reports 12 incorrect public
outcomes for zero tangents, a hidden endpoint gap, a nonparallel pair and a
small nonzero tangent. [Source review](docs/research/axis-projection-owner.md)

The primary affine planner and independent replay both certified an invalid
negative absolute derivative under `APPROXIMATE_512`. Local trial
`cce4eb9f9` returns `PredicateUnresolved` and keeps the control reports,
dispatch, heap and stack across all 36 native workloads. Seven repairs were
tested. The public-input guard reproduced a slowdown on the Rust 1.95 32×8
approximate workload with compiled, passive tracing. Six alternative source
patches and their independent gate findings are archived. The guard remains
on `interval-axis-proof-qualification`; the production path and dynamics
ownership transfer are open. No trial spent a production allowance.

Commit `{src[:9]}` restores strict Rust 1.99 Clippy for the retained schedule
equivalence oracle. It consumes complete byte pairs and ignores the same odd
tail and excess edges. Both decoder revisions matched the independent byte
grammar on 2,097,174 inputs, completed 2,500 ASan fuzz runs apiece and
replayed the same {num} distinct generated inputs. Both Rust 1.95 and 1.99
passed 446 all-feature Hyperpath tests and strict all-target Clippy. The two
release suites shrank by 8 and 16 file bytes. The ASan driver shrank by 432.
[Target measurements](docs/research/interval-size-accounts.json)

Raw reports, traces, independent oracles, complete memory histories, linked
sizes and paired timing samples are in evidence commit `{rev}`.
[Evidence index](docs/evidence-archive.tsv)
''')
with (root/'docs/research/axis-projection-owner.md').open('a') as f:f.write(f'\nMeasured sources, both exact oracles and raw trial records are archived in\nevidence commit `{rev}`. [Evidence index](../evidence-archive.tsv)\n')
