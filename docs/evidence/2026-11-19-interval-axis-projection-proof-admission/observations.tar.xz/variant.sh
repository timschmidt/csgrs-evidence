set -eu
while test "$(find "$s/images" -maxdepth 1 -name 'fixed-*' | wc -l)" -ne 14;do sleep 1;done
if ! git -C "$s/src" ls-files --error-unmatch crates/hyperpath/examples/certified_schedule.rs >/dev/null 2>&1;then python3 -c "from pathlib import Path;import os;p=Path(os.environ['s'])/'src/crates/hyperpath/examples/certified_schedule.rs';assert p.read_bytes()==Path('/mnt/development/csgrs/crates/hyperpath/examples/certified_schedule.rs').read_bytes();p.unlink()";fi
git -C "$s/src" switch --detach 143c712e5 > "$s/logs/back-to-current" 2>&1
cp /mnt/development/csgrs/crates/hyperpath/src/routing/axis_projection.rs "$s/src/crates/hyperpath/src/routing/axis_projection.rs"
python3 "$s/decisions.py" "$s/src"
git -C "$s/src" diff > "$s/decisions.patch"
bash "$s/build-cost.sh" decisions & a=$!
bash "$s/wasm.sh" decisions & b=$!
bash "$s/owner.sh" decisions & c=$!
for p in "$a" "$b" "$c";do wait "$p";done
python3 "$s/memory.py" decisions > "$s/logs/decisions-memory" 2>&1
for tc in 1.95.0 stable;do "$s/node/node" "$s/guest.cjs" after "$s/images/decisions-$tc.wasm" > "$s/logs/decisions-guest-$tc";done
