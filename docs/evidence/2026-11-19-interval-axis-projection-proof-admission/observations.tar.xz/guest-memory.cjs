const fs = require('node:fs');
const assert = require('node:assert/strict');
const [tag, path] = process.argv.slice(2);
const bytes = fs.readFileSync(path);
let pos = 8;
function nat() {
  let value = 0, shift = 0, byte;
  do {byte = bytes[pos++]; value += (byte & 127) * 2 ** shift; shift += 7;} while (byte & 128);
  return value;
}
function address() {
  assert.equal(bytes[pos++], 0x41);
  const value = nat();
  assert.equal(bytes[pos++], 0xb);
  return value;
}
let top, lowestData = Infinity;
while (pos < bytes.length) {
  const kind = bytes[pos++], length = nat(), end = pos + length;
  if (kind === 6) {
    assert(nat() >= 1);
    assert.equal(bytes[pos++], 0x7f);
    assert.equal(bytes[pos++], 1);
    top = address();
  }
  if (kind === 11) {
    const count = nat();
    for (let i=0; i<count; i++) {
      assert.equal(nat(), 0);
      lowestData = Math.min(lowestData, address());
      const size = nat(); pos += size;
    }
    assert.equal(pos, end);
  }
  pos = end;
}
assert.equal(top, 1048576);
assert(lowestData >= top && Number.isFinite(lowestData));
const mod = new WebAssembly.Module(bytes);
const results = [];
for(const fill of [90,165]) for(const warm of [0,1]) for(const approx of [0,1]) for(let c=0;c<9;c++) {
  const api = new WebAssembly.Instance(mod, {}).exports;
  const initial = api.memory.buffer.byteLength;
  const stack = () => new Uint8Array(api.memory.buffer, 0, top);
  for(let iteration=0; iteration<2; iteration++) {
    stack().fill(fill);
    const actual = api.run(c,approx,warm);
    const changed = stack().findIndex(x=>x!==fill);
    assert(changed > 262144 && changed < top);
    results.push({c,warm,approx,iteration,fill,actual,stack_bytes:top-changed,initial_bytes:initial,linear_bytes:api.memory.buffer.byteLength});
  }
}
console.log(JSON.stringify({tag,top,lowestData,results}));
