set -eu
v=$1
export PATH="$s/host-tools/bin:$PATH" CARGO_TARGET_DIR="$s/fuzz-target" CARGO_BUILD_JOBS=8
export RUSTFLAGS="-C link-arg=-Wl,--compress-debug-sections=zlib"
corpus="$s/seeds-$v";mkdir -p "$corpus" "$s/fuzz-findings"
cp crates/hyperpath/fuzz/seeds/schedule_equivalence/* "$corpus/"
cargo +nightly fuzz run --fuzz-dir crates/hyperpath/fuzz --target-dir "$CARGO_TARGET_DIR" schedule_equivalence "$corpus" -- -runs=2500 -max_len=32 -timeout=10 -rss_limit_mb=4096 -seed=19112026 -artifact_prefix="$s/fuzz-findings/" > "$s/logs/$v-asan" 2>&1
cp "$CARGO_TARGET_DIR/x86_64-unknown-linux-gnu/release/schedule_equivalence" "$s/$v-fuzz-equivalence"
