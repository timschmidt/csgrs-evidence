import os,json,subprocess,hashlib
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s'])
out={}
for kind in ('fuzz-equivalence','schedule-equivalence-1.95.0','schedule-equivalence-stable'):
 a,b=[metrics(s/(tag+'-'+kind)) for tag in ('original','current')]
 out[kind]={'original':a,'current':b,'delta':{m:b[m]-a[m] for m in ('file','code','functions')},'remaining_slot':64*2**20-b['file']}
 assert all(v<=0 for v in out[kind]['delta'].values())
(s/'decoder-cost.json').write_text(json.dumps(out,indent=1)+'\n')
data={}
for d in ('seeds-current','seeds-original'):
 for f in (s/d).iterdir():
  payload=f.read_bytes();data[hashlib.sha256(payload).hexdigest()]=payload
corpus=s/'retained-decoder-corpus';corpus.mkdir(exist_ok=True)
for k,v in sorted(data.items()):(corpus/k).write_bytes(v)
for tag in ('original','current'):
 paths=[str(corpus/k) for k in sorted(data)]
 with (s/'logs'/f'{tag}-frozen-asan').open('w') as f:subprocess.run([s/(tag+'-fuzz-equivalence'),'-runs=1',*paths],check=True,stdout=f,stderr=f)
(s/'decoder-corpus.json').write_text(json.dumps({k:v.hex() for k,v in sorted(data.items())},separators=(',',':'))+'\n')
print(len(data),'unique frozen generated inputs')
