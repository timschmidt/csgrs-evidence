set -eu
for ((n=0;n<1500;n++)); do
 if test "$(find "$s/images" -maxdepth 1 -name 'before-*' | wc -l)" -eq 14;then break;fi
 sleep 1
done
test "$(find "$s/images" -maxdepth 1 -name 'before-*' | wc -l)" -eq 14
for tc in 1.95.0 stable;do "$s/node/node" "$s/guest.cjs" before "$s/images/before-$tc.wasm" > "$s/logs/before-guest-$tc";done
python3 "$s/memory.py" before > "$s/logs/before-memory" 2>&1 & base=$!
cp /mnt/development/csgrs/crates/hyperpath/src/routing/axis_projection.rs "$s/src/crates/hyperpath/src/routing/axis_projection.rs"
bash "$s/build-cost.sh" after > "$s/logs/after-cost" 2>&1 & p=$!
bash "$s/wasm.sh" after > "$s/logs/after-modules" 2>&1 & q=$!
bash "$s/owner.sh" after > "$s/logs/after-owners" 2>&1 & r=$!
for proc in "$base" "$p" "$q" "$r";do wait "$proc";done
for tc in 1.95.0 stable;do "$s/node/node" "$s/guest.cjs" after "$s/images/after-$tc.wasm" > "$s/logs/after-guest-$tc";done
python3 "$s/memory.py" after > "$s/logs/after-memory" 2>&1
