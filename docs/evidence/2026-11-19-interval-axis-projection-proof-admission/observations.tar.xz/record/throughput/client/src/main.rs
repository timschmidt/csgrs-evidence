#![allow(deprecated)] // Exercise legacy callers through the coordinated release.


#[cfg(feature = "direct")]
use axis::AxisProjectionError as Error;
#[cfg(not(feature = "direct"))]
use axis::RouteCertificationError as Error;
use axis::{
    AffineSpanAxisProjection, AxisMotionLimits, certify_axis_projected_motion_limits,
    plan_axis_projected_motion_limits,
};
#[cfg(feature = "direct")]
use hyperdynamics::axis_projection as axis;
use hyperlimit::PredicatePolicy;
#[cfg(not(feature = "direct"))]
use hyperpath as axis;
use hyperreal::Real;


struct Job {
    spans: usize,
    axes: usize,
    policy: PredicatePolicy,
    #[cfg(feature = "trace")]
    active: bool,
    control: bool,
}
fn cycle(job: &Job) {
    #[cfg(feature = "trace")]
    let guard = job.active.then(hyperreal::dispatch_trace::recording_scope);
    let limits: Vec<_> = (0..job.axes)
        .map(|i| AxisMotionLimits {
            maximum_velocity: Real::from(3 + i as i32),
            maximum_acceleration: Real::from(4 + i as i32),
            maximum_jerk: Real::from(5 + i as i32),
        })
        .collect();
    let small = (Real::one() / Real::from(3)).unwrap();
    let spans: Vec<_> = (0..job.spans)
        .map(|i| AffineSpanAxisProjection {
            absolute_axis_derivatives: (0..job.axes)
                .map(|j| match (i + j) % 3 {
                    0 => Real::one(),
                    1 => Real::zero(),
                    _ => small.clone(),
                })
                .collect(),
        })
        .collect();
    let rejected = plan_axis_projected_motion_limits(&[], &limits, job.policy).unwrap_err();
    assert_eq!(rejected, Error::EmptyAxisProjection);
    let plan = plan_axis_projected_motion_limits(&spans, &limits, job.policy).unwrap();
    assert_eq!(plan.maximum_path_feed, Real::from(3));
    assert_eq!(plan.maximum_path_acceleration, Real::from(4));
    assert_eq!(plan.maximum_path_jerk, Real::from(5));
    for at in [
        plan.feed_bottleneck,
        plan.acceleration_bottleneck,
        plan.jerk_bottleneck,
    ] {
        assert_eq!((at.span_index, at.axis_index), (0, 0));
    }
    assert!(plan.all_satisfied());
    assert_eq!(plan.certification.rows.len(), job.spans * job.axes);
    let replay = certify_axis_projected_motion_limits(
        &spans,
        &limits,
        plan.maximum_path_feed.clone(),
        plan.maximum_path_acceleration.clone(),
        plan.maximum_path_jerk.clone(),
        job.policy,
    )
    .unwrap();
    assert_eq!(plan.certification, replay);
    #[cfg(feature = "trace")]
    let trace = job.active.then(hyperreal::dispatch_trace::take_trace);
    #[cfg(feature = "trace")]
    drop(guard);
    if job.control {
        println!("OUTPUT {plan:?} {replay:?} {rejected:?}");
        #[cfg(feature = "trace")]
        println!("TRACE {trace:?}");
    }
    #[cfg(feature = "trace")]
    drop(trace);
    drop(std::hint::black_box((plan, replay, limits, spans, small)));
}

fn main() {
    let arg: Vec<_> = std::env::args().collect();
    let mode = &arg[1];
    for (n,k,repetitions) in [(1,1,64),(4,3,8),(32,8,1)] {
        for (tag,policy) in [("strict", PredicatePolicy::STRICT),("approx",PredicatePolicy::APPROXIMATE_512)] {
            if arg.len() > 3 && (n != arg[3].parse::<usize>().unwrap() || tag != arg[4]) { continue; }
            let job = Job { spans:n, axes:k, policy, control:mode=="control",
                #[cfg(feature="trace")] active:arg[2]=="active" };
            if job.control { println!("CASE {n} {k} {tag}"); cycle(&job); continue; }
            let warm = std::time::Instant::now();
            while warm.elapsed().as_millis()<100 { cycle(std::hint::black_box(&job)); }
            for i in 0..30 {
                let start=std::time::Instant::now();
                for _ in 0..repetitions { cycle(std::hint::black_box(&job)); }
                let ns=start.elapsed().as_nanos();
                println!("SAMPLE {n} {k} {tag} {i} {repetitions} {ns}");
            }
        }
    }
}
