set -eu
tag=$1
until test -s "$s/images/$tag-stable-time-trace" && test -s "$s/images/$tag-1.95.0-time-trace"; do sleep 1;done
for mode in default passive active;do
 python3 "$s/time-check.py" "$tag" 1.95.0 "$mode" & p=$!
 python3 "$s/time-check.py" "$tag" stable "$mode" & q=$!
 wait "$p";wait "$q"
done
