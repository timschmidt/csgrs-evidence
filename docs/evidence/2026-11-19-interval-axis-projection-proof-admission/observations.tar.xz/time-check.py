from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,statistics,shutil,sys
s=Path(os.environ['s']);tag=sys.argv[1];tc=sys.argv[2];mode=sys.argv[3]
base=s/'images';panel=s/'timings';panel.mkdir(exist_ok=True)
def on_cpu(cpu):
 x={};dest=panel/f'{tc}-{mode}-{cpu}-run'
 for i in range(8):
  variant=tag if (i in (0,3,5,6))==(cpu in (6,8)) else 'before'
  lib=base/f"{variant}-{tc}-time-{'normal' if mode=='default' else 'trace'}";shutil.copyfile(lib,dest);dest.chmod(0o755)
  r=subprocess.run(['setarch','x86_64','-R','taskset','-c',str(cpu),dest,'measure',mode],check=True,stdout=subprocess.PIPE,text=True)
  rows={}
  for ln in r.stdout.splitlines():
   _,n,k,p,j,rep,ns=ln.split();rows.setdefault(f'{n}/{k}/{p}',[]).append(int(ns)/int(rep))
  assert len(rows)==6 and all(len(t)==30 for t in rows.values())
  x[i]={'label':variant,'samples':rows}
 return cpu,x
cores=(6,16) if tc=='1.95.0' else (8,19)
with ThreadPoolExecutor(2) as pool:data=dict(pool.map(on_cpu,cores))
(panel/f'{tag}-{tc}-{mode}.json').write_text(json.dumps(data)+'\n')
