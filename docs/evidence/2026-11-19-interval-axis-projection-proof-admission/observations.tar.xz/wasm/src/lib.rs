use hyperpath::{AxisMotionLimits,AffineSpanAxisProjection,RouteCertificationError as E,certify_axis_projected_motion_limits as replay,plan_axis_projected_motion_limits as plan};
use hyperlimit::{classify_real_sign,PredicatePolicy as P};
use hyperreal::Real;
include!("hidden.rs");
#[unsafe(no_mangle)]
pub extern "C" fn run(case:u32,approx:bool,warm:bool)->u32{
 let p=if approx{P::APPROXIMATE_512}else{P::STRICT};
 let mut axis=AxisMotionLimits{maximum_velocity:Real::one(), maximum_acceleration:Real::one(), maximum_jerk:Real::one()};
 let other=axis.clone();
 let mut v=match case{0|1=>-hidden_positive(),2|3=>hidden_positive(),4=>Real::one()+hidden_positive(),5=>Real::zero(),6=>Real::from(-1),7=>Real::from(2),_=>Real::one()};
 if warm {std::hint::black_box(classify_real_sign(&v,P::APPROXIMATE_512));}
 let axes=if case==2 || case==4{axis.maximum_velocity=v.clone();[axis,other]}else{[axis,other]};
 let d=if case==2 || case==3 || case==4 {Real::one()}else{v.clone()};
 let spans=[AffineSpanAxisProjection{absolute_axis_derivatives:vec![Real::one(),d]}];
 let ans=if case==0 || case==3{
  if case!=3{v=Real::one();}
  replay(&spans,&axes,v,Real::one(),Real::one(),p).map(|x|u32::from(x.all_satisfied()))
 }else{
  plan(&spans,&axes,p).map(|x|{assert!(x.all_satisfied());1+x.feed_bottleneck.axis_index as u32})
 };
 match ans {Ok(code)=>code,Err(E::PredicateUnresolved)=>10,Err(E::NegativeAxisProjection)=>11,Err(E::ZeroFeedRate)=>12,Err(E::AxisProjectionProposalUncertified)=>13,_=>99}
}
