set -eu
v=$1
mkdir -p "$s/images"
for tc in 1.95.0 stable;do
 (
  export CARGO_TARGET_DIR="$s/cost-$tc" CARGO_BUILD_JOBS=5
  for dir in record/client record/throughput/client;do
   for feature in normal trace;do
    if test "$feature" = normal;then flags=();else flags=(--features trace);fi
    cargo +"$tc" build --release --offline --manifest-path "$s/$dir/Cargo.toml" "${flags[@]}" >> "$s/logs/$v-cost-$tc" 2>&1
    if test "$dir" = record/client;then tag=memory;else tag=time;fi
    cp "$CARGO_TARGET_DIR/release/axis-consumer" "$s/images/$v-$tc-$tag-$feature"
   done
  done
 ) &
done
err=0;for p in $(jobs -p);do wait "$p" || err=1;done;exit "$err"
