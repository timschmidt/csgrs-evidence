#define _GNU_SOURCE
#include <dlfcn.h>
#include <time.h>
#include <stdlib.h>
static int (*system_clock)(clockid_t, struct timespec *);
__attribute__((constructor)) static void setup(void) {
    system_clock=dlsym(RTLD_NEXT,"clock_gettime");
    if(!system_clock) abort();
}
int clock_gettime(clockid_t id, struct timespec *result) {
    return system_clock(id==CLOCK_MONOTONIC?CLOCK_THREAD_CPUTIME_ID:id,result);
}
