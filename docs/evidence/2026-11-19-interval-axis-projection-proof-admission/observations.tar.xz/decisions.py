import sys
from pathlib import Path
p=Path(sys.argv[1])/'crates/hyperpath/src/routing/axis_projection.rs'
x=p.read_text().replace('    let policy = policy.certified_only();\n','')
a='''            match classify_real_sign(derivative, policy).value() {
                Some(Sign::Negative) => {
                    return Err(RouteCertificationError::NegativeAxisProjection);
                }
                Some(Sign::Zero) => {}
                Some(Sign::Positive) => has_positive = true,
                None => return Err(RouteCertificationError::PredicateUnresolved),
            }'''
assert x.count(a)==1
x=x.replace(a,'''            // Validate every axis, including those after the first moving one.
            has_positive |= is_positive_projection(derivative, policy)?;''')
assert x.count('classify_real_sign(value, policy)')==2
x=x.replace('classify_real_sign(value, policy)','classify_real_sign(value, policy.certified_only())').replace('compare_reals(&candidate, &selected, policy)','compare_reals(&candidate, &selected, policy.certified_only())')
p.write_text(x)
