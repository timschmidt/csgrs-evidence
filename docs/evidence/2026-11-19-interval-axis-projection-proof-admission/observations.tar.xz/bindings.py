from pathlib import Path
import os
s=Path(os.environ['s'])
file=Path('crates/hyperpath/src/routing/axis_projection.rs')
t=file.read_text().replace('CandidateCertificationReport, Constraint, ConstraintKind, Expr, Problem, certify_candidate,','CandidateCertificationReport, Constraint, ConstraintKind, EvaluationContext, Expr, Problem, VariableId, certify_candidate,')
t=t.replace('    let mut rows = Vec::with_capacity', '''    let (mut problem, variables) = projection_problem(
        maximum_path_feed.clone(),
        maximum_path_acceleration.clone(),
        maximum_path_jerk.clone(),
    );
    let context = context_from_problem(&problem);
    let mut rows = Vec::with_capacity''')
t=t.replace('''                    maximum_path_feed.clone(),
                    maximum_path_acceleration.clone(),
                    maximum_path_jerk.clone(),''','''                    &mut problem,
                    variables,
                    &context,''')
start=t.index('fn certify_projection_row(');end=t.index('    problem.add_constraint(projection_constraint(',start)
t=t[:start]+'''fn projection_problem(
    maximum_path_feed: Real,
    maximum_path_acceleration: Real,
    maximum_path_jerk: Real,
) -> (Problem, [VariableId; 3]) {
    let mut problem = Problem::default();
    let feed = problem.add_variable("path_feed", maximum_path_feed);
    let acceleration = problem.add_variable("path_acceleration", maximum_path_acceleration);
    let jerk = problem.add_variable("path_jerk", maximum_path_jerk);
    (problem, [feed, acceleration, jerk])
}

fn certify_projection_row(
    derivative: Real,
    axis_limits: &AxisMotionLimits,
    problem: &mut Problem,
    [feed, acceleration, jerk]: [VariableId; 3],
    context: &EvaluationContext,
) -> CandidateCertificationReport {
    // Each row has its own residuals and report. The proposed path variables
    // and their evaluation bindings are identical for every span and axis.
    problem.constraints.clear();
'''+t[end:]
t=t.replace('    certify_problem(problem)','    certify_candidate(&problem.analyze(), context)',1)
start=t.index('    let mut problem = Problem::default();',t.index('fn certify_bottlenecks('));end=t.index('    add_bottleneck_equality(',start)
t=t[:start]+'''    let (mut problem, [feed, acceleration, jerk]) = projection_problem(
        maximum_path_feed.clone(),
        maximum_path_acceleration.clone(),
        maximum_path_jerk.clone(),
    );
'''+t[end:]
t=t.replace('    certify_problem(problem)','    let analysis = problem.analyze();\n    certify_candidate(&analysis, &context_from_problem(&problem))')
t=t[:t.index('fn certify_problem(problem:')].rstrip()+'\n'
(s/'src'/file).write_text(t)
