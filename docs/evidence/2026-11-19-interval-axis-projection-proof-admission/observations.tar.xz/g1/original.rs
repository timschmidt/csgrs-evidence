use hyperlimit::{Point2,PredicatePolicy};
use hyperpath::{TangentJoinClass,TangentSpan,certify_g1_chain,certify_g1_join_candidate,classify_tangent_join,g1_join_problem};
use hyperreal::Real;
fn p(x:i32)->Point2{Point2::new(Real::from(x),Real::zero())}
fn main(){
 for (x,y) in [(1,2),(1,-2),(1,0),(0,1),(0,0)]{
  let classified=classify_tangent_join(&p(0),&p(x),&p(0),&p(y),PredicatePolicy::STRICT).class;
  let model=g1_join_problem(p(0),p(x),p(0),p(y));let report=certify_g1_join_candidate(&model);
  let chain=certify_g1_chain(&[TangentSpan{start:p(-1),end:p(0),start_tangent:p(1),end_tangent:p(x)},TangentSpan{start:p(0),end:p(1),start_tangent:p(y),end_tangent:p(1)}]);
  let actual=report.all_satisfied();println!("{x} {y} {classified:?} {actual} {}",chain.all_certified());assert_eq!(actual,chain.all_certified());
  let expected=x*y>0;assert_eq!(classified==TangentJoinClass::G1Continuous,expected);
  assert_eq!(actual,x*y>=0);
 }
}
