use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::{
    TangentJoinClass, TangentSpan, certify_g1_chain, certify_g1_join_candidate,
    certify_tangent_alignment_candidate, classify_tangent_join, g1_join_problem,
    oriented_tangent_alignment_problem,
};
use hyperreal::Real;

include!("hidden.rs");

fn on_x(x: i32) -> Point2 {
    Point2::new(Real::from(x), Real::zero())
}

fn main() {
    let mut failures = Vec::new();
    for (x, y) in [(1, 2), (1, -2), (1, 0), (0, 1), (0, 0)] {
        let expected = x * y > 0;
        let a = TangentSpan {
            start: on_x(-1),
            start_tangent: on_x(1),
            end: on_x(0),
            end_tangent: on_x(x),
        };
        let b = TangentSpan {
            start: on_x(0),
            start_tangent: on_x(y),
            end: on_x(1),
            end_tangent: on_x(1),
        };
        let direct = classify_tangent_join(
            &a.end,
            &a.end_tangent,
            &b.start,
            &b.start_tangent,
            PredicatePolicy::STRICT,
        );
        assert_eq!(direct.class == TangentJoinClass::G1Continuous, expected);
        let model = g1_join_problem(on_x(0), on_x(x), on_x(0), on_x(y));
        let alignment = oriented_tangent_alignment_problem(on_x(x), on_x(y));
        for (operation, actual) in [
            (
                "candidate",
                certify_g1_join_candidate(&model).all_satisfied(),
            ),
            ("chain", certify_g1_chain(&[a, b]).all_certified()),
            (
                "oriented alignment",
                certify_tangent_alignment_candidate(&alignment).all_satisfied(),
            ),
        ] {
            if actual != expected {
                failures.push(format!(
                    "{operation}: ({x}, {y}) expected {expected}, got {actual}"
                ));
            }
        }
    }
    let h = hidden_positive();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for (name, endpoint, tangent, expected) in [
            (
                "noncoincident endpoints",
                Point2::new(h.clone(), Real::zero()),
                on_x(1),
                TangentJoinClass::EndpointMismatch,
            ),
            (
                "nonparallel tangents",
                on_x(0),
                Point2::new(Real::one(), h.clone()),
                TangentJoinClass::Corner,
            ),
            (
                "short nonzero tangent",
                on_x(0),
                Point2::new(h.clone(), Real::zero()),
                TangentJoinClass::G1Continuous,
            ),
        ] {
            let report = classify_tangent_join(&on_x(0), &on_x(1), &endpoint, &tangent, policy);
            if report.class != expected && report.class != TangentJoinClass::Unknown {
                failures.push(format!(
                    "{name} {policy:?}: expected {expected:?} or Unknown, got {:?}",
                    report.class
                ));
            }
        }
    }
    for failure in &failures {
        eprintln!("{failure}");
    }
    assert!(
        failures.is_empty(),
        "{} incorrect public outcomes",
        failures.len()
    );
}
