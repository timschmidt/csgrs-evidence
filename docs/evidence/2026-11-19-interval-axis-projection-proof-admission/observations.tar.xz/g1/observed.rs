use hyperlimit::{Point2,PredicatePolicy};
use hyperpath::{TangentJoinClass,TangentSpan,certify_g1_chain,certify_g1_join_candidate,classify_tangent_join,g1_join_problem};
use hyperreal::Real;
fn p(x:i32)->Point2{Point2::new(Real::from(x),Real::zero())}
include!("hidden.rs");
fn main(){
 let hidden=hidden_positive();
 for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
     for (k,e,t) in [
       ("gap",Point2::new(hidden.clone(),Real::zero()),p(1)),
       ("cross",p(0),Point2::new(Real::one(),hidden.clone())),
       ("short",p(0),Point2::new(hidden.clone(),Real::zero()))
     ] {
       let r=classify_tangent_join(&p(0),&p(1),&e,&t,policy);
       println!("{k} {policy:?} {:?} {:?} {:?}",r.class,r.endpoints_equal,r.alignment);
     }
 }
 for (x,y) in [(1,2),(1,-2),(0,1),(1,0),(0,0)] {
    let m=hyperpath::oriented_tangent_alignment_problem(p(x),p(y));
    let report=hyperpath::certify_tangent_alignment_candidate(&m);
    assert_eq!(report.all_satisfied(),x*y>=0);println!("oriented {x} {y} {}",report.all_satisfied());
 }

 for (x,y) in [(1,2),(1,-2),(1,0),(0,1),(0,0)]{
  let classified=classify_tangent_join(&p(0),&p(x),&p(0),&p(y),PredicatePolicy::STRICT).class;
  let model=g1_join_problem(p(0),p(x),p(0),p(y));let report=certify_g1_join_candidate(&model);
  let chain=certify_g1_chain(&[TangentSpan{start:p(-1),end:p(0),start_tangent:p(1),end_tangent:p(x)},TangentSpan{start:p(0),end:p(1),start_tangent:p(y),end_tangent:p(1)}]);
  let actual=report.all_satisfied();println!("{x} {y} {classified:?} {actual} {}",chain.all_certified());assert_eq!(actual,chain.all_certified());
  let expected=x*y>0;assert_eq!(classified==TangentJoinClass::G1Continuous,expected);
  assert_eq!(actual,x*y>=0);
 }
}
