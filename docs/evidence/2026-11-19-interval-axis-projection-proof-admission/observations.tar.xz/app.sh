set -eu
cd "$s/linked/alumina-interface"
export CARGO_TARGET_DIR="$s/app-target" CARGO_BUILD_JOBS=8
for target in wasm32-unknown-unknown x86_64-unknown-linux-gnu;do
 if test "$target" = wasm32-unknown-unknown;then flags=(--lib);artifact=alumina_interface.wasm;else flags=(--bin alumina-interface);artifact=alumina-interface;fi
 cargo +1.95.0 build --locked --release --target "$target" "${flags[@]}" > "$s/logs/$1-app-$target" 2>&1
 cp "$CARGO_TARGET_DIR/$target/release/$artifact" "$s/deployed/$1-$artifact"
done
