set -eu
until test -s "$s/original-fuzz-equivalence";do if rg -q '^error:' "$s/logs/original-asan";then exit 1;fi;sleep 2;done
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hyperpath/tests/support/schedule_equivalence.rs');t=p.read_text();old='        for edge in tail.chunks_exact(2).take(6) {';assert t.count(old)==1;p.write_text(t.replace(old,'        let (edges, _) = tail.as_chunks::<2>();\n        for edge in edges.iter().take(6) {'))
PY
git diff -- crates/hyperpath/tests/support/schedule_equivalence.rs > "$s/decoder.patch"
bash "$s/equivalence.sh" current & a=$!
bash "$s/fuzz-check.sh" current & b=$!
cargo +1.95.0 run --release --offline --manifest-path "$s/decode/Cargo.toml" > "$s/logs/current-grammar" 2>&1 & c=$!
for tc in 1.95.0 stable;do
 (
  if test "$tc" = stable;then export CARGO_TARGET_DIR="$s/main-stable";fi
  cargo +"$tc" clippy --release --all-targets --all-features --locked --offline -p hyperpath -- -D warnings > "$s/logs/current-all-clippy-$tc" 2>&1
  cargo +"$tc" test --release --all-features --locked --offline -p hyperpath > "$s/logs/current-test-$tc" 2>&1
 ) &
done
failed=0;for p in $(jobs -p);do wait "$p" || failed=1;done
cargo +1.95.0 fmt --all -- --check > "$s/logs/fmt-final" 2>&1
exit "$failed"
