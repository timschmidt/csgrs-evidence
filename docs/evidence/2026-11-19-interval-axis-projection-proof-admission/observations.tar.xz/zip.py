from pathlib import Path
import os
p=Path(os.environ['s'])/'src/crates/hyperpath/src/routing/axis_projection.rs'
t=p.read_text();pat='for (axis_index, derivative) in projection.absolute_axis_derivatives.iter().enumerate() {'
assert t.count(pat)==2
t=t.replace(pat,'''for (axis_index, (derivative, limit)) in projection
            .absolute_axis_derivatives
            .iter()
            .zip(axis_limits)
            .enumerate()
        {''')
t=t.replace('&axis_limits[axis_index].maximum','&limit.maximum').replace('axis_limits: axis_limits[axis_index].clone(),','axis_limits: limit.clone(),').replace('                    &axis_limits[axis_index],','                    limit,')
p.write_text(t)
