from pathlib import Path
import os,csv,hashlib
s=Path(os.environ['s']);repo=Path('/mnt/development/csgrs');owner='crates/hyperpath/src/tangent.rs'
reviews={
'G1JoinProblem':('Four solver symbols, two target Point2 objects and the original Problem.','Retains a candidate endpoint and tangent that can be changed by the solver before replay.','Owns the Problem and both targets.','g1_join_problem and certify_g1_join_candidate','Keep target and candidate identity when replaying fitted geometry.'),
'classify_tangent_join':('Four Point2 operands and one PredicatePolicy.','Checks endpoint equality first, then classifies tangent alignment. A zero vector at coincident endpoints yields DegenerateTangent under STRICT.','Borrows the four points and returns a Copy report.','classify_tangent_chain','Preserve the strict direct classification as an independent check on G1 residuals.'),
'g1_join_problem':('Point2 endpoints and unnormalized Real tangent components.','Builds two endpoint equalities, a zero cross product and a nonnegative dot product. At coincident endpoints a zero tangent satisfies all four residuals.','Builds four variables and four constraints, retaining target geometry.','certify_g1_chain and solver clients','Open correctness gap for zero dot product. Strict positive orientation is required for G1.'),
'certify_g1_join_candidate':('Current problem variables and retained exact target data.','Analyzes the model and replays its residuals. Either zero tangent can yield all_satisfied at coincident endpoints.','Constructs structural analysis, variable bindings and a candidate report.','certify_g1_chain and public G1 solver replay','Keep explicit diagnostic coverage for degenerate tangents before moving the solver boundary.'),
'certify_g1_chain':('Borrowed slice of TangentSpan with exact endpoint and tangent fields.','Replays each adjacent pair in order, so the individual zero-tangent false positive propagates to the chain.','Allocates and collects one candidate report per adjacent pair.','G1ChainCertificationReport and downstream path clients','Exercise single-join failure through the chain as well as the public candidate operation.'),
}
exec((s/'tangent-roles.py').read_text());add_roles(reviews)
assert len(reviews)==34
p=Path(__import__('sys').argv[1]);out=Path(__import__('sys').argv[2])
with p.open() as f: reader=csv.DictReader(f,delimiter='\t');fields=reader.fieldnames;rows=list(reader)
found=set();sha=hashlib.sha256((repo/owner).read_bytes()).hexdigest()
for r in list(rows):
 n=r['symbol']
 if r['path']!=owner or not r['review_status'].startswith('lexical') or n not in reviews:continue
 assert n not in found;found.add(n);representation,meaning,allocation,consumer,decision=reviews[n]
 rows.append(r|dict(endpoint_representation=representation,semantics=meaning,allocation=allocation,platform='Hyperpath std; native direct and solver replay controls measured on Rust 1.95.0.',serialization='No native wire encoding on the reviewed model or classification.',consumers=consumer,disposition=decision,baseline_tests='Hyperpath path_primitives tangent and G1 cases; separate public zero-tangent and hidden-displacement probes cover the direct and solver paths.',baseline_benchmarks='No G1 timing qualification in this review.',review_status='Body and immediate consumers reviewed against tangent.rs SHA-256 '+sha+'.'))
assert found==reviews.keys()
with out.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
