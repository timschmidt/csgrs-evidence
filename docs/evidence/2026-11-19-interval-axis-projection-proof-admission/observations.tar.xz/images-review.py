import json,os,sys
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s']);rows={}
for f in sorted((s/'images').glob('after-*')):
 k=f.name[6:];before=f.with_name('before-'+k);a,b=map(metrics,[before,f]);rows[k]={}
 for m in ('file','code','functions'):
  rows[k][m]={'previous':a[m],'candidate':b[m],'delta':b[m]-a[m],'percent':100*(b[m]-a[m])/a[m],'incremental_cap':min(4096,a[m]//100),'cumulative_cap':min(8192,a[m]//50)}
 rows[k]['hashes']=[a['sha256'],b['sha256']]
 print(k,[rows[k][m]['delta'] for m in ('file','code','functions')])
(s/'sizes.json').write_text(json.dumps(rows,indent=2)+'\n')
