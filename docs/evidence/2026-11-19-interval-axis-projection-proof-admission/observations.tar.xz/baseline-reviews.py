from pathlib import Path
import os
s=Path(os.environ['s']);p=s/'review-axis.py';t=p.read_text()
t=t.replace("path=Path(os.environ.get(",'''# These dispositions are tied to the primary source, including known failures.
for i,r in enumerate(reviews):
    name,rep,meaning,allocation,consumer,decision=r
    if name=='require_positive':
        meaning='Maps the returned sign to a typed error or success. Terminal approximate zero can mislabel an exact positive limit.'
    elif name=='select_minimum':
        meaning='Replaces only on a reported strict decrease. A terminal approximate equality can keep the wrong row.'
    elif name=='is_positive_projection':
        meaning='Distinguishes returned positive and zero signs. Approximate zero can skip an invalid negative derivative.'
    elif name=='validate_projection_inputs':
        meaning+=' A terminal approximate zero can admit an exact negative component.'
    elif name=='plan_axis_projected_motion_limits':
        meaning+=' An approximate validation can publish an invalid absolute derivative as certified.'
    elif name=='certify_axis_projected_motion_limits':
        meaning+=' Independent replay can pass the same invalid derivative after a terminal zero.'
    if name in ('require_positive','select_minimum','is_positive_projection','validate_projection_inputs','plan_axis_projected_motion_limits','certify_axis_projected_motion_limits'):
        decision+=' The public proof requires certified decisions at the predicate boundary.'
    reviews[i]=(name,rep,meaning,allocation,consumer,decision)
path=Path(os.environ.get(''')
t=t.replace('Hyperpath axis_projection_certainty and path_primitives affine_axis_projection cases','Archived axis_projection_certainty failure and maintained path_primitives affine_axis_projection cases')
exec(compile(t,str(p),'exec'))
