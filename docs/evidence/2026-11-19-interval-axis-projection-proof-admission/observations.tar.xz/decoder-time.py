from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,json,shutil,subprocess,statistics,resource
s=Path(os.environ['s'])
def run(arg):
 cpu,tc=arg;script=s/'timings'/f'decoder-{cpu}';res=[]
 for i in range(6):
  block={}
  for tag in (('original','current','current','original') if (i+cpu)%2 else ('current','original','original','current')):
   shutil.copyfile(s/f'{tag}-schedule-equivalence-{tc}',script);script.chmod(0o755)
   p=subprocess.Popen(['setarch','x86_64','-R','taskset','-c',str(cpu),script,'--test-threads=1'],stdout=subprocess.DEVNULL)
   _,code,usage=os.wait4(p.pid,0);assert code==0;p.returncode=0
   block.setdefault(tag,[]).append(usage.ru_utime+usage.ru_stime)
  res.append(block)
 (s/f'decoder-time-{tc}-{cpu}.json').write_text(json.dumps(res)+'\n')
with ThreadPoolExecutor(4) as ex:list(ex.map(run,[(4,'1.95.0'),(14,'1.95.0'),(5,'stable'),(15,'stable')]))
