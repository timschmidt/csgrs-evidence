import os,sys,json,hashlib
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s']);p=s/'images';anchors=('fixed','before');trials=('after','decisions','capacity','bindings','rows','receipt','zip')
rows={}
for base in sorted(p.glob('before-*')):
 name=base.name[7:];data={tag:metrics(p/f'{tag}-{name}') for tag in anchors+trials}
 row={'raw':data};rows[name]=row
 for tag in trials:
  checks={}
  for m in ('file','code','functions'):
   a,b,c=[data[t][m] for t in (*anchors,tag)]
   inc=min(4096,b//100);cum=min(8192,a//50);prior=max(0,b-a);debit=max(0,c-b)
   checks[m]={'delta':c-b,'percent':100*(c-b)/b,'incremental_cap':inc,'incremental_left':inc-debit,'positive_growth_from_program_baseline_before_trial':prior,'cumulative_cap':cum,'cumulative_left':cum-prior-debit,'slot_remaining':64*2**20-c if m=='file' else None}
  row[tag]=checks
for tag in trials:
 positive=[(k,m,v['delta']) for k,r in rows.items() for m,v in r[tag].items() if v['incremental_left']<0 or v['cumulative_left']<0];print(tag,positive, max(r[tag]['file']['delta'] for r in rows.values()), max(r[tag]['code']['delta'] for r in rows.values()))
(s/'linked-size-review.json').write_text(json.dumps(rows,indent=1)+'\n')
