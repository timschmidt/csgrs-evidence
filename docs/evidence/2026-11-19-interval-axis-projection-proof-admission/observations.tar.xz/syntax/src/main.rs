use std::{env,fs};
use syn::{Ident,visit::{self,Visit}};
struct Inventory<'a>(&'a str);
impl Inventory<'_> {
    fn add(&self,k:&str,n:&Ident){println!("{}\t{}\t{k}\t{n}",self.0,n.span().start().line);}
}
impl<'a> Visit<'a> for Inventory<'_> {
    fn visit_item_struct(&mut self,x:&'a syn::ItemStruct){self.add("struct",&x.ident);visit::visit_item_struct(self,x);}
    fn visit_item_enum(&mut self,x:&'a syn::ItemEnum){self.add("enum",&x.ident);visit::visit_item_enum(self,x);}
    fn visit_item_trait(&mut self,x:&'a syn::ItemTrait){self.add("trait",&x.ident);visit::visit_item_trait(self,x);}
    fn visit_item_type(&mut self,x:&'a syn::ItemType){self.add("type",&x.ident);visit::visit_item_type(self,x);}
    fn visit_signature(&mut self,x:&'a syn::Signature){self.add("fn",&x.ident);visit::visit_signature(self,x);}
    fn visit_impl_item_type(&mut self,x:&'a syn::ImplItemType){self.add("type",&x.ident);visit::visit_impl_item_type(self,x);}
    fn visit_trait_item_type(&mut self,x:&'a syn::TraitItemType){self.add("type",&x.ident);visit::visit_trait_item_type(self,x);}
}
fn main(){for path in env::args().skip(1){let m=syn::parse_file(&fs::read_to_string(&path).unwrap()).unwrap();Inventory(&path).visit_file(&m);}}
