set -eu
v=$1
mkdir -p "$s/deployed/$v-browser"
tool="$s/wasm-bindgen"
"$tool" --version
wasm-opt --version
"$tool" --target web --no-typescript --out-name alumina-interface --out-dir "$s/deployed/$v-browser" "$s/deployed/$v-alumina_interface.wasm"
export BINARYEN_CORES=6
wasm-opt -Oz --enable-bulk-memory --enable-nontrapping-float-to-int "$s/deployed/$v-browser/alumina-interface_bg.wasm" -o "$s/deployed/$v-browser.wasm"
gzip -9 -n -c "$s/deployed/$v-browser.wasm" > "$s/deployed/$v-browser.wasm.gz"
brotli -q 11 -w 23 -n -f "$s/deployed/$v-browser.wasm" -o "$s/deployed/$v-browser.wasm.br"
