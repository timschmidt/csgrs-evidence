from concurrent.futures import ThreadPoolExecutor
import os,subprocess,shutil,statistics,json,random
from pathlib import Path
s=Path(os.environ['s']);jobs=[('1.95.0','passive',32,8,'approx'),('stable','active',32,8,'approx'),('1.95.0','active',1,1,'strict'),('stable','passive',32,8,'strict')]
def run(arg):
 cpu,ix=arg;res={};rng=random.Random(791+cpu)
 for tc,mode,n,k,policy in jobs[ix:]+jobs[:ix]:
  kcase=f'{tc}/{mode}/{n}/{k}/{policy}';values=[]
  dest=s/'timings'/f'confirm-{cpu}'
  for j in range(10):
   order=['before','after','after','before'] if rng.randrange(2) else ['after','before','before','after']
   group={'before':[],'after':[]}
   for v in order:
    shutil.copyfile(s/'images'/f'{v}-{tc}-time-trace',dest);dest.chmod(0o755)
    a=subprocess.check_output(['setarch','x86_64','-R','taskset','-c',str(cpu),dest,'measure',mode,str(n),policy],text=True)
    rows=[line.split() for line in a.splitlines()];assert len(rows)==30 and all(int(r[2])==k for r in rows)
    group[v].append(statistics.median(int(r[6])/int(r[5]) for r in rows))
   values.append(group)
  res[kcase]=values
 (s/f'confirm-{cpu}.json').write_text(json.dumps(res)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(run,[(7,0),(18,2)]))
