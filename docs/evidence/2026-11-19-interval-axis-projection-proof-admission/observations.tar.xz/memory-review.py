import json,os,re,sys,ast
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1]
load=lambda v:json.loads((s/(v+'-memory.json')).read_text())
before,cand=map(load,('before',tag))
def extract(obs):
 out=[]
 for p in ('90','165'):
  data={}
  stack,*rows=obs[p];data['stack']=int(stack.split()[1]);records=[]
  for row in rows:
   i,j,left,right=re.fullmatch(r'ROW (\d+) (\d+) (\(.*?\)) (\(.*?\))',row).groups();u=ast.literal_eval(left);v=ast.literal_eval(right);records.append((int(j),u,v))
  for name,ix,which in [('allocations',0,1),('deallocations',1,1),('reallocations',2,1),('requested_traffic',3,1),('requested_peak',4,1),('usable_traffic',0,2),('usable_peak',1,2)]:
   data[name]=max(r[which][ix] for r in records)
  for j,stage in enumerate(('input','plan','replay','trace','cleanup')):
   for which,ix,name in ((1,5,'requested'),(2,2,'usable')):data[name+'_'+stage]=max(r[which][ix] for r in records if r[0]==j)
  out.append(data)
 return {k:max(d[k] for d in out) for k in out[0]}
rows={}
for k,v in before.items():
 assert v['out_sha256']==cand[k]['out_sha256'] and v['trace_sha256']==cand[k]['trace_sha256']
 a,b=map(extract,[v,cand[k]]);rows[k]={name:[a[name],b[name],b[name]-a[name]] for name in a}
for m in next(iter(rows.values())):print(m,min(x[m][2] for x in rows.values()),max(x[m][2] for x in rows.values()))
(s/f'{tag}-memory-review.json').write_text(json.dumps(rows,indent=1)+'\n')
