from collections import Counter
import csv,json,sys,os,subprocess
from pathlib import Path
s=Path(os.environ['s']);base=Path('crates/hyperpath/src')
files=[str(base/n) for n in ('routing.rs','tangent.rs','solve.rs','routing/axis_projection.rs')]
raw=subprocess.check_output([s/'syntax-target/release/axis-source-audit',*files],text=True)
(s/'syntax.tsv').write_text(raw)
def read(p):
 with Path(p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
outpath=Path(sys.argv[1]);current=read(outpath);historical=read('interval-inventory.tsv')
def declarations(rows):return {(r['path'],r['line'],r['kind'],r['symbol']) for r in rows if r['review_status'].startswith('lexical') and r['path'] in files}
oracle={tuple(i.split('\t')) for i in raw.splitlines()}
assert declarations(current)==oracle
def manual(rows):return Counter(tuple(r.values()) for r in rows if not r['review_status'].startswith('lexical') and r['review_status']!='repository unavailable')
old,new=manual(historical),manual(current);assert not old-new
print('syn exact agreement:', dict(Counter(r[0] for r in sorted(oracle))),'manual records',sum(old.values()),sum(new.values()))
for name in ['before-inventory.tsv', 'after-inventory.tsv']:
 rows=read(s/name);print(name, len(declarations(rows)),sum(v['review_status'].startswith('lexical') for v in rows))
