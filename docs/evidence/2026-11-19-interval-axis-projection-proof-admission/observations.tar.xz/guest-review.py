import json,os
from pathlib import Path
s=Path(os.environ['s']);results={}
for tc in ('1.95.0','stable'):
 a=json.loads((s/f'before-guest-memory-{tc}.json').read_text())['results']
 def key(x):return tuple(x[m] for m in ('c','warm','approx','iteration','fill'))
 base={key(x):x for x in a}
 for tag in ('after','decisions','bindings','rows','receipt','capacity','zip'):
  p=s/f'{tag}-guest-memory-{tc}.json'
  if not p.is_file():continue
  b=json.loads(p.read_text())['results'];rc={}
  for x in b:
   # Old approximate false successes and wrong failures are not successful controls.
   changed=x['c']<5 and x['approx'];neighbor=x|{'approx':0} if changed else x
   y=base[key(neighbor)];assert x['actual']==y['actual']
   rc[str(key(x))]={m:[y[m],x[m],x[m]-y[m]] for m in ('stack_bytes','linear_bytes')}
  results[f'{tag}/{tc}']=rc
  print(tag,tc,[(met,min(r[met][2] for r in rc.values()),max(r[met][2] for r in rc.values()),max(r[met][1] for r in rc.values())) for met in ('stack_bytes','linear_bytes')])
(s/'guest-lifetime-comparison.json').write_text(json.dumps(results,separators=(',',':'))+'\n')
