# The five G1 witnesses are described separately in review-tangent.py.
def add_roles(reviews):
 def add(n,rep,sem,alloc,who,action):reviews[n]=(rep,sem,alloc,who,action)
 add('TangentAlignment','Five-way enum for a pair of directed vectors.','Encodes parallel orientation, a corner, degeneracy or uncertainty. Certainty of a decided relation is not carried separately.','Copy enum.','TangentJoinReport and classify_tangent_alignment','Preserve undecided results; see the hidden cross-product witness.')
 add('TangentJoinClass','Six-way join classification.','Distinguishes coincident same-direction, reversed, corner and degenerate joins from mismatched endpoints or an undecided join.','Copy enum.','TangentChainReport','Keep endpoint mismatch distinct from tangent degeneracy.')
 add('TangentJoinReport','Join class plus Option<bool> for endpoints and optional alignment.','Keeps evidence of which predicates ran. Unknown endpoint equality precludes an alignment report.','Copy fields.','classify_tangent_chain','Retain the endpoint-before-tangent decision order and expose certainty.')
 add('TangentSpan','Four Point2 values with exact Real components.','Owns both endpoints and both directed, unnormalized tangent vectors of a span.','Inline points with shared Real handles.','classify_tangent_chain and certify_g1_chain','Keep source-directed start and end tangents.')
 for n,rep,sem,act in [
  ('from_line_segment','LinePathSegment','Clones both segment endpoints and queries each directed endpoint displacement.','Preserve exact displacement direction.'),
  ('from_cardinal_arc','CircularArc','Obtains both cardinal endpoints and directed radial-rotation tangents from the arc.','Preserve traversal for both rotations.'),
  ('from_explicit_arc','ExplicitCircularArc','Clones the retained endpoints and queries both directed radial-rotation tangents.','Keep the explicit endpoints paired with their arc.'),
  ('from_quadratic_bezier','QuadraticBezier','Clones the endpoints and evaluates the linear hodograph at exact parameters zero and one.','Preserve stationary endpoint tangents.'),
  ('from_cubic_bezier','CubicBezier','Clones the endpoints and evaluates the quadratic hodograph at exact parameters zero and one.','Keep the original parameter directions.'),
  ('from_rational_quadratic_bezier','RationalQuadraticBezier','Evaluates both endpoint derivatives by the rational curve API and propagates its typed failure.','Preserve the fallible quotient-rule construction.')]:
  add(n,rep+' to four exact Point2 values.',sem,'Constructs a TangentSpan using the source accessors.','TangentSpan for direct and solver chain consumers',act)
 add('TangentChainReport','Ordered vector of direct TangentJoinReport values.','Stores one direct result for each adjacent pair.','Owns the join vector.','all_g1_continuous and first_non_g1_join','Keep adjacency and exact join ordering.')
 add('G1ChainCertificationReport','Ordered vector of Hypersolve candidate reports.','Preserves all constraint rows per join and their original order. A zero tangent currently passes its residuals.','Owns each report and the join vector.','all_certified and first_uncertified_join','Carry per-join residual evidence and distinguish a degenerate candidate.')
 for n,sem,who in [
  ('all_g1_continuous','Tests for G1Continuous on every class. Returns true with no joins.','Direct chain clients'),
  ('first_non_g1_join','Returns the first index whose class differs from G1Continuous, including Unknown.','Direct chain diagnostics'),
  ('all_certified','Requires all_satisfied on each solver report. Returns true with no joins.','Solver replay clients'),
  ('first_uncertified_join','Finds the first report rejected by all_satisfied. A false positive on a degenerate tangent escapes this query.','Solver chain diagnostics')]:
  add(n,'Borrowed join sequence; Boolean or optional index.',sem,'Short-circuit iteration over retained rows.',who,'Maintain ordered query semantics and propagate evidence from the underlying join.')
 add('TangentAlignmentProblem','Two candidate component symbols, retained target Point2 and Problem.','Represents a movable tangent and its target for cross-product or oriented replay.','Owns both variable and constraint vectors.','certify_tangent_alignment_candidate','Keep oriented and unoriented model semantics distinct.')
 add('classify_tangent_alignment','Two exact Point2 tangent vectors and a predicate policy.','Checks zero vectors, then cross, then dot only for a parallel pair. With a hidden nonzero cross, approximate equality can publish SameDirection.','Constructs exact intermediate Real values.','classify_tangent_join','Require a certified relation wherever a report advertises exact alignment.')
 add('classify_tangent_chain','Borrowed slice of TangentSpan.','Pairs each end with the next start and runs the direct classifier in adjacency order.','Collects one direct report per pair.','TangentChainReport','Preserve original join ordering and certainty from each classifier.')
 add('tangent_alignment_problem','Candidate and target Point2 tangents.','Builds only the cross-product equality and does not require positive orientation.','Constructs a two-variable Problem.','certify_tangent_alignment_candidate','Keep the unoriented cross-product model explicit.')
 add('oriented_tangent_alignment_problem','Candidate and target Point2 tangents.','Adds a nonnegative dot-product constraint. Solver replay accepts an exactly zero vector on either side.','Constructs a two-variable, two-constraint Problem.','certify_tangent_alignment_candidate','Resolve the zero-vector discrepancy in the oriented contract.')
 add('build_tangent_alignment_problem_with_orientation','Two Point2 inputs and an orientation selector.','Creates two candidate components, a common cross residual and an optional dot constraint under the same symbols.','Owns constraint expressions and the exact target.','Both tangent alignment constructors','Keep the optional orientation requirement and carry exact target components.')
 add('certify_tangent_alignment_candidate','TangentAlignmentProblem and its current variable values.','Builds solver analysis and bindings and certifies each active residual. Oriented zero vectors satisfy both residuals.','Owns the returned candidate report.','Public solver tangent replay','Require certified nonzero direction for an oriented tangent guarantee.')
 for n,rep,sem,who in [
  ('tangent_cross','Two Point2 vectors.','Returns first.x times second.y minus first.y times second.x.','classify_tangent_alignment'),
  ('tangent_dot','Two Point2 vectors.','Returns the sum of the two componentwise products.','classify_tangent_alignment'),
  ('tangent_norm_squared','One Point2 vector.','Uses the signed-product-sum kernel for x squared plus y squared.','is_zero_vector')]:
  add(n,rep,sem,'Constructs an exact Real using the scalar owner.',who,'Preserve the directed expression and scalar dispatch.')
 add('is_zero_vector','Vector squared norm and PredicatePolicy.','Compares the norm with exact zero. Unknown or an impossible negative norm returns None. A terminal equality can misclassify a small nonzero tangent.','Constructs a Real squared norm and compares it.','classify_tangent_alignment','Use a certified zero test for a degeneracy claim.')
 for n,end in [('parameter_zero','0'),('parameter_one','1')]:
  add(n,'Closed BezierParameter '+end+'/1.','Constructs the exact '+end+' endpoint of the unit parameter domain.','Fixed parameter value.','Polynomial and rational Bezier tangent adapters','Keep exact endpoint evaluation.')
