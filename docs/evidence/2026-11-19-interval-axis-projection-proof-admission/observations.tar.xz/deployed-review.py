import hashlib,json,os,subprocess,re
from pathlib import Path
from metrics import metrics
s=Path(os.environ['s']);p=s/'deployed'
out={}
for name in ('alumina_interface.wasm','browser.wasm','browser.wasm.gz','browser.wasm.br','alumina-interface','browser/alumina-interface.js'):
 a,b=[p/(t+'-'+name) for t in ('before','after')]
 assert a.is_file() and b.is_file()
 def describe(f):
  if name.endswith('.wasm'):return metrics(f)
  raw=f.read_bytes();r={'sha256':hashlib.sha256(raw).hexdigest(),'file':len(raw)}
  if name=='alumina-interface':
   sections=subprocess.check_output(['size','-A',f],text=True)
   r['sections']={k:int(n) for k,n in re.findall(r'^(\.[\w.]+)\s+(\d+)\s+\d+\s*$',sections,re.M)}
  return r
 x,y=map(describe,(a,b));out[name]={'before':x,'after':y,'file_delta':y['file']-x['file'],'file_percent':100*(y['file']-x['file'])/x['file'],'remaining_slot':64*2**20-y['file']}
 print(name,out[name]['file_delta'],out[name]['remaining_slot'])
(s/'deployed-review.json').write_text(json.dumps(out,indent=1)+'\n')
