from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,statistics,shutil,random,sys
s=Path(os.environ['s']);tag=sys.argv[1]
def one(arg):
 cpu,tc=arg;rng=random.Random(cpu+1491); out={}
 for mode in ('default','passive','active'):
  img=f'{tc}-time-'+('normal' if mode=='default' else 'trace')
  values=[]
  for i in range(12):
   g={};seq=['before',tag,tag,'before'] if rng.randrange(2) else [tag,'before','before',tag]
   for v in seq:
    dest=s/'timings'/f'contract-{tag}-{cpu}';shutil.copyfile(s/'images'/f'{v}-{img}',dest);dest.chmod(0o755)
    res=subprocess.check_output(['setarch','x86_64','-R','taskset','-c',str(cpu),dest,'measure',mode],text=True,env=os.environ|{'LD_PRELOAD':str(s/'thread-clock.so')})
    rows={}
    for ln in res.splitlines():
     _,n,k,p,j,reps,ns=ln.split();rows.setdefault(f'{n}/{k}/{p}',[]).append(int(ns)/int(reps))
    assert len(rows)==6 and all(len(a)==30 for a in rows.values())
    g.setdefault(v,[]).append({k:statistics.median(a) for k,a in rows.items()})
   values.append(g)
  out[mode]=values
  (s/f'contract-{tag}-{tc}-{cpu}.json').write_text(json.dumps(out)+'\n')
with ThreadPoolExecutor(4) as pool:list(pool.map(one,[(7,'1.95.0'),(18,'1.95.0'),(8,'stable'),(19,'stable')]))
