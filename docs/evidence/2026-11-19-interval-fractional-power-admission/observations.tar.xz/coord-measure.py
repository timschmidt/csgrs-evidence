from pathlib import Path
import os,subprocess as sp,json
from concurrent.futures import ThreadPoolExecutor
from metrics import metrics
s=Path(__file__).resolve().parent;b=s/'wasibase'
def git(*args):return sp.check_output(['git','-C',b,*args])
assert not git('status','--porcelain')
for tag in ['before','copied']:
 if tag=='copied':git('apply',str(s/'copied.patch'))
 def lane(c):
  for role in ['ordinary','coordinator']:
   env=os.environ|{'CARGO_TARGET_DIR':str(s/('suite-target-'+c)),'CARGO_BUILD_JOBS':'4'}
   if role=='coordinator':env['HYPERINTERVAL_REPLAY_DRIVER']=str(s/'child-driver')
   cmd=['cargo','+'+c,'build','--release','--locked','--offline','--all-features','-p','hyperinterval','--test','fractional_power','--test','tangent','--message-format=json']
   with (s/f'coord-{role}-{tag}-{c}.log').open('w') as f:out=sp.check_output(cmd,cwd=b,env=env,stderr=f,text=True)
   rows={x['target']['name']:metrics(Path(x['executable'])) for x in map(json.loads,out.splitlines()) if x.get('executable')};assert len(rows)==2
   if role=='coordinator' and tag=='copied':assert json.loads((s/'records'/f'coordinator-copied-{c}.json').read_text())==rows
   (s/'records'/f'coord-{role}-{tag}-{c}.json').write_text(json.dumps(rows))
 with ThreadPoolExecutor(2) as pool:list(pool.map(lane,['1.95.0','stable']))
 if tag=='copied':git('restore','--','crates/hyperinterval/src')
