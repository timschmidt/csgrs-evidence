from pathlib import Path
import json,re,subprocess as sp
s=Path(__file__).resolve().parent
def read(n):return (s/n).read_text()
def count(n):
 t=read(n);assert not re.search(r'test result: FAILED|panicked at',t)
 return sum(map(int,re.findall(r'test result: ok. (\d+) passed',t)))
result={k:count('copied-'+k+'.log') for k in ['owner','witness','no-trace','solver','dynamics']}
assert list(result.values())==[307,4,4,9,10]
for c in ['1.95.0','stable']:
 logs=list(s.glob('guest-copied-'+c+'-*.log'));n=sum(count(p.name) for p in logs);assert n==34 and len(logs)==6
 for suite in ['tangent','fractional_power']:
  assert count(f'copied-parent-{c}-{suite}.log')==count(f'copied-parent-child-{c}-{suite}.log')==1
 result[c+'-wasi']=n+2
assert '10000 runs' in read('copied-asan.log') and 'No findings' in read('workflow-audit.log')
assert read('copied-fmt.log')==read('copied-fuzz-fmt.log')==''
for name in ['clippy','fuzz-clippy','docs']:
 t=read('copied-'+name+'.log');assert 'Finished' in t and 'warning:' not in t
assert 'FAILED' in read('baseline.log')
result['asan_runs']=10000
print(json.dumps(result))
(s/'receipts.json').write_text(json.dumps(result,indent=1))
