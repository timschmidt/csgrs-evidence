from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,tomllib,subprocess as sp,hashlib,tarfile
s=Path(__file__).resolve().parent;triple='x86_64-unknown-linux-gnu'
def run(c):
 root=Path(sp.check_output(['rustc','+'+c,'--print','sysroot'],text=True).strip())
 manifest=tomllib.loads((root/'lib/rustlib/multirust-channel-manifest.toml').read_text())
 pkg=manifest['pkg']['rust-std']['target']['wasm32-wasip1']
 archive=s/('std-'+c+'.xz');sp.run(['curl','-fsSL','--retry','2','--max-time','90','-o',str(archive),pkg['xz_url']],check=True)
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==pkg['xz_hash']
 dest=s/('sysroot-'+c)/'lib/rustlib';dest.mkdir(parents=True,exist_ok=True);(dest/triple).symlink_to(root/'lib/rustlib'/triple,target_is_directory=True)
 with tarfile.open(archive,'r:xz') as t:
  for f in t:
   head='/lib/rustlib/wasm32-wasip1/'
   if head not in f.name or not f.isfile():continue
   out=dest/'wasm32-wasip1'/f.name.split(head)[1];out.parent.mkdir(parents=True,exist_ok=True)
   out.write_bytes(t.extractfile(f).read())
 print(c,flush=True)
with ThreadPoolExecutor(2) as pool:list(pool.map(run,['1.88.0']))
