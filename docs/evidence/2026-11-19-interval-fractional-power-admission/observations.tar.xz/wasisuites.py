from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,sys,subprocess as sp,importlib.util
from metrics import metrics
s=Path(__file__).resolve().parent;root=s.parent/'csgrs';b=s/'wasibase'
spec=importlib.util.spec_from_file_location('runner',s/'run-wasi.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
def git(*args):return sp.check_output(['git','-C',b,*args])
for label in sys.argv[1:]:
 rev='c9f1f9ac5' if label=='fixed' else 'bc8fe3061'
 git('switch','--detach',rev)
 manifest=b/'crates/hyperinterval/Cargo.toml'
 old=manifest.read_bytes()
 if 'force-cross' not in manifest.read_text():
  with manifest.open('a') as f:f.write('\n[target.wasm32-wasip1.dev-dependencies]\ngmp-mpfr-sys={version="1.7",default-features=false,features=["force-cross"]}\n')
  sp.run(['cargo','+1.95.0','metadata','--offline','--format-version','1','--filter-platform','wasm32-wasip1'],cwd=b,stdout=sp.DEVNULL,stderr=(s/'wasi-lock.log').open('a'))
 if label not in ['fixed','before']:
  git('apply',str(s/(label+'.patch')))
  p=b/'crates/hyperinterval/tests/fractional_power_ingress.rs';p.write_bytes((root/'crates/hyperinterval/tests/fractional_power_ingress.rs').read_bytes())
 tests=[n for n in ['fractional_power','tangent','trigonometry','periodic_refinement','periodic_ingress','fractional_power_ingress'] if (b/f'crates/hyperinterval/tests/{n}.rs').is_file()]
 def lane(c):
  target=s/('wasi-target-'+c)
  flags='--sysroot='+str(s/('sysroot-'+c))+' -C link-arg='+str(s/'sdk/usr/lib/wasm32-wasi/libwasi-emulated-signal.a')
  env=os.environ|dict(CARGO_TARGET_DIR=str(target),CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS=flags,CARGO_BUILD_JOBS='6')
  cmd=['cargo','+'+c,'build','--release','--offline','--target','wasm32-wasip1','-p','hyperinterval','--all-features','--message-format=json']
  for n in tests:cmd+=['--test',n]
  for n in ['fractional_power_cost','trig_cost','tangent_cost']:cmd+=['--example',n]
  with (s/f'wasi-{label}-{c}.log').open('w') as log:out=sp.check_output(cmd,cwd=b,env=env,stderr=log,text=True)
  records={};paths={}
  for row in map(json.loads,out.splitlines()):
   if not row.get('executable'):continue
   name=row['target']['name'];exe=Path(row['executable']);records[name]=metrics(exe)
   paths[name]=str(exe)
  (s/'records'/f'wasi-{label}-{c}.json').write_text(json.dumps(records,indent=1))
  (s/'records'/f'guest-paths-{label}-{c}.json').write_text(json.dumps(paths))
  skips={'tangent':'replay_then_another_pole_operation_in_fresh_process','fractional_power':'exact_replay_then_further_power_in_fresh_process'}
  for name in tests:
   runner.run(Path(paths[name]),['--test-threads=1']+(['--skip',skips[name]] if name in skips else []),s/f'guest-{label}-{c}-{name}.log')
 with ThreadPoolExecutor(2) as pool:list(pool.map(lane,['1.95.0','stable']))
 manifest.write_bytes(old);git('restore','--','Cargo.lock')
 if label not in ['fixed','before']:git('restore','--','crates/hyperinterval/src');p.unlink()
 print(label,flush=True)
