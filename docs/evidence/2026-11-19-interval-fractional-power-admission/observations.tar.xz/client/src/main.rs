use power_admission_client::{image,input,replay};
use std::hint::black_box;
#[cfg(feature="measure")] mod allocations;
fn main(){
 let args:Vec<_>=std::env::args().collect();
 let k:u32=args[1].parse().unwrap();let limit:u32=args[2].parse().unwrap();let times:usize=args[3].parse().unwrap();
 let complete=||{black_box(replay(black_box(k),black_box(limit)));};
 let retained=input(k);
 let warm=||{black_box(image(black_box(k),black_box(&retained),u64::from(black_box(limit))));};
 if times==0 {println!("{}",replay(k,limit));return;}
 for _ in 0..8 {complete();warm();}
 #[cfg(feature="measure")] {println!("{:?} {:?}",allocations::once(complete),allocations::once(warm));return;}
 #[allow(unreachable_code)] for f in [&complete as &dyn Fn(),&warm] {
 let start=std::time::Instant::now(); for _ in 0..times{f();} print!("{} ",start.elapsed().as_nanos());}
}
