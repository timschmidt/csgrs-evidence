import os,subprocess as sp,json
from pathlib import Path
from metrics import metrics
s=Path(__file__).resolve().parent;b=s.parent/'csgrs'
for p in ['native','wasm32-wasip1']:
 env=os.environ|dict(CARGO_TARGET_DIR=str(s/'msrv-target'))
 args=['cargo','+1.88.0','build','--release','--locked','--offline','-p','hyperinterval','--no-default-features','--features','integer,fixed,dyadic,float-proposal,float-enclosure,serde','--test','fractional_power_ingress','--message-format=json']
 if p!='native':
  args+=['--target',p];env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']='--sysroot='+str(s/'sysroot-1.88.0')+' -C link-arg='+str(s/'sdk/usr/lib/wasm32-wasi/libwasi-emulated-signal.a')
 else:
  for key in ['CC','CPPFLAGS','LIBS','AR','RANLIB']:env.pop(key,None)
  env['GMP_MPFR_SYS_CACHE']=str(s/'gmp')
 with (s/f'msrv-{p}.log').open('w') as f:out=sp.check_output(args,cwd=b,env=env,stderr=f,text=True)
 path=next(Path(row['executable']) for row in map(json.loads,out.splitlines()) if row.get('executable'))
 if p=='native':out=sp.check_output([path,'--list'],text=True);assert '0 tests' in out
 else:
  out=s/'msrv-empty-wasi.log';sp.run([s/'wasm-tools/bin/python',s/'run-wasi.py',path,out,'--list'],check=True);assert '0 tests' in out.read_text()
 (s/'records'/f'empty-{p}.json').write_text(json.dumps(metrics(path)))
