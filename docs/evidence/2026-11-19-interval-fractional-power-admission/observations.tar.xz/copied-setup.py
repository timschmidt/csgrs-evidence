from pathlib import Path
import subprocess as sp
s=Path(__file__).resolve().parent;b=s/'base';p=b/'crates/hyperinterval/src/fractional_power.rs';t=p.read_text();start=t.index('        let convert = |x: &hyperreal::Rational');end=t.index('        let (an, ad) = ',start)
fn='''// Charge the canonical magnitudes before copying them into the power kernel.
#[cfg(feature = "rational")]
fn copy_endpoint(
    x: &hyperreal::Rational,
    budget: &mut DyadicBudget,
) -> Result<(BigInt, BigInt), IntervalError> {
    let n = x.numerator();
    let d = x.denominator();
    budget.reserve(n.bits().max(d.bits()), 2, false)?;
    Ok((BigInt::from(n.clone()), BigInt::from(d.clone())))
}
'''
t=(t[:start]+t[end:]).replace('convert(a, budget)?','copy_endpoint(a, budget)?').replace('convert(b, budget)?','copy_endpoint(b, budget)?');t=t.replace('fn trivial(\n',fn+'fn trivial(\n');p.write_text(t)
(s/'copied.patch').write_bytes(sp.check_output(['git','-C',b,'diff','--','crates/hyperinterval/src']))
for name in ['build','suites','extra','paired','points']:
 p=s/f'ordered-{name}.py';(s/f'copied-{name}.py').write_text(p.read_text().replace('ordered','copied'))
