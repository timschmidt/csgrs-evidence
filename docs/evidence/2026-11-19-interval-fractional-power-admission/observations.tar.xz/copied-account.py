from pathlib import Path
import json,math,ast,re
s=Path(__file__).resolve().parent;r=s/'records';root=s.parent/'csgrs'
def get(n):return json.loads(n.read_text())
def dump(n,x):n.write_text(json.dumps(x,indent=1)+'\n')
def db(n):return get(r/(n+'.json'))
def room(f,b,v,prior=0,inc=4096,pct=.01,total=8192,cpct=.02):
 step=max(0,v-b);cum=step+prior;si=min(inc,int(b*pct))-step;sc=min(total,int(f*cpct))-cum
 assert min(si,sc)>=0,(f,b,v,prior,si,sc)
 return [f,b,v,prior,step,cum,si,sc]
labels=['fixed','before','copied'];keys=['file','code','functions']
fixed,before,now=[db(i) for i in labels]
sizes={};mem={};suites={};historical={};harness={};legacy={}
j=get(root/'docs/research/interval-size-accounts.json')
for lane in now:
 wasm=lane.endswith('wasm');c=lane.split('-')[0];rows=[x[lane] for x in (fixed,before,now)]
 sizes[lane]={}
 for m in keys:
  f,b,v=[x['size'][m] for x in rows]
  ic,ip=(1024,.005) if m=='functions' and not wasm else ((1024,.01) if wasm else (4096,.01))
  sizes[lane][m]=room(f,b,v,max(0,b-f),ic,ip)
 heap=[db('heap-'+z+'-'+c) for z in labels] if wasm else []
 out={}
 for k in rows[2]['jobs']:
  data=[x['jobs'][k] for x in rows];fs,bs,vs=[d[0] for d in data]
  if fs!=vs:
   assert fs==bs==1 and vs==2 and ast.literal_eval(k)[1]==97
   out[k]={'corrected_outcome':[fs,bs,vs]};continue
  cap=(1<<20) if wasm else (2<<20)-4096
  for t in range(2):
   inds=[t,t+2] if wasm else [2*t,2*t+1]
   f,b,v=[max(d[1][i] for i in inds) for d in data]
   m=room(f,b,v,max(0,b-f),128,.02,256,.04)
   assert cap-v>=262144
   if wasm: hp=[x[str((*ast.literal_eval(k),t))][-2:] for x in heap]
   else: hp=[list(map(int,re.findall(r'peak_live_bytes: (\d+), live_bytes: (-?\d+)',d[2])[t])) for d in data]
   assert hp[2][0]<=hp[1][0]<=hp[0][0] and hp[0][1]==hp[1][1]==hp[2][1]==0,(lane,k,t,hp)
   out.setdefault(k,[]).append({'stack':m,'headroom':cap-v,'heap_peak_retained':hp[2],'heap_history':hp})
 mem[lane]=out
period=get(s/'prior-periodic.json')['ordinary'];fresh=get(s/'prior-fresh.json')['rows']
for c in ['1.95.0','stable']:
 for platform,prefix in [('native','suites'),('wasm32-wasip1','wasi')]:
  lane=c+'-'+platform
  f,b,v=[db(f'{prefix}-{z}-{c}') for z in labels]
  if prefix=='suites':
   for d,z in zip([f,b,v],labels):d['trig_cost']=db(f'trig-{z}-{c}')
  suites[lane]={};historical[lane]={};new='fractional_power_ingress'
  harness[lane]=v[new];assert v[new]['file']<=4<<20
  for name in b:
   vv=v[name];bb=b[name]; suites[lane][name]={}
   for m in keys:
    old=period[c][platform].get(name,{}).get(m) or fresh[c][platform].get(name,{}).get(m)
    change_since_archive=max(0,bb[m]-old[2]) if old else 0
    if platform=='native' and old:
     origin='period' if name in period[c][platform] else 'fresh'
     change_since_archive=max(0,bb[m]-db(f'origin-{origin}-{c}')[name][m])
    if old:base=old[0];prior=old[5]+change_since_archive
    elif name=='periodic_ingress':
     a=j['monotone_composition_qualification']['targets'][c][platform]['existing_periodic_test']['metrics'][m];base=a['preceding'];prior=a['cumulative_positive_bytes']+max(0,bb[m]-(db(f'origin-mono-{c}')[name][m] if platform=='native' else a['measured']))
    else:
     base=f.get(name,bb)[m];prior=max(0,bb[m]-base)
    suites[lane][name][m]=room(base,bb[m],vv[m],prior,total=(old[5]+old[7] if old else 8192))
    if c=='1.95.0' and platform=='native' and name in ['trigonometry','fractional_power','tangent']:
     a=next(a for a in j['accounts'] if a.get('artifact','').endswith('/'+name+'.rs#release-tests'))['metrics'][{'file':'file','code':'executable_code','functions':'named_text'}[m]]
     caps=a['caps'];prior=(0 if name in ('tangent','trigonometry') else a['accepted_positive_growth_bytes'])+old[5]+change_since_archive
     historical[lane].setdefault(name,{})[m]=room(a['baseline'],bb[m],vv[m],prior,caps['incremental_bytes'],caps['incremental_percent']/100,caps['cumulative_bytes'],caps['cumulative_percent']/100)
   assert (64<<20)-vv['file']>=16<<20
for n in ['fractional_power_cost','tangent_cost']:
 a=next(x for x in j['accounts'] if x.get('artifact','').endswith('/'+n+'.rs'));legacy[n]={};z=[db('legacy-'+t)[n] for t in labels]
 for m,x in a['metrics'].items():
  key='functions' if m=='function_union' else m;f,b,v=[row[key] for row in z]
  old=get(s/'prior-periodic.json')['legacy'].get(key) if n=='tangent_cost' else None
  prior=(old[5]+max(0,b-old[2]) if old else x['accepted_positive_growth_bytes']+max(0,b-x['retained']));caps=x['caps']
  legacy[n][key]=room(x['baseline'],b,v,prior,caps['incremental_bytes'],caps['incremental_percent']/100,caps['cumulative_bytes'],caps['cumulative_percent']/100)
dump(r/'accounted.json',dict(columns=['reference','preceding','candidate','prior_positive','positive_step','cumulative_charge','remaining_step','remaining_cumulative'],clients=sizes,ordinary=suites,earlier_native_harnesses=historical,legacy=legacy,new_harness=harness,memory=mem))
for k,rows in mem.items():
 a=[d for v in rows.values() if isinstance(v,list) for d in v];print(k,'max step, cumulative, peak stack, min headroom, peak heap',max(x['stack'][4] for x in a),max(x['stack'][5] for x in a),max(x['stack'][2] for x in a),min(x['headroom'] for x in a),max(x['heap_peak_retained'][0] for x in a))
print('smallest ordinary cumulative balance',min((v[-1],k,n,m) for k,t in suites.items() for n,r in t.items() for m,v in r.items()))
