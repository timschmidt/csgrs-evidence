from pathlib import Path
import json,math,re,statistics
s=Path(__file__).resolve().parent;r=s/'records'
def load(n):return json.loads((r/(n+'.json')).read_text())
j=load('accounted');c=[*j['clients']];sz={};memory={};imgs={};co={}
def write(n,x):(s/(n+'.json')).write_text(json.dumps(x,indent=2)+'\n')
base=dict(source=(s/'source-revision').read_text().strip(),preceding='bc8fe3061137e00caf9909f44eed15d47c64e0a3',fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',evidence='docs/evidence/2026-11-19-interval-fractional-power-admission')
for lane in c:
 rows=j['clients'][lane];sz[lane]={m:dict(bytes=v[2],delta=v[2]-v[1],positive_charge=v[5],remaining_cumulative=v[7]) for m,v in rows.items()};sz[lane]['free_tool_slot_bytes']=(64<<20)-rows['file'][2]
 a=[x for v in j['memory'][lane].values() if isinstance(v,list) for x in v]
 memory[lane]=dict(maximum_stack_bytes=max(x['stack'][2] for x in a),largest_positive_step=max(x['stack'][4] for x in a),largest_cumulative_stack_charge=max(x['stack'][5] for x in a),minimum_remaining_cumulative_allowance=min(x['stack'][7] for x in a),minimum_stack_headroom=min(x['headroom'] for x in a),maximum_requested_heap_bytes=max(x['heap_peak_retained'][0] for x in a),largest_peak_heap_increase=max(max(0,x['heap_history'][2][0]-x['heap_history'][1][0]) for x in a),peak_retained_after_drop=0)
for lane,group in j['ordinary'].items():
 rows=[v for n,ms in group.items() for v in ms.values()]
 tot=max([x['file'][2] for x in group.values()]+[j['new_harness'][lane]['file']]);imgs[lane]=dict(maximum_positive_step=max(v[4] for v in rows),minimum_remaining_cumulative=min(v[7] for v in rows),maximum_file_bytes=tot,minimum_slot_headroom=(64<<20)-tot,new_harness_bytes=j['new_harness'][lane]['file'])
for c in ['1.95.0','stable']:
 a,b=[load('coord-ordinary-'+q+'-'+c) for q in ['before','copied']]
 x,y=[load('coord-coordinator-'+q+'-'+c) for q in ['before','copied']]
 old=json.loads((s/'prior-fresh.json').read_text())['rows'][c]['coordinator'];co[c]={}
 for n in y:
  co[c][n]={}
  for m in ['file','code','functions']:
   caps=min(16384,int(b[n][m]*.01))
   # Charge the selected parent path against the same revision's ordinary image.
   current=max(0,y[n][m]-b[n][m]);previous=max(0,x[n][m]-a[n][m])
   historic=old[n][m][5];total=max(previous,historic)+max(0,current-previous)
   assert total<=caps
   co[c][n][m]=dict(ordinary=b[n][m],coordinator=y[n][m],previous_premium=previous,current_premium=current,cumulative_premium=total,remaining=caps-total)
write('coordinator-account',co)
for plat in ['native','wasm32-wasip1']:
 m=load('empty-'+plat);assert m['file']<=4<<20;imgs['1.88.0-'+plat]=dict(new_harness_bytes=m['file'],minimum_slot_headroom=(64<<20)-m['file'],active_cases=0)
size=base|dict(scope='Generated rational endpoints in the fractional power consumer. Compare final linked public clients on Linux and bare Wasm plus owner release tests and cost drivers on Linux and WASI. The optional native replay coordinator uses its existing premium over the corresponding ordinary image. The reduced 1.88 feature lane builds an empty harness. Firmware selects integer/fixed backends. No rational power code reaches those linked firmware images.',caps='Public linked file, code and nonoverlapping function bytes: 4096 B and 1% incremental, 8192 B and 2% cumulative. Also limit bare Wasm to 1024 B incremental and native functions to 1024 B and 0.5%. Each 64 MiB tool slot retains 16 MiB. New test harness limited to 4 MiB. Existing ordinary, coordinator and legacy accounts retain their own limits and prior positive charges.',clients=sz,owner_release_images=imgs,legacy_cost_accounts=j['legacy'],legacy_columns=j['columns'],details='records/accounted.json contains per-image fixed, preceding, candidate, prior charge, step, cumulative charge and remaining allowances. Native earlier sources recompiled at the same path. coordinator-account.json carries each coordinator premium. No savings credited against growth.')
mem=base|dict(scope='One sequential completed rational power with materialized output, on canonical or generated point 3, cube-root range [-8,27], and the partial square root on [-8,4]. Check both a fresh input and a retained input. Complete point source construction uses an exact line intersection. Small-budget refusals are accounted separately from completed jobs.',caps='Zero positive requested heap growth and zero retained after drop. Per job stack growth at most 128 B and 2% incremental and 256 B and 4% cumulative. Retain at least 256 KiB stack headroom. Native worker has a 2 MiB mapping including a 4 KiB guard, bare-Wasm has a 1 MiB stack. No new concurrency.',targets=memory,details='records/accounted.json contains the per-case stack and heap history. Native pthread and Wasm canaries use two byte patterns. Heap peaks cover requested allocations only. records/process-resident.json reports process high-water separately, including the host runtime for bare Wasm.')
write('size-entry',size);write('memory-entry',mem)
