set -eu
s=/mnt/development/interval-power-admission.fJ3fwT
source "$s/env"
cd "$s"
python3 copied-legacy.py
git -C wasibase apply "$s/copied.patch"
"$s/wasm-tools/bin/python" copied-replays.py
git -C wasibase restore -- crates/hyperinterval/src
