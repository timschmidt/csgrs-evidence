import json,os,sys,subprocess as sp
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from metrics import metrics
s=Path(__file__).resolve().parent
cases={'tangent':('replay_then_another_pole_operation_in_fresh_process','HYPERINTERVAL_TANGENT_REPLAY'),'fractional_power':('exact_replay_then_further_power_in_fresh_process','HYPERINTERVAL_POWER_REPLAY')}
if '--exact' in sys.argv:
 import wasmtime as w
 n=os.environ['SUITE'];case,key=cases[n];c=os.environ['LANE']
 assert sys.argv[sys.argv.index('--exact')+1]==case and os.environ[key]
 e=w.Engine();store=w.Store(e);link=w.Linker(e);cfg=w.WasiConfig();cfg.argv=[n,*sys.argv[1:]];cfg.env=[(key,os.environ[key])]
 out=s/f'copied-parent-child-{c}-{n}.log';cfg.stdout_file=str(out);cfg.stderr_file=str(out)+'.stderr';store.set_wasi(cfg);link.define_wasi()
 m=w.Module.from_file(e,os.environ['GUEST'])
 try:link.instantiate(store,m).exports(store)['_start'](store)
 except w.ExitTrap as ex:
  if ex.code:raise
 assert f'test {case} ... ok' in out.read_text() and '1 passed' in out.read_text()
else:
 def lane(c):
  sizes={}
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('suite-target-'+c)),'HYPERINTERVAL_REPLAY_DRIVER':str(s/'child-driver'),'CARGO_BUILD_JOBS':'4'}
  cmd=['cargo','+'+c,'build','--release','--locked','--offline','--all-features','-p','hyperinterval','--test','fractional_power','--test','tangent','--message-format=json']
  with (s/f'copied-parent-{c}-build.log').open('w') as log:out=sp.check_output(cmd,cwd=s/'wasibase',env=env,text=True,stderr=log)
  guests=json.loads((s/'records'/f'guest-paths-copied-{c}.json').read_text())
  for row in map(json.loads,out.splitlines()):
   if not row.get('executable'):continue
   n=row['target']['name'];sizes[n]=metrics(Path(row['executable']));case,key=cases[n]
   with (s/f'copied-parent-{c}-{n}.log').open('w') as log:sp.run([row['executable'],'--exact',case,'--nocapture'],env=env|dict(SUITE=n,LANE=c,GUEST=guests[n]),stdout=log,stderr=sp.STDOUT,check=True)
  (s/'records'/f'coordinator-copied-{c}.json').write_text(json.dumps(sizes))
 with ThreadPoolExecutor(2) as pool:list(pool.map(lane,['1.95.0','stable']))
