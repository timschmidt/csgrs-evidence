import json,os,subprocess as sp
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from metrics import metrics
import wasmtime as w
s=Path(__file__).resolve().parent;b=s/'base';root=b.parent.parent/'csgrs'
def git(*args):return sp.check_output(['git','-C',b,*args])
for label in ['copied']:
 def run(c):
  log=(s/f'extra-{label}-{c}.log').open('w')
  t=s/('client-target-'+c);env=os.environ|{'CARGO_TARGET_DIR':str(t),'CARGO_BUILD_JOBS':'6'}
  sp.run(['cargo','+'+c,'build','--release','--offline','--target','wasm32-unknown-unknown','--features','measure','--lib'],check=True,env=env,cwd=s/'client',stderr=log)
  engine=w.Engine();m=w.Module.from_file(engine,str(t/'wasm32-unknown-unknown/release/power_admission_client.wasm'));assert not m.imports
  jobs={}
  for k in range(6):
   for l in [97,4096]:
    for temp in [0,1]:
     store=w.Store(engine);a=w.Instance(store,m,[]).exports(store)
     jobs[str((k,l,temp))]=[a['heap'](store,k,l,temp,i) for i in range(6)]
  (s/'records'/f'heap-{label}-{c}.json').write_text(json.dumps(jobs,indent=1))
  env['CARGO_TARGET_DIR']=str(s/('suite-target-'+c))
  cmd=['cargo','+'+c,'build','--release','--locked','--offline','--all-features','-p','hyperinterval','--example','trig_cost','--message-format=json']
  out=sp.check_output(cmd,cwd=b,env=env,stderr=log,text=True)
  path=next(r['executable'] for r in map(json.loads,out.splitlines()) if r.get('executable'))
  (s/'records'/f'trig-{label}-{c}.json').write_text(json.dumps(metrics(Path(path))))
 with ThreadPoolExecutor(2) as pool:list(pool.map(run,['1.95.0','stable']))
 print(label,flush=True)
