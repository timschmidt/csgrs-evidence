from pathlib import Path
import os,subprocess as sp,json,statistics as st,math,random
s=Path(__file__).resolve().parent
os.sched_setaffinity(0,{3})
rng=random.Random(20261119)
jobs=[(c,k) for c in ['1.95.0','stable'] for k in [0,1]]
raw={str(key):[] for key in jobs}
for sample in range(41):
 rng.shuffle(jobs)
 for c,k in jobs:
  order=['before','copied'] if (sample+k)%2==0 else ['copied','before']
  row={}
  for tag in order:
   out=sp.check_output([s/'bin'/f'{tag}-{c}-native',str(k),'4096','2048'],text=True)
   row[tag]=[int(x)/2048 for x in out.split()]
  raw[str((c,k))].append(row)
(s/'records'/'copied-point-timing.json').write_text(json.dumps(raw))
for key,rows in raw.items():
 def values(i):return [r['copied'][i]/r['before'][i] for r in rows]
 print(key,'complete/warm ratios',*[round(st.median(values(i)),3) for i in range(2)])
