from pathlib import Path
import os,sys,json
s=Path(__file__).resolve().parent
def peak(args):
 pid=os.fork()
 if not pid:
  dev=os.open('/dev/null',os.O_RDWR);os.dup2(dev,1);os.dup2(dev,2);os.execv(str(args[0]),list(map(str,args)))
 _,code,usage=os.wait4(pid,0);assert code==0,(args,code);return usage.ru_maxrss*1024
def run():
 rows={}
 for c in ['1.95.0','stable']:
  for tag in ['fixed','before','copied']:
   for kind in ['native','wasm']:
    p=s/'bin'/f'{tag}-{c}-{kind}'
    rows[f'{tag}-{c}-{kind}']=[peak([p,k,4096,1] if kind=='native' else [sys.executable,__file__,'guest',p,k]) for k in range(6)]
 (s/'records'/'process-resident.json').write_text(json.dumps(rows))
if len(sys.argv)==1:run()
else:
 import wasmtime as w
 e=w.Engine();st=w.Store(e);m=w.Module.from_file(e,sys.argv[2]);assert w.Instance(st,m,[]).exports(st)['replay'](st,int(sys.argv[3]),4096)==1
