from pathlib import Path
import json,subprocess as sp
from record import record
s=Path(__file__).resolve().parent
items=set()
for pattern in [
'caps.txt','source-revision','toolchains.txt','evidence-guide.md','env','wasienv','stack.c','stack_hook.c','record.py','collect.py','metrics.py','observe.py','build.py','extra.py','suites.py','wasisuites.py','wasisdk.py','msrv*.py','run-wasi.py','rss.py','legacy.py','period-remeasure.py','coord-measure.py','make-entries.py','append-account.py','prior-*.json','child-driver','coordinator-account.json','*-entry.json',
'baseline.log','workflow-audit.log','msrv*.log','origin-*.log','wasi-fixed*.log','wasi-before*.log','wasi-copied*.log','guest-copied*','legacy-*.log','copied*','ordered.patch','ordered-point-timing.log','ordered-timing.log','inline.patch','inline-point-timing.log','inline-timing.log','reuse.patch','compact.patch','pair.patch','direct.patch','*.txt','coord-*.log',
'records/fixed.json','records/before.json','records/copied.json','records/*-fixed*.json','records/*-before*.json','records/*-copied*.json','records/copied-*.json','records/origin-*.json','records/empty-*.json','records/process-resident.json','records/accounted.json','records/ordered*.json','records/compact.json','records/inline.json','records/reuse.json','records/pair.json','records/direct.json',
'client/Cargo.toml','client/Cargo.lock','client/src/*','shared-corpus/*','ordered-corpus/*','copied-corpus/*','check-receipts.py','receipts.json'
]:
 items.update(p for p in s.glob(pattern) if p.is_file())
assert all(p.stat().st_size<600000 for p in items)
res=record('fractional-power-admission',sorted(items),'Record rational fractional-power budget, lifetime and linked-target qualification')
(s/'archive-receipt.json').write_text(json.dumps(res))
print(res['members'],res['commit'],res['row'])
