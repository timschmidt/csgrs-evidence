import subprocess as sp,json,os,re
from pathlib import Path
from metrics import metrics
s=Path(__file__).resolve().parent;b=s/'wasibase'
def git(*a):return sp.check_output(['git','-C',b,*a])
assert not git('status','--porcelain')
for label,rev in [('fixed','c9f1f9ac5'),('before','bc8fe3061'),('shared','bc8fe3061')]:
 git('switch','--detach',rev)
 if label=='shared':git('apply',str(s/'shared.patch'))
 env=os.environ|dict(CARGO_TARGET_DIR=str(s/'suite-target-1.95.0'))
 cmd=['cargo','+1.95.0','build','--release','--locked','--offline','-p','hyperinterval','--features','integer,fixed,rational,dyadic,float-enclosure','--example','tangent_cost','--example','fractional_power_cost','--message-format=json']
 with (s/f'legacy-{label}.log').open('w') as f:rows=sp.check_output(cmd,cwd=b,env=env,stderr=f,text=True)
 result={}
 for row in map(json.loads,rows.splitlines()):
  if not row.get('executable'):continue
  p=Path(row['executable']);result[row['target']['name']]=metrics(p)|{m[1]:int(m[2]) for m in re.finditer(r'^(\.\S+)\s+(\d+)\s+\d+',sp.check_output(['size','-A',p],text=True),re.M)}
 (s/'records'/f'legacy-{label}.json').write_text(json.dumps(result,indent=1))
 if label=='shared':git('restore','--','crates/hyperinterval/src')
