from pathlib import Path
import os,subprocess as sp,json
from concurrent.futures import ThreadPoolExecutor
from metrics import metrics
s=Path(__file__).resolve().parent;b=s/'base';root=s.parent/'csgrs'
def git(*args):return sp.check_output(['git','-C',b,*args])
assert git('diff','--','crates/hyperinterval/src')==(s/'copied.patch').read_bytes()
t=b/'crates/hyperinterval/tests/fractional_power_ingress.rs';assert t.read_bytes()==(root/'crates/hyperinterval/tests/fractional_power_ingress.rs').read_bytes()
t.unlink();git('restore','--','crates/hyperinterval/src')
for label,rev,names in [
 ('period','5d15ce394447210262b3de7c20d2b8f99cebec18',['trigonometry','tangent','periodic_refinement','trig_cost','tangent_cost']),
 ('fresh','88e11ea7bbdab5c8d1ff7b5c73a5e010b7d310ee',['fractional_power']),
 ('mono','41e99d06eb4701ffdccaa4865ce7c622f09d3571',['periodic_ingress'])]:
 git('switch','--detach',rev)
 def measure(c):
  args=['cargo','+'+c,'build','--release','--locked','--offline','-p','hyperinterval','--all-features','--message-format=json']
  for n in names: args+=['--example' if n.endswith('_cost') else '--test',n]
  env=os.environ|dict(CARGO_TARGET_DIR=str(s/('suite-target-'+c)),CARGO_BUILD_JOBS='5')
  with (s/f'origin-{label}-{c}.log').open('w') as log:out=sp.check_output(args,cwd=b,env=env,text=True,stderr=log)
  rows={x['target']['name']:metrics(Path(x['executable'])) for x in map(json.loads,out.splitlines()) if x.get('executable')};assert set(rows)==set(names)
  (s/'records'/f'origin-{label}-{c}.json').write_text(json.dumps(rows))
 with ThreadPoolExecutor(2) as pool:list(pool.map(measure,['1.95.0','stable']))
git('switch','--detach','bc8fe3061')
