import json,os,subprocess,sys,shutil
from pathlib import Path
s=Path(__file__).resolve().parent
b=s/'base'; c=s/'client'; bin=s/'bin'
def command(args,cwd,log,env=None):
 with log.open('a') as f:
  subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for state,rev in [('fixed','c9f1f9ac5'),('before','bc8fe3061'),('after','bc8fe3061')]:
 log=s/(state+'-build.log')
 command(['git','switch','--detach',rev],b,log)
 if state=='after':
  command(['git','apply',s/'production.patch'],b,log)
 for compiler in ['1.95.0','stable']:
  for target in ['x86_64-unknown-linux-gnu','wasm32-unknown-unknown']:
   wasm=target.startswith('wasm')
   env=os.environ.copy();t=s/('client-target-'+compiler);env['CARGO_TARGET_DIR']=str(t)
   cmd=['cargo','+'+compiler,'build','--offline','--release','--target',target]
   if wasm:cmd+=['--lib']
   command(cmd,c,log,env)
   src=t/target/'release'/('power_admission_client.wasm' if wasm else 'power-admission-client')
   dest=bin/(state+'-'+compiler+('-wasm' if wasm else '-native'));shutil.copy(src,dest)
   if not wasm:
    command(cmd+['--features','measure','--bin','power-admission-client'],c,log,env);shutil.copy(src,str(dest)+'-heap')
   print(state,compiler,target,flush=True)
