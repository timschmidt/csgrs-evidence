import json,os,subprocess as sp,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from metrics import metrics
s=Path(__file__).resolve().parent;b=s/'base';root=Path('/mnt/development/csgrs')
def git(*args):return sp.check_output(['git','-C',b,*args])
for tag in ['copied']:
 tests=[p for p in ['fractional_power','trigonometry','tangent','periodic_ingress','periodic_refinement','fractional_power_ingress'] if (b/f'crates/hyperinterval/tests/{p}.rs').is_file()]
 ex=['fractional_power_cost','trig_cost','tangent_cost']
 ex=[n for n in ex if (b/f'crates/hyperinterval/conformance/{n}.rs').is_file()]
 def run(c):
  cmd=['cargo','+'+c,'build','--release','--offline','--locked','--all-features','-p','hyperinterval','--message-format=json']
  for n in tests:cmd+=['--test',n]
  for n in ex:cmd+=['--example',n]
  with (s/f'{tag}-{c}-suites.log').open('w') as log:
   out=sp.check_output(cmd,env=os.environ|{'CARGO_TARGET_DIR':str(s/('suite-target-'+c)),'CARGO_BUILD_JOBS':'6'},cwd=b,stderr=log,text=True)
  found={}
  for row in map(json.loads,out.splitlines()):
   if row.get('executable'):
    p=Path(row['executable']);found[row['target']['name']]=metrics(p)
  assert set(found)==set(tests+ex)
  (s/'records'/f'suites-{tag}-{c}.json').write_text(json.dumps(found,indent=1))
 with ThreadPoolExecutor(2) as pool:list(pool.map(run,['1.95.0','stable']))
 print(tag,'verified',flush=True)
