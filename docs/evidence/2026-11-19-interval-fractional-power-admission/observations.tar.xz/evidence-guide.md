# Fractional-power admission for generated rational endpoints

The preceding source is bc8fe3061137e00caf9909f44eed15d47c64e0a3.
source-revision identifies the accepted source. fixed is the program baseline
c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb. copied denotes the accepted
production implementation in file names. Other named trials are historical.

baseline.log records the failing 97-bit test. The exact line intersection has
98-bit stored parts and reduces to 3. The previous result [1,2] is a valid
enclosure for the cube root, but the reduction bypassed the stated input cap.
The maintained tests validate cache state, exact cutoff, retry, and ordinary,
split and partial-domain results. The fuzzer uses independently specified GMP
interval endpoints and the existing directed MPFR oracle.

## Replaying the measurements

Build release sources at one fixed checkout and target-directory path for
each comparison. The client is an independent Cargo package with relative
path dependencies on base, checked at fixed, before and source-revision.
The *-build scripts save separate, immutable final executables. See env,
wasienv, toolchains.txt, metrics.py, observe.py, stack.c, stack_hook.c,
copied-build.py, copied-extra.py and client/. Native symbols are the union
of the final ELF text-symbol ranges. The Wasm code section and sum of its
function bodies are measured separately. The canary export changes only
the Wasm export section; observe.py checks the unmodified program's result.
Native calls enter the actual linked replay symbol and include the caller
in the guarded pthread. A warmed worker repeats the whole public operation.
Allocator runs separately distinguish construction through drop from image
materialization on a previously used source. Process RSS includes allocator
and runtime overhead. The Wasm process RSS includes the host JIT.

The before and fixed releases erroneously return success on the 97-bit
generated jobs. These results are excluded from matched-workload memory
comparisons. The larger budget returns the expected exact enclosure and
coverage on all three source revisions. Cumulative growth always charges a
positive step within the same metric, image or job. Earlier artifact
charges are imported from the two prior registries. The native harness
compiler can embed build paths. origin-* rebuilds compare earlier sources
at this checkout path before adding any additional positive difference.
The earlier test additions have their own budgets. records/accounted.json
includes both the current and historical native accounts.

For each compiler, guest-copied logs contain the affected WASI libtest cases.
Two process-spawning tests on each toolchain run with a native producer and
a separate WASI guest reading its serialized result. The parent-child logs
certify that the guest actually entered the requested case. Rust 1.88 builds
the CI reduced feature set without the rational provider, so the new harness
has zero active tests there. Full native tests, docs, hosted Clippy, workflow
audit and the isolated fuzz run have their own logs.

## Timing and discarded alternatives

The 25 paired batches per workload use 512 completed operations per timing.
The separate 41 paired batches cover canonical/generated point inputs with
2,048 calls per timing. Each process verifies the numerical result. The first
number is construction through completion and the second uses a retained
input. Raw timings and both favorable and unfavorable medians are included.
These are measurements of six workloads on this host. The new deterministic
admission weights are visible on generated inputs even when the cache is warm.

ordered preserved all sign calls but repeated the point copies. Its
Rust 1.95 generated-point warm median was 2.6% slower on the longer run.
reuse and compact reused the coefficients but their linked Rust 1.95 bare
Wasm files exceeded the 1,024-byte step cap. inline met the linked size cap
and exceeded the 2% stack cap on the same target (64 B over 1,660 B on one
workload). copied uses the shared preflight, retains both original sign
checks and uses an owning-module endpoint copy function. Shared immutable
storage permits borrowing one materialized coefficient pair after both
endpoint charges. Separate source identities still follow their normal path.
