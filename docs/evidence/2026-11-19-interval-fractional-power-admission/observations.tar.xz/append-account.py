from pathlib import Path
import json,sys
p=Path(sys.argv[1]);key=sys.argv[2];value=json.loads(Path(sys.argv[3]).read_text())
t=p.read_text();original=json.loads(t);assert key not in original and t.endswith('}\n')
section=json.dumps(value,indent=2).splitlines()
p.write_text(t.rstrip()[:-1].rstrip()+',\n  "'+key+'": '+section[0]+'\n'+'\n'.join('  '+v for v in section[1:])+'\n}\n')
new=json.loads(p.read_text());assert new.pop(key)==value and new==original
