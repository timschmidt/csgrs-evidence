import sys,subprocess,re,json
from pathlib import Path
def sizes(p):
    s={'file':p.stat().st_size}
    for l in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
        m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)',l)
        if m and m[1]=='.text': s['text']=int(m[2],16)
    ranges=[]
    for l in subprocess.check_output(['readelf','-Ws',p],text=True).splitlines():
        r=l.split()
        if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit() and int(r[2]):
            a=int(r[1],16); ranges.append((a,a+int(r[2])))
    end=total=0
    for a,b in sorted(ranges): total+=max(0,b-max(a,end)); end=max(b,end)
    s['named_text']=total
    return s
d=Path(sys.argv[1]); out={}
for b in sorted({p.name.rsplit('-',1)[0] for p in d.iterdir() if p.name.endswith('-base')}):
    a=sizes(d/(b+'-base')); c=sizes(d/(b+'-cand'))
    out[b]={'base':a,'cand':c}
    print(f"{b:28s} "+'  '.join(f"{k} {a[k]}->{c[k]} ({c[k]-a[k]:+d})" for k in a))
json.dump(out,open(sys.argv[2],'w'),indent=1)
