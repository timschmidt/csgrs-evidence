Acceptance of the automatic affine-noise controller (flow-noise-evolution), 22 November 2026.
Before: CSGRS 51a095f0e. After: the same tree plus the 16 November candidate 3dc973c69,
cherry-picked without conflicts. Rust 1.100.0, all features, built from one checkout path and one
target directory (/dev/shm/noise, /mnt/development/.noise-target); executables in image-sha256.txt.

function-comparison.txt: fncmp2.py compares every .text function body after normalizing addresses,
::h hash suffixes, .llvm. suffixes, anon.<hash> names and RIP-relative operands, resolving each
call target to the callee's body hash (so identically folded functions with different names match),
with five rounds of callee propagation. "unmatched" counts bodies without an identical counterpart.

callgrind-counts.txt: hosted run 45085562195 (noise-ir.yml, valgrind 3.26.0). Columns: binary,
criterion filter, revision, repetition, collected Ir with the case, collected Ir with a filter
matching no case, and their difference (one benchmark iteration). Collection is toggled on the
benchmark routine function only. Both repetitions agree exactly.

bench-sizes.json / example-sizes.json: file, .text and address-deduplicated named FUNC symbol union
(sizes.py). Executables and build caches were deleted after measurement.
