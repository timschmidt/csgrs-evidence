import re,subprocess,sys,hashlib
norm=lambda s: re.sub(r'anon\.[0-9a-f]{32}\.\d+','anon',re.sub(r'::h[0-9a-f]{16}','',re.sub(r'\.llvm\.\d+','',s)))
def load(path):
    out=subprocess.run(['objdump','-d','--no-show-raw-insn','-C','-M','intel','--section=.text',path],capture_output=True,text=True,check=True).stdout
    fns=[];cur=None
    for line in out.splitlines():
        m=re.match(r'^([0-9a-f]+) <(.*)>:$',line)
        if m: cur={'addr':int(m[1],16),'name':norm(m[2]),'ins':[]}; fns.append(cur); continue
        m=re.match(r'^\s+([0-9a-f]+):\s+(.*)$',line)
        if m and cur:
            ins=re.sub(r'\s+# [0-9a-f]+ <.*$','',m[2]).rstrip()
            t=re.match(r'^(\S+)\s+([0-9a-f]+) <(.*)>$',ins)
            if t:
                tgt=int(t[2],16); off=tgt-cur['addr']
                base=norm(t[3]).split('+0x')[0]
                cur['ins'].append(('B',t[1],off) if base==cur['name'] else ('C',t[1],tgt,base))
            else:
                ins=re.sub(r'<([^>]*)>',lambda k:'<'+norm(k[1])+'>',ins); ins=re.sub(r'\[rip\+0x[0-9a-f]+\]','[rip+R]',ins)
                cur['ins'].append(('I',ins))
    byaddr={f['addr']:f for f in fns}
    h={f['addr']:'0' for f in fns}
    for _ in range(5):  # propagate callee identity a few levels
        nh={}
        for f in fns:
            parts=[]
            for x in f['ins']:
                if x[0]=='C': parts.append(x[1]+' F:'+(h[x[2]] if x[2] in byaddr else 'X'+x[3]))
                elif x[0]=='B': parts.append(x[1]+' +'+str(x[2]))
                else: parts.append(x[1])
            nh[f['addr']]=hashlib.sha256('\n'.join(parts).encode()).hexdigest()[:20]
        h=nh
    return fns,h
fa,ha=load(sys.argv[1]); fb,hb=load(sys.argv[2])
from collections import Counter,defaultdict
ca=Counter(ha.values()); cb=Counter(hb.values())
size_a={ha[f['addr']]:len(f['ins']) for f in fa}; size_b={hb[f['addr']]:len(f['ins']) for f in fb}
names_a=defaultdict(set); names_b=defaultdict(set)
for f in fa: names_a[ha[f['addr']]].add(f['name'])
for f in fb: names_b[hb[f['addr']]].add(f['name'])
only_a=ca-cb; only_b=cb-ca
print(f"bodies base={sum(ca.values())} cand={sum(cb.values())} unmatched_base={sum(only_a.values())} unmatched_cand={sum(only_b.values())} insns_unmatched_base={sum(size_a[k]*v for k,v in only_a.items())} insns_unmatched_cand={sum(size_b[k]*v for k,v in only_b.items())}")
for tag,only,size,names in (('base',only_a,size_a,names_a),('cand',only_b,size_b,names_b)):
    for k,v in sorted(only.items(),key=lambda kv:-size[kv[0]])[:int(sys.argv[3]) if len(sys.argv)>3 else 10]:
        print(f"  {tag} x{v} {size[k]:6d} {sorted(names[k])[0][:140]}")
