run() {
  local name="$1"
  shift
  printf '%-30s ' "${name}"
  (cd "${run_dir}" && "$@" > "${run_dir}/${name}.log" 2>&1) || {
    echo "FAILED"
    cat "${run_dir}/${name}.log"
    exit 1
  }
  echo "ok"
}
run_example() {
  local owner="$1" example="$2"
  shift 2
  local manifest="${work}/packages/${owner}-${version[${owner}]}/Cargo.toml"
  run "${owner}-${example}" env CARGO_TARGET_DIR="${work}/example-target" \
    "${cargo_command[@]}" run --manifest-path "${manifest}" "${patches[@]}" --example "${example}" "$@"
}
