from pathlib import Path
import os,tarfile,tomllib,json,subprocess,re,sys
s=Path(os.environ['w']);root=s/'preflight';d=root/'sources';d.mkdir(parents=True)
pack={}
for p in (s/'repack-1.95.0/package').glob('*.crate'):
 with tarfile.open(p) as t:t.extractall(d,filter='data')
 path=d/p.name[:-6]; pkg=tomllib.loads((path/'Cargo.toml').read_text())['package'];pack[pkg['name']]=(pkg['version'],path)
p=root/'client';p.mkdir();(p/'src').mkdir();(p/'src/main.rs').write_text('fn main(){}')
script=Path('scripts/release-check.sh').read_text()
feature=dict(re.findall(r'\[(\S+?)\]="([^"]+)"',re.search(r'declare -A quickstart_features=\((.*?)\n\)',script,re.S)[1]))
manifest='[package]\nname="release-consumer"\nversion="0.0.0"\nedition="2024"\n[dependencies]\n'
for n,(v,path) in sorted(pack.items()):
 manifest+=f'{n}={{version="={v}",features={json.dumps([feature[n]] if n in feature else [])}}}\n'
manifest+='[patch.crates-io]\n'+''.join(f'{n}={{path={json.dumps(str(path))}}}\n' for n,(_,path) in sorted(pack.items()))+'[workspace]\n'
(p/'Cargo.toml').write_text(manifest)
env=os.environ|{'CARGO_NET_OFFLINE':'true'}
subprocess.run(['cargo','+1.95.0','generate-lockfile','--offline'],cwd=p,check=True,env=env)
cmd=['cargo','+1.95.0','metadata','--locked','--format-version','1']
result=subprocess.run(cmd,cwd=p,env=env,stdout=subprocess.DEVNULL)
if result.returncode:
 subprocess.run(['cargo','+1.95.0','fetch','--locked'],cwd=p,env=os.environ|{'CARGO_NET_OFFLINE':'false'},check=True)
 subprocess.run(cmd,cwd=p,env=env,stdout=subprocess.DEVNULL,check=True)
print('All locked consumer metadata available in the work cache')
