
## Phase 14, worked interval examples from the release archives

At `ce6cf85f5`, the Hyperinterval README's Q30 command worked in a
checkout. Cargo reported a missing `fixed_bounds` target when the same
command used the release archive. The published manifest contained only
`proposal_replay` and `real_to_dyadic`. Commit `bbf96fd7f` includes all
three example sources and makes the release check run seven worked targets
from their unpacked owning crates, using the feature flags in their documented
commands. A control that changed the squared lower bound from 2²⁸ to 2²⁷
compiled successfully and failed when the release check executed it.
[Package manifest](crates/hyperinterval/Cargo.toml) · [Release procedure](docs/RELEASE.md)

The seven executables cover eight worked topics in section 17. The proposal at
an offset of 2⁵³ collapsed to zero while exact replay retained [1/4, 3/4].
The fine dyadic grid separated √2 from 181/128. The affine image retained
2x−y = −1, the Krawczyk example checked both contraction bounds, the schedule
replay identified the failed stopping constraint, and the ODE example exercised
certified steps and a complete horizon. In the ninth topic, unchanged Alumina
Firmware `56c2c28` consumed the packaged fixed-only library. Its calibration
example checked the two ADC intervals and the invalid count. The Cortex-M4F
library check passed on Rust 1.88. Board execution and timing remain open.
[Example expectations](#section-17-worked-interval-examples)

Each Linux release run verified 21 packages and their 21 workspace
documentation configurations. All 34 named checks passed on Rust 1.95 and
1.99. The seven new executables produced identical outputs across compilers.
A separate build rendered the documentation of all five example owners from
the unpacked archives on both compilers. All resolved first-party manifests
in those ten builds came from the extracted packages. The hosted docs.rs
build remains a separate release gate.

All 21 archives were byte-identical between two clean checkouts using the
same compiler. Fourteen also matched across compiler versions. Of the seven
remaining cross-compiler differences, four had differences confined to `Cargo.lock` member
contents and three had identical member contents. Against the preceding
revision on each compiler, the Hyperinterval archive grew by 157 bytes to
92,726 bytes in the coordinated 21-package build. The added Q30 source is
705 bytes. The normalized manifest declares the `fixed` feature for its
target. The dependency versions and edges in the packaged locks stayed
the same after accounting for sibling archive checksums.

The packaged Q30 Cargo target also ran on its fixed backend's Rust 1.88
minimum. An external program using the same source and only the `fixed`
feature produced byte-identical native and bare WebAssembly images against
the preceding and retained libraries on Rust 1.88, 1.95 and 1.99. All six
image pairs executed their assertions. This distribution change consumed no
production binary or memory allowance. Both workspace formatting checks
passed and the inventory regenerated with 7,356 scan rows and 435 body
reviews. Publication and the full cross-platform and HIL matrix remain open.
