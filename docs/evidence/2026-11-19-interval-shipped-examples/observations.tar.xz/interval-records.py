from pathlib import Path
import os,sys,re,subprocess,hashlib,json
s=Path(os.environ['w'])
sys.path.insert(0,str(Path('scripts').resolve()))
import evidence_archive as archive
repo='/mnt/development/csgrs-evidence'; rev=sys.argv[1]
all_names=subprocess.check_output(['git','-C',repo,'ls-tree','--name-only',rev+':docs/evidence'],text=True).splitlines()
rx=r'2026-11-\d\d-interval-.+'
expected=[r for r in Path('docs/evidence-archive.tsv').read_text().splitlines() if re.fullmatch(rx,r.partition('\t')[0].removeprefix('docs/evidence/'))]
names={r.partition('\t')[0] for r in expected}
assert names=={'docs/evidence/'+n for n in all_names if re.fullmatch(rx,n)}
assert len(names)==len(expected)
archive.ROOTS={n:False for n in names}
rows=archive.manifest(repo,rev)
assert rows[0]==archive.HEADER and rows[1:]==sorted(expected)
print(json.dumps({'evidence_revision':rev,'records':len(expected),'files':sum(int(r.split('\t')[1]) for r in expected),'total_bytes':sum(int(r.split('\t')[2]) for r in expected),'listing_sha256':hashlib.sha256(('\n'.join(rows)+'\n').encode()).hexdigest(),'git_no_lazy_fetch':os.environ['GIT_NO_LAZY_FETCH']}))
