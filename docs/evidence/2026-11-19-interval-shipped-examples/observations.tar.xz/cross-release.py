from pathlib import Path
import tarfile,hashlib,os,json
s=Path(os.environ['w']);roots=[s/(p+'target')/'release-check/package' for p in ('','stable-')]
def members(p):
 with tarfile.open(p) as t:
  return {m.name.partition('/')[2]:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
out={}
for a in roots[0].glob('*.crate'):
 b=roots[1]/a.name
 x,y=members(a),members(b)
 out[a.name]={'identical':hashlib.sha256(a.read_bytes()).digest()==hashlib.sha256(b.read_bytes()).digest(),'different_members':sorted(n for n in x.keys()|y.keys() if x.get(n)!=y.get(n))}
assert len(out)==21
(s/'cross-compiler.json').write_text(json.dumps(out,indent=2)+'\n')
print([(k,v['different_members']) for k,v in out.items() if not v['identical']])
