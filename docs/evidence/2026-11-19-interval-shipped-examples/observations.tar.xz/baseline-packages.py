from pathlib import Path
import subprocess,os,re,tarfile,tomllib,json,hashlib
s=Path(os.environ['w']);src=s/'repack-tree'
assert subprocess.check_output(['git','rev-parse','--short=9','HEAD'],cwd=src,text=True).strip()=='ce6cf85f5'
names=re.search(r'^crates=\(\n(.*?)^\)',(src/'scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
cmd=['package','--locked','--no-verify','--config','patch.crates-io.hypervoxel.path="crates/hypervoxel"']
for n in names:cmd+=['-p',n]
def read(p):
 with tarfile.open(p) as t:
  return {str(Path(m.name).relative_to(p.name[:-6])):t.extractfile(m).read() for m in t if m.isfile()}
for tc in ['1.95.0','stable']:
 d=s/('baseline-pkgs-'+tc); env=os.environ|{'CARGO_TARGET_DIR':str(d),'CARGO_HOME':str(s/'repack-home'),'CARGO_NET_OFFLINE':'true'}
 subprocess.run(['cargo','+'+tc,*cmd],cwd=src,env=env,check=True)
 rows={}
 for p in (d/'package').glob('*.crate'):
  q=s/('repack-'+tc)/'package'/p.name
  a,b=read(p),read(q);diff=sorted(n for n in (a.keys()|b.keys()) if a.get(n)!=b.get(n))
  allow={'.cargo_vcs_info.json','Cargo.lock'}
  if p.name.startswith('hyperinterval-'):
   allow|={'examples/fixed_bounds.rs','Cargo.toml','Cargo.toml.orig'}
   assert 'examples/fixed_bounds.rs' in diff
  assert not set(diff)-allow,(p,diff)
  assert a.keys()<=b.keys()
  if 'Cargo.lock' in diff:
   locks=[tomllib.loads(data['Cargo.lock'].decode()) for data in (a,b)]
   for l,package_dir in zip(locks,(p.parent,q.parent),strict=True):
    for dep in l['package']:
     if dep['name'] in names and 'checksum' in dep:
      ref=package_dir/(dep['name']+'-'+dep['version']+'.crate')
      if ref.exists():assert dep.pop('checksum')==hashlib.sha256(ref.read_bytes()).hexdigest()
   assert locks[0]==locks[1],p
  rows[p.name]={'before_bytes':p.stat().st_size,'after_bytes':q.stat().st_size,'different_members':diff}
 (s/('baseline-delta-'+tc+'.json')).write_text(json.dumps(rows,indent=1)+'\n')
 print(tc,len(rows),rows['hyperinterval-0.1.0.crate'],flush=True)
