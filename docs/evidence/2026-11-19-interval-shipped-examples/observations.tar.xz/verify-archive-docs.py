import json,os,subprocess,sys,tomllib,hashlib
from pathlib import Path
s=Path(os.environ['w']);source=s/'preflight/sources'
pkgs={tomllib.loads(p.read_text())['package']['name']:p.parent for p in source.glob('*/Cargo.toml')}
owners=['hyperinterval','hyperlattice-interval','hypersolve','hyperpath','hyperdynamics']
option=[]
for n,p in sorted(pkgs.items()):option+=['--config',f'patch.crates-io.{n}.path={json.dumps(str(p))}']
script=Path('scripts/release-docs.py').resolve()
env=os.environ|{'CARGO_TARGET_DIR':str(s/'archive-docs'),'CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'4'}
tc=sys.argv[1];reports={}
for name in owners:
 p=pkgs[name]
 # Each archive has a lockfile from packaging. Resolve the local copies of
 # the prerelease dependencies, then require the resulting lock for rustdoc.
 meta=json.loads(subprocess.check_output(['cargo','+'+tc,'metadata','--format-version','1','--all-features',*option],cwd=p,env=env))
 ids={r['id'] for r in meta['resolve']['nodes']}
 for pkg in meta['packages']:
  if pkg['id'] in ids and (pkg['source'] is None or pkg['name'] in pkgs):
   assert Path(pkg['manifest_path']).resolve().is_relative_to(source)
 out=subprocess.check_output(['python3',script,'--toolchain=+'+tc,'--target-dir',env['CARGO_TARGET_DIR'],*option,name],cwd=p,env=env,text=True)
 print(out,flush=True)
 page=s/'archive-docs/doc'/name.replace('-','_')/'index.html'
 assert page.stat().st_size>100 and 'local documentation configurations passed: 1' in out
 reports[name]={'index_bytes':page.stat().st_size,'index_sha256':hashlib.sha256(page.read_bytes()).hexdigest(),'resolved_packages':len(ids),'local_sources':sorted(pkg['name'] for pkg in meta['packages'] if pkg['id'] in ids and pkg['source'] is None)}
(s/('archive-docs-'+tc+'.json')).write_text(json.dumps(reports,indent=2)+'\n')
