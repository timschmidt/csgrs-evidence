from pathlib import Path
import hashlib,json,os,re,shutil,sys,time
s=Path(os.environ['w'])
tag=sys.argv[1]
log=s/'logs'/('release-'+tag)
# Observe the actual successful executions while the driver's cleanup trap
# still owns the temporary consumer and its manifests.
examples={'hyperinterval':['fixed_bounds','proposal_replay','real_to_dyadic'],'hyperlattice-interval':['affine_image'],'hypersolve':['krawczyk_certificate'],'hyperpath':['certified_schedule'],'hyperdynamics':['expression_field']}
rows={}; names={c+'-'+ex for c,exs in examples.items() for ex in exs}
out=s/'receipts'/tag;out.mkdir(exist_ok=True,parents=True)
for _ in range(3600):
 body=log.read_text() if log.is_file() else ''
 for tmp in (s/('tmp-stable' if tag=='stable' else 'tmp')).glob('csgrs-release-check.*'):
  for owner,exs in examples.items():
   for ex in exs:
    name=owner+'-'+ex
    if name in rows or not re.search(r'^'+name+r'\s+ok$',body,re.M):continue
    source,=tmp.glob(f'packages/{owner}-[0-9]*/examples/{ex}.rs')
    exe=tmp/'example-target/debug/examples'/ex
    observed=tmp/'run'/(name+'.log')
    if not observed.exists() or not exe.is_file():continue
    transcript=observed.read_text(); assert 'Running ' in transcript and str(exe) in transcript
    rows[name]={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'image_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'file_bytes':exe.stat().st_size,'transcript':transcript}
    (out/'examples.json').write_text(json.dumps(rows,indent=2)+'\n')
  if names==rows.keys():print('verified all seven',tag,flush=True);sys.exit(0)
 if 'release check passed' in body:break
 time.sleep(1)
sys.exit(f'Missing observations for {names-rows.keys()}')
