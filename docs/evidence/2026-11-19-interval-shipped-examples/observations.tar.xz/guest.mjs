import fs from "node:fs";
const module = await WebAssembly.compile(fs.readFileSync(process.argv[2]));
const imports = WebAssembly.Module.imports(module);
if (imports.length) throw new Error(JSON.stringify(imports));
const { exports } = await WebAssembly.instantiate(module, {});
if (exports.main(0, 0) !== 0) throw new Error("packaged Q30 assertions failed");
console.log("The packaged Q30 executable passed on bare WebAssembly.");
