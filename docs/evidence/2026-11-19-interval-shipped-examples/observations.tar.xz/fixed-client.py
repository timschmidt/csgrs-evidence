from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
s=Path(os.environ['w']);client=s/'fixed-client'; manifest=client/'Cargo.toml'
client.mkdir(); (client/'src').mkdir()
manifest.write_text((s/'msrv-consumer/Cargo.toml').read_text().replace('../msrv-packages','../fixed-owner'))
shutil.copyfile(s/'msrv-consumer/src/main.rs', client/'src/main.rs')
out={}
for phase,source in [('before','target'),('after','msrv-package')]:
 root=s/'fixed-owner'
 if root.exists():shutil.rmtree(root)
 root.mkdir()
 for crate in ['hyperinterval-0.1.0','hyperreal-0.14.0']:
  with tarfile.open(s/source/'package'/(crate+'.crate')) as t:t.extractall(root,filter='data')
 for tc in ['1.88.0','1.95.0','stable']:
  for arch in ['native','wasm32-unknown-unknown']:
   target=s/('fixed-build-'+tc);env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_NET_OFFLINE':'true'}
   cmd=['cargo','+'+tc,'build','--release']+(['--target',arch] if arch!='native' else [])
   subprocess.run(cmd,cwd=client,env=env,check=True)
   exe=target/('release/shipped-q30' if arch=='native' else 'wasm32-unknown-unknown/release/shipped-q30.wasm')
   subprocess.run([exe] if arch=='native' else ['node',s/'guest.mjs',exe],check=True)
   key=tc+' '+arch
   row={'bytes':exe.stat().st_size,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
   out.setdefault(key,{})[phase]=row
  # Fresh compilation at identical paths, independent of archive timestamps.
  shutil.rmtree(target)
(s/'fixed-images.json').write_text(json.dumps(out,indent=2)+'\n')
assert all(d['before']==d['after'] for d in out.values()),out
print('All six existing external client images reproduced byte for byte.')
