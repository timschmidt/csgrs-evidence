set -eu
source "$1/env"
export CARGO_NET_OFFLINE=true GMP_MPFR_SYS_CACHE="$w/gmp-control"
work="$w/control"
run_dir="$work/run"
cargo_command=(cargo +1.95.0)
declare -A version=([hyperinterval]=0.1.0 [hyperreal]=0.14.0)
patches=(--config "patch.crates-io.hyperreal.path=\"$work/packages/hyperreal-0.14.0\"")
source "$w/example-functions.sh"
run_example hyperinterval fixed_bounds --features fixed
