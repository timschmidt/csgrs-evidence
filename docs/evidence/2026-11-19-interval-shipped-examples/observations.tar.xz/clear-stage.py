from pathlib import Path
import os,re,shutil,time,json,sys,hashlib
s=Path(os.environ['w']).resolve();tag=sys.argv[1]
assert s.parent==Path('/mnt/development') and s.name.startswith('interval-shipped-examples.')
target=s/('stable-target' if tag=='stable' else 'target')/'release-check'
log=s/'logs'/('release-'+tag)
names=re.search(r'^crates=\(\n(.*?)^\)',Path('scripts/release-check.sh').read_text(),re.S|re.M)[1].split()
for _ in range(3600):
 body=log.read_text()
 if '== building the consumer against packaged sources' in body:break
 if 'release check passed' in body:raise Exception('missing build phase')
 time.sleep(2)
else:sys.exit('did not reach consumer build')
assert 'local documentation configurations passed: 21' in body
rows={}
for name in names:
 html=target/'doc'/name.replace('-','_')/'index.html'
 rows[name]={'html_bytes':html.stat().st_size,'sha256':hashlib.sha256(html.read_bytes()).hexdigest()}
assert len(rows)==21
(s/'receipts'/tag/'docs.json').write_text(json.dumps(rows,indent=2)+'\n')
for p in ['doc','debug']:
 path=target/p
 assert path.is_dir() and not path.is_symlink()
 shutil.rmtree(path)
print('Verified 21 rendered documentation roots and cleared finished build products.',flush=True)
