import os,io,hashlib,json,lzma,tarfile
from pathlib import Path
s=Path(os.environ['w']); root=Path('/mnt/development/csgrs-evidence/docs/evidence/2026-11-19-interval-shipped-examples')
root.mkdir()
selected={}
for pattern in ['*.py','*.sh','*.mjs','*.md','*.toml','*.json','env','revision','firmware-rev','preexisting-evidence-revision','logs/*','receipts/*.json','receipts/*/*.json']:
 for p in s.glob(pattern):
  if p.name in ('prior-full-index',) or not p.is_file():continue
  assert not p.is_symlink()
  selected[str(p.relative_to(s))]=p
assert all(selected[f'logs/release-{tc}'].read_text().rstrip().endswith('release check passed') for tc in ['stable','1.95.0'])
assert 'release-summary.json' in selected
digests={}
with tarfile.open(root/'observations.tar.xz','w:xz',preset=6) as t:
 for name,p in sorted(selected.items()):
  data=p.read_bytes()
  assert len(data)<2**21
  digests[name]=hashlib.sha256(data).hexdigest()
  ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;t.addfile(ti,io.BytesIO(data))
(root/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(digests,sort_keys=True,indent=1)+'\n').encode()))
print(len(selected),'members,',sum(p.stat().st_size for p in root.iterdir()),'bytes archived.')
