from pathlib import Path
import os,hashlib,tarfile,json,tomllib
s=Path(os.environ['w'])
paths=[s/'target/package/hyperinterval-0.1.0.crate',s/'msrv-package/package/hyperinterval-0.1.0.crate']
def scan(p):
 with tarfile.open(p) as t:
  data={str(Path(m.name).relative_to('hyperinterval-0.1.0')):t.extractfile(m).read() for m in t if m.isfile()}
 return data
a,b=map(scan,paths)
assert 'examples/fixed_bounds.rs' not in a and b['examples/fixed_bounds.rs']==Path('crates/hyperinterval/examples/fixed_bounds.rs').read_bytes()
changed=sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])
new=sorted(b.keys()-a.keys()); lost=sorted(a.keys()-b.keys())
assert new==['examples/fixed_bounds.rs'] and not lost
assert all(k in {'.cargo_vcs_info.json','Cargo.toml','Cargo.toml.orig','Cargo.lock'} for k in changed),changed
locks=[]
for archive,members in zip(paths,(a,b),strict=True):
 lock=tomllib.loads(members['Cargo.lock'].decode())
 dep=next(item for item in lock['package'] if item['name']=='hyperreal')
 assert dep.pop('checksum')==hashlib.sha256(archive.with_name('hyperreal-0.14.0.crate').read_bytes()).hexdigest()
 locks.append(lock)
assert locks[0]==locks[1]
ex=next(i for i in tomllib.loads(b['Cargo.toml'].decode())['example'] if i['name']=='fixed_bounds')
assert ex['required-features']==['fixed'] and ex['path']==new[0]
res={'archives':[{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],
'added':new,'removed':lost,'changed':changed,'manifest_target':ex,'added_source_bytes':len(b[new[0]])}
print(json.dumps(res,indent=2))
