import os,json,re,tarfile,hashlib,tomllib
from pathlib import Path
s=Path(os.environ['w'])
rows={}
script=Path('scripts/release-check.sh').read_text()
for (owner,example,flags) in re.findall(r'^run_example (\S+) (\S+)([^\n]*)$',script,re.M):
 archive,=list((s/'repack-1.95.0/package').glob(owner+'-[0-9]*.crate'))
 with tarfile.open(archive) as tar:
  root=archive.name.removesuffix('.crate')
  manifest=tomllib.loads(tar.extractfile(root+'/Cargo.toml').read().decode())
  target,=[ex for ex in manifest['example'] if ex['name']==example]
  features=flags.strip().removeprefix('--features ').split(',') if flags.strip() else []
  assert sorted(target.get('required-features',[]))==sorted(features)
  path=target['path']; src=tar.extractfile(root+'/'+path).read()
  assert src==Path('crates',owner,path).read_bytes()
  rows[owner+'-'+example]={'archive':archive.name,'target':example,'flags':features,'source_sha256':hashlib.sha256(src).hexdigest(),'bytes':len(src)}
assert len(rows)==7
(s/'manifest-examples.json').write_text(json.dumps(rows,indent=2)+'\n')
