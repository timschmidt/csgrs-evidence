from pathlib import Path
import hashlib,json,os,re
s=Path(os.environ['w'])
expected=json.loads((s/'manifest-examples.json').read_text())
result={}
for tc in ('1.95.0','stable'):
 log=(s/'logs'/('release-'+tc)).read_text()
 assert log.rstrip().endswith('release check passed'),tc
 rust=json.loads((s/'receipts'/(tc+'-rust-artifacts.json')).read_text())
 known=set(rust)|set(expected)|{'ffi_smoke','cpp_smoke','python_bindings','go_bindings','typescript_bindings'}
 passed=re.findall(r'^(\S+)\s+ok$',log,re.M)
 assert len(passed)==len(set(passed))==34 and set(passed)==known,(tc,set(passed)^known)
 rows=json.loads((s/'receipts'/tc/'examples.json').read_text())
 assert rows.keys()==expected.keys()
 for name,row in rows.items():
  assert row['source_sha256']==expected[name]['source_sha256'] and 0<row['file_bytes']<=48*(1<<20)
  lines=row['transcript'].splitlines()
  index=next(i for i,l in enumerate(lines) if l.lstrip().startswith('Running `'))
  row['output']=lines[index+1:]
  del row['transcript']
 assert 'resolution: 21 released crates from packages' in log
 docs=json.loads((s/'receipts'/tc/'docs.json').read_text())
 assert len(docs)==21
 result[tc]={'passed':passed,'workspace_docs':len(docs),'additional_examples':rows}
for name in expected:
 a,b=[result[tc]['additional_examples'][name]['output'] for tc in ('1.95.0','stable')]
 assert a==b,(name,a,b)
print(json.dumps(result,indent=2))
