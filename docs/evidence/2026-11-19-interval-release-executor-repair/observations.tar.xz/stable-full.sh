set -eu
source /mnt/development/interval-release-lock.XbAvXQ/env
export PATH="$s/rel-tools/bin:$s/rel-tools/go/bin:$s/rel-tools/node/bin:$PATH" GOCACHE="$s/rel-tools/go-cache-stable" GOPATH="$s/rel-tools/go-path-stable" GOTMPDIR="$s/tmp" GOTOOLCHAIN=local
export CARGO_TARGET_DIR="$s/full-stable" CARGO_BUILD_JOBS=12
scripts/release-check.sh --toolchain stable > "$s/full-stable.log" 2>&1
