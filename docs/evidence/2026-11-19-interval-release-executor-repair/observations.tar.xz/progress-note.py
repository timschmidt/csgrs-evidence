from pathlib import Path
import os,json
s=Path(os.environ['s']);r=s.parent/'csgrs'
def get(n):return json.loads((s/(n+'.json')).read_text())
e=get('receipt');o=get('owner-results');size=get('signed-size-accounts')
def step(n):return size[n]['metrics']['file']['signed_step']
native={n:step(n+'_x86_64-unknown-linux-gnu') for n in ['hypercurve','hypermesh','hypertri']}
note=f"""
## Phase 14 — repair the released Bevy executor dependency

Cargo reproduced the yanked `async-executor` 1.14.0 warning on `eed465b87`
when packaging csgrs 0.23.0. Commit `311f3cca2` updates the workspace,
the three standalone GUI lockfiles and the OpenSCAD corpus worker to
1.14.1. The dependency and checksum are the only two changed fields in
each lock. Of the 21 coordinated packages, only csgrs includes this
executor, through the optional Bevy feature. Hypervoxel's independent
lock already used an unyanked version.
[Upstream repair](https://github.com/smol-rs/async-executor/releases/tag/v1.14.1)

The full release driver passed on Rust 1.95.0 and 1.99.0. Each toolchain
verified 21 packages, rendered 21 local documentation configurations and
passed all 27 packaged consumer checks. Across the archived dependency
graphs the only version change was the executor. Every changed sibling
checksum matched its rebuilt archive. A separate clean checkout reproduced
all 21 final archives byte-for-byte on each compiler, offline. The standalone UIs passed 42
Hypercurve, 8 Hypermesh and 6 Hypertri tests, strict all-target Clippy,
and native and Wasm release links on 1.95. Per-application Wasm
predecessor and patch binaries matched byte-for-byte.

The packaged Bevy client checked cube corners, face counts, orientation
and 18 completed scoped tasks. On the two compilers its signed file
steps were {step('packaged_bevy_1.95.0'):+,} and {step('packaged_bevy_stable'):+,} bytes.
The original caps rejected both the patched client and the earlier
unaffected 1.13.3 alternative. Commit `0d37f7b88` records the revised
desktop budget. The Hypercurve, Hypermesh and Hypertri native GUI file
steps were {native['hypercurve']:+,}, {native['hypermesh']:+,} and
{native['hypertri']:+,} bytes. Each file, code section and function
union passed its individual and cumulative caps against `c9f1f9ac5`.
[Size accounts](docs/research/interval-size-accounts.json)

Across the fixed, preceding and patched builds, cold peak requested
heap was 22,736 bytes and warm peak was 13,552 bytes. A cold run retained
9,184 bytes of one-time state and the warm job returned to its starting
level. Peak calling-thread stack was 15,096 bytes on Rust 1.95 and 15,528
on Rust 1.99. The account includes separate process RSS samples.
[Memory accounts](docs/research/interval-memory-accounts.json)

The randomized paired run found median increases of 0.22–1.19 percent in
the complete short pool, mesh and task workload across two CPUs and two
compilers. Three of four per-lane bootstrap intervals were above zero.
The initial three-version run measured 0.51–0.74 percent. The release
accepts this small complete-job cost for the upstream executor lifetime
repair under the plan's higher-priority correctness rule. The repository's
separate sphere-to-Bevy conversion benchmark measured {o['before_median_ns']/1e6:.2f} ms before and
{o['candidate_median_ns']/1e6:.2f} ms after ({o['percent_difference']:+.2f}%) with identical
work, output and checksum receipts. Per-run medians overlapped. Raw samples and repeat controls are
archived. [Performance protocol](docs/INTERVAL_REFACTOR_PLAN.md#15-benchmark-and-resource-matrix)

The 26 OpenSCAD collector and protocol tests passed. The historical
SynapsCAD revision was unavailable from its public repository. Both
executor locks produced the same 29 compiler diagnostics against public
SynapsCAD `a63c4c95f` and parser `c0d92e6ea`, after matching the local
manifest layout. The worker's end-to-end execution remains open. Hosted
publication and hardware qualification also remain open.

Evidence commit `{e['commit']}` records {e['members']} verified
members in {int(e['row'].split(chr(9))[2]):,} compressed bytes. [Evidence index](docs/evidence-archive.tsv)
"""
p=r/'INTERVAL_REFACTOR_PROGRESS.md'
assert '## Phase 14 — repair the released Bevy executor dependency' not in p.read_text()
with p.open('a') as f:f.write(note)
