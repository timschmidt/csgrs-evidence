import hashlib,json,os,re,shutil,subprocess as sp
from pathlib import Path
s=Path(os.environ['s']);r=s.parent/'csgrs';w=s/'reproduce-src';source=(s/'source-revision').read_text().strip()
sp.run(['git','-C',r,'worktree','add','--detach',w,source],check=True)
try:
 assert not sp.check_output(['git','-C',w,'status','--porcelain'])
 names=re.search(r'^crates=\(\n(.*?)^\)',(w/'scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
 data={}
 for v in ['1.95.0','stable']:
  target=s/('reproduce-target-'+v)
  cmd=['cargo','+'+v,'package','--locked','--no-verify','--config','patch.crates-io.hypervoxel.path="crates/hypervoxel"']
  for n in names:cmd+=['-p',n]
  with (s/('reproduce-packages-'+v+'.log')).open('w') as log:
   sp.run(cmd,cwd=w,env=os.environ|dict(CARGO_TARGET_DIR=str(target),CARGO_NET_OFFLINE='true'),stdout=log,stderr=sp.STDOUT,check=True)
  expect=json.loads((s/f'retained-{v}.json').read_text())
  sha={p.stem:hashlib.sha256(p.read_bytes()).hexdigest() for p in (target/'package').glob('*.crate')}
  assert len(sha)==21 and sha=={k:d['archive_sha256'] for k,d in expect.items()},v
  data[v]=sha
  shutil.rmtree(target)
 (s/'clean-reproduction.json').write_text(json.dumps(data,indent=1))
finally:
 assert not sp.check_output(['git','-C',w,'status','--porcelain'])
 sp.run(['git','-C',r,'worktree','remove',w],check=True)
