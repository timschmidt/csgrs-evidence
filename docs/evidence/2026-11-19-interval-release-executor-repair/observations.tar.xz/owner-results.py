from pathlib import Path
from statistics import median
import os,json,hashlib
s=Path(os.environ['s']);samples={};receipts=set()
for i,t in enumerate(['before','candidate','candidate','before']*2):
 p=s/f'owner-bench-{i}-{t}.out'
 data=[line.split(',') for line in p.read_text().splitlines() if ',feature,adapter,bevy_mesh,' in line]
 assert len(data)==20 and all(len(z)==11 and z[0]=='csgrs' and int(z[6])==16 for z in data)
 samples[str(i)+'_'+t]=[int(z[7])/int(z[6]) for z in data]
 for z in data:receipts.add(tuple(map(int,z[8:])))
assert len(receipts)==1
result={'ns_per_conversion':samples,'receipt_work_output_checksum':list(next(iter(receipts))),'per_run_median_ns':{k:median(a) for k,a in samples.items()},'executables':{t:hashlib.sha256((s/(t+'-owner-exe')).read_bytes()).hexdigest() for t in ('before','candidate')}}
for t in ('before','candidate'):result[t+'_median_ns']=median(x for k,r in samples.items() if k.endswith(t) for x in r)
result['percent_difference']=100*(result['candidate_median_ns']/result['before_median_ns']-1)
(s/'owner-results.json').write_text(json.dumps(result,indent=1));print(result['percent_difference'],result['per_run_median_ns'])
