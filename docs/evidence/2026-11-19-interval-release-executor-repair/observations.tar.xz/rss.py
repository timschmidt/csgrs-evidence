from pathlib import Path
import json,os,subprocess as sp,statistics as st
s=Path(os.environ['s']);time=s/'time-layer/upper/time'
def measure(program):
 r=sp.run([time,'-f','%M',program],stdout=sp.DEVNULL,stderr=sp.PIPE,text=True,check=True)
 return int(r.stderr.strip())
rows={}
for v in ['1.95.0','stable']:
 order=['fixed','before','candidate','control','previous-safe']
 data={k:[] for k in order}
 for i in range(60):
  ts=order[i%5:]+order[:i%5]
  if i%2:ts.reverse()
  for tag in ts:data[tag].append(measure(s/(tag+'-exe-'+v)))
 rows[v]=data
 print(v,{k:(min(a),st.median(a),max(a)) for k,a in data.items()})
(s/'fresh-process-rss.json').write_text(json.dumps(dict(units='KiB',true_control_KiB=[measure('/bin/true') for _ in range(9)],stages=rows),indent=1))
