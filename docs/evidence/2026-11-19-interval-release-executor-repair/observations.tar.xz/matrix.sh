set -eu
source /mnt/development/interval-release-lock.XbAvXQ/env
export CARGO_NET_OFFLINE=true
cd "$s/client"
CARGO_TARGET_DIR="$s/client-1.95.0" cargo +1.95.0 build --locked --release --bin heap --bin stack > "$s/before-observers-1.95.log" 2>&1
python3 "$s/measure.py" before 1.95.0
for pair in 'candidate 1.95.0' 'before stable' 'candidate stable'; do
 read -r tag v <<< "$pair"
 python3 "$s/clients.py" "$tag" "$v"
 python3 "$s/measure.py" "$tag" "$v"
done
