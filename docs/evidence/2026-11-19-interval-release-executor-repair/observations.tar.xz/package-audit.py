from pathlib import Path
import subprocess as sp,os,hashlib,json,tomllib,sys
s=Path(os.environ['s']);root=s.parent/'csgrs';prev='eed465b8728b8a3f01c2fcfd7542189a1d15d231'
tag=sys.argv[1] if len(sys.argv)>1 else 'candidate'
index={x['vers']:x for x in map(json.loads,(s/'registry.jsonl').read_text().splitlines())}
old='1.14.0';new='1.14.1';assert index[old]['yanked'] and not index[new]['yanked']
for ver in (old,new):assert hashlib.sha256(next((s/'cargo/registry/cache').glob('*'+'/async-executor-'+ver+'.crate')).read_bytes()).hexdigest()==index[ver]['cksum']
def changed(x):return x.replace(old,new).replace(index[old]['cksum'],index[new]['cksum'])
locks={}
for n in sp.check_output(['git','-C',root,'ls-files','*Cargo.lock'],text=True).splitlines():
 p=root/n;content=p.read_text()
 data=tomllib.loads(content).get('package',[])
 if not any(x['name']=='async-executor' for x in data):continue
 before=sp.check_output(['git','-C',root,'show',prev+':'+n],text=True);versions=[z['version'] for z in data if z['name']=='async-executor']
 if new in versions:
  start=before.index('name = "async-executor"');end=before.index('dependencies',start)
  assert before[:start]+changed(before[start:end])+before[end:]==content
 else:assert before==content and all(not index[v]['yanked'] for v in versions)
 locks[n]=versions
assert list(locks.values()).count([new])==5
lanes={}
for v in ['1.95.0','stable']:
 a,b=[json.loads((s/(t+'-'+v+'.json')).read_text()) for t in ['before',tag]]
 assert a.keys()==b.keys() and len(b)==21
 altered=[];rows={}
 for n in sorted(a):
  x,y=a[n],b[n];xl,yl=x['packages'],y['packages']
  assert ('async-executor@'+old) not in yl
  if 'async-executor@'+new in yl:
   altered.append(n);assert xl.keys()-yl.keys()=={'async-executor@'+old} and yl.keys()-xl.keys()=={'async-executor@'+new}
   ox=dict(xl['async-executor@'+old]);oy=dict(yl['async-executor@'+new])
   for z in (ox,oy):z.pop('version');z.pop('checksum')
   assert ox==oy
  else:assert yl.keys()==xl.keys()
  deps=[]
  for dep in xl.keys()&yl.keys():
   xx,yy=xl[dep],yl[dep]
   if xx==yy:continue
   fields={f for f in xx.keys()|yy.keys() if xx.get(f)!=yy.get(f)}
   assert fields=={'checksum'},(n,dep,fields)
   ident=yy['name']+'-'+yy['version']
   assert xx['checksum']==a[ident]['archive_sha256'] and yy['checksum']==b[ident]['archive_sha256'];deps.append(ident)
  members=sorted(k for k in x['members'].keys()|y['members'].keys() if x['members'].get(k)!=y['members'].get(k));assert set(members)<={'Cargo.lock','.cargo_vcs_info.json'}
  rows[n]={'before':x['archive_sha256'],'after':y['archive_sha256'],'changed_members':members,'recomputed_dependency_checksums':sorted(deps)}
 assert altered==['csgrs-0.23.0']
 log=(s/(tag+'-packages-'+v+'.log')).read_text();assert 'async-executor v1.14.0' not in log and 'is yanked' not in log
 lanes[v]=rows
(s/(tag+'-package-audit.json')).write_text(json.dumps({'locks':locks,'targets':lanes},indent=1))
print('five updated locks, six inspected, 21 archive closures per compiler and only the expected dependency change')
