from pathlib import Path
from statistics import median
import json, os, random, subprocess as sp
from math import exp,log
s=Path(os.environ['s'])
cores=[19,22]
out={}
for v in ('1.95.0','stable'):
 for core in cores:
  gen=random.Random(195 if v=='stable' else 199)
  orders=['ABBA','BAAB','AAAA']*12
  gen.shuffle(orders)
  rows=[]
  for order in orders:
   times=[]
   for label in order:
    tag={'A':'control','B':'candidate'}[label]
    t=int(sp.check_output(['taskset','-c',str(core),s/f'cost-bin-{tag}-{v}','256']))
    times.append(t/256)
   # Symmetric adjacent-pair contrasts limit the effect of CPU frequency drift.
   ratio=(log(times[1])+log(times[2])-log(times[0])-log(times[3]))/2
   if order=='BAAB':ratio=-ratio
   rows.append({'order':order,'ns':times,'paired_log_ratio':ratio})
  def summary(values):
   values=sorted(values);n=len(values)
   # Percentile interval of a resampled median, using whole blocks as observations.
   boots=sorted(median(gen.choices(values,k=n)) for _ in range(10000))
   return [round(100*(exp(x)-1),3) for x in [median(values),boots[250],boots[9749]]]
  results={k:summary([r['paired_log_ratio'] for r in rows if (r['order']=='AAAA')==ctl]) for k,ctl in [('patch',False),('repeat_control',True)]}
  out[v+'-'+str(core)]={'samples':rows,'percent_median_lower_upper':results}
  print(v,core,results,flush=True)
(s/'confirmation.json').write_text(json.dumps(out))
