from pathlib import Path
import hashlib,re,os,subprocess as sp,json,sys,shutil
s=Path(os.environ['s']);work=s/'csgrs'
def fields(p):
 import io
 def num(f):
  n=0;k=0
  while True:
   x=f.read(1)[0];n|=(x&127)<<k
   if x<128:return n
   k+=7
 raw=p.read_bytes();r={'file':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if p.suffix=='.wasm':
  f=io.BytesIO(raw);assert f.read(8)==b'\0asm\x01\0\0\0'
  while t:=f.read(1):
   length=num(f);end=f.tell()+length
   if t==b'\x0a':
    n=num(f);total=0
    for _ in range(n):
     k=num(f);total+=k;f.seek(k,1)
    assert f.tell()==end;r.update(code=length,functions=total)
   f.seek(end)
 else:
  sizes=sp.check_output(['size','-A',p],text=True)
  r['code']=int(re.search(r'^\.text\s+(\d+)',sizes,re.M)[1]);spans=[]
  for ln in sp.check_output(['nm','-S','--radix=d','--defined-only',p],text=True).splitlines():
   w=ln.split(maxsplit=3)
   if len(w)==4 and w[2] in ('t','T'):spans.append((int(w[0]),int(w[0])+int(w[1])))
  total=hi=0
  for a,b in sorted(spans):total+=max(0,b-max(hi,a));hi=max(hi,b)
  r['functions']=total
 return r
v='1.95.0'
# Replay the identical source, manifest, compiler, cache path and worktree for each lock.
# Native and Wasm shipped applications are measured without attaching a display.
for n in ['hypertri','hypermesh','hypercurve']:
 rel=Path('crates')/n/'examples'/(n+'_ui')
 pkg=work/rel;lock=pkg/'Cargo.lock';original=lock.read_bytes()
 try:
  for stage,ref in [('before',s/'before'),('candidate',s.parent/'csgrs')]:
   lock.write_bytes((ref/rel/'Cargo.lock').read_bytes())
   for arch in ['x86_64-unknown-linux-gnu','wasm32-unknown-unknown']:
    out=s/f'{stage}-desktop-{n}-{arch}'
    cmd=['cargo','+'+v,'build','--locked','--release','--target',arch,'--message-format=json-render-diagnostics']
    env=os.environ|dict(CARGO_TARGET_DIR=str(s/'ui-release'),CARGO_BUILD_JOBS='6')
    with out.with_suffix('.log').open('w') as log:data=sp.check_output(cmd,env=env,cwd=pkg,stderr=log,text=True)
    exes=[Path(j['executable']) for j in map(json.loads,data.splitlines()) if j.get('executable')]
    assert len(exes)==1,(n,arch,exes)
    out.with_suffix('.json').write_text(json.dumps(fields(exes[0])))
 finally:lock.write_bytes(original)
