import json, os, shutil, subprocess as sp
from pathlib import Path
s=Path(os.environ['s']);w=s/'before';lock=w/'Cargo.lock';original=lock.read_bytes();target=s/'owner-target'
def cmd(*a,**kw):return sp.check_output(a,cwd=w,**kw)
assert not cmd('git','status','--porcelain')
try:
 for tag in ('before','candidate'):
  if tag=='candidate':lock.write_bytes((s.parent/'csgrs/Cargo.lock').read_bytes())
  with (s/f'{tag}-owner-bench-build.log').open('w') as f:
   data=cmd('cargo','+1.95.0','bench','--locked','--bench','feature_pipeline','--features','bench-feature-pipeline','--no-run','--message-format=json-render-diagnostics',env=os.environ|dict(CARGO_BUILD_JOBS='10',CARGO_TARGET_DIR=str(target)),stderr=f,text=True)
  exes=[x['executable'] for x in map(json.loads,data.splitlines()) if x.get('executable') and x['target']['name']=='feature_pipeline']
  assert len(exes)==1;shutil.copy2(exes[0],s/f'{tag}-owner-exe')
finally:lock.write_bytes(original)
assert sorted(p.name for p in s.glob('*-owner-exe'))==['before-owner-exe','candidate-owner-exe']
shutil.rmtree(target)
for i,label in enumerate(['before','candidate','candidate','before']*2):
 with (s/f'owner-bench-{i}-{label}.out').open('w') as f:
  sp.run(['taskset','-c','22',s/f'{label}-owner-exe'],cwd=w,env=os.environ|dict(CSGRS_BENCH_FILTER='feature/adapter/bevy_mesh',CSGRS_BENCH_WARMUP='8',CSGRS_BENCH_SAMPLES='20',CSGRS_BENCH_SCALE='4'),stdout=f,stderr=sp.STDOUT,check=True)
