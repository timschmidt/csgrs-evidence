from pathlib import Path
import json,os,shutil,subprocess,time
s=Path(os.environ['s']);log=s/'space-observations.jsonl'
a=shutil.disk_usage(s);run=subprocess.run(['du','-sx','--block-size=1',s],capture_output=True,text=True)
with log.open('a') as f:f.write(json.dumps(dict(time_unix=time.time(),workspace_free_bytes=a.free,scratch_bytes=int(run.stdout.split()[0])))+'\n')
