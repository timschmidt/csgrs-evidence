from pathlib import Path
import os,sys,shutil,subprocess as sp
s=Path(os.environ['s']);c=s/'client'
for v in ['1.95.0','stable']:
 for tag in ['control','candidate','previous-safe']:
  shutil.copy2(s/(tag+'-client-'+v+'.lock'),c/'Cargo.lock')
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('client-'+v))}
  with (s/('cost-build-'+tag+'-'+v+'.log')).open('w') as log:sp.run(['cargo','+'+v,'build','--locked','--release','--bin','cost'],cwd=c,env=env,stderr=log,check=True)
  shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release/cost',s/('cost-bin-'+tag+'-'+v))
