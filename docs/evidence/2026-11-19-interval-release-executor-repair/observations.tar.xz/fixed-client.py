from pathlib import Path
import os,sys,shutil
s=Path(os.environ['s']);v=sys.argv[2];old=s/('client-'+v)
assert old.parent==s and (s/('previous-safe-size-'+v+'.json')).exists() and (s/('cost-bin-candidate-'+v)).is_file()
shutil.rmtree(old);shutil.rmtree(s/'unpacked')
p=(s/'clients.py').read_text().replace("expected='1.14.0' if stage=='before' else '1.14.1'","expected='1.14.0'")
exec(compile(p,str(s/'clients.py'),'exec'))
