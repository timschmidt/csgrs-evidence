set -eu
source /mnt/development/interval-release-lock.XbAvXQ/env
export CARGO_BUILD_JOBS=6 CARGO_TARGET_DIR="$s/ui"
for n in hypercurve hypermesh hypertri; do
 p=crates/$n/examples/${n}_ui/Cargo.toml
 for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown; do
  cargo +1.95.0 tree --locked --manifest-path "$p" --target "$target" -e normal -i async-executor > "$s/tree-$n-$target.log" 2>&1
 done
 cargo +1.95.0 test --locked --manifest-path "$p" > "$s/test-$n.log" 2>&1
 cargo +1.95.0 clippy --locked --manifest-path "$p" --all-targets -- -D warnings > "$s/clippy-$n.log" 2>&1
 cargo +1.95.0 build --locked --manifest-path "$p" --release --target wasm32-unknown-unknown > "$s/wasm-$n.log" 2>&1
done
