#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef int (*main_fn)(int,char**,char**);
static void *main_addr;
static int (*replay)(unsigned,unsigned);
static unsigned k,limit;
static void check(void *x){ int result=replay(k,limit); if(result!=1 && result!=2) abort(); }
extern size_t measure_stack(void (*)(void *),void *,int,unsigned char);
static int measured(int argc,char **argv,char **envp) {
 Dl_info file;if(!dladdr(main_addr,&file))abort();
 replay=(void*)((uintptr_t)file.dli_fbase+strtoul(argv[1],NULL,16));
 k=atoi(argv[2]);limit=atoi(argv[3]);
 for(int warm=0;warm<2;warm++)for(int i=0;i<2;i++)printf("%zu ",measure_stack(check,NULL,warm,i?0xa5:0x5a));
 return 0;
}
int __libc_start_main(main_fn f,int argc,char **argv,void *init,void *fini,void *rt,void *end) {
 main_addr=(void*)f;
 __typeof__(&__libc_start_main) start=dlsym(RTLD_NEXT,"__libc_start_main");
 return start(measured,argc,argv,init,fini,rt,end);
}
