use bevy_mesh::{Mesh, PrimitiveTopology};
use bevy_tasks::TaskPoolBuilder;
use csgrs::solid;

fn main() {
    let pool = TaskPoolBuilder::new().num_threads(1).build();
    for width in [1i32, 2, 4] {
        let cube = solid::cube(width).unwrap();
        let mesh = solid::to_bevy_mesh(&cube);
        assert_eq!(mesh.primitive_topology(), PrimitiveTopology::TriangleList);
        let positions = mesh.attribute(Mesh::ATTRIBUTE_POSITION).unwrap().as_float3().unwrap();
        let normals = mesh.attribute(Mesh::ATTRIBUTE_NORMAL).unwrap().as_float3().unwrap();
        assert_eq!(positions.len(), normals.len());
        let indices: Vec<_> = mesh.indices().unwrap().iter().collect();
        assert_eq!(indices.len(), 36);
        let mut corners = [false; 8];
        let mut faces = [0; 6];
        for tri in indices.chunks_exact(3) {
            let a = positions[tri[0]];
            let b = positions[tri[1]];
            let c = positions[tri[2]];
            let axes: Vec<_> = (0..3).filter(|&i| a[i] == b[i] && a[i] == c[i]).collect();
            assert_eq!(axes.len(), 1);
            let axis = axes[0];
            let side = usize::from(a[axis] > 0.);
            faces[2 * axis + side] += 1;
            let i = (axis+1)%3;
            let j = (axis+2)%3;
            let area = (b[i]-a[i])*(c[j]-a[j]) - (b[j]-a[j])*(c[i]-a[i]);
            let sign = if side == 1 {1.0} else {-1.0};
            assert_eq!(area, sign * (width*width) as f32);
            for &idx in tri {
                let p = positions[idx];
                assert!(p.iter().all(|&x| x == 0. || x == width as f32));
                corners[(p[0]>0.) as usize + 2*(p[1]>0.) as usize + 4*(p[2]>0.) as usize] = true;
                let normal=normals[idx];
                assert!(normal.iter().all(|x| x.is_finite()));
            }
        }
        assert_eq!(corners,[true;8]);assert_eq!(faces,[2;6]);
        let mut results = pool.scope(|scope| {
            for (i, count) in faces.iter().enumerate() {
                scope.spawn(async move {(i,*count*width*width)});
            }
        });
        results.sort_unstable();
        assert_eq!(results, (0..6).map(|i|(i,2*width*width)).collect::<Vec<_>>());
        println!("{width} {faces:?} {results:?}");
    }
}
