from pathlib import Path
import os,sys,re,subprocess as sp,json
s=Path(os.environ['s']);tag,v=sys.argv[1:]
b=s/('client-'+v)/'release';stack=b/'stack';heap=b/'heap'
off=re.search(r'^(\w+) T replay$',sp.check_output(['nm','-an',stack],text=True),re.M)[1]
raw=sp.check_output([stack,off,'0','1024'],env=os.environ|{'LD_PRELOAD':str(s/'stack.so')},text=True);hits=list(map(int,raw.splitlines()[-1].split()));assert len(hits)==4
hs=sp.check_output([heap],text=True);rows=[list(map(int,re.findall(r'\d+',l))) for l in hs.splitlines() if l.startswith('allocations')];assert len(rows)==2
cmd=[s/(tag+'-exe-'+v)]
peak=[]
for _ in range(9):
 pid=os.posix_spawn(str(cmd[0]),list(map(str,cmd)),os.environ,file_actions=[(os.POSIX_SPAWN_OPEN,1,'/dev/null',os.O_WRONLY,0)]);_,st,usage=os.wait4(pid,0);assert st==0;peak.append(usage.ru_maxrss)
(s/(tag+'-memory-'+v+'.json')).write_text(json.dumps({'stack_bytes':hits,'heap_columns':['allocations','deallocations','reallocations','bytes','peak_live','live_after'],'heap':rows,'process_rss_KiB':peak},indent=1))
