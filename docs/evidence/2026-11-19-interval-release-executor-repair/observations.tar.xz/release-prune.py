# Discard large verified build products while the other toolchain is running.
from pathlib import Path
import json,os,shutil,sys
s=Path(os.environ['s']);suffix='-stable' if sys.argv[1:]==['stable'] else ''
audit=json.loads((s/('full-audit'+suffix+'.json')).read_text())
assert len(audit['programs'])==27 and len(audit['documentation'])==21
d=s/('full'+suffix)
assert (d/'release-check/package').is_dir() and (s/'retained-stable.json').exists()
shutil.rmtree(d)
