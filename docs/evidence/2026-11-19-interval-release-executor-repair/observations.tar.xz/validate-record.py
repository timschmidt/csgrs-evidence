import json,os
from pathlib import Path
s=Path(os.environ['s'])
def get(n):return json.loads((s/(n+'.json')).read_text())
t=get('demo-tests')
assert {n:sum(v['tests']) for n,v in t.items()}=={'hypercurve':42,'hypermesh':8,'hypertri':6}
for n in t:
 assert 'Finished' in (s/f'clippy-{n}.log').read_text() and 'Finished' in (s/f'wasm-{n}.log').read_text()
 assert 'async-executor v1.14.1' in (s/f'tree-{n}-x86_64-unknown-linux-gnu.log').read_text()
 assert 'nothing to print' in (s/f'tree-{n}-wasm32-unknown-unknown.log').read_text()
a,b=[get(t+'-corpus-diagnostics') for t in ['before','candidate']]
assert a==b and len(a['errors'])==29 and a['returncode']!=0
assert 'Ran 26 tests' in (s/'corpus-protocol-qualified.log').read_text()
m=get('signed-memory-accounts')
for rows in m.values():
 for k,v in rows['workload'].items():
  assert v['increment']==v['positive_cumulative']==0
 for warm,expected in [('cold',[708,645,6,122848,22736,9184]),('warm',[615,615,6,108528,13552,0])]:
  assert [rows['workload'][warm+'_'+k]['candidate'] for k in ['allocations','deallocations','reallocations','bytes','peak_live','live_after']]==expected
assert len(get('retained-package-audit')['targets'])==2
assert len(get('full-audit')['programs'])==len(get('full-audit-stable')['programs'])==27
assert len(get('owner-results')['ns_per_conversion'])==8
assert len(get('confirmation'))==4
assert [len(r) for r in get('clean-reproduction').values()]==[21,21]
print('archive contract checks passed')
