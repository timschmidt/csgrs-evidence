from pathlib import Path
import sys,os,subprocess as sp
s=Path(os.environ['s']);p=(s/'clients.py').read_text()
p=p.replace("packages=s/(stage+'-packages-'+v)/'package'","packages=s/(('candidate' if stage=='previous-safe' else 'before')+'-packages-'+v)/'package'")
p=p.replace("tree=run('tree'","if stage=='previous-safe':run('update','-p','async-executor','--precise','1.13.3')\ntree=run('tree'")
p=p.replace("expected='1.14.0' if stage=='before' else '1.14.1'","expected='1.13.3' if stage=='previous-safe' else '1.14.0'")
exec(compile(p,str(s/'clients.py'),'exec'))
