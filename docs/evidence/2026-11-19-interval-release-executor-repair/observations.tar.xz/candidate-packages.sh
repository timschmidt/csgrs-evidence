set -eu
source /mnt/development/interval-release-lock.XbAvXQ/env
python3 "$s/packages.py" candidate 1.95.0 > "$s/candidate-packaging.out"
python3 "$s/packages.py" before stable > "$s/before-stable-packaging.out"
python3 "$s/packages.py" candidate stable > "$s/candidate-stable-packaging.out"
