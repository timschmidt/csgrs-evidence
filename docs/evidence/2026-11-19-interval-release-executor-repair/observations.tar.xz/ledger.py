from pathlib import Path
import json,os
s=Path(os.environ['s']);root=s.parent/'csgrs'
def load(k):return json.loads((s/(k+'.json')).read_text())
def add(p,k,v):
 f=root/'docs/research'/p;data=f.read_text();assert k not in json.loads(data) and data.endswith('\n}\n')
 newer=data[:-3]+',\n'+json.dumps({k:v},indent=2,ensure_ascii=False)[2:]+'\n'
 assert json.loads(newer)==json.loads(data)|{k:v}
 f.write_text(newer)
src=(s/'source-revision').read_text().strip();e=load('receipt')
base=dict(source=src,fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',preceding='eed465b8728b8a3f01c2fcfd7542189a1d15d231',evidence=e['record'],evidence_commit=e['commit'])
sz=load('signed-size-accounts');mem=load('signed-memory-accounts')
targets={}
for k,d in sz.items():
 if 'metrics' in d:
  targets[k]={'file_code_functions_signed_step':[d['metrics'][m]['signed_step'] for m in ('file','code','functions')],'file_code_functions_cumulative_charge':[d['metrics'][m]['cumulative_charge'] for m in ('file','code','functions')],'file_code_functions_cumulative_remaining':[d['metrics'][m]['remaining_cumulative'] for m in ('file','code','functions')],'free_artifact_bytes':d['free_bytes']}
 else:targets[k]={'current_file_and_code_step':0,'wasm_sha256':d['stages']['candidate']['sha256'],'signed_history':d['signed_history']}
add('interval-size-accounts.json','csgrs_bevy_executor_release_qualification',base|{'benefit':'Use the unyanked patch that repairs the upstream desktop executor lifetime.','caps':'See csgrs_bevy_executor_release_client_budget. Three Linux GUI slots each use the same step and cumulative file, text and function caps, with a 128 MiB slot and 32 MiB reserved. Wasm requires byte identity on this step.','method':'The archive records absolute totals, caps, remaining step and cumulative allowances and separate checksums for every final image. Cargo uses the executor only in the native normal dependency graphs of the three demos.','targets':targets})
add('interval-memory-accounts.json','csgrs_bevy_executor_release_qualification',base|{'workload':'Single-worker packaged Bevy client validating three cube conversions and 18 completed scoped tasks across pool creation and teardown. Whole-job requested Rust heap, calling-thread stack on a guarded 2 MiB allocation, and 60 GNU time fresh-process RSS samples per stage.','heap_cold_then_warm':[[708,645,6,122848,22736,9184],[615,615,6,108528,13552,0]],'heap_columns':['allocations','deallocations','reallocations','cumulative_bytes','peak_live_bytes','live_after_return'],'caller_stack_cold_then_warm':{k:[r['workload'][key]['candidate'] for key in ('cold_stack','warm_stack')] for k,r in mem.items()},'current_and_cumulative_charge':'Every measured requested-heap and calling-thread stack field is equal at the fixed, preceding and retained revisions on both compilers. The new charge is zero. The stack measurement covers the calling thread.','sampled_peak_process_rss_KiB_min_median_max':{k:d['peak_process_rss_KiB_min_median_max'] for k,d in mem.items()}})
