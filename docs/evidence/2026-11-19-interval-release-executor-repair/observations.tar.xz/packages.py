from pathlib import Path
import subprocess as sp,sys,os,re,hashlib,tarfile,tomllib,json
s=Path(os.environ['s']);root=s.parent/'csgrs';stage,v=sys.argv[1:]
repo=s/stage if stage in ('before','fixed') else root
names=re.search(r'^crates=\(\n(.*?)^\)',(repo/'scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
cmd=['cargo','+'+v,'package','--locked','--no-verify','--config','patch.crates-io.hypervoxel.path="crates/hypervoxel"']
if stage=='candidate':cmd.append('--allow-dirty')
if stage=='retained':assert not sp.check_output(['git','status','--porcelain'],cwd=repo) and sp.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==(s/'source-revision').read_text().strip()
for n in names:cmd+=['-p',n]
target=s/(stage+'-packages-'+v)
if stage=='retained' and v=='1.95.0':
 target=s/'full/release-check'
 assert (s/'full.log').read_text().rstrip().endswith('release check passed')
 shutil_path=s/(stage+'-packages-'+v+'.log');shutil_path.write_bytes((s/'full.log').read_bytes())
else:
 with (s/(stage+'-packages-'+v+'.log')).open('w') as log:
  sp.run(cmd,cwd=repo,env=os.environ|{'CARGO_TARGET_DIR':str(target)},check=True,stdout=log,stderr=sp.STDOUT)
rows={}
for p in sorted((target/'package').glob('*.crate')):
 with tarfile.open(p) as t:
  base=p.name[:-6]
  lock=tomllib.loads(t.extractfile(base+'/Cargo.lock').read().decode())['package']
  rows[base]={'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'packages':{x['name']+'@'+x['version']:x for x in lock},'members':{m.name[len(base)+1:]:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}}
assert len(rows)==len(names)==21
(s/(stage+'-'+v+'.json')).write_text(json.dumps(rows,separators=(',',':')))
print('packages',len(rows),'executor',[(n,[k for k in x['packages'] if k.startswith('async-executor@')]) for n,x in rows.items() if any(k.startswith('async-executor@') for k in x['packages'])])
