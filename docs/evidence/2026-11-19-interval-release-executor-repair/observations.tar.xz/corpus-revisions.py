from pathlib import Path
import os,subprocess as sp,json
s=Path(os.environ['s']);pkg=s/'csgrs/scripts/openscad-corpus';lock=pkg/'Cargo.lock';ref=Path('scripts/openscad-corpus/Cargo.lock')
orig=lock.read_bytes()
try:
 for tag,r in [('candidate',s.parent/'csgrs'),('before',s/'before')]:
  lock.write_bytes((r/ref).read_bytes());rows=[]
  env=os.environ|dict(CARGO_TARGET_DIR=str(s/'corpus-build'),CARGO_BUILD_JOBS='4',C_INCLUDE_PATH=str(s/'sysroot/usr/include'),LIBRARY_PATH=str(s/'sysroot/usr/lib/x86_64-linux-gnu'),PKG_CONFIG_PATH=str(s/'sysroot/usr/lib/x86_64-linux-gnu/pkgconfig'))
  with (s/(tag+'-corpus-build.log')).open('w') as log:
   z=sp.run(['cargo','+1.95.0','check','--locked','--message-format=json'],cwd=pkg,env=env,stderr=log,stdout=sp.PIPE,text=True)
  for d in map(json.loads,z.stdout.splitlines()):
   if d['reason']=='compiler-message' and d['message']['level']=='error':
    m=d['message'];rows.append([m.get('code'),m['message'],[[p['file_name'],p['line_start'],p['column_start']] for p in m['spans'] if p['is_primary']]])
  r={'returncode':z.returncode,'errors':rows}
  (s/(tag+'-corpus-diagnostics.json')).write_text(json.dumps(r,indent=1))
  assert rows and z.returncode!=0
finally:lock.write_bytes(orig)
assert json.loads((s/'before-corpus-diagnostics.json').read_text())==json.loads((s/'candidate-corpus-diagnostics.json').read_text())
