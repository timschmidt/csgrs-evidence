set -eu
source /mnt/development/interval-release-lock.XbAvXQ/env
export CARGO_NET_OFFLINE=true
python3 "$s/timing-bins.py"
for v in 1.95.0 stable; do
 python3 "$s/fixed-client.py" fixed "$v"
 python3 "$s/measure.py" fixed "$v"
 test -s "$s/fixed-size-$v.json"
 rm -r -- "$s/client-$v"
done
