from pathlib import Path
import os,subprocess as sp
s=Path(os.environ['s']);work=s/'csgrs';src=(s/'demo-compare.py').read_text()
def git(*a):return sp.check_output(['git','-C',work,*a])
# The candidate fixtures in this detached checkout belong to this run.
changed=git('diff','--name-only').decode().splitlines()
assert len(changed)==5 and all(n.endswith('Cargo.lock') for n in changed)
assert all((work/n).read_bytes()==(s.parent/'csgrs'/n).read_bytes() for n in changed)
git('restore','--',*changed);assert not git('status','--porcelain')
git('switch','--detach','c9f1f9ac5')
src=src.replace("[('before',s/'before'),('candidate',s.parent/'csgrs')]","[('fixed',s/'fixed')]")
exec(compile(src,str(s/'demo-compare.py'),'exec'))
