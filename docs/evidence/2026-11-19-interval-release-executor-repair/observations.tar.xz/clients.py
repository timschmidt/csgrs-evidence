from pathlib import Path
import hashlib,json,os,re,shutil,subprocess as sp,tarfile,sys
s=Path(os.environ['s']);c=s/'client';stage,v=sys.argv[1:]
packages=s/(stage+'-packages-'+v)/'package'
src=s/'unpacked';src.mkdir(exist_ok=True)
for p in sorted(packages.glob('*.crate')):
 with tarfile.open(p) as t:t.extractall(src,filter='data')
data='[package]\nname="release-executor-client"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\ncsgrs={version="=0.23.0",default-features=false,features=["bevymesh"]}\nbevy_mesh="=0.18.1"\nbevy_tasks="=0.18.1"\n[patch.crates-io]\n'
import tomllib
for p in sorted(src.glob('*/Cargo.toml')):
 name=tomllib.loads(p.read_text())['package']['name']
 data+=name+'={path='+json.dumps(str(p.parent))+'}\n'
(c/'Cargo.toml').write_text(data)
shutil.copy2(src/'csgrs-0.23.0/Cargo.lock',c/'Cargo.lock')
env=os.environ|{'CARGO_TARGET_DIR':str(s/('client-'+v)),'CARGO_BUILD_JOBS':'7'}
def run(*args,check=True):
 with (s/(stage+'-client-'+v+'.log')).open('a') as f:return sp.check_output(['cargo','+'+v,*args],cwd=c,env=env,stderr=f,text=True)
run('metadata','--format-version','1','--no-deps')
tree=run('tree','-e','normal','-i','async-executor')
expected='1.14.0' if stage=='before' else '1.14.1';assert tree.startswith('async-executor v'+expected),(tree,stage)
(s/(stage+'-client-'+v+'.tree')).write_text(tree)
shutil.copy2(c/'Cargo.lock',s/(stage+'-client-'+v+'.lock'))
run('build','--locked','--release')
built=Path(env['CARGO_TARGET_DIR'])/'release/release-executor-client'
exe=s/(stage+'-exe-'+v);shutil.copy2(built,exe)
result=sp.check_output([exe],text=True);(s/(stage+'-client-'+v+'.out')).write_text(result)
sizes={m[1]:int(m[2]) for m in re.finditer(r'^(\.\S+)\s+(\d+)\s+\d+',sp.check_output(['size','-A',exe],text=True),re.M)}
spans=[]
for ln in sp.check_output(['nm','-S','--radix=d','--defined-only',exe],text=True).splitlines():
 w=ln.split(maxsplit=3)
 if len(w)==4 and w[2] in ('t','T'):spans.append((int(w[0]),int(w[0])+int(w[1])))
hi=total=0
for a,b in sorted(spans):total+=max(0,b-max(hi,a));hi=max(b,hi)
(s/(stage+'-size-'+v+'.json')).write_text(json.dumps({'file':exe.stat().st_size,'functions':total,'sections':sizes,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}))
