from pathlib import Path
import os,shutil,sys,time
s=Path(os.environ['s']);suffix=sys.argv[1] if len(sys.argv)>1 else '';assert suffix in ('','-stable')
log=s/('full'+suffix+'.log');debug=s/('full'+suffix)/'release-check/debug'
while '== building the consumer against packaged sources' not in log.read_text():
 time.sleep(4)
assert 'local documentation configurations passed: 21' in log.read_text()
if debug.is_dir():shutil.rmtree(debug)
