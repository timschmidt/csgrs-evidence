from pathlib import Path
import json
from record import s,record
for required in ['retained-package-audit.json','signed-memory-accounts.json','signed-size-accounts.json','full-audit.json','owner-results.json','conditions.txt']:
 assert (s/required).is_file()
extensions={'.json','.jsonl','.log','.out','.tree','.lock','.py','.sh','.rs','.c','.txt','.patch'}
files={p for p in s.iterdir() if p.is_file() and (p.suffix in extensions or p.name in ('env','source-revision'))}
files.update((s/'client/src').rglob('*.rs'))
files.update([s/'client/Cargo.toml',s/'client/Cargo.lock'])
r=record('release-executor-repair',files,'Archive release executor qualification and measured resource accounts')
(s/'receipt.json').write_text(json.dumps(r));print(r)
