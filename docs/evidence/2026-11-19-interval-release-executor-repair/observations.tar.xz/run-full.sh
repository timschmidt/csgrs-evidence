set -euo pipefail
source /mnt/development/interval-release-lock.XbAvXQ/env
mkdir -p "$s/rel-tools"/{go,node,bin}
tools=/mnt/development/.interval-refactor-build/release-tools
tar --strip-components=1 -xzf "$tools/go1.27.4.linux-amd64.tar.gz" -C "$s/rel-tools/go"
tar --strip-components=1 -xJf "$tools/node-v22.23.5-linux-x64.tar.xz" -C "$s/rel-tools/node" node-v22.23.5-linux-x64/bin/node
ln -s "$HOME/.npm/_npx/f25047f5dd92c9a8/node_modules/typescript/bin/tsc" "$s/rel-tools/bin/tsc"
export PATH="$s/rel-tools/bin:$s/rel-tools/go/bin:$s/rel-tools/node/bin:$PATH" GOCACHE="$s/rel-tools/go-cache" GOPATH="$s/rel-tools/go-path" GOTMPDIR="$s/tmp" GOTOOLCHAIN=local
export CARGO_TARGET_DIR="$s/full" CARGO_BUILD_JOBS=10
scripts/release-check.sh --toolchain 1.95.0 > "$s/full.log" 2>&1
