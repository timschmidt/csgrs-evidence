from pathlib import Path
import sys,os,time,json,subprocess as sp,statistics as st
s=Path(os.environ['s'])
def cpu_stat():
 rows={}
 for line in Path('/proc/stat').read_text().splitlines():
  w=line.split()
  if w and w[0][3:].isdigit() and w[0].startswith('cpu'):
   z=list(map(int,w[1:]));rows[int(w[0][3:])]=(sum(z[:8]),z[3]+z[4])
 return rows
a=cpu_stat();time.sleep(1);b=cpu_stat();avail=os.sched_getaffinity(0)
rank=sorted(avail,key=lambda k:(b[k][1]-a[k][1])/max(1,b[k][0]-a[k][0]),reverse=True)
cpus=[];seen=set()
for k in rank:
 key=(Path(f'/sys/devices/system/cpu/cpu{k}/topology/physical_package_id').read_text().strip(),Path(f'/sys/devices/system/cpu/cpu{k}/topology/core_id').read_text().strip())
 if key in seen:continue
 seen.add(key);cpus.append(k)
 if len(cpus)==2:break
out={};n=128
for core in cpus:
 for v in ['1.95.0','stable']:
  rows={t:[] for t in ['control','candidate','previous-safe']}
  order=list(rows)
  for i in range(30):
   seq=order[i%3:]+order[:i%3]
   if i%2:seq.reverse()
   for t in seq:rows[t].append(int(sp.check_output(['taskset','-c',str(core),s/('cost-bin-'+t+'-'+v),str(n)]))/n)
  out[v+'-'+str(core)]=rows
  print(v,core,round(st.median(100*(y/x-1) for x,y in zip(rows['control'],rows['candidate'])),2),flush=True)
(s/'cost.json').write_text(json.dumps(out))
