from pathlib import Path
import hashlib, json, os,re,tarfile,sys
s=Path(os.environ['s']);suffix='-stable' if sys.argv[1:]==['stable'] else '';d=s/('full'+suffix)/'release-check';root=s.parent/'csgrs'
names=re.search(r'^crates=\(\n(.*?)^\)',(root/'scripts/release-check.sh').read_text(),re.M|re.S)[1].split()
log=(s/('full'+suffix+'.log')).read_text()
assert log.rstrip().endswith('release check passed') and 'local documentation configurations passed: 21' in log
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=['user_path']+['quickstart_'+n.replace('-','_') for n in names if n!='csgrs-ffi']+['curve_interval_ranges','ffi_smoke','cpp_smoke','python_bindings','go_bindings','typescript_bindings']
assert re.findall(r'^(\w+)\s+ok$', log[log.index('== running the user path'):],re.M)==expected and len(expected)==27
exe={n:sha(d/'consumer/debug'/n) for n in expected[:22]}
docs={n:sha(d/'doc'/n.replace('-','_')/'index.html') for n in names}
source=(s/'source-revision').read_text().strip()
if suffix:
 for p in (d/'package').glob('*.crate'):
  assert sha(p)==sha(s/'retained-packages-stable/package'/p.name)
for base in [d/'package',s/'retained-packages-stable/package']:
 archives=list(base.glob('*.crate'));assert len(archives)==21
 for p in archives:
  with tarfile.open(p) as t:
   git=json.load(t.extractfile(p.stem+'/.cargo_vcs_info.json'))['git']
   assert git=={'sha1':source},(p,git)
(s/('full-audit'+suffix+'.json')).write_text(json.dumps(dict(source=source,programs=expected,hashes=exe,documentation=docs),indent=1))
