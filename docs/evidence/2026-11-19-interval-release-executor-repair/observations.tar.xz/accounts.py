from pathlib import Path
import json, os
from statistics import median
s=Path(os.environ['s'])
def read(name):
 return json.loads((s/(name+'.json')).read_text())
def save(name,data):
 (s/(name+'.json')).write_text(json.dumps(data,indent=2)+'\n')
stages=['fixed','before','candidate']
size={};memory={}
def account(key, rows, slot):
 reserve=slot//4
 rec={'sha256':{t:r['sha256'] for t,r in zip(stages,rows)},'slot_bytes':slot,'reserve_bytes':reserve,'free_bytes':slot-rows[-1]['file'],'metrics':{}}
 assert rec['free_bytes']>=reserve
 for met in ('file','code','functions'):
  a,b,c=[r[met] for r in rows]
  prior=max(b-a,0);step=max(c-b,0);total=step+prior
  lim,pct=(65536,0.005) if met=='file' else (16384,0.0025)
  step_cap=min(lim,int(b*pct));total_cap=min(2*lim,int(a*(2*pct)))
  rec['metrics'][met]=dict(fixed=a,before=b,candidate=c,signed_step=c-b,prior_charge=prior,step_charge=step,cumulative_charge=total,step_cap=step_cap,cumulative_cap=total_cap,remaining_step=step_cap-step,remaining_cumulative=total_cap-total)
 size[key]=rec
for v in ('1.95.0','stable'):
 rows=[read(t+'-size-'+v) for t in stages]
 for row in rows:row['code']=row['sections']['.text']
 assert rows[1]['sha256']==read('control-size-'+v)['sha256']
 assert len({(s/(t+'-client-'+v+'.out')).read_bytes() for t in stages+['previous-safe','control']})==1
 account('packaged_bevy_'+v,rows,64<<20)
 mem=[read(t+'-memory-'+v) for t in stages]
 for key in ['heap_columns','heap','stack_bytes']:
  assert mem[1][key]==mem[2][key]
 memfields=['cold_'+n for n in mem[0]['heap_columns']]+['warm_'+n for n in mem[0]['heap_columns']]+['cold_stack','warm_stack']
 def flat(r):return r['heap'][0]+r['heap'][1]+[max(r['stack_bytes'][:2]),max(r['stack_bytes'][2:])]
 m={}
 for name,a,b,c in zip(memfields,*map(flat,mem)):
  m[name]=dict(fixed=a,before=b,candidate=c,increment=c-b,positive_cumulative=max(0,b-a)+max(0,c-b))
 rss=read('fresh-process-rss')['stages'][v]
 memory[v]={'workload':m,'peak_process_rss_KiB_min_median_max':{t:[min(rss[t]),median(rss[t]),max(rss[t])] for t in stages+['control','previous-safe']}}
for n in ('hypertri','hypermesh','hypercurve'):
 for target in ('x86_64-unknown-linux-gnu','wasm32-unknown-unknown'):
  rows=[read(f'{t}-desktop-{n}-{target}') for t in stages]
  if target=='wasm32-unknown-unknown':
   assert rows[1]==rows[2]
   size[n+'_'+target]={'before_and_candidate_identical':True,'stages':dict(zip(stages,rows)),'signed_history':{m:rows[1][m]-rows[0][m] for m in ('file','code','functions')}}
  else:account(n+'_'+target,rows,128<<20)
save('signed-size-accounts',size);save('signed-memory-accounts',memory)
for key,r in size.items():
 for met,row in r.get('metrics',{}).items():
  print(key,met,row['signed_step'],row['prior_charge'],row['remaining_step'],row['remaining_cumulative'])
bad=[(k,m,r) for k,v in size.items() for m,r in v.get('metrics',{}).items() if min(r['remaining_step'],r['remaining_cumulative'])<0]
assert not bad,bad
