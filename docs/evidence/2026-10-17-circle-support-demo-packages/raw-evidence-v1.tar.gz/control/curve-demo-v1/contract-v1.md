# Hypercurve demo CI qualification

The demo consumes the candidate Hypercurve library through its existing local
patches and separate lockfile. This tests the current source distribution shape;
it does not establish clean registry installation. P17-P20 and P36 apply.
Source files, geometry, policies, fixtures and all dependency versions remain
unchanged. The demo lockfile adds registry packages not present in the root
lockfile; fetch them with --locked into the open isolated Cargo home, then verify
every registry archive against the demo lockfile before offline validation.

Execute the unchanged workflow commands: cargo test --locked --no-fail-fast,
cargo clippy --locked --all-targets -- -D warnings, and cargo build --locked
--release --target wasm32-unknown-unknown. Use a fresh demo target, two build
jobs, disabled incremental compilation and the existing external resource
limits. Preserve the CI default test worker behavior for this demo command.
Each command has 1,800 seconds wall time, 8 GiB child address space, 2 GiB host
available memory, 512 MiB active volume reserve, 64 GiB fresh volume consumption
and 64 MiB aggregate command logs. Run without overlapping qualification work.

Successful compilation is not interactive browser validation. Preserve failure
and resource-stop outcomes without reducing fixtures, features or validation.
The broader native/report/modeling/binding/distribution gates remain separate.
