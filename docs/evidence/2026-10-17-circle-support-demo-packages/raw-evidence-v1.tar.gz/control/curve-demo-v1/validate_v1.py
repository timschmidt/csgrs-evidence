"""Fetch the unchanged demo lock, verify archives, and run its exact CI commands."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tomllib
sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W = Path(__file__).resolve().parent
C = V/'checkout-candidate-v1'
D = C/'crates/hypercurve/examples/hypercurve_ui'
TARGET = V/'target-curve-demo-v1'
assert json.loads((V/'candidate-curve-result-v1.json').read_text())['complete']
assert not TARGET.exists()
assert not (V/'curve-demo-protocol-v1.json').exists()
compiler = json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['GIT_OPTIONAL_LOCKS']='0'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
inventory=json.loads(gzip.decompress((V/'candidate-source-inventory-v1.json.gz').read_bytes()))
pins={p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
def verify():
    for name,digest in pins.items():
        path=C/name
        assert not path.is_symlink() and sha(path)==digest,name
    assert not reasons(resources())
verify()
commands=[('curve-demo-fetch-v1',['fetch','--locked']),
    ('curve-demo-tests-v1',['test','--locked','--no-fail-fast']),
    ('curve-demo-clippy-v1',['clippy','--locked','--all-targets','--','-D','warnings']),
    ('curve-demo-wasm-build-v1',['build','--locked','--release','--target','wasm32-unknown-unknown'])]
dump(V/'curve-demo-protocol-v1.json',{
    'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),
    'source_inventory_sha256':sha(V/'candidate-source-inventory-v1.json.gz'),
    'demo_lock_sha256':sha(D/'Cargo.lock'),'root_lock_sha256':sha(C/'Cargo.lock'),
    'source':str(D),'target':str(TARGET),'commands':[[name,[cargo,*args]] for name,args in commands],
    'source_pin_count':len(pins),'wall_limit_seconds_per_command':1800,
    'source_or_policy_changes':False,'interactive_browser_qualification':False,'candidate_admitted':False})
results={}
os.environ['CARGO_NET_OFFLINE']='false'
name,args=commands[0]
results[name]=run(name,[cargo,*args],D,target=TARGET)
verify()
lock=tomllib.loads((D/'Cargo.lock').read_text())
archives={}
for package in lock['package']:
    if not package.get('source','').startswith('registry+'):
        continue
    filename=package['name']+'-'+package['version']+'.crate'
    paths=list((V/'cargo-home-v1/registry/cache').glob('*/'+filename))
    assert len(paths)==1,(filename,paths)
    assert sha(paths[0])==package['checksum'],filename
    archives[str(paths[0])]={'sha256':sha(paths[0]),'bytes':paths[0].stat().st_size}
(V/'curve-demo-archive-inventory-v1.json.gz').write_bytes(gzip.compress((json.dumps(archives,sort_keys=True)+'\n').encode(),mtime=0))
os.environ['CARGO_NET_OFFLINE']='true'
for name,args in commands[1:]:
    verify()
    results[name]=run(name,[cargo,*args],D,target=TARGET)
    if name=='curve-demo-tests-v1':
        rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',
            (V/'logs'/name/'stdout').read_text(),re.M)
        assert rows and all(row[0]=='ok' and row[2]=='0' and row[5]=='0' for row in rows)
    verify()
    dump(V/'curve-demo-progress-v1.json',results)
dump(V/'curve-demo-result-v1.json',{'complete':True,'commands':results,'test_summaries':rows,
    'registry_archives_verified':len(archives),'source_unchanged':True,'locked_dependencies_unchanged':True,
    'exact_demo_ci_commands_passed':True,'interactive_browser_qualified':False,
    'external_distribution_complete':False,'candidate_admitted':False,'full_plan_complete':False})
print(json.dumps({'exact_demo_ci_commands_passed':True,'test_summaries':rows,
                  'interactive_browser_qualified':False,'candidate_admitted':False}),flush=True)
