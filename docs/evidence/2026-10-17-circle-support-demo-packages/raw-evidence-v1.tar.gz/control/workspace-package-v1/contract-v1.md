# Assemble the candidate workspace packages before release validation

Owner: Cargo package metadata and distribution boundary, P26/P27/P37 and T12.
The missing evidence is actual package assembly with normalized dependency
manifests, beyond earlier file-list inventories. The input is every publishable
member in the unchanged root workspace, with the isolated cache candidate's
three explicitly uncommitted files. The separately excluded Hypervoxel workspace
and nested demos are not thereby claimed packaged or release-ready.

After the demo pipeline terminates, execute the installed stable Cargo's
package --workspace --allow-dirty --locked --no-verify against the candidate,
with a fresh package target on Disk B. The allow-dirty flag names the preserved
candidate patch; it does not admit the candidate. The no-verify flag defines an
archive-assembly stage only. Actual package builds, feature/MSRV checks and the
clean external construct/transform/compose/certainty/topology/export/reimport
pipeline remain required and separate. Do not publish, push, rewrite dependencies,
remove lockfiles or substitute workspace paths to obtain success.

Cargo may update the official registry and fetch required locked inputs in the
isolated open Cargo home. A failed package, dependency lookup, offline cache miss
or resource stop remains separately classified; none proves public availability
or unavailability by itself. Preserve partial archives and every raw output.
Verify all current materialized non-comparison source pins before and after.
If assembly completes, independently inspect every archive, require normalized
active manifests without workspace patch/path dependencies, verify regular source
members against the candidate bytes, and require the new cache test to be present.
Archive assembly alone cannot certify a build, API behavior or shipped capability.

Use the existing 1,800-second wall, 8 GiB process address space, 2 GiB host memory
reserve, 512 MiB active-volume reserve, 64 GiB cumulative fresh-volume consumption
and 64 MiB aggregate log limits. Two build workers, no incremental compilation,
no concurrent qualification workload. Existing tool/source/cache roots stay
unchanged or open as already declared; all new outputs use fresh paths.

Primary command semantics were checked in the installed Cargo help and
https://doc.rust-lang.org/cargo/commands/cargo-package.html on 2026-10-17.
