"""Attempt actual package assembly; retain failure and partial archives honestly."""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile
import tomllib
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent
C=V/'checkout-candidate-v1'
B=V/'checkout-baseline-v1'
TARGET=V/'target-workspace-packages-v1'
assert not TARGET.exists() and not (V/'workspace-package-protocol-v1.json').exists()
assert json.loads((V/'curve-demo-result-v1.json').read_text())['complete']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE']='false'
os.environ['CARGO_HTTP_TIMEOUT']='30'
os.environ['CARGO_NET_RETRY']='0'
os.environ['GIT_OPTIONAL_LOCKS']='0'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
inventory=json.loads(gzip.decompress((V/'candidate-source-inventory-v1.json.gz').read_bytes()))
pins={p:h for p,h in inventory.items() if not p.startswith('crates/comparisons/')}
def verify_sources():
    for p,h in pins.items():assert not (C/p).is_symlink() and sha(C/p)==h,p
    assert not reasons(resources())
verify_sources()
metadata=json.loads((V/'logs/cargo-metadata-v1/stdout').read_text())
members=set(metadata['workspace_members'])
packages={}
for package in metadata['packages']:
    if package['id'] not in members or package['publish']==[]:continue
    manifest=C/Path(package['manifest_path']).relative_to(B)
    data=tomllib.loads(manifest.read_text())
    assert data['package']['name']==package['name'] and data['package']['version']==package['version']
    packages[package['name']]={'version':package['version'],'manifest':str(manifest),'manifest_sha256':sha(manifest),
        'source_directory':str(manifest.parent)}
assert len(packages)==20,len(packages)
command=[cargo,'package','--workspace','--allow-dirty','--locked','--no-verify']
dump(V/'workspace-package-protocol-v1.json',{'helper_sha256':sha(Path(__file__)),
 'contract_sha256':sha(W/'contract-v1.md'),'runner_sha256':sha(V/'control/validation_runner_v2.py'),
 'source_inventory_sha256':sha(V/'candidate-source-inventory-v1.json.gz'),'source_pin_count':len(pins),
 'packages':packages,'command':command,'target':str(TARGET),
 'environment':{key:os.environ[key] for key in ['CARGO_NET_OFFLINE','CARGO_HTTP_TIMEOUT','CARGO_NET_RETRY']},
 'source_changes':False,'archive_assembly_only':True,'package_build_verification':False,'publish':False,
 'candidate_admitted':False,'full_plan_complete':False})
name='workspace-package-assembly-v1'
failure=None
try:
    command_result=run(name,command,C,target=TARGET)
except RuntimeError as error:
    command_result=json.loads((V/'logs'/name/'result.json').read_text())
    failure={'category':'resource_exhaustion' if command_result['stops'] else 'package_command_failed',
             'exception_type':type(error).__name__,'exit_code':command_result['exit_code'],'stops':command_result['stops']}
for p,h in pins.items():assert sha(C/p)==h,p
archives={}
for archive in sorted((TARGET/'package').glob('*.crate')):
    archives[str(archive)]={'sha256':sha(archive),'bytes':archive.stat().st_size}
dump(V/'workspace-package-attempt-v1.json',{'command':command_result,'failure':failure,'archives':archives,
 'source_unchanged':True,'archive_builds_verified':False,'candidate_admitted':False})
if failure:
    dump(V/'workspace-package-result-v1.json',{'complete_diagnostic_run':True,'archive_assembly_complete':False,
     'command':command_result,'failure':failure,'partial_archives':archives,'source_unchanged':True,
     'package_builds_verified':False,'external_consumer_complete':False,'release_qualified':False,
     'candidate_admitted':False,'full_plan_complete':False})
    print(json.dumps({'archive_assembly_complete':False,'failure':failure,'partial_archive_count':len(archives)}),flush=True)
    sys.exit(0)
expected={name+'-'+row['version']+'.crate' for name,row in packages.items()}
assert {Path(p).name for p in archives}==expected
inspections={}
for name,package in packages.items():
    prefix=name+'-'+package['version']
    archive=TARGET/'package'/(prefix+'.crate')
    rows={};active_manifest=None
    source_root=Path(package['source_directory'])
    with tarfile.open(archive,'r:gz') as source:
        for member in source:
            path=PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0]==prefix,member.name
            assert member.isfile(),(member.name,member.type)
            relative=str(PurePosixPath(*path.parts[1:]))
            assert relative and relative not in rows
            with source.extractfile(member) as stream:data=stream.read()
            digest=hashlib.sha256(data).hexdigest()
            row={'sha256':digest,'bytes':len(data),'source_bytes_verified':False}
            original=source_root/relative
            if relative not in ['Cargo.toml','Cargo.lock','.cargo_vcs_info.json','Cargo.toml.orig']:
                assert original.is_file() and sha(original)==digest,(name,relative)
                row['source_bytes_verified']=True
            elif relative=='Cargo.toml.orig':
                assert sha(Path(package['manifest']))==digest
                row['source_bytes_verified']=True
            elif relative=='Cargo.toml':
                active_manifest=tomllib.loads(data.decode())
            rows[relative]=row
    assert active_manifest and active_manifest['package']['name']==name and active_manifest['package']['version']==package['version']
    assert not any(key in active_manifest for key in ['workspace','patch','replace'])
    tables=[active_manifest,*active_manifest.get('target',{}).values()]
    for table in tables:
        for group in ['dependencies','build-dependencies','dev-dependencies']:
            for dep,value in table.get(group,{}).items():
                assert not isinstance(value,dict) or 'path' not in value,(name,group,dep,value)
    inspections[name]={'archive':str(archive),'sha256':sha(archive),'members':rows,
                      'active_manifest_uses_no_workspace_paths_or_patches':True}
assert 'src/circle_support_cache_tests.rs' in inspections['hypercurve']['members']
assert inspections['hypercurve']['members']['src/circle_support_cache_tests.rs']['sha256']==sha(C/'crates/hypercurve/src/circle_support_cache_tests.rs')
(V/'workspace-package-members-v1.json.gz').write_bytes(gzip.compress((json.dumps(inspections,sort_keys=True)+'\n').encode(),mtime=0))
verify_sources()
dump(V/'workspace-package-result-v1.json',{'complete_diagnostic_run':True,'archive_assembly_complete':True,
 'command':command_result,'archives':archives,'archive_count':len(archives),'source_unchanged':True,
 'all_regular_source_members_verified':True,'normalized_manifests_verified':True,'candidate_new_test_included':True,
 'package_builds_verified':False,'external_consumer_complete':False,'release_qualified':False,
 'candidate_admitted':False,'full_plan_complete':False})
print(json.dumps({'archive_assembly_complete':True,'archive_count':len(archives),
 'package_builds_verified':False,'release_qualified':False,'candidate_admitted':False}),flush=True)
