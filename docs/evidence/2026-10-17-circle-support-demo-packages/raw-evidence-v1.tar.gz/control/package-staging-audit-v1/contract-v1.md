# Inspect retained package staging without changing it

The workspace package command failed at Hypervoxel resolution. Its v2 summary
looked only in the final output directory and omitted nested staging archives.
Read all 17 retained physical archive paths independently: eight pairs of staged
packages and one incomplete HyperSDF archive. Require every nongenerated member
of each complete staged package to equal the current source bytes, inspect its
normalized active manifest, and preserve the generated lock and VCS metadata.
Require the candidate cache test in the Hypercurve archive. This corrects the
inventory scope without changing the failed command or claiming a package build,
complete workspace assembly, installed consumer, release or cache admission.
