"""Verify source bytes and normalized manifests in all completed staging archives."""
import gzip
import hashlib
import json
from pathlib import Path,PurePosixPath
import tarfile
import tomllib
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
C=V/'checkout-candidate-v1'
T=V/'target-workspace-packages-v2/package'
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
inspection=json.loads((V/'workspace-package-staging-inspection-v1.json').read_text())
selection=json.loads((V/'control/workspace-package-v2/selection-v2.json').read_text())
assert len(inspection['archives'])==17
assert all(sha(p)==row['sha256'] for p,row in inspection['archives'].items())
archives={}
for archive in sorted((T/'tmp-registry').glob('*.crate')):
    stem=archive.name[:-6]
    name,version=stem.rsplit('-',1)
    selected=selection[name]
    assert selected['version']==version
    original_manifest=C/selected['manifest']
    source_root=original_manifest.parent
    assert sha(original_manifest)==selected['manifest_sha256']
    sibling=T/'tmp-crate'/archive.name
    assert sha(archive)==sha(sibling)
    rows={};active=None;vcs=None
    with tarfile.open(archive,'r:gz') as source:
        for member in source:
            path=PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0]==stem
            assert member.isfile(),(member.name,member.type)
            relative=str(PurePosixPath(*path.parts[1:]));assert relative and relative not in rows
            with source.extractfile(member) as f:data=f.read()
            row={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'source_bytes_verified':False}
            if relative=='Cargo.toml':active=tomllib.loads(data.decode())
            elif relative=='.cargo_vcs_info.json':vcs=json.loads(data)
            elif relative=='Cargo.lock':row['generated_lock']=True
            else:
                original=original_manifest if relative=='Cargo.toml.orig' else source_root/relative
                assert original.read_bytes()==data,(name,relative)
                row['source_bytes_verified']=True
            rows[relative]=row
    assert active and active['package']['name']==name and active['package']['version']==version
    assert not any(key in active for key in ['workspace','patch','replace'])
    for table in [active,*active.get('target',{}).values()]:
        for group in ['dependencies','build-dependencies','dev-dependencies']:
            for dep,value in table.get(group,{}).items():assert not isinstance(value,dict) or 'path' not in value,(name,dep)
    archives[name]={'version':version,'physical_archive':str(archive),'physical_twin':str(sibling),
        'sha256':sha(archive),'bytes':archive.stat().st_size,'members':rows,'vcs':vcs,
        'source_members_byte_equal':True,'active_manifest_without_workspace_patches_or_paths':True}
assert len(archives)==8 and 'hypercurve' in archives
assert archives['hypercurve']['members']['src/circle_support_cache_tests.rs']['source_bytes_verified']
incomplete=T/'tmp-crate/hypersdf-0.2.0.crate'
with tarfile.open(incomplete,'r:gz') as source:
    incomplete_members=source.getnames()
assert not any(p.endswith('/Cargo.toml') for p in incomplete_members)
record={'completed_staging_archives':archives,'logical_staged_package_count':8,
    'independently_hashed_physical_archive_paths':17,'final_output_archives':0,
    'incomplete_archive':{'path':str(incomplete),'sha256':sha(incomplete),'members':incomplete_members},
    'initial_v2_partial_inventory_omitted_nested_staging':True,
    'initial_inspection_sha256':sha(V/'workspace-package-staging-inspection-v1.json'),
    'helper_sha256':sha(Path(__file__)),'all_source_members_byte_equal':True,
    'archive_assembly_complete':False,'package_builds_verified':False,'candidate_admitted':False,
    'release_qualified':False,'full_plan_complete':False}
p=V/'workspace-package-staged-members-v1.json.gz';assert not p.exists()
p.write_bytes(gzip.compress((json.dumps(record,sort_keys=True)+'\n').encode(),mtime=0))
print(json.dumps({'logical_staged_packages_verified':8,'physical_archive_paths_hashed':17,
    'all_source_members_byte_equal':True,'incomplete_archives':1,'archive_assembly_complete':False}),flush=True)
