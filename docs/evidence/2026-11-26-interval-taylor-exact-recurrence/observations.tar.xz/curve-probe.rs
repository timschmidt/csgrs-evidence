#![cfg(feature = "interval-ranges")]
use hyperinterval::{DyadicBudget, DyadicInterval};
use hypercurve::{HomogeneousControl2, RationalBezier2, interval_ranges::prepare_rational_bezier_ranges};
use hyperreal::Real;
use hypersolve::expression_program::{ExpressionBudget, TaylorRequest};
use std::time::Instant;
fn g() -> ExpressionBudget { ExpressionBudget::new(100_000_000, 10_000_000_000) }
fn a() -> DyadicBudget { DyadicBudget::new(16384, 1_000_000_000_000_000) }
fn d(l: i64, u: i64, e: i32) -> DyadicInterval { DyadicInterval::new(l.into(), u.into(), e).unwrap() }
fn f(v: &impl std::fmt::Display, e: i32) -> f64 { v.to_string().parse::<f64>().unwrap() * 2f64.powi(e) }
fn w(i: &DyadicInterval) -> f64 { match i.width(&mut a()).unwrap().upper() { Some((m, e)) => f(m, e), None => f64::NAN } }
fn r(n: i64, dd: i64) -> Real { (Real::from(n) / Real::from(dd)).unwrap() }
fn hc(x: Real, y: Real, wt: Real) -> HomogeneousControl2 { HomogeneousControl2::new(x, y, wt) }
#[test]
fn probe() {
    // homogeneous controls (wx, wy, w)
    let curves: Vec<(&str, RationalBezier2, Vec<(f64,f64,f64)>)> = vec![
        ("conic w=[1,1/2,1] quarter-ish", RationalBezier2::from_homogeneous_controls(vec![
            hc(r(1,1),r(0,1),r(1,1)), hc(r(1,2),r(1,2),r(1,2)), hc(r(0,1),r(1,1),r(1,1))]).unwrap(),
            vec![(1.,0.,1.),(0.5,0.5,0.5),(0.,1.,1.)]),
        ("cubic w=[1,3,1/2,2]", RationalBezier2::from_homogeneous_controls(vec![
            hc(r(0,1),r(0,1),r(1,1)), hc(r(3,1),r(6,1),r(3,1)), hc(r(1,1),r(-1,2),r(1,2)), hc(r(8,1),r(2,1),r(2,1))]).unwrap(),
            vec![(0.,0.,1.),(3.,6.,3.),(1.,-0.5,0.5),(8.,2.,2.)]),
        ("quartic w=[1,4,1,4,1]", RationalBezier2::from_homogeneous_controls(vec![
            hc(r(0,1),r(0,1),r(1,1)), hc(r(4,1),r(8,1),r(4,1)), hc(r(2,1),r(-1,1),r(1,1)), hc(r(12,1),r(8,1),r(4,1)), hc(r(4,1),r(0,1),r(1,1))]).unwrap(),
            vec![(0.,0.,1.),(4.,8.,4.),(2.,-1.,1.),(12.,8.,4.),(4.,0.,1.)]),
    ];
    for (name, curve, h) in &curves {
        let prepared = prepare_rational_bezier_ranges(curve, &mut g()).unwrap();
        for (lo, hi, e) in [(0i64, 1i64, 0i32), (0, 1, -1), (1, 2, -2), (3, 4, -3)] {
            let dom = d(lo, hi, e);
            let (t0, t1) = (lo as f64 * 2f64.powi(e), hi as f64 * 2f64.powi(e));
            // true range by dense sampling
            let mut tr = [(f64::MAX, f64::MIN); 2];
            let n = h.len() - 1;
            for k in 0..=20000 {
                let t = t0 + (t1 - t0) * k as f64 / 20000.0;
                let mut s = [0.0; 3];
                for (i, c) in h.iter().enumerate() {
                    let b = (1..=n).fold(1.0, |acc, j| acc * (n + 1 - j) as f64 / j as f64);
                    let _ = b;
                    let binom = { let mut v = 1.0; for j in 0..i { v = v * (n - j) as f64 / (j + 1) as f64; } v };
                    let bb = binom * t.powi(i as i32) * (1.0 - t).powi((n - i) as i32);
                    s[0] += bb * c.0; s[1] += bb * c.1; s[2] += bb * c.2;
                }
                for c in 0..2 { let v = s[c] / s[2]; tr[c].0 = tr[c].0.min(v); tr[c].1 = tr[c].1.max(v); }
            }
            let tw = [tr[0].1 - tr[0].0, tr[1].1 - tr[1].0];
            let start = Instant::now();
            let nat = prepared.enclose(&dom, -64, &mut g(), &mut a());
            let nt = start.elapsed();
            let nw = match &nat { Ok(rep) => format!("{:.4e}/{:.4e}", w(rep.coordinates()[0]), w(rep.coordinates()[1])), Err(e) => format!("err {e:?}").chars().take(40).collect() };
            print!("{name} dom[{t0},{t1}] true {:.4e}/{:.4e} natural {nw} ({:?})", tw[0], tw[1], nt);
            let center = dom.midpoint(&mut a()).unwrap();
            for order in [1usize, 2, 3, 4, 6, 8] {
                let start = Instant::now();
                let m = prepared.program().source().taylor_model(TaylorRequest { center: vec![center.clone()], domain: vec![dom.clone()], order, precision: -64 }, &mut g(), &mut a());
                let el = start.elapsed();
                match m { Ok(m) => print!(" | o{order} {:.4e}/{:.4e} ({:?})", w(&m.image()[0]), w(&m.image()[1]), el), Err(e) => print!(" | o{order} err {:?}", format!("{e:?}").chars().take(30).collect::<String>()) }
            }
            println!();
        }
    }
}
