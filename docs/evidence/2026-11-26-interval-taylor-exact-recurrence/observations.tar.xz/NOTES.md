# Exact Taylor coefficients from Taylor-mode recurrences (2026-11-26)

- base-commit.txt: main before the change; change-commit.txt / change.diff: the change.
- bench-main-baseline.txt / bench-ab.txt: Criterion, CPU 0, ASLR off, binaries built
  from main (worktree, separate CARGO_TARGET_DIR) and from the change.
- superseded-*: first A/B attempt with a shared target directory. Cargo hashes
  workspace members by relative path, so the main worktree's release build replaced
  the checkout's artifacts; both sides ran main. Kept as superseded, not evidence.
- curve-probe*: temporary hypercurve probe (removed from the tree) comparing natural
  interval-range boxes with Taylor images of rational Bezier coordinates; widths
  identical between builds, timings per build.
- flow-noise-*: hyperdynamics flow_noise example output, byte-identical.
- mutations.txt: exact-arithmetic mutants, all killed by failing tests.
- text-sizes.txt: development artifact .text deltas.
- *-tests.txt: test summaries on the committed tree (hyperdynamics 191 passed).
