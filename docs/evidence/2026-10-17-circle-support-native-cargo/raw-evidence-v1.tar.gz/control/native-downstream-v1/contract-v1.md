# Downstream qualification after the fresh curve matrix

Scope: preserve the supported downstream behavior of the deferred circular
support index; P4/P19/P20/P27/P36 apply. This is a cache-only candidate. The
rejected exact KiCad ingress and 35-file integration remain rejected, with
their unresolved geometry claims retained. Preserving current report artifacts
does not establish exact fidelity of the legacy KiCad source representation.

First require the complete fresh Hypercurve candidate matrix. Verify all affected source
and fixture hashes for each downstream command. Both complete native project
archives must be present and match the baseline inventory. Independently compare
Python ZIP extraction with the actual unzip executable for both board entries
in baseline and candidate trees. Keep the extracted bytes and command results.
Any missing/extraction failure blocks credit; the legacy test helpers can skip
such inputs and their nominal pass alone is insufficient.

Build the unchanged baseline and candidate native targets in their separate
open target directories. Run all three original native gates separately with
one test worker and no overlapping qualification build or workload. Preserve
the exact full-board 120-second worker-CPU assertion, copper-neck 60-second
check-body wall assertion, Gerber assertions, fixture content and resolution.
Record completed results, errors and exhaustion separately. Do not infer an
end-to-end speedup from gate passes or Cargo elapsed time.

Run full candidate HyperDRC CI tests, strict all-target Clippy, docs, root
feature configurations, Hypercircuit consumers and actual affected bindings
before production admission. The workspace CI explicitly budgets 90 minutes
for HyperDRC; its complete test command may use an external 5,400-second limit,
predeclared here before execution. All other commands retain 1,800 seconds.
This does not alter either native operation's 120/60-second acceptance limit.
Keep 8 GiB child address space, 2 GiB host available memory, 512 MiB active
volume reserve, 64 GiB cumulative fresh-volume consumption and 64 MiB logs.
All outputs and scratch stay on the fresh validation volume. Existing closed
roots and the original repository remain read-only. No internal resource bound
or full release qualification follows from these external controls.

For report compatibility, use identical complete inputs, paths, checks, policies
and serialization boundaries for both binaries. Preserve full raw output,
row counts, output bytes and hashes. Test repeat determinism separately from
baseline/candidate equality. Do not normalize away a difference or substitute
triangle counts/checksums for an independent geometry oracle. New exact
circle-oracle tests and the historical E46 semantic/cost evidence serve their
own narrow claims. Real binding and clean external distribution results remain
explicit gates; workspace success cannot stand in for either.
