"""Verify both complete native fixture archives and independent board extraction."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
O = V / 'native-fixture-preflight-v1'
BASE = V / 'checkout-baseline-v1'
CANDIDATE = V / 'checkout-candidate-v1'
assert not O.exists()
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
O.mkdir()
unzip = Path(shutil.which('unzip')).resolve()

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

fixtures = [
    ('CPArti FPGA dev board.zip', 'CPArti FPGA dev board.kicad_pcb'),
    ('HVP109A.zip', 'HVP109A.kicad_pcb'),
]
records = {}
for variant, root in [('baseline', BASE), ('candidate', CANDIDATE)]:
    folder = O / variant
    folder.mkdir()
    for archive_name, board in fixtures:
        relative = 'crates/hyperdrc/docs/' + archive_name
        archive = root / relative
        assert sha(archive) == inventory[relative]['sha256']
        with zipfile.ZipFile(archive) as source:
            assert source.testzip() is None
            entries = source.infolist()
            assert len({p.filename for p in entries}) == len(entries)
            assert board in source.namelist()
            members = {}
            for info in entries:
                if info.is_dir():
                    continue
                with source.open(info) as stream:
                    members[info.filename] = {'bytes': info.file_size,
                        'sha256': hashlib.file_digest(stream, 'sha256').hexdigest()}
            expected = source.read(board)
            if archive_name.startswith('CPArti'):
                assert 'gerbers/CPArti FPGA dev board-Edge_Cuts.gbr' in members
                assert any(p.startswith('gerbers/') and 'F_Cu' in p for p in members)
        argv = [str(unzip), '-p', str(archive), board]
        result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
        output = folder / board
        output.write_bytes(result.stdout)
        (folder / (archive_name + '.stderr')).write_bytes(result.stderr)
        assert result.returncode == 0 and result.stdout == expected and expected
        records[variant + '/' + archive_name] = {
            'archive': str(archive), 'archive_sha256': sha(archive),
            'archive_bytes': archive.stat().st_size, 'members': members,
            'entry_count': len(entries), 'uncompressed_bytes': sum(i.file_size for i in entries),
            'unzip_argv': argv, 'unzip_exit_code': result.returncode,
            'board_output': str(output), 'board_bytes': len(expected),
            'board_sha256': sha(output), 'independent_extractors_agree': True}
for name, board in fixtures:
    assert records['baseline/' + name]['members'] == records['candidate/' + name]['members']
    assert records['baseline/' + name]['board_sha256'] == records['candidate/' + name]['board_sha256']
record = {'complete': True, 'archives_verified': 4, 'board_extractions_verified': 4,
          'archive_member_maps_match': True, 'unzip': str(unzip), 'unzip_sha256': sha(unzip),
          'full_fixtures_unchanged': True, 'records': records,
          'geometry_tests_executed': False, 'resource_gates_passed': False}
(O / 'result.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archives_verified': 4, 'board_extractions_verified': 4,
                  'archive_member_maps_match': True, 'geometry_tests_executed': False}), flush=True)
