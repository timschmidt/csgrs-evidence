"""Replay full native gates and the complete downstream suite on fresh targets."""
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import GIT, dump, reasons, resources, run, sha

W = Path(__file__).resolve().parent
C = V / 'checkout-candidate-v1'
B = V / 'checkout-baseline-v1'
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert not (V / 'native-downstream-protocol-v1.json').exists()
toolchain = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p) == h for p,h in toolchain['tool_sha256'].items())
os.environ.update(toolchain['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
os.environ['GMP_MPFR_SYS_CACHE'] = str(V / 'gmp-cache-v1')
cargo = str(Path(toolchain['additional_environment']['RUSTC']).with_name('cargo'))
base_inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
candidate_inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))

def affected(name):
    # Include root assets, documentation fixtures and every materialized crate
    # outside archived comparison data, which these commands do not consume.
    return not name.startswith('crates/comparisons/')


pins = {
    'baseline': {p:row['sha256'] for p,row in base_inventory.items() if affected(p)},
    'candidate': {p:h for p,h in candidate_inventory.items() if affected(p)}}
roots = {'baseline': B, 'candidate': C}
targets = {variant: V / ('target-' + variant + '-v1') for variant in roots}

def verify(variant):
    root = roots[variant]
    for name, digest in pins[variant].items():
        path = root / name
        assert not path.is_symlink(), name
        assert sha(path) == digest, name
    assert not reasons(resources())

for variant in roots:
    verify(variant)
fixture_command = [sys.executable, '-B', str(W / 'fixtures_v1.py')]
gates = {
    'full-board': 'zz_complex_project_performance_tests::kicad_board_completes_smoke_check_suite',
    'copper-neck': 'zz_complex_project_performance_tests::min_copper_neck_width_completes_on_copper_layers',
    'gerber': 'zz_complex_project_performance_tests::gerber_package_completes_smoke_check_suite'}
protocol = {'source_roots': {k:str(v) for k,v in roots.items()},
    'targets': {k:str(v) for k,v in targets.items()}, 'affected_source_counts': {k:len(v) for k,v in pins.items()},
    'contract_sha256': sha(W / 'contract-v1.md'), 'runner_sha256': sha(V / 'control/validation_runner_v2.py'),
    'helper_sha256': sha(Path(__file__)), 'fixture_verifier_sha256': sha(W / 'fixtures_v1.py'),
    'native_gates': gates, 'full_board_worker_cpu_limit_seconds': 120,
    'copper_neck_body_wall_limit_seconds': 60,
    'full_suite_wall_limit_seconds': 5400, 'other_command_wall_limit_seconds': 1800,
    'test_threads_full_suite': 2, 'test_threads_separate_gates': 1,
    'ci_test_scheduling_difference': 'The same complete HyperDRC release suite is run with two workers for local containment.',
    'performance_comparison': False, 'candidate_admitted': False,
    'GMP_MPFR_SYS_CACHE': os.environ['GMP_MPFR_SYS_CACHE']}
dump(V / 'native-downstream-protocol-v1.json', protocol)
results = {}
results['fixture-preflight'] = run('native-fixture-preflight-v1', fixture_command, V, target=targets['candidate'])
fixtures = json.loads((V / 'native-fixture-preflight-v1/result.json').read_text())
assert fixtures['complete'] and fixtures['board_extractions_verified'] == 4
for variant, root in roots.items():
    verify(variant)
    name = 'native-' + variant + '-compile-v1'
    results[name] = run(name, [cargo, 'test', '--release', '--locked', '-p', 'hyperdrc', '--no-run'],
                        root, target=targets[variant])
    dump(V / 'native-downstream-progress-v1.json', results)
for variant, root in roots.items():
    for label, test_name in gates.items():
        verify(variant)
        assert sha(fixtures['unzip']) == fixtures['unzip_sha256']
        name = 'native-' + variant + '-' + label + '-v1'
        argv = [cargo, 'test', '--release', '--locked', '-p', 'hyperdrc', '--lib', test_name,
                '--', '--exact', '--nocapture', '--test-threads=1']
        results[name] = run(name, argv, root, target=targets[variant])
        stdout = (V / 'logs' / name / 'stdout').read_text()
        stderr = (V / 'logs' / name / 'stderr').read_text()
        assert 'skipping complex project fixture' not in stdout + stderr
        assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;', stdout)
        dump(V / 'native-downstream-progress-v1.json', results)
for variant in roots:
    verify(variant)
name = 'native-candidate-clippy-v1'
results[name] = run(name, [cargo, 'clippy', '--locked', '-p', 'hyperdrc', '--all-targets', '--', '-D', 'warnings'],
                    C, target=targets['candidate'])
verify('candidate')
name = 'native-candidate-docs-v1'
os.environ['RUSTDOCFLAGS'] = '-D warnings'
results[name] = run(name, [cargo, 'doc', '--locked', '-p', 'hyperdrc', '--no-deps'], C, target=targets['candidate'])
os.environ.pop('RUSTDOCFLAGS')
verify('candidate')
name = 'native-candidate-full-tests-v1'
results[name] = run(name, [cargo, 'test', '--locked', '-p', 'hyperdrc', '--release', '--', '--test-threads=2'],
                    C, target=targets['candidate'], wall_seconds=5400)
stdout = (V / 'logs' / name / 'stdout').read_text()
rows = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout, re.M)
assert rows and all(row[0] == 'ok' and row[2] == '0' and row[5] == '0' for row in rows)
assert 'skipping complex project fixture' not in stdout + (V / 'logs' / name / 'stderr').read_text()
for variant in roots:
    verify(variant)
subprocess.run(GIT + ['diff', '--quiet'], cwd=B, check=True)
subprocess.run(GIT + ['diff', '--check'], cwd=C, check=True)
summary = {'complete': True, 'commands': results, 'full_suite_summaries': rows,
    'full_suite_passed': sum(int(row[1]) for row in rows), 'full_suite_failed': 0,
    'full_suite_ignored': sum(int(row[3]) for row in rows),
    'all_six_separate_native_gates_passed': True, 'full_fixtures_verified': True,
    'source_unchanged': True, 'artifact_comparison_complete': False,
    'real_bindings_complete': False, 'external_distribution_complete': False,
    'candidate_admitted': False, 'full_plan_complete': False}
dump(V / 'native-downstream-result-v1.json', summary)
print(json.dumps({k:summary[k] for k in ['complete','full_suite_passed','full_suite_failed','full_suite_ignored','all_six_separate_native_gates_passed','candidate_admitted']}), flush=True)
