# Native report compatibility for the cache-only candidate

Owning layer: the Hypercurve circular-support cache; affected consumer:
HyperDRC. P4, P19, P27 and P36 require retained witness order, certainty and
unchanged deterministic artifacts for this optimization. The original 35-file
integration and later exact KiCad ingress proposals remain rejected.

Prerequisites are the fresh curve matrix, native fixture preflight and all
native downstream gates. Build each unchanged native CLI in its existing open
validation target. Copy both complete board entries into a new shared input
directory, verifying their archive hashes and independently extracted bytes.
For each board, select exactly the four checks and 0.0762 minimum width used by
the original full-board gate. Also exercise the original Gerber outline smoke
input and layer-sanity check. Retain the complete source archives; the Gerber
smoke input is the existing limited loader workload, not full-package coverage.

Run baseline, candidate, candidate, baseline for each input, sequentially at
identical absolute input paths and the same working directory. Use the existing
JSON serializer and --allow-findings: that flag changes only the process status
for completed reports containing findings, not checks, rules or geometry.
Preserve the full stdout/stderr, findings, coverage, diagnostics and provenance.
Reject duplicate JSON keys and non-finite JSON constants. Compare parsed full
reports and byte-for-byte output separately, including size and SHA-256, both
across variants and within each variant. Do not normalize paths, timing fields,
coordinates, ordering or any other report content to force agreement.

Completion, inconclusive coverage and findings are recorded separately. Report
compatibility is not an independent geometry oracle and does not establish
exact fidelity of the legacy KiCad representation. The independent exact circle
regressions support their separately stated domain. This is not a matched
performance benchmark or a release/distribution qualification.

Every command retains the external 1,800-second wall limit, 8 GiB child address
space, 2 GiB host available-memory reserve, 512 MiB active-volume reserve, 64 GiB
fresh-volume consumption limit and 64 MiB aggregate command-log limit. All
outputs and scratch are on Disk B. No builds or measured workloads overlap.
A mismatch, process failure or resource stop remains a failed gate with its raw
evidence preserved. It cannot be removed by changing the workload or serializer.
