"""Compare unchanged native JSON reports without normalizing any output."""
import decimal
import gzip
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

sys.dont_write_bytecode = True
V = Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0, str(V / 'control'))
from validation_runner_v2 import dump, reasons, resources, run, sha

W = Path(__file__).resolve().parent
O = V / 'native-report-fixtures-v1'
B = V / 'checkout-baseline-v1'
C = V / 'checkout-candidate-v1'
assert json.loads((V / 'candidate-curve-result-v1.json').read_text())['complete']
assert json.loads((V / 'native-downstream-result-v1.json').read_text())['complete']
assert not O.exists()
assert not (V / 'native-report-protocol-v1.json').exists()
compiler = json.loads((V / 'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p) == h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE'] = 'true'
os.environ['GIT_OPTIONAL_LOCKS'] = '0'
cargo = str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
base_inventory = json.loads(gzip.decompress((V / 'baseline-source-inventory-v1.json.gz').read_bytes()))
candidate_inventory = json.loads(gzip.decompress((V / 'candidate-source-inventory-v1.json.gz').read_bytes()))
roots = {'baseline': B, 'candidate': C}
targets = {k: V / ('target-' + k + '-v1') for k in roots}
pins = {'baseline': {p:r['sha256'] for p,r in base_inventory.items() if not p.startswith('crates/comparisons/')},
        'candidate': {p:h for p,h in candidate_inventory.items() if not p.startswith('crates/comparisons/')}}

def verify(variant):
    for name, digest in pins[variant].items():
        path = roots[variant] / name
        assert not path.is_symlink() and sha(path) == digest, name
    assert not reasons(resources())

for variant in roots:
    verify(variant)
fixtures = json.loads((V / 'native-fixture-preflight-v1/result.json').read_text())
assert fixtures['complete'] and fixtures['board_extractions_verified'] == 4
O.mkdir()
fixture_records = {}
board_specs = [('cparti', 'CPArti FPGA dev board.zip', 'CPArti FPGA dev board.kicad_pcb'),
               ('hvp109a', 'HVP109A.zip', 'HVP109A.kicad_pcb')]
for label, archive, member in board_specs:
    row = fixtures['records']['baseline/' + archive]
    assert sha(row['archive']) == row['archive_sha256']
    assert sha(row['board_output']) == row['board_sha256']
    destination = O / member
    shutil.copyfile(row['board_output'], destination)
    assert sha(destination) == row['board_sha256']
    fixture_records[label] = {'path': str(destination), 'sha256': sha(destination),
        'bytes': destination.stat().st_size, 'archive': row['archive'],
        'archive_sha256': row['archive_sha256'], 'member': member}
row = fixtures['records']['baseline/CPArti FPGA dev board.zip']
member = 'gerbers/CPArti FPGA dev board-Edge_Cuts.gbr'
folder = O / 'gerber-outline-smoke'
folder.mkdir()
destination = folder / Path(member).name
with zipfile.ZipFile(row['archive']) as archive:
    destination.write_bytes(archive.read(member))
assert sha(destination) == row['members'][member]['sha256']
fixture_records['gerber-outline'] = {'path': str(destination), 'sha256': sha(destination),
    'bytes': destination.stat().st_size, 'archive': row['archive'],
    'archive_sha256': row['archive_sha256'], 'member': member}
checks = ['layer-sanity', 'board-outline-sanity', 'min-copper-neck', 'drill-spacing']
cases = []
for label, _, member in board_specs:
    args = ['--kicad-pcb', str(O / member)]
    for check in checks:
        args.extend(['--check', check])
    args.extend(['--min-width', '0.0762', '--format', 'json', '--allow-findings'])
    cases.append((label, args, checks))
cases.append(('gerber-outline', ['--gerber-dir', str(folder), '--check', 'layer-sanity',
    '--min-width', '0.0762', '--format', 'json', '--allow-findings'], ['layer-sanity']))
order = ['baseline', 'candidate', 'candidate', 'baseline']
dump(V / 'native-report-protocol-v1.json', {
    'helper_sha256': sha(Path(__file__)), 'contract_sha256': sha(W / 'contract-v1.md'),
    'runner_sha256': sha(V / 'control/validation_runner_v2.py'),
    'source_roots': {k:str(p) for k,p in roots.items()},
    'source_inventory_sha256': {k:sha(V / (k + '-source-inventory-v1.json.gz')) for k in roots},
    'fixture_records': fixture_records, 'cases': cases, 'order': order,
    'common_cwd': str(O), 'output_normalization': False,
    'independent_geometry_oracle': False, 'performance_comparison': False,
    'wall_limit_seconds_per_command': 1800, 'candidate_admitted': False})
results = {}
for variant in roots:
    verify(variant)
    name = 'native-report-' + variant + '-build-v1'
    results[name] = run(name, [cargo, 'build', '--release', '--locked', '-p', 'hyperdrc', '--bin', 'hyperdrc'],
                        roots[variant], target=targets[variant])
binaries = {k: targets[k] / 'release/hyperdrc' for k in roots}
binary_pins = {k:sha(p) for k,p in binaries.items()}
dump(V / 'native-report-binaries-v1.json', {
    k:{'path':str(p), 'sha256':binary_pins[k], 'bytes':p.stat().st_size} for k,p in binaries.items()})

def reject_constant(value):
    raise ValueError('non-finite JSON constant: ' + value)

def unique_keys(pairs):
    result = {}
    for key,value in pairs:
        assert key not in result, key
        result[key] = value
    return result

reports = {}
for label, args, expected_checks in cases:
    raw = []
    parsed = []
    records = []
    for ordinal, variant in enumerate(order):
        verify(variant)
        assert sha(binaries[variant]) == binary_pins[variant]
        assert all(sha(row['path']) == row['sha256'] for row in fixture_records.values())
        name = 'native-report-' + label + '-' + str(ordinal) + '-' + variant + '-v1'
        results[name] = run(name, [str(binaries[variant]), *args], O, target=targets[variant])
        output = V / 'logs' / name / 'stdout'
        data = output.read_bytes()
        report = json.loads(data, parse_float=decimal.Decimal,
                            parse_constant=reject_constant, object_pairs_hook=unique_keys)
        assert report['inputs'], label
        assert len(report['violations']) == report['violation_count']
        assert len(report.get('waived_violations', [])) == report['waived_count']
        coverage = report['coverage']['checks']
        assert [record['check'] for record in coverage] == expected_checks
        assert all(record['status'] in ['passed', 'failed', 'not_applicable', 'uncertain', 'skipped'] for record in coverage)
        raw.append(data)
        parsed.append(report)
        records.append({'variant':variant, 'command':name, 'stdout_sha256':sha(output),
            'stdout_bytes':len(data), 'violation_count':report['violation_count'],
            'waived_count':report['waived_count'], 'diagnostic_count':len(report.get('diagnostics', [])),
            'coverage':coverage, 'inconclusive_check_count':sum(record['status'] in ['uncertain','skipped'] for record in coverage),
            'serialized_report_complete':True, 'certified_geometry_claim':False})
        dump(V / 'native-report-progress-v1.json', {'commands':results, 'current_case':label, 'reports':records})
    comparisons = {'baseline_repeat_bytes_equal':raw[0] == raw[3],
        'candidate_repeat_bytes_equal':raw[1] == raw[2],
        'all_variants_bytes_equal':all(value == raw[0] for value in raw),
        'all_variants_full_parsed_reports_equal':all(value == parsed[0] for value in parsed)}
    reports[label] = {'runs':records, 'comparisons':comparisons}
    dump(V / ('native-report-' + label + '-comparison-v1.json'), reports[label])
    assert all(comparisons.values()), (label, comparisons)
for variant in roots:
    verify(variant)
dump(V / 'native-report-result-v1.json', {
    'complete':True, 'commands':results, 'cases':reports, 'source_unchanged':True,
    'full_reports_equal':True, 'repeat_determinism_verified':True,
    'independent_geometry_oracle':False, 'legacy_kicad_exact_fidelity_established':False,
    'performance_comparison':False, 'candidate_admitted':False,
    'external_distribution_complete':False, 'full_plan_complete':False})
print(json.dumps({'full_reports_equal':True, 'repeat_determinism_verified':True,
                  'report_processes':12, 'candidate_admitted':False}), flush=True)
