from pathlib import Path
import hashlib,io,json,tarfile,shutil,subprocess as sp,importlib.util
s=Path(__file__).parent; repo=Path.cwd();other=repo.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-wasm-stack'
def git(*args):return sp.check_output(['git','-C',other,*args])
assert not git('status','--porcelain')
archive=s/'archive';archive.mkdir()
files={}
for n in ['scope','artifacts.py','reproduce.txt','measure.mjs','archive.py','proposal/tracked.patch','proposal/new.patch','p1-cfg','p1threads-cfg']:
 files[n]=s/n
for n in ['previous-ingress','excluded-final','thread-mutant','retained-native','retained-zizmor','retained-negatives','retained-browser','artifacts','artifacts.json','msrv-final','modes','codegen','repo-budget','native-image-old','native-image-new','bare-paired','guest-proposal.json','mutant-layout','mutant-overlap','mutant-start','memory-final-1.95.0-wasm32-wasip1.json','memory-final-1.95.0-wasm32-unknown-unknown.json','memory-old-unknown.json']:
 files['logs/'+n]=s/'logs'/n
for p in [*s.glob('logs/stack-*.json'),*s.glob('final-native-codegen/*')]:
 if p.name not in ['disassembly.txt','kernel.asm','build.jsonl','symbols.txt']:files[p.relative_to(s).as_posix()]=p
for d in [*s.glob('final-*-wasm32-*'),*s.glob('retained-*')]:
 if not (d/'report.json').exists():continue
 for p in d.iterdir():
  if p.is_file() and (p.name in ['commands.json','report.json','compiler.log','guest-stack.log','dependencies.log'] or p.suffix=='.log' and p.stat().st_size and not p.name.startswith('real-bridge-metadata')):
   files['reports/'+d.name+'/'+p.name]=p
sha=lambda b:hashlib.sha256(b).hexdigest()
digests={}
with tarfile.open(archive/'observations.tar.xz','w:xz',preset=6) as tar:
 for n,p in sorted(files.items()):
  b=p.read_bytes(); i=tarfile.TarInfo(n);i.size=len(b);tar.addfile(i,io.BytesIO(b));digests[n]=sha(b)
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {i.name:sha(tar.extractfile(i).read()) for i in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record); git('add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive IEEE guest stack, ABI controls and paired WASI candidate results')
rev=git('rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git('show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',repo/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=repo/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1],len(digests))
