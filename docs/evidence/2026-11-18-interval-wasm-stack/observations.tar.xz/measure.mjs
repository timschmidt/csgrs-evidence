// Run the complete maintained oracle on the unmodified linked instances. Only
// the JS adapter gains a hook to seed the linker stack and inspect it on return.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const [binary, wat, corpusPath, source] = process.argv.slice(2);
const assembly = await fs.readFile(wat,'utf8');
const stack = Number(/\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)/.exec(assembly)[1]);
for (const [,base] of assembly.matchAll(/\(data [^\n]*?\(i32.const (\d+)\)/g)) assert.ok(Number(base) >= stack);
const bytes = await fs.readFile(binary), corpus=JSON.parse(await fs.readFile(corpusPath,'utf8'));
const module = await WebAssembly.compile(bytes);
const {instantiate}=await import(pathToFileURL(path.resolve(source,'instantiate.mjs')));
const wasi = binary.includes('wasip1');
const text=(await fs.readFile(path.resolve(source,'check.mjs'),'utf8')).replace(
  'from "./instantiate.mjs"', 'from '+JSON.stringify(pathToFileURL(path.resolve(source,'instantiate.mjs')).href)
).replace('const { exports: api } = await instantiate(module, wasiPreview1);',
  'const api = globalThis.intervalInstance.exports;');
const {verify}=await import('data:text/javascript;base64,'+Buffer.from(text).toString('base64'));
const rows=[];
for (const pattern of [0x55,0xaa]) {
  globalThis.intervalInstance=await instantiate(module,wasi);
  const {memory}=globalThis.intervalInstance.exports;
  const initial=memory.buffer.byteLength;
  for(const temperature of ['cold','warm']){
    const data = new Uint8Array(memory.buffer, 0, stack);
    data.fill(pattern);
    const report=await verify(bytes,corpus,wasi);
    const first=data.findIndex(v=>v!==pattern);
    assert.ok(first>=0);
    assert.equal(memory.buffer.byteLength,initial);
    rows.push({pattern,temperature,cases:report.cases,properties:report.properties,initial,stack_capacity:stack,touched:stack-first,unused_stack:first});
  }
}
console.log(JSON.stringify(rows,null,2));
