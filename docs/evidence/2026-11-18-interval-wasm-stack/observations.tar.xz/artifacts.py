import io, json, hashlib, subprocess as sp
from pathlib import Path
s=Path(__file__).parent
metrics={}
def unsigned(stream):
    n=shift=0
    while True:
        b=stream.read(1)[0]
        n |= (b & 127)<<shift
        if b<128: return n
        shift+=7
def wasm(path):
    raw=path.read_bytes(); parts={}; stream=io.BytesIO(raw)
    assert stream.read(8)==b'\0asm\x01\0\0\0'
    while section:=stream.read(1):
        n=unsigned(stream); block=stream.read(n); assert len(block)==n
        if section==b'\0':
            chunk=io.BytesIO(block)
            name=chunk.read(unsigned(chunk)).decode()
        else:name=str(section[0])
        assert name not in parts
        parts[name]={'bytes':n,'sha256':hashlib.sha256(block).hexdigest()}
    return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),sections=parts)
names={'float':'float_wasm_conformance','layout':'layout_wasm','dyadic':'dyadic_wasm_conformance','real_bridge':'real_bridge_wasm_conformance'}
for alias,name in names.items():
    raw=f'interval_{name}.wasm';out=f'interval_{alias}.wasm'
    n={stage:wasm(p) for stage,p in {
        'checkout_previous':s/'old-unknown/wasm32-unknown-unknown/release'/raw,
        'checkout_candidate':s/'final-1.95.0-wasm32-unknown-unknown'/out,
        'checkout_retained':s/'retained-1.95.0'/out,
        'scratch_previous':s/'matched-original'/raw,
        'scratch_candidate':s/'matched-qualified'/raw,
        'p1_previous_refusal_or_control':s/'control-target/wasm32-wasip1/release'/raw,
        'p1_candidate':s/'final-1.95.0-wasm32-wasip1'/out,
    }.items()}
    assert n['checkout_previous']==n['checkout_retained']
    metrics[alias]=n
    for pair in ['checkout','scratch']:
        old,new=[n[pair+'_'+k] for k in ['previous','candidate']]
        print(pair,alias,'file delta',new['bytes']-old['bytes'],'section length changes',
            {k:v['bytes']-old['sections'][k]['bytes'] for k,v in new['sections'].items() if v['bytes']!=old['sections'][k]['bytes']})
(s/'logs/artifacts.json').write_text(json.dumps(metrics,indent=2)+'\n')
for n in ['old','new']:
    p=s/('float-cost-'+n)
    print(n,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),sp.check_output(['size',p],text=True).splitlines()[1])
