from pathlib import Path
import json
s=Path(__file__).resolve().parent
dest=s/'matched'
def get(stage,f):return json.loads((dest/stage/f).read_text())
hist=json.loads((s/'history-library.json').read_text())
stages=['fixed','preceding','candidate']
rows={};fail=[]
def check(f,name,metric,fixed,previous,candidate,prior=0):
    prior=max(prior,0,previous-fixed);delta=candidate-previous
    inc=max(0,delta);cum=prior+inc
    cap=min(4096,previous//100); total=min(8192,fixed*2//100)
    if inc and (inc>cap or cum>total):fail.append([f,name,metric,inc,cum,cap,total])
    return dict(fixed=fixed,previous=previous,candidate=candidate,delta=delta,prior=prior,incremental_charge=inc,cumulative_charge=cum,
                incremental_cap=cap,cumulative_cap=total,remaining_incremental=max(0,cap-inc),remaining_cumulative=max(0,total-cum))
for compiler in ['1.95.0','stable']:
 for target in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
    tag=compiler+'-'+target;f=tag+'.json';fixed,b,c=[get(st,f) for st in stages]
    port=get('port-only',f) if target.startswith('wasm') else {}
    co=get('coordinator',f) if not port else {}
    examples=get('candidate',tag+'.examples.json')
    assert examples==get('preceding',tag+'.examples.json')
    out={'equal_example_hashes':{k:v['sha256'] for k,v in examples.items()},'artifacts':{}}
    for name,measures in c.items():
        if name=='hypersolve_sections':continue
        if name not in fixed:
            assert c[name]['sha256']==b[name]['sha256'],(tag,name)
            continue
        row={'charges':{},'capacity':67108864,'headroom':67108864-measures['file']}
        assert row['headroom']>=16777216
        if name in port:
            row['new_guest_replay']={k:port[name][k]-b[name][k] for k in ('file','code','functions')}
            assert measures['file']<=16777216
        for k in ('file','code','functions'):
            fixed_val=fixed[name][k];prev=b[name][k];cand=measures[k];prior=0
            if name=='hypersolve' and not port:
                metric={'code':'.text','functions':'functions'}.get(k,k)
                old=hist['matrix-'+compiler+'-all']['charged'].get(metric,{})
                prior=old.get('cumulative',0)
            if name in port:
                # Separate the bytes in the original, previously uncompiled guest test from transport overhead.
                prior=max(0,prev-fixed_val);prev=port[name][k]
                row['charges'][k]=check(tag,name,k,prev,prev,cand,prior)
            else:row['charges'][k]=check(tag,name,k,fixed_val,prev,cand,prior)
            if co:
                x=co[name][k];cap=min(16384,cand*2//100);added=max(0,x-cand)
                row.setdefault('coordinator',{})[k]=dict(ordinary=cand,candidate=x,delta=x-cand,cumulative_charge=added,cap=cap,remaining=cap-added)
                if added>cap:fail.append([tag,name,k,'coordinator',added,cap])
        if co:
            row['coordinator_headroom']=67108864-co[name]['file']
            if co[name]['file']>16777216:fail.append([tag,name,'coordinator capacity'])
        out['artifacts'][name]=row
    if co:
        a0,b0,c0=[d['hypersolve_sections'] for d in [fixed,b,c]]
        h=hist['matrix-'+compiler+'-all']['charged']
        out['library_allocated_sections']={k:check(tag,'hypersolve_sections',k,a0[k],b0[k],val,h.get('functions' if k=='function_union' else k,{}).get('cumulative',0)) for k,val in c0.items()}
    rows[tag]=out
for compiler in ('1.95.0','stable'):
 trace=[json.loads((s/'trace'/f'{stage}-{compiler}.json').read_text()) for stage in stages]
 a,b,c=trace;h=hist['matrix-'+compiler+'-trace']['charged']
 rows[compiler+'-x86_64-unknown-linux-gnu']['trace_library_sections']={
    k:check(compiler,'trace_library_sections',k,a[k],b[k],val,h.get('functions' if k=='function_union' else k,{}).get('cumulative',0)) for k,val in c.items()}
(s/'accounts-review.json').write_text(json.dumps({'targets':rows,'failures':fail},indent=2)+'\n')
for tag,out in rows.items(): print(tag,'ordinary max',max(q['incremental_charge'] for row in out['artifacts'].values() for q in row['charges'].values()), 'examples',len(out['equal_example_hashes']))
print('failures',fail)
