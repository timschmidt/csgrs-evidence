set -eu
. /dev/shm/interval-horner-readmission/env
v=$1
tag=$2
s=/dev/shm/interval-solver-library
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/full-wasi-$v"
python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$v" --output "$s/$tag-$v"
