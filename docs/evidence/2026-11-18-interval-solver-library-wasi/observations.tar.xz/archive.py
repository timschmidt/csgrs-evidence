from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-solver-library-wasi'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p):files[str(p.relative_to(d))]=p.read_bytes()
for p in d.iterdir():
 if p.is_file() and (p.suffix in ('.rs','.py','.sh','.json','.patch','.txt','.md') or p.name in ('scope','guest-list','source-revision')):add(p)
for folder in ('logs','trace','matched','limit-old-1.95.0','limit-old-stable','limit-retained-1.95.0','limit-retained-stable','dynamics-1.95.0','dynamics-stable','dynamics-retained-1.95.0','dynamics-retained-stable','word-width','mutant-observed','mutant-model-observed'):
 for p in (d/folder).rglob('*'):
    if p.is_file() and p.suffix not in ('.pyc','.errors'):add(p)
for v in ('1.95.0','stable'):
 assert (d/f'logs/quality-{v}.log').read_text().strip().endswith('PASS')
 assert (d/f'logs/post-edit-{v}.log').read_text().strip().endswith('PASS')
 assert (d/f'logs/owner-more-{v}.log').read_text().strip().endswith('PASS')
 for t in ('old','retained'):
    log=(d/f'logs/limit-{t}-{v}.log').read_text()
    assert 'memory.max 1073741824' in log and 'oom 0' in log and 'oom_kill 0' in log
    assert int(next(l.split()[-1] for l in log.splitlines() if l.startswith('memory.peak ')))<=768*1024**2
 report=json.loads((d/f'limit-retained-{v}/report.json').read_text())
 assert sum(len(c) for c in report['guest'].values())==1511
 assert sum(sum(c.values()) for c in report['fresh_replays'].values())==26
 assert sum(sum(c.values()) for c in report['replay_records'].values())==15
 assert sum(report['dispatch_windows'].values())==4212
 assert (d/f'logs/dynamics-retained-{v}.log').read_text().strip().endswith('141 direct WASI tests, 17 fresh WASI replay cases, 1 native thread test.')
sets=[{p.name:p.read_bytes() for p in (d/f'limit-retained-{v}').glob('*.records.jsonl')} for v in ('1.95.0','stable')]
assert sets[0]==sets[1] and len(sets[0])==8
assert sum(len(json.loads(line)) for value in sets[0].values() for line in value.splitlines())==15
assert not json.loads((d/'accounts-review.json').read_text())['failures']
assert 'No findings to report' in (d/'logs/zizmor.log').read_text()
assert '0 passed; 1 failed' in next((d/'mutant-model-observed').glob('*.log')).read_text()
assert 'word_bits=32' in (d/'logs/width-guest.log').read_text() and 'assertion' in (d/'logs/width-guest.log').read_text()
assert (d/'source-revision').read_text().strip()==git(r,'rev-parse','HEAD').decode().strip()
sha={k:h(v) for k,v in sorted(files.items())}
dest=d/'record';dest.mkdir(exist_ok=True)
with tarfile.open(dest/'observations.tar.xz','w:xz') as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(dest/'observations.tar.xz','r|xz') as t:assert {m.name:h(t.extractfile(m).read()) for m in t}==sha
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(sha,indent=1).encode()))
total=sum(p.stat().st_size for p in dest.iterdir())
assert shutil.disk_usage(e).free-(e/'.git/index').stat().st_size-3*total-1048576>20*1024**3
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(dest,e/record);git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive whole-solver WASI replays, bounded test memory and linked images')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in dest.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOTS={record:False};row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
print(rev,row,'members',len(sha))
