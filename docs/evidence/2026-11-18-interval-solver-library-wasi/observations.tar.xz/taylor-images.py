from metrics import metrics
from pathlib import Path
import sys,json,os,subprocess
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent;names=['program_taylor_composition','program_taylor_polynomial','program_taylor_model'];root=Path('/mnt/development/csgrs')
stage=sys.argv[1]
def measure(v):
 env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/full-wasi-'+v,'CARGO_BUILD_JOBS':'4'}
 for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
  with (s/'logs'/f'{stage}-{v}-{t}.log').open('w') as err:raw=subprocess.check_output(['cargo','+'+v,'test','--no-run','--release','--locked','--all-features','-p','hypersolve','--target',t,*(x for n in names for x in ('--test',n)),'--message-format=json'],cwd=root,text=True,env=env,stderr=err)
  out={r['target']['name']:metrics(Path(r['executable'])) for r in map(json.loads,raw.splitlines()) if r.get('executable')}
  (s/f'{stage}-{v}-{t}.json').write_text(json.dumps(out,indent=2)+'\n')
  a=json.loads((s/'baseline-images.json').read_text())[v+' '+t]
  print(v,t,[(n,{k:m[k]-a[n][k] for k in ['file','code','functions']}) for n,m in out.items()],flush=True)
with ThreadPoolExecutor(2) as pool:list(pool.map(measure,['1.95.0','stable']))
