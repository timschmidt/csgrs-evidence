//! Select the child that replays the source supplied by a native test parent.
macro_rules! replay_path {
    () => {
        match option_env!("HYPERSOLVE_REPLAY_DRIVER") {
            Some(driver) => std::io::Result::Ok(std::path::PathBuf::from(driver)),
            None => std::env::current_exe(),
        }
    };
}
pub(crate) use replay_path as path;
