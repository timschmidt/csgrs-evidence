from pathlib import Path
import json,re
s=Path(__file__).resolve().parent
d=Path('/mnt/development/csgrs/docs/research')
ref='docs/evidence/2026-11-18-interval-solver-library-wasi'
source=(s/'source-revision').read_text().strip()
def add(p,key,value):
 original=p.read_text();old=json.loads(original)
 assert key not in old and original.endswith('}\n')
 section=json.dumps(value,indent=2).splitlines()
 p.write_text(original.rstrip()[:-1].rstrip()+',\n  "'+key+'": '+section[0]+'\n'+'\n'.join('  '+t for t in section[1:])+'\n}\n')
 new=json.loads(p.read_text());assert new.pop(key)==value and new==old
account=json.loads((s/'accounts-review.json').read_text());assert not account['failures']
size={'source':source,'preceding':'486af4162','fixed':'c9f1f9ac5','evidence':ref,'benefit':'Complete solver WASI test inventories, source replay and native/guest comparisons of exact results and work records.',
'capacity_bytes':67108864,'required_free_bytes':16777216,'ordinary_caps':'4,096 bytes and 1% incremental, 8,192 bytes and 2% cumulative per final file, code and function metric. Historical allocated ELF section limits also apply to the native library tests under all features and dispatch-trace.',
'new_replay_cases':'Previously excluded WASI vertical-component and field-resultant replay assertions are compiled independently as a control. The new test workload has a 16 MiB executable ceiling. Its measured addition to the existing qualification file and its residual transport cost are both retained.',
'coordinator_caps':'Optional native test driver up to 16,384 bytes and 2% over its ordinary binary per metric, with a 16 MiB absolute executable ceiling.',
'accounting':'Full fixed, preceding, port-only, retained and coordinator measures, historical positive charges, effective caps, headroom, and remaining allowances are hash-bound in accounts-review.json. Existing charges carry forward. Each target summary gives maximum incremental charge across ordinary workloads separately by metric. The exhaustive positive accounts in the archive are the input for future cumulative reviews.',
'metrics':['file','code','functions'],'targets':{}}
for tag,data in account['targets'].items():
 group=list(data['artifacts'].values())
 row={'compared_artifacts':len(group),'matching_release_examples':len(data['equal_example_hashes']),'max_incremental_charges':[max(x['charges'][m]['incremental_charge'] for x in group) for m in size['metrics']],'minimum_slot_headroom':min(x['headroom'] for x in group)}
 port={n:[q['new_guest_replay'][m] for m in size['metrics']] for n,q in data['artifacts'].items() if 'new_guest_replay' in q}
 if port:row['new_assertion_workload_bytes']=port
 else:row['max_coordinator_charges']=[max(x['coordinator'][m]['cumulative_charge'] for x in group) for m in size['metrics']]
 size['targets'][tag]=row
add(d/'interval-size-accounts.json','whole_solver_wasi_replay',size)
memory={'source':source,'evidence':ref,'workload':'Compiled 70-executable Hypersolve qualification job on Linux. Warm Cargo lookup, native and WASI libtest, Python, Node, children, assertion output and cleanup in one fresh cgroup v2 per compiler and workload. Swap disabled.',
'capacity_bytes':1073741824,'required_headroom_bytes':268435456,'positive_charges':'New qualification workload. Record its full observed peak against its own capacity. The preceding run executed 64 direct tests and the two migration comparisons. Its separate reference peak measures the change in the CI job. No production allocation or stack allowance is spent. Cold compilation is outside this observation.','targets':{}}
for compiler in ['1.95.0','stable']:
 row={}
 for stage in ['old','retained']:
  text=(s/f'logs/limit-{stage}-{compiler}.log').read_text()
  assert re.search(r'^memory.max 1073741824$',text,re.M) and re.search(r'^memory.swap.max 0$',text,re.M)
  assert all(re.search(r'^'+metric+r' 0$',text,re.M) for metric in ['oom','oom_kill','max'])
  row[stage+'_peak_bytes']=int(re.search(r'^memory.peak (\d+)',text,re.M)[1])
  times=[float(x) for x in re.findall(r'^\d{10}\.\d+$',text,re.M)];row[stage+'_wall_seconds']=round(times[1]-times[0],3)
 row['increase_over_preceding_job_bytes']=row['retained_peak_bytes']-row['old_peak_bytes']
 row['headroom_bytes']=memory['capacity_bytes']-row['retained_peak_bytes'];assert row['headroom_bytes']>=memory['required_headroom_bytes']
 memory['targets'][compiler]=row
add(d/'interval-memory-accounts.json','whole_solver_wasi_qualification',memory)
(s/'registration.json').write_text(json.dumps({'size':size,'memory':memory},indent=2)+'\n')
