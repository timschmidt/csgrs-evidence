from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,shutil,subprocess,sys,json
from metrics import metrics
s=Path(__file__).resolve().parent
root=Path('/mnt/development/csgrs')
w=s/'matched-src';stage=sys.argv[1];w.mkdir(exist_ok=True)
if stage in ('fixed','preceding'):
 subprocess.run(['tar','-xm','-C',w],input=subprocess.check_output(['git','archive','c9f1f9ac5' if stage=='fixed' else '486af4162'],cwd=root),check=True)
 if stage=='fixed':
  p=w/'crates/hypersolve/Cargo.toml';current=(root/'crates/hypersolve/Cargo.toml').read_text()
  old=p.read_text();a=old.index('[dev-dependencies]');b=old.index('[features]',a)
  p.write_text(old[:a]+current[current.index('[dev-dependencies]'):current.index('[features]')]+old[b:])
if stage=='candidate':
 for p in (root/'crates/hypersolve/tests').rglob('*.rs'):
  dst=w/p.relative_to(root)
  if not dst.exists() or p.read_bytes()!=dst.read_bytes():shutil.copyfile(p,dst)
 p=Path('crates/hypersolve/src/work_budget/tests.rs')
 if (w/p).read_bytes()!=(root/p).read_bytes():shutil.copyfile(root/p,w/p)
dest=s/'matched'/stage;dest.mkdir(exist_ok=True,parents=True)
selected=['bivariate_vertical_components','expression_program','ordered_field_resultant','program_composition','program_coordinates','program_jacobian','program_taylor_affine','program_taylor_composition','program_taylor_model','program_taylor_polynomial','selected_chamfer_enclosure','selected_polynomial_fields','selected_polynomial_join_retention','selected_polynomial_replay','selected_polynomial_root_discovery','trivariate_arithmetic']
def build(v):
 env=os.environ|{'CARGO_TARGET_DIR':str(s/('matched-target-'+v)),'CARGO_BUILD_JOBS':'6'}
 for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']:
  if stage=='coordinator' and t.startswith('wasm'):continue
  if stage=='coordinator':env['HYPERSOLVE_REPLAY_DRIVER']=str(root/'crates/hyperinterval/conformance/wasi-solver.py')
  names=[n for n in selected if (w/f'crates/hypersolve/tests/{n}.rs').exists() and not (stage=='fixed' and t.startswith('wasm') and n=='trivariate_arithmetic')]
  args=['cargo','+'+v,'test','--no-run','--locked','--release','-p','hypersolve','--all-features','--target',t,'--lib',*(part for n in names for part in ('--test',n)),'--message-format=json']
  p=dest/f'{v}-{t}';log=Path(str(p)+'.log')
  with log.open('w') as err:
   result=subprocess.run(args,cwd=w,env=env,stdout=subprocess.PIPE,stderr=err,text=True)
  if result.returncode:
   Path(str(p)+'.errors').write_text(result.stdout);result.check_returncode()
  rows=[r for r in map(json.loads,result.stdout.splitlines()) if r.get('executable')]
  out={r['target']['name']:metrics(Path(r['executable'])) for r in rows}
  if t.startswith('x86'):
   sys.path.insert(0,str(s));from image_metrics import sizes
   out['hypersolve_sections']=sizes(Path(next(r['executable'] for r in rows if r['target']['name']=='hypersolve')))
  Path(str(p)+'.json').write_text(json.dumps(out,indent=2)+'\n')
  if stage in ('preceding','candidate'):
   exargs=['cargo','+'+v,'build','--locked','--release','-p','hypersolve','--all-features','--target',t,'--examples','--message-format=json']
   with Path(str(p)+'.examples.log').open('w') as err:
    text=subprocess.check_output(exargs,cwd=w,env=env,stderr=err,text=True)
   outputs={r['target']['name']:metrics(Path(r['executable'])) for r in map(json.loads,text.splitlines()) if r.get('executable')}
   Path(str(p)+'.examples.json').write_text(json.dumps(outputs,indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(build,['1.95.0','stable']))
