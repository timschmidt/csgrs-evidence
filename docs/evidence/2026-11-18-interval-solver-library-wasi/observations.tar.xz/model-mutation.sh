set -eu
s=/dev/shm/interval-solver-library
r=/mnt/development/csgrs
. /dev/shm/interval-horner-readmission/env
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR="$s/mutant-target"
cd "$s/mutant-src"
cp "$r/crates/hypersolve/tests/program_taylor_model.rs" crates/hypersolve/tests/
cp "$r/crates/hypersolve/tests/support/replay_binary.rs" crates/hypersolve/tests/support/
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hypersolve/tests/program_taylor_model.rs');s=p.read_text()
orig='"MODEL {model:?} work {} {}",\n            gb.remaining_work(),'
assert s.count(orig)==1
p.write_text(s.replace(orig,orig.replace('gb.remaining_work()','gb.remaining_work() + 1')))
PY
cargo +1.95.0 test --locked --release --all-features -p hypersolve --test program_taylor_model --no-run --target wasm32-wasip1 --message-format=json > "$s/mutant-model.jsonl"
cd "$r"
python3 - <<'PY'
import importlib.util,json,sys,os
from pathlib import Path
s=Path('/dev/shm/interval-solver-library');d=Path('crates/hyperinterval/conformance').resolve();sys.path.insert(0,str(d))
spec=importlib.util.spec_from_file_location('solver',d/'wasi-solver.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
g=next(x['executable'] for x in map(json.loads,(s/'mutant-model.jsonl').read_text().splitlines()) if x.get('executable'))
env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/full-wasi-1.95.0','HYPERSOLVE_REPLAY_DRIVER':str(d/'wasi-solver.py')}
host=m.build_tests(['cargo','+1.95.0','test','--locked','--release','-p','hypersolve','--all-features'],['--test','program_taylor_model'],env)['program_taylor_model']
case='fresh_process_replay_rebuilds_source_coefficients_and_remainder';_,key,count=m.REPLAYS['program_taylor_model'][case]
out=s/'mutant-model-observed';out.mkdir()
try:m.run_parent(out,'program_taylor_model',case,case,key,count,g,host)
except SystemExit:pass
else:raise RuntimeError('mutated Taylor work receipt accepted')
t=(out/f'program_taylor_model.{case}.log').read_text()
assert 'records differ. Native' in t and '0 passed; 1 failed;' in t
assert (out/f'program_taylor_model.{case}.children').read_text().splitlines()==[case]
print('The guest completed the Taylor proof; differential replay rejected its one-unit work-counter mutation.')
PY
