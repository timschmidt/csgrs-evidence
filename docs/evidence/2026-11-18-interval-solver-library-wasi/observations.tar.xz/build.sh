set -eu
s=/dev/shm/interval-solver-library
. /dev/shm/interval-horner-readmission/env
v=$1
export CARGO_BUILD_JOBS=8 CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/full-wasi-$v"
for t in wasm32-wasip1 x86_64-unknown-linux-gnu;do
 cargo +"$v" test --locked --release -p hypersolve --all-features --lib --tests --no-run --target "$t" --message-format=json > "$s/$v-$t.jsonl" 2> "$s/logs/$v-$t-build.log"
done
