from concurrent.futures import ThreadPoolExecutor
from subprocess import run,STDOUT,PIPE
from pathlib import Path
import json,sys,re
s=Path(__file__).resolve().parent
v=sys.argv[1]
records=list(map(json.loads,(s/(v+'-wasm32-wasip1.jsonl')).read_text().splitlines()))
assert records[-1].get('success') is True
guests={r['target']['name']:r['executable'] for r in records if r.get('executable') and 'test' in r['target']['kind']}
node='/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node'
runner=Path('/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs')
def probe(item):
 suite,g=item
 cmd=[node,runner,g]
 listing=run(cmd+['--list'],capture_output=True,text=True,check=True).stdout
 names=re.findall(r'^(\S+): test$',listing,re.M)
 # Let each WASI module complete as many unmodified cases as possible, including after an abort.
 remaining=names[:];fail={};passed=[]
 for i in range(len(names)):
  if not remaining:break
  log=s/'logs'/f'{v}-integration-{suite}-{i}.log'
  with log.open('w') as out:
   status=run(cmd+['--test-threads=1','--exact',*remaining],stdout=out,stderr=STDOUT).returncode
  t=log.read_text()
  got=re.findall(r'^test (\S+) \.\.\. ok$',t,re.M)
  passed+=got
  remaining=[n for n in remaining if n not in got]
  if not status:
   assert not remaining,(suite,remaining)
   break
  bad=re.findall(r'^test (\S+) \.\.\.',t,re.M)[-1]
  assert bad in remaining,(bad,suite)
  remaining.remove(bad)
  fail[bad]=[x for x in t.splitlines() if 'Unsupported' in x or 'panicked' in x or 'fatal error' in x or 'Error:' in x][:4]
 return suite,{'count':len(names),'passed':len(passed),'failed':fail}
with ThreadPoolExecutor(5) as pool: out=dict(pool.map(probe,guests.items()))
(s/(v+'-integrations.json')).write_text(json.dumps(out,indent=2)+'\n')
print(len(out),sum(m['count'] for m in out.values()),sum(m['passed'] for m in out.values()))
for k,m in out.items():
 if m['failed']:print(k, list(m['failed']))
