set -eu
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-solver-library
v=$1
export CARGO_BUILD_JOBS=5 CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/matrix-x86_64-unknown-linux-gnu-$v" CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 HYPERSOLVE_SKIP_BENCHMARK_REPORTS=1
cargo +"$v" check --locked -p hypersolve --all-targets --all-features
cargo +"$v" test --locked -p hypersolve --no-default-features
cargo +"$v" test --locked -p hypersolve --all-targets --all-features
cargo +"$v" run --locked -p hypersolve --no-default-features --example krawczyk_certificate
cargo +"$v" check --locked --manifest-path crates/hypersolve/fuzz/Cargo.toml --bins
cargo +"$v" clippy --locked --manifest-path crates/hypersolve/fuzz/Cargo.toml --bin hyperreal_representations -- -D warnings
echo PASS
