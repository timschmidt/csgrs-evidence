set -eu
s=/dev/shm/interval-solver-library
r=/mnt/development/csgrs
. /dev/shm/interval-horner-readmission/env
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" CARGO_BUILD_JOBS=4 CARGO_TARGET_DIR="$s/mutant-target"
mkdir "$s/mutant-src"
git -C "$r" archive 486af4162 | tar -xm -C "$s/mutant-src"
cd "$s/mutant-src"
cp "$r/crates/hypersolve/tests/expression_program.rs" crates/hypersolve/tests/
cp "$r/crates/hypersolve/tests/support/replay_binary.rs" crates/hypersolve/tests/support/
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hypersolve/tests/expression_program.rs');s=p.read_text()
a=s.index('fn replay_child()');b=s.index('let Some(path)',a)
i=s.index('program.eval_real(&[Real::from(5)]',b)
p.write_text(s[:i]+s[i:].replace('program.eval_real(&[Real::from(5)]','program.eval_real(&[Real::from(6)]',1))
PY
cargo +1.95.0 test --release --locked --all-features -p hypersolve --test expression_program --no-run --target wasm32-wasip1 --message-format=json > "$s/mutant.jsonl"
cd "$r"
python3 - <<'PY'
import importlib.util,json,sys
from pathlib import Path
s=Path('/dev/shm/interval-solver-library')
p=Path('crates/hyperinterval/conformance').resolve()
sys.path.insert(0,str(p));spec=importlib.util.spec_from_file_location('solver',p/'wasi-solver.py')
solver=importlib.util.module_from_spec(spec);spec.loader.exec_module(solver)
g=next(x['executable'] for x in map(json.loads,(s/'mutant.jsonl').read_text().splitlines()) if x.get('executable'))
from subprocess import check_output
env=__import__('os').environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-univariate-proof/full-wasi-1.95.0','HYPERSOLVE_REPLAY_DRIVER':str(p/'wasi-solver.py')}
hosts=solver.build_tests(['cargo','+1.95.0','test','--release','--locked','-p','hypersolve','--all-features'],['--test','expression_program'],env)
case='fresh_process_replay_retains_symbolic_constants_and_revalidates_edges'
child,key,count=solver.REPLAYS['expression_program'][case]
out=s/'mutant-observed';out.mkdir()
try:solver.run_parent(out,'expression_program',case,child,key,count,g,hosts['expression_program'])
except SystemExit:pass
else:raise RuntimeError('changed guest result accepted')
log=(out/f'expression_program.{case}.log').read_text()
assert 'assertion `left == right` failed' in log and '0 passed; 1 failed;' in log
assert (out/f'expression_program.{case}.children').read_text().splitlines()==[child]
print('The altered WASI child completed; the original native parent rejected its emitted scalar.')
PY
