from pathlib import Path
r=Path('crates/hypersolve/tests')
for f in sorted(r.glob('*.rs')):
 text=f.read_text()
 if 'std::env::current_exe().unwrap()' not in text:continue
 cfg=''
 if f.stem=='expression_program':cfg='#[cfg(any(feature = "serde", feature = "dispatch-trace"))]\n'
 elif f.stem.startswith('program_'):cfg='#[cfg(feature = "serde")]\n'
 if f.stem in ('ordered_field_resultant','bivariate_vertical_components'):
  text=text.replace('not(target_arch = "wasm32")','any(not(target_arch = "wasm32"), target_os = "wasi")')
  cfg='#[cfg(any(not(target_arch = "wasm32"), target_os = "wasi"))]\n'
 lines=text.splitlines(keepends=True)
 i=0
 while i<len(lines) and lines[i].startswith(('//!','#![','\n')):i+=1
 lines.insert(i,cfg+'#[path = "support/replay_binary.rs"]\nmod replay_binary;\n\n')
 text=''.join(lines).replace('std::env::current_exe().unwrap()', 'replay_binary::path().unwrap()')
 f.write_text(text)
