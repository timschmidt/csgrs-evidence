from pathlib import Path
import json,os,subprocess,shutil
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');w=s/'matched-src';dest=s/'inspect';dest.mkdir(exist_ok=True)
env=os.environ|{'CARGO_TARGET_DIR':str(s/'matched-target-stable'),'CARGO_BUILD_JOBS':'6'}
for stage in ['baseline','alias']:
 for n in ['program_taylor_composition','program_taylor_polynomial']:
  p=Path('crates/hypersolve/tests')/(n+'.rs')
  raw=subprocess.check_output(['git','show','486af4162:'+str(p)],cwd=r,text=True)
  if stage=='alias':raw=raw.replace('std::env::current_exe().unwrap()', 'replay_binary::path().unwrap()')+'\n#[cfg(feature = "serde")]\n#[path = "support/replay_binary.rs"]\nmod replay_binary;\n'
  (w/p).write_text(raw)
 (w/'crates/hypersolve/tests/support/replay_binary.rs').write_bytes((s/'alias.rs').read_bytes())
 args=['cargo','+stable','test','--locked','--release','-p','hypersolve','--all-features','--test','program_taylor_composition','--test','program_taylor_polynomial','--no-run','--target','x86_64-unknown-linux-gnu','--message-format=json']
 with (dest/(stage+'.log')).open('w') as err:raw=subprocess.check_output(args,cwd=w,env=env,stderr=err,text=True)
 for row in map(json.loads,raw.splitlines()):
  if row.get('executable'):shutil.copyfile(row['executable'], dest/(stage+'-'+row['target']['name']))
