import json,sys,os,importlib.util
from pathlib import Path
root=Path('/mnt/development/csgrs')
s=Path(__file__).resolve().parent;v=sys.argv[1];tag=sys.argv[2]
d=root/'crates/hyperinterval/conformance';sys.path.insert(0,str(d))
spec=importlib.util.spec_from_file_location('solver',d/'wasi-solver.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=['cargo','+'+v,'test','--release','--locked','-p','hypersolve','--all-features']
selection=[a for k in m.REPLAYS for a in ('--test',k)]
env=os.environ.copy();env.pop('HYPERSOLVE_REPLAY_DRIVER',None)
gs=m.build_tests([*base,'--target',m.TARGET],selection,env);hs=m.build_tests(base,selection,env|{'HYPERSOLVE_REPLAY_DRIVER':str(d/'wasi-solver.py')})
out=s/f'{tag}-{v}';out.mkdir()
for suite,cases in m.REPLAYS.items():
 for parent,(child,key,count) in cases.items():
  if key in m.RECORDS:m.run_parent(out,suite,parent,child or parent,key,count,gs[suite],hs[suite])
print('All emitted source-replay records matched.')
