import json,hashlib,sys,subprocess
from pathlib import Path
s=Path(__file__).resolve().parent
sys.path.insert(0,'/dev/shm/interval-scalar-wasi')
src=Path('/dev/shm/interval-univariate-proof/history/sizes.py')
import importlib.util
spec=importlib.util.spec_from_file_location('metrics',src);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
