set -euo pipefail
. /dev/shm/interval-horner-readmission/env
s=/dev/shm/interval-solver-library
mkdir "$s/fixed-src"
git archive c9f1f9ac5 | tar -xm -C "$s/fixed-src"
cd "$s/fixed-src"
python3 - <<'PY'
from pathlib import Path
p=Path('crates/hypersolve/Cargo.toml');text=p.read_text()
text=text.replace('\ncriterion = "0.5"\n','\n')
spot=text.index('\n[features]')
text=text[:spot]+'''
[target.'cfg(target_os = "wasi")'.dev-dependencies]
criterion = { version = "0.5", default-features = false, features = ["plotters", "cargo_bench_support"] }

[target.'cfg(not(target_os = "wasi"))'.dev-dependencies]
criterion = "0.5"
'''+text[spot:]
p.write_text(text)
PY
for v in 1.95.0 stable;do (
 export CARGO_TARGET_DIR="$s/fixed-target-$v" CARGO_BUILD_JOBS=8
 targets=(--lib --examples)
 for f in crates/hypersolve/tests/*.rs; do
  n=$(basename "$f" .rs)
  case "$n" in program_composition|program_coordinates|program_jacobian|program_taylor_affine|program_taylor_composition|program_taylor_model|program_taylor_polynomial|expression_program|ordered_field_resultant|bivariate_vertical_components|selected_chamfer_enclosure|selected_polynomial_fields|selected_polynomial_join_retention|selected_polynomial_replay|selected_polynomial_root_discovery) targets+=(--test "$n");; esac
 done
 for t in wasm32-wasip1 x86_64-unknown-linux-gnu;do
  cargo +"$v" test --release --locked -p hypersolve --all-features "${targets[@]}" --target "$t" --no-run --message-format=json > "$s/fixed-$v-$t.jsonl" 2> "$s/logs/fixed-$v-$t.log"
 done
 ) & done
fail=0;for job in $(jobs -p);do wait "$job" || fail=1;done;exit "$fail"
