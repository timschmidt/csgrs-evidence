//! Compare the complete model and work record from two fresh test processes.
#[path = "replay_binary.rs"]
mod replay_binary;

pub fn assert_repeatable(case: &str, input_key: &str, source: &str) {
    let record = || {
        let output = std::process::Command::new(replay_binary::path().unwrap())
            .args(["--exact", case, "--nocapture"])
            .env(input_key, source)
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        String::from_utf8(output.stdout)
            .unwrap()
            .lines()
            .find(|line| line.starts_with("MODEL "))
            .expect("the child emits its reconstructed model and work counts")
            .to_owned()
    };
    assert_eq!(record(), record());
}
