//! Select the child that replays the source supplied by a native test parent.
use std::{io, path::PathBuf};

#[inline]
pub fn path() -> io::Result<PathBuf> {
    match option_env!("HYPERSOLVE_REPLAY_DRIVER") {
        Some(driver) => Ok(PathBuf::from(driver)),
        None => std::env::current_exe(),
    }
}
