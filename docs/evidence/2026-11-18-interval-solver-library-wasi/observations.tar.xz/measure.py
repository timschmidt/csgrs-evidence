import sys,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from metrics import metrics
s=Path(__file__).resolve().parent
stage=sys.argv[1]
def group(job):
 v,t=job
 rows=[json.loads(l) for l in (s/f'{v}-{t}.jsonl').read_text().splitlines()]
 assert rows[-1]['success']
 names={r['target']['name']:Path(r['executable']) for r in rows if r.get('executable') and r['profile']['test']}
 return v+' '+t,{name:metrics(p) for name,p in sorted(names.items())}
with ThreadPoolExecutor(4) as pool: out=dict(pool.map(group,[(v,t) for v in ['1.95.0','stable'] for t in ['x86_64-unknown-linux-gnu','wasm32-wasip1']]))
(s/(stage+'-images.json')).write_text(json.dumps(out,indent=2)+'\n')
