set -eu
s=/dev/shm/interval-solver-library
v=$1
stage=$2
r=/mnt/development/csgrs
. /dev/shm/interval-horner-readmission/env
export PATH="/dev/shm/interval-dynamics-wasi/v24.22.3/bin:$PATH" PYTHONDONTWRITEBYTECODE=1 CARGO_BUILD_JOBS=8
if test "$stage" = old;then
 export CARGO_TARGET_DIR="$s/control-target-$v"
 cd "$s/control-src"
else
 export CARGO_TARGET_DIR="/dev/shm/interval-univariate-proof/full-wasi-$v"
 cd "$r"
fi
group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
printf 'memory.max ';cat "$group/memory.max"
printf 'memory.swap.max ';cat "$group/memory.swap.max"
date -u +%s.%N
python3 crates/hyperinterval/conformance/wasi-solver.py --toolchain "$v" --output "$s/limit-$stage-$v"
date -u +%s.%N
printf 'memory.peak ';cat "$group/memory.peak"
printf 'memory.current ';cat "$group/memory.current"
cat "$group/memory.events"
