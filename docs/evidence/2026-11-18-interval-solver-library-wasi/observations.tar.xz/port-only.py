from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json,os,subprocess
from metrics import metrics
s=Path(__file__).resolve().parent;w=s/'matched-src';r=Path('/mnt/development/csgrs');dest=s/'matched/port-only';dest.mkdir()
names=['ordered_field_resultant','bivariate_vertical_components']
for n in names:
 p=Path('crates/hypersolve/tests')/(n+'.rs'); original=subprocess.check_output(['git','show','486af4162:'+str(p)],cwd=r,text=True)
 (w/p).write_text(original.replace('not(target_arch = "wasm32")','any(not(target_arch = "wasm32"), target_os = "wasi")'))
def build(v):
 env=os.environ|{'CARGO_TARGET_DIR':str(s/('matched-target-'+v)),'CARGO_BUILD_JOBS':'4'}
 args=['cargo','+'+v,'test','--locked','--no-run','--release','--all-features','-p','hypersolve','--target','wasm32-wasip1',*(x for n in names for x in ('--test',n)),'--message-format=json']
 p=dest/f'{v}-wasm32-wasip1'
 with Path(str(p)+'.log').open('w') as err:raw=subprocess.check_output(args,cwd=w,env=env,stderr=err,text=True)
 rows=[r for r in map(json.loads,raw.splitlines()) if r.get('executable')]
 Path(str(p)+'.json').write_text(json.dumps({r['target']['name']:metrics(Path(r['executable'])) for r in rows},indent=2)+'\n')
with ThreadPoolExecutor(2) as pool:list(pool.map(build,['1.95.0','stable']))
