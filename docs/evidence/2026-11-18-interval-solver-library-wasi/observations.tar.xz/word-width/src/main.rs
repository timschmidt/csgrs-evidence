use hypersolve::work_budget::{observe_coefficient_bits, with_coefficient_bit_limit, WorkKind};
fn main() {
    let limit = 1_u64 << 32;
    let requested = limit + 1;
    let attempt = with_coefficient_bit_limit(limit, || observe_coefficient_bits(requested));
    let error = attempt.result.unwrap_err();
    assert_eq!(error.kind, WorkKind::CoefficientGrowth);
    println!("word_bits={} limit={limit} requested={requested} receipt={error}", usize::BITS);
    assert_eq!((error.limit as u64, error.requested as u64), (limit, requested));
}
