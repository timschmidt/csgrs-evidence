import json,os,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from image_metrics import sizes
s=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');w=s/'trace-src'
w.mkdir();dest=s/'trace';dest.mkdir()
for stage in ('fixed','preceding','candidate'):
 rev='c9f1f9ac5' if stage=='fixed' else '486af4162'
 if stage=='candidate':
  p=Path('crates/hypersolve/src/work_budget/tests.rs');(w/p).write_bytes((r/p).read_bytes())
 else:subprocess.run(['tar','-xm','-C',w],input=subprocess.check_output(['git','archive',rev],cwd=r),check=True)
 def run(v):
  env=os.environ|{'CARGO_TARGET_DIR':str(s/('trace-target-'+v)),'CARGO_BUILD_JOBS':'5'}
  cmd=['cargo','+'+v,'test','--release','--locked','-p','hypersolve','--lib','--features','dispatch-trace','--no-run','--message-format=json']
  with (dest/f'{stage}-{v}.log').open('w') as err:raw=subprocess.check_output(cmd,cwd=w,env=env,text=True,stderr=err)
  p=next(Path(row['executable']) for row in map(json.loads,raw.splitlines()) if row.get('executable'))
  (dest/f'{stage}-{v}.json').write_text(json.dumps(sizes(p),indent=2)+'\n')
 with ThreadPoolExecutor(2) as pool:list(pool.map(run,['1.95.0','stable']))
