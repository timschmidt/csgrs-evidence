from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from subprocess import run,STDOUT
import sys,json,re
d=Path(__file__).resolve().parent
root=Path('/mnt/development/csgrs')
v=sys.argv[1]
g=next(Path('/dev/shm/interval-univariate-proof/full-wasi-'+v+'/wasm32-wasip1/release/deps').glob('hypersolve-*.wasm'))
command=['/dev/shm/interval-dynamics-wasi/v24.22.3/bin/node',root/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs',g]
names=re.findall(r'^(\S+): test$',(d/'guest-list').read_text(),re.M)
exception=[n for n in names if any(k in n for k in ['dispatch_differential','from_another_thread','threads_start_without','scopes_restore_after_unwinding'])]
modules=sorted({n.split('::')[0]+'::' for n in names})
def run_case(k):
 args=[k,'--exact','--nocapture'] if k in exception else [k,'--test-threads=1',*(item for name in exception for item in ('--skip',name))]
 path=d/'logs'/(v+'-probe-'+k.replace(':','.')+'.log')
 with path.open('w') as f:
  p=run([*command,*args],stdout=f,stderr=STDOUT)
 t=path.read_text()
 return [k,p.returncode,t.count(' ... ok\n'),t[-400:]]
with ThreadPoolExecutor(8) as ex:
 rows=list(ex.map(run_case,modules+exception))
(d/(v+'-discovery.json')).write_text(json.dumps(rows,indent=2)+'\n')
for n,r,c,t in rows:
 if r:print(n,r,t[-120:])
