import os,sys,subprocess,json,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent;root=s/'src';sys.path.insert(0,str(root/'crates/hyperinterval/conformance'))
from wasi_libtest import build_tests,execute,completed,RUNNER
sys.path.insert(0,'/dev/shm/interval-budget-receipt');from metrics import metrics
stage=sys.argv[1]
replays=dict(dyadic_zero_grid='fresh_process_replay_then_operation',fractional_power='exact_replay_then_further_power_in_fresh_process',integer_division='replayed_output_feeds_widening_and_further_division',split_division='replay_in_fresh_process',tangent='replay_then_another_pole_operation_in_fresh_process')
def build(v):
 sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr');host=os.environ|{'CARGO_TARGET_DIR':str(s/('target-'+v))};host.pop('HYPERINTERVAL_REPLAY_DRIVER',None)
 guest=host|{'CC':str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),'CC_FOR_BUILD':'cc','CPPFLAGS':'-D_WASI_EMULATED_SIGNAL','LIBS':'-lwasi-emulated-signal','GMP_MPFR_SYS_CACHE':str(Path('/dev/shm/interval-scalar-wasi')/('final-'+v)/'gmp-cache'),'CARGO_ENCODED_RUSTFLAGS':'-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a')}
 cargo=['cargo','+'+v,'test','--locked','--release','-p','hyperinterval']
 cargo+=['--all-features'] if v!='1.88.0' else ['--no-default-features','--features','integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace']
 selection=[k for n in replays for k in ('--test',n)]
 out={}
 for target,exe,env in [('wasm32-wasip1',cargo+['--target','wasm32-wasip1'],guest),('native',cargo,host)]+([('coordinator',cargo,host|{'HYPERINTERVAL_REPLAY_DRIVER':str(root/'crates/hyperinterval/conformance/wasi-tests.py')})] if stage not in ('base','fixed') else []):
  bins=build_tests(exe,selection,env);out[target]={n:metrics(Path(p)) for n,p in bins.items()}
  for n,case in replays.items():
   if target=='coordinator':continue
   cmd=['node',str(RUNNER),bins[n]] if target=='wasm32-wasip1' else [bins[n]]
   log=s/f'{stage}-{v}-{target}-{n}.log';run=execute([*cmd,'--exact',case,'--nocapture','--test-threads=1'],log)
   if target=='native':assert not run.returncode and completed(run.stdout,{case})
   else:assert run.returncode and 'kind: Unsupported' in run.stdout
 (s/f'{stage}-{v}.json').write_text(json.dumps(out,indent=1)+'\n')
with ThreadPoolExecutor(3) as pool:list(pool.map(build,('1.88.0','1.95.0','stable')))
