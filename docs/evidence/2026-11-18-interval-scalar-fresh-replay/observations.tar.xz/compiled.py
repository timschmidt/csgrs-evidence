"""Measure the five unmodified native parent invocations and the extra guest invocations separately."""
import os,json,sys,time
from pathlib import Path
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');sys.path.insert(0,str(r/'crates/hyperinterval/conformance'))
from wasi_libtest import execute,completed
v,stage=sys.argv[1:];dest=s/f'compiled-{v}-{stage}';dest.mkdir()
output=s/('accepted-'+v)
replays=json.loads((output/'report.json').read_text())['fresh_replays']
group=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
start=time.monotonic()
def one(d,pat):
 rows=[x for x in d.glob(pat) if x.is_file() and os.access(x,os.X_OK)];assert len(rows)==1,rows;return str(rows[0])
for suite,case in replays.items():
 base=s/('lint-'+v) if stage=='native' else output/'target'
 host=one(base/'release/deps',suite+'-*')
 guest=one(output/'target/wasm32-wasip1/release/deps',suite+'-*.wasm')
 receipt=dest/(suite+'.children')
 env=os.environ|{'SCALAR_WASI_RECEIPT':str(receipt),'SCALAR_WASI_SUITE':suite,'SCALAR_WASI_GUEST':guest}
 run=execute([host,'--exact',case,'--nocapture'],dest/(suite+'.log'),env)
 assert run.returncode==0 and completed(run.stdout,{case})
 if stage=='guest': assert receipt.read_text().splitlines()==[case]
 else: assert not receipt.exists()
print(json.dumps({'stage':stage,'cases':list(replays),'seconds':time.monotonic()-start,**{k:(group/k).read_text().strip() for k in ('memory.peak','memory.max','memory.swap.max','memory.events')}},indent=2))
