from pathlib import Path
import importlib.util,json
s=Path(__file__).parent
spec=importlib.util.spec_from_file_location('writer','/dev/shm/interval-budget-receipt/width-record.py')
writer=importlib.util.module_from_spec(spec);spec.loader.exec_module(writer);writer.s=s
items=set()
for glob in ('*.py','scope.md','env','*.sh','*.log','*.build','*.json','*.tsv','tangent-reference.c','source-revision','baseline','instrument/node','horner-current.patch','strong-*.rs','README.md','fixed-*.log','rays-*.log','base-*.log','strong-*.log','sources-*/*','compiled-*/*','lifetime/Cargo.toml','lifetime/Cargo.lock','lifetime/build.rs','lifetime/stack.c','lifetime/src/*.rs','horner-harness/*.lock','horner-harness/*.json','horner-harness/scope','horner-harness/*.py'):
 items.update(p for p in s.glob(glob) if p.is_file())
for stage in ('accepted','qualified','cold'):
 for v in ('1.88.0','1.95.0','stable'):
  group=s/(stage+'-'+v)
  items.update(p for p in group.iterdir() if p.is_file())
assert all((s/p) in items for p in ('horner-before.json','horner-after.json','life-review.json','source-revision','per-image.json','memory-entry.json'))
print(json.dumps(writer.record('scalar-fresh-replay',items,'Archive cross-target scalar replay qualification and current Horner readmission measurements')))
