from pathlib import Path
import hashlib,subprocess as sp,os,json
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).parent;h=Path('/dev/shm/interval-horner-readmission');w=s/'life-src';life=s/'lifetime'
p=w/'crates/hyperinterval/src/rational.rs';text=p.read_text()
old='// This two-add adapter must not add a call frame to its Horner consumers.\n#[inline(always)]\nfn translated_bounds'
assert text.count(old)==1
p.write_text(text.replace(old,'#[inline]\nfn translated_bounds'))
env=os.environ|{'CARGO_TARGET_DIR':str(s/'life-target'),'CARGO_BUILD_JOBS':'6'}
with (s/'life-plain.build').open('w') as log:sp.run(['cargo','+stable','build','--release','--locked','--manifest-path',life/'Cargo.toml'],env=env,stdout=log,stderr=sp.STDOUT,check=True)
def lane(i):
 for block in (i,i+4):
  with (s/f'life-plain-{block}.tsv').open('w') as f:sp.run(['taskset','-c',str(1+4*i),s/'life-target/release/horner-life-harness'],stdout=f,check=True,timeout=180)
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,range(4)))
rows={}
for i in range(8):
 lines=(s/f'life-plain-{i}.tsv').read_text().splitlines()
 assert len(lines)==1600
 seen=set()
 for line in lines:
  rep,case,warm,pattern,*metrics=line.split('\t');key=case,warm=='true'
  assert (rep,case,warm,pattern) not in seen;seen.add((rep,case,warm,pattern));rows.setdefault(key,[]).append(list(map(int,metrics)))
assert len(rows)==100 and all(len(x)==128 for x in rows.values())
data=json.loads((s/'life-review.json').read_text())
for q in data:
 plain=list(map(max,zip(*rows[q['case'],q['warm']])))
 q['ordinary_inline']=plain
 q['ordinary_increment']=[y-x for x,y in zip(q['before'],plain)]
 q['ordinary_cumulative']=[max(0,b-a)+max(0,c-b)+max(0,d-c) for a,b,c,d in zip(q['fixed'],q['historical_preceding'],q['before'],plain)]
 q['ordinary_incremental_failure']=q['ordinary_increment'][0]>min(32,q['before'][0]*.01) or any(x>0 for x in q['ordinary_increment'][1:])
 q['ordinary_cumulative_failure']=q['ordinary_cumulative'][0]>min(64,q['fixed'][0]*.02) or any(q['ordinary_cumulative'][1:])
(s/'life-both.json').write_text(json.dumps(data,indent=1)+'\n')
print('ordinary incremental failures',sum(q['ordinary_incremental_failure'] for q in data),'peak comparable increase',max(q['ordinary_increment'][0] for q in data))
