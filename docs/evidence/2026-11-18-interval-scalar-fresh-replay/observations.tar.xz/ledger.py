from pathlib import Path
import json
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
mem=json.loads((s/'memory-entry.json').read_text())['targets']
sizes=json.loads((s/'per-image.json').read_text())['rows']
data=json.loads((s/'life-both.json').read_text())
w=next(x for x in data if x['case']=='tensor-cardinal/true' and not x['warm'])
assert all(not x['incremental_failure'] and not x['cumulative_failure'] and not x['headroom_failure'] for x in data)
assert sum(x['ordinary_incremental_failure'] for x in data)==1 and w['ordinary_incremental_failure']
assert all(not any(x['increment'][1:]) and not any(x['ordinary_increment'][1:]) for x in data)
before,after=[json.loads((s/f'horner-{k}.json').read_text())['image'] for k in ('before','after')]
x=sizes['stable']['wasm32-wasip1']['fractional_power']['file'];assert x[4]==4057
record=json.loads((s/'archive-result').read_text());sha=record['row'].split('\t')[-1];assert len(sha)==64
ledger=r/'INTERVAL_REFACTOR_PROGRESS.md'
with ledger.open('a') as f:f.write(f"""
## Phases 3, 5, 7 and 14, scalar replay and bounded Horner review, 18 November 2026

Commit `88e11ea7b` exercises five native-produced scalar results in fresh
WASI guests. The native parent supplies the actual serialized fixed division,
dyadic grid, rational power, split division or tangent result. Each guest
performs the corresponding operation on the decoded value. The runner
requires a successful parent and one receipt from the named child.
The original native subprocess cases and the direct WASI probes still run.
[Scalar conformance runner](crates/hyperinterval/conformance/wasi-tests.py)

Before the stronger assertions, both the fractional-power and tangent cases
accepted the canonical empty set. The split-division, power and tangent cases
also accepted another operation’s pair of rays. The retained tests check
component counts, exact endpoints and the subsequent operation. Directed
256-bit MPFR independently determines the two finite tangent endpoints.
Across all three compilers the five genuine payloads agreed byte for byte,
and all thirteen substitutions per compiler were rejected on both targets.
The substitutions include malformed JSON, unrelated canonical intervals
and an extra dyadic grid entry.

| Rust release | Direct guest tests | OS-dependent native cases | Extra fresh guests | Warm whole-job peak |
| --- | ---: | ---: | ---: | ---: |
""")
with ledger.open('a') as f:
 for label,k in [('1.88','1.88.0'),('1.95','1.95.0'),('1.99','stable')]:
  a=mem[k];f.write(f"| {label} | {a['direct_guest_passes']} | {a['native_os_cases']} | {a['fresh_guest_replays']} | {a['measured_whole_job_bytes']:,} B |\n")
 f.write(f"""
The two Hyperreal-enabled configurations also matched all 450 ordered
rational dispatch windows. Each job ran with 1 GiB of memory and zero
swap, retained its 256 MiB reserve and recorded zero OOM events. These
peaks include native harness relinking and exclude cold dependency
compilation. The individual compiled replay workloads are recorded
separately. Native release tests, strict native and WASI Clippy, workspace
formatting and the downstream Cartesian replay and dyadic suites passed.

The initial assertions exceeded two existing image budgets. Keeping the
exact cardinality check on the decoded vector and comparing both power
rays without emitting an extra array formatter put all five native and
guest harnesses within their existing per-image caps. The largest file
charge was {x[4]:,} B on the Rust 1.99 WASI power test, leaving {x[6]} B
incrementally and {x[7]:,} B cumulatively. The ordinary and opt-in native
images have separate accounts. [Size accounts](docs/research/interval-size-accounts.json) · [Memory accounts](docs/research/interval-memory-accounts.json)

The targeted-inline Horner trial and its ordinary-inline alternative were
rebuilt against this revision. Across the 100 case and cache-state
combinations, both preserved the six heap and allocation maxima. The cold
tensor chain used {w['before'][0]:,} B in the control,
{w['after'][0]:,} B with targeted inlining and {w['ordinary_inline'][0]:,} B
with ordinary inlining. Targeted inlining fits the 32 B incremental and
64 B cumulative stack limits. Ordinary inlining exceeds both. The targeted
trial grew the registered Rust 1.95 certification executable by
{after['file']-before['file']:,} B against its 4,096 B cap. The trials were
discarded. The scalar replay commit affects test binaries and has its
own hosted workload account.

Evidence commit `{record['commit']}` contains {record['members']:,}
files under `{record['record']}`, with digest
`{sha}`. [Evidence index](docs/evidence-archive.tsv)
""")
