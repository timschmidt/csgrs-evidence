from pathlib import Path
import sys
r=Path(sys.argv[1])/'crates/hyperinterval/tests'
def change(name,old,new):
 p=r/(name+'.rs');t=p.read_text();assert t.count(old)==1;p.write_text(t.replace(old,new))
change('dyadic_zero_grid','let values: Vec<D> = serde_json::from_str(&encoded).unwrap();','let values: [D; 5] = serde_json::from_str(&encoded).unwrap();')
change('fractional_power','''        for piece in set.components() {''','''        // x^(-1/3) on [-8,8] has the two rays ending at -1/2 and +1/2.
        assert_eq!(
            set.components(),
            &[E::below(d(-1, -1, -1)).unwrap(), E::above(d(1, 1, -1)).unwrap()]
        );
        for (piece, expected) in set.components().iter().zip([d(-8, 0, 0), d(0, 8, 0)]) {''')
change('fractional_power','            assert!(result.range.components()[0].as_finite().is_some());','            assert_eq!(result.range.components()[0].as_finite(), Some(&expected));')
change('split_division','        assert_eq!(restored.components().len(), 2);','''        assert_eq!(
            restored.components(),
            &[E::below(d(-1, -1)).unwrap(), E::above(d(1, 1)).unwrap()]
        );''')
change('tangent','''        for component in set.components() {''','''        // A single pole lies between 1 and 2. The finite grid endpoints are
        // ceil(2^64 tan(2)) and floor(2^64 tan(1)), checked with directed MPFR.
        let point = |n: i128| DyadicInterval::point(n.into(), -64).unwrap();
        assert_eq!(
            set.components(),
            &[
                E::below(point(-40_306_871_148_438_554_474)).unwrap(),
                E::above(point(28_729_101_715_127_294_858)).unwrap(),
            ]
        );
        for component in set.components() {''')
