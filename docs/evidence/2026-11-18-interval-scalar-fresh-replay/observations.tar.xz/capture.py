from pathlib import Path
import subprocess,os,json,sys,shutil
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');sys.path.insert(0,str(r/'crates/hyperinterval/conformance'))
from wasi_libtest import completed,execute
stage=sys.argv[1];v=sys.argv[2]
bundle=s/f'{stage}-{v}'
rep=json.loads((bundle/'report.json').read_text())['fresh_replays']
dest=s/('sources-'+stage+'-'+v);dest.mkdir(exist_ok=True)
for n,case in rep.items():
 def one(parent,pattern):
  found=[p for p in parent.glob(pattern) if p.is_file() and os.access(p,os.X_OK)]
  assert len(found)==1,(n,found);return str(found[0])
 host=one(bundle/'target/release/deps',n+'-*');guest=one(bundle/'target/wasm32-wasip1/release/deps',n+'-*.wasm')
 env=os.environ|{'PATH':str(s/'instrument')+os.pathsep+os.environ['PATH'],'REAL_REPLAY_NODE':shutil.which('node'),'SCALAR_WASI_SUITE':n,'SCALAR_WASI_GUEST':guest,'REPLAY_PAYLOAD_LOG':str(dest/(n+'.json'))}
 variants=[('original',None)]
 if stage in ('accepted','qualified'):
  variants += [('invalid','{'), ('other','extra' if n=='dyadic_zero_grid' else '[-1,1]' if n=='integer_division' else '"Empty"')]
  if n in ('fractional_power','split_division','tangent'):
   other='fractional_power' if n=='split_division' else 'split_division'
   variants.append(('wrong_rays',(s/'sources-qualified-stable'/(other+'.json')).read_text()))
 for tag,mutation in variants:
  receipt=dest/(n+'.'+tag+'.children');log=dest/(n+'.'+tag+'.log')
  if receipt.exists():receipt.unlink()
  ev=env|{'SCALAR_WASI_RECEIPT':str(receipt)}
  if mutation:ev['REPLAY_TEST_MUTATION']=mutation
  run=execute([host,'--exact',case,'--nocapture'],log,ev)
  legacy_accepts = stage=='qualified' and ((tag=='other' and n in ('fractional_power','dyadic_zero_grid','tangent')) or (tag=='wrong_rays' and n in ('fractional_power','split_division','tangent')))
  if not mutation or legacy_accepts:assert not run.returncode and completed(run.stdout,{case}) and receipt.read_text().splitlines()==[case]
  else:assert run.returncode and not receipt.exists() and 'panicked' in run.stdout
  import re
  keys={'dyadic_zero_grid':'HYPERINTERVAL_ZERO_GRID_REPLAY','integer_division':'HYPERINTERVAL_INTEGER_DIV_REPLAY','fractional_power':'HYPERINTERVAL_POWER_REPLAY','tangent':'HYPERINTERVAL_TANGENT_REPLAY','split_division':'HYPERINTERVAL_SPLIT_REPLAY_PAYLOAD'}
  source=(dest/(n+'.json')).read_text()
  payload=source if not mutation else mutation
  if mutation=='extra':
   rows=json.loads(source);rows.append(rows[0]);payload=json.dumps(rows,separators=(',',':'))
  native=execute([host,'--exact',case,'--nocapture'],dest/(n+'.'+tag+'.native.log'),os.environ|{keys[n]:payload})
  assert (not native.returncode and completed(native.stdout,{case})) == (not mutation or legacy_accepts),(n,tag,native.stdout[-500:])
  print(n,tag,'accepted' if not run.returncode else 'rejected','native and WASI',flush=True)
