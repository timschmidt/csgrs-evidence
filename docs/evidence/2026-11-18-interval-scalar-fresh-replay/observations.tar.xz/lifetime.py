from pathlib import Path
import subprocess as sp,sys,shutil,os,json,concurrent.futures
from collections import defaultdict
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');h=Path('/dev/shm/interval-horner-readmission');w=s/'life-src';w.mkdir(exist_ok=True)
life=s/'lifetime';shutil.copytree(h/'life',life,dirs_exist_ok=True)
p=life/'Cargo.toml';p.write_text(p.read_text().replace(str(h/'src'),str(w)))
rev=(s/'source-revision').read_text().strip()
with sp.Popen(['git','archive',rev],cwd=r,stdout=sp.PIPE) as p:
 sp.run(['tar','-xmC',w],stdin=p.stdout,check=True);assert p.wait()==0
env=os.environ|{'CARGO_TARGET_DIR':str(s/'life-target'),'CARGO_BUILD_JOBS':'6'}
for stage in ('before','after'):
 shutil.copyfile(h/('preceding' if stage=='before' else 'candidate')/'life.lock',life/'Cargo.lock')
 if stage=='after':sp.run(['git','apply',s/'horner-current.patch'],cwd=w,check=True)
 with (s/f'life-{stage}.build').open('w') as log:sp.run(['cargo','+stable','build','--release','--locked','--manifest-path',life/'Cargo.toml'],env=env,stdout=log,stderr=sp.STDOUT,check=True)
 shutil.copyfile(s/'life-target/release/horner-life-harness',s/f'life-{stage}.bin');os.chmod(s/f'life-{stage}.bin',0o755)
def lane(i):
 for block in (i,i+4):
  for stage in (('before','after') if block%2==0 else ('after','before')):
   with (s/f'life-{stage}-{block}.tsv').open('w') as log:sp.run(['taskset','-c',str(1+4*i),s/f'life-{stage}.bin'],stdout=log,check=True,timeout=180)
with concurrent.futures.ThreadPoolExecutor(4) as pool:list(pool.map(lane,range(4)))
prior=json.loads((h/'review-life.json').read_text());data={}
for stage in ('before','after'):
 rows=defaultdict(list)
 for block in range(8):
  lines=(s/f'life-{stage}-{block}.tsv').read_text().splitlines();assert len(lines)==1600
  seen=set()
  for x in lines:
   rep,case,warm,pattern,*metrics=x.split('\t');assert (rep,case,warm,pattern) not in seen
   seen.add((rep,case,warm,pattern));rows[case,warm=='true'].append(list(map(int,metrics)))
 assert len(rows)==100 and all(len(q)==128 for q in rows.values())
 data[stage]={k:list(map(max,zip(*q))) for k,q in rows.items()}
out=[]
for row in prior:
 k=row['case'],row['warm'];a=row['maxima']['fixed'];x=data['before'][k];y=data['after'][k]
 previous=row['maxima']['preceding']
 charges=[max(0,b-f)+max(0,c-b)+max(0,d-c) for f,b,c,d in zip(a,previous,x,y)]
 inc=[d-c for c,d in zip(x,y)]
 out.append(dict(case=k[0],warm=k[1],fixed=a,historical_preceding=previous,before=x,after=y,increment=inc,cumulative=charges,incremental_failure=inc[0]>min(32,x[0]/100) or any(i>0 for i in inc[1:]),cumulative_failure=charges[0]>min(64,a[0]/50) or any(charges[1:]),headroom_failure=2097152-4096-y[0]<1048576 or y[0]>32768))
(s/'life-review.json').write_text(json.dumps(out,indent=1)+'\n')
print('incremental/cumulative failure counts',sum(x['incremental_failure'] for x in out),sum(x['cumulative_failure'] for x in out),'largest incremental stack',max(x['increment'][0] for x in out),'peak',max(x['after'][0] for x in out))
