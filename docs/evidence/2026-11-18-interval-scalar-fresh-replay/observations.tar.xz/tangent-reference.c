#include <mpfr.h>
#include <stdio.h>
int main(void) {
    mpfr_t x, lo, hi;
    mpfr_inits2(256, x, lo, hi, (mpfr_ptr)0);
    for (int k=1; k<=2; ++k) {
        mpfr_set_si(x, k, MPFR_RNDN);
        mpfr_tan(lo, x, MPFR_RNDD);
        mpfr_tan(hi, x, MPFR_RNDU);
        mpfr_mul_2ui(lo, lo, 64, MPFR_RNDD);
        mpfr_mul_2ui(hi, hi, 64, MPFR_RNDU);
        if (k==1) {mpfr_floor(lo, lo); mpfr_floor(hi, hi);}
        else {mpfr_ceil(lo, lo); mpfr_ceil(hi, hi);}
        if (!mpfr_equal_p(lo, hi)) return 1;
        mpfr_printf("%d %.0Rf\n", k, lo);
    }
    mpfr_clears(x, lo, hi, (mpfr_ptr)0);
    return 0;
}
