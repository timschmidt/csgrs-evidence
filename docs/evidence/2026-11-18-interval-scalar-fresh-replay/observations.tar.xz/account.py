from pathlib import Path
import json,re,hashlib
from fractions import Fraction
s=Path(__file__).parent
source=(s/'source-revision').read_text().strip();record='docs/evidence/2026-11-18-interval-scalar-fresh-replay'
def read(name):return json.loads((s/name).read_text())
def save(name,data):(s/name).write_text(json.dumps(data,indent=2)+'\n')
def interval(x):
 def big(a):return a[0]*sum(t<<(32*i) for i,t in enumerate(a[1]))
 return tuple(big(c)*Fraction(2)**x[-1] for c in x[:2])
def ends(x):
 lo,hi=x['Two'];a,b=interval(lo['Below']);c,d=interval(hi['Above']);assert a==b and c==d;return a,d
slot=64*2**20; reserve=16*2**20
full={};short={};memory={};digest={}
for v in ('1.88.0','1.95.0','stable'):
 b,f,c=[read(f'{k}-{v}.json') for k in ('base','fixed','rays')]
 rows={};summary={};checks=('file','code','functions')
 for t in c:
  rows[t]={}
  for n in sorted(c[t]):
   rows[t][n]={}
   for m in checks:
    if t=='coordinator':
     a=x=c['native'][n][m];y=c[t][n][m];inc_limit=total_limit=min(16384,x//100)
    else:
     a,x,y=(q[t][n][m] for q in (f,b,c));inc_limit=min(4096,x//100);total_limit=min(8192,a*2//100)
    prior=max(0,x-a);inc=max(0,y-x);charge=inc+prior
    assert inc<=inc_limit and charge<=total_limit and slot-c[t][n]['file']>=reserve
    rows[t][n][m]=[a,x,y,prior,inc,charge,inc_limit-inc,total_limit-charge]
  summary[t]=dict(peak_file_bytes=max(p['file'] for p in c[t].values()),minimum_free_slot_bytes=min(slot-p['file'] for p in c[t].values()),largest_positive_increment={m:max(p[m][4] for p in rows[t].values()) for m in checks},smallest_incremental_allowance_left={m:min(p[m][6] for p in rows[t].values()) for m in checks},largest_cumulative_charge={m:max(p[m][5] for p in rows[t].values()) for m in checks})
 full[v]=rows;short[v]=summary
 report=read(f'accepted-{v}/report.json')
 assert report==read(f'cold-{v}/report.json')
 ctext=(s/f'limited-{v}.log').read_text()
 assert 'memory.swap.max 0' in ctext and '\noom 0\noom_kill 0\n' in ctext and '\nmax 0\n' in ctext
 peak=int(re.search(r'^memory.peak (\d+)',ctext,re.M)[1]);cap=2**30;assert peak+2**28<=cap
 times=list(map(float,re.findall(r'^\d{10}\.\d+$',ctext,re.M)));assert len(times)==2
 modes={k:read(f'compiled-{v}-{k}.json') for k in ('native','guest')}
 assert all(int(q['memory.peak'])+2**28<=cap and 'oom_kill 0' in q['memory.events'] for q in modes.values())
 memory[v]=dict(measured_whole_job_bytes=peak,registered_whole_job_charge_bytes=peak,remaining_with_reserve_bytes=cap-2**28-peak,headroom_bytes=cap-peak,warm_job_seconds=round(times[1]-times[0],3),compiled_five_native_parents_peak_bytes=int(modes['native']['memory.peak']),compiled_five_cross_target_parents_peak_bytes=int(modes['guest']['memory.peak']),direct_guest_passes=sum(map(len,report['guest'].values())),native_os_cases=len(report['host_required']),fresh_guest_replays=len(report['fresh_replays']))
 src=s/f'sources-accepted-{v}';by={n:json.loads((src/(n+'.json')).read_text()) for n in report['fresh_replays']}
 assert by['integer_division']==[-715827883,715827883]
 assert [b[-1] for b in by['dyadic_zero_grid']]==[-2**31,-17,0,17,2**31-1] and all(b[:2]==[[-1,[3]],[1,[7]]] for b in by['dyadic_zero_grid'])
 assert ends(by['fractional_power'])==(Fraction(-1,2),Fraction(1,2))
 assert ends(by['split_division'])==(-1,1)
 mp=[int(x.split()[1]) for x in (s/'tangent-reference.log').read_text().splitlines()]
 assert ends(by['tangent'])==(Fraction(mp[1],2**64),Fraction(mp[0],2**64))
 for n in by:
  digest[n]=hashlib.sha256((src/(n+'.json')).read_bytes()).hexdigest()
  assert (src/(n+'.json')).read_bytes()==(s/'sources-qualified-stable'/(n+'.json')).read_bytes()
 assert (s/f'native-check-{v}.log').read_text().endswith('PASSED\n')
 mutations=(s/f'mutations-{v}.log').read_text()
 assert mutations.count('accepted native and WASI')==5 and mutations.count('rejected native and WASI')==13
save('source-digests.json',digest)
save('per-image.json',{'columns':['fixed','previous','final','prior_positive','incremental_positive','cumulative_positive','remaining_incremental','remaining_cumulative'],'rows':full})
save('size-entry.json',dict(source=source,evidence=record,scope='Five Hyperinterval release integration test executables, ordinary native and WASI plus opt-in native parent. File, complete code and nonoverlapping function bytes are tracked separately for every compiler and image in per-image.json. All previous accounts carry forward.',fixed='933c9ae56',preceding='d0a782310',ordinary_caps='Incremental 4096 bytes and 1% of preceding. Cumulative 8192 bytes and 2% of fixed. Positive charges only.',coordinator_caps='New optional path relative to the corresponding ordinary native image. Incremental and total allowance 16384 bytes and 1%.',slot_bytes=slot,required_free_bytes=reserve,targets=short))
save('memory-entry.json',dict(source=source,evidence=record,scope='New hosted Hyperinterval test job, one compiler lane and one child guest at a time. One fresh swap-disabled cgroup per run. Linux memory.peak includes parent, children, Cargo, native test relinking, Node and cleanup, with dependency and guest build caches prewarmed. Cold dependency compilation is separate. Native-only and guest-only five-case runs are separate compiled workloads.',capacity_bytes=2**30,required_headroom_bytes=2**28,charge='Register the entire observed peak per compiler for the new job, without offsetting production, firmware or other test budgets. Existing ordinary production heap and stack accounts carry forward.',targets=memory))
