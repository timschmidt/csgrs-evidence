"""Rebuild the previously stack-qualified targeted Horner change on the current sources."""
from pathlib import Path
import os,sys,subprocess as sp,json,hashlib
s=Path(__file__).parent
root=Path('/mnt/development/csgrs');h=Path('/dev/shm/interval-horner-readmission')
w=s/'src'
sys.path.insert(0,'/dev/shm/interval-budget-receipt')
from metrics import metrics
rev=(s/'source-revision').read_text().strip()
with sp.Popen(['git','archive',rev],cwd=root,stdout=sp.PIPE) as p:
 sp.run(['tar','xf','-','-m','-C',w],stdin=p.stdout,check=True);assert p.wait()==0
def build(stage):
 env=os.environ|{'CARGO_TARGET_DIR':str(h/'target-all'),'CARGO_BUILD_JOBS':'6'}
 cmd=['cargo','+1.95.0','build','--release','--locked','-p','hypersolve','-p','hyperdynamics','-p','hyperlattice-interval','--all-features','--bench','certification','--message-format=json']
 with (s/f'horner-{stage}.build').open('w') as err:
  out=sp.check_output(cmd,cwd=w,env=env,stderr=err,text=True)
 rows=[json.loads(x) for x in out.splitlines()]
 row,=[x for x in rows if x.get('executable') and x['target']['name']=='certification']
 ref=json.loads((root/'docs/research/interval-size-accounts.json').read_text())
 reg=next(x for x in ref['accounts'] if x['artifact']=='crates/hypersolve/benches/certification.rs' and x['target']=='x86_64-unknown-linux-gnu')
 assert sorted(reg['features'])==sorted(row['features'])
 return {'revision':rev,'features':row['features'],'image':metrics(Path(row['executable'])),'command':cmd}
base=build('before')
(s/'horner-before.json').write_text(json.dumps(base,indent=2)+'\n')
names=json.loads((h/'source-hashes.json').read_text())
for name,hashes in names.items():
 path=w/name;candidate=h/'candidate-source'/name
 old=sp.check_output(['git','show','79b183c51:'+name],cwd=root)
 assert hashlib.sha256(old).hexdigest()==hashes['base'] and hashlib.sha256(candidate.read_bytes()).hexdigest()==hashes['candidate']
 (s/'horner-common').write_bytes(old)
 new=sp.check_output(['git','merge-file','-p',path,s/'horner-common',candidate])
 path.write_bytes(new)
with (s/'horner-current.patch').open('wb') as patch:
 for name in names:
  cur=s/'horner-original';cur.write_bytes(sp.check_output(['git','show',rev+':'+name],cwd=root))
  run=sp.run(['diff','-u','--label','a/'+name,'--label','b/'+name,cur,w/name],stdout=patch)
  assert run.returncode in (0,1)
trial=build('after')
(s/'horner-after.json').write_text(json.dumps(trial,indent=2)+'\n')
print({k:trial['image'][k]-base['image'][k] for k in ['file','code','functions']})
