set -eu
s=/dev/shm/interval-scalar-replay
. "$s/env"
v=$1
export CARGO_TARGET_DIR="$s/lint-$v" CARGO_BUILD_JOBS=4
features=(--all-features)
if test "$v" = 1.88.0; then features=(--no-default-features --features integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace); fi
cargo "+$v" clippy --release --locked -p hyperinterval --all-targets "${features[@]}" -- -D warnings
cargo "+$v" test --locked --release -p hyperinterval "${features[@]}"
export CC="$wasi_sdk/bin/clang-18 --target=wasm32-wasi --sysroot=$wasi_sdk" CC_FOR_BUILD=cc CPPFLAGS=-D_WASI_EMULATED_SIGNAL LIBS=-lwasi-emulated-signal GMP_MPFR_SYS_CACHE="/dev/shm/interval-scalar-wasi/final-$v/gmp-cache"
export CARGO_ENCODED_RUSTFLAGS="-C"$'\x1f'"link-arg=$wasi_sdk/lib/wasm32-wasi/libwasi-emulated-signal.a"
cargo "+$v" clippy --release --locked -p hyperinterval --tests --target wasm32-wasip1 "${features[@]}" -- -D warnings
echo PASSED
