from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,re,subprocess,sys
d=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
v=sys.argv[1];dest=d/(v+'-discovery');dest.mkdir()
exes={row['target']['name']:row['executable'] for l in (d/(v+'-wasi.jsonl')).open() if (row:=json.loads(l)).get('executable')}
def run(entry):
 name,exe=entry
 cli=['node',str(r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe]
 names=re.findall(r'^(\S+): test$',subprocess.check_output([*cli,'--list'],text=True,stderr=subprocess.DEVNULL),re.M)
 with (dest/(name+'.log')).open('w') as f:rc=subprocess.run([*cli,'--test-threads=1'],stdout=f,stderr=subprocess.STDOUT).returncode
 log=(dest/(name+'.log')).read_text()
 return name,dict(rc=rc,listed=names,passed=re.findall(r'^test (\S+) \.\.\. ok$',log,re.M),failed=re.findall(r'^test (\S+) \.\.\. FAILED$',log,re.M),tail=log[-300:])
with ThreadPoolExecutor(8) as pool:out=dict(pool.map(run,exes.items()))
(dest/'results.json').write_text(json.dumps(out,indent=2)+'\n')
for name,x in out.items():print(name,len(x['listed']),len(x['passed']),x['failed'],x['rc'])
