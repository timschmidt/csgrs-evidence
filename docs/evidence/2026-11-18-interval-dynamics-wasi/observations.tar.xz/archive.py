from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile
d=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-dynamics-wasi'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p):files[str(p.relative_to(d))]=p.read_bytes()
for p in d.iterdir():
 if p.is_file() and (p.suffix in ('.log','.py','.sh','.json','.rs','.patch','.toml','.txt','.children') or p.name in ('source-revision','scope','measurement-scope','tier-results','mutant-receipt','reproduction')):
    add(p)
for folder in ('measured','retained-stable','retained-1.95.0','warm-stable','warm-1.95.0','stable-discovery','stable-cases'):
 for p in (d/folder).rglob('*'):
    if p.is_file():add(p)
for version in ('24.22.3','26.13.1'):
 p=d/('v'+version)/'SHASUMS256.txt';add(p)
 asset=p.parent/('node-v'+version+'-linux-x64.tar.xz')
 assert any(line.split()==[h(asset.read_bytes()),asset.name] for line in p.read_text().splitlines() if line.endswith(asset.name))
assert not json.loads((d/'qualified-accounts.json').read_text())['failures']
assert 'assertion `left == right` failed' in (d/'final-mutant.log').read_text()
assert 'No findings' in (d/'final-zizmor.log').read_text()
assert 'Verified' in (d/'package.log').read_text() or 'Verifying hyperdynamics' in (d/'package.log').read_text()
assert 'Done ' in (d/'fuzz.log').read_text()
for version in ('stable','1.95.0'):
 assert (d/f'quality-{version}.log').read_text().strip().endswith('PASS')
 for run in ('retained','warm'):
    rep=json.loads((d/f'{run}-{version}/report.json').read_text())
    assert sum(map(len,rep['guest'].values()))==141 and sum(map(len,rep['fresh_replays'].values()))==17
    assert sum(sum(x.values()) for x in rep['fresh_replays'].values())==33 and len(rep['host_threads'])==1
 mem=(d/f'memory-{version}.log').read_text()
 assert 'oom 0' in mem and 'memory.max 1073741824' in mem and int(mem.split('memory.peak ')[1].split()[0])<768*1024**2
assert (d/'source-revision').read_text().strip()==git(r,'rev-parse','HEAD').decode().strip()
sha={k:h(v) for k,v in sorted(files.items())}
dest=d/'record';dest.mkdir(exist_ok=True)
with tarfile.open(dest/'observations.tar.xz','w:xz') as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(dest/'observations.tar.xz','r|xz') as t:assert {m.name:h(t.extractfile(m).read()) for m in t}==sha
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(sha,indent=1).encode()))
total=sum(p.stat().st_size for p in dest.iterdir())
assert shutil.disk_usage(e).free-(e/'.git/index').stat().st_size-3*total-1048576>20*1024**3
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(dest,e/record);git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive native-parent and WASI-child Hyperdynamics qualification')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in dest.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ROOTS={record:False};row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
print(rev,row,'members',len(sha))
