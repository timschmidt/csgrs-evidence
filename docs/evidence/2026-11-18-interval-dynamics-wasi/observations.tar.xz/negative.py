from pathlib import Path
import json,os,subprocess
d=Path(__file__).resolve().parent
def artifact(name):
    return next(j['executable'] for j in map(json.loads,(d/name).read_text().splitlines()) if j.get('executable') and j['target']['name']=='expression_field' and j['target']['kind']==['test'])
case='fresh_process_replay_revalidates_source_and_regenerates_field_partials'
receipt=d/'final-mutant.children'
assert not receipt.exists()
env=os.environ|{'PATH':str(d/'v24.22.3/bin')+':'+os.environ['PATH'], 'DYNAMICS_WASI_GUEST':artifact('mutant.jsonl'),'DYNAMICS_WASI_RECEIPT':str(receipt)}
with (d/'final-mutant.log').open('w') as out:
    status=subprocess.run([artifact('negative-parent.jsonl'),'--exact',case,'--nocapture'],env=env,stdout=out,stderr=subprocess.STDOUT)
txt=(d/'final-mutant.log').read_text()
assert status.returncode and 'assertion `left == right` failed' in txt and '0 passed; 1 failed;' in txt and receipt.read_text().splitlines()==[case]
print('Original native parent rejected independently mutated payload from successful WASI child.')
