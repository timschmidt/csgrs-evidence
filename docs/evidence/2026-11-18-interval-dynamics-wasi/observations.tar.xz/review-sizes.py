from pathlib import Path
import json,sys
d=Path(__file__).resolve().parent
s=d/'measured';stage=sys.argv[1] if len(sys.argv)>1 else 'candidate'
result={}
for p in sorted((s/stage).glob('*.json')):
 prev=json.loads((s/'preceding'/p.name).read_text());fixed=json.loads((s/'fixed'/p.name).read_text());new=json.loads(p.read_text())
 assert set(prev)==set(new)
 rows={}
 for name,n in new.items():
    b=prev[name]['metrics'];c=n['metrics'];f=fixed.get(name,{}).get('metrics',{})
    if (c['sha256']==b['sha256']) and name not in fixed:continue
    ds={k:c[k]-b[k] for k in ('file','code','functions')}
    incr={k:max(0,x) for k,x in ds.items()}
    cs={k:max(0,b[k]-f[k])+inc for k,inc in incr.items() if k in f}
    fail=[]
    for k,inc in incr.items():
        if 'example' in n['kind']:
            if inc:fail.append(k+' shipped')
        elif inc and (inc>4096 or 100*inc>b[k] or k in cs and (cs[k]>8192 or cs[k]*100>2*f[k])):fail.append(k+' cap')
        if not f and inc:fail.append(k+' missing fixed')
    rows[name]=dict(delta=ds,prior_fixed={k:f[k] for k in ds if k in f},preceding={k:b[k] for k in ds},candidate={k:c[k] for k in ds},charges=cs,failed=fail)
    if fail:print(p.stem,name,ds,fail)
 result[p.stem]=rows
 print(p.stem,len(rows),'grown',sum(any(x>0 for x in v['delta'].values()) for v in rows.values()))
(d/(stage+'-accounts.json')).write_text(json.dumps(result,indent=2)+'\n')
