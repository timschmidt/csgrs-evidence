from pathlib import Path
import re,subprocess
root=Path('crates/hyperdynamics/tests')
pattern=r'\n#\[cfg\([^\n]+\)\]\n#\[path = "support/replay.rs"\]\nmod replay;\n$'
calls=suites=0
for p in root.rglob('*.rs'):
    if p==root/'support/replay.rs':continue
    s=p.read_text()
    orig=subprocess.check_output(['git','show','c18d6e6d4:'+str(p)],text=True)
    replacements=s.count('crate::replay::binary().unwrap()')
    s,n=re.subn(pattern,'',s)
    assert s.replace('crate::replay::binary().unwrap()','std::env::current_exe().unwrap()')==orig,p
    calls+=replacements;suites+=n
assert (calls,suites)==(17,13)
print('All original Rust test sources recovered verbatim from 17 program selections and 13 module imports.')
