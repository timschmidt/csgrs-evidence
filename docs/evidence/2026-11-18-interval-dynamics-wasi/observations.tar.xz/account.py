from pathlib import Path
import json
root=Path(__file__).resolve().parent
size=root/'measured'
keys=('file','code','functions')
ledger=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
old=ledger['dynamics_graph_budget_replay']['artifacts']
result={}
failures=[]
for p in sorted((size/'candidate').glob('*.json')):
    tag=p.stem
    before=json.loads((size/'preceding'/p.name).read_text()); fixed=json.loads((size/'fixed'/p.name).read_text())
    after=json.loads(p.read_text())
    assert set(before)==set(after) and len(after)==29 and len(fixed)==28
    coordinator=size/'coordinator'/p.name
    opt=json.loads(coordinator.read_text()) if coordinator.exists() else {}
    rows={}
    for name in sorted(after):
        b,c=before[name]['metrics'],after[name]['metrics']
        f=fixed.get(name,{}).get('metrics',{})
        single={'kind':after[name]['kind'],'matched_sha256':b['sha256']==c['sha256']}
        if not f:
            assert name=='test/reachability_policy' and b['sha256']==c['sha256']
        delta={};extra={}
        for k in keys:
            diff=c[k]-b[k]
            historical=max(0,b[k]-f[k]) if f else 0
            prior=old.get(name.removeprefix('test/'),{}).get('metrics',{}).get({'code':'text'}.get(k,k),{})
            if tag=='1.95.0-x86_64-unknown-linux-gnu' and name.startswith('test/'):
                historical=max(historical,prior.get('cumulative_charge',0))
                if name=='test/rk_proposal':
                    prior_rk=ledger['binary32_proposal_radius']['tests']['rk_proposal-test']['metrics']
                    metric={'code':'text','functions':'named_text'}.get(k,k)
                    historical=max(historical,*(entry['cumulative'] for entry in prior_rk if entry['metric']==metric))
            charged=historical+max(diff,0)
            denom=f.get(k,b[k])
            delta[k]={'fixed':f.get(k),'previous':b[k],'candidate':c[k],'delta':diff,'relative_percent':100*diff/b[k],
                      'incremental_charge':max(0,diff),'cumulative_charge':charged,
                      'remaining_incremental_bytes':max(0,min(4096,b[k]//100)-max(0,diff)),
                      'remaining_cumulative_bytes':max(0,min(8192,denom*2//100)-charged)}
            if diff>0 and (name.startswith('example/') or diff>min(4096,b[k]//100) or charged>min(8192,denom*2//100)):
                failures.append((tag,name,k,'regular',diff,charged))
            if opt:
                x=opt[name]['metrics'][k];add=max(0,x-c[k]);cap=min(16384,c[k]*2//100)
                extra[k]={'regular':c[k],'coordinator':x,'delta':x-c[k],'charge':add,'percent':100*(x-c[k])/c[k],'remaining_bytes':cap-add}
                if add>cap:failures.append((tag,name,k,'coordinator',add))
        single['metrics']=delta
        single['headroom_bytes']=20*1024**2-c['file']
        if single['headroom_bytes']<4*1024**2:failures.append((tag,name,'regular capacity'))
        if opt:
            single['opt_in']=extra
            single['coordinator_headroom_bytes']=20*1024**2-opt[name]['metrics']['file']
            if single['coordinator_headroom_bytes']<4*1024**2:failures.append((tag,name,'coordinator capacity'))
        rows[name]=single
    result[tag]=rows
    print(tag, 'unchanged hashes',sum(v['matched_sha256'] for v in rows.values()),'/',len(rows),
          'max normal delta',tuple(max(r['metrics'][k]['delta'] for r in rows.values()) for k in keys),
          'max coordinator delta', tuple(max(r['opt_in'][k]['delta'] for r in rows.values()) for k in keys) if opt else None)
print('failures',failures)
(root/'qualified-accounts.json').write_text(json.dumps({'measurements':result,'failures':failures},indent=2)+'\n')
