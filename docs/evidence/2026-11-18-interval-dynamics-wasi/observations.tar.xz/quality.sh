#!/bin/bash
set -euo pipefail
. /dev/shm/interval-horner-readmission/env
d=/dev/shm/interval-dynamics-wasi
v=$1
export CARGO_TARGET_DIR="$d/quality-$v" CARGO_BUILD_JOBS=8 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
run() { printf '%q ' "$@" ; echo; "$@"; }
run cargo +"$v" fmt --all -- --check
run rustfmt +"$v" --edition 2024 --check crates/hyperdynamics/fuzz/fuzz_targets/*.rs
run cargo +"$v" hack check --locked -p hyperdynamics --each-feature --all-targets
run cargo +"$v" test --locked -p hyperdynamics --no-default-features
run cargo +"$v" test --locked -p hyperdynamics --all-targets --all-features
run cargo +"$v" test --locked -p hyperdynamics --release --lib --tests --all-features
run cargo +"$v" test --locked -p hyperdynamics --doc --all-features
run cargo +"$v" clippy --locked -p hyperdynamics --all-targets --no-default-features -- -D warnings
run cargo +"$v" clippy --locked -p hyperdynamics --all-targets --all-features -- -D warnings
run cargo +"$v" clippy --locked -p hyperdynamics --lib --tests --target wasm32-wasip1 --all-features -- -D warnings
run cargo +"$v" check --locked --manifest-path crates/hyperdynamics/fuzz/Cargo.toml --bins
run cargo +"$v" clippy --locked --manifest-path crates/hyperdynamics/fuzz/Cargo.toml --bins -- -D warnings
export RUSTDOCFLAGS='-D warnings'
run cargo +"$v" doc --locked -p hyperdynamics --no-deps --all-features
echo PASS
