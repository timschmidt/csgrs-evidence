from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,re,subprocess,sys
d=Path(__file__).resolve().parent;r=Path('/mnt/development/csgrs');v=sys.argv[1];dest=d/(v+'-cases');dest.mkdir()
items=[]
for line in (d/(v+'-wasi.jsonl')).open():
 row=json.loads(line)
 if not row.get('executable'):continue
 cli=['node',str(r/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),row['executable']]
 names=re.findall(r'^(\S+): test$',subprocess.check_output([*cli,'--list'],text=True,stderr=subprocess.DEVNULL),re.M)
 items.extend((row['target']['name'],name,cli) for name in names)
def run(item):
 suite,name,cli=item;log=dest/(suite+'.'+name.replace('::','.')+'.log')
 with log.open('w') as f:rc=subprocess.run([*cli,'--exact',name,'--nocapture','--test-threads=1'],stdout=f,stderr=subprocess.STDOUT).returncode
 s=log.read_text()
 if rc==0:assert '1 passed; 0 failed' in s
 return dict(suite=suite,case=name,rc=rc,diagnostic='\n'.join(l for l in s.splitlines() if 'panicked' in l or 'Unsupported' in l or 'assertion' in l or 'failed to spawn' in l)[:900])
with ThreadPoolExecutor(12) as pool:out=list(pool.map(run,items))
(dest/'results.json').write_text(json.dumps(out,indent=2)+'\n')
for x in out:
 if x['rc']:print(x)
print('total',len(out),'failures',sum(bool(x['rc']) for x in out))
