#!/bin/bash
set -euo pipefail
d=/dev/shm/interval-dynamics-wasi
v=$1
cd /mnt/development/csgrs
. /dev/shm/interval-horner-readmission/env
export PATH="$d/v24.22.3/bin:/home/tim/.cargo/bin:/usr/local/bin:/usr/bin:/bin" CARGO_TARGET_DIR="$d/target-$v" PYTHONDONTWRITEBYTECODE=1
group="/sys/fs/cgroup$(cut -d: -f3 /proc/self/cgroup)"
date -u
printf 'memory.max '; cat "$group/memory.max"
printf 'memory.swap.max '; cat "$group/memory.swap.max"
python3 crates/hyperinterval/conformance/wasi-dynamics.py --toolchain "$v" --output "$d/warm-$v"
printf 'memory.peak '; cat "$group/memory.peak"
printf 'memory.current after runner exit '; cat "$group/memory.current"
cat "$group/memory.events"
