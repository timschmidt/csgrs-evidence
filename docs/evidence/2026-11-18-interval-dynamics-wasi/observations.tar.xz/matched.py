from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,io,json,os,re,shutil,subprocess,sys
d=Path(__file__).resolve().parent;root=Path('/mnt/development/csgrs');w=d/'matched-src'
from sizes import metrics
def export(rev):
 if w.exists():shutil.rmtree(w)
 w.mkdir()
 with subprocess.Popen(['git','-C',root,'archive',rev],stdout=subprocess.PIPE) as c:
    subprocess.run(['tar','xf','-','-m','-C',w],stdin=c.stdout,check=True);assert c.wait()==0
def build(item):
 v,target,stage=item
 dest=d/'measured'/stage;dest.mkdir(parents=True,exist_ok=True)
 tag=f'{v}-{target}'
 env=os.environ|{'CARGO_TARGET_DIR':str(d/f'matched-{v}-{target}'),'CARGO_BUILD_JOBS':'5'}
 if stage=='coordinator':env['HYPERDYNAMICS_REPLAY_DRIVER']=str(root/'crates/hyperinterval/conformance/wasi-dynamics.py')
 args=['cargo','+'+v,'build','--locked','--release','-p','hyperdynamics','--all-features','--lib','--tests','--examples','--target',target,'--message-format=json-render-diagnostics']
 with (dest/(tag+'.log')).open('w') as log:
    output=subprocess.check_output(args,cwd=w,text=True,stderr=log,env=env)
 rows={}
 for l in output.splitlines():
    j=json.loads(l)
    if j.get('executable'):
        name=','.join(j['target']['kind'])+'/'+j['target']['name'];assert name not in rows;rows[name]=dict(kind=j['target']['kind'],metrics=metrics(Path(j['executable'])))
 (dest/(tag+'.json')).write_text(json.dumps(rows,indent=2)+'\n')
 print(stage,tag,len(rows),flush=True)
for stage in sys.argv[1:]:
 if stage in ('fixed','preceding'):
    export('c9f1f9ac5' if stage=='fixed' else 'c18d6e6d4')
    # Unmodified manifests cannot compile Criterion on WASI. Match all other
    # code while retaining that revision's native dev dependencies and lock.
    p=w/'crates/hyperdynamics/Cargo.toml';s=p.read_text()
    pos=s.index('[[example]]')
    s=s.replace('criterion = "0.5"\n','',1)
    start=(root/'crates/hyperdynamics/Cargo.toml').read_text()
    extra=start[start.index("[target.'cfg(all(target_arch"):start.index('[[example]]')]
    s=s.replace('[[example]]',extra+'[[example]]',1);p.write_text(s)
 elif stage in ('candidate','inline','selected'):
    # The live tree is the declared candidate; prior exports may contain different tests.
    shutil.copytree(root/'crates/hyperdynamics/tests',w/'crates/hyperdynamics/tests',dirs_exist_ok=True,copy_function=shutil.copyfile)
    shutil.copyfile(root/'crates/hyperdynamics/Cargo.toml',w/'crates/hyperdynamics/Cargo.toml')
 jobs=[(v,t,stage) for v in ['stable','1.95.0'] for t in (['x86_64-unknown-linux-gnu'] if stage=='coordinator' else ['x86_64-unknown-linux-gnu','wasm32-wasip1'])]
 with ThreadPoolExecutor(len(jobs)) as pool:list(pool.map(build,jobs))
