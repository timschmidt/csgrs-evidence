use std::process::Command;

/// The conformance build runs the same child test in a fresh WASI instance.
/// Ordinary Cargo tests replay in a fresh copy of their own executable.
#[inline]
pub fn child() -> Command {
    if let Some(driver) = option_env!("HYPERDYNAMICS_REPLAY_DRIVER") {
        let mut command = Command::new("python3");
        command.arg(driver).arg("--child");
        command
    } else {
        Command::new(std::env::current_exe().unwrap())
    }
}
