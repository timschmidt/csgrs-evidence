use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use hypersolve::{Expr,SymbolId,Problem,Constraint,certify_univariate_quadratic_alpha,context_from_problem,UnivariateQuadraticAlphaStatus as S};
fn main() {
 let mut args=std::env::args().skip(1);let mode=args.next().unwrap();let count=args.next().unwrap().parse::<usize>().unwrap();
 let mut p=Problem::default();p.add_variable("x",Real::zero());let x=Expr::symbol(SymbolId(0),"x");let mut expected=vec![];
 for b in -4_i64..=4 {for c in -3_i64..=3 {
  let (linear,constant,status)=if mode=="opaque" {
    let t=Real::e();let z=(Real::from(2)*&t).sin()-Real::from(2)*t.clone().sin()*t.cos();
    (z,Real::zero(),S::Undecided)
  }else{
    let s=match (b==0,c==0){(true,true)=>S::ExactMultipleRoot,(true,false)=>S::ZeroDerivative,(false,true)=>S::ExactSimpleRoot,_ if 8*c.abs()<=b*b=>S::CertifiedSmaleAlphaBound,_=>S::BoundFailed};
    (Real::from(b),Real::from(c),s)
  };
  p.add_constraint(Constraint::equality("quadratic",x.clone().powi(2)+Expr::real(linear)*x.clone()+Expr::real(constant)));expected.push((b,c,status));
 }}
 let a=p.analyze();let context=context_from_problem(&p);let mut h=0usize;
 for _ in 0..count {for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512]{
   let r=certify_univariate_quadratic_alpha(&a,&context,policy);assert_eq!(r.rows.len(),63);assert_eq!(r.examined_rows,63);
   assert_eq!(r.certified_rows,expected.iter().filter(|(_,_,s)|s.is_certified()).count());
   for (i,(row,(b,c,s))) in r.rows.into_iter().zip(&expected).enumerate(){
    assert_eq!(&row.status,s);assert_eq!(row.constraint_index,i);assert_eq!(row.name,"quadratic");
    if mode=="common"{
     assert_eq!(row.residual,Real::from(*c));assert_eq!(row.derivative,Real::from(*b));
     if *b!=0{assert_eq!(row.alpha_numerator,Some(Real::from(c.abs())));assert_eq!(row.alpha_denominator,Some(Real::from(b*b)));}
     else{assert_eq!(row.alpha_numerator,None);assert_eq!(row.alpha_denominator,None);}
    }else{assert_eq!(row.alpha_numerator,None);assert_eq!(row.alpha_denominator,None);}
    h=h.rotate_left(1)^i^usize::from(row.status.is_certified());
   }
 }}println!("{mode} {count} {h}");
}
