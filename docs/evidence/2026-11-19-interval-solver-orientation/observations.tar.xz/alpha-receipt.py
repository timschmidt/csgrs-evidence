from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/alpha.rs';s=p.read_text().replace('use hyperlimit::{PredicatePolicy, compare_reals};','use hyperlimit::{Certainty, PredicateOutcome, PredicatePolicy, compare_reals};')
start=s.index('    let policy = policy.certified_only();');end=s.index('\n\n',start)
s=s[:start]+'''    let certified_order = |left: &Real, right: &Real| match compare_reals(left, right, policy) {
        PredicateOutcome::Decided {
            value,
            certainty: Certainty::Exact | Certainty::Filtered,
            ..
        } => Some(value),
        _ => None,
    };
    let residual_order = certified_order(&residual_abs, &Real::zero());
    let derivative_order = certified_order(&derivative_abs, &Real::zero());'''+s[end:]
s=s.replace('compare_reals(&sufficient_left, &denominator, policy).value()', 'certified_order(&sufficient_left, &denominator)');p.write_text(s)
