from pathlib import Path
import subprocess,hashlib,re,json
w=Path(__file__).parent
def inspect(p):
 raw=subprocess.check_output(['readelf','-lW',p],text=True)
 result=[]
 for l in raw.splitlines():
  r=l.split()
  if not r or r[0] not in ('LOAD','GNU_RELRO'):continue
  k=r[0];addr=int(r[2],16);file=int(r[4],16);mem=int(r[5],16);perm=''.join(r[6:-1])
  result.append(dict(kind=k,address=addr,end=addr+mem,initialized_bytes=file,permissions=perm,pages=[addr//4096,(addr+mem+4095)//4096]))
 secs=subprocess.check_output(['readelf','-SW',p],text=True)
 l=next(l for l in secs.splitlines() if '.relro_padding' in l);assert 'NOBITS' in l
 return dict(segments=result,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),section=l.strip())
a={s:inspect(w/f'alpha-img-{s}-stable-native') for s in ['fixed','previous','matched','recheck']}
assert a['matched']==a['recheck']
old,new=a['previous'],a['recheck']
assert [(i['kind'],i['permissions'],i['pages']) for i in old['segments']]==[(i['kind'],i['permissions'],i['pages']) for i in new['segments']]
assert [i['initialized_bytes'] for i in old['segments'] if i['kind']=='GNU_RELRO']==[i['initialized_bytes'] for i in new['segments'] if i['kind']=='GNU_RELRO']
assert new['bytes']<old['bytes']
r=json.loads((w/'matched-client-sizes.json').read_text())['stable-native']['metrics']['.relro_padding'];assert r['delta']<=min(16,r['previous']*.025) and r['cumulative_remaining']>=0
(w/'layout-evidence.json').write_text(json.dumps(a,indent=1));print('all PT_LOAD/RELRO pages and permissions identical; exact rebuild',new['sha256'])
