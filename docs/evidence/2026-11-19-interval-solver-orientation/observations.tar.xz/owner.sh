set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
v=$1; t=$2; stage=$3; export PATH="$w/bin:$PATH" CARGO_TARGET_DIR="$w/owner-$v-$t"
opts=(); flags=()
if [ "$t" = wasi ]; then
 export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-$v"
 opts=(--target wasm32-wasip1 --config "target.wasm32-wasip1.runner=['node','$w/control/crates/hyperlattice-interval/conformance/run-wasi-test.mjs']")
 flags=(--test-threads=1 --nocapture)
fi
cd "$w/control"
cargo +"$v" test --release --locked -p hypersolve --all-features "${opts[@]}" --test symbolic_inequality_jacobian -- "${flags[@]}" > "$w/logs/owner-$v-$t-$stage" 2>&1
