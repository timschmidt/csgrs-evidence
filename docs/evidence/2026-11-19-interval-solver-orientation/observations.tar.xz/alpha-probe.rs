use hyperlimit::{PredicatePolicy,compare_reals};
use hyperreal::Real;
use hypersolve::{Expr,SymbolId,Problem,Constraint,context_from_problem,certify_univariate_quadratic_alpha};
#[test]
fn independently_known_root_multiplicity() {
 for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
  let sine=Real::e().sin();let cosine=Real::e().cos();
  let identity=&sine*&sine+&cosine*&cosine-Real::one();
  let d=compare_reals(&identity.abs(),&Real::zero(),policy);
  let x=Expr::symbol(SymbolId(0),"x");
  let mut p=Problem::default();p.add_variable("x",Real::zero());
  p.add_constraint(Constraint::equality("x*x + identity*x",x.clone().powi(2)+Expr::real(identity)*x));
  let r=certify_univariate_quadratic_alpha(&p.analyze(),&context_from_problem(&p),policy);
  println!("ALPHA {policy:?} derivative comparison {d:?}, report {:?}, certified {}",r.rows.first().map(|x| &x.status),r.all_examined_rows_certified());
  assert_eq!(r.examined_rows,1);
 }
}
