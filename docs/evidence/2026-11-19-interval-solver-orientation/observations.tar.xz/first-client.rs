use hyperreal::Real;
use hypersolve::{Constraint, ConstraintKind, Expr, Problem, SymbolId, SolverConfig, SolverState, context_from_problem, solve_damped_least_squares};
use hypersolve::jacobian::{FiniteDifferenceConfig, finite_difference_jacobian, symbolic_jacobian, symbolic_jacobian_with_analysis};
fn main() {
    for kind in [ConstraintKind::LessOrEqual, ConstraintKind::GreaterOrEqual] {
        let mut problem = Problem::default();
        problem.add_variable("x", Real::from(-3));
        let x = Expr::symbol(SymbolId(0),"x");
        let mut row = Constraint::equality("feasible at x >= 0", if kind==ConstraintKind::GreaterOrEqual {x} else {-x});
        row.kind = kind;
        row.weight = Real::from(2);
        problem.add_constraint(row);
        let c = context_from_problem(&problem);
        println!("{kind:?} plain {:?} prepared {:?} finite {:?}",symbolic_jacobian(&problem,&c).unwrap(),symbolic_jacobian_with_analysis(&problem.analyze(),&c).unwrap(),finite_difference_jacobian(&problem,&c,FiniteDifferenceConfig{step:Real::one()}).unwrap());
        let report=solve_damped_least_squares(SolverState{problem,config:SolverConfig{damping:Real::zero(),..Default::default()}});
        println!("{kind:?} reason {:?} iterations {} final {:?}",report.reason,report.iterations,report.residuals.last().and_then(|r|r.weighted_dense_solver_estimate));
    }
}
