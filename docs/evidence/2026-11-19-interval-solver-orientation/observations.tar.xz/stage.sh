set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
stage=$1
pids=()
for v in 1.95.0 stable; do for target in native wasi; do bash "$w/build-client.sh" "$v" "$target" "$stage" & pids+=("$!"); done; done
for pid in "${pids[@]}"; do wait "$pid"; done
