set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
for i in {1..120}; do if test -s "$w/alpha-img-fixed-stable-native" && test -s "$w/alpha-img-fixed-1.95.0-native" && test -s "$w/alpha-img-fixed-stable-wasi" && test -s "$w/alpha-img-fixed-1.95.0-wasi"; then break; fi; sleep 3; done
python3 "$w/alpha-client-size.py" alpha > "$w/logs/alpha-client-sizes"
python3 "$w/alpha-runtime.py" > "$w/logs/alpha-runtime" 2>&1
