set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
v=$1; t=$2; stage=$3
export CARGO_TARGET_DIR="$w/matched-$v-$t" CARGO_BUILD_JOBS=6
dir="$CARGO_TARGET_DIR/release"
flags=()
if [ "$t" = wasi ]; then
 export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-$v"
 flags=(--target wasm32-wasip1); dir="$CARGO_TARGET_DIR/wasm32-wasip1/release"
fi
cargo +"$v" build --release --locked --manifest-path "$w/client/Cargo.toml" "${flags[@]}" > "$w/logs/build-$stage-$v-$t" 2>&1
if [ "$t" = wasi ]; then cp "$dir/jacobian-client.wasm" "$w/$stage-$v-$t"; else cp "$dir/jacobian-client" "$w/$stage-$v-$t"; fi
