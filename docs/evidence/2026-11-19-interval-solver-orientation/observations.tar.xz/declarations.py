from pathlib import Path
import csv,subprocess
w=Path(__file__).parent
ast={tuple(l.split('\t')) for l in (w/'ast.tsv').read_text().splitlines()}
paths={r[0] for r in ast}
def chosen(s):
 return {(r['path'],r['line'],r['kind'],r['symbol']) for r in csv.DictReader(s.splitlines(),delimiter='\t') if r['repository']=='csgrs' and r['path'] in paths and r['review_status'].startswith('lexical')}
base=chosen(subprocess.check_output(['git','show','590b87f32:interval-inventory.tsv'],text=True));current=chosen((w/'preview.tsv').read_text());assert not ast-current
listed=[l.split(': test')[0] for l in (w/'logs/libtest-macro-map').read_text().splitlines() if l.endswith(': test')]
extra=sorted(current-ast)
for path,line,kind,name in extra:
 matches=[l for l in listed if l.split('::')[-1]==name];assert len(matches)==1,(path,line,name,matches)
 print(path,line,kind,name,matches[0],sep='\t')
print(f'{len(paths)} paths, {len(ast)} syntax declarations, {len(extra)} macro definitions in compiled test list, {len(base)} old rows ({len(base&ast)} syntax and {len(base-ast)} macro), {len(current)} current rows')
