from pathlib import Path
import os,sys,re,json,time,statistics,subprocess,resource
w=Path(__file__).parent
stages=['fixed','previous','scalar','scalar-projected']
def jobs():
 for v in ['1.95.0','stable']:
  for s in stages:
   for mode in (['common','equivalent'] if s=='scalar-projected' else ['common']):
    for nr,n in [(8,1),(32,100)]:
     yield v,s,mode,nr,n
def checked(argv,env=None):
 p=subprocess.run(argv,capture_output=True,text=True,env=env,check=True);return p.stdout.strip(),p.stderr
out=[]
for v,s,m,nr,n in jobs():
 args=[w/f'{s}-{v}-native',m,str(nr),str(n)]
 value,raw=checked(args,os.environ|dict(LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libmemusage.so'));h=list(map(int,re.search(r'heap total: (\d+), heap peak: (\d+), stack peak: (\d+)',raw).groups()))
 counts={a:[int(x),int(y),int(z)] for a,x,y,z in re.findall(r'(malloc|realloc|calloc|free)\|\s+(\d+)\s+(\d+)\s+(\d+)',raw)}
 stack=[]
 for p in ['a5','5a','8d']:
  x,sp=checked(args,os.environ|dict(LD_PRELOAD=str(w/'stackview.so'),STACK_PATTERN=p));assert x==value
  stack.append(list(map(int,re.search(r'HEADROOM (.*)',sp)[1].split())))
 out.append(dict(version=v,stage=s,mode=m,rows=nr,repeats=n,output=value,heap_total=h[0],heap_peak=h[1],allocator=counts,stack=stack))
(w/'lifetime.json').write_text(json.dumps(out,indent=1))
def cpu():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
out=[]
for v in ['1.95.0','stable']:
 for i in range(12):
  for s in (stages if i%2==0 else stages[::-1]):
   args=['taskset','-c','5',w/f'{s}-{v}-native','common','32','600']
   t=cpu();start=time.monotonic();value,_=checked(args)
   out.append(dict(v=v,stage=s,i=i,cpu=cpu()-t,wall=time.monotonic()-start,output=value))
(w/'timing.json').write_text(json.dumps(out,indent=1))
for v in ['1.95.0','stable']:
 for s in stages:
  rs=[r for r in out if r['v']==v and r['stage']==s]
  print(v,s,'CPU, wall',*(round(statistics.median(r[k] for r in rs),6) for k in ['cpu','wall']))
