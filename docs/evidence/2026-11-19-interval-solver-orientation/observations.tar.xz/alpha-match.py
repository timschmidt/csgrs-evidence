from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/alpha.rs';s=p.read_text();start=s.index('    if derivative_order ==');end=s.index('    let numerator =',start)
s=s[:start]+'''    use UnivariateQuadraticAlphaStatus as Status;
    match (residual_order, derivative_order) {
        (Some(Ordering::Equal), Some(Ordering::Equal)) => {
            return alpha_status(Status::ExactMultipleRoot);
        }
        (Some(Ordering::Equal), None) | (None, Some(Ordering::Equal)) => {
            return alpha_status(Status::Undecided);
        }
        (_, Some(Ordering::Equal)) => return alpha_status(Status::ZeroDerivative),
        (Some(Ordering::Equal), _) => {
            return AlphaBoundClassification {
                status: Status::ExactSimpleRoot,
                alpha_numerator: Some(Real::zero()),
                alpha_denominator: Some(derivative_abs.clone() * derivative_abs),
            };
        }
        _ => {}
    }

'''+s[end:];p.write_text(s)
