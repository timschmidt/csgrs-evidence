#define _GNU_SOURCE
#include <stdlib.h>
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
typedef int (*entry_fn)(int, char **, char **);
static entry_fn program;
extern size_t measure_stack(void (*)(void *),void *,int,unsigned char);
struct args {int argc; char **argv; char **env; int code;};
static void invoke(void *ptr) {
    struct args *a=ptr;
    a->code=program(a->argc,a->argv,a->env);
}
static int run(int argc,char **argv,char **env) {
    struct args a={argc,argv,env,1};
    unsigned long p=strtoul(getenv("STACK_PATTERN"),NULL,16);
    measure_stack(invoke,&a,0,p);
    return a.code;
}
int __libc_start_main(entry_fn user_main,int argc,char **argv,void (*init)(void),void (*fini)(void),void (*ld_fini)(void),void *end) {
    typedef int (*start_fn)(entry_fn,int,char**,void(*)(void),void(*)(void),void(*)(void),void*);
    start_fn start=(start_fn)dlsym(RTLD_NEXT,"__libc_start_main");
    program=user_main;
    return start(run,argc,argv,init,fini,ld_fini,end);
}
