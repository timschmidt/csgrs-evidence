from pathlib import Path
import sys,json
w=Path(__file__).parent
def read(s):
 rows={}
 for line in (w/'logs'/f'trace-{s}').read_text().splitlines():
  if line.startswith('TRACE\t'):
   _,k,x,ww,sp,bits,dispatch,stats=line.split('\t'); rows[(k,x,ww,sp)]=(bits,dict(x.split('=') for x in dispatch.split(',') if x),stats)
 assert len(rows)==72;return rows
a,b=read('previous'),read('scalar-projected');changed=[]
for key in a:
 x,y=a[key],b[key];assert x[2]==y[2];delta={k:int(y[1].get(k,0))-int(x[1].get(k,0)) for k in x[1].keys()|y[1].keys() if x[1].get(k)!=y[1].get(k)}
 if delta or x[0]!=y[0]:changed.append(dict(key=key,delta=delta,old=x[0],new=y[0]))
print(json.dumps(changed,indent=1))
