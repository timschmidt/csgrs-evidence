from pathlib import Path
import json,sys,subprocess,hashlib
from record import record
w=Path(__file__).parent
for name in ['registered-sizes.json','alpha-sizes.json','alpha-client-sizes.json','trace-changes.json','confirmation.json','guest-stack.json','groups.json','alpha-lifetime.json','alpha-timing.json','review-commit','alpha-review-commit','witness-images.json','logs/retained-owner','logs/alpha-green-final','logs/alpha-wasi','alpha-deploy-sizes.json','layout-evidence.json','matched-lifetime.json','matched-groups.json','matched-guest-stack.json','alpha-matched-registered-sizes.json','logs/matched-final-rustdoc','logs/matched-final-clippy','logs/alpha-trace-compare','logs/declarations','logs/scan-final']:
 assert (w/name).is_file(),name
p=[]
for glob in ['*.py','*.sh','*.json','*.md','*.rs','*.patch','*.mjs','*.c','*.txt','*review-commit','*retained-commit','env','ast.tsv','syntax/Cargo.toml','syntax/Cargo.lock','syntax/src/*.rs','client/Cargo.toml','client/Cargo.lock','client/src/main.rs','alpha-client/Cargo.toml','alpha-client/Cargo.lock','alpha-client/src/main.rs','logs/*','source/*']:
 p.extend(x for x in w.glob(glob) if x.is_file() and not x.name.endswith('.jsonl') and x.name not in ('archive.json',))
p=sorted(set(p));assert all(x.stat().st_size<4*1024**2 for x in p)
obj=record('solver-orientation',p,'Archive Phase 7 source inventory and signed-gradient and proof qualification')
(w/'archive.json').write_text(json.dumps(obj,indent=2)+'\n');print(obj)
