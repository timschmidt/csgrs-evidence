import json,csv,sys,subprocess
from pathlib import Path
w=Path(__file__).parent;root=w/'control';src=root/'crates/hypersolve/src'
mods={'interval','real_interval','jacobian','linalg','alpha','root_isolation','certification','residual_replay'}
paths={src/(m+'.rs') for m in mods}
paths.update(src.glob('algebraic*.rs'))
for p in src.glob('algebraic*'):
 if p.is_dir(): paths.update(p.rglob('*.rs'))
paths.update(src/f for f in ('interval_migration/algebraic.rs','interval_migration/root_isolation.rs','root_isolation_monic_tests.rs'))
paths=sorted(p.relative_to(root) for p in paths)
run=subprocess.check_output([w/'syntax-target/debug/machine-source-map-oracle',*paths],cwd=root,text=True)
(w/'ast.tsv').write_text(run)
actual={tuple(l.split('\t')) for l in run.splitlines()};assert len(actual)==len(run.splitlines())
def scanned(text):
 rows=csv.DictReader(text.splitlines(),delimiter='\t');return {(r['path'],r['line'],r['kind'],r['symbol']) for r in rows if r['repository']=='csgrs' and r['review_status'].startswith('lexical') and Path(r['path']) in paths}
prev=scanned(subprocess.check_output(['git','show','590b87f32:interval-inventory.tsv'],text=True))
old_source=scanned((w/'preview.tsv').read_text())
print('files',len(paths),'syntax',len(actual),'old',len(prev),'new',len(old_source),'missing',sorted(actual-old_source)[:20],'excess',sorted(old_source-actual)[:20])
