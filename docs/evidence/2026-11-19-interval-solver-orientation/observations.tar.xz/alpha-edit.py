from pathlib import Path
import sys
p=Path(sys.argv[1])/'crates/hypersolve/src/alpha.rs';s=p.read_text()
start=s.index('    let residual_is_zero =');end=s.index('    let numerator =',start)
s=s[:start]+'''    let policy = policy.certified_only();
    let residual_order = compare_reals(&residual_abs, &Real::zero(), policy).value();
    let derivative_order = compare_reals(&derivative_abs, &Real::zero(), policy).value();

    if derivative_order == Some(Ordering::Equal) {
        return alpha_status(match residual_order {
            Some(Ordering::Equal) => UnivariateQuadraticAlphaStatus::ExactMultipleRoot,
            Some(_) => UnivariateQuadraticAlphaStatus::ZeroDerivative,
            None => UnivariateQuadraticAlphaStatus::Undecided,
        });
    }
    if residual_order == Some(Ordering::Equal) {
        if derivative_order.is_none() {
            return alpha_status(UnivariateQuadraticAlphaStatus::Undecided);
        }
        return AlphaBoundClassification {
            status: UnivariateQuadraticAlphaStatus::ExactSimpleRoot,
            alpha_numerator: Some(Real::zero()),
            alpha_denominator: Some(derivative_abs.clone() * derivative_abs),
        };
    }

'''+s[end:]
start=s.index('        Some(Ordering::Less | Ordering::Equal) => {',start);end=s.index('    };',start)
s=s[:start]+'''        // A strict inequality proves the denominator positive because the left side is nonnegative.
        Some(Ordering::Less) => UnivariateQuadraticAlphaStatus::CertifiedSmaleAlphaBound,
        Some(Ordering::Equal) if derivative_order.is_some() => {
            UnivariateQuadraticAlphaStatus::CertifiedSmaleAlphaBound
        }
        Some(Ordering::Greater) => UnivariateQuadraticAlphaStatus::BoundFailed,
        Some(Ordering::Equal) | None => UnivariateQuadraticAlphaStatus::Undecided,
'''+s[end:];p.write_text(s)
