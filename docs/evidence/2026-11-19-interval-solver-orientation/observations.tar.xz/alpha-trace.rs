use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use hypersolve::{
    Constraint, Expr, Problem, SymbolId, UnivariateQuadraticAlphaStatus as Status,
    certify_univariate_quadratic_alpha, context_from_problem,
};

fn classify(linear: Real, constant: Real, policy: PredicatePolicy) -> Status {
    let mut problem = Problem::default();
    problem.add_variable("x", Real::zero());
    let x = Expr::symbol(SymbolId(0), "x");
    problem.add_constraint(Constraint::equality(
        "quadratic",
        x.clone().powi(2) + Expr::real(linear) * x + Expr::real(constant),
    ));
    let report = certify_univariate_quadratic_alpha(
        &problem.analyze(),
        &context_from_problem(&problem),
        policy,
    );
    assert_eq!(report.examined_rows, 1);
    assert_eq!(
        report.certified_rows,
        usize::from(report.rows[0].status.is_certified())
    );
    report.rows.into_iter().next().unwrap().status
}

#[test]
fn ordinary_root_proof_dispatch() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for b in -4..=4 {
            for c in -3..=3 {
                hyperreal::dispatch_trace::reset();
                let s=hyperreal::dispatch_trace::with_recording(|| classify(Real::from(b),Real::from(c),policy));
                let t=hyperreal::dispatch_trace::take_trace();
                let mut counts=t.dispatch.into_iter().map(|e|format!("{}/{}/{}={}",e.layer,e.operation,e.path,e.count)).collect::<Vec<_>>();counts.sort();
                println!("PROOF {policy:?} {b} {c} {s:?} {} {:?}",counts.join(","),t.rational);
            }
        }
    }
}
