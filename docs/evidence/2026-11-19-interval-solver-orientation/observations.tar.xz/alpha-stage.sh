set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/control"
export CARGO_TARGET_DIR="$w/owner-1.95.0-native" GMP_MPFR_SYS_CACHE="$w/gmp-cache" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
python3 "$w/alpha-edit.py" "$PWD"
cargo +1.95.0 fmt --manifest-path crates/hypersolve/Cargo.toml
git diff -- crates/hypersolve/src/alpha.rs > "$w/alpha-fix.patch"
cp crates/hypersolve/tests/alpha_proof_classification.rs "$w/alpha-witness-final.rs"
cargo +1.95.0 build --release --all-features --locked -p hypersolve --test smoke --test alpha_proof_classification --bench certification --message-format=json > "$w/logs/alpha-artifact.jsonl" 2> "$w/logs/alpha-actual"
python3 - "$w" <<'PY'
import json,sys,shutil
from pathlib import Path
w=Path(sys.argv[1])
for l in (w/'logs/alpha-artifact.jsonl').read_text().splitlines():
 a=json.loads(l);n=a.get('target',{}).get('name','')
 if a.get('executable') and n in ['smoke','alpha_proof_classification','certification']:shutil.copy(a['executable'],w/f'reg-{n}-alpha')
PY
"$w/reg-alpha_proof_classification-alpha" > "$w/logs/alpha-green" 2>&1
"$w/reg-smoke-alpha" univariate_quadratic_alpha > "$w/logs/alpha-smoke" 2>&1
