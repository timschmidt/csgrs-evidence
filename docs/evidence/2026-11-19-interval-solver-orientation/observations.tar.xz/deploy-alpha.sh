set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
export CARGO_TARGET_DIR="$w/application" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
cd "$w/deploy/csgrs"
for stage in alpha-matched; do
 git switch --quiet --detach 590b87f32
 git apply "$w/alpha-matched.patch"
 (cd ../alumina-interface && cargo +stable build --locked --release --manifest-path ../alumina-interface/Cargo.toml --lib -p alumina-interface --target wasm32-unknown-unknown) > "$w/logs/application-$stage" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/alumina_interface.wasm" "$w/app-$stage.wasm"
 mkdir -p "$w/web/$stage"
 /home/tim/.cache/trunk/wasm-bindgen-0.2.122/wasm-bindgen --target web --out-dir "$w/web/$stage" --out-name alumina-interface "$w/app-$stage.wasm" >> "$w/logs/application-$stage" 2>&1
 wasm-opt -Oz --enable-bulk-memory --enable-nontrapping-float-to-int "$w/web/$stage/alumina-interface_bg.wasm" -o "$w/app-$stage-opt.wasm" >> "$w/logs/application-$stage" 2>&1
done
