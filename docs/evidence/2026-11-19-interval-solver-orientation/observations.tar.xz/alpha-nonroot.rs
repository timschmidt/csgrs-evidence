use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use hypersolve::{
    Constraint, Expr, Problem, SymbolId, UnivariateQuadraticAlphaStatus as Status,
    certify_univariate_quadratic_alpha, context_from_problem,
};

fn classify(linear: Real, constant: Real, policy: PredicatePolicy) -> Status {
    let mut problem = Problem::default();
    problem.add_variable("x", Real::zero());
    let x = Expr::symbol(SymbolId(0), "x");
    problem.add_constraint(Constraint::equality(
        "quadratic",
        x.clone().powi(2) + Expr::real(linear) * x + Expr::real(constant),
    ));
    let report = certify_univariate_quadratic_alpha(
        &problem.analyze(),
        &context_from_problem(&problem),
        policy,
    );
    assert_eq!(report.examined_rows, 1);
    assert_eq!(
        report.certified_rows,
        usize::from(report.rows[0].status.is_certified())
    );
    report.rows.into_iter().next().unwrap().status
}


#[test]
fn probe() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let t=Real::e();
        let z=(Real::from(2)*&t).sin()-Real::from(2)*t.clone().sin()*t.cos();
        let c=z+Real::from(2).powi((-600).into()).unwrap();
        println!("NONROOT {policy:?} {:?}",classify(Real::one(),c,policy));
    }
}
