set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/control"
cp "$w/alpha-full.rs" crates/hypersolve/tests/alpha_proof_classification.rs
export CARGO_TARGET_DIR="$w/alpha-wasi" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-1.95.0" PATH="$w/bin:$PATH"
cargo +1.95.0 test --locked --release --all-features -p hypersolve --target wasm32-wasip1 --config "target.wasm32-wasip1.runner=['node','$w/control/crates/hyperlattice-interval/conformance/run-wasi-test.mjs']" --test alpha_proof_classification -- --test-threads=1 > "$w/logs/alpha-wasi" 2>&1
