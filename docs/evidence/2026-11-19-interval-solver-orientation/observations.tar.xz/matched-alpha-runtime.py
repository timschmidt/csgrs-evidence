import resource,subprocess,os,statistics,json,sys,re,time
from pathlib import Path
w=Path(__file__).parent;runner=Path('/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs');rows=[];timings=[]
for v in ['1.95.0','stable']:
 for target in ['native','wasi']:
  for mode,repeats in [('common',1),('common',7),('opaque',1)]:
   stages=['fixed','previous','matched'] if mode=='common' else ['matched']
   for s in stages:
    exe=w/f'alpha-img-{s}-{v}-{target}'
    if target=='wasi':
     val=subprocess.check_output([w/'bin/node',runner,exe,mode,str(repeats)],text=True,stderr=subprocess.DEVNULL).strip()
     rows.append(dict(v=v,target=target,mode=mode,n=repeats,stage=s,output=val));continue
    args=['proof-client',mode,str(repeats)];sam=[]
    for p in ['95','27','af']:
     run=subprocess.run(args,executable=exe,capture_output=True,check=True,text=True,env=os.environ|dict(LD_PRELOAD=str(w/'stackview.so'),STACK_PATTERN=p));sam.append(list(map(int,re.search(r'HEADROOM (.*)',run.stderr)[1].split())))
    mem=subprocess.run(args,executable=exe,capture_output=True,check=True,text=True,env=os.environ|dict(LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libmemusage.so'))
    heap=list(map(int,re.search(r'heap total: (\d+), heap peak: (\d+)',mem.stderr).groups()));al={a:[int(x),int(y),int(z)] for a,x,y,z in re.findall(r'(malloc|realloc|calloc|free)\|\s+(\d+)\s+(\d+)\s+(\d+)',mem.stderr)}
    rows.append(dict(v=v,target=target,mode=mode,n=repeats,stage=s,output=mem.stdout.strip(),alloc=al,heap=heap,stack=sam))
(w/'matched-lifetime.json').write_text(json.dumps(rows,indent=1))
for v in ['1.95.0','stable']:
 for n in [1,7]:
  a,b,c=[r for r in rows if r['target']=='native' and r['v']==v and r['mode']=='common' and r['n']==n];p=lambda r:max(x[3] for x in r['stack']);print(v,n,[p(x) for x in (a,b,c)],[x['heap'] for x in (a,b,c)],'alloc identical',b['alloc']==c['alloc'])
def cpu():
 r=resource.getrusage(resource.RUSAGE_CHILDREN);return r.ru_utime+r.ru_stime
for v in ['1.95.0','stable']:
 for i in range(10):
  for s in (['previous','matched'] if i%2==0 else ['matched','previous']):
   start=time.monotonic();t=cpu();val=subprocess.check_output(['taskset','-c','15',w/f'alpha-img-{s}-{v}-native','common','20'],text=True).strip()
   timings.append(dict(v=v,i=i,stage=s,wall=time.monotonic()-start,cpu=cpu()-t,output=val))
(w/'matched-timing.json').write_text(json.dumps(timings,indent=1))
