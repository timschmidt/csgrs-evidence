from pathlib import Path
import subprocess,re,json
w=Path(__file__).parent;rows=[]
for v in ['1.95.0','stable']:
 for stage in ['fixed','previous','matched']:
  image=w/f'alpha-img-{stage}-{v}-wasi';wat=w/'matched-client-stack.wat';guest=w/'matched-client-stack.wasm'
  subprocess.run(['wasm-dis','--all-features',image,'-o',wat],check=True)
  code=wat.read_text();assert '(global $__stack_pointer (mut i32) (i32.const 1048576))' in code
  writes=code.count('(global.set $__stack_pointer');assert writes>1000
  code=code.replace('(global.set $__stack_pointer','(call $measure_sp').rstrip()
  assert code.endswith(')')
  code=code[:-1]+'''
  (global $low (mut i32) (i32.const 1048576))
  (export "low" (global $low))
  (func $measure_sp (param $p i32)
    (if (i32.lt_u (local.get $p) (global.get $low))
        (then (global.set $low (local.get $p))))
    (global.set $__stack_pointer (local.get $p)))
  )
'''
  wat.write_text(code);subprocess.run(['wasm-as','--all-features',wat,'-o',guest],check=True)
  for mode in (['common','opaque'] if stage=='matched' else ['common']):
   for nr,n in [(63,1),(63,7)] if mode=='common' else [(63,1)]:
    args=[mode,str(n)]
    ref=subprocess.check_output([w/'bin/node','/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs',image,*args],stderr=subprocess.DEVNULL,text=True).strip()
    out=subprocess.check_output([w/'bin/node',w/'guest-stack.mjs',guest,*args],stderr=subprocess.DEVNULL,text=True).splitlines()
    assert len(out)==2 and ref==out[0] and 0<int(out[1])<512*1024
    rows.append(dict(v=v,stage=stage,mode=mode,rows=nr,repeats=n,output=ref,stack_writes=writes,peak=int(out[1]),headroom=1048576-int(out[1])))
  wat.unlink();guest.unlink()
(w/'matched-guest-stack.json').write_text(json.dumps(rows,indent=1))
