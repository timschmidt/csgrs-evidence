import subprocess,tomllib,sys,tarfile,hashlib,shutil
from pathlib import Path
w=Path(__file__).parent
for v in ('stable','1.95.0'):
 root=Path(subprocess.check_output(['rustc','+'+v,'--print','sysroot'],text=True).strip())
 lib=root/'lib/rustlib'; man=tomllib.loads((lib/'multirust-channel-manifest.toml').read_text())
 spec=man['pkg']['rust-std']['target']['wasm32-wasip1']
 arc=w/('std-'+v+'.xz')
 subprocess.run(['curl','--retry','2','-fsSL',spec['xz_url'],'-o',arc],check=True)
 assert hashlib.sha256(arc.read_bytes()).hexdigest()==spec['xz_hash']
 dest=w/('sysroot-'+v)/'lib/rustlib';dest.mkdir(parents=True,exist_ok=True)
 for host in lib.iterdir():
  if host.is_dir() and not (dest/host.name).exists():(dest/host.name).symlink_to(host)
 with tarfile.open(arc,'r:xz') as tar:
  for m in tar:
   parts=Path(m.name).parts
   if m.isfile() and 'rustlib' in parts:
    p=dest.joinpath(*parts[parts.index('rustlib')+1:]);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('wb') as f:shutil.copyfileobj(tar.extractfile(m),f)
 arc.unlink()
 print(v,spec['xz_hash'],flush=True)
