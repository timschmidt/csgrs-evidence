from pathlib import Path
import sys,json,hashlib
from size import size,caps
w=Path(__file__).parent
names=['application','application-optimized']
db=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())
def previous_charge(n,k):
 name={'certification':'crates/hypersolve/benches/certification.rs','gmp_api_coverage':'crates/hyperreal/tests/gmp_api_coverage.rs#release-tests'}.get(n)
 if not name:return 0
 acc=next(a for a in db['accounts'] if a['artifact']==name)
 metrics=acc['metrics']
 metric=metrics.get(k) or metrics.get({'.text':'text','function_union':'monomorphized_text_sum'}.get(k,''))
 return 0 if not metric else metric.get('accepted_positive_growth_bytes',max(0,metric.get('net_growth_bytes',0)))
out={}
for name in names:
 t='wasi' if name.startswith('application') else 'native'
 for stage in ['alpha-matched']:
  def path(s):
   if t=='wasi':return w/('app-'+s+('-opt' if name.endswith('-optimized') else '')+'.wasm')
   if name in ['scalar_micro','gmp_api_coverage'] and s=='scalar-projected':s='scalar'
   return w/f'reg-{name}-{s}'
  p={s:path(s) for s in ['fixed','previous',stage]}
  if any(not x.exists() for x in p.values()):continue
  sets={s:size(x,t) for s,x in p.items()};rows={};bad=[]
  for k in sorted(set.union(*(set(m) for m in sets.values()))):
   base,prev,a=[ss.get(k,0) for ss in sets.values()]
   cap=caps['wasm_final_file_and_code' if t=='wasi' else ('native_monomorphized_text_sum' if k in ('.text','function_union') else 'native_final_file_and_allocated_sections')]
   old=max(max(0,prev-base),previous_charge(name,k));inc=max(0,a-prev);cum=old+inc;ic=min(cap['incremental_bytes'],int(prev*cap['incremental_percent']/100));cc=min(cap['cumulative_bytes'],int(base*cap['cumulative_percent']/100))
   if inc>ic or (inc and cum>cc):bad.append(k)
   rows[k]=dict(fixed=base,previous=prev,candidate=a,delta=a-prev,delta_percent=100*(a-prev)/prev if prev else None,previous_positive_charge=old,incremental_charge=inc,incremental_remaining=ic-inc,cumulative_charge=cum,cumulative_remaining=cc-cum)
  out[f'{name}-{stage}']=dict(metrics=rows,failed=bad,sha={s:hashlib.sha256(x.read_bytes()).hexdigest() for s,x in p.items()})
  print(name,stage,'file delta',rows['file']['delta'],'failed',[(k,rows[k]['fixed'],rows[k]['previous'],rows[k]['candidate'],rows[k]['incremental_remaining'],rows[k]['cumulative_remaining']) for k in bad])
(w/'alpha-deploy-sizes.json').write_text(json.dumps(out,indent=1))
