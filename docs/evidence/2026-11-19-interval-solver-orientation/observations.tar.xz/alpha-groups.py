from pathlib import Path
import json,subprocess,os
w=Path(__file__).parent;allrows=[]
runner='/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs'
for v in ('1.95.0','stable'):
 for platform in ('native','wasi'):
  for stage in ('fixed','previous','alpha'):
   for mode in (('common','opaque') if stage=='alpha' else ('common',)):
    for nr,n in [(63,1),(63,7)] if mode=='common' else [(63,1)]:
     name=f'interval-orientation-{os.getpid()}-{len(allrows)}'
     opts=['systemd-run','--user','--quiet','--unit',name,'--service-type=oneshot','-p','RemainAfterExit=yes','-p','MemoryMax=256M','-p','MemorySwapMax=0']
     cmd=[w/f'alpha-img-{stage}-{v}-{platform}',mode,str(n)]
     if platform=='wasi':cmd=[w/'bin/node',runner,*cmd]
     try:
      subprocess.run([*opts,'--',*cmd],check=True)
      output=subprocess.check_output(['systemctl','--user','show',name,'-p','MemoryPeak','-p','MemoryMax','-p','MemorySwapMax','-p','ExecMainStatus','-p','Result','-p','ControlGroup'],text=True)
      fields=dict(l.split('=',1) for l in output.splitlines());assert fields['Result']=='success' and fields['ExecMainStatus']=='0',fields
      assert 0<int(fields['MemoryPeak'])<=192*1024**2 and int(fields['MemoryMax'])==256*1024**2 and fields['MemorySwapMax']=='0'
      allrows.append(dict(v=v,platform=platform,stage=stage,mode=mode,rows=nr,repeats=n,**fields))
     finally:subprocess.run(['systemctl','--user','stop',name],check=False)
(w/'alpha-groups.json').write_text(json.dumps(allrows,indent=1));print(len(allrows),max(int(r['MemoryPeak']) for r in allrows))
