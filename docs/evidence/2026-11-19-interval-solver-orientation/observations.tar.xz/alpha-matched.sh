set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/alpha-owner"
for s in matched; do
 case "$s" in
  matched) git switch --quiet --detach 590b87f32; git apply "$w/alpha-fix.patch"; python3 "$w/alpha-match.py" "$PWD"; git diff -- crates/hypersolve/src/alpha.rs > "$w/alpha-matched.patch" ;;
  alpha) git apply "$w/alpha-fix.patch" ;;
  fixed) git restore -- crates/hypersolve/src/alpha.rs; git switch --quiet --detach c9f1f9ac5 ;;
 esac
 pids=()
 for v in 1.95.0 stable; do for t in native wasi; do
  (
   export CARGO_TARGET_DIR="$w/alpha-match-$v-$t" CARGO_BUILD_JOBS=4
   args=();f=release/alpha-client
   if [ "$t" = wasi ]; then export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-$v"; args=(--target wasm32-wasip1);f=wasm32-wasip1/release/alpha-client.wasm; fi
   cargo +"$v" build --release --locked --manifest-path "$w/alpha-client/Cargo.toml" "${args[@]}" > "$w/logs/alpha-img-$s-$v-$t" 2>&1
   cp "$CARGO_TARGET_DIR/$f" "$w/alpha-img-$s-$v-$t"
  ) & pids+=("$!")
 done; done
 for pid in "${pids[@]}"; do wait "$pid"; done
done
