set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
export CARGO_TARGET_DIR="$w/owner-1.95.0-native" GMP_MPFR_SYS_CACHE="$w/gmp-cache" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
cd "$w/control"
for stage in scalar-projected previous scalar fixed; do
 case "$stage" in
 previous) git restore -- crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hypersolve/src/jacobian.rs ;;
 scalar) git apply "$w/scalar.patch" ;;
 fixed) git restore -- crates/hyperreal/src/rational/arithmetic/queries_conversion.rs; git switch --detach c9f1f9ac5 ;;
 esac
 for entry in 'hypersolve --test smoke' 'hypersolve --bench certification' 'hyperreal --bench float_convert'; do
  set -- $entry
  cargo +1.95.0 build --locked --release --all-features -p "$1" "$2" "$3" --message-format=json > "$w/logs/artifact-$stage-$3.jsonl" 2> "$w/logs/registered-$stage-$3"
  python3 - "$w" "$stage" "$3" <<'PY'
import json,sys,shutil
from pathlib import Path
w,stage,name=sys.argv[1:];w=Path(w)
art=[x['executable'] for l in (w/f'logs/artifact-{stage}-{name}.jsonl').open() if (x:=json.loads(l)).get('executable') and x['target']['name']==name];assert len(art)==1,art
shutil.copy(art[0],w/f'reg-{name}-{stage}')
PY
 done
done
