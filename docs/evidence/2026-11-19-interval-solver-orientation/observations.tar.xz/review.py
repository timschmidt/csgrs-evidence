from pathlib import Path
import csv
path=Path('interval-inventory.tsv')
module='crates/hypersolve/src/alpha.rs'
with path.open() as f:
 rd=csv.DictReader(f,delimiter='\t');fields=rd.fieldnames;source={r['symbol']:r for r in rd if r['path']==module and r['review_status'].startswith('lexical')}
rows={
'UnivariateQuadraticAlphaRow':('Per-row residual, derivative, optional bound parts and status, with source index, copied name and symbol. Missing bindings use zero placeholders and a typed status.','Owned String and Real fields. Optional numerator and denominator.','UnivariateQuadraticAlphaReport.rows'),
'UnivariateQuadraticAlphaStatus':('Seven variants distinguish simple and multiple roots, a sufficient bound, derivative zero, unbound symbol, undecided and failed bound. Variants omit predicate receipts.','Enum with SymbolId payload for an unbound symbol.','Row classifications and is_certified'),
'is_certified':('Accepts ExactSimpleRoot and CertifiedSmaleAlphaBound. The status carries no information about the comparison certainty.','Borrowed enum match.','certify_univariate_quadratic_alpha report count'),
'UnivariateQuadraticAlphaReport':('Per-row results and two stored counts over eligible rows. Other constraint families are skipped.','Owns the vector and row payloads.','Public report returned by certify_univariate_quadratic_alpha'),
'all_examined_rows_certified':('Requires a nonzero examined count equal to the certified count. Reads stored counts without replaying rows.','Two usize comparisons.','Public summary for callers and smoke / property tests'),
'certify_univariate_quadratic_alpha':('Visits active recognized univariate quadratic equality rows in source order. Uses the binding to evaluate the exact derivative and residual and delegates classification. Records missing bindings.','Grows a Vec, clones source names and retains row values and optional bound operands.','Public API, smoke tests, residual properties, certification bench'),
'AlphaBoundClassification':('Groups the candidate status and optional exact numerator and denominator. Contains no classification receipt.','Owns two optional Real values.','classify_alpha_bound and per-row report construction'),
'classify_alpha_bound':('Compares absolute residual and derivative to zero, then tests 8*abs(f)*abs(a) against abs(derivative)^2. Using value() drops certainty. An undecided derivative comparison can enter the simple-root path with a zero residual.','Real magnitudes, products and optional retained bound operands.','certify_univariate_quadratic_alpha'),
'alpha_status':('Builds a status with absent bound components for the multiple-root and zero-derivative returns.','Returns two empty Option fields.','classify_alpha_bound')
}
assert source.keys()==rows.keys()
with path.open('a',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n')
 for name,r in source.items():
  description,alloc,uses=rows[name]
  r.update(endpoint_representation='Exact Real point expressions and scalar bound parts. No interval endpoints.',semantics=description,allocation=alloc,platform='Hypersolve std API. Native release source and tests reviewed.',serialization='No codec or serde derive in this module.',consumers=uses,disposition='Retain quadratic proof semantics in Hypersolve. Receipt preservation and derivative nonzero proof remain open.',baseline_tests='hypersolve smoke and residual_props univariate_quadratic_alpha cases',baseline_benchmarks='certification / certify_univariate_quadratic_alpha_rows (mapped)',review_status='Body and immediate consumers reviewed at 590b87f32. Coverage of declarations does not certify all policy branches.')
  writer.writerow(r)
