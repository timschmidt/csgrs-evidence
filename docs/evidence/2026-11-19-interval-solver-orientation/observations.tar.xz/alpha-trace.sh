set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/control";cp "$w/alpha-trace.rs" crates/hypersolve/tests/alpha_protocol_trace.rs
export CARGO_TARGET_DIR="$w/owner-1.95.0-native" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
for s in alpha previous; do
 if [ "$s" = previous ]; then git restore -- crates/hypersolve/src/alpha.rs; fi
 cargo +1.95.0 test --locked --all-features --release -p hypersolve --test alpha_protocol_trace -- --nocapture > "$w/logs/alpha-trace-$s" 2>&1
 rg '^PROOF ' "$w/logs/alpha-trace-$s" > "$w/alpha-trace-$s.txt"
done
cmp "$w/alpha-trace-previous.txt" "$w/alpha-trace-alpha.txt" > "$w/logs/alpha-trace-compare"
