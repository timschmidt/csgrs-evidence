use hyperreal::Real;
fn main() {
 for e in [-1074,-1075,-1076,-1200] {
  let x=Real::from(2).powi(e.into()).unwrap();let y=-x.clone();let reduced=-(Real::one()*x.clone());
  for a in [&x, &y,&reduced] {println!("{} {:?} {:?} {:?} {:016x}",e,a.exact_rational().is_some(),a.structural_facts().sign,a.to_f32_lossy().map(f32::to_bits),a.to_f64_lossy().unwrap().to_bits());}
 }
}
