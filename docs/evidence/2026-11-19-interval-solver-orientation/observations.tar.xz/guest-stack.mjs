import { readFile } from "node:fs/promises";
import { WASI } from "node:wasi";
const [image,...args] = process.argv.slice(2);
const wasi = new WASI({version:"preview1",args:[image,...args],returnOnExit:true});
const {instance} = await WebAssembly.instantiate(await readFile(image),{wasi_snapshot_preview1:wasi.wasiImport});
if(wasi.start(instance)!==0) throw Error("guest failed");
console.log(1048576-instance.exports.low.value);
