use hyperreal::{Real, dispatch_trace};
use hypersolve::{Constraint, ConstraintKind, Expr, Problem, SymbolId, context_from_problem};
use hypersolve::jacobian::{symbolic_jacobian, symbolic_jacobian_with_analysis};

#[test]
fn recorded_gradient_paths() {
    for k in [ConstraintKind::Equality, ConstraintKind::Soft, ConstraintKind::LessOrEqual, ConstraintKind::GreaterOrEqual] {
        for x in [-1,0,1] {
            for w in [-1,0,1] {
                for sparse in [false,true] {
                    let mut p=Problem::default();p.add_variable("x",Real::from(x));p.add_variable("unused",Real::zero());
                    let mut row=Constraint::equality("g",Expr::symbol(SymbolId(0),"x"));row.kind=k;row.weight=Real::from(w);p.add_constraint(row);
                    let c=context_from_problem(&p);let a=p.analyze();dispatch_trace::reset();
                    let matrix=dispatch_trace::with_recording(|| if sparse {symbolic_jacobian_with_analysis(&a,&c)} else {symbolic_jacobian(&p,&c)}).unwrap();
                    let tr=dispatch_trace::take_trace();let mut counts=tr.dispatch.iter().map(|e|format!("{}/{}/{}={}",e.layer,e.operation,e.path,e.count)).collect::<Vec<_>>();counts.sort();
                    println!("TRACE\t{k:?}\t{x}\t{w}\t{sparse}\t{:?}\t{}\t{:?}",matrix[0].iter().map(|v|v.to_bits()).collect::<Vec<_>>(),counts.join(","),tr.rational);
                }
            }
        }
    }
}
