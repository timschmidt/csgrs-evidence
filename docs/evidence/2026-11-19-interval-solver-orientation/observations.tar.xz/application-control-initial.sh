set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
export CARGO_TARGET_DIR="$w/application" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
cd "$w/deploy/csgrs"
for stage in previous scalar scalar-projected fixed; do
 case "$stage" in
 scalar) git apply "$w/scalar.patch" ;;
 scalar-projected) git apply "$w/projected-final.patch" ;;
 fixed) git restore -- crates/hyperreal/src/rational/arithmetic/queries_conversion.rs crates/hypersolve/src/jacobian.rs; git switch --detach c9f1f9ac5 ;;
 esac
 cargo +1.95.0 build --locked --release --manifest-path ../alumina-interface/Cargo.toml --lib -p alumina-interface --target wasm32-unknown-unknown > "$w/logs/application-$stage" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/alumina_interface.wasm" "$w/app-$stage.wasm"
done
