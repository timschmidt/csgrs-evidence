set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/control"
cp "$w/trace-probe.rs" crates/hypersolve/tests/trace_orientation_probe.rs
export CARGO_TARGET_DIR="$w/owner-1.95.0-native" GMP_MPFR_SYS_CACHE="$w/gmp-cache" PATH="$w/host-tools/usr/bin:$w/bin:$PATH"
for s in previous scalar-projected; do
 if [ "$s" = scalar-projected ]; then git apply "$w/scalar.patch" "$w/projected-final.patch"; fi
 cargo +1.95.0 test --release --all-features --locked -p hypersolve --test trace_orientation_probe -- --nocapture > "$w/logs/trace-$s" 2>&1
done
