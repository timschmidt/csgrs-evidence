from pathlib import Path
import json,sys,os,hashlib
from size import size
w=Path(__file__).parent;root=Path('/mnt/development/csgrs')
def append(p,key,value):
 s=p.read_text();assert key not in json.loads(s) and s.endswith('\n}\n')
 p.write_text(s[:-3]+',\n  '+json.dumps(key)+': '+json.dumps(value,indent=2).replace('\n','\n  ')+'\n}\n')
def read(f):return json.loads((w/f).read_text())
base='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb'
raw=read('matched-client-sizes.json');reg=read('alpha-matched-registered-sizes.json')
for k,a in (raw|reg).items(): assert a['failed']==(['.relro_padding incremental'] if k=='stable-native' else []),(k,a['failed'])
layout=read('layout-evidence.json');assert layout['matched']==layout['recheck']
rr=raw['stable-native']['metrics']['.relro_padding'];assert rr['delta']==16 and rr['cumulative_remaining']==12
out={}
for k,a in (raw|reg).items():
 m=a['metrics'];key='code' if 'code' in m else 'function_union';out[k]={n:{f:m[n][f] for f in ['fixed','previous','candidate','delta','cumulative_charge','cumulative_remaining']} for n in ('file',key)}
out['1.99_native_padding']={'fixed':1424,'previous':656,'retained':672,'prior_charge':0,'new_charge':16,'incremental_percent':100*16/656,'remaining_incremental_bytes':0,'remaining_cumulative_bytes':12,'linker_page_size':4096,'same_pages_permissions_and_relro_payload':True}
harnesses={}
for t,p,l in [('native',w/'reg-alpha_proof_classification-matched',64*1024**2),('wasi',next((w/'alpha-wasi/wasm32-wasip1/release/deps').glob('alpha_proof_classification-*.wasm')),16*1024**2)]:
 m=size(p,t); assert m['file']<l;harnesses[t]=dict(bytes=m['file'],capacity=l,remaining=l-m['file'],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
app=read('alpha-deploy-sizes.json');assert all(not v['failed'] for v in app.values())
append(root/'docs/research/interval-size-accounts.json','quadratic_alpha_proof_classification',dict(source=(w/'alpha-retained-commit').read_text().strip(),benefit='Return honest proof statuses for unknown or approximately compared zero values under both public policies.',fixed=base,previous='590b87f32',policy='existing_artifacts with the one Rust 1.99 native NOBITS exception at alpha_client_native_layout_revision. Its new allowance is used only after the independent same-path rebuild. Original failure measurements are archived.',accounts=out,new_test_harness=harnesses,browser={k:v['metrics']['file'] for k,v in app.items()},evidence='docs/evidence/2026-11-19-interval-solver-orientation: matched-client-sizes.json, alpha-matched-registered-sizes.json, alpha-deploy-sizes.json, layout-evidence.json and full section reports; no firmware artifact links the proof API.'))
rows=read('matched-lifetime.json');guest=read('matched-guest-stack.json');cg=read('matched-groups.json')
stats={}
for v in ['1.95.0','stable']:
 natives=[];guests=[]
 for n in [1,7]:
  a,b,c=[r for r in rows if r['v']==v and r['mode']=='common' and r['target']=='native' and r['n']==n]
  peak=lambda r:max(x[3] for x in r['stack'])
  assert peak(a)==peak(b)==peak(c) and a['heap']==b['heap']==c['heap'] and a['alloc']==b['alloc']==c['alloc']
  pcs=[r for r in guest if r['v']==v and r['mode']=='common' and r['repeats']==n];assert len(set(r['peak'] for r in pcs))==1
  natives.append(peak(c));guests.append(pcs[0]['peak'])
 new=next(r for r in rows if r['v']==v and r['mode']=='opaque' and r['target']=='native')
 stats[v]=dict(existing_native_peak_heap=b['heap'][1],common_native_stack_bytes=natives,common_guest_stack_bytes=guests,incremental_bytes=0,cumulative_bytes=0,new_native_peak_requested_bytes=new['heap'][1],new_native_stack=peak(new),new_guest_stack=next(r['peak'] for r in guest if r['v']==v and r['mode']=='opaque'))
append(root/'docs/research/interval-memory-accounts.json','quadratic_alpha_proof_classification',dict(fixed=base,previous='590b87f32',source=(w/'alpha-retained-commit').read_text().strip(),workload='63 quadratic rows per evaluation, both policies, 1 and 7 repetitions; complete model construction, proof classification, field checks and destruction. One native worker or WASI instance per process.',scope='No positive memory charge on common workloads. Fixed, previous and retained stack, requested heap, allocator counts and bytes freed agree. Opaque unresolved input is a separate correctly completed workload.',metrics=stats,process_groups=len(cg),peak_process_bytes=max(int(x['MemoryPeak']) for x in cg),process_limit_bytes=256*1024**2,required_free_bytes=64*1024**2,evidence='docs/evidence/2026-11-19-interval-solver-orientation: matched-lifetime.json, matched-guest-stack.json, matched-groups.json and alpha-scope.md'))
