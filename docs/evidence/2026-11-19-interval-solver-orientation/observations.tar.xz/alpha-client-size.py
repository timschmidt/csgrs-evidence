from pathlib import Path
import json,hashlib,sys,importlib.util
w=Path(__file__).parent
spec=importlib.util.spec_from_file_location('metrics',w/'image_metrics.py');metrics=importlib.util.module_from_spec(spec);spec.loader.exec_module(metrics)
caps=json.loads(Path('/mnt/development/csgrs/docs/research/interval-size-accounts.json').read_text())['existing_artifacts']
def size(p,target):
 if target=='native':return metrics.sizes(p)
 data=p.read_bytes();assert data[:8]==b'\0asm\x01\0\0\0';i=8;result={'file':len(data)}
 while i<len(data):
  key=data[i];i+=1;n=shift=0
  while True:
   b=data[i];i+=1;n+=(b&127)<<shift
   if b<128:break
   shift+=7
  if key==10:result['code']=n
  i+=n
 assert i==len(data) and 'code' in result
 return result
if __name__=='__main__':
 trial=sys.argv[1];out={}
 for v in ('1.95.0','stable'):
  for t in ('native','wasi'):
   files={s:w/f'alpha-img-{s}-{v}-{t}' for s in ['fixed','previous',trial]}
   if not files['fixed'].exists():del files['fixed']
   if not files[trial].exists():continue
   ss={s:size(p,t) for s,p in files.items()}
   rows={};failed=[]
   for key in sorted(set.union(*(set(m) for m in ss.values()))):
    a,b=ss['previous'].get(key,0),ss[trial].get(key,0)
    cap=caps['wasm_final_file_and_code' if t=='wasi' else ('native_monomorphized_text_sum' if key in ('.text','function_union') else 'native_final_file_and_allocated_sections')]
    pos=max(0,b-a);inc=min(cap['incremental_bytes'],int(a*cap['incremental_percent']/100))
    row=dict(previous=a,candidate=b,delta=b-a,incremental_remaining=inc-pos)
    if pos>inc:failed.append(key+' incremental')
    if 'fixed' in ss:
     fx=ss['fixed'].get(key,0);cum=max(0,a-fx)+pos;ccap=min(cap['cumulative_bytes'],int(fx*cap['cumulative_percent']/100))
     row.update(fixed=fx,cumulative_charge=cum,cumulative_remaining=ccap-cum)
     if cum>ccap and pos>0:failed.append(key+' cumulative')
    rows[key]=row
   out[v+'-'+t]=dict(metrics=rows,failed=failed,sha={s:hashlib.sha256(p.read_bytes()).hexdigest() for s,p in files.items()})
   print(v,t,rows['file'],failed)
 (w/(trial+'-client-sizes.json')).write_text(json.dumps(out,indent=2)+'\n')
