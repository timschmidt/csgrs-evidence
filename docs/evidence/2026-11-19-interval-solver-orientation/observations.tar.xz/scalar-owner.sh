set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
cd "$w/scalar-owner"
export CARGO_TARGET_DIR="$w/scalar-native" GMP_MPFR_SYS_CACHE="$w/gmp-cache" PATH="$w/host-tools/usr/bin:$w/bin:$PATH" HYPERREAL_SKIP_BENCHMARK_REPORTS=1
for stage in previous scalar fixed; do
 case "$stage" in
 scalar) git apply "$w/scalar.patch"; cp /mnt/development/csgrs/crates/hyperreal/tests/gmp_api_coverage.rs crates/hyperreal/tests/gmp_api_coverage.rs; cp /mnt/development/csgrs/crates/hyperreal/src/real/convert.rs crates/hyperreal/src/real/convert.rs ;;
 fixed) git restore -- crates/hyperreal; git switch --detach c9f1f9ac5 ;;
 esac
 cargo +1.95.0 build --locked --release -p hyperreal --all-features --test gmp_api_coverage --bench scalar_micro --message-format=json > "$w/logs/artifacts-real-$stage.jsonl" 2> "$w/logs/scalar-actual-$stage"
 python3 - "$w" "$stage" <<'PY'
import sys,json,shutil
from pathlib import Path
w=Path(sys.argv[1]);stage=sys.argv[2]
for l in (w/f'logs/artifacts-real-{stage}.jsonl').read_text().splitlines():
 a=json.loads(l)
 if a.get('executable') and a['target']['name'] in ['gmp_api_coverage','scalar_micro']:shutil.copy(a['executable'],w/f'reg-{a["target"]["name"]}-{stage}')
PY
done
