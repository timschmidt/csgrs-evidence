set -eu
. /mnt/development/.interval-refactor-build/solver-orientation.twnj5n/env
for i in {1..80}; do if test -s "$w/alpha-img-fixed-stable-native" && test -s "$w/alpha-img-fixed-1.95.0-native" && test -s "$w/alpha-img-fixed-stable-wasi" && test -s "$w/alpha-img-fixed-1.95.0-wasi"; then break; fi; sleep 3; done
bash "$w/alpha-matched.sh"
python3 "$w/alpha-client-size.py" matched > "$w/logs/alpha-matched-sizes"
