from pathlib import Path
import subprocess,os,json,re
w=Path(__file__).parent;rows=[]
for v in ['1.95.0','stable']:
 for nr,n in [(1,1),(8,1),(32,100),(256,3)]:
  for mode in ['common','equivalent']:
   for stage in (['fixed','previous','scalar-projected'] if mode=='common' else ['scalar-projected']):
    exe=w/f'{stage}-{v}-native';args=["jacobian-client",mode,str(nr),str(n)]
    peaks=[]
    for pattern in ['d7','13','fd','21']:
     p=subprocess.run(args,executable=exe,check=True,capture_output=True,text=True,env=os.environ|dict(STACK_PATTERN=pattern,LD_PRELOAD=str(w/'stackview.so')))
     peaks.append([int(x) for x in re.search(r'HEADROOM (.*)',p.stderr)[1].split()])
    mem=subprocess.run(args,executable=exe,check=True,capture_output=True,text=True,env=os.environ|dict(LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libmemusage.so'))
    totals=list(map(int,re.search(r'heap total: (\d+), heap peak: (\d+)',mem.stderr).groups()))
    counts={a:[int(x),int(y),int(z)] for a,x,y,z in re.findall(r'(malloc|realloc|calloc|free)\|\s+(\d+)\s+(\d+)\s+(\d+)',mem.stderr)}
    rows.append(dict(v=v,mode=mode,rows=nr,repeats=n,stage=stage,output=p.stdout.strip(),peak=max(s[3] for s in peaks),reserve=min(s[4] for s in peaks),samples=peaks,heap=totals,allocator=counts))
(w/'confirmation.json').write_text(json.dumps(rows,indent=1))
for v in ['1.95.0','stable']:
 for nr in [1,8,32,256]:
  f,b,a=[r for r in rows if r['v']==v and r['rows']==nr and r['mode']=='common']
  inc=max(0,a['peak']-b['peak']);cum=max(0,b['peak']-f['peak'])+inc
  ok=inc<=min(32,b['peak']*.005) and cum<=min(64,f['peak']*.01) and a['peak']<16384 and a['reserve']>=1048576 and f['heap']==b['heap']==a['heap'] and f['allocator']==b['allocator']==a['allocator']
  print(v,nr,'stack',f['peak'],b['peak'],a['peak'],'incremental',inc,'cumulative',cum,'pass',ok)
