use hyperlimit::{PredicatePolicy,compare_reals};
use hyperreal::Real;
use hypersolve::{Expr,SymbolId,Problem,Constraint,context_from_problem,certify_univariate_quadratic_alpha};
#[test]
fn known_multiple_root_with_different_coefficient_sources() {
 for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512] {
  let theta=Real::e(); let sine=theta.clone().sin();let cosine=theta.clone().cos();
  let zero=sine.clone().powi(2.into()).unwrap()+cosine.clone().powi(2.into()).unwrap()-Real::one();
  let double_angle=(Real::from(2)*theta.clone()).sin()-Real::from(2)*sine.clone()*cosine.clone();
  let product=(theta.clone()+Real::one()).sin()-sine*Real::one().cos()-cosine*Real::one().sin();
  for (name,identity) in [("powers",zero),("double-angle",double_angle),("sum",product)] {
   let d=compare_reals(&identity.abs(),&Real::zero(),policy);
   let x=Expr::symbol(SymbolId(0),"x");
   let mut p=Problem::default();p.add_variable("x",Real::zero());
   p.add_constraint(Constraint::equality("x*x + identity*x",x.clone().powi(2)+Expr::real(identity)*x));
   let r=certify_univariate_quadratic_alpha(&p.analyze(),&context_from_problem(&p),policy);
   println!("ALPHA {name} {policy:?} derivative comparison {d:?}, report {:?}, certified {}",r.rows.first().map(|x| &x.status),r.all_examined_rows_certified());
  }
 }
}
