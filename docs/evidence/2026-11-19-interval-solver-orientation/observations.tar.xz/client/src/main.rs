use hyperreal::Real;
use hypersolve::{Constraint, ConstraintKind, Expr, Problem, SymbolId, SolverConfig, SolverState, context_from_problem, solve_damped_least_squares};
use hypersolve::jacobian::{FiniteDifferenceConfig, finite_difference_jacobian, symbolic_jacobian, symbolic_jacobian_with_analysis};
fn main() {
    if let Some(mode) = std::env::args().nth(1) { matrix(&mode); return; }
    for kind in [ConstraintKind::LessOrEqual, ConstraintKind::GreaterOrEqual] {
        let mut problem = Problem::default();
        problem.add_variable("x", Real::from(-3));
        let x = Expr::symbol(SymbolId(0),"x");
        let mut row = Constraint::equality("feasible at x >= 0", if kind==ConstraintKind::GreaterOrEqual {x} else {-x});
        row.kind = kind;
        row.weight = Real::from(2);
        problem.add_constraint(row);
        let c = context_from_problem(&problem);
        println!("{kind:?} plain {:?} prepared {:?} finite {:?}",symbolic_jacobian(&problem,&c).unwrap(),symbolic_jacobian_with_analysis(&problem.analyze(),&c).unwrap(),finite_difference_jacobian(&problem,&c,FiniteDifferenceConfig{step:Real::one()}).unwrap());
        let report=solve_damped_least_squares(SolverState{problem,config:SolverConfig{damping:Real::zero(),..Default::default()}});
        println!("{kind:?} reason {:?} iterations {} final {:?}",report.reason,report.iterations,report.residuals.last().and_then(|r|r.weighted_dense_solver_estimate));
    }
}
fn matrix(mode: &str) {
    let rows: usize = std::env::args().nth(2).unwrap().parse().unwrap();
    let repeats: usize = std::env::args().nth(3).unwrap().parse().unwrap();
    let mut model = Problem::default();
    for (name, value) in [("x", 3), ("y", 0), ("unused", 0)] {model.add_variable(name, Real::from(value));}
    let x = Expr::symbol(SymbolId(0), "x");
    let y = Expr::symbol(SymbolId(1), "y");
    let mut expected = Vec::new();
    for i in 0..rows {
        let (a, b) = (i as i32 % 5 + 1, i as i32 % 7 - 4);
        let expr = Expr::int(a.into()) * x.clone() + Expr::int(b.into()) * y.clone();
        let negative_form = mode == "equivalent";
        let mut row = Constraint::equality("row", if negative_form { -expr } else { expr });
        row.kind = if negative_form {ConstraintKind::GreaterOrEqual} else if i % 2 == 0 {ConstraintKind::Equality} else {ConstraintKind::LessOrEqual};
        let weight=i as i32 % 3 - 1;
        row.weight = Real::from(weight);
        model.add_constraint(row);
        expected.push(vec![f64::from(a*weight), f64::from(b*weight), 0.0]);
    }
    let context=context_from_problem(&model);
    let analysis=model.analyze();
    let mut hash=0u64;
    for _ in 0..repeats {
        let m=symbolic_jacobian_with_analysis(std::hint::black_box(&analysis),&context).unwrap();
        assert_eq!(m,expected);
        for value in m.into_iter().flatten() {hash=hash.rotate_left(7)^value.to_bits();}
    }
    println!("{rows} {repeats} {hash}");
}
