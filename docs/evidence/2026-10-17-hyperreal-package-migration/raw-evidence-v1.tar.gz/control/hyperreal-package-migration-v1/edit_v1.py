# Apply the recorded package migration after its failures were reproduced.
import gzip,hashlib,json
from pathlib import Path
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
W=Path(__file__).resolve().parent; D=V/'paper-worktree-v1'
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((V/'hyperreal-package-baseline-result-v1.json').read_text())
assert r['command']['exit_code']==101 and not r['command']['stops']
assert r['test_terminal_rows']==[['ok','2','0','0'],['FAILED','1','1','0']]
assert 'manifest has a normal dependency table' in (V/'logs/hyperreal-package-baseline-readme-v1/stdout').read_text()
pins=json.loads(gzip.decompress((V/'hyperreal-package-source-pins-v1.json.gz').read_bytes()))
changed=['crates/hyperreal/Cargo.toml','crates/hyperreal/README.md','crates/hyperreal/tests/readme_metadata.rs']
assert all(sha(D/p)==h for p,h in pins.items())
manifest=D/changed[0]; text=manifest.read_text()
text=text.replace('readme = "README.md"\n','readme = "README.md"\n# Full validation replay bundles remain in the repository.\nexclude = ["/benchmarks/checkpoints/*.tar.gz"]\n',1)
needle='serde_json = "1.0.149"\n\n[[bin]]'
assert text.count(needle)==1
text=text.replace(needle,'serde_json = "1.0.149"\ntoml = "=0.8.23"\n\n[[bin]]')
manifest.write_text(text)
readme=D/changed[1]; text=readme.read_text()
a='Version `0.13.1` is the current crate release documented here.'
assert text.count(a)==1
text=text.replace(a,'Version `0.13.1` describes the unreleased source in this checkout.')
a='''Create a project and add Hyperreal:

```sh
cargo new exact-scalars
cd exact-scalars
cargo add hyperreal
```

Replace `src/main.rs` with:'''
b='''From the repository root, run the checked-in example for this source version:

```sh
cargo run -p hyperreal --example readme_quickstart
```

The example is:'''
assert text.count(a)==1; text=text.replace(a,b)
a='''Run it:

```sh
cargo run
```

The same program is checked in as'''
assert text.count(a)==1; text=text.replace(a,'The program is checked in as')
a='- Generate the complete API reference with `cargo doc --open`.\n'
b=a+'''
The Cargo package includes the source, examples, tests, regression fixtures,
and checkpoint summaries. Full validation replay bundles under
`benchmarks/checkpoints/*.tar.gz` remain in the repository and are excluded
from the package; use a repository checkout to replay those archived runs.
'''
assert text.count(a)==1; text=text.replace(a,b)
readme.write_text(text)
p=D/changed[2]; text=p.read_text(); start=text.index('    let manifest = include_str!("../Cargo.toml");')
text=text[:start]+'''    let manifest: toml::Table = include_str!("../Cargo.toml")
        .parse()
        .expect("Cargo.toml is valid TOML");
    let release_dependencies = manifest["dependencies"]
        .as_table()
        .expect("manifest has a normal dependency table");
    let dev_dependencies = manifest["dev-dependencies"]
        .as_table()
        .expect("manifest has a development dependency table");

    assert!(
        !release_dependencies.contains_key("rug"),
        "the GMP binding must not enter Hyperreal's release dependency graph"
    );
    assert!(
        dev_dependencies.contains_key("rug"),
        "competitive GMP benchmarks require rug as a development dependency"
    );
}
'''
p.write_text(text)
assert all(sha(D/p)==h for p,h in pins.items() if p not in changed)
marker='<!-- quickstart:start -->'; end='<!-- quickstart:end -->'
a=(V/'checkout-baseline-v1/crates/hyperreal/README.md').read_text().split(marker,1)[1].split(end,1)[0]
b=readme.read_text().split(marker,1)[1].split(end,1)[0]
assert a==b
out=V/'hyperreal-package-edits-v1.json'; assert not out.exists()
out.write_text(json.dumps({'helper_sha256':sha(Path(__file__)),
 'contract_sha256':sha(W/'contract-v1.md'),'addendum_sha256':sha(W/'contract-addendum-v1.md'),
 'changed_files':{p:{'before':pins[p],'after':sha(D/p)} for p in changed},
 'quickstart_rust_unchanged':True,'all_other_materialized_sources_unchanged':True,
 'lock_update_pending':True,'candidate_admitted':False,'release_qualified':False},indent=2)+'\n')
print(json.dumps({'changed_files':changed,'lock_update_pending':True}))
