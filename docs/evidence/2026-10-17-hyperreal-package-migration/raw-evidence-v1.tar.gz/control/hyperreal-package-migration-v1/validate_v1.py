# Validate the intentional package-content migration using actual Cargo archives.
import copy, gzip, hashlib, json, os, re, shutil, sys, tarfile, tomllib
from pathlib import Path, PurePosixPath
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent; D=V/'paper-worktree-v1'; B=V/'checkout-baseline-v1'
P=V/'hyperreal-package-candidate-v1'; A=V/'target-hyperreal-package-assembly-v1'
T=V/'target-hyperreal-package-checks-v1'; M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
assert not P.exists() and not A.exists()
assert not (V/'hyperreal-package-validation-protocol-v1.json').exists()
assert not reasons(resources()) and M.is_dir() and not list(M.iterdir())
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ.update(CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
pins=json.loads(gzip.decompress((V/'hyperreal-package-source-pins-v1.json.gz').read_bytes()))
edits=json.loads((V/'hyperreal-package-edits-v1.json').read_text())
expected={**pins,**{p:r['after'] for p,r in edits['changed_files'].items()}}
assert all(sha(D/p)==h for p,h in expected.items())
commands={}
def execute(label,args,cwd,target=T,expected_failure=None):
    name='hyperreal-package-'+label+'-v1'
    mapped={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/target.relative_to(V)),
        'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),
        'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev',
        '--ro-bind','/proc','/proc','--bind',str(V),str(M),'--chdir',str(M/cwd.relative_to(V))]
    for key,value in mapped.items():argv.extend(['--setenv',key,value])
    argv+=args
    try:result=run(name,argv,cwd,target=target)
    except RuntimeError:
        result=json.loads((V/'logs'/name/'result.json').read_text())
        if expected_failure is None:raise
    stdout=(V/'logs'/name/'stdout').read_text()
    stderr=(V/'logs'/name/'stderr').read_text()
    if expected_failure is not None:
        assert result['exit_code']==101 and not result['stops'],result
        assert expected_failure in stdout,stdout
        rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout,re.M)
        assert rows==[('FAILED','0','1','0')],rows
    commands[label]=result
    return stdout,stderr

dump(V/'hyperreal-package-validation-protocol-v1.json',{
    'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),
    'addendum_sha256':sha(W/'contract-addendum-v1.md'),'edit_receipt_sha256':sha(V/'hyperreal-package-edits-v1.json'),
    'runner_sha256':sha(V/'control/validation_runner_v2.py'),'tool_sha256':compiler['tool_sha256'],
    'source_before_lock_update':expected,'build_target':str(T),'assembly_target':str(A),
    'extracted_package':str(P),'source_changes':list(edits['changed_files'])+['Cargo.lock'],
    'features':['default','all'],'all_target_checks_and_clippy':True,
    'source_and_package_readme_tests':True,'documented_example':True,
    'negative_controls':['normal_dependency_rug','missing_dev_dependency_rug'],
    'archive_content_migration':True,'runtime_optimization':False,'full_scalar_suite':False,
    'candidate_admitted':False,'release_qualified':False,'full_plan_complete':False})

# Only the edge to an already locked development dependency may change.
execute('lock-update',[cargo,'metadata','--offline','--format-version','1'],D)
before=tomllib.loads((B/'Cargo.lock').read_text()); after=tomllib.loads((D/'Cargo.lock').read_text())
expected_lock=copy.deepcopy(before)
rows=[row for row in expected_lock['package'] if row['name']=='hyperreal']
assert len(rows)==1 and 'toml 0.8.23' not in rows[0]['dependencies']
rows[0]['dependencies']=sorted(rows[0]['dependencies']+['toml 0.8.23'])
assert expected_lock==after,'unexpected workspace lock change'
expected['Cargo.lock']=sha(D/'Cargo.lock')
assert all(sha(D/p)==h for p,h in expected.items())
dump(V/'hyperreal-package-source-after-v1.json',{
    'changed_files':{p:{'before':pins[p],'after':expected[p]} for p in expected if expected[p]!=pins[p]},
    'only_lock_change':'hyperreal adds existing toml 0.8.23 development dependency',
    'all_other_sources_unchanged':True})
execute('fmt',[cargo,'fmt','--all','--','--check'],D)
execute('assemble',[cargo,'package','-p','hyperreal','--allow-dirty','--locked','--offline','--no-verify'],D,A)
archives=list((A/'package').glob('*.crate')); assert len(archives)==1
archive=archives[0]; assert archive.name=='hyperreal-0.13.1.crate'
base=json.loads(gzip.decompress((V/'hyperreal-package-baseline-members-v1.json.gz').read_bytes()))
excluded={p:r for p,r in base.items() if PurePosixPath(p).parent==PurePosixPath('benchmarks/checkpoints') and p.endswith('.tar.gz')}
assert len(excluded)==63
allowed_changed={'Cargo.toml','Cargo.toml.orig','Cargo.lock','.cargo_vcs_info.json','README.md','tests/readme_metadata.rs'}
P.mkdir(); members={}; changed=[]
with tarfile.open(archive,'r:gz') as source:
    for member in source:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.parts[0]=='hyperreal-0.13.1' and len(path.parts)>1
        rel=str(PurePosixPath(*path.parts[1:])); assert rel not in members
        data=source.extractfile(member).read(); digest=hashlib.sha256(data).hexdigest()
        assert rel in base and rel not in excluded,rel
        if digest!=base[rel]['sha256']:
            assert rel in allowed_changed,rel
            changed.append(rel)
        else:assert len(data)==base[rel]['bytes']
        if rel not in ['Cargo.toml','Cargo.lock','.cargo_vcs_info.json']:
            src=D/'crates/hyperreal'/('Cargo.toml' if rel=='Cargo.toml.orig' else rel)
            assert sha(src)==digest,rel
        dest=P/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);dest.chmod(member.mode & 0o777)
        assert sha(dest)==digest
        members[rel]={'sha256':digest,'bytes':len(data),'mode':member.mode & 0o777}
assert set(members)==set(base)-set(excluded)
for p,row in excluded.items():
    assert sha(D/'crates/hyperreal'/p)==row['sha256'],p
old=tomllib.loads((V/'hyperreal-package-baseline-v1/Cargo.toml').read_text())
new=tomllib.loads((P/'Cargo.toml').read_text())
expected_manifest=copy.deepcopy(old)
expected_manifest['package']['exclude']=['/benchmarks/checkpoints/*.tar.gz']
expected_manifest['dev-dependencies']['toml']={'version':'=0.8.23'}
assert new==expected_manifest,'unexpected normalized manifest change'
assert not any(key in new for key in ['workspace','patch','replace'])
for table in [new,*new.get('target',{}).values()]:
    for kind in ['dependencies','build-dependencies','dev-dependencies']:
        for name,value in table.get(kind,{}).items():
            assert not isinstance(value,dict) or 'path' not in value,(kind,name)
(V/'hyperreal-package-candidate-members-v1.json.gz').write_bytes(gzip.compress((json.dumps(members,sort_keys=True)+'\n').encode(),mtime=0))
dump(V/'hyperreal-package-migration-members-v1.json',{'baseline_archive_bytes':108043832,
    'candidate_archive':str(archive),'candidate_archive_sha256':sha(archive),'candidate_archive_bytes':archive.stat().st_size,
    'baseline_members':len(base),'candidate_members':len(members),'removed_members':excluded,
    'changed_members':sorted(changed),'all_other_members_byte_identical':True,
    'all_removed_bundles_retained_in_repository':True,'features_and_normal_dependencies_unchanged':True,
    'intentional_package_content_migration':True,'runtime_performance_claim':False})

# The archive has no workspace ancestry and uses registry dependencies only.
stdout,_=execute('extracted-metadata',[cargo,'metadata','--locked','--offline','--no-deps','--format-version','1'],P)
metadata=json.loads(stdout)
assert Path(metadata['workspace_root'])==M/P.relative_to(V)
assert len(metadata['workspace_members'])==1 and len(metadata['packages'])==1
assert all(dep['source'] is not None and dep.get('path') is None for dep in metadata['packages'][0]['dependencies'])
execute('extracted-build',[cargo,'build','--locked'],P)
for feature in ['default','all']:
    flags=[] if feature=='default' else ['--all-features']
    execute('extracted-check-'+feature,[cargo,'check','--locked','--all-targets',*flags],P)
    execute('extracted-clippy-'+feature,[cargo,'clippy','--locked','--all-targets',*flags,'--','-D','warnings'],P)
    for location,cwd,selection in [('source',D,['-p','hyperreal']),('extracted',P,[])]:
        stdout,_=execute(location+'-readme-'+feature,[cargo,'test','--locked',*selection,*flags,
            '--test','readme','--test','readme_metadata','--','--test-threads=2'],cwd)
        rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout,re.M)
        assert rows==[('ok','2','0','0'),('ok','2','0','0')],rows
for location,cwd in [('source',D),('extracted',P)]:
    stdout,_=execute(location+'-quickstart',[cargo,'run','-p','hyperreal','--example','readme_quickstart'],cwd)
    assert stdout.strip()=='sqrt(2) ≈ 1.414213562373',stdout
    script='crates/hyperreal/verification/test_acceptance.py' if location=='source' else 'verification/test_acceptance.py'
    stdout,stderr=execute(location+'-acceptance-guards',['python3','-B',script],cwd)
    assert re.search(r'Ran \d+ tests? in ',stderr) and stderr.strip().endswith('OK'),stderr
stdout,_=execute('extracted-normal-tree',[cargo,'tree','--locked','--offline','--all-features','--edges','normal','--prefix','none','--format','{p}'],P)
for line in stdout.splitlines():assert line.split()[0] not in ['rug','gmp-mpfr-sys','toml'],line

# Independent invalid manifests must still trip each preserved assertion.
controls={}
text=(P/'Cargo.toml').read_text()
block=re.search(r'(?ms)^\[dev-dependencies\.rug\]\n.*?(?=^\[|\Z)',text)
assert block
for label,expectation in [('normal-rug','the GMP binding must not enter Hyperreal\'s release dependency graph'),
                           ('missing-dev-rug','competitive GMP benchmarks require rug as a development dependency')]:
    O=V/('hyperreal-package-negative-'+label+'-v1'); assert not O.exists()
    shutil.copytree(P,O)
    changed_text=text[:block.start()]+text[block.end():]
    if label=='normal-rug':changed_text+='\n'+block.group(0).replace('[dev-dependencies.rug]','[dependencies.rug]',1)
    (O/'Cargo.toml').write_text(changed_text)
    execute('negative-'+label,[cargo,'test','--offline','--test','readme_metadata',
        'gmp_binding_remains_a_development_only_dependency','--','--exact','--test-threads=2'],O,expected_failure=expectation)
    controls[label]={'directory':str(O),'manifest_sha256':sha(O/'Cargo.toml'),'lock_sha256':sha(O/'Cargo.lock'),
        'expected_assertion':expectation,'expected_test_failure_observed':True}
assert all(sha(D/p)==h for p,h in expected.items())
assert all(sha(P/p)==row['sha256'] for p,row in members.items())
assert all(sha(V/'hyperreal-package-baseline-v1'/p)==row['sha256'] for p,row in base.items())
assert sha(archive)==json.loads((V/'hyperreal-package-migration-members-v1.json').read_text())['candidate_archive_sha256']
dump(V/'hyperreal-package-validation-result-v1.json',{'complete_for_declared_scope':True,
    'commands':commands,'negative_controls':controls,'readme_tests_passed':16,'quickstarts_passed':2,
    'all_target_checks_and_clippy':['default','all'],'source_and_extracted_inputs_unchanged_after_tests':True,
    'all_63_replay_bundles_retained_in_repository':True,'only_declared_members_changed_or_removed':True,
    'features_and_normal_dependencies_unchanged':True,'full_scalar_suite_passed':False,
    'formal_proofs_rerun':False,'msrv_qualified':False,'candidate_admitted':False,
    'release_qualified':False,'full_plan_complete':False})
print(json.dumps({'complete_for_declared_scope':True,'command_count':len(commands),'readme_tests_passed':16,
    'quickstarts_passed':2,'negative_controls_rejected':2,'candidate_admitted':False,'release_qualified':False}),flush=True)
