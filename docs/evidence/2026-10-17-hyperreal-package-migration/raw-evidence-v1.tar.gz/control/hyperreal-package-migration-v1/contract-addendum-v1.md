# Reproduced normalized-manifest guard failure

Before source edits, the actual E58 package was extracted and its two README
test binaries executed. Three tests passed and the GMP dependency guard failed:
`manifest has a normal dependency table`. Raw stdout/stderr and command result
are in logs/hyperreal-package-baseline-readme-v1; exit 101, no resource stop.
Cargo writes [dependencies.name] tables, while the test requires the literal
[dependencies] header. This is a package-boundary test defect on the target
revision, not a newly introduced failure.

Extend the migration with the smallest semantic correction: parse Cargo.toml
with the already locked toml 0.8.23 parser (used by Hypermesh), declared only as
a Hyperreal dev dependency. Assert the same dependency-table facts: rug absent
from normal dependencies and present in development dependencies. Retain both
README tests and the unchanged quickstart Rust program. Root lock changes may
only add that existing parser to Hyperreal's dev dependency edges; no package
version, checksum, production dependency or optional feature may change.

Validate both source and extracted-package forms. In fresh disposable package
copies, move rug to normal dependencies and remove it from dev dependencies;
the unchanged guard assertions must reject both invalid manifests. Keep those
negative controls separate from accepted source and retain their raw failures.
No hand-written TOML parser, skipped assertion or source-only fallback.
