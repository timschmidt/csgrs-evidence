# Hyperreal package boundary migration

Owning layer: Hyperreal distribution metadata and its documentation. Relevant
requirements: P37, T12, admission sections 1, 6 and 7. Domain: the actual
hyperreal 0.13.1 Cargo source archive, its default and all-feature Rust targets,
README example and metadata tests. This is an intentional package-content
migration, not a runtime optimization or a claim of release completion.

Fresh reproduced findings: E58 actual staged archive is 108,043,832 bytes;
its exact members and source bytes are retained. The successful official
registry response in registry-hyperreal-observation-v1.json contains no 0.13.1
entry, contradicting the README release statement. Missing acceptance:
building and exercising the archive outside the monorepo and verifying that
packaging retains every required source, test, fixture and evidence summary.

Proposed source edit: exclude only /benchmarks/checkpoints/*.tar.gz, retaining
all those replay archives in Git. Keep every non-archive checkpoint summary,
fixture, Rust source, example and test. Explain this package boundary and the
unreleased source example in the README. Preserve the Rust quickstart block.
Any additional failure is reproduced and recorded before an added correction;
no policy, mathematical output, validation assertion or fixture is weakened.

First materialize noncomparison source into the existing isolated paper
worktree, checking every materialized source against the retained baseline
inventory. Preserve the separate cache candidate checkout. Independently
extract the original actual package, validating paths, byte hashes and modes,
and run its README tests to reproduce package-specific behavior before edits.
After changes, assemble a fresh package, compare all actual memberships and
unaffected byte hashes with the baseline, and build the extracted package with
no workspace, path dependencies or patches. Run applicable default/all-feature
all-target checks and Clippy, README tests, the documented example, and fmt.
Record failures as failures; archive assembly is not a package build.

Reuse validation_runner_v2.py unchanged: 8 GiB child address-space limit,
2 GiB host-memory reserve, 512 MiB volume reserve, 64 GiB cumulative volume
consumption, 64 MiB aggregate command logs, 1800 seconds per command, two Cargo
jobs and incremental off. These are external containment, not scalar bounds.
Use the verified private spaceless mount for GMP. Fresh targets/extractions
remain on Disk B. Keep raw output and all prior failed attempts immutable.
No original-volume writes, publishing, pushing, cache admission, complete
scalar-suite, formal-proof, MSRV, whole-stack release or full-plan claim.
