"""Include direct crates/ files omitted by the preserved v1 preflight."""
import gzip, hashlib, json, os, re, subprocess, sys, tarfile
from pathlib import Path, PurePosixPath
sys.dont_write_bytecode=True
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(V/'control'))
from validation_runner_v2 import GIT,dump,reasons,resources,run,sha
W=Path(__file__).resolve().parent
D=V/'paper-worktree-v1'; B=V/'checkout-baseline-v1'; C=V/'checkout-candidate-v1'
M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
O=V/'hyperreal-package-baseline-v1'; TARGET=V/'target-hyperreal-package-checks-v1'
assert not O.exists() and not TARGET.exists()
assert not reasons(resources())
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_LFS_SKIP_SMUDGE='1')
def git(args,stdin=None):
    return subprocess.run(GIT+args,cwd=D,env=env,input=stdin,capture_output=True,check=True).stdout
head=git(['rev-parse','HEAD']).decode().strip()
assert head=='a78335a44dc2b286682571d871dc00046162940c'
assert not git(['status','--porcelain=v1'])
assert sha(D/'docs/properties-status.json')=='a04721cb186dd8f3345d9ed6e18181dae8fcb054e5a645eeb947ea3277d27de7'
base=json.loads(gzip.decompress((V/'baseline-source-inventory-v1.json.gz').read_bytes()))
patterns=set()
for p in base:
    parts=PurePosixPath(p).parts
    if parts[0] in ['docs','crates']:continue
    patterns.add('/'+parts[0]+('/' if len(parts)>1 else ''))
for p in base:
    parts=PurePosixPath(p).parts
    if parts[0]=='crates' and len(parts)==2:
        patterns.add('/'+p)
    elif len(parts)>2 and parts[0]=='crates' and parts[1]!='comparisons':
        patterns.add('/crates/'+parts[1]+'/')
stdin=('\n'.join(sorted(patterns))+'\n').encode()
(W/'sparse-add-v2.txt').write_bytes(stdin)
git(['sparse-checkout','add','--stdin'],stdin)
assert not git(['status','--porcelain=v1'])
pins={}
for p,row in base.items():
    if p.startswith('docs/') or p.startswith('crates/comparisons/'):continue
    assert row['storage']=='git-blob',p
    path=D/p
    assert path.is_file() and not path.is_symlink(),p
    assert sha(path)==row['sha256'],p
    assert sha(B/p)==row['sha256'],p
    pins[p]=row['sha256']
assert all(sha(D/p)==sha(C/p) for p in pins if p.startswith('crates/hyperreal/'))
(V/'hyperreal-package-source-pins-v1.json.gz').write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
staged=json.loads(gzip.decompress((V/'workspace-package-staged-members-v1.json.gz').read_bytes()))['completed_staging_archives']['hyperreal']
archive=Path(staged['physical_archive']); assert sha(archive)==staged['sha256']
O.mkdir(); members={}
with tarfile.open(archive,'r:gz') as source:
    for member in source:
        path=PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert path.parts[0]=='hyperreal-0.13.1' and len(path.parts)>1
        rel=str(PurePosixPath(*path.parts[1:])); assert rel not in members
        data=source.extractfile(member).read(); digest=hashlib.sha256(data).hexdigest()
        assert staged['members'][rel]['sha256']==digest,(rel,staged['members'][rel])
        dest=O/rel; dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data); dest.chmod(member.mode & 0o777)
        assert sha(dest)==digest
        members[rel]={'sha256':digest,'bytes':len(data),'mode':member.mode & 0o777}
assert set(members)==set(staged['members'])
(V/'hyperreal-package-baseline-members-v1.json.gz').write_bytes(gzip.compress((json.dumps(members,sort_keys=True)+'\n').encode(),mtime=0))
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']); os.environ['CARGO_NET_OFFLINE']='true'
assert M.is_dir() and not list(M.iterdir())
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
name='hyperreal-package-baseline-readme-v1'
command=[cargo,'test','--locked','--test','readme','--test','readme_metadata','--','--test-threads=2']
mapped={'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(M/TARGET.relative_to(V)),
 'TMPDIR':str(M/'scratch'/name),'XDG_CACHE_HOME':str(M/'xdg-cache-v1'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc',
 '--bind',str(V),str(M),'--chdir',str(M/O.relative_to(V))]
for key,value in mapped.items():argv.extend(['--setenv',key,value])
argv+=command
dump(V/'hyperreal-package-preparation-protocol-v2.json',{'helper_sha256':sha(Path(__file__)),
 'contract_sha256':sha(W/'contract-v1.md'),'worktree_head':head,'materialized_source_count':len(pins),
 'source_inventory_sha256':sha(V/'hyperreal-package-source-pins-v1.json.gz'),
 'baseline_archive_sha256':sha(archive),'baseline_archive_path':str(archive),
 'baseline_members':len(members),'baseline_extraction':str(O),'command':command,
 'tool_sha256':compiler['tool_sha256'],'runner_sha256':sha(V/'control/validation_runner_v2.py'),
 'source_edits':False,'candidate_admitted':False,'release_qualified':False})
try:
    result=run(name,argv,O,target=TARGET)
except RuntimeError:
    result=json.loads((V/'logs'/name/'result.json').read_text())
assert all(sha(O/p)==row['sha256'] for p,row in members.items())
assert all(sha(D/p)==h for p,h in pins.items())
stdout=(V/'logs'/name/'stdout').read_text()
rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout,re.M)
dump(V/'hyperreal-package-baseline-result-v1.json',{'diagnostic_complete':True,'command':result,
 'test_terminal_rows':rows,'baseline_source_unchanged':True,'worktree_source_unchanged':True,
 'package_tests_passed':result['exit_code']==0 and not result['stops'],
 'candidate_admitted':False,'release_qualified':False,'full_plan_complete':False})
print(json.dumps({'materialized_source_count':len(pins),'baseline_members':len(members),
 'test_exit':result['exit_code'],'terminal_rows':rows}),flush=True)
