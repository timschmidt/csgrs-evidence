from pathlib import Path
import os,io,lzma,tarfile,hashlib,json
s=Path(os.environ['s']); out=Path('/mnt/development/csgrs-evidence/docs/evidence/2026-11-19-interval-rational-ieee-projection')
out.mkdir()
files={}
def add(p):
 assert p.is_file() and not p.is_symlink()
 files[p.relative_to(s).as_posix()]=p
for pattern in ('*.py','*.sh','*.mjs','*.md','*.json','env','wasi-env','logs/*','trials/*.patch','scalar-complete/*.log','scalar-complete/*.children','scalar-complete/*.json','scalar-complete/rustc.txt','consumer-direct/*.rs'):
 for p in s.glob(pattern):
  if p.name!='corpus.json':add(p)
for base in ('client','client-audit','consumer'):
 for p in (s/base).rglob('*'):
  if p.is_file():add(p)
assert max(p.stat().st_size for p in files.values())<2_000_000
digests={}
with tarfile.open(out/'observations.tar.xz','w:xz',preset=6) as ar:
 for k,p in sorted(files.items()):
  v=p.read_bytes(); digests[k]=hashlib.sha256(v).hexdigest()
  info=tarfile.TarInfo(k); info.size=len(v); info.mode=0o644
  ar.addfile(info,io.BytesIO(v))
(out/'members.sha256.json.xz').write_bytes(lzma.compress(json.dumps(digests,sort_keys=True,indent=1).encode()+b'\n'))
print('Archived',len(digests),'files',sum(p.stat().st_size for p in out.iterdir()),'compressed bytes')
