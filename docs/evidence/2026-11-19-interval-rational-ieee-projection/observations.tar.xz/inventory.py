from pathlib import Path
import csv,hashlib
p=Path('interval-inventory.tsv')
with p.open() as f: header=next(csv.reader(f,delimiter='\t'))
with p.open('a',newline='') as f:
 w=csv.DictWriter(f,header,delimiter='\t',lineterminator='\n')
 for file,fn,visibility,semantics in [
  ('float/rational.rs','from_rational','pub','Canonical empty succeeds before qualification. Nonempty rational endpoints share the caller budget and project outward independently.'),
  ('ieee/rational.rs','rational_bound','pub(crate)','The stored bit lengths bound the leading exponent. Between the extreme cases, directed unsigned division on a grid dividing the local IEEE spacing preserves the nearest outward endpoint.')
 ]:
  path=Path('crates/hyperinterval/src')/file
  line=next(i for i,l in enumerate(path.read_text().splitlines(),1) if 'fn '+fn+'(' in l)
  row=['csgrs',str(path),line,fn,'fn','Exact rational to finite binary32 or binary64',semantics,'Budgeted BigUint division. Zero and extreme exponent shortcuts use stored lengths.','rational,dyadic,float-enclosure on qualified x86_64, bare wasm32 and opt-in WASI Preview 1.',visibility,'Existing IEEE endpoint bits and exact rational export.','Strict float construction and exact interval round trips.','hyperinterval','Retain the scalar representation conversion.','rational_float_projection includes both directed MPFR endpoints, limits and retry.','Paired complete projections and guarded native lifetime measurements in the rational IEEE evidence record.','Body reviewed at 97c59c69f, file SHA-256 '+hashlib.sha256(path.read_bytes()).hexdigest()+'.']
  w.writerow(dict(zip(header,row,strict=True)))
