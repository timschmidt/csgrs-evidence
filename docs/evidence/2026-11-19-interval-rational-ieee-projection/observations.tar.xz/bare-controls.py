from pathlib import Path
from metrics import metrics
import os, subprocess, json
s=Path(os.environ['s']); root=s/'tree'
for phase,rev in [('base','6cd10d93e'),('inline','interval-rational-ieee-inline')]:
 subprocess.run(['git','switch','-q','--detach',rev],cwd=root,check=True)
 out={}
 for n in ('wasm-float','wasm-dyadic','wasm-real-bridge'):
  path=root/'crates/hyperinterval/conformance'/n
  env=os.environ|{'CARGO_TARGET_DIR':str(s/'bare-controls')}
  p=subprocess.check_output(['cargo','+1.95.0','build','--locked','--release','--target','wasm32-unknown-unknown','--message-format=json-render-diagnostics'],env=env,cwd=path,text=True)
  images=[Path(f) for l in p.splitlines() for f in json.loads(l).get('filenames',[]) if f.endswith('.wasm')]
  assert len(images)==1
  out[n]=metrics(images[0])
  driver=path/'check.mjs' if n=='wasm-real-bridge' else path.parent/'wasm-float/check.mjs'
  args=[] if n=='wasm-real-bridge' else [s/'corpus.json']+(['--egress'] if n=='wasm-dyadic' else [])
  subprocess.run([s/'bin/node',driver,images[0],*args],cwd=path,check=True)
 (s/f'bare-controls-{phase}.json').write_text(json.dumps(out,indent=2)+'\n')
