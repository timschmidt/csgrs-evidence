use hyperinterval::{DyadicBudget, F32Enclosure, F64Enclosure, RationalInterval};
use hyperreal::Rational;
#[unsafe(no_mangle)]
pub extern "C" fn verify() {
    let (a,b) = std::hint::black_box((1,10));
    let source = RationalInterval::point(Rational::fraction(a,b).unwrap());
    let mut budget = DyadicBudget::new(80,1_000_000);
    let lo_hi = F32Enclosure::from_rational(&source,&mut budget).unwrap().bounds().unwrap();
    assert_eq!((lo_hi.0.to_bits(),lo_hi.1.to_bits()), (0x3dcccccc,0x3dcccccd));
    let lo_hi = F64Enclosure::from_rational(&source,&mut budget).unwrap().bounds().unwrap();
    assert_eq!((lo_hi.0.to_bits(),lo_hi.1.to_bits()),(0x3fb9999999999999,0x3fb999999999999a));
}
