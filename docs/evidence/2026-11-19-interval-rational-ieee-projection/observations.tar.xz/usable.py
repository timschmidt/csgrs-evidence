from pathlib import Path
import os
s=Path(os.environ['s'])
p=s/'client-audit/src/allocations.rs';txt=(s/'client/src/allocations.rs').read_text()
def change(old,new):
 global txt
 assert txt.count(old)==1,old
 txt=txt.replace(old,new)
change('struct CountingAllocator;','''unsafe extern "C" { fn malloc_usable_size(p: *const std::ffi::c_void) -> usize; }
static USABLE: AtomicIsize = AtomicIsize::new(0);
static PEAK_USABLE: AtomicIsize = AtomicIsize::new(0);
fn change_usable(delta:isize) { let n=USABLE.fetch_add(delta,Ordering::Relaxed)+delta; PEAK_USABLE.fetch_max(n,Ordering::Relaxed); }
struct CountingAllocator;''')
change('            add_live_bytes(layout.size());','            change_usable(unsafe { malloc_usable_size(pointer.cast()) } as isize);\n            add_live_bytes(layout.size());')
change('            subtract_live_bytes(layout.size());','            change_usable(-(unsafe { malloc_usable_size(pointer.cast()) } as isize));\n            subtract_live_bytes(layout.size());')
change('let replacement = unsafe','let old = if ENABLED.load(Ordering::Relaxed) { unsafe { malloc_usable_size(pointer.cast()) } } else { 0 };\n        let replacement = unsafe')
change('REALLOCATIONS.fetch_add','change_usable(unsafe { malloc_usable_size(replacement.cast()) } as isize - old as isize);\n            REALLOCATIONS.fetch_add')
change('pub allocations: usize,','pub peak_usable: isize,\n    pub final_usable: isize,\n    pub allocations: usize,')
change('            allocations: ALLOCATIONS.load','            peak_usable: PEAK_USABLE.load(Ordering::Relaxed),\n            final_usable: USABLE.load(Ordering::Relaxed),\n            allocations: ALLOCATIONS.load')
change('        LIVE_BYTES.store(0','        USABLE.store(0, Ordering::Relaxed); PEAK_USABLE.store(0, Ordering::Relaxed);\n        LIVE_BYTES.store(0')
p.write_text(txt)
