from pathlib import Path
import os,json,statistics,collections
s=Path(os.environ['s']); result={}
for tc in ('1.95.0','stable'):
 d=collections.defaultdict(list)
 for p in sorted(s.glob('logs/audit-'+tc+'-[123]')):
  for line in p.read_text().splitlines():
   kind,i,*rest=line.split(); i=int(i)
   if kind=='STACK': d[i,'stack_'+rest[0]].append(int(rest[-1]))
   else:
    for k,v in zip(['allocations','reallocations','peak_requested','final_requested','deallocations','total_allocated','peak_usable','final_usable'],rest,strict=True):d[i,k].append(int(v))
 rows=[]
 for i in range(12):
  for (j,k),a in d.items():
   if j!=i:continue
   b=d[i+12,k]
   if k in ('stack_0','stack_1','peak_requested','peak_usable','final_requested','final_usable'):assert max(b)<=max(a)
   rows.append([i,k,max(a),max(b),max(b)-max(a)])
 result[tc]=rows
(s/'audited-lifetimes.json').write_text(json.dumps(result,indent=1)+'\n')
