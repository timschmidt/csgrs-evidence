mod allocations;
use hyperinterval::{DyadicBudget, F32Enclosure, F64Enclosure, RationalInterval};
use hyperreal::Rational;
use num_bigint::{BigInt,BigUint};
use std::{ffi::c_void,hint::black_box,time::Instant};

unsafe extern "C" { fn measure_stack(callback:extern "C" fn(*mut c_void),context:*mut c_void,warm:i32,pattern:u8)->usize; }
fn source(case:usize)->RationalInterval {
    let frac=|n,d| Rational::fraction(n,d).unwrap();
    let (lo,hi) = match case {
        0 => (frac(1,10),frac(2,3)),
        1 => (frac(-17,23),frac(37,61)),
        2 => {
            let p=BigUint::from(1u8)<<70usize;
            (Rational::from_bigint_fraction(1.into(),&p+1u8).unwrap(),Rational::from_bigint_fraction(BigInt::from(p),3u8.into()).unwrap())
        }
        3 => {
            let p=BigUint::from(1u8)<<2200usize;
            let r=Rational::from_bigint_fraction(1.into(),p+1u8).unwrap();
            (-r.clone(),r)
        }
        4 => {
            let p=BigUint::from(1u8)<<1024usize;
            (Rational::from_bigint_fraction(BigInt::from(&p-1u8),&p+3u8).unwrap(),Rational::from_bigint_fraction(BigInt::from(&p+1u8),&p-3u8).unwrap())
        }
        5 => (Rational::zero(),Rational::zero()),
        _=> unreachable!(),
    };
    RationalInterval::new(lo,hi).unwrap()
}
#[inline(never)]
fn project(i:usize,r:&RationalInterval)->(u64,u64,u64) {
    let mut b=DyadicBudget::new(8192,1_000_000_000);
    macro_rules! get { ($ty:ty,$grid:expr)=>{{
        let value=if i/12==1 {<$ty>::from_rational(r,&mut b).unwrap()}else {
            <$ty>::from_dyadic(&r.to_dyadic($grid,&mut b).unwrap(),&mut b).unwrap()
        };
        let (lo,hi)=value.bounds().unwrap();(lo.to_bits() as u64,hi.to_bits() as u64,1_000_000_000-b.remaining_work())
    }};}
    if i/6%2==0 {get!(F32Enclosure,-149)} else {get!(F64Enclosure,-1074)}
}
extern "C" fn full(ptr:*mut c_void) {let i=ptr.addr();black_box(project(i,&source(i%6)));}
fn main(){
    if std::env::args().any(|a|a=="time") {
        for c in 0..12 {
            let r=source(c%6);let base=project(c,&r);let direct=project(c+12,&r);
            assert_eq!((base.0,base.1),(direct.0,direct.1));println!("BITS {c} {} {} {} {}",base.0,base.1,base.2,direct.2);
            for j in 0..33 {
                for k in 0..2 {
                    let i=c+12*((k+j)%2);let t=Instant::now();
                    for _ in 0..400 {black_box(project(black_box(i),black_box(&r)));}
                    println!("TIME {c} {j} {} {}",i/12,t.elapsed().as_nanos());
                }
            }
        }
    }else{
        for i in 0..24 {
            let ptr=std::ptr::without_provenance_mut(i);
            for warm in [0,1] {for p in [85,170] {println!("STACK {i} {warm} {p} {}",unsafe{measure_stack(full,ptr,warm,p)});}}
            let v=allocations::measure(2,||full(ptr));
            assert_eq!(v.live_bytes,0);
            println!("HEAP {i} {} {} {} {} {} {} {} {}",v.allocations,v.reallocations,v.peak_live_bytes,v.live_bytes,v.deallocations,v.allocated_bytes,v.peak_usable,v.final_usable);
        }
    }
}
