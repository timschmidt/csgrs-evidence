import os,re,hashlib,subprocess,json
from pathlib import Path
s=Path(os.environ['s']); all_rows={}
for name in ('float_cost','host_cost','order_cost'):
 data={}
 for ph,p in [('previous',s/'base'/name),('final',s/'target/release/examples'/name)]:
  raw=p.read_bytes(); rows={}
  for line in subprocess.check_output(['readelf','-WS',p],text=True).splitlines():
   m=re.match(r'^\s*\[\s*\d+\]\s+(\S+)\s+(\S+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([0-9a-f]+)\s+\S+\s+(\w+)',line)
   if m and 'A' in m[6]:
    addr,off,size=[int(m[i],16) for i in (3,4,5)]
    rows[m[1]]=[addr,size,'NOBITS' if m[2]=='NOBITS' else hashlib.sha256(raw[off:off+size]).hexdigest()]
  data[ph]=rows
 all_rows[name]=data
 print(name,[k for k in data['previous'] if data['previous'][k]!=data['final'][k]])
(s/'loadable-rows.json').write_text(json.dumps(all_rows,indent=1)+'\n')
