set -eu
for phase in base initial; do
 if test "$phase" = initial; then git -C "$s/tree" switch -q --detach 17608b88f; fi
 for tc in 1.95.0 stable; do (
   python3 "$s/size-build.py" "$tc" native "$phase"
   source "$s/wasi-env"
   python3 "$s/size-build.py" "$tc" wasi "$phase"
 ) >"$s/logs/compare-$tc-$phase" 2>&1 & done
 wait
 for tc in 1.95.0 stable; do test -s "$s/$phase-$tc-wasi.json"; done
done
