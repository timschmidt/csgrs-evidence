from pathlib import Path
from metrics import metrics
import os,subprocess,json
s=Path(os.environ['s']); wd=s/'consumer'
for mode in ['composed','direct']:
 for name in ('main.rs','lib.rs'):
  text=(s/'consumer-direct'/name).read_text()
  if mode=='composed':
   text=text.replace('new(80,1_000_000)','new(4096,100_000_000)')
   for ty,grid in [('F32Enclosure',-149),('F64Enclosure',-1074)]:
    text=text.replace(ty+'::from_rational(&source,&mut budget)',f'{ty}::from_dyadic(&source.to_dyadic({grid}, &mut budget).unwrap(),&mut budget)')
  (wd/'src'/name).write_text(text)
 out={}
 for tc in ('1.95.0','stable'):
  target=s/('pkg-'+tc)
  for arch,trip in [('native',None),('wasi','wasm32-wasip1'),('bare','wasm32-unknown-unknown')]:
   env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS':'--sysroot '+str(s/('sysroot-'+tc))}
   cmd=['cargo','+'+tc,'build','--release','--locked',*(['--target',trip] if trip else []),*(['--lib'] if arch=='bare' else ['--bin','projection-consumer'])]
   subprocess.run(cmd,env=env,cwd=wd,check=True)
   exe=target/(trip or '')/'release'/('projection_consumer.wasm' if arch=='bare' else ('projection-consumer.wasm' if trip else 'projection-consumer'))
   run=[exe] if arch=='native' else [s/'bin/node','--no-warnings',s/('check-module.mjs' if arch=='bare' else 'qualified/crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe]
   subprocess.run(run,cwd=wd,env=env,check=True)
   out[tc+'-'+arch]=metrics(exe)
 (s/('paired-package-'+mode+'.json')).write_text(json.dumps(out,indent=2)+'\n')
