from pathlib import Path
import os
p=Path(os.environ['s'])/'tree/crates/hyperinterval/src'
q=p/'ieee/dyadic.rs'
q.write_text(q.read_text()+'''
#[cfg(feature = "rational")]
impl Format {
    pub(crate) fn rational_bound(
        self,
        value: &hyperreal::Rational,
        upper: bool,
        budget: &mut DyadicBudget,
    ) -> Result<u64, IntervalError> {
        budget.reserve(1, 1, false)?;
        let (sign, numerator, denominator) = value.ratio_parts();
        if numerator.bits() == 0 {
            return Ok(0);
        }
        // The leading exponent is either order - 1 or order. Inspecting stored
        // lengths needs no reduction, allocation or exponent-sized shift.
        let order = i128::from(numerator.bits()) - i128::from(denominator.bits());
        if order > i128::from(self.bias()) + 1 {
            return Err(IntervalError::Overflow);
        }
        if order < i128::from(self.minimum()) {
            let (lo, hi) = self.signed(0, 1, sign == Sign::Minus);
            return Ok(if upper { hi } else { lo });
        }
        // This grid divides the IEEE spacing on either possible binade. An
        // outward projection onto it cannot skip a representable endpoint.
        let grid = self.minimum().max(order as i32 - 1 - self.fraction() as i32);
        let rounded = crate::DyadicInterval::from_rational(value, grid, budget)?;
        let (lo, hi, exponent) = rounded.bounds().expect("finite rational point has bounds");
        if upper {
            Ok(self.enclose_dyadic(hi, exponent, budget)?.1)
        } else {
            Ok(self.enclose_dyadic(lo, exponent, budget)?.0)
        }
    }
}
''')
q=p/'float.rs';t=q.read_text();i=t.index('            /// Exact common-scale dyadic conversion.')
q.write_text(t[:i]+'''            /// Tightest finite IEEE enclosure of a closed exact rational interval.
            ///
            /// Each endpoint rounds outward on its own binary grid. A fraction
            /// such as 1/10 lies between adjacent IEEE values. Underflow encloses
            /// the source between zero and the least subnormal of the same sign.
            /// Returns [`IntervalError::Overflow`] if a finite endpoint cannot
            /// enclose the source. Empty succeeds without work on every target.
            ///
            /// Requires the `rational` and `dyadic` features. Nonempty inputs
            /// first require a qualified environment. Both endpoints share the
            /// caller's budget. Each spends one unit on magnitude inspection.
            /// Directed division and IEEE projection charge their normal stages
            /// when the stored bit lengths alone do not settle the bound.
            #[cfg(all(feature = "rational", feature = "dyadic"))]
            pub fn from_rational(
                source: &crate::RationalInterval,
                budget: &mut crate::DyadicBudget,
            ) -> Result<Self, IntervalError> {
                let Some((lo, hi)) = source.bounds() else {
                    return Ok(Self::empty());
                };
                qualify()?;
                Self::from_bits(
                    $format.rational_bound(lo, false, budget)?,
                    $format.rational_bound(hi, true, budget)?,
                )
            }

'''+t[i:])
