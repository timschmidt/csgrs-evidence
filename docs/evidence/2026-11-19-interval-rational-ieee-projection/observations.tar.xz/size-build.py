from pathlib import Path
import os,sys,subprocess,json,re
from metrics import metrics
s=Path(os.environ['s']);tc,arch,phase=sys.argv[1:]
cmd=['cargo','+'+tc,'build','--locked','--release','-p','hyperinterval','--all-features','--message-format=json-render-diagnostics']
for n in ['float_cost','order_cost','host_cost']:cmd+=['--example',n]
for n in ['dyadic_float_egress','real_bridge']+(['rational_float_projection'] if phase not in ('base','fixed','firstwasi') else []):cmd+=['--test',n]
env=os.environ|{'CARGO_TARGET_DIR':str(s/('target' if tc=='1.95.0' else 'target-stable'))}
if arch=='wasi':
 cmd+=['--target','wasm32-wasip1']
 env['CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS']=f'--sysroot {s}/sysroot-{tc} -C link-arg={s}/wasi-tools/usr/lib/wasm32-wasi/libwasi-emulated-signal.a'
name=f'{phase}-{tc}-{arch}'
with (s/'logs'/(name+'.build')).open('w') as log:p=subprocess.run(cmd,cwd=s/'tree',env=env,stdout=subprocess.PIPE,stderr=log,text=True,check=True)
bins={r['target']['name']:Path(r['executable']) for l in p.stdout.splitlines() if (r:=json.loads(l)).get('executable')}
assert len(bins)==(5 if phase in ('base','fixed','firstwasi') else 6)
out={}
for n,exe in bins.items():
 v=out[n]=metrics(exe)
 if arch=='native':
  sections=subprocess.check_output(['readelf','-WS',exe],text=True)
  v['sections']={m[1]:int(m[2],16) for l in sections.splitlines() if (m:=re.match(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\w+)',l)) and 'A' in m[3]}
(s/(name+'.json')).write_text(json.dumps(out,indent=2)+'\n')
