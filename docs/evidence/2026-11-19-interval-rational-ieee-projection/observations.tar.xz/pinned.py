import os,time,csv,subprocess,statistics,json
from pathlib import Path
s=Path(os.environ['s'])
def load():
 return {int(f[0][3:]):sum(map(int,f[1:4]+f[6:9])) for l in Path('/proc/stat').read_text().splitlines() if (f:=l.split())[0][3:].isdigit() and f[0].startswith('cpu')}
a=load(); time.sleep(1); b=load(); allowed=os.sched_getaffinity(0)
def score(cpu):
 siblings=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list').read_text().strip()
 ids=[int(v) for v in siblings.split(',') if v.isdigit()]
 return sum(b[k]-a[k] for k in ids),b[cpu]-a[cpu],cpu
cpu=min(allowed,key=score);os.sched_setaffinity(0,{cpu});print('pinned CPU',cpu,score(cpu),flush=True)
result={}
for n in ('float_cost','host_cost','order_cost'):
 rows={}
 for j in range(6):
  for ph in (('base','candidate') if j%2==0 else ('candidate','base')):
   binary=(s/'base'/n if ph=='base' else s/'target/release/examples'/n)
   out=s/'logs'/f'pinned-{n}-{j}-{ph}'
   with out.open('w') as f: subprocess.run([binary],stdout=f,stderr=subprocess.DEVNULL,check=True)
   data={}
   for row in csv.DictReader(out.open()):
    k=tuple(v for k,v in row.items() if k not in ('elapsed_ns','sample','checksum'))
    data.setdefault(k,[]).append((int(row['elapsed_ns']),row.get('checksum')))
   rows[j,ph]=data
 r={}
 for k in rows[0,'base']:
  ratios=[]
  for j in range(6):
   aa,bb=(rows[j,p][k] for p in ('base','candidate'))
   assert [v[1] for v in aa]==[v[1] for v in bb]
   ratios.append(statistics.median(v[0] for v in bb)/statistics.median(v[0] for v in aa))
  r['/'.join(k)]=ratios
 result[n]=r
 print(n,{k:round(statistics.median(v),4) for k,v in r.items()},flush=True)
(s/'pinned-timings.json').write_text(json.dumps(result,indent=2)+'\n')
