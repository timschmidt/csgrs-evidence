from pathlib import Path
import json,os,subprocess,sys
from metrics import metrics
s=Path(os.environ['s']); tc,phase=sys.argv[1:]
out=s/'logs'/f'{tc}-{phase}-clients'
if tc=='1.95.0' and phase=='base':
    bins={p.name:p for p in (s/'base').iterdir()}
else:
    names=['float_cost','order_cost','host_cost','dyadic_float_egress','real_bridge']
    opts=['--example',names[0],'--example',names[1],'--example',names[2],'--test',names[3],'--test',names[4]]
    cmd=['cargo','+'+tc,'build','--locked','--release','-p','hyperinterval','--all-features','--message-format=json-render-diagnostics',*opts]
    env=os.environ|{'CARGO_TARGET_DIR':str(s/('target' if tc=='1.95.0' else 'target-stable'))}
    with Path(str(out)+'.build').open('w') as log:
        build=subprocess.run(cmd,env=env,cwd=s/'tree',stdout=subprocess.PIPE,stderr=log,check=True,text=True)
    bins={r['target']['name']:Path(r['executable']) for line in build.stdout.splitlines() if (r:=json.loads(line)).get('executable')}
assert len(bins)==5
Path(str(out)+'.json').write_text(json.dumps({n:metrics(p) for n,p in bins.items()},indent=2)+'\n')
