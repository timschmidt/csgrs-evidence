import os,json,sys
from pathlib import Path
s=Path(os.environ['s']);v=sys.argv[1];all_={}
for tc in ('1.95.0','stable'):
 for arch in ('native','wasi'):
  name=tc+'-'+arch
  b=json.loads((s/f'base-{name}.json').read_text());a=json.loads((s/f'{v}-{name}.json').read_text());out=all_[name]={}
  for client,old in b.items():
   new=a[client];d=out[client]={k:new[k]-old[k] for k in ('file','code','functions')};d['equal']=new['sha256']==old['sha256']
   d['bad_sections']={k:n-old['sections'].get(k,0) for k,n in new.get('sections',{}).items() if n-old['sections'].get(k,0)>min(4096,old['sections'].get(k,0)*.01)}
   print(name,client,d)
(s/(v+'-deltas.json')).write_text(json.dumps(all_,indent=2)+'\n')
