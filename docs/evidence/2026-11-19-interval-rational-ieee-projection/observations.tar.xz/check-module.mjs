import fs from 'node:fs';
const { instance } = await WebAssembly.instantiate(fs.readFileSync(process.argv[2]), {});
instance.exports.verify();
console.log("Packaged binary32 and binary64 directed endpoints passed");
