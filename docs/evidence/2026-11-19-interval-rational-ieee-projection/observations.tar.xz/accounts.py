from pathlib import Path
import os,json,math
from metrics import metrics
s=Path(os.environ['s'])
rows=[];new=[];frozen=[];increased=[]
for tc in ('1.95.0','stable'):
 for arch in ('native','wasi'):
  name=tc+'-'+arch
  get=lambda phase:json.loads((s/f'{phase}-{name}.json').read_text())
  fixed,previous,final=get('fixed' if arch=='native' else 'firstwasi'),get('base'),get('inline')
  for n in previous:
   a,b,c=fixed[n],previous[n],final[n]
   for k in ('file','code','functions',*sorted(c.get('sections',{}))):
    def read(row):
     return row.get('sections',{}).get(k,0) if k.startswith('.') else row[k]
    start,prior,now=map(read,(a,b,c));hist=max(0,prior-start);inc=max(0,now-prior)
    if arch=='native':
     caps=(1024,.005,4096,.01) if k=='functions' else (4096,.01,16384,.02)
    else:caps=(1024,.05,4096,.1)
    inc_cap=min(caps[0],math.floor(caps[1]*prior))
    cum_cap=min(caps[2],math.floor(caps[3]*start))
    assert inc<=inc_cap
    remaining=cum_cap-inc-hist
    if remaining<0:
      assert inc==0 and k=='.relro_padding'
      frozen.append([tc,n,k,start,prior,now,hist,remaining])
    row=[tc,arch,n,k,start,prior,now,hist,inc,inc+hist,inc_cap-inc,max(0,remaining)]
    rows.append(row)
    if inc: increased.append(row)
   assert c['file']<=48*1024**2
  r=final['rational_float_projection']; new.append([tc,arch,'oracle',r['file'],r['code'],r['functions'],64*1024**2-r['file']]); assert new[-1][-1]>=16*1024**2
 for arch,rel in [('native','release/projection-consumer'),('wasi','wasm32-wasip1/release/projection-consumer.wasm'),('bare','wasm32-unknown-unknown/release/projection_consumer.wasm')]:
  r=metrics(s/('pkg-'+tc)/rel)
  new.append([tc,arch,'package_consumer',r['file'],r['code'],r['functions'],4194304-r['file']])
  assert new[-1][-1]>=1048576
(s/'account-rows.json').write_text(json.dumps({'columns':['toolchain','target','client','metric','fixed','previous','candidate','earlier_positive','incremental_charge','cumulative_charge','incremental_remaining','cumulative_remaining'],'rows':rows,'previously_over_full_rows_without_new_charge':frozen,'new_artifacts_columns':['toolchain','target','role','file','code','functions','remaining_slot'],'new_artifacts':new},indent=1)+'\n')
print('Existing metrics',len(rows),'positive charges',len(increased),'largest new charge',max(r[8] for r in rows))
print('Frozen',frozen)
print('New artifacts',new)
