set -eu
s=/dev/shm/interval-translation-signal
. /dev/shm/interval-bisection/env
v=$1;expected=$2
cd "$s/validation"
export CARGO_TARGET_DIR=/dev/shm/interval-real-ball-boundary/target-native
cargo +1.95.0 build --offline --release
cp "$CARGO_TARGET_DIR/release/translation-retry" "$s/images/$v-validated"
"$s/images/$v-validated" "$expected" > "$s/logs/$v-validated"
export CARGO_TARGET_DIR=/dev/shm/interval-real-ball-boundary/target-wasm
cargo +1.95.0 build --offline --release --lib --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/translation_retry.wasm" "$s/images/$v-validated.wasm"
node "$s/controlled.cjs" "$s/images/$v-validated.wasm" "$expected" > "$s/logs/$v-validated-wasm"
