const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{const module=await WebAssembly.compile(fs.readFileSync(process.argv[2]));assert.deepEqual(WebAssembly.Module.imports(module),[]);
let target=[1,1,2,2,1,1,2,1,2,1,1,1,1,2,3,2,2,2,1,1];
if(true)for(const i of [4,5,6,7,8,9,10,11,18,19])target[i]=3;
for(let run=0;run<2;run++){const {exports:e}=await WebAssembly.instantiate(module);for(let i=0;i<40;i++){const c=i%20,v=e.ball_verdict(c);console.log(run,c,v,e.memory.buffer.byteLength);assert.equal(v,target[c],"case "+c)}}})().catch(e=>{console.error(e);process.exit(1)})
