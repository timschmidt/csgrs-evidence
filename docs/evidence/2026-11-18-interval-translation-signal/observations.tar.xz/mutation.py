from pathlib import Path
import sys
if sys.argv[1]=='abort':
 p=Path('crates/hyperreal/src/real/arithmetic/facts.rs');t=p.read_text()
 i=t.index('    pub fn certified_rational_interval(');j=t.index('    /// Returns a certified rational interval using only',i)
 before=t[i:j];guard='        if self.is_aborted() {\n            return None;\n        }\n'
 assert before.count(guard)==2;t=t[:i]+before.replace(guard,'')+t[j:]
else:
 p=Path('crates/hyperinterval/src/dyadic.rs');t=p.read_text();i=t.index('        pub fn from_real(')
 before='Self::from_grid_bounds(&lower, &upper, precision, budget)'
 assert t[i:].count(before)==1;t=t[:i]+t[i:].replace(before,'Self::from_grid_bounds(&lower, &lower, precision, budget)')
p.write_text(t)
