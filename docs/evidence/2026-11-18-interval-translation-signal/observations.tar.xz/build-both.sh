set -eu
s=/dev/shm/interval-translation-signal
for v in before repair; do
 if test "$v" = repair; then git -C "$s/csgrs" apply "$s/translation.patch";fi
 for k in native trace wasm life usable test; do bash "$s/build.sh" "$v" "$k" > "$s/logs/$v-$k-build" 2>&1 & done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
