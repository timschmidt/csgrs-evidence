set -eu
s=/dev/shm/interval-translation-signal
cd "$s/csgrs"
. /dev/shm/interval-bisection/env
p=crates/hyperinterval/conformance/wasm-real-bridge
for m in abort point;do
 python3 "$s/mutation.py" "$m"
 git diff > "$s/$m-mutation.patch"
 if cargo +1.95.0 test --locked -p hyperinterval --features hyperreal --test real_dyadic_lifecycle > "$s/logs/mutation-$m-native" 2>&1;then exit 1;fi
 cargo +1.95.0 build --locked --release --manifest-path "$p/Cargo.toml" --target wasm32-unknown-unknown --target-dir /dev/shm/interval-real-ball-boundary/target-wasm > "$s/logs/mutation-$m-build" 2>&1
 if node "$p/check.mjs" /dev/shm/interval-real-ball-boundary/target-wasm/wasm32-unknown-unknown/release/interval_real_bridge_wasm_conformance.wasm > "$s/logs/mutation-$m-wasm" 2>&1;then exit 1;fi
 rg -q 'test result: FAILED' "$s/logs/mutation-$m-native"
 rg -q 'RuntimeError: unreachable' "$s/logs/mutation-$m-wasm"
 git apply -R "$s/$m-mutation.patch"
done
git diff --exit-code
