from pathlib import Path
import ast,json
s=Path(__file__).parent
def profile(v):
 h={};u={};stack={}; guards=[]
 for i in range(1,17):
  for l in (s/'logs'/f'{v}-controlled-life-{i}').read_text().splitlines():
   x=l.split('|');k=x[1]
   if x[0]=='STACK': key=k+','+x[2];stack[key]=max(stack.get(key,0),int(x[-1]))
   else:
    values=tuple(ast.literal_eval(x[-1]));assert h.setdefault(k,values)==values
  guards.extend(int(l.split()[-1]) for l in (s/'logs'/f'{v}-controlled-guard-{i}').read_text().splitlines())
 for l in (s/'logs'/f'{v}-controlled-usable').read_text().splitlines():
  k,_,usable=l.split('|');u[k]=ast.literal_eval(usable)
 assert len(stack)==48 and len(h)==len(u)==24
 return dict(heap=h,usable=u,stack=stack,headroom=min(guards),rss=(s/'logs'/f'{v}-controlled-rss').read_text().strip())
p={v:profile(v) for v in ['fixed','before','fold']}
for v,h in p.items():
 print(v,'requested/usable/retained/stack/headroom', max(x[4] for x in h['heap'].values()),max(x[1] for x in h['usable'].values()),max(x[-1] for x in h['heap'].values()),max(h['stack'].values()),h['headroom'])
(s/'controlled-profiles.json').write_text(json.dumps(p,indent=2)+'\n')
