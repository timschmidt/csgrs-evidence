set -eu
s=/dev/shm/interval-translation-signal
. /dev/shm/interval-bisection/env
for pair in fixed:c9f1f9ac5 before:8fe441513 fold:7e881ac12;do
 v=${pair%:*}
 git -C "$s/csgrs" switch -q --detach "${pair#*:}"
 for k in life usable; do (
  cd "$s/controlled-$k"
  export CARGO_TARGET_DIR="/dev/shm/interval-real-ball-boundary/target-$k"
  cargo +1.95.0 build --offline --release
  cp "$CARGO_TARGET_DIR/release/ball-$k" "$s/images/$v-controlled-$k"
  if test "$k" = life;then
   for i in $(seq 1 16);do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-controlled-life" > "$s/logs/$v-controlled-life-$i" 2>"$s/logs/$v-controlled-guard-$i";done
  else
   python3 /dev/shm/interval-box-coverage/measure-rss.py "$s/logs/$v-controlled-rss" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-controlled-usable" > "$s/logs/$v-controlled-usable"
  fi
 ) > "$s/logs/$v-controlled-$k-build" 2>&1 & done
 fail=0;for j in $(jobs -p);do wait "$j" || fail=1;done;test "$fail" -eq 0
done
