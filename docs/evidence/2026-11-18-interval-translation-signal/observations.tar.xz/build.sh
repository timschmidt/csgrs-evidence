set -eu
s=/dev/shm/interval-translation-signal
v=$1
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="/dev/shm/interval-real-ball-boundary/target-$2"
case $2 in
native|trace)
 cd "$s/client";args=();if test "$2" = trace;then args=(--features trace);fi
 cargo +1.95.0 build --offline --release "${args[@]}" --bin ball-client
 cp "$CARGO_TARGET_DIR/release/ball-client" "$s/images/$v-$2"
 setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-$2" > "$s/logs/$v-$2";;
wasm)
 cd "$s/client"
 cargo +1.95.0 build --offline --release --target wasm32-unknown-unknown --lib
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/ball_client.wasm" "$s/images/$v.wasm"
 node "$s/check.cjs" "$s/images/$v.wasm" "$v" > "$s/logs/$v-wasm";;
life|usable)
 cd "$s/$2"
 cargo +1.95.0 build --offline --release
 cp "$CARGO_TARGET_DIR/release/ball-$2" "$s/images/$v-$2"
 if test "$2" = life; then
 for i in $(seq 1 16);do setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-life" > "$s/logs/$v-life-$i" 2>"$s/logs/$v-guard-$i";done
 else python3 /dev/shm/interval-box-coverage/measure-rss.py "$s/logs/$v-rss" setarch "$(uname -m)" -R taskset -c 4 "$s/images/$v-usable" > "$s/logs/$v-usable";fi;;
test)
 cd "$s/csgrs"; export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/owner-target
 cargo +1.95.0 test --locked --release -p hyperinterval --features real-ball --test real_bridge --no-run --message-format=json > "$s/logs/$v-test.json"
 python3 - "$s" "$v" <<'PY'
import json,sys,shutil
from pathlib import Path
s=Path(sys.argv[1]);v=sys.argv[2];p=next(r['executable'] for l in (s/'logs'/(v+'-test.json')).read_text().splitlines() if (r:=json.loads(l)).get('executable') and r['target']['name']=='real_bridge')
shutil.copy2(p,s/'images'/(v+'-test'))
PY
 "$s/images/$v-test" > "$s/logs/$v-test";;
esac
