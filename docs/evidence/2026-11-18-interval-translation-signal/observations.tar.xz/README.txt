Primary comparison 8fe441513, program reference c9f1f9ac5. The retained conformance
client and native tests are at 3ad284efe. The unadmitted owner repair and exact
regressions are at 7e881ac12 on interval-translation-signal-review.
Translation is scoped to shifts of one nonrational Real by a structurally rational
operand. The rational may have its own active flag. This is not signal composition
for two separately controlled nonrational operands or a claim of global closure.

Build paths in scripts name /dev/shm/interval-translation-signal. Place the Cargo
clients from logs/tools below that directory, copy build.sh etc. from the top level,
and use a csgrs worktree there at each selected revision. Use Rust 1.95.0 and
wasm32-unknown-unknown, or adjust absolute offline target, registry and observer
paths. The six ordinary consumer versions are fixed, before, repair, shared, cache
and fold (the last four nonbaseline versions are alternative implementations).
Apply translation.patch, shared.patch, cache.patch or fold.patch separately to the
clean primary. Run build.sh VERSION KIND, for native, trace, wasm, life, usable,
test. The old rational-boundary cases remain unresolved in every version; check.cjs
has the same expected statuses for all cases. compare-all.py reads the images and
raw logs. The baseline was rebuilt at the same path as all candidates including
the fixed program. timing, timing2 and the foo-times-a/b scripts use pinned cores
3 and 5 respectively and alternate order across 18 independent paired processes.
FRESH includes construction and drop; WARM reuses the inputs. A pair has 2000
calls per leg for each fixture. Inputs 15 and 17 repeat the same control.

For signalled workloads run controlled.sh and validate.sh on before/fold, with
expected masks 56 and 63 respectively. validate.sh additionally checks every
present active scalar/dyadic bound and membership against independent mathematical
expectations. Each native run exercises 24 ordered records; each WASM run exercises
96 records across two fresh instances. Masks 56/63 say bits 3--5 passed for
independent reader and retry; bits 0--2 differ on proper rejection of active
requests. controlled-lifetimes.sh measures the complete fixture including retry,
allocation and release. observations.py produces per-key accounts. Different
active outcomes are never timing-equivalent completed work.

The primary conformance runner is scripts/check_interval_wasm.py in the accepted
commit. The concurrency test uses native threads; bare WASM shares its exact serial
oracle. Mutation files are independent negative controls on 8fe441513 using the
accepted corpus. Native tests must fail and the bare WASM entry point must trap
on each mutation. A direct attempt to build native dev tests targeting bare WASM
is kept under main-wasm-tests; this is separate from the executed import-free
consumer. The early one-million-work-unit observation is retained. The permanent
test covers that failure and retries with a larger conversion allowance.
