const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{const module=await WebAssembly.compile(fs.readFileSync(process.argv[2]));
assert.deepEqual(WebAssembly.Module.imports(module),[]);
for(let run=0;run<2;run++){
 const {exports:e}=await WebAssembly.instantiate(module);
 for(let n=0;n<48;n++){
 const i=n%24,mask=e.observe(i);
 console.log(run,i,mask,e.memory.buffer.byteLength);assert.equal(mask,+process.argv[3]);
 }
}})().catch(e=>{console.error(e);process.exit(1)})
