use hyperreal::{Rational,Real};
use hyperinterval::{BallRelation,RealBall,DyadicInterval,DyadicBudget,IntervalError};
use std::sync::{Arc,atomic::{AtomicBool,Ordering}};

// Bits 0..2 report rejection of active scalar, dyadic and membership queries.
// Bits 3..5 independently verify the retry and the uncontrolled reader.
#[unsafe(no_mangle)]
pub extern "C" fn observe(case:u32)->u32 {
    let kind=case%3;
    let (mut value,mut q,expected)=match kind {
        0=>(Real::from(2).sqrt().unwrap(),Real::from(Rational::fraction(7,5).unwrap()),BallRelation::Contained),
        1=>(Real::pi(),Real::from(3),BallRelation::Contained),
        _=>(Real::e(),Real::from(3),BallRelation::Excluded),
    };
    let independent=value.clone();
    if case&8!=0 {assert!(value.certified_rational_interval(-96).is_some());}
    let stop=Arc::new(AtomicBool::new(false));
    value.abort(stop.clone());
    q.abort(Arc::new(AtomicBool::new(true)));
    let swap=case&4!=0;
    let (point,center)=if swap {(&q,&value)} else {(&value,&q)};
    let delta=point-center;
    let ball=RealBall::new(center.clone(),Rational::fraction(1,4).unwrap()).unwrap();
    stop.store(true,Ordering::Relaxed);
    let mut result=u32::from(delta.certified_rational_interval(-96).is_none());
    result|=u32::from(DyadicInterval::from_real(&delta,-96,&mut DyadicBudget::new(4096,1_000_000_000))==Err(IntervalError::EnclosureUnavailable))<<1;
    result|=u32::from(ball.classify_point(point,-96)==Err(IntervalError::EnclosureUnavailable))<<2;
    result|=u32::from(independent.certified_rational_interval(-96).is_some())<<3;
    stop.store(false,Ordering::Relaxed);
    result|=u32::from(ball.classify_point(point,-96)==Ok(expected))<<4;
    let [lo,hi]=delta.certified_rational_interval(-96).unwrap();
    let offset=q.exact_rational_ref().unwrap();
    let (lo,hi)=if swap{(offset-hi,offset-lo)}else{(lo+offset,hi+offset)};
    let numerical=match kind {
        0=>lo>Rational::one()&&&lo*&lo<Rational::from(2)&&&hi*&hi>Rational::from(2)&&hi<Rational::from(2),
        1=>lo>Rational::fraction(333,106).unwrap()&&hi<Rational::fraction(355,113).unwrap(),
        _=>lo>Rational::fraction(27,10).unwrap()&&hi<Rational::fraction(68,25).unwrap(),
    };
    result|(u32::from(numerical)<<5)
}
