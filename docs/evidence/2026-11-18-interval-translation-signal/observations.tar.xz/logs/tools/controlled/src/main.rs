fn main() {
    let expect:u32=std::env::args().nth(1).unwrap().parse().unwrap();
    for case in 0..24 {
        let mask=translation_retry::observe(case);
        println!("{case} {mask}");
        assert_eq!(mask,expect);
    }
}
