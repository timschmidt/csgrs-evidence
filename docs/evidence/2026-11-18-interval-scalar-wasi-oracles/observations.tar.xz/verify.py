from pathlib import Path
import collections,hashlib,json,re,runpy,subprocess,tomllib
s=Path(__file__).parent
root=Path('/mnt/development/csgrs')
driver=runpy.run_path(str(root/'crates/hyperinterval/conformance/wasi-tests.py'))
out={}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for compiler in ('1.88.0','1.95.0','stable'):
    guest=s/f'final-{compiler}'; report=json.loads((guest/'report.json').read_text())
    assert report==json.loads((s/f'noble-{compiler}/report.json').read_text())
    assert report==json.loads((s/f'admit-{compiler}/report.json').read_text())
    passed=sum(map(len,report['guest'].values()))
    assert (passed,len(report['host_required']))==((178,6) if compiler=='1.88.0' else (228,9))
    for target,case in report['host_required'].items():
        probe=(guest/(target+'-probe.log')).read_text()
        assert driver['missing_os_facility'](probe,target,driver['OS_PROBES'][target][1])
        assert driver['completed']((guest/(target+'-host.log')).read_text(),{case})
    extras={}; seen=set()
    for sec in re.split(r'^\s*Running ',(s/f'host-{compiler}.log').read_text(),flags=re.M)[1:]:
        path=sec.partition(' (')[0]
        k='hyperinterval' if path.startswith('unittests') else Path(path).stem
        assert k not in seen;seen.add(k)
        native=set(re.findall(r'^test (\S+) \.\.\. ok$',sec,re.M))
        covered=set(report['guest'][k])
        if k in report['host_required']:covered.add(report['host_required'][k])
        assert not (covered-native),(compiler,k,covered-native)
        if native-covered:extras[k]=sorted(native-covered)
    assert seen==set(report['guest'])
    assert sum(map(len,extras.values()))==(32 if compiler=='1.88.0' else 33)
    old=Path('/dev/shm/interval-box-requalification')/('final-'+compiler)
    new=s/('clients-'+compiler)
    assert json.loads((new/'report.json').read_text())==json.loads((old/'report.json').read_text())
    images={p.name:sha(p) for p in new.glob('*.wasm')}
    assert images=={p.name:sha(p) for p in old.glob('*.wasm')}
    assert len(images)==(4 if compiler=='1.88.0' else 5)
    atan,=list((guest/'target/wasm32-wasip1/release/deps').glob('arctangent-*.wasm'))
    assert b'mpfr_atan' in atan.read_bytes() and b'__gmpz_mul' in atan.read_bytes()
    out[compiler]={'guest_arctangent_sha256':sha(atan),'passed_guest':passed,'passed_host_required':len(report['host_required']),'additional_native_tests':extras,'existing_images':images}
assert 'Cross compilation from x86_64-unknown-linux-gnu to wasm32-wasip1 not supported' in (s/'baseline.log').read_text()
assert 'dyadic_bisection.log' in (s/'mutant-suite.log').read_text() and 'assertion' in (s/'mutant-suite/dyadic_bisection.log').read_text()
assert '4 passed' in (s/'mutant-native.log').read_text()
assert 'Unexpected guest probe result' in (s/'wrong-site.log').read_text()
assert 'force-cross' in (s/'features-wasm32-wasip1.txt').read_text() and all('force-cross' not in (s/('features-'+t+'.txt')).read_text() for t in ('wasm32-wasip1-threads','x86_64-unknown-linux-gnu'))
assert not re.search(r'\b(?:rug|gmp-mpfr-sys) v',(s/'normal-deps.txt').read_text())
pkg=s/'package-target/package/hyperinterval-0.1.0'
assert tomllib.loads((pkg/'Cargo.toml').read_text())['target']['wasm32-wasip1']['dev-dependencies']['gmp-mpfr-sys']['features']==['force-cross']
assert sha(s/'driver-client.elf')==sha(s/'preceding-client.elf')
assert json.loads((s/'size-result.json').read_text())['failed']['driver']=={}
(s/'qualification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified all guest IDs, diagnosed OS traps and native equivalents, native-only inventory, 14 existing WASM images, the linked native client, package dependency scopes, and two negative controls.')
