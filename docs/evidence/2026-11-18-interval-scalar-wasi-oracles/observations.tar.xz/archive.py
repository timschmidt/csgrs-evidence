from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence';record='docs/evidence/2026-11-18-interval-scalar-wasi-oracles'
def git(repo,*args):return sp.check_output(['git','-C',repo,*args])
files={}
def add(p):files[str(p.relative_to(s))]=p.read_bytes()
for p in s.iterdir():
    if p.is_file() and (p.suffix in ['.log','.json','.sh','.py','.patch','.txt','.c'] or p.name in ['scope','preceding','source-revision','env']):
        add(p)
for rel in ['ubuntu/toolchain.py','ubuntu/toolchain.log','bin/wasi-cc','wrong-site/dyadic_zero_grid-probe.log','mutant-suite/dyadic_bisection.log']:
    add(s/rel)
for stem in ['final','noble','admit','clients']:
    for d in s.glob(stem+'-*'):
        if not d.is_dir():continue
        for p in d.iterdir():
            if p.is_file() and (p.suffix=='.log' or p.name in ['rustc.txt','commands.json','report.json']):add(p)
for v in ['1.88.0','1.95.0','stable']:
    assert 'final-'+v+'/report.json' in files
    d=s/('final-'+v)/'target/wasm32-wasip1/release/build'
    for p in sorted(d.glob('gmp-mpfr-sys-*/out/include/*.h')):
        if p.name in ['gmp.h','mpfr.h']:
            # The build's ABI and version facts suffice; do not redistribute vendor headers.
            lines=[x for x in p.read_text(errors='replace').splitlines() if x.startswith(('#define GMP_LIMB_BITS','#define __GNU_MP_VERSION','#define MPFR_VERSION_'))]
            files[f'ABI/{v}-{p.name}.txt']=('\n'.join(lines)+'\n').encode()
    libs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.glob('gmp-mpfr-sys-*/out/lib/*.a')}
    assert libs.keys()=={'libgmp.a','libmpfr.a'},libs
    files[f'ABI/{v}-archives.json']=json.dumps(libs,indent=2).encode()
assert files['source-revision'].decode().strip()==git(r,'rev-parse','HEAD').decode().strip()
assert 'Verified all guest IDs' in files['verified.log'].decode()
assert 'No findings to report' in files['zizmor-final.log'].decode()
files['node-version.txt']=sp.check_output(['node','--version'])
h=lambda b:hashlib.sha256(b).hexdigest()
digests={k:h(v) for k,v in sorted(files.items())}
archive=s/'record';archive.mkdir(exist_ok=True)
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
    for k,b in sorted(files.items()):
        i=tarfile.TarInfo(k);i.size=len(b);tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar: assert {m.name:h(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(e).free-3*size-1024**2>=20*1024**3
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(archive,e/record)
git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive WASI scalar MPFR oracle runs and matched qualification controls')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
(s/'evidence-revision').write_text(rev+'\n')
print(rev,row)
