set -eu
s=/dev/shm/interval-scalar-wasi
cd "$s/repo"
. "$s/env"
v=$1
stage=$2
export CARGO_TARGET_DIR="$s/guest-$v" CARGO_BUILD_JOBS=5
features=(--all-features)
if [ "$v" = 1.88.0 ]; then
 ieee=float-enclosure-wasip1
 if [ "$stage" = fixed ]; then ieee=float-enclosure; fi
 features=(--no-default-features --features "integer,fixed,dyadic,float-proposal,$ieee,serde,dispatch-trace")
fi
cargo "+$v" test --release --locked -p hyperinterval --target wasm32-wasip1 "${features[@]}" --test extended --no-run --message-format=json >"$s/linked-$stage-$v.jsonl" 2>"$s/linked-$stage-$v.log"
path=$(python3 - "$s/linked-$stage-$v.jsonl" <<'PY'
import json,sys
for l in open(sys.argv[1]):
 if (j:=json.loads(l)).get('executable'):print(j['executable'])
PY
)
cp "$path" "$s/$stage-$v.wasm"
node /mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs "$path" --test-threads=1 --nocapture > "$s/linked-run-$stage-$v.log" 2>&1
