import json,re,subprocess,pathlib
s=pathlib.Path(__file__).parent
root=pathlib.Path(subprocess.check_output(['rustc','+1.95.0','--print','sysroot'],text=True).strip())
objdump=root/'lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-objdump'
out={}
for v in ('1.88.0','1.95.0','stable'):
 r={}
 for n in ('fixed','preceding','candidate'):
  p=s/f'{n}-{v}.wasm'
  listing=subprocess.check_output([objdump,'-h',p],text=True)
  r[n]={'file':p.stat().st_size,'code':int(re.search(r'^\s*\d+ CODE\s+([a-f0-9]+)',listing,re.M)[1],16)}
 r['gate']={}
 for name in ('file','code'):
  f,p,c=[r[n][name] for n in ('fixed','preceding','candidate')]
  incr=max(c-p,0); cum=max(0,p-f)+incr
  r['gate'][name]={'incremental_bytes':incr,'cumulative_bytes':cum,'passes':incr<=4096 and incr<=p*0.01 and cum<=16384 and cum<=f*0.02}
 assert r['candidate']['file']<=1536*1024
 out[v]=r
print(json.dumps(out,indent=2))
