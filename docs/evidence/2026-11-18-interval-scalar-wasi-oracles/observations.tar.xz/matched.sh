set -eu
s=/dev/shm/interval-scalar-wasi
cd "$s/repo"
. /dev/shm/interval-lattice-coverage/env
p=crates/hyperinterval/tests/extended.rs
git restore Cargo.lock crates/hyperinterval/Cargo.toml "$p"
for stage in fixed preceding candidate; do
 case $stage in
 fixed) git switch --detach c9f1f9ac5
 cat >>crates/hyperinterval/Cargo.toml <<'EOF'

[target.wasm32-wasip1.dev-dependencies]
gmp-mpfr-sys = { version = "1.7", default-features = false, features = ["force-cross"] }
EOF
 ;;
 preceding) git restore Cargo.lock crates/hyperinterval/Cargo.toml
 git switch --detach "$(cat "$s/preceding")"
 cp /mnt/development/csgrs/crates/hyperinterval/Cargo.toml crates/hyperinterval/ ;;
 candidate) git apply "$s/ingress.patch" ;;
 esac
 cargo metadata --offline --format-version 1 >/dev/null
 pids=()
 for v in 1.88.0 1.95.0 stable; do bash "$s/measure.sh" "$v" "$stage" & pids+=("$!"); done
 rc=0
 for p in "${pids[@]}"; do wait "$p" || rc=1; done
 test "$rc" -eq 0
done
