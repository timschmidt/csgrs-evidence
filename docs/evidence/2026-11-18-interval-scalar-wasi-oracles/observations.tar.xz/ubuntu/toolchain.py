from pathlib import Path
import hashlib,lzma,subprocess,urllib.request
s=Path(__file__).parent
needed=set('wasi-libc clang-18 lld-18 libclang-rt-18-dev-wasm32 libllvm18 libclang-common-18-dev libclang1-18 libclang-cpp18'.split())
for archive in ['main','universe']:
 for p in lzma.open(s/(archive+'.xz'),'rt').read().split('\n\n'):
    fields=dict(l.split(': ',1) for l in p.splitlines() if ': ' in l and not l.startswith(' '))
    name=fields.get('Package')
    if name not in needed: continue
    dest=s/(name+'.deb')
    subprocess.run(['curl','--retry','2','--max-time','90','-fsSL','https://archive.ubuntu.com/ubuntu/'+fields['Filename'],'-o',str(dest)],check=True)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==fields['SHA256']
    subprocess.run(['dpkg-deb','-x',dest,s/'sdk'],check=True)
    print(name,fields['Version'],fields['SHA256'],flush=True)
    needed.remove(name)
assert not needed,needed
