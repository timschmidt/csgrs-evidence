set -eu
s=/dev/shm/interval-scalar-wasi
cd "$s/repo"
. /dev/shm/interval-lattice-coverage/env
export CARGO_TARGET_DIR="$s/matched-host" CARGO_BUILD_JOBS=6
git restore Cargo.lock crates/hyperinterval/Cargo.toml crates/hyperinterval/tests/extended.rs
for stage in fixed preceding driver typed; do
 case $stage in
 fixed) git switch --detach c9f1f9ac5 ;;
 preceding) git switch --detach "$(cat "$s/preceding")" ;;
 driver) cp /mnt/development/csgrs/Cargo.lock .
 cp /mnt/development/csgrs/crates/hyperinterval/Cargo.toml crates/hyperinterval/ ;;
 typed) git apply "$s/typed-error.patch" ;;
 esac
 cargo +1.95.0 test --locked --release -p hyperinterval --all-features --test extended --no-run --message-format=json > "$s/host-$stage.jsonl" 2>"$s/build-host-$stage.log"
 f=$(python3 - "$s/host-$stage.jsonl" <<'PY'
import json,sys
for l in open(sys.argv[1]):
 if (j:=json.loads(l)).get('executable'):print(j['executable'])
PY
 )
 cp "$f" "$s/$stage.elf"
 "$f" >"$s/host-extended-$stage.log"
 cargo +1.95.0 build --release --locked -p hyperlattice-interval --features fixed --example fixed_affine > "$s/host-client-$stage.log" 2>&1
 cp "$CARGO_TARGET_DIR/release/examples/fixed_affine" "$s/$stage-client.elf"
done
