//! Exact closed-interval classifiers.
//!
//! The functions here classify Real ranges by exact sign decisions over
//! endpoint differences. They are intentionally Real predicates, not bounding
//! box or sweep-line data structures; higher crates own those objects and call
//! this module for certified interval decisions.

use crate::predicate::PredicatePolicy;
use crate::predicates::decision::{DecisionTrace, UnknownDecision, decided};
use core::cmp::Ordering;

use crate::classify::{ClosedIntervalIntersection, RealIntervalLocation};
use crate::predicate::PredicateOutcome;
use crate::predicates::order::compare_reals_with_policy;
use hyperreal::Real;

/// Classify `value` relative to a closed interval with an explicit predicate
/// escalation policy.
///
/// Endpoints may be supplied in either order; this function first normalizes
/// them by exact Real comparison. The result is useful for segment parameter
/// checks, bounding-box point tests, and candidate filtering in arrangement or
/// triangulation code. The interval itself is not a geometric object here.
/// Interval tests are candidate filters; final topology must still be certified
/// by geometric predicates. Every comparison is a certified sign, not a
/// primitive-float tolerance.
pub fn classify_real_closed_interval_with_policy(
    value: &Real,
    first: &Real,
    second: &Real,
    policy: PredicatePolicy,
) -> PredicateOutcome<RealIntervalLocation> {
    let mut trace = DecisionTrace::default();
    let (lower, upper) = match ordered_pair(first, second, policy, &mut trace) {
        Ok(pair) => pair,
        Err(unknown) => return unknown.into_outcome(),
    };

    let lower_cmp = match decided(compare_reals_with_policy(value, lower, policy), &mut trace) {
        Ok(ordering) => ordering,
        Err(unknown) => return unknown.into_outcome(),
    };
    if lower_cmp == Ordering::Less {
        return PredicateOutcome::decided(
            RealIntervalLocation::Below,
            trace.certainty,
            trace.stage,
        );
    }
    if lower_cmp == Ordering::Equal {
        return PredicateOutcome::decided(
            RealIntervalLocation::AtLowerEndpoint,
            trace.certainty,
            trace.stage,
        );
    }

    let upper_cmp = match decided(compare_reals_with_policy(value, upper, policy), &mut trace) {
        Ok(ordering) => ordering,
        Err(unknown) => return unknown.into_outcome(),
    };
    let location = match upper_cmp {
        Ordering::Less => RealIntervalLocation::Interior,
        Ordering::Equal => RealIntervalLocation::AtUpperEndpoint,
        Ordering::Greater => RealIntervalLocation::Above,
    };

    PredicateOutcome::decided(location, trace.certainty, trace.stage)
}

/// Return whether `value` lies in a closed interval with an explicit predicate
/// escalation policy.
pub fn real_in_closed_interval_with_policy(
    value: &Real,
    first: &Real,
    second: &Real,
    policy: PredicatePolicy,
) -> PredicateOutcome<bool> {
    match classify_real_closed_interval_with_policy(value, first, second, policy) {
        PredicateOutcome::Decided {
            value,
            certainty,
            stage,
        } => PredicateOutcome::decided(value.is_inside_or_boundary(), certainty, stage),
        PredicateOutcome::Unknown { needed, stage } => PredicateOutcome::unknown(needed, stage),
    }
}

/// Classify two closed Real intervals with an explicit predicate escalation
/// policy.
///
/// Endpoint order does not matter for either interval. `Touching` means the
/// intervals share exactly one endpoint value, which is a useful distinction for
/// curve splitting, sweep events, and conservative broad-phase pruning.
pub fn classify_closed_interval_intersection_with_policy(
    first_start: &Real,
    first_end: &Real,
    second_start: &Real,
    second_end: &Real,
    policy: PredicatePolicy,
) -> PredicateOutcome<ClosedIntervalIntersection> {
    match classify_closed_interval_intersection_with_extent_policy(
        first_start,
        first_end,
        second_start,
        second_end,
        policy,
    ) {
        PredicateOutcome::Decided {
            value: (relation, _),
            certainty,
            stage,
        } => PredicateOutcome::decided(relation, certainty, stage),
        PredicateOutcome::Unknown { needed, stage } => PredicateOutcome::unknown(needed, stage),
    }
}

/// Internal interval report that retains whether either input has zero extent.
///
/// AABB classifiers need this fact in addition to the overlap relation. Keeping
/// it in the interval normalization pass avoids repeating the same endpoint
/// comparisons after all four orders have already been certified.
pub(crate) fn classify_closed_interval_intersection_with_extent_policy(
    first_start: &Real,
    first_end: &Real,
    second_start: &Real,
    second_end: &Real,
    policy: PredicatePolicy,
) -> PredicateOutcome<(ClosedIntervalIntersection, bool)> {
    let mut trace = DecisionTrace::default();
    let (first_lower, first_upper, first_zero_extent) =
        match ordered_pair_with_zero_extent(first_start, first_end, policy, &mut trace) {
            Ok(pair) => pair,
            Err(unknown) => return unknown.into_outcome(),
        };
    let (second_lower, second_upper, second_zero_extent) =
        match ordered_pair_with_zero_extent(second_start, second_end, policy, &mut trace) {
            Ok(pair) => pair,
            Err(unknown) => return unknown.into_outcome(),
        };
    let zero_extent = first_zero_extent || second_zero_extent;

    match decided(
        compare_reals_with_policy(first_upper, second_lower, policy),
        &mut trace,
    ) {
        Ok(Ordering::Less) => {
            return PredicateOutcome::decided(
                (ClosedIntervalIntersection::Disjoint, zero_extent),
                trace.certainty,
                trace.stage,
            );
        }
        Ok(Ordering::Equal) => {
            return PredicateOutcome::decided(
                (ClosedIntervalIntersection::Touching, zero_extent),
                trace.certainty,
                trace.stage,
            );
        }
        Ok(Ordering::Greater) => {}
        Err(unknown) => return unknown.into_outcome(),
    }

    match decided(
        compare_reals_with_policy(second_upper, first_lower, policy),
        &mut trace,
    ) {
        Ok(Ordering::Less) => PredicateOutcome::decided(
            (ClosedIntervalIntersection::Disjoint, zero_extent),
            trace.certainty,
            trace.stage,
        ),
        Ok(Ordering::Equal) => PredicateOutcome::decided(
            (ClosedIntervalIntersection::Touching, zero_extent),
            trace.certainty,
            trace.stage,
        ),
        Ok(Ordering::Greater) => PredicateOutcome::decided(
            (ClosedIntervalIntersection::Overlapping, zero_extent),
            trace.certainty,
            trace.stage,
        ),
        Err(unknown) => unknown.into_outcome(),
    }
}

/// Return whether two closed Real intervals intersect with an explicit
/// predicate escalation policy.
pub fn closed_intervals_intersect_with_policy(
    first_start: &Real,
    first_end: &Real,
    second_start: &Real,
    second_end: &Real,
    policy: PredicatePolicy,
) -> PredicateOutcome<bool> {
    match classify_closed_interval_intersection_with_policy(
        first_start,
        first_end,
        second_start,
        second_end,
        policy,
    ) {
        PredicateOutcome::Decided {
            value,
            certainty,
            stage,
        } => PredicateOutcome::decided(value.intersects(), certainty, stage),
        PredicateOutcome::Unknown { needed, stage } => PredicateOutcome::unknown(needed, stage),
    }
}

fn ordered_pair<'a>(
    first: &'a Real,
    second: &'a Real,
    policy: PredicatePolicy,
    trace: &mut DecisionTrace,
) -> Result<(&'a Real, &'a Real), UnknownDecision> {
    let (lower, upper, _) = ordered_pair_with_zero_extent(first, second, policy, trace)?;
    Ok((lower, upper))
}

fn ordered_pair_with_zero_extent<'a>(
    first: &'a Real,
    second: &'a Real,
    policy: PredicatePolicy,
    trace: &mut DecisionTrace,
) -> Result<(&'a Real, &'a Real, bool), UnknownDecision> {
    Ok(
        match decided(compare_reals_with_policy(first, second, policy), trace)? {
            Ordering::Greater => (second, first, false),
            Ordering::Less => (first, second, false),
            Ordering::Equal => (first, second, true),
        },
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::predicate::RefinementNeed;
    use crate::predicate::{Certainty, Escalation};
    use crate::predicates::decision::{certainty_rank, max_certainty, max_stage, stage_rank};

    const APPROX: PredicatePolicy = PredicatePolicy::APPROXIMATE_512;

    fn real(value: i32) -> hyperreal::Real {
        hyperreal::Real::from(value)
    }

    fn terminally_unresolved_zero() -> Real {
        let sine = Real::e().sin();
        let cosine = Real::e().cos();
        let original = &sine * &sine + &cosine * &cosine - Real::one();
        // Preserve the original identity as a newly certified proof case.
        assert_eq!(
            original.exact_rational_normal_form(),
            Some(hyperreal::Rational::zero())
        );
        // A separate angle-addition identity retains the terminal-policy control.
        crate::test_support::terminally_unresolved_zero()
    }

    #[test]
    fn real_interval_classifies_ordered_and_reversed_endpoints() {
        assert_eq!(
            crate::classify_real_closed_interval(&real(1), &real(1), &real(4), APPROX).value(),
            Some(RealIntervalLocation::AtLowerEndpoint)
        );
        assert_eq!(
            crate::classify_real_closed_interval(&real(3), &real(4), &real(1), APPROX).value(),
            Some(RealIntervalLocation::Interior)
        );
        assert_eq!(
            crate::classify_real_closed_interval(&real(5), &real(1), &real(4), APPROX).value(),
            Some(RealIntervalLocation::Above)
        );
        assert_eq!(
            crate::real_in_closed_interval(&real(4), &real(1), &real(4), APPROX).value(),
            Some(true)
        );
    }

    #[test]
    fn closed_interval_intersection_distinguishes_disjoint_touching_and_overlap() {
        assert_eq!(
            crate::classify_closed_interval_intersection(
                &real(0),
                &real(1),
                &real(2),
                &real(3),
                APPROX
            )
            .value(),
            Some(ClosedIntervalIntersection::Disjoint)
        );
        assert_eq!(
            crate::classify_closed_interval_intersection(
                &real(0),
                &real(2),
                &real(2),
                &real(3),
                APPROX
            )
            .value(),
            Some(ClosedIntervalIntersection::Touching)
        );
        assert_eq!(
            crate::classify_closed_interval_intersection(
                &real(0),
                &real(3),
                &real(2),
                &real(4),
                APPROX
            )
            .value(),
            Some(ClosedIntervalIntersection::Overlapping)
        );
        assert_eq!(
            crate::closed_intervals_intersect(&real(4), &real(2), &real(1), &real(2), APPROX)
                .value(),
            Some(true)
        );
    }

    #[test]
    fn real_interval_covers_every_location_and_boolean_result() {
        for (value, expected) in [
            (-1, RealIntervalLocation::Below),
            (0, RealIntervalLocation::AtLowerEndpoint),
            (1, RealIntervalLocation::Interior),
            (2, RealIntervalLocation::AtUpperEndpoint),
            (3, RealIntervalLocation::Above),
        ] {
            assert_eq!(
                classify_real_closed_interval_with_policy(
                    &real(value),
                    &real(0),
                    &real(2),
                    PredicatePolicy::STRICT,
                )
                .value(),
                Some(expected),
            );
        }

        assert_eq!(
            real_in_closed_interval_with_policy(
                &real(-1),
                &real(0),
                &real(2),
                PredicatePolicy::STRICT,
            )
            .value(),
            Some(false),
        );
    }

    #[test]
    fn interval_classifiers_preserve_unknowns_at_each_comparison_stage() {
        fn is_unknown<T>(outcome: PredicateOutcome<T>) -> bool {
            matches!(outcome, PredicateOutcome::Unknown { .. })
        }

        let unresolved = terminally_unresolved_zero();

        // Endpoint normalization, lower comparison, and upper comparison.
        assert!(is_unknown(classify_real_closed_interval_with_policy(
            &real(0),
            &unresolved,
            &real(0),
            PredicatePolicy::STRICT,
        )));
        assert!(is_unknown(classify_real_closed_interval_with_policy(
            &unresolved,
            &real(0),
            &real(1),
            PredicatePolicy::STRICT,
        )));
        assert!(is_unknown(classify_real_closed_interval_with_policy(
            &unresolved,
            &real(-1),
            &real(0),
            PredicatePolicy::STRICT,
        )));
        assert!(is_unknown(real_in_closed_interval_with_policy(
            &unresolved,
            &real(0),
            &real(1),
            PredicatePolicy::STRICT,
        )));

        // First normalization, second normalization, first separating
        // comparison, and the reverse separating comparison.
        assert!(is_unknown(
            classify_closed_interval_intersection_with_policy(
                &unresolved,
                &real(0),
                &real(1),
                &real(2),
                PredicatePolicy::STRICT,
            )
        ));
        assert!(is_unknown(
            classify_closed_interval_intersection_with_policy(
                &real(1),
                &real(2),
                &unresolved,
                &real(0),
                PredicatePolicy::STRICT,
            )
        ));
        assert!(is_unknown(
            classify_closed_interval_intersection_with_policy(
                &real(-1),
                &unresolved,
                &real(0),
                &real(1),
                PredicatePolicy::STRICT,
            )
        ));
        assert!(is_unknown(
            classify_closed_interval_intersection_with_policy(
                &unresolved,
                &real(2),
                &real(-1),
                &real(0),
                PredicatePolicy::STRICT,
            )
        ));
        assert!(is_unknown(closed_intervals_intersect_with_policy(
            &real(-1),
            &unresolved,
            &real(0),
            &real(1),
            PredicatePolicy::STRICT,
        )));
    }

    #[test]
    fn reverse_interval_separation_and_contact_are_distinguished() {
        assert_eq!(
            classify_closed_interval_intersection_with_policy(
                &real(2),
                &real(3),
                &real(0),
                &real(1),
                PredicatePolicy::STRICT,
            )
            .value(),
            Some(ClosedIntervalIntersection::Disjoint),
        );
        assert_eq!(
            classify_closed_interval_intersection_with_policy(
                &real(1),
                &real(3),
                &real(0),
                &real(1),
                PredicatePolicy::STRICT,
            )
            .value(),
            Some(ClosedIntervalIntersection::Touching),
        );
        assert_eq!(
            closed_intervals_intersect_with_policy(
                &real(3),
                &real(2),
                &real(1),
                &real(0),
                PredicatePolicy::STRICT,
            )
            .value(),
            Some(false),
        );
    }

    #[test]
    fn decision_trace_rankings_are_total() {
        let certainties = [
            Certainty::Exact,
            Certainty::Filtered,
            Certainty::Approximate,
        ];
        for left in certainties {
            for right in certainties {
                assert_eq!(
                    certainty_rank(max_certainty(left, right)),
                    certainty_rank(left).max(certainty_rank(right)),
                );
            }
        }

        let stages = [
            Escalation::Structural,
            Escalation::Filter,
            Escalation::Exact,
            Escalation::Refined,
            Escalation::Undecided,
        ];
        for left in stages {
            for right in stages {
                assert_eq!(
                    stage_rank(max_stage(left, right)),
                    stage_rank(left).max(stage_rank(right)),
                );
            }
        }

        let mut trace = DecisionTrace::default();
        assert!(matches!(
            decided(
                PredicateOutcome::decided(7_u8, Certainty::Filtered, Escalation::Filter),
                &mut trace,
            ),
            Ok(7)
        ));
        assert_eq!(trace.certainty, Certainty::Filtered);
        assert_eq!(trace.stage, Escalation::Filter);
        assert!(
            decided::<u8>(
                PredicateOutcome::unknown(RefinementNeed::RealRefinement, Escalation::Undecided),
                &mut trace,
            )
            .is_err()
        );
    }
}
