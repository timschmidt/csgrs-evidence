//! Exact univariate resultant reports.
//!
//! Resultants are the elimination step that lets a curve or solver pipeline
//! remove one variable before root isolation. This module starts with the
//! classical Sylvester-matrix determinant: the determinant is computed by
//! [`crate::determinant_bareiss`], so coefficient arithmetic remains exact and
//! pivot decisions remain certified. It also exposes a fraction-free
//! pseudo-remainder chain for the subresultant scheduling boundary. Both
//! constructions remain exact and report uncertain pivot decisions.

use hyperreal::{CertifiedRealSign, Rational, Real, RealSign, ZeroKnowledge};
use num::Integer;
use num::{BigInt, One, Zero};

use crate::bareiss::{
    BareissDeterminantReport, BareissError, determinant_bareiss,
    determinant_integer_polynomial_matrix,
};
use crate::integer_interpolation::primitive_integer_polynomial;
use crate::policy_division::strict_exact_zero_for_storage;

/// Failure mode for exact univariate resultant construction.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum UnivariateResultantError {
    /// One of the input coefficient slices was empty.
    EmptyPolynomial,
    /// A coefficient needed for degree trimming remained unknown after the
    /// requested refinement bound and strict exact predicate cascade.
    UndecidedCoefficient {
        /// Input side whose coefficient was undecided.
        side: ResultantInputSide,
        /// Coefficient index in ascending power order.
        index: usize,
    },
    /// The Sylvester determinant could not be computed exactly.
    Determinant(BareissError),
}

/// Failure mode for exact univariate pseudo-remainder chain construction.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum UnivariateSubresultantChainError {
    /// One of the input coefficient slices was empty.
    EmptyPolynomial,
    /// A coefficient needed for degree trimming remained unknown after the
    /// requested refinement bound and strict exact predicate cascade.
    UndecidedCoefficient {
        /// Input side whose coefficient was undecided.
        side: ResultantInputSide,
        /// Coefficient index in ascending power order.
        index: usize,
    },
}

/// Identifies the input polynomial that produced a resultant error.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ResultantInputSide {
    /// Left-hand polynomial.
    Left,
    /// Right-hand polynomial.
    Right,
}

/// Exact Sylvester-resultant report for two univariate polynomials.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateResultantReport {
    /// Trimmed left polynomial coefficients in ascending power order.
    pub left_coefficients: Vec<Real>,
    /// Trimmed right polynomial coefficients in ascending power order.
    pub right_coefficients: Vec<Real>,
    /// Degree of the left polynomial after certified trimming.
    pub left_degree: usize,
    /// Degree of the right polynomial after certified trimming.
    pub right_degree: usize,
    /// Size of the square Sylvester matrix.
    pub sylvester_dimension: usize,
    /// Exact resultant value.
    pub resultant: Real,
    /// Determinant report for nonconstant/nonconstant inputs.
    pub determinant: Option<BareissDeterminantReport>,
}

/// One step in the exact pseudo-remainder chain.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateSubresultantChainStep {
    /// Dividend degree entering this step.
    pub dividend_degree: usize,
    /// Divisor degree entering this step.
    pub divisor_degree: usize,
    /// Leading coefficient of the divisor used by pseudo-division.
    pub divisor_leading_coefficient: Real,
    /// Signed pseudo-remainder coefficients in ascending power order.
    pub remainder: Vec<Real>,
    /// Degree of the signed pseudo-remainder.
    pub remainder_degree: usize,
    /// True when the chain terminated with a zero pseudo-remainder.
    pub zero_remainder: bool,
}

/// Exact pseudo-remainder chain report for two univariate polynomials.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateSubresultantChainReport {
    /// Trimmed left polynomial coefficients in ascending power order.
    pub left_coefficients: Vec<Real>,
    /// Trimmed right polynomial coefficients in ascending power order.
    pub right_coefficients: Vec<Real>,
    /// Fraction-free signed pseudo-remainder steps.
    pub steps: Vec<UnivariateSubresultantChainStep>,
    /// Last nonzero polynomial in the chain, in ascending power order.
    pub last_nonzero: Vec<Real>,
    /// Degree of the last nonzero polynomial.
    pub last_nonzero_degree: usize,
    /// True when the last nonzero polynomial is nonconstant, proving a common
    /// factor over exact arithmetic.
    pub has_nonconstant_common_factor: bool,
}

/// Input pair for batch resultant scheduling.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateResultantPairInput {
    /// Caller-supplied pair id preserved in reports.
    pub pair_index: usize,
    /// Left polynomial coefficients in ascending power order.
    pub left_coefficients: Vec<Real>,
    /// Right polynomial coefficients in ascending power order.
    pub right_coefficients: Vec<Real>,
}

/// Classification for one resultant-scheduled polynomial pair.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum UnivariateResultantPairStatus {
    /// The resultant was certified nonzero, so the two univariate polynomials
    /// are coprime over exact arithmetic.
    CertifiedCoprime,
    /// The resultant was zero and the pseudo-remainder chain ended with a
    /// nonconstant common factor.
    CertifiedCommonFactor,
    /// The resultant was zero but the chain did not expose a nonconstant
    /// common factor under this narrow report surface.
    ResultantZeroWithoutCommonFactorReport,
    /// Resultant construction failed.
    ResultantError,
    /// Subresultant-chain construction failed after a zero resultant.
    SubresultantChainError,
    /// Resultant sign could not be certified.
    UndecidedResultantSign,
}

/// Batch resultant scheduling report for one polynomial pair.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateResultantPairReport {
    /// Caller-supplied pair id.
    pub pair_index: usize,
    /// Pair classification.
    pub status: UnivariateResultantPairStatus,
    /// Resultant report when construction succeeded.
    pub resultant: Option<UnivariateResultantReport>,
    /// Subresultant-chain report when a zero resultant triggered it.
    pub subresultant_chain: Option<UnivariateSubresultantChainReport>,
    /// Resultant construction error, if any.
    pub resultant_error: Option<UnivariateResultantError>,
    /// Subresultant construction error, if any.
    pub subresultant_error: Option<UnivariateSubresultantChainError>,
}

/// Batch resultant scheduling report.
#[derive(Clone, Debug, PartialEq)]
pub struct UnivariateResultantScheduleReport {
    /// One report per input pair.
    pub pairs: Vec<UnivariateResultantPairReport>,
    /// Number of pairs certified coprime by a nonzero resultant.
    pub certified_coprime_pairs: usize,
    /// Number of pairs certified to have a nonconstant common factor.
    pub certified_common_factor_pairs: usize,
    /// Number of pairs that ended in explicit error or uncertainty.
    pub unresolved_pairs: usize,
}

impl UnivariateResultantScheduleReport {
    /// Returns true when every pair has a certified resultant classification.
    pub fn all_classified(&self) -> bool {
        self.unresolved_pairs == 0
            && self.pairs.len() == self.certified_coprime_pairs + self.certified_common_factor_pairs
    }
}

/// Computes the exact Sylvester resultant of two univariate polynomials.
///
/// Coefficients are supplied in ascending power order. Constant inputs use the
/// standard resultant convention `Res(f, c) = c^deg(f)` and
/// `Res(c, g) = c^deg(g)`, avoiding an artificial zero-size determinant. For
/// two nonconstant inputs, the Sylvester matrix is built exactly and evaluated
/// through Bareiss fraction-free elimination.
pub fn resultant_univariate_polynomials(
    left: &[Real],
    right: &[Real],
    min_precision: i32,
) -> Result<UnivariateResultantReport, UnivariateResultantError> {
    if left.is_empty() || right.is_empty() {
        return Err(UnivariateResultantError::EmptyPolynomial);
    }

    let left = trim_coefficients(left, ResultantInputSide::Left, min_precision)?;
    let right = trim_coefficients(right, ResultantInputSide::Right, min_precision)?;
    let left_degree = left.len() - 1;
    let right_degree = right.len() - 1;

    if left_degree == 0 && right_degree == 0 {
        return Ok(resultant_report(left, right, Real::one(), None));
    }
    if right_degree == 0 {
        let resultant = real_pow(&right[0], left_degree);
        return Ok(resultant_report(left, right, resultant, None));
    }
    if left_degree == 0 {
        let resultant = real_pow(&left[0], right_degree);
        return Ok(resultant_report(left, right, resultant, None));
    }

    let sylvester = sylvester_matrix(&left, &right);
    let determinant = determinant_bareiss(&sylvester, min_precision)
        .map_err(UnivariateResultantError::Determinant)?;
    Ok(resultant_report(
        left,
        right,
        determinant.determinant.clone(),
        Some(determinant),
    ))
}

/// Computes only the exact resultant value for exact-rational inputs.
///
/// Internal interpolation kernels already prove this coefficient boundary and
/// discard the public report at every sample. Borrowing the certified-trimmed
/// inputs avoids cloning two coefficient vectors merely to drop them with that
/// report. General callers should keep using [`resultant_univariate_polynomials`]
/// so unresolved coefficients retain the full predicate cascade and evidence.
pub(crate) fn resultant_exact_rational_polynomials_value(
    left: &[Real],
    right: &[Real],
    min_precision: i32,
) -> Result<Real, UnivariateResultantError> {
    if left.is_empty() || right.is_empty() {
        return Err(UnivariateResultantError::EmptyPolynomial);
    }
    let left = trim_exact_rational_coefficients(left, ResultantInputSide::Left)?;
    let right = trim_exact_rational_coefficients(right, ResultantInputSide::Right)?;
    let left_degree = left.len() - 1;
    let right_degree = right.len() - 1;

    if left_degree == 0 && right_degree == 0 {
        return Ok(Real::one());
    }
    if right_degree == 0 {
        return Ok(real_pow(&right[0], left_degree));
    }
    if left_degree == 0 {
        return Ok(real_pow(&left[0], right_degree));
    }

    // Normalize each input once, instead of clearing the same polynomial's
    // denominators independently in every Sylvester row. Restore both signed
    // contents to their resultant homogeneity powers after integer elimination.
    let integer_content = |coefficients: &[Real]| {
        let rational = coefficients
            .iter()
            .map(Real::exact_rational_ref)
            .collect::<Option<Vec<_>>>()?;
        let integers = Rational::primitive_bigint_ratio(&rational);
        let index = rational
            .iter()
            .position(|coefficient| !coefficient.is_zero())?;
        let scale = rational[index] / Rational::from_bigint(integers[index].clone());
        Some((integers, scale))
    };
    if let (Some((left_integers, left_scale)), Some((right_integers, right_scale))) =
        (integer_content(left), integer_content(right))
    {
        let dimension =
            left_degree
                .checked_add(right_degree)
                .ok_or(UnivariateResultantError::Determinant(
                    BareissError::DimensionMismatch,
                ))?;
        let entries =
            dimension
                .checked_mul(dimension)
                .ok_or(UnivariateResultantError::Determinant(
                    BareissError::DimensionMismatch,
                ))?;
        let mut sylvester = vec![BigInt::zero(); entries];
        for row in 0..right_degree {
            for (degree, coefficient) in left_integers.iter().enumerate() {
                sylvester[row * dimension + row + left_degree - degree] = coefficient.clone();
            }
        }
        for row in 0..left_degree {
            for (degree, coefficient) in right_integers.iter().enumerate() {
                sylvester[(right_degree + row) * dimension + row + right_degree - degree] =
                    coefficient.clone();
            }
        }
        if let Some(determinant) = determinant_integer_bareiss_flat(&mut sylvester, dimension) {
            return Ok(if determinant.is_zero() {
                Real::zero()
            } else {
                Real::from(Rational::from_bigint(determinant))
                    * real_pow(&Real::from(left_scale), right_degree)
                    * real_pow(&Real::from(right_scale), left_degree)
            });
        }
    }

    let sylvester = sylvester_matrix(left, right);
    determinant_bareiss(&sylvester, min_precision)
        .map(|report| report.determinant)
        .map_err(UnivariateResultantError::Determinant)
}

/// Constructs `Res_x(P(x), N(x) - y D(x))` up to one shared nonzero scale.
///
/// Multiplication by the relation in `Q[x] / (P)` has dimension `deg(P)`,
/// independent of the relation degree. Its determinant is the relation norm
/// and differs from the Sylvester resultant only by a source-leading-
/// coefficient power that is constant across `y`. Clearing all entries of the
/// two multiplication matrices with one shared scale keeps the determinant
/// polynomial integral and preserves its roots.
pub(crate) fn quotient_ring_resultant_polynomial(
    source: &[Real],
    numerator: &[Real],
    denominator: &[Real],
) -> Option<Vec<Real>> {
    let degree = source.len().checked_sub(1)?;
    if degree == 0 || numerator.is_empty() || denominator.is_empty() {
        return None;
    }
    let matrix_entries = degree.checked_mul(degree)?;
    let relation_degree = numerator.len().max(denominator.len()).checked_sub(1)?;
    let (numerator_entries, denominator_entries) =
        pseudo_quotient_multiplication_matrices(source, numerator, denominator, relation_degree)?;
    if numerator_entries.len() != matrix_entries || denominator_entries.len() != matrix_entries {
        return None;
    }

    determinant_linear_polynomial_matrix(&numerator_entries, &denominator_entries, degree).map(
        |coefficients| {
            coefficients
                .into_iter()
                .map(Rational::from_bigint)
                .map(Real::from)
                .collect()
        },
    )
}

/// Constructs the norm of a polynomial fiber over one quotient ring.
///
/// `fiber_coefficients[k]` is the source-variable polynomial multiplying the
/// `k`th power of the fiber parameter. The returned polynomial is the
/// determinant of multiplication by that complete fiber in `Q[x] / (source)`
/// and therefore has the same fiber roots as the corresponding resultant, up
/// to one nonzero constant scale. Matrix dimension is `deg(source)`; the fiber
/// degree affects only polynomial-entry multiplication, not determinant size.
pub(crate) fn quotient_ring_fiber_resultant_polynomial(
    source: &[Real],
    fiber_coefficients: &[Vec<Real>],
    max_source_degree: usize,
) -> Option<Vec<Real>> {
    let degree = source.len().checked_sub(1)?;
    // Keep the selected algebraic degree within the caller's work budget.
    // Rational fields share fraction-free integer polynomial elimination;
    // arbitrary exact coefficients retain the division-free subset fallback.
    if degree == 0 || degree > max_source_degree || fiber_coefficients.is_empty() {
        return None;
    }
    let Some(rational_coefficients) = source
        .iter()
        .chain(fiber_coefficients.iter().flatten())
        .map(Real::exact_rational_ref)
        .collect::<Option<Vec<_>>>()
    else {
        return quotient_ring_fiber_resultant_polynomial_real(source, fiber_coefficients, degree);
    };
    let mut integers = Rational::primitive_bigint_ratio(&rational_coefficients).into_iter();
    let source = integers.by_ref().take(source.len()).collect::<Vec<_>>();
    if source.len() != degree + 1 || source.last().is_none_or(BigInt::is_zero) {
        return None;
    }
    let mut relations = Vec::with_capacity(fiber_coefficients.len());
    for coefficients in fiber_coefficients {
        let mut relation = integers
            .by_ref()
            .take(coefficients.len())
            .collect::<Vec<_>>();
        if relation.is_empty() {
            relation.push(BigInt::zero());
        }
        relations.push(relation);
    }
    if integers.next().is_some() {
        return None;
    }
    let relation_degree = relations
        .iter()
        .map(|relation| relation.len().saturating_sub(1))
        .max()?;
    let matrix_entries = degree.checked_mul(degree)?;
    let mut polynomial_entries = vec![Vec::<BigInt>::new(); matrix_entries];
    for (fiber_power, relation) in relations.iter().enumerate() {
        let matrix = pseudo_quotient_multiplication_matrix(&source, relation, relation_degree)?;
        if matrix.len() != matrix_entries {
            return None;
        }
        for (entry, coefficient) in polynomial_entries.iter_mut().zip(matrix) {
            if entry.len() <= fiber_power {
                entry.resize(fiber_power + 1, BigInt::zero());
            }
            entry[fiber_power] = coefficient;
        }
    }
    let mut polynomial = determinant_integer_polynomial_matrix(&polynomial_entries, degree)?;
    while polynomial.len() > 1 && polynomial.last().is_some_and(BigInt::is_zero) {
        polynomial.pop();
    }
    let polynomial = polynomial
        .into_iter()
        .map(Rational::from_bigint)
        .map(Real::from)
        .collect::<Vec<_>>();
    primitive_integer_polynomial(&polynomial)
}

/// Exact-`Real` counterpart of the primitive-integer quotient-ring norm.
///
/// The pseudo-reduction and subset determinant use only addition,
/// subtraction, and multiplication. They therefore remain exact over the
/// full canonical scalar and need neither coefficient-field division nor a
/// primitive-element construction. The integer path above remains the hot
/// representation for rational inputs.
fn quotient_ring_fiber_resultant_polynomial_real(
    source: &[Real],
    fiber_coefficients: &[Vec<Real>],
    degree: usize,
) -> Option<Vec<Real>> {
    if source.len() != degree + 1
        || source
            .last()
            .is_none_or(|coefficient| coefficient.zero_status() == ZeroKnowledge::Zero)
    {
        return None;
    }
    let relation_degree = fiber_coefficients
        .iter()
        .map(|relation| relation.len().saturating_sub(1))
        .max()?;
    let matrix_entries = degree.checked_mul(degree)?;
    let mut polynomial_entries = vec![Vec::<Real>::new(); matrix_entries];
    for (fiber_power, relation) in fiber_coefficients.iter().enumerate() {
        let matrix = pseudo_quotient_multiplication_matrix_real(source, relation, relation_degree)?;
        if matrix.len() != matrix_entries {
            return None;
        }
        for (entry, coefficient) in polynomial_entries.iter_mut().zip(matrix) {
            if entry.len() <= fiber_power {
                entry.resize(fiber_power + 1, Real::zero());
            }
            entry[fiber_power] = coefficient;
        }
    }
    let mut polynomial = determinant_polynomial_matrix_real(&polynomial_entries, degree)?;
    while polynomial.len() > 1 && polynomial.last().is_some_and(strict_exact_zero_for_storage) {
        polynomial.pop();
    }
    Some(polynomial)
}

fn determinant_polynomial_matrix_real(
    entries: &[Vec<Real>],
    dimension: usize,
) -> Option<Vec<Real>> {
    if entries.len() != dimension.checked_mul(dimension)? {
        return None;
    }
    let state_count = 1usize.checked_shl(u32::try_from(dimension).ok()?)?;
    let mut partials = vec![None; state_count];
    partials[0] = Some(vec![Real::one()]);
    for mask in 0..state_count {
        let row = usize::try_from(mask.count_ones()).ok()?;
        if row == dimension {
            continue;
        }
        let Some(partial) = partials[mask].take() else {
            continue;
        };
        for column in 0..dimension {
            let column_bit = 1usize.checked_shl(u32::try_from(column).ok()?)?;
            if mask & column_bit != 0 {
                continue;
            }
            let entry = &entries[row * dimension + column];
            if entry
                .iter()
                .all(|coefficient| coefficient.zero_status() == ZeroKnowledge::Zero)
            {
                continue;
            }
            let sign_is_negative = (mask >> (column + 1)).count_ones() % 2 != 0;
            let next_mask = mask | column_bit;
            let next_length = partial.len().checked_add(entry.len())?.checked_sub(1)?;
            let next = partials[next_mask].get_or_insert_with(|| vec![Real::zero(); next_length]);
            if next.len() < next_length {
                next.resize(next_length, Real::zero());
            }
            for (left_power, left) in partial.iter().enumerate() {
                if left.zero_status() == ZeroKnowledge::Zero {
                    continue;
                }
                for (right_power, right) in entry.iter().enumerate() {
                    if right.zero_status() == ZeroKnowledge::Zero {
                        continue;
                    }
                    let term = left * right;
                    if sign_is_negative {
                        next[left_power + right_power] -= term;
                    } else {
                        next[left_power + right_power] += term;
                    }
                }
            }
        }
    }
    partials.pop()?.or_else(|| Some(vec![Real::zero()]))
}

fn determinant_linear_polynomial_matrix(
    constants: &[BigInt],
    negative_linear_coefficients: &[BigInt],
    dimension: usize,
) -> Option<Vec<BigInt>> {
    let entries = dimension.checked_mul(dimension)?;
    if constants.len() != entries || negative_linear_coefficients.len() != entries {
        return None;
    }
    let matrix = constants
        .iter()
        .zip(negative_linear_coefficients)
        .map(|(constant, linear)| vec![constant.clone(), -linear])
        .collect::<Vec<_>>();
    determinant_integer_polynomial_matrix(&matrix, dimension)
}

/// Ring authority for the one shared Bezout coefficient construction.
pub(crate) trait BezoutArithmetic<P>: crate::bareiss::DeterminantArithmetic<P> {
    fn subtract(&mut self, first: &P, second: &P) -> Result<P, Self::Error>;
    /// A sufficient exact zero certificate; false may mean unavailable.
    fn is_zero(&mut self, value: &P) -> Result<bool, Self::Error>;
}

/// Flat Bezout matrix in the same coefficient ring as the two polynomials.
/// Callers supply that ring's zero. Size/storage failure is not a zero matrix.
pub(crate) fn bezout_matrix_with<P: Clone, A: BezoutArithmetic<P>>(
    first: &[P],
    second: &[P],
    degree: usize,
    zero: P,
    arithmetic: &mut A,
) -> Result<Option<Vec<P>>, A::Error> {
    let Some(count) = degree.checked_add(1) else {
        return Ok(None);
    };
    if first.len() != count || second.len() != count {
        return Ok(None);
    }
    let Some(size) = degree.checked_mul(degree) else {
        return Ok(None);
    };
    let mut matrix = Vec::new();
    if matrix.try_reserve_exact(size).is_err() {
        return Ok(None);
    }
    matrix.resize(size, zero);
    for high in 1..=degree {
        for low in 0..high {
            let first_product = arithmetic.multiply(&first[high], &second[low])?;
            let second_product = arithmetic.multiply(&first[low], &second[high])?;
            let cross = arithmetic.subtract(&first_product, &second_product)?;
            // Preserve the native builder's temporary-lifetime boundary.
            drop(first_product);
            drop(second_product);
            if arithmetic.is_zero(&cross)? {
                continue;
            }
            for offset in 0..(high - low) {
                let row = high - 1 - offset;
                let column = low + offset;
                let index = row * degree + column;
                matrix[index] = arithmetic.add(&matrix[index], &cross)?;
            }
        }
    }
    Ok(Some(matrix))
}

#[cfg(test)]
fn quotient_ring_resultant_samples(
    source: &[Real],
    numerator: &[Real],
    denominator: &[Real],
) -> Option<Vec<Real>> {
    let degree = source.len().checked_sub(1)?;
    let matrix_entries = degree.checked_mul(degree)?;
    let relation_degree = numerator.len().max(denominator.len()).checked_sub(1)?;
    let (numerator_entries, denominator_entries) =
        pseudo_quotient_multiplication_matrices(source, numerator, denominator, relation_degree)?;
    let mut samples = Vec::with_capacity(degree + 1);
    let mut matrix = vec![BigInt::zero(); matrix_entries];
    for sample in 0..=degree {
        let image_value = i64::try_from(sample).ok()?;
        for ((entry, numerator), denominator) in matrix
            .iter_mut()
            .zip(&numerator_entries)
            .zip(&denominator_entries)
        {
            entry.clone_from(numerator);
            if image_value != 0 {
                *entry -= denominator * image_value;
            }
        }
        samples.push(Real::from(Rational::from_bigint(
            determinant_integer_bareiss_flat(&mut matrix, degree)?,
        )));
    }
    Some(samples)
}

fn determinant_integer_bareiss_flat(matrix: &mut [BigInt], dimension: usize) -> Option<BigInt> {
    if matrix.len() != dimension.checked_mul(dimension)? {
        return None;
    }
    if dimension == 0 {
        return Some(BigInt::one());
    }
    let mut swaps = 0;
    let mut previous_pivot = BigInt::one();
    for pivot in 0..dimension.saturating_sub(1) {
        let pivot_row = (pivot..dimension).find(|row| !matrix[row * dimension + pivot].is_zero());
        let Some(pivot_row) = pivot_row else {
            return Some(BigInt::zero());
        };
        if pivot_row != pivot {
            for column in 0..dimension {
                matrix.swap(pivot * dimension + column, pivot_row * dimension + column);
            }
            swaps += 1;
        }

        let pivot_value = matrix[pivot * dimension + pivot].clone();
        for row in (pivot + 1)..dimension {
            let eliminand = matrix[row * dimension + pivot].clone();
            for column in (pivot + 1)..dimension {
                let mut numerator = &pivot_value * &matrix[row * dimension + column];
                numerator -= &eliminand * &matrix[pivot * dimension + column];
                matrix[row * dimension + column] = if previous_pivot.is_one() {
                    numerator
                } else {
                    let (quotient, remainder) = numerator.div_rem(&previous_pivot);
                    if !remainder.is_zero() {
                        return None;
                    }
                    quotient
                };
            }
            matrix[row * dimension + pivot] = BigInt::zero();
        }
        previous_pivot = pivot_value;
    }

    let determinant = matrix[dimension * dimension - 1].clone();
    Some(if swaps % 2 == 0 {
        determinant
    } else {
        -determinant
    })
}

fn pseudo_quotient_multiplication_matrices(
    source: &[Real],
    first_relation: &[Real],
    second_relation: &[Real],
    relation_degree: usize,
) -> Option<(Vec<BigInt>, Vec<BigInt>)> {
    let source = source
        .iter()
        .map(|value| value.exact_rational_ref()?.to_big_integer())
        .collect::<Option<Vec<_>>>()?;
    let first_relation = first_relation
        .iter()
        .map(|value| value.exact_rational_ref()?.to_big_integer())
        .collect::<Option<Vec<_>>>()?;
    let second_relation = second_relation
        .iter()
        .map(|value| value.exact_rational_ref()?.to_big_integer())
        .collect::<Option<Vec<_>>>()?;
    Some((
        pseudo_quotient_multiplication_matrix(&source, &first_relation, relation_degree)?,
        pseudo_quotient_multiplication_matrix(&source, &second_relation, relation_degree)?,
    ))
}

fn pseudo_quotient_multiplication_matrix(
    source: &[BigInt],
    relation: &[BigInt],
    relation_degree: usize,
) -> Option<Vec<BigInt>> {
    let degree = source.len().checked_sub(1)?;
    let leading = source.last()?;
    if leading.is_zero() {
        return None;
    }

    let mut matrix = vec![BigInt::zero(); degree.checked_mul(degree)?];
    if relation.len() == 1 {
        let mut diagonal = relation[0].clone();
        for _ in 0..relation_degree {
            diagonal *= leading;
        }
        for index in 0..degree {
            matrix[index * degree + index] = diagonal.clone();
        }
        return Some(matrix);
    }

    let product_len = degree.checked_add(relation_degree)?;
    let mut product = vec![BigInt::zero(); product_len];
    for column in 0..degree {
        for (power, coefficient) in relation.iter().enumerate() {
            product[column + power] = coefficient.clone();
        }
        for power in (degree..product_len).rev() {
            // Stop a cancelled or exhausted scope between elimination steps.
            if crate::work_budget::exhaustion().is_some() {
                return None;
            }
            let eliminand = product[power].clone();
            let shift = power - degree;
            if !leading.is_one() {
                for coefficient in &mut product[..shift] {
                    *coefficient *= leading;
                }
            }
            for (source_power, coefficient) in source[..degree].iter().enumerate() {
                let index = shift + source_power;
                product[index] = leading * &product[index] - coefficient * &eliminand;
            }
            product[power] = BigInt::zero();
        }
        if crate::work_budget::is_active() {
            let bits = product[..degree]
                .iter()
                .map(BigInt::bits)
                .max()
                .unwrap_or(0);
            if crate::work_budget::observe_coefficient_bits(bits).is_err() {
                return None;
            }
        }
        for row in 0..degree {
            matrix[row * degree + column] = std::mem::take(&mut product[row]);
        }
    }
    Some(matrix)
}

fn pseudo_quotient_multiplication_matrix_real(
    source: &[Real],
    relation: &[Real],
    relation_degree: usize,
) -> Option<Vec<Real>> {
    let degree = source.len().checked_sub(1)?;
    let leading = source.last()?;
    if leading.zero_status() == ZeroKnowledge::Zero {
        return None;
    }

    let mut matrix = vec![Real::zero(); degree.checked_mul(degree)?];
    if relation.len() == 1 {
        let mut diagonal = relation[0].clone();
        for _ in 0..relation_degree {
            diagonal *= leading;
        }
        for index in 0..degree {
            matrix[index * degree + index] = diagonal.clone();
        }
        return Some(matrix);
    }

    let product_len = degree.checked_add(relation_degree)?;
    let mut product = vec![Real::zero(); product_len];
    for column in 0..degree {
        for (power, coefficient) in relation.iter().enumerate() {
            product[column + power] = coefficient.clone();
        }
        for power in (degree..product_len).rev() {
            // Stop a cancelled or exhausted scope between elimination steps.
            if crate::work_budget::exhaustion().is_some() {
                return None;
            }
            let eliminand = product[power].clone();
            let shift = power - degree;
            if leading != &Real::one() {
                for coefficient in &mut product[..shift] {
                    *coefficient *= leading;
                }
            }
            for (source_power, coefficient) in source[..degree].iter().enumerate() {
                let index = shift + source_power;
                product[index] = leading * &product[index] - coefficient * &eliminand;
            }
            // This coefficient cancels algebraically by construction. Publish
            // the identity rather than asking the scalar DAG to rediscover it.
            product[power] = Real::zero();
        }
        for row in 0..degree {
            matrix[row * degree + column] = std::mem::replace(&mut product[row], Real::zero());
        }
    }
    Some(matrix)
}

/// Builds an exact fraction-free pseudo-remainder chain.
///
/// The chain uses pseudo-division instead of field division, matching the
/// subresultant polynomial remainder sequence. This is
/// intentionally a report-bearing scheduling API: it gives curve and solver
/// callers exact elimination evidence without claiming to be a full
/// multivariate algebraic solver. The exact-computation boundary is
/// preserved by requiring certified coefficient trimming before any degree
/// decision is made.
pub fn subresultant_chain_univariate_polynomials(
    left: &[Real],
    right: &[Real],
    min_precision: i32,
) -> Result<UnivariateSubresultantChainReport, UnivariateSubresultantChainError> {
    if left.is_empty() || right.is_empty() {
        return Err(UnivariateSubresultantChainError::EmptyPolynomial);
    }

    let left = trim_coefficients(left, ResultantInputSide::Left, min_precision)
        .map_err(map_trim_error_to_chain)?;
    let right = trim_coefficients(right, ResultantInputSide::Right, min_precision)
        .map_err(map_trim_error_to_chain)?;

    let mut previous = left.clone();
    let mut current = right.clone();
    if degree(&previous) < degree(&current) {
        std::mem::swap(&mut previous, &mut current);
    }

    let mut steps = Vec::new();
    while !is_zero_polynomial(&current, min_precision).map_err(|(side, index)| {
        UnivariateSubresultantChainError::UndecidedCoefficient { side, index }
    })? && degree(&current) > 0
    {
        let divisor_leading_coefficient = current[current.len() - 1].clone();
        let remainder = pseudo_remainder(&previous, &current, min_precision)?;
        let zero_remainder =
            is_zero_polynomial(&remainder, min_precision).map_err(|(side, index)| {
                UnivariateSubresultantChainError::UndecidedCoefficient { side, index }
            })?;
        let signed_remainder = if zero_remainder {
            vec![Real::zero()]
        } else {
            remainder
                .into_iter()
                .map(|value| -value)
                .collect::<Vec<_>>()
        };
        let remainder_degree = degree(&signed_remainder);
        steps.push(UnivariateSubresultantChainStep {
            dividend_degree: degree(&previous),
            divisor_degree: degree(&current),
            divisor_leading_coefficient,
            remainder: signed_remainder.clone(),
            remainder_degree,
            zero_remainder,
        });

        if zero_remainder {
            break;
        }
        previous = current;
        current = signed_remainder;
    }

    let last_nonzero = if is_zero_polynomial(&current, min_precision).map_err(|(side, index)| {
        UnivariateSubresultantChainError::UndecidedCoefficient { side, index }
    })? {
        previous
    } else {
        current
    };
    let last_nonzero_degree = degree(&last_nonzero);

    Ok(UnivariateSubresultantChainReport {
        left_coefficients: left,
        right_coefficients: right,
        steps,
        last_nonzero,
        last_nonzero_degree,
        has_nonconstant_common_factor: last_nonzero_degree > 0,
    })
}

/// Schedule exact univariate resultant checks for many polynomial pairs.
///
/// This is the generic hypersolve side of curve-pair elimination scheduling:
/// curve crates own span construction and topology, then pass univariate
/// coefficient pairs here for exact algebraic filtering. Each pair first runs
/// the Sylvester resultant; zero resultants then run the fraction-free
/// pseudo-remainder chain. Exact reports, rather than sampled approximations,
/// drive every branching decision.
pub fn schedule_univariate_resultant_pairs(
    pairs: &[UnivariateResultantPairInput],
    min_precision: i32,
) -> UnivariateResultantScheduleReport {
    let reports = pairs
        .iter()
        .map(|pair| schedule_one_resultant_pair(pair, min_precision))
        .collect::<Vec<_>>();
    let certified_coprime_pairs = reports
        .iter()
        .filter(|pair| pair.status == UnivariateResultantPairStatus::CertifiedCoprime)
        .count();
    let certified_common_factor_pairs = reports
        .iter()
        .filter(|pair| pair.status == UnivariateResultantPairStatus::CertifiedCommonFactor)
        .count();
    let unresolved_pairs = reports.len() - certified_coprime_pairs - certified_common_factor_pairs;

    UnivariateResultantScheduleReport {
        pairs: reports,
        certified_coprime_pairs,
        certified_common_factor_pairs,
        unresolved_pairs,
    }
}

fn resultant_report(
    left_coefficients: Vec<Real>,
    right_coefficients: Vec<Real>,
    resultant: Real,
    determinant: Option<BareissDeterminantReport>,
) -> UnivariateResultantReport {
    let left_degree = left_coefficients.len() - 1;
    let right_degree = right_coefficients.len() - 1;
    UnivariateResultantReport {
        left_coefficients,
        right_coefficients,
        left_degree,
        right_degree,
        sylvester_dimension: left_degree + right_degree,
        resultant,
        determinant,
    }
}

fn schedule_one_resultant_pair(
    pair: &UnivariateResultantPairInput,
    min_precision: i32,
) -> UnivariateResultantPairReport {
    let resultant = match resultant_univariate_polynomials(
        &pair.left_coefficients,
        &pair.right_coefficients,
        min_precision,
    ) {
        Ok(resultant) => resultant,
        Err(error) => {
            return UnivariateResultantPairReport {
                pair_index: pair.pair_index,
                status: UnivariateResultantPairStatus::ResultantError,
                resultant: None,
                subresultant_chain: None,
                resultant_error: Some(error),
                subresultant_error: None,
            };
        }
    };

    let resultant_sign = match resultant.resultant.certified_sign_until(min_precision) {
        CertifiedRealSign::Known { sign, .. } => sign,
        CertifiedRealSign::Unknown { .. } => {
            let Some(sign) =
                crate::policy_division::strict_sign_after_refinement_failure(&resultant.resultant)
            else {
                return UnivariateResultantPairReport {
                    pair_index: pair.pair_index,
                    status: UnivariateResultantPairStatus::UndecidedResultantSign,
                    resultant: Some(resultant),
                    subresultant_chain: None,
                    resultant_error: None,
                    subresultant_error: None,
                };
            };
            sign
        }
    };
    if !matches!(resultant_sign, RealSign::Zero) {
        return UnivariateResultantPairReport {
            pair_index: pair.pair_index,
            status: UnivariateResultantPairStatus::CertifiedCoprime,
            resultant: Some(resultant),
            subresultant_chain: None,
            resultant_error: None,
            subresultant_error: None,
        };
    }

    let chain = match subresultant_chain_univariate_polynomials(
        &pair.left_coefficients,
        &pair.right_coefficients,
        min_precision,
    ) {
        Ok(chain) => chain,
        Err(error) => {
            return UnivariateResultantPairReport {
                pair_index: pair.pair_index,
                status: UnivariateResultantPairStatus::SubresultantChainError,
                resultant: Some(resultant),
                subresultant_chain: None,
                resultant_error: None,
                subresultant_error: Some(error),
            };
        }
    };
    let status = if chain.has_nonconstant_common_factor {
        UnivariateResultantPairStatus::CertifiedCommonFactor
    } else {
        UnivariateResultantPairStatus::ResultantZeroWithoutCommonFactorReport
    };

    UnivariateResultantPairReport {
        pair_index: pair.pair_index,
        status,
        resultant: Some(resultant),
        subresultant_chain: Some(chain),
        resultant_error: None,
        subresultant_error: None,
    }
}

#[inline]
fn trim_coefficients(
    coefficients: &[Real],
    side: ResultantInputSide,
    min_precision: i32,
) -> Result<Vec<Real>, UnivariateResultantError> {
    let mut last_nonzero = None;
    for (index, coefficient) in coefficients.iter().enumerate().rev() {
        match coefficient.certified_sign_until(min_precision) {
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            } => {}
            CertifiedRealSign::Known { .. } => {
                last_nonzero = Some(index);
                break;
            }
            CertifiedRealSign::Unknown { .. } => {
                return trim_coefficients_strict_fallback(coefficients, side, index, min_precision);
            }
        }
    }

    let Some(last_nonzero) = last_nonzero else {
        return Ok(vec![Real::zero()]);
    };
    Ok(coefficients[..=last_nonzero].to_vec())
}

fn trim_exact_rational_coefficients(
    coefficients: &[Real],
    side: ResultantInputSide,
) -> Result<&[Real], UnivariateResultantError> {
    for (index, coefficient) in coefficients.iter().enumerate().rev() {
        let Some(coefficient) = coefficient.exact_rational_ref() else {
            return Err(UnivariateResultantError::UndecidedCoefficient { side, index });
        };
        if !coefficient.is_zero() {
            return Ok(&coefficients[..=index]);
        }
    }
    Ok(&coefficients[..1])
}

#[cold]
fn trim_coefficients_strict_fallback(
    coefficients: &[Real],
    side: ResultantInputSide,
    start: usize,
    min_precision: i32,
) -> Result<Vec<Real>, UnivariateResultantError> {
    for (index, coefficient) in coefficients[..=start].iter().enumerate().rev() {
        match crate::policy_division::strict_sign_after_refinement(coefficient, min_precision) {
            Some(RealSign::Zero) => {}
            Some(RealSign::Negative | RealSign::Positive) => {
                return Ok(coefficients[..=index].to_vec());
            }
            None => {
                return Err(UnivariateResultantError::UndecidedCoefficient { side, index });
            }
        }
    }
    Ok(vec![Real::zero()])
}

fn map_trim_error_to_chain(error: UnivariateResultantError) -> UnivariateSubresultantChainError {
    match error {
        UnivariateResultantError::EmptyPolynomial => {
            UnivariateSubresultantChainError::EmptyPolynomial
        }
        UnivariateResultantError::UndecidedCoefficient { side, index } => {
            UnivariateSubresultantChainError::UndecidedCoefficient { side, index }
        }
        UnivariateResultantError::Determinant(_) => {
            unreachable!("trimming does not compute determinants")
        }
    }
}

fn pseudo_remainder(
    dividend: &[Real],
    divisor: &[Real],
    min_precision: i32,
) -> Result<Vec<Real>, UnivariateSubresultantChainError> {
    let mut remainder = dividend.to_vec();
    let divisor_degree = degree(divisor);
    let divisor_leading = divisor[divisor_degree].clone();

    while degree(&remainder) >= divisor_degree
        && !is_zero_polynomial(&remainder, min_precision).map_err(|(side, index)| {
            UnivariateSubresultantChainError::UndecidedCoefficient { side, index }
        })?
    {
        let remainder_degree = degree(&remainder);
        let shift = remainder_degree - divisor_degree;
        let remainder_leading = remainder[remainder_degree].clone();
        let mut next = remainder
            .iter()
            .map(|coefficient| divisor_leading.clone() * coefficient.clone())
            .collect::<Vec<_>>();
        for (index, coefficient) in divisor.iter().enumerate() {
            let target = index + shift;
            next[target] = next[target].clone() - remainder_leading.clone() * coefficient.clone();
        }
        remainder = trim_coefficients(&next, ResultantInputSide::Left, min_precision)
            .map_err(map_trim_error_to_chain)?;
    }

    Ok(remainder)
}

fn degree(polynomial: &[Real]) -> usize {
    polynomial.len().saturating_sub(1)
}

#[inline]
fn is_zero_polynomial(
    polynomial: &[Real],
    min_precision: i32,
) -> Result<bool, (ResultantInputSide, usize)> {
    for (index, coefficient) in polynomial.iter().enumerate() {
        match coefficient.certified_sign_until(min_precision) {
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            } => {}
            CertifiedRealSign::Known { .. } => return Ok(false),
            CertifiedRealSign::Unknown { .. } => {
                return is_zero_polynomial_strict_fallback(polynomial, index, min_precision);
            }
        }
    }
    Ok(true)
}

#[cold]
fn is_zero_polynomial_strict_fallback(
    polynomial: &[Real],
    start: usize,
    min_precision: i32,
) -> Result<bool, (ResultantInputSide, usize)> {
    // A nonzero structural fact anywhere already disproves polynomial zero.
    // Check from the leading end, where normalized polynomial callers retain
    // their degree witness, before spending effort on unresolved lower terms.
    // This is only a sufficient test; the full three-valued scan remains below.
    if polynomial[start..]
        .iter()
        .rev()
        .any(|coefficient| coefficient.zero_status() == ZeroKnowledge::NonZero)
    {
        return Ok(false);
    }
    let mut first_undecided = None;
    for (offset, coefficient) in polynomial[start..].iter().enumerate() {
        let index = start + offset;
        match crate::policy_division::strict_sign_after_refinement(coefficient, min_precision) {
            Some(RealSign::Zero) => {}
            Some(RealSign::Negative | RealSign::Positive) => return Ok(false),
            None => {
                first_undecided.get_or_insert(index);
            }
        }
    }
    // One known nonzero coefficient disproves polynomial zero even if an
    // earlier coefficient is unresolved. Otherwise retain the first blocker.
    match first_undecided {
        Some(index) => Err((ResultantInputSide::Left, index)),
        None => Ok(true),
    }
}

pub(crate) fn sylvester_matrix(left: &[Real], right: &[Real]) -> Vec<Vec<Real>> {
    let left_degree = left.len() - 1;
    let right_degree = right.len() - 1;
    let dimension = left_degree + right_degree;
    let mut matrix = vec![vec![Real::zero(); dimension]; dimension];

    for row in 0..right_degree {
        for (degree, coefficient) in left.iter().enumerate() {
            matrix[row][row + left_degree - degree] = coefficient.clone();
        }
    }
    for row in 0..left_degree {
        for (degree, coefficient) in right.iter().enumerate() {
            matrix[right_degree + row][row + right_degree - degree] = coefficient.clone();
        }
    }

    matrix
}

fn real_pow(value: &Real, exponent: usize) -> Real {
    let mut result = Real::one();
    let mut base = value.clone();
    let mut remaining = exponent;
    while remaining > 0 {
        if remaining & 1 == 1 {
            result *= base.clone();
        }
        remaining >>= 1;
        if remaining > 0 {
            base = base.clone() * base;
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use proptest::prelude::*;

    use super::*;

    fn real(value: i64) -> Real {
        Real::from(value)
    }

    fn unresolved_zero_coefficient() -> Real {
        let value = (real(1) + real(2).sqrt().unwrap()).ln().unwrap() * real(2)
            - (real(3) + real(2) * real(2).sqrt().unwrap()).ln().unwrap();
        assert_eq!(
            crate::policy_division::strict_sign_after_refinement(&value, -64),
            None
        );
        value
    }

    #[test]
    fn polynomial_zero_truth_lets_nonzero_dominate_unknown() {
        let unknown = unresolved_zero_coefficient();
        for code in 0..256 {
            let mut digits = code;
            let mut polynomial = Vec::new();
            let mut first_unknown = None;
            let mut any_nonzero = false;
            for index in 0..4 {
                let digit = digits % 4;
                digits /= 4;
                polynomial.push(match digit {
                    0 => Real::zero(),
                    1 => {
                        any_nonzero = true;
                        Real::one()
                    }
                    2 => {
                        any_nonzero = true;
                        -Real::one()
                    }
                    _ => {
                        first_unknown.get_or_insert(index);
                        unknown.clone()
                    }
                });
            }
            let expected = if any_nonzero {
                Ok(false)
            } else if let Some(index) = first_unknown {
                Err((ResultantInputSide::Left, index))
            } else {
                Ok(true)
            };
            assert_eq!(
                is_zero_polynomial(&polynomial, -64),
                expected,
                "code {code}"
            );
        }
        assert_eq!(is_zero_polynomial(&[], -64), Ok(true));
    }

    #[test]
    fn subresultant_chain_keeps_unknown_lower_coefficients() {
        let unknown = unresolved_zero_coefficient();
        let polynomial = [unknown, Real::one()];
        let self_chain = subresultant_chain_univariate_polynomials(&polynomial, &polynomial, -64)
            .expect("a known leading one makes the polynomial nonzero");
        assert_eq!(self_chain.last_nonzero_degree, 1);
        assert!(self_chain.has_nonconstant_common_factor);
        assert_eq!(self_chain.steps.len(), 1);
        assert!(self_chain.steps[0].zero_remainder);
        let shifted = [polynomial[0].clone() + Real::one(), Real::one()];
        let coprime = subresultant_chain_univariate_polynomials(&polynomial, &shifted, -64)
            .expect("a constant-one difference certifies coprimality");
        assert_eq!(coprime.last_nonzero_degree, 0);
        assert!(!coprime.has_nonconstant_common_factor);
    }

    #[test]
    fn subresultant_chain_still_rejects_unknown_leading_degree() {
        let polynomial = [Real::one(), unresolved_zero_coefficient()];
        assert_eq!(
            subresultant_chain_univariate_polynomials(&polynomial, &polynomial, -64).unwrap_err(),
            UnivariateSubresultantChainError::UndecidedCoefficient {
                side: ResultantInputSide::Left,
                index: 1,
            }
        );
    }

    #[test]
    fn resultant_reports_common_linear_root_as_zero() {
        let report = resultant_univariate_polynomials(
            &[real(-1), real(1)],
            &[real(-1), real(0), real(1)],
            -64,
        )
        .unwrap();

        assert_eq!(report.left_degree, 1);
        assert_eq!(report.right_degree, 2);
        assert_eq!(report.sylvester_dimension, 3);
        assert_eq!(report.resultant, Real::zero());
        assert!(report.determinant.is_some());
    }

    #[test]
    fn resultant_of_linear_polynomials_is_exact_difference() {
        let report =
            resultant_univariate_polynomials(&[real(-2), real(1)], &[real(-5), real(1)], -64)
                .unwrap();

        assert_eq!(report.resultant, real(-3));
    }

    #[test]
    fn scalar_resultant_preserves_exact_fractional_scale() {
        let fraction = |numerator, denominator| {
            Real::from(Rational::fraction(numerator, denominator).unwrap())
        };
        let left = [fraction(1, 2), Real::one()];
        let right = [fraction(1, 3), Real::one()];
        let expected = resultant_univariate_polynomials(&left, &right, -64)
            .unwrap()
            .resultant;

        assert_eq!(
            resultant_exact_rational_polynomials_value(&left, &right, -64),
            Ok(expected)
        );
    }

    #[test]
    fn scalar_integer_resultant_matches_full_report_at_binary_dimension_limit() {
        let mut degree_nine = vec![Real::zero(); 10];
        degree_nine[0] = real(-2);
        degree_nine[9] = Real::one();
        let linear = [real(-3), Real::one()];
        let expected = resultant_univariate_polynomials(&degree_nine, &linear, -64)
            .unwrap()
            .resultant;

        assert_eq!(
            resultant_exact_rational_polynomials_value(&degree_nine, &linear, -64),
            Ok(expected)
        );
    }

    #[test]
    fn quotient_ring_samples_match_sylvester_resultants_up_to_one_scale() {
        let source = [real(2), real(-3), Real::zero(), real(2)];
        let numerator = [real(1), real(2), real(3)];
        let denominator = [real(2), real(-1)];
        let quotient_samples =
            quotient_ring_resultant_samples(&source, &numerator, &denominator).unwrap();
        let quotient_polynomial =
            quotient_ring_resultant_polynomial(&source, &numerator, &denominator).unwrap();
        let polynomial_samples = (0..source.len())
            .map(|sample| {
                let image = real(i64::try_from(sample).unwrap());
                quotient_polynomial
                    .iter()
                    .rev()
                    .fold(Real::zero(), |value, coefficient| {
                        value * image.clone() + coefficient.clone()
                    })
            })
            .collect::<Vec<_>>();
        assert_eq!(polynomial_samples, quotient_samples);
        let sylvester_samples = (0..source.len())
            .map(|sample| {
                let image = real(i64::try_from(sample).unwrap());
                let mut relation = numerator.to_vec();
                for (coefficient, denominator_coefficient) in relation.iter_mut().zip(&denominator)
                {
                    *coefficient =
                        coefficient.clone() - denominator_coefficient.clone() * image.clone();
                }
                resultant_univariate_polynomials(&source, &relation, -64)
                    .unwrap()
                    .resultant
            })
            .collect::<Vec<_>>();
        let pivot = quotient_samples
            .iter()
            .zip(&sylvester_samples)
            .position(|(quotient, sylvester)| {
                quotient != &Real::zero() && sylvester != &Real::zero()
            })
            .unwrap();

        for (quotient, sylvester) in quotient_samples.iter().zip(&sylvester_samples) {
            assert_eq!(
                quotient.clone() * sylvester_samples[pivot].clone(),
                sylvester.clone() * quotient_samples[pivot].clone()
            );
        }
    }

    #[test]
    fn constant_quotient_relation_retains_padded_pseudo_scale() {
        let source = [2, -3, 0, 2].map(BigInt::from);
        let relation = [BigInt::from(3)];

        assert_eq!(
            pseudo_quotient_multiplication_matrix(&source, &relation, 2),
            Some(vec![
                BigInt::from(12),
                BigInt::zero(),
                BigInt::zero(),
                BigInt::zero(),
                BigInt::from(12),
                BigInt::zero(),
                BigInt::zero(),
                BigInt::zero(),
                BigInt::from(12),
            ])
        );
    }

    #[test]
    fn flat_integer_bareiss_matches_reported_determinants() {
        let cases = [
            (0, vec![]),
            (1, vec![5]),
            (2, vec![0, 2, 3, 4]),
            (2, vec![1, 2, 2, 4]),
            (3, vec![2, -1, 3, 4, 0, 1, -2, 5, 2]),
        ];
        for (dimension, entries) in cases {
            let mut flat = entries
                .iter()
                .copied()
                .map(BigInt::from)
                .collect::<Vec<_>>();
            let matrix = entries
                .chunks(dimension.max(1))
                .map(|row| row.iter().copied().map(real).collect::<Vec<_>>())
                .collect::<Vec<_>>();
            let expected = determinant_bareiss(&matrix, -64).unwrap().determinant;

            assert_eq!(
                determinant_integer_bareiss_flat(&mut flat, dimension)
                    .map(Rational::from_bigint)
                    .map(Real::from),
                Some(expected)
            );
        }
        let mut wrong_size = vec![BigInt::one()];
        assert_eq!(determinant_integer_bareiss_flat(&mut wrong_size, 2), None);
    }

    #[test]
    fn resultant_validates_empty_and_zero_polynomials() {
        assert_eq!(
            resultant_univariate_polynomials(&[], &[real(1)], -64).unwrap_err(),
            UnivariateResultantError::EmptyPolynomial
        );

        let report =
            resultant_univariate_polynomials(&[Real::zero()], &[real(-3), real(1)], -64).unwrap();
        assert_eq!(report.left_degree, 0);
        assert_eq!(report.resultant, Real::zero());
        assert!(report.determinant.is_none());
    }

    #[test]
    fn resultant_trimming_uses_strict_exact_signs_without_guessing() {
        let positive = crate::test_support::exact_normal_positive();
        let report =
            resultant_univariate_polynomials(&[real(1), positive], &[real(2)], -64).unwrap();
        assert_eq!(report.left_degree, 1);
        assert_eq!(report.resultant, real(2));

        let normalized_zero =
            real(2).powi_i64(-3000).unwrap() - crate::test_support::exact_normal_positive();
        let report = resultant_univariate_polynomials(
            &[real(-1), real(1), normalized_zero],
            &[real(-2), real(1)],
            -64,
        )
        .unwrap();
        assert_eq!(report.left_degree, 1);
        assert_eq!(report.resultant, real(-1));

        assert_eq!(
            resultant_univariate_polynomials(
                &[real(-1), real(1), crate::test_support::terminal_zero()],
                &[real(-2), real(1)],
                -64,
            )
            .unwrap_err(),
            UnivariateResultantError::UndecidedCoefficient {
                side: ResultantInputSide::Left,
                index: 2,
            }
        );
    }

    #[test]
    fn subresultant_and_scheduler_complete_strict_exact_boundaries() {
        let normalized_zero =
            real(2).powi_i64(-3000).unwrap() - crate::test_support::exact_normal_positive();
        let chain = subresultant_chain_univariate_polynomials(
            &[real(-1), real(1)],
            &[real(-1) + normalized_zero, real(1)],
            -64,
        )
        .unwrap();
        assert!(chain.has_nonconstant_common_factor);
        assert!(chain.steps.last().is_some_and(|step| step.zero_remainder));

        let root = real(2).sqrt().unwrap();
        let shifted = root.clone() + crate::test_support::exact_normal_positive();
        let pair = UnivariateResultantPairInput {
            pair_index: 0,
            left_coefficients: vec![-root.clone(), real(1)],
            right_coefficients: vec![-shifted, real(1)],
        };
        let resultant = resultant_univariate_polynomials(
            &pair.left_coefficients,
            &pair.right_coefficients,
            -64,
        )
        .unwrap();
        assert_eq!(
            resultant.resultant.exact_rational_normal_form(),
            (-real(2).powi_i64(-3000).unwrap()).exact_rational(),
        );
        let report = schedule_univariate_resultant_pairs(&[pair], -64);
        assert_eq!(
            report.pairs[0].status,
            UnivariateResultantPairStatus::CertifiedCoprime
        );

        let unsupported_shifted = root.clone() + crate::test_support::terminal_zero();
        let report = schedule_univariate_resultant_pairs(
            &[UnivariateResultantPairInput {
                pair_index: 1,
                left_coefficients: vec![-root, real(1)],
                right_coefficients: vec![-unsupported_shifted, real(1)],
            }],
            -64,
        );
        assert_eq!(
            report.pairs[0].status,
            UnivariateResultantPairStatus::UndecidedResultantSign
        );
    }

    #[test]
    fn constant_resultant_uses_exact_binary_power_for_high_degree() {
        let mut polynomial = vec![Real::zero(); 65];
        polynomial[0] = real(-1);
        polynomial[64] = Real::one();
        let report = resultant_univariate_polynomials(&polynomial, &[real(2)], -64).unwrap();
        let expected = (0..64).fold(Real::one(), |value, _| value * real(2));

        assert_eq!(report.resultant, expected);
        assert_eq!(report.left_degree, 64);
        assert!(report.determinant.is_none());
    }

    #[test]
    fn subresultant_chain_reports_common_factor() {
        let report = subresultant_chain_univariate_polynomials(
            &[real(2), real(-3), real(1)],
            &[real(-1), real(1)],
            -64,
        )
        .unwrap();

        assert!(report.has_nonconstant_common_factor);
        assert_eq!(report.last_nonzero_degree, 1);
        assert_eq!(report.last_nonzero, vec![real(-1), real(1)]);
        assert!(report.steps.last().unwrap().zero_remainder);
    }

    #[test]
    fn subresultant_chain_reports_coprime_linear_inputs() {
        let report = subresultant_chain_univariate_polynomials(
            &[real(-2), real(1)],
            &[real(-5), real(1)],
            -64,
        )
        .unwrap();

        assert!(!report.has_nonconstant_common_factor);
        assert_eq!(report.last_nonzero_degree, 0);
        assert_eq!(report.last_nonzero, vec![real(-3)]);
    }

    #[test]
    fn resultant_schedule_classifies_coprime_common_and_bad_pairs() {
        let report = schedule_univariate_resultant_pairs(
            &[
                UnivariateResultantPairInput {
                    pair_index: 10,
                    left_coefficients: vec![real(-1), real(1)],
                    right_coefficients: vec![real(-2), real(1)],
                },
                UnivariateResultantPairInput {
                    pair_index: 11,
                    left_coefficients: vec![real(-1), real(1)],
                    right_coefficients: vec![real(-1), Real::zero(), Real::one()],
                },
                UnivariateResultantPairInput {
                    pair_index: 12,
                    left_coefficients: Vec::new(),
                    right_coefficients: vec![real(1)],
                },
            ],
            -64,
        );

        assert_eq!(report.pairs.len(), 3);
        assert_eq!(report.certified_coprime_pairs, 1);
        assert_eq!(report.certified_common_factor_pairs, 1);
        assert_eq!(report.unresolved_pairs, 1);
        assert_eq!(report.pairs[0].pair_index, 10);
        assert_eq!(
            report.pairs[0].status,
            UnivariateResultantPairStatus::CertifiedCoprime
        );
        assert_eq!(
            report.pairs[1].status,
            UnivariateResultantPairStatus::CertifiedCommonFactor
        );
        assert_eq!(
            report.pairs[2].status,
            UnivariateResultantPairStatus::ResultantError
        );
        assert!(report.pairs[1].subresultant_chain.is_some());
        assert!(report.pairs[2].resultant_error.is_some());
    }

    proptest! {
        #[test]
        fn generated_exact_rational_scalar_resultants_match_full_reports(
            left in prop::collection::vec((-4_i16..=4, 1_u16..=11), 1..=4),
            right in prop::collection::vec((-4_i16..=4, 1_u16..=11), 1..=4),
        ) {
            let left = left
                .into_iter()
                .map(|(numerator, denominator)| Real::from(Rational::fraction(i64::from(numerator), u64::from(denominator)).unwrap()))
                .collect::<Vec<_>>();
            let right = right
                .into_iter()
                .map(|(numerator, denominator)| Real::from(Rational::fraction(i64::from(numerator), u64::from(denominator)).unwrap()))
                .collect::<Vec<_>>();
            let expected = resultant_univariate_polynomials(&left, &right, -64)
                .unwrap()
                .resultant;

            prop_assert!(
                resultant_exact_rational_polynomials_value(&left, &right, -64) == Ok(expected)
            );
        }

        #[test]
        fn generated_flat_integer_bareiss_matches_reported_four_by_four(
            entries in prop::collection::vec(-8_i16..=8, 16),
        ) {
            let mut flat = entries
                .iter()
                .copied()
                .map(|value| BigInt::from(i64::from(value)))
                .collect::<Vec<_>>();
            let matrix = entries
                .as_chunks::<4>()
                .0
                .iter()
                .map(|row| {
                    row.iter()
                        .copied()
                        .map(|value| real(i64::from(value)))
                        .collect::<Vec<_>>()
                })
                .collect::<Vec<_>>();
            let expected = determinant_bareiss(&matrix, -64).unwrap().determinant;

            prop_assert_eq!(
                determinant_integer_bareiss_flat(&mut flat, 4)
                    .map(Rational::from_bigint)
                    .map(Real::from),
                Some(expected)
            );
        }

        #[test]
        fn generated_monic_quotient_ring_samples_match_sylvester_up_to_scale(
            source_constant in -4_i16..=4,
            source_linear in -4_i16..=4,
            source_quadratic in -4_i16..=4,
            numerator_constant in -4_i16..=4,
            numerator_linear in -4_i16..=4,
            numerator_quadratic in 1_i16..=4,
            denominator_linear in -4_i16..=4,
        ) {
            let source = [
                real(i64::from(source_constant)),
                real(i64::from(source_linear)),
                real(i64::from(source_quadratic)),
                Real::one(),
            ];
            let numerator = [
                real(i64::from(numerator_constant)),
                real(i64::from(numerator_linear)),
                real(i64::from(numerator_quadratic)),
            ];
            let denominator = [Real::one(), real(i64::from(denominator_linear))];
            let samples =
                quotient_ring_resultant_samples(&source, &numerator, &denominator).unwrap();
            let polynomial =
                quotient_ring_resultant_polynomial(&source, &numerator, &denominator).unwrap();
            let polynomial_samples = (0..source.len())
                .map(|sample| {
                    let image = real(i64::try_from(sample).unwrap());
                    polynomial
                        .iter()
                        .rev()
                        .fold(Real::zero(), |value, coefficient| {
                            value * image.clone() + coefficient.clone()
                        })
                })
                .collect::<Vec<_>>();
            prop_assert_eq!(&polynomial_samples, &samples);

            let sylvester_samples = (0..source.len())
                .map(|sample| {
                    let image = real(i64::try_from(sample).unwrap());
                    let mut relation = numerator.to_vec();
                    for (coefficient, denominator_coefficient) in
                        relation.iter_mut().zip(&denominator)
                    {
                        *coefficient =
                            coefficient.clone() - denominator_coefficient.clone() * image.clone();
                    }
                    resultant_univariate_polynomials(&source, &relation, -64)
                        .unwrap()
                        .resultant
                })
                .collect::<Vec<_>>();
            let pivot = samples
                .iter()
                .zip(&sylvester_samples)
                .position(|(quotient, sylvester)| {
                    quotient != &Real::zero() && sylvester != &Real::zero()
                });

            if let Some(pivot) = pivot {
                for (quotient, sylvester) in samples.iter().zip(&sylvester_samples) {
                    prop_assert_eq!(
                        quotient.clone() * sylvester_samples[pivot].clone(),
                        sylvester.clone() * samples[pivot].clone()
                    );
                }
            } else {
                prop_assert!(samples.iter().all(|sample| sample == &Real::zero()));
                prop_assert!(
                    sylvester_samples
                        .iter()
                        .all(|sample| sample == &Real::zero())
                );
            }
        }

        #[test]
        fn generated_linear_resultants_match_root_difference(
            left_root in -64_i16..=64,
            right_root in -64_i16..=64,
        ) {
            let left_root = i64::from(left_root);
            let right_root = i64::from(right_root);
            let report = resultant_univariate_polynomials(
                &[real(-left_root), real(1)],
                &[real(-right_root), real(1)],
                -64,
            ).unwrap();

            prop_assert_eq!(report.resultant, real(left_root - right_root));
        }

        #[test]
        fn generated_common_linear_factor_resultant_is_zero(
            shared_root in -32_i16..=32,
            other_root in -32_i16..=32,
        ) {
            let shared_root = i64::from(shared_root);
            let other_root = i64::from(other_root);
            let quadratic = vec![
                real(shared_root * other_root),
                real(-(shared_root + other_root)),
                real(1),
            ];
            let report = resultant_univariate_polynomials(
                &[real(-shared_root), real(1)],
                &quadratic,
                -64,
            ).unwrap();

            prop_assert_eq!(report.resultant, Real::zero());
        }

        #[test]
        fn generated_subresultant_chain_detects_common_linear_factor(
            shared_root in -32_i16..=32,
            other_root in -32_i16..=32,
        ) {
            let shared_root = i64::from(shared_root);
            let other_root = i64::from(other_root);
            let quadratic = vec![
                real(shared_root * other_root),
                real(-(shared_root + other_root)),
                real(1),
            ];
            let report = subresultant_chain_univariate_polynomials(
                &quadratic,
                &[real(-shared_root), real(1)],
                -64,
            ).unwrap();

            prop_assert!(report.has_nonconstant_common_factor);
            prop_assert_eq!(report.last_nonzero_degree, 1);
        }

        #[test]
        fn generated_resultant_schedule_classifies_linear_pairs(
            left_root in -32_i16..=32,
            right_root in -32_i16..=32,
        ) {
            let left_root = i64::from(left_root);
            let right_root = i64::from(right_root);
            let report = schedule_univariate_resultant_pairs(
                &[UnivariateResultantPairInput {
                    pair_index: 0,
                    left_coefficients: vec![real(-left_root), real(1)],
                    right_coefficients: vec![real(-right_root), real(1)],
                }],
                -64,
            );

            if left_root == right_root {
                prop_assert_eq!(
                    &report.pairs[0].status,
                    &UnivariateResultantPairStatus::CertifiedCommonFactor
                );
                prop_assert_eq!(report.certified_common_factor_pairs, 1);
            } else {
                prop_assert_eq!(
                    &report.pairs[0].status,
                    &UnivariateResultantPairStatus::CertifiedCoprime
                );
                prop_assert_eq!(report.certified_coprime_pairs, 1);
            }
            prop_assert!(report.all_classified());
        }
    }
}
