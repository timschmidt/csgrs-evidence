//! Iterative constraint solving experiments built on `hyperreal`.
//!
//! Its public seams include symbolic expressions with variable leaves,
//! residual evaluation, a linear-solver facade, a predicate/classification
//! facade, and a small iterative solver skeleton.

pub mod active_set;
pub mod affine;
pub mod algebraic;
pub mod algebraic_binary;
pub mod algebraic_fiber;
pub mod algebraic_mobius;
pub mod algebraic_polynomial_image;
pub mod algebraic_rational_image;
pub mod algebraic_sqrt;
pub mod algebraic_tensor_image;
pub mod alpha;
pub mod analysis;
pub mod bareiss;
pub mod batch;
pub mod bivariate_arithmetic;
pub mod bivariate_components;
pub mod bivariate_topology;
pub mod branches;
pub mod certification;
pub mod classification;
pub mod curve_resultant;
pub mod curve_substitution;
pub mod diagnostics;
pub mod direct;
pub mod domain;
pub mod domain_certification;
pub mod eval;
pub mod exact_factor;
#[cfg(feature = "expression-program")]
pub mod expression_program;
pub mod failed_constraints;
mod integer_interpolation;
pub mod interval;
pub mod jacobian;
pub mod linalg;
pub mod model;
pub mod modular_gcd;
pub mod ordered_field_resultant;
pub mod ordered_field_roots;
mod policy_division;
pub mod polynomial;
pub mod predicates;
pub mod quotient_ring;
pub mod radical_expression;
pub mod rank;
pub mod real_interval;
pub mod recursive_quadratic_field;
pub mod represented_root;
pub mod residual_replay;
pub mod resultant;
pub mod root_isolation;
mod root_sign;
pub mod selected_polynomial_field;
pub mod simplex_projection;
pub mod sketch;
mod sketch_arc_incidence;
mod sketch_arc_length;
mod sketch_arc_tangent;
pub mod sketch_builders;
pub mod sketch_certificates;
mod sketch_circle_tangent;
mod sketch_cubic_tangent;
pub mod sketch_degeneracy;
pub mod sketch_domains;
pub mod sketch_entity_domains;
pub mod sketch_failed_constraints;
pub mod sketch_fixtures;
mod sketch_oriented_angle;
mod sketch_projection;
pub mod sketch_units;
mod sketch_workplane_symmetry;
pub mod sketch_workplanes;
pub mod solver;
pub mod solver_block;
pub mod sparse_pattern;
pub mod symbolic;
pub mod tensor_resultant;
pub mod tensor_support;
#[cfg(test)]
mod test_support;
pub mod trivariate_arithmetic;
pub mod work_budget;

pub use active_set::{
    ActiveSetAffineRegenerationReport, ActiveSetAffineRegenerationStatus, ActiveSetAuditReport,
    ActiveSetAuditRow, ActiveSetLoopConfig, ActiveSetLoopIteration, ActiveSetLoopReport,
    ActiveSetLoopStatus, ActiveSetQuadraticCandidateReport, ActiveSetQuadraticCandidateStatus,
    ActiveSetQuadraticRegenerationConfig, ActiveSetQuadraticRegenerationReport,
    ActiveSetQuadraticRegenerationStatus, ActiveSetQuadraticRootAssignment, ActiveSetRowStatus,
    ActiveSetUpdateAction, ActiveSetUpdateReport, ActiveSetUpdateRow, audit_active_mask,
    audit_active_set, propose_active_set_update, regenerate_active_set_affine_candidate,
    regenerate_active_set_quadratic_candidates, run_active_set_update_loop,
};
pub use affine::AffineResidual;
pub use algebraic::{
    AlgebraicPolynomialValueInterval, AlgebraicRootAffineRelation,
    AlgebraicRootAffineTransformReport, AlgebraicRootAffineTransformStatus,
    AlgebraicRootArithmeticOp, AlgebraicRootArithmeticReport, AlgebraicRootArithmeticStatus,
    AlgebraicRootComparisonReport, AlgebraicRootComparisonStatus,
    AlgebraicRootDifferenceComparisonReport, AlgebraicRootPolynomialEvaluationReport,
    AlgebraicRootPolynomialEvaluationStatus, AlgebraicRootRationalEvaluationReport,
    AlgebraicRootRationalEvaluationStatus, AlgebraicRootRefinementComparisonConfig,
    AlgebraicRootRefinementComparisonReport, AlgebraicRootRepresentation,
    AlgebraicRootRepresentationReport, AlgebraicRootRepresentationStatus,
    AlgebraicRootValidationReport, AlgebraicRootValidationStatus, algebraic_root_affine_relation,
    arithmetic_algebraic_root_representations, compare_algebraic_root_representations,
    compare_algebraic_root_representations_by_difference,
    compare_algebraic_root_representations_with_refinement, evaluate_polynomial_at_algebraic_root,
    evaluate_rational_expression_at_algebraic_root, represent_univariate_algebraic_roots,
    represent_univariate_algebraic_roots_from_reports, represented_root_sign,
    transform_algebraic_root_affine, translated_algebraic_root_difference,
    validate_algebraic_root_representation,
};
pub use algebraic_binary::{
    AlgebraicRootBinaryTransformReport, AlgebraicRootBinaryTransformStatus,
    transform_algebraic_roots_binary,
};
pub use algebraic_fiber::{
    AlgebraicFiberDiagonalDeflationReport, AlgebraicFiberDiagonalDeflationStatus,
    AlgebraicFiberPolynomialImageProjectionConfig, AlgebraicFiberPolynomialImageProjectionReport,
    AlgebraicFiberPolynomialImageProjectionStatus, AlgebraicFiberProjectionReport,
    AlgebraicFiberProjectionStatus, AlgebraicFiberRationalReductionReport,
    AlgebraicFiberRationalReductionStatus, AlgebraicFiberRootCountReport,
    AlgebraicFiberRootCountStatus, AlgebraicFiberRootIsolationConfig,
    AlgebraicFiberRootIsolationReport, AlgebraicFiberRootIsolationStatus,
    AlgebraicFiberRootRefiner, AlgebraicFiberSubresultantError, AlgebraicField,
    AlgebraicFieldError, AlgebraicFieldValue,
    count_bivariate_common_fiber_roots_at_algebraic_parameter,
    count_bivariate_fiber_roots_at_algebraic_parameter,
    count_bivariate_fiber_roots_at_algebraic_parameter_closed,
    count_bivariate_fiber_roots_at_algebraic_parameter_intervals,
    deflate_bivariate_fiber_diagonal_root_at_algebraic_parameter,
    isolate_bivariate_fiber_roots_at_algebraic_parameter, project_algebraic_fiber_polynomial_image,
    project_algebraic_fiber_polynomial_image_relation,
    project_algebraic_fiber_rational_image_relation,
    project_bivariate_fiber_at_algebraic_parameter,
    reduce_bivariate_rational_function_at_algebraic_parameter, subresultant_in_algebraic_fiber,
};
pub use algebraic_mobius::{
    AlgebraicRootMobiusTransformReport, AlgebraicRootMobiusTransformStatus,
    compose_univariate_polynomial_linear_fractional, transform_algebraic_root_mobius,
};
pub use algebraic_polynomial_image::{
    AlgebraicRootPolynomialImageReport, AlgebraicRootPolynomialImageStatus,
    transform_algebraic_root_polynomial_image,
};
pub use algebraic_rational_image::{
    AlgebraicRootRationalImageReport, AlgebraicRootRationalImageStatus, AlgebraicRootRationalMap,
    transform_algebraic_root_rational_image, transform_algebraic_root_rational_image_in_interval,
    transform_algebraic_root_rational_images,
};
pub use algebraic_sqrt::{
    AlgebraicRootSquareRootReport, AlgebraicRootSquareRootStatus,
    square_root_algebraic_root_representation,
};
pub use algebraic_tensor_image::{
    AlgebraicTensorImageReport, AlgebraicTensorImageStatus,
    compact_algebraic_root_low_degree_witness, project_selected_tensor_fiber_via_tagged_norm,
    represent_algebraic_tensor_image,
};
pub use alpha::{
    UnivariateQuadraticAlphaReport, UnivariateQuadraticAlphaRow, UnivariateQuadraticAlphaStatus,
    certify_univariate_quadratic_alpha,
};
pub use analysis::{ConstraintFacts, ProblemAnalysis, ProblemFacts, facts_depend_on_symbol};
pub use bareiss::{
    BareissDeterminantMethod, BareissDeterminantReport, BareissError, BareissMultiRhsSolveReport,
    BareissPivot, BareissSolveReport, SparseBareissError, SparseBareissSolveReport,
    SparseMinimumDegreeBareissSolveReport, SparsePatternPreservingBareissSolveReport,
    determinant_bareiss, solve_dense_linear_system_bareiss,
    solve_dense_linear_system_bareiss_multi_rhs, solve_sparse_linear_system_bareiss,
    solve_sparse_linear_system_bareiss_minimum_degree,
    solve_sparse_linear_system_bareiss_pattern_preserving,
};
pub use batch::{
    BatchCandidateCertificationReport, BatchCandidateReplay, BatchCandidateStatus,
    BatchPredicateScheduleConfig, BatchPredicateScheduleError, BatchPredicateScheduleReport,
    BatchPredicateWorkItem, certify_candidate_batch, certify_candidate_batch_with_config,
    schedule_candidate_batch_predicates,
};
pub use branches::{
    ExactBranchEnumerationReport, ExactBranchStatus, ExactSolutionBranch,
    enumerate_direct_univariate_quadratic_branches,
    enumerate_direct_univariate_quadratic_branches_with_config,
};
pub use certification::{
    CandidateCertificationConfig, CandidateCertificationReport, CandidateResidualBall,
    CertifiedCandidateRow, CertifiedCandidateStatus, certify_candidate,
    certify_candidate_with_config, certify_candidate_with_residual_balls,
    report_lossy_adapter_only_candidate,
};
pub use curve_resultant::{
    BivariatePolynomial, BivariatePolynomialAxisFactorReport, BivariatePolynomialAxisFactorStatus,
    BivariatePolynomialComponentReport, BivariatePolynomialComponentStatus,
    CurveIntersectionParameterLiftMap, CurveIntersectionParameterLiftReport,
    CurveIntersectionParameterLiftStatus, CurveIntersectionResultantConfig,
    CurveIntersectionResultantReport, CurveIntersectionResultantStatus, CurveResultantParameter,
    PolynomialParametricCurve2, QuadrivariateConstraintResultantReport,
    QuadrivariateConstraintSubresultantReport, QuadrivariatePolynomial,
    TrivariateConstraintResultantReport, TrivariateConstraintResultantStatus,
    TrivariateConstraintSubresultantReport, TrivariateConstraintSubresultantStatus,
    TrivariatePolynomial, TrivariatePolynomialAxis, TrivariatePolynomialSystemSubresultantReport,
    TrivariatePolynomialSystemSubresultantStatus, divide_bivariate_polynomial_exact,
    divide_univariate_polynomial_exact, extract_bivariate_polynomial_system_axis_factors,
    greatest_common_divisor_univariate_polynomials_exact,
    linear_parameter_lifts_bivariate_polynomial_system,
    parameter_component_bivariate_polynomial_system, primitive_bivariate_fiber_component_exact,
    resultant_bivariate_polynomial_system, resultant_parametric_curve_intersection,
    resultant_quadrivariate_polynomial_fourth_axis_constraint,
    resultant_rational_parametric_curve_intersection,
    resultant_trivariate_polynomial_univariate_constraint,
    saturate_rootless_bivariate_axis_factors,
    subresultant_quadrivariate_polynomial_fourth_axis_constraint,
    subresultant_trivariate_polynomial_system,
    subresultant_trivariate_polynomial_univariate_constraint,
};
pub use curve_substitution::{
    BezierPowerBasisSubstitutionConfig, BezierPowerBasisSubstitutionReport,
    BezierPowerBasisSubstitutionStatus, BsplineKnotSpanSubstitutionConfig,
    BsplineKnotSpanSubstitutionReport, BsplineKnotSpanSubstitutionStatus,
    HomogeneousCurveControlPoint2, NurbsKnotSpanSubstitutionReport, PolynomialCurvePoint2,
    RationalBezierPowerBasisSubstitutionReport, RationalBezierPowerBasisSubstitutionStatus,
    RationalCurveControlPoint2, RationalParametricCurve2, substitute_bezier_power_basis,
    substitute_bspline_knot_span_power_basis, substitute_nurbs_knot_span_power_basis,
    substitute_rational_bezier_power_basis,
};
pub use diagnostics::{
    ConvergenceReason, ProposalEngineKind, ProposalEnginePrecision, ProposalEngineReport,
    ProposalPreprocessingReport, SolveReport,
};
pub use direct::{
    DirectAffineSolution, DirectAffineSystemAssignment, DirectAffineSystemReport,
    DirectAffineSystemStatus, DirectQuadraticCandidateReport, DirectQuadraticCandidateStatus,
    DirectQuadraticSolution, DirectSolveError, EliminatedAffineRow, EqualitySubstitution,
    EqualitySubstitutionClass, EqualitySubstitutionClassApplicationReport,
    EqualitySubstitutionClassApplicationRow, EqualitySubstitutionClassApplicationStatus,
    EqualitySubstitutionClassMember, EqualitySubstitutionCycle,
    EqualitySubstitutionEliminationReport, EqualitySubstitutionProblem,
    EqualitySubstitutionValidation, apply_equality_substitution_classes,
    apply_equality_substitutions, certify_direct_univariate_quadratic_roots,
    certify_direct_univariate_quadratic_roots_with_config,
    eliminate_affine_rows_with_substitution_classes, equality_substitution_classes,
    find_equality_substitution_cycles, find_equality_substitutions, solve_direct_affine_equalities,
    solve_direct_affine_system, solve_direct_univariate_quadratic_equalities,
    validate_equality_substitutions,
};
pub use domain::geometry::{
    Point2 as SolverPoint2, named_equation, point_coincidence_equations, squared_distance_equation,
    squared_distance_expr, tangent_cross_expr, tangent_dot_expr, tangent_parallel_equation,
    tangent_same_direction_constraint,
};
pub use domain_certification::{
    CandidateDomainReport, DomainCheck, DomainCheckKind, DomainCheckStatus,
    certify_candidate_domains,
};
pub use eval::{
    EvalError, EvaluationContext, ResidualEvaluation, context_from_problem, evaluate_residuals,
};
pub use failed_constraints::{
    FailedConstraintMinimalRemovalSearchReport, FailedConstraintPairRemovalProbe,
    FailedConstraintPairRemovalSearchReport, FailedConstraintRemovalProbe,
    FailedConstraintRemovalSearchReport, FailedConstraintRemovalStatus, FailedConstraintReport,
    FailedConstraintRow, FailedConstraintSetRemovalProbe, FailedConstraintSetRemovalSearchReport,
    FailedConstraintStatus, diagnose_failed_constraints,
    diagnose_failed_constraints_from_certification, diagnose_failed_constraints_with_config,
    search_failed_constraint_minimal_removals,
    search_failed_constraint_minimal_removals_with_config, search_failed_constraint_pair_removals,
    search_failed_constraint_pair_removals_with_config, search_failed_constraint_set_removals,
    search_failed_constraint_set_removals_with_config, search_failed_constraint_single_removals,
    search_failed_constraint_single_removals_with_config,
};
pub use hyperlimit::{
    Certainty as PredicateCertainty, PredicateOutcome, PredicatePolicy, Sign as PredicateSign,
    classify_real_sign as classify_real_sign_predicate, compare_reals as compare_real_predicate,
};
pub use interval::{
    AffineIntervalError, AffineKrawczykReport, AffineKrawczykStatus, AffineKrawczykVariableStep,
    IntervalBoxCertificationPackage, IntervalBoxCertificationReport,
    IntervalBoxCertificationStatus, MultivariateQuadraticKrawczykReport,
    MultivariateQuadraticKrawczykResidual, MultivariateQuadraticKrawczykStatus,
    MultivariateQuadraticKrawczykVariable, QuadraticIntervalError, QuadraticKrawczykReport,
    QuadraticKrawczykRow, QuadraticKrawczykStatus, VariableBall, certify_affine_interval_candidate,
    certify_affine_krawczyk_box, certify_interval_box_candidate,
    certify_multivariate_quadratic_interval_candidate, certify_multivariate_quadratic_krawczyk_box,
    certify_quadratic_interval_candidate, certify_univariate_quadratic_krawczyk_box,
};
pub use linalg::{
    DenseLinearBackend, LinearAdapterKind, LinearAdapterPrecision, LinearBackend, LinearSolveError,
    LinearSolveReport,
};
pub use model::{Constraint, ConstraintKind, Problem, Variable, VariableId};
pub use modular_gcd::{ModularCoprimality, univariate_polynomials_modular_coprimality};
pub use ordered_field_resultant::{OrderedFieldResultantError, ordered_field_resultant_bivariate};
pub use ordered_field_roots::{
    OrderedFieldPolynomialContext, OrderedFieldRootIsolationConfig,
    OrderedFieldRootIsolationReport, OrderedFieldRootIsolationStatus,
    isolate_ordered_field_polynomial_roots, isolate_ordered_field_polynomial_roots_complete,
    isolate_ordered_field_polynomial_roots_complete_with_config, ordered_field_polynomial_gcd,
    ordered_field_polynomial_linear_quotient, ordered_field_polynomial_sign_remainder,
};
pub use polynomial::{
    QuadraticLinearTerm, QuadraticResidual, QuadraticTerm, UnivariateQuadraticResidual,
};
pub use predicates::{Classification, PredicateBackend, PredicateReport};
pub use rank::{ExactAffineRankReport, ExactAffineRankStatus, analyze_exact_affine_rank};
pub use real_interval::RealInterval;
pub use represented_root::*;
pub use residual_replay::{
    DenseResidualReplayError, DenseResidualReplayReport, SparseLinearSystem,
    SparseResidualBatchReplay, SparseResidualBatchReport, SparseResidualBatchStatus,
    SparseResidualReplayError, SparseResidualReplayReport, SparseResidualReplayRow,
    SparseResidualTerm, replay_dense_linear_residuals, replay_sparse_linear_residual_batch,
    replay_sparse_linear_residuals,
};
pub use resultant::{
    ResultantInputSide, UnivariateResultantError, UnivariateResultantPairInput,
    UnivariateResultantPairReport, UnivariateResultantPairStatus, UnivariateResultantReport,
    UnivariateResultantScheduleReport, UnivariateSubresultantChainError,
    UnivariateSubresultantChainReport, UnivariateSubresultantChainStep,
    resultant_univariate_polynomials, schedule_univariate_resultant_pairs,
    subresultant_chain_univariate_polynomials,
};
pub use root_isolation::{
    AlgebraicRootCandidateReport, AlgebraicRootCandidateStatus, BernsteinRootCountReport,
    BernsteinRootCountStatus, BernsteinSubdivisionConfig, BernsteinSubdivisionInterval,
    BernsteinSubdivisionIntervalStatus, BernsteinSubdivisionReport, BernsteinSubdivisionStatus,
    DescartesRootCountReport, DescartesRootCountStatus, IsolatedRootInterval,
    IsolatedRootRefinementReport, IsolatedRootRefinementStatus, RootIsolationConfig,
    RootIsolationStatus, RootMultiplicityStatus, UnivariateRootIsolationReport,
    UnivariateSturmPoint, UnivariateSturmSequence, certify_isolated_rational_root_witnesses,
    certify_isolated_rational_root_witnesses_with_config,
    certify_univariate_polynomial_nonnegative, count_bernstein_univariate_polynomial_interval_expr,
    count_bernstein_univariate_polynomial_interval_roots,
    count_descartes_univariate_polynomial_expr, count_descartes_univariate_polynomial_roots,
    isolate_univariate_polynomial_expr, isolate_univariate_polynomial_expr_with_config,
    isolate_univariate_polynomial_roots, isolate_univariate_polynomial_roots_with_config,
    polynomial_has_one_distinct_root_in_open_interval,
    refine_isolated_univariate_polynomial_interval, square_free_part,
    subdivide_bernstein_univariate_polynomial_interval_expr,
    subdivide_bernstein_univariate_polynomial_interval_roots,
};
pub use root_sign::{
    ordered_field_count_roots, ordered_field_count_roots_between_values,
    ordered_field_polynomial_sign_at_value, ordered_field_sign_at_selected_root,
    ordered_field_vanishes_at_selected_root, sign_at_selected_root, sign_at_selected_tuple,
};
pub use simplex_projection::{
    SimplexProjectionConfig, SimplexProjectionError, SimplexProjectionReport,
    SimplexProjectionStatus, project_origin_onto_simplex, project_origin_onto_simplex_with_config,
};
pub use sketch::{
    SketchArcEndpoint, SketchArcLengthSweep, SketchArcOfCircle2, SketchArcPointSweep,
    SketchArcTangencyBranch, SketchCircle2, SketchCircleTangencyBranch, SketchConstraint,
    SketchConstraintHandle, SketchConstraintKind, SketchCubic2, SketchDistance, SketchEntity,
    SketchEntityDomain, SketchEntityHandle, SketchEntityKind, SketchGeneratedRow,
    SketchGeneratedRowStatus, SketchGroupHandle, SketchLineEndpoint, SketchLineSegment2,
    SketchLineSegment3, SketchLoweringReport, SketchNormal2, SketchNormal3, SketchParameter,
    SketchParameterDomain, SketchParameterHandle, SketchPoint2, SketchPoint3, SketchResidualForm,
    SketchResidualFormKind, SketchResidualFormRole, SketchResidualFormsReport,
    SketchResidualFormsStatus, SketchResidualStrategy, SketchRoundTripMetadata,
    SketchRoundTripRole, SketchSolveProblem, SketchTangentOrientation, SketchWorkplane,
};
pub use sketch_builders::{
    SketchConstraintBuildReport, SketchConstraintFamily, angle as sketch_angle_builders,
    distance as sketch_distance_builders, incidence as sketch_incidence_builders,
    objective as sketch_objective_builders, orientation as sketch_orientation_builders,
    ranges as sketch_range_builders, symmetry as sketch_symmetry_builders,
    tangency as sketch_tangency_builders,
};
pub use sketch_certificates::{
    SketchConstructionCertificate, SketchConstructionCertificateStatus,
    SketchConstructionProvenance, SketchConstructionTraceCounts, certify_sketch_construction,
};
pub use sketch_degeneracy::{
    SketchDegeneracyCheck, SketchDegeneracyKind, SketchDegeneracyReport, SketchDegeneracyStatus,
    preflight_sketch_degeneracies, preflight_sketch_degeneracies_with_policy,
};
pub use sketch_domains::{
    SketchParameterDomainCheck, SketchParameterDomainKind, SketchParameterDomainReport,
    SketchParameterDomainStatus, preflight_sketch_parameter_domains,
    preflight_sketch_parameter_domains_with_policy,
};
pub use sketch_entity_domains::{
    SketchEntityDomainCheck, SketchEntityDomainKind, SketchEntityDomainReport,
    SketchEntityDomainStatus, preflight_sketch_entity_domains,
    preflight_sketch_entity_domains_with_policy,
};
pub use sketch_failed_constraints::{
    SketchFailedConstraintReport, SketchFailedConstraintRow, SketchFailedConstraintStatus,
    diagnose_sketch_failed_constraints, diagnose_sketch_failed_constraints_with_config,
};
pub use sketch_fixtures::{
    SketchCompatibilityFixture, SketchCompatibilityFixtureKind, SketchCompatibilityReplayReport,
    replay_sketch_compatibility_fixture, sketch_compatibility_fixtures,
};
pub use sketch_units::{
    SketchUnitToleranceObjectKind, SketchUnitToleranceReport, SketchUnitToleranceRow,
    SketchUnitToleranceStatus, audit_sketch_unit_tolerances,
    audit_sketch_unit_tolerances_with_policy,
};
pub use sketch_workplanes::{
    SketchWorkplaneFrameReport, SketchWorkplaneFrameStatus, SketchWorkplanePointLiftReport,
    SketchWorkplanePointProjectionReport, lift_sketch_point2_to_workplane3,
    lift_sketch_point2_to_workplane3_with_policy, project_sketch_point3_to_workplane2,
    project_sketch_point3_to_workplane2_with_policy, sketch_workplane_frame,
    sketch_workplane_frame_with_policy,
};
pub use solver::{DraggedParameterWeight, SolverConfig, SolverState, solve_damped_least_squares};
pub use solver_block::{SolverBlock, SolverBlockFacts, SolverBlockRow, SolverBlockRowKind};
pub use sparse_pattern::{
    SparsePatternEntry, SparsePatternEntryStatus, SparsePatternError,
    SymbolicSparseEliminationStep, SymbolicSparseFactorizationReport,
    analyze_sparse_bareiss_elimination_pattern,
};
pub use symbolic::{Expr, ExprDegree, ExprEvalError, ExprFacts, SymbolId, SymbolRef};
pub use tensor_resultant::{
    DenseTensorPolynomial, TensorConstraintResultantReport, TensorConstraintResultantStatus,
    resultant_tensor_polynomial_univariate_constraint,
};
