<h1>
  Hypersolve
  <img src="./doc/hypersolve.png" alt="Hypersolve logo" width="144" align="right">
</h1>

Exact-aware symbolic constraints, direct subproblem solvers, candidate
certification, and explicit numerical proposal adapters for the Hyper stack.

Hypersolve represents variables and residuals with `hyperreal::Real`, analyzes
their algebraic structure, solves supported exact subproblems, and records
whether a proposed candidate was certified, violated, or left unresolved. It
is not a claim that every nonlinear problem can be solved exactly, nor is its
dense floating-point proposal loop a source of topology truth.

Domain geometry remains owned by Hyperlimit, Hypercurve, Hypertri, and their
consumers. Hypersolve owns reusable equation structure and certification.

This README describes crate version `0.4.0`.

## Primary types

| Type | Role |
| --- | --- |
| `Expr`, `SymbolId`, `ExprFacts`, `ExprDegree` | Symbolic residual and structural facts |
| `Problem`, `Variable`, `Constraint` | Solver model |
| `ProblemAnalysis`, `ConstraintFacts`, `SolverBlock` | Dependency, degree, affine, polynomial, and sparsity analysis |
| `EvaluationContext`, `ResidualEvaluation` | Exact candidate bindings and residual values |
| `AffineResidual`, `QuadraticResidual`, `UnivariateQuadraticResidual` | Recognized exact subproblems |
| `CandidateCertificationReport`, `CandidateDomainReport` | Candidate proof, violation, uncertainty, and domain evidence |
| `AlgebraicRootRepresentation` | Isolated exact algebraic root carrier |
| `work_budget::{WorkBudget, BudgetOutcome, BudgetExceeded, CancellationToken}` | Shared synchronous refinement/promotion accounting with typed exhaustion and cooperative cancellation |
| `SolverConfig`, `SolverState`, `SolveReport` | Explicit proposal-engine state and diagnostics |
| `SketchSolveProblem`, `SketchConstraintBuildReport` | Sketch-specific equation construction and reports |

## Install

Add hypersolve 0.4.0 to a project with `cargo add hypersolve`; it requires Rust
1.95 or newer. The examples below are checked in; from the root of a
[CSGRS source checkout](../../readme.md), run:

```sh
cargo run -p hypersolve --example basic
```

Hypersolve has no default features. `dispatch-trace` is for exact-dispatch
instrumentation and does not change the mathematical API.

The experimental `expression-program` feature adds owned flat expression
graphs with ordered bindings and validated replay. It retains the existing
`Expr` grammar and exact scalar definitions. Enable `serde` to serialize its
unvalidated definitions; load them through `ExpressionProgram::from_definition`
before evaluation. Graph budgets cover structural work and entry counts, not
scalar arithmetic or heap bytes. `ExpressionProgram::jacobian` builds symbolic
partials through bounded local templates and a shared DAG, retaining original
source guards and ordered differentiation variables for replay. Its combined
program evaluates source outputs before column-major partials. This bounds graph
expansion, not total scalar work; removable derivative singularities can still
prevent evaluation. Validated evolution remains separate work. Run the source and
symbolic-Jacobian example with:

```sh
cargo run -p hypersolve --features expression-program --example owned_program
```

`ExpressionProgram::compose` binds an outer program's input slots to selected
inner output slots, preserving shared nodes and independent identifier scopes.
Its executable retains every inner output before the composed values so ignored
inputs cannot erase domain checks. Use `CompositionProgram::composed_output` to
locate results after evaluating or certifying the complete program. Repeated
composition retains these guard outputs; replay rebuilds both original sources
and their binding selection. Taylor output projection can select final values
while retaining the full source proof; the existing regularity restrictions still
apply to every retained output.

`interval-program` adds `eval_dyadic` over input boxes, retaining the exact
definition and refusing partial-domain images. Graph work and dyadic arithmetic
have separate budgets; Hyperreal constant refinement is outside their total-work
accounting. This is an interval expression evaluator, not a validated ODE solver.
Run `cargo run -p hypersolve --features interval-program --example enclosed_program`
for an oscillator image and source-bound symbolic-Jacobian enclosure.

`interval-lattice` adds `RegularJacobianEnclosure::matrix::<R, C>()`. It checks
source output and selected-variable counts, then copies partials into the same
row-major `IntervalMatrix` used by Hyperlattice. The returned `JacobianMatrix`
borrows the original regularity evidence, retaining source, arguments and grid.
Its `intervals()` supplies numerical products and norms; `into_intervals()`
explicitly extracts only the numerical matrix. Copies share caller-owned graph
and dyadic budgets. Empty domains stay empty even with zero matrix dimensions;
nonempty zero-dimensional products remain distinct. Replay rebuilds the original
evidence through `enclose_regular`; no serialized proof flag is accepted.

`taylor-model` adds demanded normalized mixed partials through
`ExpressionProgram::coefficients` and centered exact-coefficient models through
`taylor_model`. Supply an exact singleton dyadic center, a finite box, total
polynomial degree and enclosure grid. The model retains exact `Real` coefficients,
source regularity and every degree-(n+1) contribution to a certified remainder.
Its image includes that remainder and intersects an independent natural source
enclosure. Subdomain reuse retains the original global remainder and grid;
replay regenerates evidence from the source and request. This requires the
current primitive grammar's open analytic domains, which can be stricter than
value evaluation. Empty products remain explicit. Structural/native arithmetic
budgets retain the scalar-refinement and heap-byte exclusions above.

`float-proposal-program` adds `ExpressionProgram::float_proposal` and a prepared
`FloatProposalProgram::estimate` view. Demanded constants are projected once;
ordered bindings, original domain guards and shared nodes remain in the schedule.
Native results are finite point estimates, without enclosure or exact-source
claims. Numerical domain/overflow errors do not prove failure of the exact source.
Recompute consumed evidence from the retained original program. Graph budgets
cover preparation and evaluation bookkeeping; scalar projection and native math
library internals remain outside whole-work accounting.

`work_budget::with_budget` bounds instrumented root-subdivision and tensor-image
promotion attempts across nested synchronous operations. Exhaustion is a typed
resource failure and never authorizes approximation. The counters do not yet
cover every solver path or bound scalar arithmetic, coefficient sizes,
allocation, or elapsed time. `work_budget::with_cancellable_budget` adds a
`CancellationToken` that another thread can cancel; the operation stops at its
next instrumented unit with a typed `Cancellation` failure.
`work_budget::with_coefficient_bit_limit` bounds the exact coefficients that
Bareiss determinants, pseudo-quotient matrices and dense tensor products
produce, failing deterministically with `CoefficientGrowth`. See the
[module contract](src/work_budget.rs) for the current coverage, cache behavior,
and thread-local scope rules.

## Quick start

This checked example evaluates and certifies the candidate \(x=2\) for
\(x^2-4=0\).

<!-- quickstart:start -->
```rust
use hyperreal::Real;
use hypersolve::{Constraint, Expr, Problem, certify_candidate, context_from_problem};

fn main() {
    let mut problem = Problem::default();
    let x = problem.add_variable("x", Real::from(2));
    let x_expr = Expr::symbol(problem.variables[x.0 as usize].symbol, "x");
    problem.add_constraint(Constraint::equality(
        "x squared is four",
        x_expr.clone() * x_expr - Expr::real(Real::from(4)),
    ));

    let analysis = problem.analyze();
    let candidate = context_from_problem(&problem);
    let certification = certify_candidate(&analysis, &candidate);

    assert_eq!(certification.certified_satisfied_rows, 1);
    assert!(!certification.has_certified_violation());
}
```
<!-- quickstart:end -->

Run it with:

```sh
cargo run -p hypersolve --example basic
```

## Solver model

```text
Expr + Variable + Constraint
             │
          Problem
             │ analyze
       ProblemAnalysis
        ┌────┴───────────────┐
 exact/direct routes    numerical proposal
        │                        │
        └──────── candidate ─────┘
                     │
       domain preflight + exact replay
                     │
       certified / violated / unknown
```

Structural analysis is intentionally reusable. It records dependencies,
degrees, constant/affine/polynomial rows, sparse Jacobian structure, and solver
blocks before an algorithm is selected.

## API guide

### Expressions, models, and evaluation

- `Expr::{real, symbol, structural_facts, dependencies, simplify, derivative,
  eval_real}` builds and inspects symbolic residuals. Standard arithmetic and
  supported elementary functions compose expressions.
- `Variable::new` and `Variable::with_bounds` create variables directly.
  `Problem::{add_variable, add_constraint, analyze}` is the usual model path.
- `Constraint::equality` creates a zero-residual equation;
  `ConstraintKind` identifies other row semantics.
- `context_from_problem`, `EvaluationContext::bind`, and
  `evaluate_residuals` create and evaluate exact candidates.
- `jacobian::symbolic_jacobian`, `symbolic_jacobian_with_analysis`, and
  `finite_difference_jacobian` expose exact-symbolic and explicitly finite
  Jacobian routes.

### Structural and direct exact solving

- `ProblemAnalysis::{facts, constraints, jacobian_sparsity,
  affine_residuals, univariate_quadratic_residuals, quadratic_residuals,
  evaluate_residuals}` exposes retained row structure.
- `AffineResidual::from_expr`, `QuadraticResidual::from_expr`, and
  `UnivariateQuadraticResidual::from_expr` recognize useful exact forms.
- `solve_direct_affine_equalities` and `solve_direct_affine_system` solve
  supported one-row or square affine systems.
- `determinant_bareiss`, `solve_dense_linear_system_bareiss`, and the sparse,
  multi-right-hand-side, pattern-preserving, and minimum-degree Bareiss
  variants provide exact fraction-free linear algebra with reports. Dense
  solves take an explicit `PredicatePolicy`, extend unresolved fast pivots
  through that policy, fall back to a pivot-free exact determinant construction
  when no pivot can be selected, and retain the weakest pivot,
  determinant, and residual certainty in their reports. Sparse pattern,
  pivot, and replay signs keep the requested refinement bound as their fast
  path, then use the strict exact predicate cascade; unsupported identities
  remain explicit rather than becoming approximate sparse decisions.
- `analyze_exact_affine_rank` reports exact rank evidence.
- `find_equality_substitutions`, `validate_equality_substitutions`,
  `equality_substitution_classes`, `apply_equality_substitutions`,
  `apply_equality_substitution_classes`, and
  `eliminate_affine_rows_with_substitution_classes` expose exact rewriting
  without mutating the source problem.
- `solve_direct_univariate_quadratic_equalities` and
  `certify_direct_univariate_quadratic_roots` enumerate and replay supported
  quadratic candidates.

### Polynomial and algebraic roots

- Root-isolation APIs provide Descartes/Bernstein bounds, recursive Bernstein
  subdivision, square-free reduction, exact dyadic Fujiwara whole-line bounds,
  Sturm intervals, bounded refinement, and exact rational-witness replay.
  Positive-width Sturm partitions own `(lower, upper]`; explicit exact
  witnesses own their point and are strictly checked for closed containment,
  polynomial vanishing, and unique-root evidence. Linear carriers are solved
  exactly, while validated one-root intervals bisect by exact midpoint and
  defining-polynomial sign under hard step and optional exact-width bounds.
  The public interval-presence query excludes both endpoints and returns an
  explicit unknown when its configured exact predicates do not decide. It uses
  endpoint/monotonicity proofs first, then exact Bernstein variation, a
  repeated-quadratic discriminant rule, square-free reduction, and Sturm as the
  complete fallback; a variation greater than one is never treated as a
  disproof. Algebraic image admission uses `(lower, upper]` for positive-width
  enclosures, strictly replays and collapses exact image witnesses, and bounds
  source refinement to eight rounds.
- `represent_univariate_algebraic_roots` and
  `validate_algebraic_root_representation` create and check retained isolated
  roots.
- `compare_algebraic_root_representations`, affine/Möbius/binary transforms,
  polynomial images, rational images, and arithmetic reports operate without
  first lowering roots to primitive floats.
- Represented-root comparison and sign replay cached-valid payloads under the
  strict policy before making a decision. Exact witnesses supersede wider
  stored bounds, exact operands are skipped during Sturm refinement, and
  difference comparison preserves direct/self orders before trying point
  polynomial replay, interval GCD evidence, narrowed-operand construction, or
  a represented difference sign. Rational sign decisions stay in rational
  payloads; unsupported identities remain explicit `Undecided` reports.
- Möbius transforms strictly replay their source carrier, accept general exact
  `Real` defining coefficients, and retain the power-sum construction as a
  fallback when homogeneous Horner trimming is undecided. Exact rational
  witnesses become canonical linear point representations, while mapped
  exact-`Real` points use zero-width isolating representations rather than
  being mislabeled as rational witnesses. Foreign poles are separated by
  bounded source refinement, selected-root poles remain explicit, and
  decreasing maps preserve `(lower, upper]` ownership. Rational determinant,
  denominator, endpoint, and homogeneous-polynomial work stays in rational
  payloads until final report values are constructed.
- Affine root transforms also strictly replay source evidence. Homogeneous
  Horner replaces repeated machine-binomial expansion, so degree is no longer
  limited by `u64` binomial storage; rational coefficients stay in rational
  payloads, exact point sources become canonical linear representations with
  truthful rational-versus-exact-`Real` metadata, and the certified scale sign
  orients reflected interval endpoints directly after bounded refinement has
  removed any ownership-changing endpoint roots.
- Represented-root arithmetic distinguishes stored exact rational results from
  general exact `Real` results without a rational payload, accepts either as a
  scalar for supported affine or Möbius lowering, and uses policy-certified
  inversion when ordinary
  exact division cannot decide a symbolic denominator. Direct point and
  identity routes replay their source payloads under `STRICT`; missing binary
  operands and unsupported coefficient fields retain distinct reports. Zero
  divided by a certified nonzero represented root is exactly zero, a selected
  nonzero root divides by itself exactly even when its interval touches zero,
  same-root addition uses an affine image, and rational quadratic squares use
  their defining linear relation instead of a general resultant.
- Algebraic-root polynomial and rational-expression evaluation strictly
  replays cached-valid point evidence and reports rational payloads separately
  from general exact `Real` values. Borrowed trimming and leading-seeded Horner
  avoid transient coefficient storage; rational intervals stay in `Rational`
  through endpoint products and quotients. Rational expressions reuse one
  source admission and the denominator/numerator sign proofs, with direct
  exact-zero, same-value, unit-denominator, and rational-payload quotient paths.
- Independent-root binary transforms strictly replay both source carriers,
  square-free repeated defining polynomials before enforcing the bounded
  resultant degree, and retain explicit unsupported-degree and denominator-
  domain reports. Exact-integer resultants use a scalar fraction-free path;
  general exact-rational coefficients keep the report-bearing fallback.
- Signed square-root transforms strictly replay their source representation
  and adaptively tighten exact dyadic image bounds when a nearby conjugate
  defeats the initial enclosure. Exact rational sources produce the canonical
  linear witness for rational square roots or the minimal quadratic relation
  for irrational ones; every bounded failure remains an explicit report.
- Unary polynomial-image transforms strictly replay their source evidence and
  admit only nonempty exact-rational authored image storage. Exact relations
  `q = scale * P + constant` collapse directly to a canonical rational point,
  while an oversized repeated carrier is square-freed before the same bounded
  Sylvester limit is enforced. Rational Horner and interval kernels stay in
  rational payloads until their final report values are constructed.
- Rational-image transforms keep the authored denominator authoritative:
  exact GCD selection reports a true pole at the chosen algebraic root, while
  a dependency-broadened interval triggers bounded exact source refinement.
  After domain admission, common factors and exact remainders modulo the
  source polynomial reduce the map before its fixed resultant budget. Exact
  constants and linear-fractional maps reuse general exact-`Real` Möbius
  support, decreasing maps preserve `(lower, upper]` endpoint ownership, and
  fixed-size batches share denominator admission, refinement, and source
  conversion without changing output order or per-image reports.
- `resultant_parametric_curve_intersection` and
  `resultant_rational_parametric_curve_intersection` expose solver-level curve
  elimination reports. Equal-degree rational systems through degree 12 use a
  half-size Bezout matrix, while other modest systems use a sparse Sylvester
  matrix. Both lanes evaluate one division-free polynomial determinant instead
  of repeated scalar determinants plus interpolation; the generic
  exact-coefficient path remains authoritative outside those bounded lanes.
  Planar curve carriers and filled-region topology still belong to Hypercurve.
- `bivariate_topology::decompose_bivariate_curve` is a source-tree prototype for
  complete rational polynomial zero-set graphs in a closed rational rectangle.
  It isolates all projection events and fibers, including interior loops and
  isolated contacts, and retains root-free connection strips with exact branch
  counts. The source equation, domain, event roots and ordered branches remain
  queryable; `rational_fiber` continues exact slice queries without a polyline
  conversion. Singular nodes and cusps need no generic-position assumption.
  Simple horizontal components on either closed rectangle boundary remain in
  the original equation and graph. Their contacts are projection events and
  their incidence uses the same closed-fiber counts and separator proofs.
  Vertical components and repeated generic fibers remain typed blockers. Source/projection degree, fiber depth and
  connection refinement controls are distinct from the shared work budget;
  none establishes a total scalar-work or heap bound. This constructor does
  not itself certify filled regions or general surface intersections; consumers
  retain their own admission and image requirements. The diagnostic graph
  records used in tests are not a native BRep archive format.
- Univariate, typed trivariate/quadrivariate, and rank-independent tensor
  resultants use the requested coefficient-refinement bound as their fast
  path, then continue unresolved exact degree, trimming, zero, normalization,
  and scheduled-resultant signs through the strict predicate cascade.
  Unsupported identities remain explicit `UndecidedCoefficient` or
  `UndecidedResultantSign` outcomes; no approximate sign enters elimination.
- Algebraic-fiber polynomial images and exact-`Real` quotient-ring norms use
  strict exact zero proofs when canonicalizing degree-bearing input,
  determinant output, and projective output storage. An unsupported trailing
  coefficient remains retained and participates in the configured degree
  rather than being discarded as an approximate zero.
- Direct tensor norms reuse already-certified retained degrees instead of
  rebuilding nominal zero padding. Sampled norms skip only represented
  rational zero arithmetic, and the quadratic closed form compacts only that
  same structural padding; opaque or unsupported coefficients still
  participate without an added sign decision.
- Dense tensor quotient-ring reduction certifies and inverts its shared
  modulus once, reuses one fiber buffer, and bypasses only entirely represented
  rational-zero fibers. Already-reduced tensors take a validated clone path;
  authored modulus shape and every opaque coefficient remain unchanged.
- Algebraic tensor images move validated dense storage through rational
  canonicalization, final square-free intake, and tagged bivariate conversion
  without cloning the complete tensor. The existing exact-rational normal form
  and all opaque coefficient decisions remain authoritative.
- Square-free intake inspects borrowed rational coefficients before deciding
  whether it needs an owned generic GCD. Modular coprimality can return the
  original polynomial, and the primitive-integer GCD path avoids its source
  clone; nonrational exact coefficients retain the generic path. Sturm setup
  likewise relies on its primitive normalizer's single trim rather than
  trimming each input twice.
- Polynomial long division reuses its certified canonical degrees: it borrows
  already-trimmed GCD/Sturm divisors, removes each algebraically canceled
  leading slot directly, and writes each quotient degree once. Arbitrary public
  divisors still pass through policy trimming, and exact nonrational fields use
  the same field operations and predicate authority as before.
- Local algebraic fields reuse the defining coefficients inside their owned,
  refinable root representation instead of cloning a second modulus. Public
  exact univariate division can trim borrowed divisor storage; internal
  local-field and GCD schedules retain owned divisors where matched benchmarks
  require them.
- Local quotient arithmetic updates rational product accumulators in place,
  moves certified leading cancellations, and seeds Horner evaluation from the
  actual leading coefficient. Denominator clearing consumes its optional
  denominators instead of cloning a parallel copy.
- Local sign and zero queries reuse the reduced numerator invariant established
  by every local-field element constructor and operation. Debug builds assert
  the canonical degree/trailing-coefficient boundary; release builds avoid a
  repeated clone, trim, and quotient reduction before consulting the sign
  cache.
- Local synthetic and exact division build quotient coefficients in descending
  discovery order, allocating an owning zero only for a genuinely skipped
  degree. Polynomial-image norms use direct 1-by-1 and 2-by-2 determinants;
  larger matrices retain the division-free Berkowitz construction.
- Local image convolution materializes only output degrees that receive a
  product. Quotient-multiplication matrices move completed row-major entries
  and eliminated high coefficients, while Berkowitz dot products move their
  first term before retaining the original ordered accumulation.
- Local-fiber exports consume their completed quotient-ring coefficients.
  Second-parameter output moves numerator vectors directly; first-parameter
  output moves each scalar into retained-power rows and pads only genuinely
  ragged entries. Any local denominator still rejects the export unchanged.
- Identically-zero image saturation computes the common image-coefficient
  factor once, then intersects every residual source multiplicity with that
  same factor. Fresh coefficient polynomials move into the GCD fold; local
  reduction, denominator clearing, and explicit removed-component evidence
  remain unchanged.
- Selected-fiber ordered-field Bernstein isolation seeds Horner values and
  controls from actual coefficients, creates the highest affine-composition
  term directly, and builds represented-root synthetic quotients in descending
  order. Endpoint ownership, variation counts, depth limits, and the complete
  repeated-root fallback are unchanged. Retained-field rational export also
  borrows its projective leading scalar while making a denominator monic.
- Rational-fiber reduction borrows its already reduced pivot and residual
  coefficients, materializes a shared zero only for a genuinely ragged power,
  and reuses the pivot's nonzero proof. The pivot residual is the exact
  cross-multiplied identity used to define the ratio; all other residuals keep
  their full quotient-ring zero proofs and public status boundaries.
- Polynomial-image projection constructs authored scalar image coefficients
  directly as denominator-free local-field constants. A validated retained
  modulus always has positive degree, so this removes an unreachable quotient
  reduction/error layer without changing degree budgets, unsupported storage,
  determinant arithmetic, or final retained/global relations.
- Batched open-interval fiber counts evaluate the lower Sturm boundary first
  and stop immediately when it is a root or an error. This matches the
  single-interval report order and avoids irrelevant upper-boundary work and
  retained-root refinement; ordinary boundary caching remains unchanged.
- Selected-fiber Sturm fallback moves its source polynomial into the sequence
  that already retains it, cloning that row back only for a rational-root
  restart. Incomplete reports preserve the Sturm length, subdivision count,
  retained-root refinements, certainty, and underlying error accumulated
  before termination.
- Plain algebraic-fiber projection shares the local field's exact evidence
  admission without cloning the complete refinable root or creating an unused
  sign cache. Retaining the second parameter also borrows the bivariate
  polynomial's authored coefficient grid directly; retaining the first still
  constructs the required transpose. The explicit degree budget bounds the
  retained defining-polynomial degree that determines matrix size.
- Selected-tensor tagged projection constructs `(z-source[0])^2` directly,
  moves its final flat tensor into primitive bivariate fibers, and reuses an
  exactly shared conjugate constraint. When exact square-free reduction lowers
  the first carrier's degree, that already-proved carrier also bounds the final
  quotient norm; repeated multiplicity cannot inflate the enumerator or its
  determinant dimension.
- Correlated tensor-image orchestration counts exact affine/duplicate-axis
  collapses as completed eliminations, reuses square-free constraints shared
  by non-affine conjugates, and skips quotient reductions whose stored power
  bounds are already below the divisor degree. Rational-class coefficients
  bypass symbolic normal-form traversal while opaque exact fields retain the
  unchanged proof path.
- Bézier, rational Bézier, B-spline span, and NURBS span substitution functions
  convert retained curve data into polynomial systems with explicit status.

### Certification

- `certify_candidate`, `certify_candidate_with_config`, and
  `certify_candidate_with_residual_balls` replay candidate rows.
- `certify_candidate_domains` preflights division, powers, square root,
  logarithm, inverse circular functions, and inverse hyperbolic functions.
- Interval APIs certify exact residual ranges over candidate boxes.
- Affine and quadratic Krawczyk reports, plus
  `certify_univariate_quadratic_alpha`, expose supported local existence and
  uniqueness evidence.
- `certify_candidate_batch` and `schedule_candidate_batch_predicates` reuse
  predicate schedules across candidates.
- `replay_dense_linear_residuals` is the shared policy-explicit exact replay
  helper for domain crates that generate small dense systems. Its residuals
  are retained once, while row evidence records sign and certainty without
  duplicating each `Real`.
- `project_origin_onto_simplex` returns exact closest-point, squared-distance,
  barycentric, and ordering evidence for small convex hulls.

Unknown certification is a result, not a request to fall through to a float
comparison.

### Proposal engines and active sets

- `solve_damped_least_squares` runs the configured dense proposal engine and
  returns `SolveReport`.
- `SolverConfig` selects limits, tolerances, Jacobian policy, and
  `ProposalEngineKind`; `SolverState` carries candidate values.
- Dense linear, Levenberg–Marquardt, Powell hybrid/dogleg, BFGS, and SQP routes
  are proposal generators. Their precision and preprocessing are retained in
  `ProposalEngineReport`.
- `audit_active_set`, `propose_active_set_update`,
  `regenerate_active_set_affine_candidate`,
  `regenerate_active_set_quadratic_candidates`, and
  `run_active_set_update_loop` make active-mask changes auditable.
- Failed-constraint search reports identify single, pair, and bounded set
  removals without silently weakening the source model.

### Sketch and domain helpers

- `SketchSolveProblem` and the `sketch_builders` modules build exact-aware 2D
  and projected-workplane constraints.
- Builder methods cover coincidence, incidence, horizontal/vertical,
  parallel/perpendicular/same-direction, distances and ranges, radii,
  concentricity, length equality/ratio/difference, angles, tangency,
  midpoint/symmetry, parameter bounds, chamfer/fillet-related continuity, and
  projected 3D equivalents.
- Sketch preflight functions audit entity domains, workplanes, unit/tolerance
  declarations, degeneracy, compatibility fixtures, construction
  certificates, and failed constraints.
- `SolverPoint2`, `squared_distance_expr`, `point_coincidence_equations`, and
  tangent helpers are small reusable equation builders.

Routing, PCB, and toolpath residual builders live in Hyperpath, where their
domain semantics can be documented and validated.

## Guarantees and boundaries

- Residual definitions, direct algebra, and certification use
  `hyperreal::Real`.
- A numerical proposal is never automatically a certified solution.
- Domain-invalid expressions are reported before residual acceptance.
- Geometry predicates are delegated to the crate that owns the geometry.
- Dense finite linear algebra, finite differences, convergence tolerances, and
  numerical stopping conditions are named adapter policy.
- Exact reports retain dependencies, row structure, pivots, permutations,
  intervals, witnesses, or replay values needed to audit the conclusion.

The nonlinear proposal layer is experimental. Consumers should accept a
candidate only when the required domain and residual reports are certified for
their use case.

## Feature flags

| Feature | Default | Purpose |
| --- | --- | --- |
| `dispatch-trace` | no | Hyperreal/Hyperlattice/Hyperlimit exact-dispatch instrumentation |
| `expression-program` | no | Experimental owned flat expression definitions and exact scalar evaluation |
| `interval-program` | no | Experimental dyadic expression images with complete-domain checks |
| `interval-lattice` | no | Fixed-size Jacobian matrix projections retaining source/domain evidence |
| `serde` | no | Symbol and expression-definition serialization using validated Hyperreal scalar replay |

## Validation and performance

```sh
cargo fmt --all -- --check
cargo test --locked --all-targets --all-features
cargo clippy --locked --all-targets --all-features -- -D warnings
RUSTDOCFLAGS="-D warnings" cargo doc --locked --no-deps --all-features
cargo check --locked --manifest-path fuzz/Cargo.toml --bins
scripts/representation_coverage.sh
scripts/coverage.sh
scripts/allocation_profile.sh
cargo bench --locked --bench representations
cargo bench --locked --bench competitive
```

The representation matrix explicitly inventories Hyperreal's 22 optimized
finite certificate classes and all eight public structural kinds. It also
exercises variable-depth opaque computable DAGs. The coverage script generates
an HTML report and enforces an 85% production-line floor; the allocation
profiler reports steady-state counts and bytes for analysis/certification,
exact dense solving, and sparse replay for every class, and fails on a nonzero
signed live-byte delta. Competitive Criterion rows compare exact Hypersolve
roots and dense solves with the proposal-only `roots` and `nalgebra` float
APIs; the CGAL/Gmpq harness remains the exact quadratic comparison.

The benchmark protocol and retained/rejected optimization record are in
[PERFORMANCE.md](PERFORMANCE.md). The automatically refreshed
[benchmarks.md](benchmarks.md) catalogues every timing and diagnostic suite,
all stored Criterion rows, and comparative ratios; the custom algebraic-fiber
timings are retained in
[algebraic_fiber_benchmarks.md](algebraic_fiber_benchmarks.md), and the external
exact CGAL/Gmpq comparison writes
[cgal_quadratic_benchmarks.md](cgal_quadratic_benchmarks.md). Fuzz replay
instructions are in [fuzz/README.md](fuzz/README.md); dispatch instrumentation
is documented in [dispatch_trace.md](dispatch_trace.md).

## References

These sources describe the exact algebra, interval certification, nonlinear
proposal, and geometric-constraint techniques relevant to Hypersolve:

- Bareiss, E. H. “Sylvester’s Identity and Multistep Integer-Preserving
  Gaussian Elimination.” *Mathematics of Computation* 22, 1968.
  [DOI: 10.1090/S0025-5718-1968-0226829-0](https://doi.org/10.1090/S0025-5718-1968-0226829-0).
- Bouma, W., Fudos, I., Hoffmann, C. M., Cai, J., and Paige, R. “A Geometric
  Constraint Solver.” *Computer-Aided Design* 27(6), 1995.
  [DOI: 10.1016/0010-4485(95)00007-4](https://doi.org/10.1016/0010-4485(95)00007-4).
- Collins, G. E. “Subresultants and Reduced Polynomial Remainder Sequences.”
  *JACM* 14(1), 1967.
  [DOI: 10.1145/321371.321381](https://doi.org/10.1145/321371.321381).
- Farouki, R. T., and Rajan, V. T. “Algorithms for Polynomials in Bernstein
  Form.” *Computer Aided Geometric Design* 5(1), 1988.
  [DOI: 10.1016/0167-8396(88)90016-7](https://doi.org/10.1016/0167-8396(88)90016-7).
- Krawczyk, R. “Newton-Algorithmen zur Bestimmung von Nullstellen mit
  Fehlerschranken.” *Computing* 4, 1969.
  [DOI: 10.1007/BF02234767](https://doi.org/10.1007/BF02234767).
- Levenberg, K. “A Method for the Solution of Certain Non-Linear Problems in
  Least Squares.” *Quarterly of Applied Mathematics* 2, 1944.
  [DOI: 10.1090/qam/10666](https://doi.org/10.1090/qam/10666).
- Marquardt, D. W. “An Algorithm for Least-Squares Estimation of Nonlinear
  Parameters.” *SIAM Journal on Applied Mathematics* 11(2), 1963.
  [DOI: 10.1137/0111030](https://doi.org/10.1137/0111030).
- Moore, R. E. *Interval Analysis*. Prentice-Hall, 1966.
- Nocedal, J., and Wright, S. J. *Numerical Optimization*, 2nd ed. Springer,
  2006. [DOI: 10.1007/978-0-387-40065-5](https://doi.org/10.1007/978-0-387-40065-5).
- Powell, M. J. D. “A Hybrid Method for Nonlinear Equations.” In *Numerical
  Methods for Nonlinear Algebraic Equations*, 1970.
  [DOI: 10.1007/BFb0067700](https://doi.org/10.1007/BFb0067700).
- Sederberg, T. W., and Nishita, T. “Curve Intersection Using Bézier
  Clipping.” *Computer-Aided Design* 22(9), 1990.
  [DOI: 10.1016/0010-4485(90)90039-F](https://doi.org/10.1016/0010-4485(90)90039-F).
- Smale, S. “Newton’s Method Estimates from Data at One Point.” In *The
  Merging of Disciplines*, 1986.
  [DOI: 10.1007/978-1-4612-4984-9_1](https://doi.org/10.1007/978-1-4612-4984-9_1).
- Sturm, C. “Mémoire sur la résolution des équations numériques.” 1835.
  [EuDML](https://eudml.org/doc/183280).
- Tinney, W. F., and Walker, J. W. “Direct Solutions of Sparse Network
  Equations by Optimally Ordered Triangular Factorization.” *IEEE Transactions
  on Power Apparatus and Systems*, 1967.
  [DOI: 10.1109/TPAS.1967.291823](https://doi.org/10.1109/TPAS.1967.291823).
- Yap, C. K. “Towards Exact Geometric Computation.” *Computational Geometry*
  7(1–2), 1997.
  [DOI: 10.1016/0925-7721(95)00040-2](https://doi.org/10.1016/0925-7721(95)00040-2).

## Acknowledgements

Hypersolve builds on
[Hyperreal](https://github.com/timschmidt/csgrs/tree/main/crates/hyperreal),
[Hyperlattice](https://github.com/timschmidt/csgrs/tree/main/crates/hyperlattice), and
[Hyperlimit](https://github.com/timschmidt/csgrs/tree/main/crates/hyperlimit). The research cited
above informs its algorithms and evidence boundaries without implying
source-code derivation.

## License and contributing

Licensed under the [MIT License](LICENSE) or the
[Apache License 2.0](LICENSE-APACHE), at your option.

Bug reports should include the smallest problem, initial candidate, selected
proposal engine, enabled features, and complete analysis/certification report.
Before proposing a change, run formatting, the focused regression, all-feature
tests, and strict Clippy.

## Extension protocol

Extensions follow the stack-wide [admission protocol](../../docs/admission.md).
It defines the exactness, certainty, boundary, cache, validation, and evidence
requirements shared by the Hyper crates.

Enable `taylor-affine` for `TaylorAffineModel`, which retains exact affine output maps over a shared `TaylorModel`.
It combines equal polynomial monomials before enclosure and composes subsequent
maps against the original residual coordinates. A shear followed by its inverse
therefore does not adopt an intermediate output box. Rectangular/singular maps,
nonrational exact coefficients, empty/unit dimensions and subdomain reuse are
supported. Replay the original source/request and the composed `TaylorAffineMap`;
serialized derived coefficients or flags are not proof. This is an image of a
function, not an ODE coordinate-change certificate or nonlinear model arithmetic.
The graph/native budgets apply with the existing scalar/payload exclusions;
entry checks are stage-local, not a total live-memory bound.

`taylor-noise` adds `TaylorNoiseModel` over an existing `TaylorAffineModel`.
It retains at most a requested number of shared monomial columns, ranked by
certified coefficient-times-monomial widths. Every omitted contribution enters
its affine output omission residual; equal bounds do not merge identities.
Original Taylor residual coordinates keep their exact affine weights separately,
so duplication and cancellation of a known shared residual remain available.
`enclose` combines exact coefficients for an affine observation before projecting
retained noise. Independence is an outer-enclosure device, not a claim about the
original functions. The exact source and all discarded term indices remain
available. Reducing capacity can widen answers; no box replaces the source.
Replay the original Taylor definition/request, affine map and capacity. Graph
and native budgets cover selection and queries, with the existing exact-scalar
and heap-byte exclusions. See the Hyperdynamics `taylor_noise` example for a
field-image consumer; no ODE noise-propagation guarantee is implied.

Enable `taylor-polynomial` for `TaylorPolynomialModel` output maps over an
existing shared Taylor model. Validated `ExpressionProgram` maps may use constants,
inputs, negation, addition, subtraction and multiplication. Products retain exact
coefficients and account for every truncated monomial and residual cross-product;
generated models accept further maps without new differentiation. Subdomain
queries return `TaylorRange`, the existing Cartesian image carrier, preserving
empty/unit products. Replay the original source/request and each map definition.
This does not implement division, transcendental model maps, or combination of
independently centered models. Use `taylor-affine` when composing linear maps
against the original residual coordinates is the intended operation.

Enable `taylor-composition` to compose certified Taylor maps through
`Arc<TaylorModel>::compose` or `TaylorPolynomialModel::compose`. The inner image
must fit every outer input domain, including unused inputs. The inner parameter
center/domain/order stay fixed; existing polynomial propagation accounts for all
truncated terms and residual cross-products, then adds the outer model's entire
remainder. Both original certificates remain shared, and generated output accepts
further polynomial or certified-model maps. Result coefficients describe a
polynomial plus residual, not necessarily the derivatives of the exact composite
at the inner center. `model_map` exposes the retained outer certificate;
`polynomial_map` supplies node indices for product evidence. Replay each original
definition/request and the ordered map sequence. Existing stage resource limits
and scalar/whole-heap exclusions apply; this does not merge independently based
parameter models or automatically select centers, orders or subdivisions.

### Exact coordinate programs

The opt-in `coordinate-program` feature certifies finite exact state charts
`x = c + A*y`. `ExpressionProgram::change_coordinates` validates a supplied
inverse B with STRICT proofs of B*A=I, then retains `B*f(c+A*y)` as a shared DAG.
`CoordinateProgram` keeps the original definition, chart, source-node mapping and
inverse outcomes. Nonselected inputs remain unchanged; source guards survive
zero coefficients. Invalid shapes, wrong inverses, undecided identities and
resource failures are distinct. Replay the original definition and chart to
regenerate the evidence. Graph limits do not bound exact scalar/predicate payload
work, total heap bytes or cancellation inside one scalar/predicate stage.

The opt-in `coordinate-transition` feature composes two validated charts of the same source into an exact affine map, retaining both inverse proofs. Interval evaluation can then project that map without first projecting through source coordinates.

The opt-in `qr-coordinates` feature constructs exact unpivoted QR frames from a square basis. It retains positive residual-norm decisions, the source-bound orthogonality proof and all reconstruction residual decisions; dependent and undecided columns remain distinct failures.
