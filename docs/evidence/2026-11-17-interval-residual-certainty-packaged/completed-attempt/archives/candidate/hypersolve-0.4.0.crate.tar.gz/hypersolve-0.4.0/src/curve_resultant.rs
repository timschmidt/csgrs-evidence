//! Exact resultant helpers for low-degree parametric curve intersections.
//!
//! Curve crates own topology, span subdivision, and curve-specific validity
//! rules. This module supplies the bounded exact algebraic handoff they need:
//! two polynomial parametric curves in power basis are substituted into
//! `x1(t) - x2(u)` and `y1(t) - y2(u)`, the second parameter is eliminated by
//! Sylvester resultants. Rational coefficients use a fraction-free polynomial
//! determinant when its dimension permits; other cases use exact interpolation.
//! This follows the elimination view of Bezier clipping while keeping the
//! exact-computation boundary explicit: the resultant is candidate
//! algebraic evidence, not an accepted topology event, until a downstream
//! curve package replays it against retained geometry.

use hyperreal::{CertifiedRealSign, Rational, Real, RealSign};

use crate::bareiss::{BareissError, determinant_bareiss, determinant_integer_polynomial_matrix};
use crate::classification::{Classification, UncertaintyReason};
use crate::curve_substitution::RationalParametricCurve2;
use crate::integer_interpolation::primitive_integer_polynomial_gcd;
use crate::resultant::{
    UnivariateResultantError, resultant_exact_rational_polynomials_value,
    resultant_univariate_polynomials, sylvester_matrix,
};
use crate::root_isolation::{
    UnivariateSturmPoint, UnivariateSturmSequence, polynomial_div_rem_borrowed_divisor,
    polynomial_gcd,
};

/// Selects which curve parameter remains after exact elimination.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CurveResultantParameter {
    /// Retain the first curve's parameter.
    First,
    /// Retain the second curve's parameter.
    Second,
}

/// Power-basis representation of a 2D polynomial parametric curve.
///
/// Coefficients are stored in ascending power order. For example,
/// `x_coefficients = [1, 2, 3]` means `x(t) = 1 + 2*t + 3*t^2`.
#[derive(Clone, Debug, PartialEq)]
pub struct PolynomialParametricCurve2 {
    /// Power-basis coefficients for the x-coordinate.
    pub x_coefficients: Vec<Real>,
    /// Power-basis coefficients for the y-coordinate.
    pub y_coefficients: Vec<Real>,
}

impl PolynomialParametricCurve2 {
    /// Construct a 2D polynomial parametric curve in power basis.
    pub const fn new(x_coefficients: Vec<Real>, y_coefficients: Vec<Real>) -> Self {
        Self {
            x_coefficients,
            y_coefficients,
        }
    }
}

/// Exact polynomial in two parameters.
///
/// `coefficients[first_power][second_power]` multiplies
/// `first_parameter^first_power * second_parameter^second_power`. Rows may be
/// ragged; omitted coefficients are zero.
#[derive(Clone, Debug, PartialEq)]
pub struct BivariatePolynomial {
    /// Coefficient grid in ascending powers of both parameters.
    pub coefficients: Vec<Vec<Real>>,
}

impl BivariatePolynomial {
    /// Constructs a bivariate polynomial from its ascending-power grid.
    pub const fn new(coefficients: Vec<Vec<Real>>) -> Self {
        Self { coefficients }
    }

    /// Substitutes independent affine maps into both parameter axes.
    ///
    /// Returns `P(first_scale*x + first_offset, second_scale*y + second_offset)`
    /// with the original coefficient magnitudes. Negative and zero scales,
    /// ragged rows, and arbitrary exact `Real` coefficients are supported;
    /// this arithmetic operation needs no degree or sign decisions.
    ///
    /// Two univariate Horner passes avoid constructing an outer-product grid
    /// for every monomial. For an m-by-n grid this takes O(m*n*(m+n)) scalar
    /// operations and O(m*n) temporary storage.
    pub fn substitute_affine(
        &self,
        first_scale: &Real,
        first_offset: &Real,
        second_scale: &Real,
        second_offset: &Real,
    ) -> Self {
        let rows = self
            .coefficients
            .iter()
            .map(|row| polynomial_affine_substitution(row, second_scale, second_offset))
            .collect::<Vec<_>>();
        let width = rows.iter().map(Vec::len).max().unwrap_or(0);
        let mut coefficients = vec![vec![Real::zero(); width]; rows.len()];
        let columns = (0..width).map(|second_power| {
            rows.iter()
                .map(|row| row.get(second_power).cloned().unwrap_or_else(Real::zero))
                .collect::<Vec<_>>()
        });
        for (second_power, column) in columns.enumerate() {
            for (first_power, value) in
                polynomial_affine_substitution(&column, first_scale, first_offset)
                    .into_iter()
                    .enumerate()
            {
                coefficients[first_power][second_power] = value;
            }
        }
        for row in &mut coefficients {
            while row.last().is_some_and(Real::definitely_zero) {
                row.pop();
            }
        }
        while coefficients.last().is_some_and(Vec::is_empty) {
            coefficients.pop();
        }
        Self::new(coefficients)
    }
}

fn polynomial_affine_substitution(coefficients: &[Real], scale: &Real, offset: &Real) -> Vec<Real> {
    let Some(leading) = coefficients.last() else {
        return Vec::new();
    };
    if scale.definitely_zero() {
        return vec![Real::eval_poly(coefficients, offset)];
    }
    if scale.definitely_one() && offset.definitely_zero() {
        return coefficients.to_vec();
    }
    let mut result = Vec::with_capacity(coefficients.len());
    result.push(leading.clone());
    for coefficient in coefficients[..coefficients.len() - 1].iter().rev() {
        let length = result.len();
        result.push(&result[length - 1] * scale);
        for index in (1..length).rev() {
            result[index] = Real::mul_add(&result[index], offset, &(&result[index - 1] * scale));
        }
        result[0] = Real::mul_add(&result[0], offset, coefficient);
    }
    result
}

/// Exact polynomial in three parameters.
///
/// `coefficients[first_power][second_power][third_power]` multiplies the
/// corresponding ascending powers. Rows and columns may be ragged; omitted
/// coefficients are zero.
#[derive(Clone, Debug, PartialEq)]
pub struct TrivariatePolynomial {
    /// Coefficient tensor in ascending powers of all three parameters.
    pub coefficients: Vec<Vec<Vec<Real>>>,
}

/// Exact polynomial in four parameters.
///
/// `coefficients[first_power][second_power][third_power][fourth_power]`
/// multiplies the corresponding ascending powers.  The fourth axis is the
/// constrained fiber axis used by the bounded resultant helpers below; the
/// first three axes remain as one exact [`TrivariatePolynomial`].
#[derive(Clone, Debug, PartialEq)]
pub struct QuadrivariatePolynomial {
    /// Coefficient tensor in ascending powers of all four parameters.
    pub coefficients: Vec<Vec<Vec<Vec<Real>>>>,
}

impl QuadrivariatePolynomial {
    /// Constructs a quadrivariate polynomial from its ascending-power tensor.
    pub const fn new(coefficients: Vec<Vec<Vec<Vec<Real>>>>) -> Self {
        Self { coefficients }
    }
}

impl TrivariatePolynomial {
    /// Constructs a trivariate polynomial from its ascending-power tensor.
    pub const fn new(coefficients: Vec<Vec<Vec<Real>>>) -> Self {
        Self { coefficients }
    }
}

/// Selects one axis of a [`TrivariatePolynomial`].
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TrivariatePolynomialAxis {
    /// The first tensor index.
    First,
    /// The second tensor index.
    Second,
    /// The third tensor index.
    Third,
}

impl TrivariatePolynomialAxis {
    const fn index(self) -> usize {
        match self {
            Self::First => 0,
            Self::Second => 1,
            Self::Third => 2,
        }
    }
}

/// Final status for eliminating one trivariate axis constrained to a selected
/// univariate algebraic root.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TrivariateConstraintResultantStatus {
    /// The two-retained-axis resultant was reconstructed exactly.
    Constructed,
    /// The enclosing operation declined this algebraic elimination.
    BudgetExhausted,
    /// The trivariate polynomial or univariate constraint was empty.
    EmptyPolynomial,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// The constraint was constant after certified trimming.
    InvalidConstraint,
    /// At least one retained-axis degree exceeded the configured or
    /// addressable budget.
    DegreeBoundExceeded,
    /// A sampled univariate resultant failed.
    ResultantError,
    /// Exact tensor-grid interpolation failed.
    InterpolationDivisionFailed,
}

/// Exact report for eliminating one constrained trivariate axis.
#[derive(Clone, Debug, PartialEq)]
pub struct TrivariateConstraintResultantReport {
    /// Final construction status.
    pub status: TrivariateConstraintResultantStatus,
    /// Tensor axis removed by the resultant.
    pub eliminated_axis: TrivariatePolynomialAxis,
    /// Remaining tensor axes, in ascending original-axis order.
    pub retained_axes: [TrivariatePolynomialAxis; 2],
    /// Conservative resultant degree bound on each retained axis.
    pub degree_bounds: [usize; 2],
    /// Exact resultant in `retained_axes` order when construction succeeded.
    pub resultant: Option<BivariatePolynomial>,
    /// Sampled resultant error, when construction stopped at that boundary.
    pub resultant_error: Option<UnivariateResultantError>,
}

/// Final status for one exact constrained-axis trivariate subresultant.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TrivariateConstraintSubresultantStatus {
    /// Every coefficient of the requested subresultant was reconstructed.
    Constructed,
    /// The enclosing operation declined this algebraic elimination.
    BudgetExhausted,
    /// The trivariate polynomial or univariate constraint was empty.
    EmptyPolynomial,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// The constraint was constant after certified trimming.
    InvalidConstraint,
    /// The requested order was zero or exceeded the smaller input degree.
    InvalidOrder,
    /// At least one retained-axis degree exceeded the configured or
    /// addressable budget.
    DegreeBoundExceeded,
    /// A sampled exact subresultant determinant failed.
    DeterminantError,
    /// Exact tensor-grid interpolation failed.
    InterpolationDivisionFailed,
}

/// Exact coefficient tensors for one constrained-axis subresultant.
///
/// `coefficients[k]` is the bivariate coefficient of eliminated-axis power
/// `k`.  Callers select the first order whose coefficients do not all vanish
/// in their retained algebraic fiber; that polynomial is the fiber GCD up to a
/// nonzero scalar.
#[derive(Clone, Debug, PartialEq)]
pub struct TrivariateConstraintSubresultantReport {
    /// Final construction status.
    pub status: TrivariateConstraintSubresultantStatus,
    /// Tensor axis on which both input polynomials were compared.
    pub eliminated_axis: TrivariatePolynomialAxis,
    /// Remaining tensor axes, in ascending original-axis order.
    pub retained_axes: [TrivariatePolynomialAxis; 2],
    /// Requested subresultant order.
    pub order: usize,
    /// Conservative coefficient degree bound on each retained axis.
    pub degree_bounds: [usize; 2],
    /// Coefficients in ascending eliminated-axis power order.
    pub coefficients: Vec<BivariatePolynomial>,
    /// Sampled determinant error, when construction stopped there.
    pub determinant_error: Option<BareissError>,
}

/// Final status for one exact subresultant of two trivariate polynomials.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TrivariatePolynomialSystemSubresultantStatus {
    /// Every retained-axis coefficient of the requested subresultant was
    /// reconstructed exactly.
    Constructed,
    /// The enclosing operation declined this algebraic elimination.
    BudgetExhausted,
    /// At least one polynomial was identically zero.
    EmptyPolynomial,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// The requested order exceeded the smaller eliminated-axis degree.
    InvalidOrder,
    /// At least one retained-axis degree exceeded the configured or
    /// addressable budget.
    DegreeBoundExceeded,
    /// A sampled Sylvester or subresultant determinant failed.
    DeterminantError,
    /// Exact tensor-grid interpolation failed.
    InterpolationDivisionFailed,
}

/// Exact subresultant of two trivariate polynomials on one eliminated axis.
///
/// Order zero is their resultant. For positive order,
/// `coefficients[k]` multiplies eliminated-axis power `k`. Scanning orders
/// upward and signing the coefficient polynomials at a selected retained pair
/// recovers the first nonzero fiber GCD without constructing a primitive
/// element for that pair.
#[derive(Clone, Debug, PartialEq)]
pub struct TrivariatePolynomialSystemSubresultantReport {
    /// Final construction status.
    pub status: TrivariatePolynomialSystemSubresultantStatus,
    /// Tensor axis on which the input polynomials were compared.
    pub eliminated_axis: TrivariatePolynomialAxis,
    /// Remaining tensor axes, in ascending original-axis order.
    pub retained_axes: [TrivariatePolynomialAxis; 2],
    /// Requested subresultant order; zero denotes the resultant.
    pub order: usize,
    /// Conservative coefficient degree bound on each retained axis.
    pub degree_bounds: [usize; 2],
    /// Coefficients in ascending eliminated-axis power order.
    pub coefficients: Vec<BivariatePolynomial>,
    /// Sampled determinant error, when construction stopped there.
    pub determinant_error: Option<BareissError>,
}

/// Exact report for eliminating the fourth axis of a quadrivariate polynomial
/// under one univariate algebraic constraint.
#[derive(Clone, Debug, PartialEq)]
pub struct QuadrivariateConstraintResultantReport {
    /// Final construction status.
    pub status: TrivariateConstraintResultantStatus,
    /// Conservative resultant degree bound on each retained axis.
    pub degree_bounds: [usize; 3],
    /// Exact resultant on the first three axes when construction succeeded.
    pub resultant: Option<TrivariatePolynomial>,
    /// Sampled resultant error, when construction stopped there.
    pub resultant_error: Option<UnivariateResultantError>,
}

/// Exact fourth-axis subresultant with trivariate coefficient tensors.
///
/// `coefficients[k]` multiplies fourth-axis power `k`.  A caller can sign the
/// coefficient tensors at three already selected roots and thereby recover
/// the first nonzero polynomial in the selected fiber without constructing a
/// primitive element for those roots.
#[derive(Clone, Debug, PartialEq)]
pub struct QuadrivariateConstraintSubresultantReport {
    /// Final construction status.
    pub status: TrivariateConstraintSubresultantStatus,
    /// Requested positive subresultant order.
    pub order: usize,
    /// Conservative coefficient degree bound on each retained axis.
    pub degree_bounds: [usize; 3],
    /// Coefficients in ascending fourth-axis power order.
    pub coefficients: Vec<TrivariatePolynomial>,
    /// Sampled determinant error, when construction stopped there.
    pub determinant_error: Option<BareissError>,
}

/// Final status for exact univariate axis-factor extraction from two bivariate equations.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BivariatePolynomialAxisFactorStatus {
    /// The active operation budget declined a common-factor attempt.
    BudgetExhausted,
    /// Neither equation pair has a nonconstant common factor depending on only
    /// one parameter.
    Primitive,
    /// At least one nonconstant common axis factor was extracted exactly.
    Reduced,
    /// Both equations are identically zero, so no greatest finite factor exists.
    ZeroSystem,
    /// An authored coefficient tower could not be reduced by exact arithmetic.
    UnsupportedCoefficient,
    /// Division by a computed exact GCD did not leave zero remainder.
    DivisionFailed,
}

/// Exact common axis factors and, when needed, their primitive equation pair.
///
/// Factors are stored in ascending power order and normalized to primitive
/// integer coefficients with positive leading coefficient. A successful absent
/// factor is represented by `[1]`; factors are empty when extraction did not
/// complete. `reduced_equations` is allocated only for
/// [`BivariatePolynomialAxisFactorStatus::Reduced`].
///
/// This report does **not** authorize saturation. Removing one of these factors
/// deletes the complete fiber at each of its roots. A geometry caller must first
/// prove that every extracted factor is nonzero throughout that parameter's
/// authored domain before substituting `reduced_equations` for the originals.
#[derive(Clone, Debug, PartialEq)]
pub struct BivariatePolynomialAxisFactorReport {
    /// Final extraction status.
    pub status: BivariatePolynomialAxisFactorStatus,
    /// Greatest common factor depending only on the first parameter.
    pub first_parameter_factor: Vec<Real>,
    /// Greatest common factor depending only on the second parameter after the
    /// first-parameter factor has been divided out.
    pub second_parameter_factor: Vec<Real>,
    /// Primitive equation pair when a nonconstant factor was extracted.
    pub reduced_equations: Option<[BivariatePolynomial; 2]>,
}

/// Extract exact common factors supported on either parameter axis.
///
/// For equations `F(t, u)` and `G(t, u)`, the first factor is the univariate GCD
/// of every `u`-coefficient polynomial in `t` from both equations. After exact
/// division, the second factor is the GCD of every remaining `t`-coefficient
/// polynomial in `u`. Thus genuinely bivariate common components remain in the
/// returned equations; only separable axis content is reported.
///
/// The integer-polynomial route remains the fast path. Exact `Real` coefficient
/// towers fall through to strict field polynomial GCD and division. In
/// particular, APPROXIMATE_512 is never used to infer an algebraic factor.
/// Callers remain responsible for domain-certified saturation as described by
/// [`BivariatePolynomialAxisFactorReport`].
/// A nonzero system charges one promotion before factor discovery and another
/// before an independently scaled retry, if needed. A zero system is free.
pub fn extract_bivariate_polynomial_system_axis_factors(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
) -> BivariatePolynomialAxisFactorReport {
    if crate::work_budget::exhaustion().is_some() {
        return axis_factor_failure(BivariatePolynomialAxisFactorStatus::BudgetExhausted);
    }
    if [first_equation, second_equation]
        .iter()
        .all(|equation| exact_bivariate_is_zero(equation))
    {
        return axis_factor_failure(BivariatePolynomialAxisFactorStatus::ZeroSystem);
    }
    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return axis_factor_failure(BivariatePolynomialAxisFactorStatus::BudgetExhausted);
    }
    let initial =
        extract_bivariate_polynomial_system_axis_factors_once(first_equation, second_equation);
    if !matches!(
        initial.status,
        BivariatePolynomialAxisFactorStatus::UnsupportedCoefficient
            | BivariatePolynomialAxisFactorStatus::DivisionFailed
    ) {
        return initial;
    }
    retry_bivariate_polynomial_system_axis_factors(first_equation, second_equation)
        .unwrap_or(initial)
}

/// Removes common axis factors only when none vanishes on a closed rectangle.
///
/// Exact division certifies the factorization, and endpoint Sturm variations
/// certify that every removed factor is nonzero throughout its supplied
/// interval. No root isolation or approximate terminal decision is needed.
/// The returned equations have exactly the original zero set in that box.
/// `Decided(None)` means no factor was removed or a required mathematical proof
/// was unavailable; callers can continue with the original equations. Resource
/// exhaustion is returned separately and must stop the budgeted operation.
pub fn saturate_rootless_bivariate_axis_factors(
    equations: &[BivariatePolynomial; 2],
    bounds: [[&Real; 2]; 2],
) -> Classification<Option<[BivariatePolynomial; 2]>> {
    let report = extract_bivariate_polynomial_system_axis_factors(&equations[0], &equations[1]);
    if report.status == BivariatePolynomialAxisFactorStatus::BudgetExhausted {
        return Classification::Uncertain(UncertaintyReason::BudgetExhausted);
    }
    if report.status != BivariatePolynomialAxisFactorStatus::Reduced {
        return Classification::Decided(None);
    }
    Classification::Decided(certify_rootless_axis_factors(report, bounds))
}

fn certify_rootless_axis_factors(
    report: BivariatePolynomialAxisFactorReport,
    bounds: [[&Real; 2]; 2],
) -> Option<[BivariatePolynomial; 2]> {
    let policy = hyperlimit::PredicatePolicy::STRICT;
    for (factor, [lower, upper]) in [
        &report.first_parameter_factor,
        &report.second_parameter_factor,
    ]
    .into_iter()
    .zip(bounds)
    {
        if hyperlimit::compare_reals(lower, upper, policy).value()? == std::cmp::Ordering::Greater {
            return None;
        }
        let sequence = UnivariateSturmSequence::new(factor, policy)?;
        let (UnivariateSturmPoint::NonRoot(first), UnivariateSturmPoint::NonRoot(last)) = (
            sequence.classify_point(lower, policy)?,
            sequence.classify_point(upper, policy)?,
        ) else {
            return None;
        };
        if first != last {
            return None;
        }
    }
    report.reduced_equations
}

#[cold]
#[inline(never)]
fn retry_bivariate_polynomial_system_axis_factors(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
) -> Option<BivariatePolynomialAxisFactorReport> {
    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return Some(axis_factor_failure(
            BivariatePolynomialAxisFactorStatus::BudgetExhausted,
        ));
    }
    let (Some((first_normalized, first_scale)), Some((second_normalized, second_scale))) = (
        normalize_bivariate_projective_scale(first_equation),
        normalize_bivariate_projective_scale(second_equation),
    ) else {
        return None;
    };
    let mut retried = extract_bivariate_polynomial_system_axis_factors_once(
        &first_normalized,
        &second_normalized,
    );
    if !matches!(
        retried.status,
        BivariatePolynomialAxisFactorStatus::Primitive
            | BivariatePolynomialAxisFactorStatus::Reduced
    ) {
        return None;
    }
    if let Some(reduced) = &mut retried.reduced_equations {
        scale_bivariate_in_place(&mut reduced[0], &first_scale);
        scale_bivariate_in_place(&mut reduced[1], &second_scale);
    }
    Some(retried)
}

fn extract_bivariate_polynomial_system_axis_factors_once(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
) -> BivariatePolynomialAxisFactorReport {
    let equations = [first_equation, second_equation];
    let has_nonrational_coefficient = equations.iter().any(|equation| {
        equation
            .coefficients
            .iter()
            .flatten()
            .any(|coefficient| coefficient.exact_rational_ref().is_none())
    });
    let Some(first_parameter_factor) =
        common_axis_factor(&equations, CurveResultantParameter::First)
    else {
        return axis_factor_failure(if has_nonrational_coefficient {
            BivariatePolynomialAxisFactorStatus::UnsupportedCoefficient
        } else {
            BivariatePolynomialAxisFactorStatus::DivisionFailed
        });
    };
    if exact_polynomial_is_zero(&first_parameter_factor) {
        return axis_factor_failure(BivariatePolynomialAxisFactorStatus::DivisionFailed);
    }

    let mut reduced_equations = if first_parameter_factor.len() > 1 {
        let (Some(first), Some(second)) = (
            divide_bivariate_by_axis(
                first_equation,
                &first_parameter_factor,
                CurveResultantParameter::First,
            ),
            divide_bivariate_by_axis(
                second_equation,
                &first_parameter_factor,
                CurveResultantParameter::First,
            ),
        ) else {
            return axis_factor_failure(BivariatePolynomialAxisFactorStatus::DivisionFailed);
        };
        Some([first, second])
    } else {
        None
    };

    let reduced_refs = match &reduced_equations {
        Some(reduced) => [&reduced[0], &reduced[1]],
        None => equations,
    };
    let Some(second_parameter_factor) =
        common_axis_factor(&reduced_refs, CurveResultantParameter::Second)
    else {
        return axis_factor_failure(if has_nonrational_coefficient {
            BivariatePolynomialAxisFactorStatus::UnsupportedCoefficient
        } else {
            BivariatePolynomialAxisFactorStatus::DivisionFailed
        });
    };
    if exact_polynomial_is_zero(&second_parameter_factor) {
        return axis_factor_failure(BivariatePolynomialAxisFactorStatus::DivisionFailed);
    }

    if second_parameter_factor.len() > 1 {
        let sources = match &reduced_equations {
            Some(reduced) => [&reduced[0], &reduced[1]],
            None => equations,
        };
        let (Some(first), Some(second)) = (
            divide_bivariate_by_axis(
                sources[0],
                &second_parameter_factor,
                CurveResultantParameter::Second,
            ),
            divide_bivariate_by_axis(
                sources[1],
                &second_parameter_factor,
                CurveResultantParameter::Second,
            ),
        ) else {
            return axis_factor_failure(BivariatePolynomialAxisFactorStatus::DivisionFailed);
        };
        reduced_equations = Some([first, second]);
    }

    let status = if reduced_equations.is_some() {
        BivariatePolynomialAxisFactorStatus::Reduced
    } else {
        BivariatePolynomialAxisFactorStatus::Primitive
    };
    BivariatePolynomialAxisFactorReport {
        status,
        first_parameter_factor,
        second_parameter_factor,
        reduced_equations,
    }
}

pub(crate) fn normalize_bivariate_projective_scale(
    polynomial: &BivariatePolynomial,
) -> Option<(BivariatePolynomial, Real)> {
    let (_, _, scale) = leading_bivariate_term(&polynomial.coefficients)?;
    let coefficients = polynomial
        .coefficients
        .iter()
        .map(|row| {
            row.iter()
                .map(|coefficient| (coefficient / &scale).ok())
                .collect::<Option<Vec<_>>>()
        })
        .collect::<Option<Vec<_>>>();
    let coefficients = match coefficients {
        Some(coefficients) => coefficients,
        None => normalize_bivariate_projective_scale_policy_fallback(polynomial, &scale)?,
    };
    Some((canonical_exact_bivariate(coefficients), scale))
}

#[cold]
fn normalize_bivariate_projective_scale_policy_fallback(
    polynomial: &BivariatePolynomial,
    scale: &Real,
) -> Option<Vec<Vec<Real>>> {
    let reciprocal = strict_reciprocal_after_inverse_failure(scale)?;
    Some(
        polynomial
            .coefficients
            .iter()
            .map(|row| {
                row.iter()
                    .map(|coefficient| coefficient * &reciprocal)
                    .collect()
            })
            .collect(),
    )
}

fn scale_bivariate_in_place(polynomial: &mut BivariatePolynomial, scale: &Real) {
    for coefficient in polynomial.coefficients.iter_mut().flatten() {
        *coefficient *= scale;
    }
}

/// Configuration for bounded exact curve resultant construction.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct CurveIntersectionResultantConfig {
    /// Fast scalar-refinement bound used before the strict exact predicate
    /// cascade is attempted for an unresolved coefficient.
    pub min_precision: i32,
    /// Maximum retained-parameter degree this bounded helper may interpolate.
    pub max_resultant_degree: usize,
}

impl Default for CurveIntersectionResultantConfig {
    fn default() -> Self {
        Self {
            min_precision: hyperlimit::PredicatePolicy::MAX_REFINEMENT_PRECISION,
            max_resultant_degree: 32,
        }
    }
}

/// Eliminates one axis of a trivariate polynomial under a univariate algebraic
/// constraint on that axis.
///
/// The result is a candidate polynomial on the other two axes. The constraint
/// is normalized to monic form, so specializations where the trivariate
/// polynomial drops degree retain the same resultant scale. Exact resultants
/// are sampled on a tensor-product integer grid and reconstructed by nested
/// Lagrange interpolation. Downstream callers must still isolate and replay
/// candidate roots against the selected algebraic branches.
/// A work budget charges one promotion after degree admission, before the
/// interpolation grid is constructed. Exhaustion returns no resultant.
pub fn resultant_trivariate_polynomial_univariate_constraint(
    polynomial: &TrivariatePolynomial,
    constraint: &[Real],
    eliminated_axis: TrivariatePolynomialAxis,
    config: CurveIntersectionResultantConfig,
) -> TrivariateConstraintResultantReport {
    let retained_axis_indices = match eliminated_axis {
        TrivariatePolynomialAxis::First => [1, 2],
        TrivariatePolynomialAxis::Second => [0, 2],
        TrivariatePolynomialAxis::Third => [0, 1],
    };
    let retained_axes = retained_axis_indices.map(trivariate_axis_from_index);
    let report =
        |status, degree_bounds, resultant, resultant_error| TrivariateConstraintResultantReport {
            status,
            eliminated_axis,
            retained_axes,
            degree_bounds,
            resultant,
            resultant_error,
        };
    if crate::work_budget::exhaustion().is_some() {
        return report(
            TrivariateConstraintResultantStatus::BudgetExhausted,
            [0, 0],
            None,
            None,
        );
    }
    if trivariate_polynomial_is_empty(polynomial) || constraint.is_empty() {
        return report(
            TrivariateConstraintResultantStatus::EmptyPolynomial,
            [0, 0],
            None,
            None,
        );
    }
    let degrees = match certified_trivariate_degree(polynomial, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariateConstraintResultantStatus::Constructed,
                [0, 0],
                Some(BivariatePolynomial::new(vec![vec![Real::zero()]])),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintResultantStatus::UndecidedCoefficient,
                [0, 0],
                None,
                None,
            );
        }
    };
    let constraint = match trim_trailing_zeroes(constraint.to_vec(), config.min_precision) {
        Ok(constraint) => constraint,
        Err(()) => {
            return report(
                TrivariateConstraintResultantStatus::UndecidedCoefficient,
                [0, 0],
                None,
                None,
            );
        }
    };
    if constraint.len() <= 1 {
        return report(
            TrivariateConstraintResultantStatus::InvalidConstraint,
            [0, 0],
            None,
            None,
        );
    }
    let leading = constraint
        .last()
        .expect("a nonconstant constraint has a leading coefficient");
    let Ok(leading_reciprocal) =
        crate::policy_division::reciprocal_after_certified_nonzero(leading)
    else {
        return report(
            TrivariateConstraintResultantStatus::InterpolationDivisionFailed,
            [0, 0],
            None,
            None,
        );
    };
    let constraint = constraint
        .iter()
        .map(|coefficient| coefficient * &leading_reciprocal)
        .collect::<Vec<_>>();
    let constraint_degree = constraint.len() - 1;
    let degree_bounds =
        retained_axis_indices.map(|axis| constraint_degree.saturating_mul(degrees[axis]));
    if degree_bounds
        .into_iter()
        .any(|degree| degree > config.max_resultant_degree)
    {
        return report(
            TrivariateConstraintResultantStatus::DegreeBoundExceeded,
            degree_bounds,
            None,
            None,
        );
    }

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return report(
            TrivariateConstraintResultantStatus::BudgetExhausted,
            degree_bounds,
            None,
            None,
        );
    }
    let mut second_axis_polynomials = Vec::with_capacity(degree_bounds[0] + 1);
    for first_sample_index in 0..=degree_bounds[0] {
        let first_value = Real::from(first_sample_index as u64);
        let mut second_samples = Vec::with_capacity(degree_bounds[1] + 1);
        for second_sample_index in 0..=degree_bounds[1] {
            let second_value = Real::from(second_sample_index as u64);
            let fiber = evaluate_trivariate_at_retained_parameters(
                polynomial,
                eliminated_axis,
                &first_value,
                &second_value,
            );
            let fiber_degree = match certified_nonzero_degree(&fiber, config.min_precision) {
                Ok(degree) => degree,
                Err(()) => {
                    return report(
                        TrivariateConstraintResultantStatus::UndecidedCoefficient,
                        degree_bounds,
                        None,
                        None,
                    );
                }
            };
            let resultant = if fiber_degree.is_none() {
                Real::zero()
            } else {
                match resultant_univariate_polynomials(&constraint, &fiber, config.min_precision) {
                    Ok(resultant) => resultant.resultant,
                    Err(error) => {
                        return report(
                            TrivariateConstraintResultantStatus::ResultantError,
                            degree_bounds,
                            None,
                            Some(error),
                        );
                    }
                }
            };
            second_samples.push(PolynomialSample {
                parameter_value: second_value,
                value: resultant,
            });
        }
        let interpolated = match interpolate_samples(&second_samples, config.min_precision) {
            Ok(interpolated) => interpolated,
            Err(failure) => {
                return report(
                    trivariate_interpolation_status(failure),
                    degree_bounds,
                    None,
                    None,
                );
            }
        };
        second_axis_polynomials.push(interpolated);
    }

    let mut interpolated_columns = Vec::with_capacity(degree_bounds[1] + 1);
    for second_power in 0..=degree_bounds[1] {
        let first_samples = second_axis_polynomials
            .iter()
            .enumerate()
            .map(|(sample_index, polynomial)| PolynomialSample {
                parameter_value: Real::from(sample_index as u64),
                value: polynomial
                    .get(second_power)
                    .cloned()
                    .unwrap_or_else(Real::zero),
            })
            .collect::<Vec<_>>();
        let interpolated = match interpolate_samples(&first_samples, config.min_precision) {
            Ok(interpolated) => interpolated,
            Err(failure) => {
                return report(
                    trivariate_interpolation_status(failure),
                    degree_bounds,
                    None,
                    None,
                );
            }
        };
        interpolated_columns.push(interpolated);
    }
    let mut coefficients = vec![vec![Real::zero(); degree_bounds[1] + 1]; degree_bounds[0] + 1];
    for (second_power, column) in interpolated_columns.into_iter().enumerate() {
        for (row, coefficient) in coefficients.iter_mut().zip(column) {
            row[second_power] = coefficient;
        }
    }
    report(
        TrivariateConstraintResultantStatus::Constructed,
        degree_bounds,
        Some(canonical_exact_bivariate(coefficients)),
        None,
    )
}

/// Reconstructs one exact subresultant of a trivariate polynomial and a
/// univariate constraint on the selected tensor axis.
///
/// This is the multiplicity-preserving companion to
/// [`resultant_trivariate_polynomial_univariate_constraint`].  Order zero is
/// the ordinary resultant and remains owned by that function.  Higher orders
/// expose the first nonzero polynomial remainder in a selected algebraic
/// fiber, allowing a caller to recover its GCD even when the original
/// incidence has an even-multiplicity root.
/// A work budget charges one promotion before interpolation. The terminal
/// order reuses an input polynomial without a promotion charge; degree-limit
/// admission alone also spends no promotion unit.
pub fn subresultant_trivariate_polynomial_univariate_constraint(
    polynomial: &TrivariatePolynomial,
    constraint: &[Real],
    eliminated_axis: TrivariatePolynomialAxis,
    order: usize,
    config: CurveIntersectionResultantConfig,
) -> TrivariateConstraintSubresultantReport {
    let retained_axis_indices = match eliminated_axis {
        TrivariatePolynomialAxis::First => [1, 2],
        TrivariatePolynomialAxis::Second => [0, 2],
        TrivariatePolynomialAxis::Third => [0, 1],
    };
    let retained_axes = retained_axis_indices.map(trivariate_axis_from_index);
    let report = |status, degree_bounds, coefficients, determinant_error| {
        TrivariateConstraintSubresultantReport {
            status,
            eliminated_axis,
            retained_axes,
            order,
            degree_bounds,
            coefficients,
            determinant_error,
        }
    };
    if crate::work_budget::exhaustion().is_some() {
        return report(
            TrivariateConstraintSubresultantStatus::BudgetExhausted,
            [0, 0],
            Vec::new(),
            None,
        );
    }
    if trivariate_polynomial_is_empty(polynomial) || constraint.is_empty() {
        return report(
            TrivariateConstraintSubresultantStatus::EmptyPolynomial,
            [0, 0],
            Vec::new(),
            None,
        );
    }
    let degrees = match certified_trivariate_degree(polynomial, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariateConstraintSubresultantStatus::EmptyPolynomial,
                [0, 0],
                Vec::new(),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintSubresultantStatus::UndecidedCoefficient,
                [0, 0],
                Vec::new(),
                None,
            );
        }
    };
    let constraint = match trim_trailing_zeroes(constraint.to_vec(), config.min_precision) {
        Ok(constraint) => constraint,
        Err(()) => {
            return report(
                TrivariateConstraintSubresultantStatus::UndecidedCoefficient,
                [0, 0],
                Vec::new(),
                None,
            );
        }
    };
    if constraint.len() <= 1 {
        return report(
            TrivariateConstraintSubresultantStatus::InvalidConstraint,
            [0, 0],
            Vec::new(),
            None,
        );
    }
    let leading = constraint
        .last()
        .expect("a nonconstant constraint has a leading coefficient");
    let Ok(leading_reciprocal) =
        crate::policy_division::reciprocal_after_certified_nonzero(leading)
    else {
        return report(
            TrivariateConstraintSubresultantStatus::InterpolationDivisionFailed,
            [0, 0],
            Vec::new(),
            None,
        );
    };
    let constraint = constraint
        .iter()
        .map(|coefficient| coefficient * &leading_reciprocal)
        .collect::<Vec<_>>();

    let eliminated_index = eliminated_axis.index();
    let polynomial_degree = degrees[eliminated_index];
    let constraint_degree = constraint.len() - 1;
    let terminal_order = polynomial_degree.min(constraint_degree);
    if order == 0 || order > terminal_order {
        return report(
            TrivariateConstraintSubresultantStatus::InvalidOrder,
            [0, 0],
            Vec::new(),
            None,
        );
    }

    // The terminal subresultant is the smaller input itself.  Returning its
    // coefficient tensors directly avoids determinant sampling and also owns
    // equal-degree proportional fibers.
    if order == terminal_order {
        let coefficients = if polynomial_degree < constraint_degree {
            (0..=polynomial_degree)
                .map(|power| {
                    trivariate_axis_coefficient_bivariate(polynomial, eliminated_axis, power)
                })
                .collect()
        } else {
            constraint
                .iter()
                .map(|coefficient| BivariatePolynomial::new(vec![vec![coefficient.clone()]]))
                .collect()
        };
        let degree_bounds = if polynomial_degree < constraint_degree {
            retained_axis_indices.map(|axis| degrees[axis])
        } else {
            [0, 0]
        };
        return report(
            TrivariateConstraintSubresultantStatus::Constructed,
            degree_bounds,
            coefficients,
            None,
        );
    }

    // Only rows contributed by the trivariate operand carry retained-axis
    // degree. Every order-k minor contains `constraint_degree-k` such rows.
    let polynomial_row_count = constraint_degree - order;
    let degree_bounds =
        retained_axis_indices.map(|axis| polynomial_row_count.saturating_mul(degrees[axis]));
    if degree_bounds
        .into_iter()
        .any(|degree| degree > config.max_resultant_degree)
    {
        return report(
            TrivariateConstraintSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    let Some(first_sample_count) = degree_bounds[0].checked_add(1) else {
        return report(
            TrivariateConstraintSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    };
    let Some(second_sample_count) = degree_bounds[1].checked_add(1) else {
        return report(
            TrivariateConstraintSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    };

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return report(
            TrivariateConstraintSubresultantStatus::BudgetExhausted,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    let mut samples = (0..=order)
        .map(|_| vec![vec![Real::zero(); second_sample_count]; first_sample_count])
        .collect::<Vec<_>>();
    for first_sample in 0..first_sample_count {
        let first_value = Real::from(first_sample as u64);
        for second_sample in 0..second_sample_count {
            let second_value = Real::from(second_sample as u64);
            let mut fiber = evaluate_trivariate_at_retained_parameters(
                polynomial,
                eliminated_axis,
                &first_value,
                &second_value,
            );
            fiber.resize(polynomial_degree + 1, Real::zero());
            fiber.truncate(polynomial_degree + 1);
            let coefficients =
                match subresultant_coefficients(&fiber, &constraint, order, config.min_precision) {
                    Ok(coefficients) => coefficients,
                    Err(error) => {
                        return report(
                            TrivariateConstraintSubresultantStatus::DeterminantError,
                            degree_bounds,
                            Vec::new(),
                            Some(error),
                        );
                    }
                };
            for (coefficient_samples, coefficient) in samples.iter_mut().zip(coefficients) {
                coefficient_samples[first_sample][second_sample] = coefficient;
            }
        }
    }
    let Some(coefficients) = samples
        .iter()
        .map(|samples| interpolate_rectangular_tensor_grid(samples, config.min_precision))
        .collect::<Option<Vec<_>>>()
    else {
        return report(
            TrivariateConstraintSubresultantStatus::InterpolationDivisionFailed,
            degree_bounds,
            Vec::new(),
            None,
        );
    };
    report(
        TrivariateConstraintSubresultantStatus::Constructed,
        degree_bounds,
        coefficients,
        None,
    )
}

/// Reconstructs one exact subresultant of two trivariate polynomials.
///
/// Both operands keep their two retained axes symbolic while the requested
/// eliminated-axis subresultant is sampled on an exact integer tensor grid.
/// Nominal eliminated-axis degrees are preserved at every sample, so a
/// leading coefficient which vanishes only at one grid point does not change
/// the represented Sylvester minor. Order zero returns the resultant as one
/// constant coefficient polynomial.
/// A work budget charges one promotion before interpolation, after degree and
/// order admission. A terminal-order input polynomial needs no new promotion.
pub fn subresultant_trivariate_polynomial_system(
    first: &TrivariatePolynomial,
    second: &TrivariatePolynomial,
    eliminated_axis: TrivariatePolynomialAxis,
    order: usize,
    config: CurveIntersectionResultantConfig,
) -> TrivariatePolynomialSystemSubresultantReport {
    let retained_axis_indices = match eliminated_axis {
        TrivariatePolynomialAxis::First => [1, 2],
        TrivariatePolynomialAxis::Second => [0, 2],
        TrivariatePolynomialAxis::Third => [0, 1],
    };
    let retained_axes = retained_axis_indices.map(trivariate_axis_from_index);
    let report = |status, degree_bounds, coefficients, determinant_error| {
        TrivariatePolynomialSystemSubresultantReport {
            status,
            eliminated_axis,
            retained_axes,
            order,
            degree_bounds,
            coefficients,
            determinant_error,
        }
    };
    if crate::work_budget::exhaustion().is_some() {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::BudgetExhausted,
            [0, 0],
            Vec::new(),
            None,
        );
    }
    if trivariate_polynomial_is_empty(first) || trivariate_polynomial_is_empty(second) {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::EmptyPolynomial,
            [0, 0],
            Vec::new(),
            None,
        );
    }
    let first_degrees = match certified_trivariate_degree(first, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariatePolynomialSystemSubresultantStatus::EmptyPolynomial,
                [0, 0],
                Vec::new(),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariatePolynomialSystemSubresultantStatus::UndecidedCoefficient,
                [0, 0],
                Vec::new(),
                None,
            );
        }
    };
    let second_degrees = match certified_trivariate_degree(second, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariatePolynomialSystemSubresultantStatus::EmptyPolynomial,
                [0, 0],
                Vec::new(),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariatePolynomialSystemSubresultantStatus::UndecidedCoefficient,
                [0, 0],
                Vec::new(),
                None,
            );
        }
    };

    let eliminated_index = eliminated_axis.index();
    let first_degree = first_degrees[eliminated_index];
    let second_degree = second_degrees[eliminated_index];
    let terminal_order = first_degree.min(second_degree);
    if order > terminal_order {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::InvalidOrder,
            [0, 0],
            Vec::new(),
            None,
        );
    }

    // At terminal order the smaller input is the subresultant. If both
    // degrees are equal, either input is valid once every lower order has
    // vanished in the selected retained fiber; use the second consistently.
    if order > 0 && order == terminal_order {
        let (polynomial, degrees) = if first_degree < second_degree {
            (first, first_degrees)
        } else {
            (second, second_degrees)
        };
        let coefficients = (0..=terminal_order)
            .map(|power| trivariate_axis_coefficient_bivariate(polynomial, eliminated_axis, power))
            .collect();
        return report(
            TrivariatePolynomialSystemSubresultantStatus::Constructed,
            retained_axis_indices.map(|axis| degrees[axis]),
            coefficients,
            None,
        );
    }

    let first_row_count = second_degree - order;
    let second_row_count = first_degree - order;
    let degree_bounds = retained_axis_indices.map(|axis| {
        first_row_count
            .saturating_mul(first_degrees[axis])
            .saturating_add(second_row_count.saturating_mul(second_degrees[axis]))
    });
    if degree_bounds
        .into_iter()
        .any(|degree| degree > config.max_resultant_degree)
    {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    let Some(first_sample_count) = degree_bounds[0].checked_add(1) else {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    };
    let Some(second_sample_count) = degree_bounds[1].checked_add(1) else {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    };

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::BudgetExhausted,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    let mut samples = (0..=order)
        .map(|_| vec![vec![Real::zero(); second_sample_count]; first_sample_count])
        .collect::<Vec<_>>();
    for first_sample in 0..first_sample_count {
        let first_value = Real::from(first_sample as u64);
        for second_sample in 0..second_sample_count {
            let second_value = Real::from(second_sample as u64);
            let mut first_fiber = evaluate_trivariate_at_retained_parameters(
                first,
                eliminated_axis,
                &first_value,
                &second_value,
            );
            let mut second_fiber = evaluate_trivariate_at_retained_parameters(
                second,
                eliminated_axis,
                &first_value,
                &second_value,
            );
            first_fiber.resize(first_degree + 1, Real::zero());
            first_fiber.truncate(first_degree + 1);
            second_fiber.resize(second_degree + 1, Real::zero());
            second_fiber.truncate(second_degree + 1);
            let coefficients = if order == 0 {
                match determinant_bareiss(
                    &sylvester_matrix(&first_fiber, &second_fiber),
                    config.min_precision,
                ) {
                    Ok(result) => vec![result.determinant],
                    Err(error) => {
                        return report(
                            TrivariatePolynomialSystemSubresultantStatus::DeterminantError,
                            degree_bounds,
                            Vec::new(),
                            Some(error),
                        );
                    }
                }
            } else {
                match subresultant_coefficients(
                    &first_fiber,
                    &second_fiber,
                    order,
                    config.min_precision,
                ) {
                    Ok(coefficients) => coefficients,
                    Err(error) => {
                        return report(
                            TrivariatePolynomialSystemSubresultantStatus::DeterminantError,
                            degree_bounds,
                            Vec::new(),
                            Some(error),
                        );
                    }
                }
            };
            for (coefficient_samples, coefficient) in samples.iter_mut().zip(coefficients) {
                coefficient_samples[first_sample][second_sample] = coefficient;
            }
        }
    }
    let Some(coefficients) = samples
        .iter()
        .map(|samples| interpolate_rectangular_tensor_grid(samples, config.min_precision))
        .collect::<Option<Vec<_>>>()
    else {
        return report(
            TrivariatePolynomialSystemSubresultantStatus::InterpolationDivisionFailed,
            degree_bounds,
            Vec::new(),
            None,
        );
    };
    report(
        TrivariatePolynomialSystemSubresultantStatus::Constructed,
        degree_bounds,
        coefficients,
        None,
    )
}

/// Eliminates the fourth axis of a quadrivariate polynomial under a
/// univariate algebraic constraint on that axis.
///
/// This is the four-field counterpart of
/// [`resultant_trivariate_polynomial_univariate_constraint`].  Only the fourth
/// axis is exposed deliberately: geometry callers use the first three axes as
/// an already selected coefficient field and need one additional fiber GCD,
/// not a general-purpose four-variable elimination package.
/// A work budget charges one promotion after degree admission, before the
/// interpolation grid is constructed. Exhaustion returns no resultant.
pub fn resultant_quadrivariate_polynomial_fourth_axis_constraint(
    polynomial: &QuadrivariatePolynomial,
    constraint: &[Real],
    config: CurveIntersectionResultantConfig,
) -> QuadrivariateConstraintResultantReport {
    let report = |status, degree_bounds, resultant, resultant_error| {
        QuadrivariateConstraintResultantReport {
            status,
            degree_bounds,
            resultant,
            resultant_error,
        }
    };
    if crate::work_budget::exhaustion().is_some() {
        return report(
            TrivariateConstraintResultantStatus::BudgetExhausted,
            [0, 0, 0],
            None,
            None,
        );
    }
    if quadrivariate_polynomial_is_empty(polynomial) || constraint.is_empty() {
        return report(
            TrivariateConstraintResultantStatus::EmptyPolynomial,
            [0, 0, 0],
            None,
            None,
        );
    }
    let degrees = match certified_quadrivariate_degree(polynomial, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariateConstraintResultantStatus::Constructed,
                [0, 0, 0],
                Some(TrivariatePolynomial::new(vec![vec![vec![Real::zero()]]])),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintResultantStatus::UndecidedCoefficient,
                [0, 0, 0],
                None,
                None,
            );
        }
    };
    let constraint = match normalized_constraint(constraint, config.min_precision) {
        Ok(Some(constraint)) => constraint,
        Ok(None) => {
            return report(
                TrivariateConstraintResultantStatus::InvalidConstraint,
                [0, 0, 0],
                None,
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintResultantStatus::UndecidedCoefficient,
                [0, 0, 0],
                None,
                None,
            );
        }
    };
    let constraint_degree = constraint.len() - 1;
    let degree_bounds = std::array::from_fn(|axis| constraint_degree.saturating_mul(degrees[axis]));
    if quadrivariate_grid_exceeds_budget(degree_bounds, config.max_resultant_degree) {
        return report(
            TrivariateConstraintResultantStatus::DegreeBoundExceeded,
            degree_bounds,
            None,
            None,
        );
    }

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return report(
            TrivariateConstraintResultantStatus::BudgetExhausted,
            degree_bounds,
            None,
            None,
        );
    }
    let mut samples = vec![
        vec![vec![Real::zero(); degree_bounds[2] + 1]; degree_bounds[1] + 1];
        degree_bounds[0] + 1
    ];
    for (first, first_samples) in samples.iter_mut().enumerate() {
        let first_value = Real::from(first as u64);
        for (second, second_samples) in first_samples.iter_mut().enumerate() {
            let second_value = Real::from(second as u64);
            for (third, sample) in second_samples.iter_mut().enumerate() {
                let third_value = Real::from(third as u64);
                let fiber = evaluate_quadrivariate_at_first_three_parameters(
                    polynomial,
                    &first_value,
                    &second_value,
                    &third_value,
                );
                let fiber_degree = match certified_nonzero_degree(&fiber, config.min_precision) {
                    Ok(degree) => degree,
                    Err(()) => {
                        return report(
                            TrivariateConstraintResultantStatus::UndecidedCoefficient,
                            degree_bounds,
                            None,
                            None,
                        );
                    }
                };
                *sample = if fiber_degree.is_none() {
                    Real::zero()
                } else {
                    match resultant_univariate_polynomials(
                        &constraint,
                        &fiber,
                        config.min_precision,
                    ) {
                        Ok(resultant) => resultant.resultant,
                        Err(error) => {
                            return report(
                                TrivariateConstraintResultantStatus::ResultantError,
                                degree_bounds,
                                None,
                                Some(error),
                            );
                        }
                    }
                };
            }
        }
    }
    let Some(resultant) = interpolate_rectangular_tensor_cube(&samples, config.min_precision)
    else {
        return report(
            TrivariateConstraintResultantStatus::InterpolationDivisionFailed,
            degree_bounds,
            None,
            None,
        );
    };
    report(
        TrivariateConstraintResultantStatus::Constructed,
        degree_bounds,
        Some(resultant),
        None,
    )
}

/// Reconstructs one positive-order fourth-axis subresultant with trivariate
/// coefficients.
///
/// Together with
/// [`resultant_quadrivariate_polynomial_fourth_axis_constraint`], scanning
/// orders from one upward recovers the exact GCD in a selected three-root
/// coefficient fiber, including an even-multiplicity fourth-axis contact.
/// A work budget charges one promotion before interpolation. Degree-limit
/// admission and terminal-order reuse do not spend a promotion unit.
pub fn subresultant_quadrivariate_polynomial_fourth_axis_constraint(
    polynomial: &QuadrivariatePolynomial,
    constraint: &[Real],
    order: usize,
    config: CurveIntersectionResultantConfig,
) -> QuadrivariateConstraintSubresultantReport {
    let report = |status, degree_bounds, coefficients, determinant_error| {
        QuadrivariateConstraintSubresultantReport {
            status,
            order,
            degree_bounds,
            coefficients,
            determinant_error,
        }
    };
    if crate::work_budget::exhaustion().is_some() {
        return report(
            TrivariateConstraintSubresultantStatus::BudgetExhausted,
            [0, 0, 0],
            Vec::new(),
            None,
        );
    }
    if quadrivariate_polynomial_is_empty(polynomial) || constraint.is_empty() {
        return report(
            TrivariateConstraintSubresultantStatus::EmptyPolynomial,
            [0, 0, 0],
            Vec::new(),
            None,
        );
    }
    let degrees = match certified_quadrivariate_degree(polynomial, config.min_precision) {
        Ok(Some(degrees)) => degrees,
        Ok(None) => {
            return report(
                TrivariateConstraintSubresultantStatus::EmptyPolynomial,
                [0, 0, 0],
                Vec::new(),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintSubresultantStatus::UndecidedCoefficient,
                [0, 0, 0],
                Vec::new(),
                None,
            );
        }
    };
    let constraint = match normalized_constraint(constraint, config.min_precision) {
        Ok(Some(constraint)) => constraint,
        Ok(None) => {
            return report(
                TrivariateConstraintSubresultantStatus::InvalidConstraint,
                [0, 0, 0],
                Vec::new(),
                None,
            );
        }
        Err(()) => {
            return report(
                TrivariateConstraintSubresultantStatus::UndecidedCoefficient,
                [0, 0, 0],
                Vec::new(),
                None,
            );
        }
    };
    let polynomial_degree = degrees[3];
    let constraint_degree = constraint.len() - 1;
    let terminal_order = polynomial_degree.min(constraint_degree);
    if order == 0 || order > terminal_order {
        return report(
            TrivariateConstraintSubresultantStatus::InvalidOrder,
            [0, 0, 0],
            Vec::new(),
            None,
        );
    }
    if order == terminal_order {
        let coefficients = if polynomial_degree < constraint_degree {
            (0..=polynomial_degree)
                .map(|power| quadrivariate_fourth_axis_coefficient(polynomial, power))
                .collect()
        } else {
            constraint
                .iter()
                .map(|coefficient| TrivariatePolynomial::new(vec![vec![vec![coefficient.clone()]]]))
                .collect()
        };
        let degree_bounds = if polynomial_degree < constraint_degree {
            [degrees[0], degrees[1], degrees[2]]
        } else {
            [0, 0, 0]
        };
        return report(
            TrivariateConstraintSubresultantStatus::Constructed,
            degree_bounds,
            coefficients,
            None,
        );
    }

    let polynomial_row_count = constraint_degree - order;
    let degree_bounds =
        std::array::from_fn(|axis| polynomial_row_count.saturating_mul(degrees[axis]));
    if quadrivariate_grid_exceeds_budget(degree_bounds, config.max_resultant_degree) {
        return report(
            TrivariateConstraintSubresultantStatus::DegreeBoundExceeded,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return report(
            TrivariateConstraintSubresultantStatus::BudgetExhausted,
            degree_bounds,
            Vec::new(),
            None,
        );
    }
    let mut samples = (0..=order)
        .map(|_| {
            vec![
                vec![vec![Real::zero(); degree_bounds[2] + 1]; degree_bounds[1] + 1];
                degree_bounds[0] + 1
            ]
        })
        .collect::<Vec<_>>();
    for first in 0..=degree_bounds[0] {
        let first_value = Real::from(first as u64);
        for second in 0..=degree_bounds[1] {
            let second_value = Real::from(second as u64);
            for third in 0..=degree_bounds[2] {
                let third_value = Real::from(third as u64);
                let mut fiber = evaluate_quadrivariate_at_first_three_parameters(
                    polynomial,
                    &first_value,
                    &second_value,
                    &third_value,
                );
                fiber.resize(polynomial_degree + 1, Real::zero());
                fiber.truncate(polynomial_degree + 1);
                let coefficients = match subresultant_coefficients(
                    &fiber,
                    &constraint,
                    order,
                    config.min_precision,
                ) {
                    Ok(coefficients) => coefficients,
                    Err(error) => {
                        return report(
                            TrivariateConstraintSubresultantStatus::DeterminantError,
                            degree_bounds,
                            Vec::new(),
                            Some(error),
                        );
                    }
                };
                for (coefficient_samples, coefficient) in samples.iter_mut().zip(coefficients) {
                    coefficient_samples[first][second][third] = coefficient;
                }
            }
        }
    }
    let Some(coefficients) = samples
        .iter()
        .map(|samples| interpolate_rectangular_tensor_cube(samples, config.min_precision))
        .collect::<Option<Vec<_>>>()
    else {
        return report(
            TrivariateConstraintSubresultantStatus::InterpolationDivisionFailed,
            degree_bounds,
            Vec::new(),
            None,
        );
    };
    report(
        TrivariateConstraintSubresultantStatus::Constructed,
        degree_bounds,
        coefficients,
        None,
    )
}

fn trivariate_axis_coefficient_bivariate(
    polynomial: &TrivariatePolynomial,
    eliminated_axis: TrivariatePolynomialAxis,
    power: usize,
) -> BivariatePolynomial {
    let dimensions = [
        polynomial.coefficients.len(),
        polynomial
            .coefficients
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0),
        polynomial
            .coefficients
            .iter()
            .flat_map(|rows| rows.iter())
            .map(Vec::len)
            .max()
            .unwrap_or(0),
    ];
    let eliminated_index = eliminated_axis.index();
    let retained_axes = match eliminated_axis {
        TrivariatePolynomialAxis::First => [1, 2],
        TrivariatePolynomialAxis::Second => [0, 2],
        TrivariatePolynomialAxis::Third => [0, 1],
    };
    let mut coefficients =
        vec![vec![Real::zero(); dimensions[retained_axes[1]]]; dimensions[retained_axes[0]]];
    for (first, rows) in polynomial.coefficients.iter().enumerate() {
        for (second, row) in rows.iter().enumerate() {
            for (third, coefficient) in row.iter().enumerate() {
                let exponents = [first, second, third];
                if exponents[eliminated_index] == power {
                    coefficients[exponents[retained_axes[0]]][exponents[retained_axes[1]]] =
                        coefficient.clone();
                }
            }
        }
    }
    canonical_exact_bivariate(coefficients)
}

fn interpolate_rectangular_tensor_grid(
    samples: &[Vec<Real>],
    min_precision: i32,
) -> Option<BivariatePolynomial> {
    let first_count = samples.len();
    let second_count = samples.first()?.len();
    if first_count == 0 || second_count == 0 || samples.iter().any(|row| row.len() != second_count)
    {
        return None;
    }
    let second_polynomials = samples
        .iter()
        .map(|row| {
            let samples = row
                .iter()
                .enumerate()
                .map(|(second, value)| PolynomialSample {
                    parameter_value: Real::from(second as u64),
                    value: value.clone(),
                })
                .collect::<Vec<_>>();
            interpolate_samples(&samples, min_precision).ok()
        })
        .collect::<Option<Vec<_>>>()?;
    let mut columns = Vec::with_capacity(second_count);
    for second_power in 0..second_count {
        let samples = second_polynomials
            .iter()
            .enumerate()
            .map(|(first, polynomial)| PolynomialSample {
                parameter_value: Real::from(first as u64),
                value: polynomial
                    .get(second_power)
                    .cloned()
                    .unwrap_or_else(Real::zero),
            })
            .collect::<Vec<_>>();
        columns.push(interpolate_samples(&samples, min_precision).ok()?);
    }
    let mut coefficients = vec![vec![Real::zero(); second_count]; first_count];
    for (second_power, column) in columns.into_iter().enumerate() {
        for (row, coefficient) in coefficients.iter_mut().zip(column) {
            row[second_power] = coefficient;
        }
    }
    Some(canonical_exact_bivariate(coefficients))
}

fn interpolate_rectangular_tensor_cube(
    samples: &[Vec<Vec<Real>>],
    min_precision: i32,
) -> Option<TrivariatePolynomial> {
    let first_count = samples.len();
    let second_count = samples.first()?.len();
    let third_count = samples.first()?.first()?.len();
    if first_count == 0
        || second_count == 0
        || third_count == 0
        || samples.iter().any(|plane| {
            plane.len() != second_count || plane.iter().any(|row| row.len() != third_count)
        })
    {
        return None;
    }
    let trailing_polynomials = samples
        .iter()
        .map(|plane| interpolate_rectangular_tensor_grid(plane, min_precision))
        .collect::<Option<Vec<_>>>()?;
    let mut coefficients = vec![vec![vec![Real::zero(); third_count]; second_count]; first_count];
    for (second_power, row) in samples[0].iter().enumerate() {
        for (third_power, _) in row.iter().enumerate() {
            let first_samples = trailing_polynomials
                .iter()
                .enumerate()
                .map(|(first, polynomial)| PolynomialSample {
                    parameter_value: Real::from(first as u64),
                    value: polynomial
                        .coefficients
                        .get(second_power)
                        .and_then(|row| row.get(third_power))
                        .cloned()
                        .unwrap_or_else(Real::zero),
                })
                .collect::<Vec<_>>();
            let first_polynomial = interpolate_samples(&first_samples, min_precision).ok()?;
            for (first_power, coefficient) in first_polynomial.into_iter().enumerate() {
                coefficients[first_power][second_power][third_power] = coefficient;
            }
        }
    }
    Some(canonical_exact_trivariate(coefficients))
}

/// Final status for a curve intersection resultant report.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CurveIntersectionResultantStatus {
    /// The retained-parameter resultant polynomial was constructed exactly.
    Constructed,
    /// The enclosing operation declined this algebraic elimination.
    BudgetExhausted,
    /// At least one coordinate polynomial was empty.
    EmptyCoordinatePolynomial,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// The conservative resultant degree bound exceeded the configured budget.
    DegreeBoundExceeded,
    /// A sampled Sylvester resultant failed.
    ResultantError,
    /// Exact interpolation required a division that failed.
    InterpolationDivisionFailed,
    /// A homogeneous rational curve had certified zero weight everywhere.
    InvalidHomogeneousWeight,
}

/// Temporary exact values used only by polynomial interpolation.
struct PolynomialSample {
    parameter_value: Real,
    value: Real,
}

/// Exact report for eliminating one parameter from two parametric curves.
#[derive(Clone, Debug, PartialEq)]
pub struct CurveIntersectionResultantReport {
    /// Final construction status.
    pub status: CurveIntersectionResultantStatus,
    /// Parameter that remains in `resultant_coefficients`.
    pub retained_parameter: CurveResultantParameter,
    /// Parameter eliminated by the Sylvester resultant.
    pub eliminated_parameter: CurveResultantParameter,
    /// Conservative degree bound used to choose interpolation samples.
    pub degree_bound: usize,
    /// Resultant polynomial coefficients in ascending retained-parameter power
    /// order. Empty unless `status == Constructed`.
    pub resultant_coefficients: Vec<Real>,
    /// Sampled resultant error, if construction failed at that boundary.
    pub resultant_error: Option<UnivariateResultantError>,
}

/// Final status for a rational lift of the eliminated system parameter.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CurveIntersectionParameterLiftStatus {
    /// Every requested parameter-recovery polynomial was constructed exactly.
    Constructed,
    /// The enclosing operation declined this cofactor interpolation.
    BudgetExhausted,
    /// At least one bivariate equation was empty.
    EmptyEquation,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// One equation is constant in the eliminated parameter, so a linear
    /// common-root lift cannot certify the pairing.
    UnsupportedEliminatedDegree,
    /// The conservative cofactor degree exceeded the configured budget.
    DegreeBoundExceeded,
    /// An exact cofactor determinant could not be constructed.
    DeterminantError,
    /// Exact cofactor interpolation or trimming did not complete.
    InterpolationFailed,
}

/// One exact adjugate ratio for lifting the eliminated parameter.
///
/// At a retained root where the specialized Sylvester matrix has nullity one,
/// at least one returned denominator is nonzero and
/// `eliminated = numerator(retained) / denominator(retained)`.
#[derive(Clone, Debug, PartialEq)]
pub struct CurveIntersectionParameterLiftMap {
    /// Sylvester row whose two signed cofactors define this ratio.
    pub cofactor_row: usize,
    /// Numerator coefficients in ascending retained-parameter power order.
    pub numerator_coefficients: Vec<Real>,
    /// Denominator coefficients in ascending retained-parameter power order.
    pub denominator_coefficients: Vec<Real>,
}

/// Exact report for linear common-root lifts of one bivariate system parameter.
#[derive(Clone, Debug, PartialEq)]
pub struct CurveIntersectionParameterLiftReport {
    /// Final construction status.
    pub status: CurveIntersectionParameterLiftStatus,
    /// Parameter supplied to every returned rational map.
    pub retained_parameter: CurveResultantParameter,
    /// Parameter produced by every returned rational map.
    pub lifted_parameter: CurveResultantParameter,
    /// Conservative interpolation degree used for every signed cofactor.
    pub degree_bound: usize,
    /// Candidate adjugate ratios. Identically zero denominators are omitted.
    pub maps: Vec<CurveIntersectionParameterLiftMap>,
    /// Exact determinant failure, when construction stopped at that boundary.
    pub determinant_error: Option<BareissError>,
}

/// Final status for one generic positive-dimensional component of a bivariate system.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum BivariatePolynomialComponentStatus {
    /// The active operation budget declined common-component discovery.
    BudgetExhausted,
    /// A rational map for one generic linear fiber factor was constructed.
    Rational,
    /// A non-linear generic common-fiber polynomial was constructed exactly.
    Implicit,
    /// At least one bivariate equation was empty.
    EmptyEquation,
    /// A coefficient remained unknown after bounded refinement and the strict
    /// exact predicate cascade.
    UndecidedCoefficient,
    /// One equation is constant in the prospective lifted parameter.
    UnsupportedLiftedDegree,
    /// The conservative coefficient degree exceeded the configured budget.
    DegreeBoundExceeded,
    /// No supported component could be extracted from the generic common fiber.
    NoSupportedComponent,
    /// An exact subresultant determinant could not be constructed.
    DeterminantError,
    /// Exact coefficient interpolation did not complete.
    InterpolationFailed,
    /// The constructed component did not divide both authored equations exactly.
    DivisionFailed,
}

/// One exact positive-dimensional bivariate component and its residual system.
///
/// When `status` is [`BivariatePolynomialComponentStatus::Rational`],
/// the prospective lifted parameter is `numerator(retained) / denominator(retained)`.
/// When it is [`BivariatePolynomialComponentStatus::Implicit`],
/// `implicit_component` contains the primitive bivariate common-fiber
/// polynomial. Geometry callers must still certify the finite real branches
/// admitted by the authored parameter domains and geometric predicates.
#[derive(Clone, Debug, PartialEq)]
pub struct BivariatePolynomialComponentReport {
    /// Final construction status.
    pub status: BivariatePolynomialComponentStatus,
    /// Parameter retained while constructing the generic common fiber.
    pub retained_parameter: CurveResultantParameter,
    /// Parameter lifted by the generic common fiber.
    pub lifted_parameter: CurveResultantParameter,
    /// Conservative interpolation degree used by the selected exact
    /// reconstruction lane.
    pub degree_bound: usize,
    /// Rational-map numerator in ascending retained-parameter power order.
    pub numerator_coefficients: Vec<Real>,
    /// Rational-map denominator in ascending retained-parameter power order.
    pub denominator_coefficients: Vec<Real>,
    /// Primitive non-linear common-fiber polynomial, when the component is not
    /// representable by a supported rational-linear map.
    pub implicit_component: Option<BivariatePolynomial>,
    /// Both authored equations after exact division by the published component.
    /// Present for rational and implicit component reports.
    ///
    /// Geometry callers must solve this residual system as well as transport
    /// the positive-dimensional component. A component and isolated contacts
    /// may coexist in one authored system.
    pub reduced_equations: Option<[BivariatePolynomial; 2]>,
    /// Exact determinant failure, when construction stopped at that boundary.
    pub determinant_error: Option<BareissError>,
}

/// Eliminates one parameter from two exact bivariate polynomial equations.
///
/// Both equations use [`BivariatePolynomial`]'s `(first, second)` coefficient
/// order. Rational systems of modest dimension use a fraction-free polynomial
/// determinant. Other systems use exact interpolation, skipping the finitely
/// many specializations whose eliminated-variable degree drops. Only the
/// resulting polynomial is retained. It is candidate evidence only; callers
/// must replay isolated roots against their original equations and geometric
/// branch conditions.
/// A work budget charges one promotion after degree admission, before the
/// determinant or interpolation. A declined degree limit consumes no promotion
/// unit, so the complete continuation shares the same remaining allowance.
pub fn resultant_bivariate_polynomial_system(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionResultantReport {
    let eliminated_parameter = match retained_parameter {
        CurveResultantParameter::First => CurveResultantParameter::Second,
        CurveResultantParameter::Second => CurveResultantParameter::First,
    };
    if crate::work_budget::exhaustion().is_some() {
        return exhausted_resultant_report(retained_parameter, 0);
    }
    if bivariate_polynomial_is_empty(first_equation)
        || bivariate_polynomial_is_empty(second_equation)
    {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::EmptyCoordinatePolynomial,
            retained_parameter,
            eliminated_parameter,
            0,
            Vec::new(),
            None,
        );
    }

    let Ok(first_degree) = certified_bivariate_degree(first_equation, config.min_precision) else {
        return undecided_report(retained_parameter, eliminated_parameter);
    };
    let Ok(second_degree) = certified_bivariate_degree(second_equation, config.min_precision)
    else {
        return undecided_report(retained_parameter, eliminated_parameter);
    };
    if first_degree.is_none() || second_degree.is_none() {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::Constructed,
            retained_parameter,
            eliminated_parameter,
            0,
            vec![Real::zero()],
            None,
        );
    }
    let first_degree = first_degree.expect("nonzero bivariate equation has a bidegree");
    let second_degree = second_degree.expect("nonzero bivariate equation has a bidegree");
    let (first_retained_degree, first_eliminated_degree) =
        oriented_bidegree(first_degree, retained_parameter);
    let (second_retained_degree, second_eliminated_degree) =
        oriented_bidegree(second_degree, retained_parameter);
    let degree_bound = second_eliminated_degree * first_retained_degree
        + first_eliminated_degree * second_retained_degree;
    if degree_bound > config.max_resultant_degree {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::DegreeBoundExceeded,
            retained_parameter,
            eliminated_parameter,
            degree_bound,
            Vec::new(),
            None,
        );
    }

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return exhausted_resultant_report(retained_parameter, degree_bound);
    }

    // Rational coefficient systems with a modest determinant dimension are
    // substantially cheaper to eliminate as one polynomial determinant than
    // as `degree_bound + 1` independent exact determinants followed by dense
    // interpolation. Equal eliminated degrees use the half-size Bezout matrix;
    // other small systems retain sparse Sylvester rows. Fraction-free
    // polynomial elimination keeps intermediate degrees at minor size and
    // uses quadratic matrix storage instead of exponential subset state.
    // Publish that polynomial directly: interpolation samples are temporary
    // construction data, not additional elimination evidence.
    let sylvester_dimension = first_eliminated_degree + second_eliminated_degree;
    let rational_coefficients = bivariate_has_only_rational_coefficients(first_equation)
        && bivariate_has_only_rational_coefficients(second_equation);
    let symbolic_resultant = rational_coefficients
        .then(|| {
            if first_eliminated_degree == second_eliminated_degree && first_eliminated_degree <= 12
            {
                symbolic_bivariate_bezout_resultant(
                    first_equation,
                    second_equation,
                    retained_parameter,
                    first_eliminated_degree,
                )
            } else if sylvester_dimension <= 12 {
                symbolic_bivariate_sylvester_resultant(
                    first_equation,
                    second_equation,
                    retained_parameter,
                    first_eliminated_degree,
                    second_eliminated_degree,
                )
            } else {
                None
            }
        })
        .flatten();
    if let Some(resultant_coefficients) = symbolic_resultant {
        let Ok(resultant_coefficients) =
            trim_trailing_zeroes(resultant_coefficients, config.min_precision)
        else {
            return undecided_report(retained_parameter, eliminated_parameter);
        };
        return curve_resultant_report(
            CurveIntersectionResultantStatus::Constructed,
            retained_parameter,
            eliminated_parameter,
            degree_bound,
            resultant_coefficients,
            None,
        );
    }

    let mut samples = Vec::with_capacity(degree_bound + 1);
    let mut index = 0_usize;
    while samples.len() <= degree_bound {
        let parameter_value = Real::from(index as u64);
        index += 1;
        let mut first = evaluate_bivariate_at_retained_parameter(
            first_equation,
            &parameter_value,
            retained_parameter,
        );
        let mut second = evaluate_bivariate_at_retained_parameter(
            second_equation,
            &parameter_value,
            retained_parameter,
        );
        // Existing curve-resultant callers define both coordinate differences
        // as retained minus eliminated. Preserve that orientation when the
        // second authored parameter is retained.
        if retained_parameter == CurveResultantParameter::Second {
            first
                .iter_mut()
                .for_each(|coefficient| *coefficient = -coefficient.clone());
            second
                .iter_mut()
                .for_each(|coefficient| *coefficient = -coefficient.clone());
        }
        let (Ok(first_sample_degree), Ok(second_sample_degree)) = (
            certified_nonzero_degree(&first, config.min_precision),
            certified_nonzero_degree(&second, config.min_precision),
        ) else {
            return undecided_report(retained_parameter, eliminated_parameter);
        };
        // Specializing the retained parameter may cancel an eliminated
        // leading coefficient. A lower-degree Sylvester determinant is not the
        // specialization of the generic resultant, so replace that sample.
        if first_sample_degree != Some(first_eliminated_degree)
            || second_sample_degree != Some(second_eliminated_degree)
        {
            continue;
        }
        // Rationality was established from every original coefficient, so
        // specialization stays in that exact field. Samples need only the
        // value; constructing and discarding pivot reports loses useful work.
        let sampled = if rational_coefficients {
            resultant_exact_rational_polynomials_value(&first, &second, config.min_precision)
        } else {
            resultant_univariate_polynomials(&first, &second, config.min_precision)
                .map(|report| report.resultant)
        };
        let resultant = match sampled {
            Ok(value) => value,
            Err(error) => {
                return curve_resultant_report(
                    CurveIntersectionResultantStatus::ResultantError,
                    retained_parameter,
                    eliminated_parameter,
                    degree_bound,
                    Vec::new(),
                    Some(error),
                );
            }
        };
        samples.push(PolynomialSample {
            parameter_value,
            value: resultant,
        });
    }

    let resultant_coefficients = match interpolate_samples(&samples, config.min_precision) {
        Ok(coefficients) => coefficients,
        Err(failure) => {
            return curve_resultant_report(
                match failure {
                    InterpolationFailure::Division => {
                        CurveIntersectionResultantStatus::InterpolationDivisionFailed
                    }
                    InterpolationFailure::UndecidedCoefficient => {
                        CurveIntersectionResultantStatus::UndecidedCoefficient
                    }
                },
                retained_parameter,
                eliminated_parameter,
                degree_bound,
                Vec::new(),
                None,
            );
        }
    };
    let Ok(resultant_coefficients) =
        trim_trailing_zeroes(resultant_coefficients, config.min_precision)
    else {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::UndecidedCoefficient,
            retained_parameter,
            eliminated_parameter,
            degree_bound,
            Vec::new(),
            None,
        );
    };
    curve_resultant_report(
        CurveIntersectionResultantStatus::Constructed,
        retained_parameter,
        eliminated_parameter,
        degree_bound,
        resultant_coefficients,
        None,
    )
}

fn bivariate_has_only_rational_coefficients(polynomial: &BivariatePolynomial) -> bool {
    polynomial
        .coefficients
        .iter()
        .flatten()
        .all(|coefficient| coefficient.exact_rational_ref().is_some())
}

// The generic coefficient builder reuses every native arithmetic and zero
// decision, in the original order. The determinant remains integer Bareiss.
struct NativePolynomialArithmetic;
impl crate::bareiss::DeterminantArithmetic<Vec<Real>> for NativePolynomialArithmetic {
    type Error = std::convert::Infallible;
    fn constant(&mut self, value: &Real) -> Result<Vec<Real>, Self::Error> {
        Ok(vec![value.clone()])
    }
    fn add(&mut self, a: &Vec<Real>, b: &Vec<Real>) -> Result<Vec<Real>, Self::Error> {
        Ok(add_exact_polynomials(a, b))
    }
    fn multiply(&mut self, a: &Vec<Real>, b: &Vec<Real>) -> Result<Vec<Real>, Self::Error> {
        Ok(multiply_exact_polynomials(a, b))
    }
    fn scale(&mut self, value: &Vec<Real>, scale: &Real) -> Result<Vec<Real>, Self::Error> {
        Ok(scale_exact_polynomial(value, scale))
    }
    fn negate(&mut self, value: Vec<Real>) -> Result<Vec<Real>, Self::Error> {
        Ok(value.into_iter().map(|c| -c).collect())
    }
}
impl crate::resultant::BezoutArithmetic<Vec<Real>> for NativePolynomialArithmetic {
    fn subtract(&mut self, a: &Vec<Real>, b: &Vec<Real>) -> Result<Vec<Real>, Self::Error> {
        Ok(subtract_exact_polynomials(a, b))
    }
    fn is_zero(&mut self, value: &Vec<Real>) -> Result<bool, Self::Error> {
        Ok(exact_polynomial_is_zero(value))
    }
}

fn symbolic_bivariate_bezout_resultant(
    first: &BivariatePolynomial,
    second: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    eliminated_degree: usize,
) -> Option<Vec<Real>> {
    let mut first = bivariate_fiber_coefficient_polynomials(first, retained_parameter);
    let mut second = bivariate_fiber_coefficient_polynomials(second, retained_parameter);
    first.truncate(eliminated_degree + 1);
    second.truncate(eliminated_degree + 1);
    if first.len() != eliminated_degree + 1 || second.len() != eliminated_degree + 1 {
        return None;
    }
    let matrix = crate::resultant::bezout_matrix_with(
        &first,
        &second,
        eliminated_degree,
        Vec::new(),
        &mut NativePolynomialArithmetic,
    )
    .unwrap_or_else(|never| match never {})?;
    let mut determinant = determinant_polynomial_matrix(&matrix, eliminated_degree)?;
    if !(eliminated_degree * eliminated_degree.saturating_sub(1) / 2).is_multiple_of(2) {
        determinant
            .iter_mut()
            .for_each(|coefficient| *coefficient = -coefficient.clone());
    }
    Some(determinant)
}

fn symbolic_bivariate_sylvester_resultant(
    first: &BivariatePolynomial,
    second: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    first_eliminated_degree: usize,
    second_eliminated_degree: usize,
) -> Option<Vec<Real>> {
    let mut first = bivariate_fiber_coefficient_polynomials(first, retained_parameter);
    let mut second = bivariate_fiber_coefficient_polynomials(second, retained_parameter);
    first.truncate(first_eliminated_degree + 1);
    second.truncate(second_eliminated_degree + 1);
    let dimension = first_eliminated_degree.checked_add(second_eliminated_degree)?;
    let mut matrix = vec![Vec::<Real>::new(); dimension.checked_mul(dimension)?];
    let negate = retained_parameter == CurveResultantParameter::Second;
    let oriented = |polynomial: &[Real]| {
        if negate {
            polynomial
                .iter()
                .map(|coefficient| -coefficient.clone())
                .collect()
        } else {
            polynomial.to_vec()
        }
    };
    for row in 0..second_eliminated_degree {
        for (degree, coefficient) in first.iter().enumerate() {
            matrix[row * dimension + row + first_eliminated_degree - degree] =
                oriented(coefficient);
        }
    }
    for row in 0..first_eliminated_degree {
        for (degree, coefficient) in second.iter().enumerate() {
            matrix[(second_eliminated_degree + row) * dimension + row + second_eliminated_degree
                - degree] = oriented(coefficient);
        }
    }

    determinant_polynomial_matrix(&matrix, dimension)
}

fn determinant_polynomial_matrix(matrix: &[Vec<Real>], dimension: usize) -> Option<Vec<Real>> {
    if matrix.len() != dimension.checked_mul(dimension)? {
        return None;
    }
    if dimension == 0 {
        return Some(vec![Real::one()]);
    }
    // Clear each rational row's content once. Intermediate polynomial
    // products and exact Bareiss quotients then contain integers only; one
    // final scale restores the actual determinant, not just its zero set.
    let mut integers = Vec::with_capacity(matrix.len());
    let mut determinant_scale = Rational::one();
    for row in matrix.chunks(dimension) {
        let coefficients = row
            .iter()
            .flatten()
            .map(Real::exact_rational_ref)
            .collect::<Option<Vec<_>>>()?;
        let normalized = Rational::primitive_bigint_ratio(&coefficients);
        let Some((source, target)) = coefficients
            .iter()
            .zip(&normalized)
            .find(|(source, _)| !source.is_zero())
        else {
            return Some(vec![Real::zero()]);
        };
        determinant_scale *= *source / Rational::from_bigint(target.clone());
        let mut normalized = normalized.into_iter();
        for entry in row {
            integers.push(normalized.by_ref().take(entry.len()).collect());
        }
        debug_assert!(normalized.next().is_none());
    }
    Some(
        determinant_integer_polynomial_matrix(&integers, dimension)?
            .into_iter()
            .map(|coefficient| Real::new(Rational::from_bigint(coefficient) * &determinant_scale))
            .collect(),
    )
}

/// Constructs rational lifts for the eliminated parameter of a bivariate system.
///
/// After specializing the retained parameter, the Sylvester matrix annihilates
/// `[u^(n-1), ..., u, 1]` at every common root `u`. When that matrix has
/// nullity one, any nonzero adjugate column is a scalar multiple of this power
/// vector, so the ratio of its last two entries is exactly `u`. This function
/// interpolates those signed cofactors as exact polynomials of the retained
/// parameter. Callers must still prove that a denominator is nonzero at their
/// retained root and replay the resulting rational image against the intended
/// lifted-root interval.
/// A work budget charges one promotion before cofactor sampling, after degree
/// admission. A degree-limited request spends no promotion unit.
pub fn linear_parameter_lifts_bivariate_polynomial_system(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionParameterLiftReport {
    let lifted_parameter = opposite_parameter(retained_parameter);
    if crate::work_budget::exhaustion().is_some() {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::BudgetExhausted,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            None,
        );
    }
    if bivariate_polynomial_is_empty(first_equation)
        || bivariate_polynomial_is_empty(second_equation)
    {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::EmptyEquation,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            None,
        );
    }
    let (Ok(first_degree), Ok(second_degree)) = (
        certified_bivariate_degree(first_equation, config.min_precision),
        certified_bivariate_degree(second_equation, config.min_precision),
    ) else {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::UndecidedCoefficient,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            None,
        );
    };
    let (Some(first_degree), Some(second_degree)) = (first_degree, second_degree) else {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::UnsupportedEliminatedDegree,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            None,
        );
    };
    let (first_retained_degree, first_lifted_degree) =
        oriented_bidegree(first_degree, retained_parameter);
    let (second_retained_degree, second_lifted_degree) =
        oriented_bidegree(second_degree, retained_parameter);
    if first_lifted_degree == 0 || second_lifted_degree == 0 {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::UnsupportedEliminatedDegree,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            None,
        );
    }
    let sylvester_dimension = first_lifted_degree + second_lifted_degree;
    let retained_entry_degree = first_retained_degree.max(second_retained_degree);
    let degree_bound = (sylvester_dimension - 1) * retained_entry_degree;
    if degree_bound > config.max_resultant_degree {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::DegreeBoundExceeded,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            None,
        );
    }

    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return parameter_lift_report(
            CurveIntersectionParameterLiftStatus::BudgetExhausted,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            None,
        );
    }
    let mut parameters = Vec::with_capacity(degree_bound + 1);
    let mut numerators = vec![Vec::with_capacity(degree_bound + 1); sylvester_dimension];
    let mut denominators = vec![Vec::with_capacity(degree_bound + 1); sylvester_dimension];
    let mut sample_index = 0_usize;
    while parameters.len() <= degree_bound {
        let parameter = Real::from(sample_index as u64);
        sample_index += 1;
        let first = evaluate_bivariate_at_retained_parameter(
            first_equation,
            &parameter,
            retained_parameter,
        );
        let second = evaluate_bivariate_at_retained_parameter(
            second_equation,
            &parameter,
            retained_parameter,
        );
        let (Ok(first_sample_degree), Ok(second_sample_degree)) = (
            certified_nonzero_degree(&first, config.min_precision),
            certified_nonzero_degree(&second, config.min_precision),
        ) else {
            return parameter_lift_report(
                CurveIntersectionParameterLiftStatus::UndecidedCoefficient,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                None,
            );
        };
        if first_sample_degree != Some(first_lifted_degree)
            || second_sample_degree != Some(second_lifted_degree)
        {
            continue;
        }
        let sylvester = sylvester_matrix(&first, &second);
        for cofactor_row in 0..sylvester_dimension {
            let numerator = match signed_cofactor(
                &sylvester,
                cofactor_row,
                sylvester_dimension - 2,
                config.min_precision,
            ) {
                Ok(value) => value,
                Err(error) => {
                    return parameter_lift_report(
                        CurveIntersectionParameterLiftStatus::DeterminantError,
                        retained_parameter,
                        lifted_parameter,
                        degree_bound,
                        Vec::new(),
                        Some(error),
                    );
                }
            };
            let denominator = match signed_cofactor(
                &sylvester,
                cofactor_row,
                sylvester_dimension - 1,
                config.min_precision,
            ) {
                Ok(value) => value,
                Err(error) => {
                    return parameter_lift_report(
                        CurveIntersectionParameterLiftStatus::DeterminantError,
                        retained_parameter,
                        lifted_parameter,
                        degree_bound,
                        Vec::new(),
                        Some(error),
                    );
                }
            };
            numerators[cofactor_row].push(numerator);
            denominators[cofactor_row].push(denominator);
        }
        parameters.push(parameter);
    }

    let mut maps = Vec::with_capacity(sylvester_dimension);
    for cofactor_row in 0..sylvester_dimension {
        let Some(numerator) = interpolate_parameter_values(
            &parameters,
            &numerators[cofactor_row],
            config.min_precision,
        ) else {
            return parameter_lift_report(
                CurveIntersectionParameterLiftStatus::InterpolationFailed,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                None,
            );
        };
        let Some(denominator) = interpolate_parameter_values(
            &parameters,
            &denominators[cofactor_row],
            config.min_precision,
        ) else {
            return parameter_lift_report(
                CurveIntersectionParameterLiftStatus::InterpolationFailed,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                None,
            );
        };
        let Ok(denominator_is_zero) =
            is_certified_zero_polynomial(&denominator, config.min_precision)
        else {
            return parameter_lift_report(
                CurveIntersectionParameterLiftStatus::UndecidedCoefficient,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                None,
            );
        };
        if !denominator_is_zero {
            maps.push(CurveIntersectionParameterLiftMap {
                cofactor_row,
                numerator_coefficients: numerator,
                denominator_coefficients: denominator,
            });
        }
    }
    parameter_lift_report(
        CurveIntersectionParameterLiftStatus::Constructed,
        retained_parameter,
        lifted_parameter,
        degree_bound,
        maps,
        None,
    )
}

/// Extracts one exact generic common component and retains both residual equations.
///
/// The first nonzero subresultant of two polynomials in the lifted parameter
/// is their generic GCD up to retained-parameter content. The degree-one path
/// publishes a primitive rational map. Split quadratics and repeated cubics
/// retain their smaller rational-linear fast paths. Otherwise the first
/// nonzero higher subresultant is made primitive and monic, divided exactly
/// from both authored equations, and returned as an implicit component. A
/// sampled-fiber GCD fast path first interpolates the low-degree GCD after
/// scaling it by one authored leading coefficient; polynomial content removes
/// that scale, and exact division of both authored equations is the authority.
/// Any failed reconstruction falls through to the complete subresultant scan.
/// This continues through the complete lifted-degree bound rather than
/// discarding irreducible or multivalued parameter correspondences. Callers
/// can apply the function again to the exact residual pair. A geometry caller
/// must still replay and decompose the finite real branches as documented by
/// [`BivariatePolynomialComponentReport`].
/// An identically zero equation adds no constraint: its companion supplies
/// the generic component, while the authored zero residual remains explicit.
/// One promotion admits discovery after degree-limit checks. The sampled GCD,
/// subresultant continuation, and exact division share that one attempt.
pub fn parameter_component_bivariate_polynomial_system(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> BivariatePolynomialComponentReport {
    let lifted_parameter = opposite_parameter(retained_parameter);
    if crate::work_budget::exhaustion().is_some() {
        return component_report(
            BivariatePolynomialComponentStatus::BudgetExhausted,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }
    if bivariate_polynomial_is_empty(first_equation)
        || bivariate_polynomial_is_empty(second_equation)
    {
        return component_report(
            BivariatePolynomialComponentStatus::EmptyEquation,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }
    let (Ok(first_degree), Ok(second_degree)) = (
        certified_bivariate_degree(first_equation, config.min_precision),
        certified_bivariate_degree(second_equation, config.min_precision),
    ) else {
        return component_report(
            BivariatePolynomialComponentStatus::UndecidedCoefficient,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    };
    if first_degree.is_none() != second_degree.is_none() {
        // gcd(F,0)=gcd(F,F). Reuse the same primitive factor discovery and
        // exact division proof, then restore the authored zero residual.
        // Certification above distinguishes an identically zero equation
        // from a coefficient or specialized fiber whose sign is undecided.
        let (equation, zero, zero_index) = if first_degree.is_none() {
            (second_equation, first_equation, 0)
        } else {
            (first_equation, second_equation, 1)
        };
        let mut report = parameter_component_bivariate_polynomial_system(
            equation,
            equation,
            retained_parameter,
            config,
        );
        if let Some(residual) = report.reduced_equations.as_mut() {
            residual[zero_index] = zero.clone();
        }
        return report;
    }
    let (Some(first_degree), Some(second_degree)) = (first_degree, second_degree) else {
        return component_report(
            BivariatePolynomialComponentStatus::NoSupportedComponent,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    };
    let (first_retained_degree, first_lifted_degree) =
        oriented_bidegree(first_degree, retained_parameter);
    let (second_retained_degree, second_lifted_degree) =
        oriented_bidegree(second_degree, retained_parameter);
    let terminal_degree = first_lifted_degree.min(second_lifted_degree);
    if terminal_degree == 0 {
        return component_report(
            BivariatePolynomialComponentStatus::UnsupportedLiftedDegree,
            retained_parameter,
            lifted_parameter,
            0,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }

    let degree_bound = if terminal_degree == 1 {
        if first_lifted_degree <= second_lifted_degree {
            first_retained_degree
        } else {
            second_retained_degree
        }
    } else {
        (second_lifted_degree - 1) * first_retained_degree
            + (first_lifted_degree - 1) * second_retained_degree
    };
    if terminal_degree >= 2 && degree_bound > config.max_resultant_degree {
        return component_report(
            BivariatePolynomialComponentStatus::DegreeBoundExceeded,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }
    if crate::work_budget::consume(crate::work_budget::WorkKind::AlgebraicPromotion, 1).is_err() {
        return component_report(
            BivariatePolynomialComponentStatus::BudgetExhausted,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }
    if terminal_degree >= 2
        && let Some(report) = sampled_common_fiber_component_report(
            first_equation,
            second_equation,
            retained_parameter,
            lifted_parameter,
            first_retained_degree,
            first_lifted_degree,
            second_retained_degree,
            second_lifted_degree,
            terminal_degree,
            config,
        )
    {
        return report;
    }

    let (mut constant, mut linear) = if terminal_degree == 1 {
        let equation = if first_lifted_degree <= second_lifted_degree {
            first_equation
        } else {
            second_equation
        };
        let coefficients = bivariate_fiber_coefficient_polynomials(equation, retained_parameter);
        (
            coefficients.first().cloned().unwrap_or_default(),
            coefficients.get(1).cloned().unwrap_or_default(),
        )
    } else {
        let mut parameters = Vec::with_capacity(degree_bound + 1);
        let mut constant_samples = Vec::with_capacity(degree_bound + 1);
        let mut linear_samples = Vec::with_capacity(degree_bound + 1);
        let mut sample_index = 0_usize;
        while parameters.len() <= degree_bound {
            let parameter = Real::from(sample_index as u64);
            sample_index += 1;
            let first = evaluate_bivariate_at_retained_parameter(
                first_equation,
                &parameter,
                retained_parameter,
            );
            let second = evaluate_bivariate_at_retained_parameter(
                second_equation,
                &parameter,
                retained_parameter,
            );
            let (Ok(first_sample_degree), Ok(second_sample_degree)) = (
                certified_nonzero_degree(&first, config.min_precision),
                certified_nonzero_degree(&second, config.min_precision),
            ) else {
                return component_report(
                    BivariatePolynomialComponentStatus::UndecidedCoefficient,
                    retained_parameter,
                    lifted_parameter,
                    degree_bound,
                    Vec::new(),
                    Vec::new(),
                    None,
                    None,
                );
            };
            if first_sample_degree != Some(first_lifted_degree)
                || second_sample_degree != Some(second_lifted_degree)
            {
                continue;
            }
            let coefficients =
                match first_subresultant_coefficients(&first, &second, config.min_precision) {
                    Ok(coefficients) => coefficients,
                    Err(error) => {
                        return component_report(
                            BivariatePolynomialComponentStatus::DeterminantError,
                            retained_parameter,
                            lifted_parameter,
                            degree_bound,
                            Vec::new(),
                            Vec::new(),
                            None,
                            Some(error),
                        );
                    }
                };
            constant_samples.push(coefficients[0].clone());
            linear_samples.push(coefficients[1].clone());
            parameters.push(parameter);
        }
        let Some(constant) =
            interpolate_parameter_values(&parameters, &constant_samples, config.min_precision)
        else {
            return component_report(
                BivariatePolynomialComponentStatus::InterpolationFailed,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                Vec::new(),
                None,
                None,
            );
        };
        let Some(linear) =
            interpolate_parameter_values(&parameters, &linear_samples, config.min_precision)
        else {
            return component_report(
                BivariatePolynomialComponentStatus::InterpolationFailed,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                Vec::new(),
                None,
                None,
            );
        };
        (constant, linear)
    };

    if exact_polynomial_is_zero(&linear) {
        if exact_polynomial_is_zero(&constant) && terminal_degree >= 2 {
            return higher_nullity_component_report(
                first_equation,
                second_equation,
                retained_parameter,
                lifted_parameter,
                first_retained_degree,
                first_lifted_degree,
                second_retained_degree,
                second_lifted_degree,
                config,
            );
        }
        return component_report(
            BivariatePolynomialComponentStatus::NoSupportedComponent,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    }
    if let Some(content) = exact_polynomial_gcd(&constant, &linear)
        && !exact_unit_polynomial(&content)
        && !exact_polynomial_is_zero(&content)
    {
        let (Some(reduced_constant), Some(reduced_linear)) = (
            divide_polynomial_exact(constant.clone(), &content),
            divide_polynomial_exact(linear.clone(), &content),
        ) else {
            return component_report(
                BivariatePolynomialComponentStatus::InterpolationFailed,
                retained_parameter,
                lifted_parameter,
                degree_bound,
                Vec::new(),
                Vec::new(),
                None,
                None,
            );
        };
        constant = reduced_constant;
        linear = reduced_linear;
    }
    let numerator_coefficients: Vec<Real> = constant.into_iter().map(std::ops::Neg::neg).collect();
    let denominator_coefficients = linear;
    let (Some(first_reduced), Some(second_reduced)) = (
        divide_bivariate_by_rational_component(
            first_equation,
            &numerator_coefficients,
            &denominator_coefficients,
            retained_parameter,
        ),
        divide_bivariate_by_rational_component(
            second_equation,
            &numerator_coefficients,
            &denominator_coefficients,
            retained_parameter,
        ),
    ) else {
        return component_report(
            BivariatePolynomialComponentStatus::DivisionFailed,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            Vec::new(),
            Vec::new(),
            None,
            None,
        );
    };
    component_report(
        BivariatePolynomialComponentStatus::Rational,
        retained_parameter,
        lifted_parameter,
        degree_bound,
        numerator_coefficients,
        denominator_coefficients,
        Some([first_reduced, second_reduced]),
        None,
    )
}

#[allow(clippy::too_many_arguments)]
fn sampled_common_fiber_component_report(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    first_retained_degree: usize,
    first_lifted_degree: usize,
    second_retained_degree: usize,
    second_lifted_degree: usize,
    terminal_degree: usize,
    config: CurveIntersectionResultantConfig,
) -> Option<BivariatePolynomialComponentReport> {
    let (scale_first, interpolation_degree) = if first_retained_degree <= second_retained_degree {
        (true, first_retained_degree)
    } else {
        (false, second_retained_degree)
    };
    let sample_count = interpolation_degree + 1;
    let mut samples_by_degree = (0..=terminal_degree)
        .map(|_| Vec::new())
        .collect::<Vec<Vec<(Real, Vec<Real>)>>>();
    let maximum_samples = sample_count
        .saturating_mul(4)
        .saturating_add(terminal_degree)
        .saturating_add(8);

    for sample_index in 0..maximum_samples {
        let parameter = Real::from(sample_index as u64);
        let first = evaluate_bivariate_at_retained_parameter(
            first_equation,
            &parameter,
            retained_parameter,
        );
        let second = evaluate_bivariate_at_retained_parameter(
            second_equation,
            &parameter,
            retained_parameter,
        );
        let (Ok(Some(first_degree)), Ok(Some(second_degree))) = (
            certified_nonzero_degree(&first, config.min_precision),
            certified_nonzero_degree(&second, config.min_precision),
        ) else {
            continue;
        };
        if first_degree != first_lifted_degree || second_degree != second_lifted_degree {
            continue;
        }
        let scale = if scale_first {
            first.get(first_lifted_degree)?.clone()
        } else {
            second.get(second_lifted_degree)?.clone()
        };
        let gcd = polynomial_gcd(first, second, hyperlimit::PredicatePolicy::STRICT)?;
        let Ok(Some(gcd_degree)) = certified_nonzero_degree(&gcd, config.min_precision) else {
            continue;
        };
        if gcd_degree == 0 || gcd_degree > terminal_degree {
            continue;
        }
        let leading = gcd.get(gcd_degree)?.clone();
        let scaled = if leading == Real::one() {
            gcd.into_iter()
                .take(gcd_degree + 1)
                .map(|coefficient| coefficient * &scale)
                .collect()
        } else {
            let leading_reciprocal =
                crate::policy_division::reciprocal_after_certified_nonzero(&leading).ok()?;
            gcd.into_iter()
                .take(gcd_degree + 1)
                .map(|coefficient| coefficient * &scale * &leading_reciprocal)
                .collect()
        };
        let samples = &mut samples_by_degree[gcd_degree];
        if samples.is_empty() {
            samples.reserve(sample_count);
        }
        samples.push((parameter, scaled));
        if samples.len() < sample_count {
            continue;
        }

        let parameters = samples
            .iter()
            .map(|(parameter, _)| parameter.clone())
            .collect::<Vec<_>>();
        let coefficients = (0..=gcd_degree)
            .map(|power| {
                let values = samples
                    .iter()
                    .map(|(_, coefficients)| coefficients[power].clone())
                    .collect::<Vec<_>>();
                interpolate_parameter_values(&parameters, &values, config.min_precision)
            })
            .collect::<Option<Vec<_>>>()?;
        if let Ok(Some(report)) = common_fiber_component_report_from_coefficients(
            first_equation,
            second_equation,
            retained_parameter,
            lifted_parameter,
            interpolation_degree,
            coefficients,
        ) {
            return Some(report);
        }
        return None;
    }
    None
}

#[allow(clippy::too_many_arguments)]
fn higher_nullity_component_report(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    first_retained_degree: usize,
    first_lifted_degree: usize,
    second_retained_degree: usize,
    second_lifted_degree: usize,
    config: CurveIntersectionResultantConfig,
) -> BivariatePolynomialComponentReport {
    let terminal_degree = first_lifted_degree.min(second_lifted_degree);
    for order in 2..=terminal_degree {
        let (coefficients, degree_bound) = match common_fiber_subresultant_coefficients(
            first_equation,
            second_equation,
            retained_parameter,
            first_retained_degree,
            first_lifted_degree,
            second_retained_degree,
            second_lifted_degree,
            order,
            config,
        ) {
            Ok(result) => result,
            Err((status, degree_bound, determinant_error)) => {
                return component_report(
                    status,
                    retained_parameter,
                    lifted_parameter,
                    degree_bound,
                    Vec::new(),
                    Vec::new(),
                    None,
                    determinant_error,
                );
            }
        };
        match common_fiber_component_report_from_coefficients(
            first_equation,
            second_equation,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            coefficients,
        ) {
            Ok(Some(report)) => return report,
            Ok(None) => continue,
            Err(()) => {
                return component_report(
                    BivariatePolynomialComponentStatus::DivisionFailed,
                    retained_parameter,
                    lifted_parameter,
                    degree_bound,
                    Vec::new(),
                    Vec::new(),
                    None,
                    None,
                );
            }
        }
    }

    component_report(
        BivariatePolynomialComponentStatus::NoSupportedComponent,
        retained_parameter,
        lifted_parameter,
        0,
        Vec::new(),
        Vec::new(),
        None,
        None,
    )
}

fn common_fiber_component_report_from_coefficients(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    degree_bound: usize,
    mut coefficients: Vec<Vec<Real>>,
) -> Result<Option<BivariatePolynomialComponentReport>, ()> {
    while coefficients
        .last()
        .is_some_and(|coefficient| exact_polynomial_is_zero(coefficient))
    {
        coefficients.pop();
    }
    if coefficients.is_empty() {
        return Ok(None);
    }

    let maps = match coefficients.len() - 1 {
        1 => vec![(
            scale_exact_polynomial(&coefficients[0], &Real::from(-1_i8)),
            coefficients[1].clone(),
        )],
        2 => quadratic_rational_maps(
            coefficients[0].clone(),
            coefficients[1].clone(),
            coefficients[2].clone(),
        ),
        3 => repeated_cubic_rational_maps(coefficients.clone()),
        _ => Vec::new(),
    };
    if let Some((numerator, denominator, reduced_equations)) =
        first_dividing_rational_map(first_equation, second_equation, retained_parameter, maps)
    {
        return Ok(Some(component_report(
            BivariatePolynomialComponentStatus::Rational,
            retained_parameter,
            lifted_parameter,
            degree_bound,
            numerator,
            denominator,
            Some(reduced_equations),
            None,
        )));
    }

    let component = primitive_common_fiber_component(coefficients, retained_parameter).ok_or(())?;
    let (first_reduced, second_reduced) = (
        divide_bivariate_polynomial_exact(first_equation, &component).ok_or(())?,
        divide_bivariate_polynomial_exact(second_equation, &component).ok_or(())?,
    );
    Ok(Some(implicit_component_report(
        retained_parameter,
        lifted_parameter,
        degree_bound,
        component,
        [first_reduced, second_reduced],
    )))
}

#[allow(clippy::too_many_arguments)]
fn common_fiber_subresultant_coefficients(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    first_retained_degree: usize,
    first_lifted_degree: usize,
    second_retained_degree: usize,
    second_lifted_degree: usize,
    order: usize,
    config: CurveIntersectionResultantConfig,
) -> Result<(Vec<Vec<Real>>, usize), ComponentConstructionError> {
    let terminal_degree = first_lifted_degree.min(second_lifted_degree);
    debug_assert!(order >= 2 && terminal_degree >= order);
    if terminal_degree == order {
        let (equation, degree_bound) = if first_lifted_degree <= second_lifted_degree {
            (first_equation, first_retained_degree)
        } else {
            (second_equation, second_retained_degree)
        };
        let mut coefficients =
            bivariate_fiber_coefficient_polynomials(equation, retained_parameter);
        coefficients.resize_with(order + 1, || vec![Real::zero()]);
        coefficients.truncate(order + 1);
        return Ok((coefficients, degree_bound));
    }

    let degree_bound = (second_lifted_degree - order) * first_retained_degree
        + (first_lifted_degree - order) * second_retained_degree;
    if degree_bound > config.max_resultant_degree {
        return Err((
            BivariatePolynomialComponentStatus::DegreeBoundExceeded,
            degree_bound,
            None,
        ));
    }
    let mut parameters = Vec::with_capacity(degree_bound + 1);
    let mut coefficient_samples = (0..=order)
        .map(|_| Vec::with_capacity(degree_bound + 1))
        .collect::<Vec<_>>();
    let mut sample_index = 0_usize;
    while parameters.len() <= degree_bound {
        let parameter = Real::from(sample_index as u64);
        sample_index += 1;
        let first = evaluate_bivariate_at_retained_parameter(
            first_equation,
            &parameter,
            retained_parameter,
        );
        let second = evaluate_bivariate_at_retained_parameter(
            second_equation,
            &parameter,
            retained_parameter,
        );
        let (Ok(first_sample_degree), Ok(second_sample_degree)) = (
            certified_nonzero_degree(&first, config.min_precision),
            certified_nonzero_degree(&second, config.min_precision),
        ) else {
            return Err((
                BivariatePolynomialComponentStatus::UndecidedCoefficient,
                degree_bound,
                None,
            ));
        };
        if first_sample_degree != Some(first_lifted_degree)
            || second_sample_degree != Some(second_lifted_degree)
        {
            continue;
        }
        let coefficients =
            match subresultant_coefficients(&first, &second, order, config.min_precision) {
                Ok(coefficients) => coefficients,
                Err(error) => {
                    return Err((
                        BivariatePolynomialComponentStatus::DeterminantError,
                        degree_bound,
                        Some(error),
                    ));
                }
            };
        for (samples, coefficient) in coefficient_samples.iter_mut().zip(coefficients) {
            samples.push(coefficient);
        }
        parameters.push(parameter);
    }
    let coefficients = coefficient_samples
        .into_iter()
        .map(|samples| {
            interpolate_parameter_values(&parameters, &samples, config.min_precision).ok_or((
                BivariatePolynomialComponentStatus::InterpolationFailed,
                degree_bound,
                None,
            ))
        })
        .collect::<Result<Vec<_>, _>>()?;
    Ok((coefficients, degree_bound))
}

fn quadratic_rational_maps(
    constant: Vec<Real>,
    linear: Vec<Real>,
    quadratic: Vec<Real>,
) -> Vec<(Vec<Real>, Vec<Real>)> {
    let discriminant = subtract_exact_polynomials(
        &multiply_exact_polynomials(&linear, &linear),
        &scale_exact_polynomial(
            &multiply_exact_polynomials(&constant, &quadratic),
            &Real::from(4_i8),
        ),
    );
    let Some(root) = exact_polynomial_square_root(discriminant) else {
        return Vec::new();
    };
    let negative_linear = scale_exact_polynomial(&linear, &Real::from(-1_i8));
    let denominator = scale_exact_polynomial(&quadratic, &Real::from(2_i8));
    vec![
        (
            add_exact_polynomials(&negative_linear, &root),
            denominator.clone(),
        ),
        (
            subtract_exact_polynomials(&negative_linear, &root),
            denominator,
        ),
    ]
}

fn repeated_cubic_rational_maps(coefficients: Vec<Vec<Real>>) -> Vec<(Vec<Real>, Vec<Real>)> {
    let [constant, linear, quadratic, cubic]: [Vec<Real>; 4] = match coefficients.try_into() {
        Ok(coefficients) => coefficients,
        Err(_) => return Vec::new(),
    };
    if exact_polynomial_is_zero(&cubic) {
        return Vec::new();
    }
    let quadratic_squared = multiply_exact_polynomials(&quadratic, &quadratic);
    let linear_squared = multiply_exact_polynomials(&linear, &linear);
    let discriminant = subtract_exact_polynomials(
        &add_exact_polynomials(
            &subtract_exact_polynomials(
                &scale_exact_polynomial(
                    &multiply_exact_polynomials(
                        &multiply_exact_polynomials(&cubic, &quadratic),
                        &multiply_exact_polynomials(&linear, &constant),
                    ),
                    &Real::from(18_i8),
                ),
                &scale_exact_polynomial(
                    &multiply_exact_polynomials(
                        &multiply_exact_polynomials(&quadratic_squared, &quadratic),
                        &constant,
                    ),
                    &Real::from(4_i8),
                ),
            ),
            &multiply_exact_polynomials(&quadratic_squared, &linear_squared),
        ),
        &add_exact_polynomials(
            &scale_exact_polynomial(
                &multiply_exact_polynomials(
                    &cubic,
                    &multiply_exact_polynomials(&linear_squared, &linear),
                ),
                &Real::from(4_i8),
            ),
            &scale_exact_polynomial(
                &multiply_exact_polynomials(
                    &multiply_exact_polynomials(&cubic, &cubic),
                    &multiply_exact_polynomials(&constant, &constant),
                ),
                &Real::from(27_i8),
            ),
        ),
    );
    if !exact_polynomial_is_zero(&discriminant) {
        return Vec::new();
    }
    let delta = subtract_exact_polynomials(
        &quadratic_squared,
        &scale_exact_polynomial(
            &multiply_exact_polynomials(&cubic, &linear),
            &Real::from(3_i8),
        ),
    );
    let repeated_numerator = subtract_exact_polynomials(
        &scale_exact_polynomial(
            &multiply_exact_polynomials(&cubic, &constant),
            &Real::from(9_i8),
        ),
        &multiply_exact_polynomials(&quadratic, &linear),
    );
    if exact_polynomial_is_zero(&delta) {
        vec![(
            scale_exact_polynomial(&quadratic, &Real::from(-1_i8)),
            scale_exact_polynomial(&cubic, &Real::from(3_i8)),
        )]
    } else {
        vec![(
            repeated_numerator,
            scale_exact_polynomial(&delta, &Real::from(2_i8)),
        )]
    }
}

fn first_dividing_rational_map(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    maps: Vec<(Vec<Real>, Vec<Real>)>,
) -> Option<(Vec<Real>, Vec<Real>, [BivariatePolynomial; 2])> {
    for (numerator, denominator) in maps {
        let (numerator, denominator) = primitive_rational_map(numerator, denominator);
        let (Some(first_reduced), Some(second_reduced)) = (
            divide_bivariate_by_rational_component(
                first_equation,
                &numerator,
                &denominator,
                retained_parameter,
            ),
            divide_bivariate_by_rational_component(
                second_equation,
                &numerator,
                &denominator,
                retained_parameter,
            ),
        ) else {
            continue;
        };
        return Some((numerator, denominator, [first_reduced, second_reduced]));
    }
    None
}

type ComponentConstructionError = (
    BivariatePolynomialComponentStatus,
    usize,
    Option<BareissError>,
);

fn primitive_rational_map(numerator: Vec<Real>, denominator: Vec<Real>) -> (Vec<Real>, Vec<Real>) {
    let Some(content) = polynomial_gcd(
        numerator.clone(),
        denominator.clone(),
        hyperlimit::PredicatePolicy::STRICT,
    ) else {
        return (numerator, denominator);
    };
    if exact_unit_polynomial(&content) || exact_polynomial_is_zero(&content) {
        return (numerator, denominator);
    }
    match (
        divide_polynomial_exact(numerator.clone(), &content),
        divide_polynomial_exact(denominator.clone(), &content),
    ) {
        (Some(numerator), Some(denominator)) => (numerator, denominator),
        _ => (numerator, denominator),
    }
}

fn exact_polynomial_square_root(mut polynomial: Vec<Real>) -> Option<Vec<Real>> {
    while polynomial.len() > 1 && polynomial.last().is_some_and(exact_real_is_zero) {
        polynomial.pop();
    }
    if exact_polynomial_is_zero(&polynomial) {
        return Some(vec![Real::zero()]);
    }
    let degree = polynomial.len() - 1;
    if !degree.is_multiple_of(2) {
        return None;
    }
    let root_degree = degree / 2;
    let leading = polynomial.last()?.clone().sqrt().ok()?;
    if exact_real_is_zero(&leading) {
        return None;
    }
    let twice_leading = Real::from(2_i8) * &leading;
    let twice_leading_reciprocal = strict_reciprocal(&twice_leading)?;
    let mut root = vec![Real::zero(); root_degree + 1];
    root[root_degree] = leading;
    for power in (0..root_degree).rev() {
        let product = multiply_exact_polynomials(&root, &root);
        let known = product
            .get(root_degree + power)
            .cloned()
            .unwrap_or_else(Real::zero);
        root[power] = (polynomial[root_degree + power].clone() - known) * &twice_leading_reciprocal;
    }
    exact_polynomial_is_zero(&subtract_exact_polynomials(
        &multiply_exact_polynomials(&root, &root),
        &polynomial,
    ))
    .then_some(root)
}

fn scale_exact_polynomial(polynomial: &[Real], scale: &Real) -> Vec<Real> {
    polynomial
        .iter()
        .map(|coefficient| coefficient * scale)
        .collect()
}

fn subtract_exact_polynomials(first: &[Real], second: &[Real]) -> Vec<Real> {
    add_exact_polynomials(first, &scale_exact_polynomial(second, &Real::from(-1_i8)))
}

/// Eliminate one parameter from a pair of 2D polynomial parametric curves.
///
/// For `retained_parameter == First`, this constructs
/// `Res_u(x1(t) - x2(u), y1(t) - y2(u))`. For `Second`, the roles are swapped
/// and the returned polynomial is in the second curve's parameter. The degree
/// bound is the classical bidegree resultant bound
/// `deg_u(g)*deg_t(f) + deg_u(f)*deg_t(g)`, evaluated after certified trimming.
/// Polynomial determinant construction or exact interpolation supplies
/// elimination evidence; downstream exact replay must still establish a
/// candidate root's geometric validity.
pub fn resultant_parametric_curve_intersection(
    first: &PolynomialParametricCurve2,
    second: &PolynomialParametricCurve2,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionResultantReport {
    if crate::work_budget::exhaustion().is_some() {
        return exhausted_resultant_report(retained_parameter, 0);
    }
    if first.x_coefficients.is_empty()
        || first.y_coefficients.is_empty()
        || second.x_coefficients.is_empty()
        || second.y_coefficients.is_empty()
    {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::EmptyCoordinatePolynomial,
            retained_parameter,
            opposite_parameter(retained_parameter),
            0,
            Vec::new(),
            None,
        );
    }
    resultant_bivariate_polynomial_system(
        &parametric_coordinate_difference(&first.x_coefficients, &second.x_coefficients),
        &parametric_coordinate_difference(&first.y_coefficients, &second.y_coefficients),
        retained_parameter,
        config,
    )
}

/// Eliminate one parameter from a pair of homogeneous rational parametric curves.
///
/// This is the rational/conic counterpart to
/// [`resultant_parametric_curve_intersection`]. It constructs homogeneous
/// coordinate equations
/// `X1(t) * W2(u) - X2(u) * W1(t)` and
/// `Y1(t) * W2(u) - Y2(u) * W1(t)`, then eliminates the other parameter by
/// exact Sylvester resultants. The cross-multiplied form follows the standard
/// rational Bezier model in the Bernstein/de Casteljau construction, and
/// keeps Bezier clipping inside the exact EGC
/// rule: denominator validity and topology are not inferred from this helper;
/// downstream curve code must replay candidates against retained geometry.
pub fn resultant_rational_parametric_curve_intersection(
    first: &RationalParametricCurve2,
    second: &RationalParametricCurve2,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionResultantReport {
    if crate::work_budget::exhaustion().is_some() {
        return exhausted_resultant_report(retained_parameter, 0);
    }
    if rational_curve_has_empty_polynomial(first) || rational_curve_has_empty_polynomial(second) {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::EmptyCoordinatePolynomial,
            retained_parameter,
            opposite_parameter(retained_parameter),
            0,
            Vec::new(),
            None,
        );
    }
    let Ok(first_weight_zero) = is_certified_zero_polynomial(&first.weight, config.min_precision)
    else {
        return undecided_report(retained_parameter, opposite_parameter(retained_parameter));
    };
    let Ok(second_weight_zero) = is_certified_zero_polynomial(&second.weight, config.min_precision)
    else {
        return undecided_report(retained_parameter, opposite_parameter(retained_parameter));
    };
    if first_weight_zero || second_weight_zero {
        return curve_resultant_report(
            CurveIntersectionResultantStatus::InvalidHomogeneousWeight,
            retained_parameter,
            opposite_parameter(retained_parameter),
            0,
            Vec::new(),
            None,
        );
    }

    resultant_bivariate_polynomial_system(
        &rational_cross_equation(
            &first.x_numerator,
            &first.weight,
            &second.x_numerator,
            &second.weight,
        ),
        &rational_cross_equation(
            &first.y_numerator,
            &first.weight,
            &second.y_numerator,
            &second.weight,
        ),
        retained_parameter,
        config,
    )
}

fn exhausted_resultant_report(
    retained_parameter: CurveResultantParameter,
    degree_bound: usize,
) -> CurveIntersectionResultantReport {
    curve_resultant_report(
        CurveIntersectionResultantStatus::BudgetExhausted,
        retained_parameter,
        opposite_parameter(retained_parameter),
        degree_bound,
        Vec::new(),
        None,
    )
}

fn curve_resultant_report(
    status: CurveIntersectionResultantStatus,
    retained_parameter: CurveResultantParameter,
    eliminated_parameter: CurveResultantParameter,
    degree_bound: usize,
    resultant_coefficients: Vec<Real>,
    resultant_error: Option<UnivariateResultantError>,
) -> CurveIntersectionResultantReport {
    CurveIntersectionResultantReport {
        status,
        retained_parameter,
        eliminated_parameter,
        degree_bound,
        resultant_coefficients,
        resultant_error,
    }
}

fn parameter_lift_report(
    status: CurveIntersectionParameterLiftStatus,
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    degree_bound: usize,
    maps: Vec<CurveIntersectionParameterLiftMap>,
    determinant_error: Option<BareissError>,
) -> CurveIntersectionParameterLiftReport {
    CurveIntersectionParameterLiftReport {
        status,
        retained_parameter,
        lifted_parameter,
        degree_bound,
        maps,
        determinant_error,
    }
}

#[allow(clippy::too_many_arguments)]
fn component_report(
    status: BivariatePolynomialComponentStatus,
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    degree_bound: usize,
    numerator_coefficients: Vec<Real>,
    denominator_coefficients: Vec<Real>,
    reduced_equations: Option<[BivariatePolynomial; 2]>,
    determinant_error: Option<BareissError>,
) -> BivariatePolynomialComponentReport {
    BivariatePolynomialComponentReport {
        status,
        retained_parameter,
        lifted_parameter,
        degree_bound,
        numerator_coefficients,
        denominator_coefficients,
        implicit_component: None,
        reduced_equations,
        determinant_error,
    }
}

fn implicit_component_report(
    retained_parameter: CurveResultantParameter,
    lifted_parameter: CurveResultantParameter,
    degree_bound: usize,
    implicit_component: BivariatePolynomial,
    reduced_equations: [BivariatePolynomial; 2],
) -> BivariatePolynomialComponentReport {
    BivariatePolynomialComponentReport {
        status: BivariatePolynomialComponentStatus::Implicit,
        retained_parameter,
        lifted_parameter,
        degree_bound,
        numerator_coefficients: Vec::new(),
        denominator_coefficients: Vec::new(),
        implicit_component: Some(implicit_component),
        reduced_equations: Some(reduced_equations),
        determinant_error: None,
    }
}

fn bivariate_fiber_coefficient_polynomials(
    polynomial: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
) -> Vec<Vec<Real>> {
    match retained_parameter {
        CurveResultantParameter::First => {
            let fiber_count = polynomial
                .coefficients
                .iter()
                .map(Vec::len)
                .max()
                .unwrap_or(0);
            (0..fiber_count)
                .map(|fiber_power| {
                    polynomial
                        .coefficients
                        .iter()
                        .map(|row| row.get(fiber_power).cloned().unwrap_or_else(Real::zero))
                        .collect()
                })
                .collect()
        }
        CurveResultantParameter::Second => polynomial.coefficients.clone(),
    }
}

fn divide_bivariate_by_rational_component(
    polynomial: &BivariatePolynomial,
    numerator: &[Real],
    denominator: &[Real],
    retained_parameter: CurveResultantParameter,
) -> Option<BivariatePolynomial> {
    let mut fibers = bivariate_fiber_coefficient_polynomials(polynomial, retained_parameter);
    while fibers
        .last()
        .is_some_and(|fiber| exact_polynomial_is_zero(fiber))
    {
        fibers.pop();
    }
    if fibers.is_empty() {
        return Some(BivariatePolynomial::new(vec![vec![Real::zero()]]));
    }
    if fibers.len() < 2 || exact_polynomial_is_zero(denominator) {
        return None;
    }

    // For C(r,l)=D(r)l-N(r) and E=CQ, coefficient comparison gives
    // E_m=D Q_(m-1), E_k=D Q_(k-1)-N Q_k, and E_0=-N Q_0.
    // Descending recurrence avoids fraction-field arithmetic: every division
    // is exact in the retained-parameter polynomial ring or the report fails.
    let quotient_degree = fibers.len() - 2;
    let mut quotient = vec![vec![Real::zero()]; quotient_degree + 1];
    quotient[quotient_degree] =
        divide_polynomial_exact(fibers[quotient_degree + 1].clone(), denominator)?;
    for lifted_power in (1..=quotient_degree).rev() {
        let dividend = add_exact_polynomials(
            &fibers[lifted_power],
            &multiply_exact_polynomials(numerator, &quotient[lifted_power]),
        );
        quotient[lifted_power - 1] = divide_polynomial_exact(dividend, denominator)?;
    }
    let remainder = add_exact_polynomials(
        &fibers[0],
        &multiply_exact_polynomials(numerator, &quotient[0]),
    );
    if !exact_polynomial_is_zero(&remainder) {
        return None;
    }
    Some(bivariate_from_fiber_coefficients(
        quotient,
        retained_parameter,
    ))
}

fn bivariate_from_fiber_coefficients(
    fibers: Vec<Vec<Real>>,
    retained_parameter: CurveResultantParameter,
) -> BivariatePolynomial {
    match retained_parameter {
        CurveResultantParameter::Second => canonical_exact_bivariate(fibers),
        CurveResultantParameter::First => {
            let retained_count = fibers.iter().map(Vec::len).max().unwrap_or(0);
            let mut coefficients = vec![vec![Real::zero(); fibers.len()]; retained_count];
            for (lifted_power, fiber) in fibers.into_iter().enumerate() {
                for (retained_power, coefficient) in fiber.into_iter().enumerate() {
                    coefficients[retained_power][lifted_power] = coefficient;
                }
            }
            canonical_exact_bivariate(coefficients)
        }
    }
}

pub(crate) fn primitive_common_fiber_component(
    mut fibers: Vec<Vec<Real>>,
    retained_parameter: CurveResultantParameter,
) -> Option<BivariatePolynomial> {
    for fiber in &mut fibers {
        while fiber.len() > 1 && fiber.last().is_some_and(exact_real_is_zero) {
            fiber.pop();
        }
    }
    let mut nonzero = fibers
        .iter()
        .filter(|fiber| !exact_polynomial_is_zero(fiber));
    let mut content = nonzero.next()?.clone();
    for fiber in nonzero {
        content = polynomial_gcd(content, fiber.clone(), hyperlimit::PredicatePolicy::STRICT)?;
        if exact_unit_polynomial(&content) {
            break;
        }
    }
    if !exact_unit_polynomial(&content) && !exact_polynomial_is_zero(&content) {
        for fiber in &mut fibers {
            if !exact_polynomial_is_zero(fiber) {
                *fiber = divide_polynomial_exact(fiber.clone(), &content)?;
            }
        }
    }
    let mut component = bivariate_from_fiber_coefficients(fibers, retained_parameter);
    let (_, _, leading) = leading_bivariate_term(&component.coefficients)?;
    if leading != Real::one() {
        let reciprocal = strict_reciprocal(&leading)?;
        for coefficient in component.coefficients.iter_mut().flatten() {
            *coefficient *= &reciprocal;
        }
    }
    (!exact_bivariate_is_zero(&component)).then_some(component)
}

/// Removes the greatest univariate content on the retained axis exactly.
///
/// The returned bivariate polynomial has the same non-identically-zero
/// selected fibers as `polynomial`, while retained-axis factors that make a
/// complete lifted fiber vanish are saturated away. All coefficient GCDs and
/// divisions are replayed with exact [`Real`] arithmetic under `STRICT`.
pub fn primitive_bivariate_fiber_component_exact(
    polynomial: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
) -> Option<BivariatePolynomial> {
    primitive_common_fiber_component(
        bivariate_fiber_coefficient_polynomials(polynomial, retained_parameter),
        retained_parameter,
    )
}

/// Returns the monic exact GCD of two univariate polynomials.
///
/// Coefficients are in ascending power order. The Euclidean/subresultant
/// package uses only exact `Real` arithmetic and the `STRICT` zero predicate;
/// a coefficient that cannot be decided exactly makes the operation
/// unsupported rather than approximate.
pub fn greatest_common_divisor_univariate_polynomials_exact(
    left: &[Real],
    right: &[Real],
) -> Option<Vec<Real>> {
    polynomial_gcd(
        left.to_vec(),
        right.to_vec(),
        hyperlimit::PredicatePolicy::STRICT,
    )
}

/// Returns the exact quotient when one univariate polynomial divides another.
///
/// Coefficients are in ascending power order. Division uses the canonical
/// exact `Real` field and accepts the quotient only when every remainder
/// coefficient is certified zero under `STRICT`.
pub fn divide_univariate_polynomial_exact(
    dividend: &[Real],
    divisor: &[Real],
) -> Option<Vec<Real>> {
    divide_polynomial_exact(dividend.to_vec(), divisor)
}

/// Returns the exact quotient when one bivariate polynomial divides another.
///
/// The divisor and dividend are canonicalized first. Multivariate long
/// division proceeds over the exact `Real` field and succeeds only when every
/// remainder coefficient is certified zero. One shared reciprocal uses the
/// ordinary inverse first, then a `STRICT` nonzero proof when needed. Each
/// leading coefficient cancels by construction, so long division cannot
/// repeatedly expand the same exact zero. A zero divisor is rejected; a zero
/// dividend has the canonical zero quotient.
pub fn divide_bivariate_polynomial_exact(
    dividend: &BivariatePolynomial,
    divisor: &BivariatePolynomial,
) -> Option<BivariatePolynomial> {
    let divisor = canonical_exact_bivariate(divisor.coefficients.clone());
    let (divisor_first_power, divisor_second_power, divisor_leading) =
        leading_bivariate_term(&divisor.coefficients)?;
    let divisor_leading_reciprocal = strict_reciprocal(&divisor_leading)?;
    let mut remainder = canonical_exact_bivariate(dividend.coefficients.clone()).coefficients;
    let mut quotient = Vec::<Vec<Real>>::new();
    while let Some((first_power, second_power, leading)) = leading_bivariate_term(&remainder) {
        if first_power < divisor_first_power || second_power < divisor_second_power {
            return None;
        }
        let quotient_first_power = first_power - divisor_first_power;
        let quotient_second_power = second_power - divisor_second_power;
        let scale = leading * &divisor_leading_reciprocal;
        if quotient.len() <= quotient_first_power {
            quotient.resize_with(quotient_first_power + 1, Vec::new);
        }
        if quotient[quotient_first_power].len() <= quotient_second_power {
            quotient[quotient_first_power].resize_with(quotient_second_power + 1, Real::zero);
        }
        quotient[quotient_first_power][quotient_second_power] += &scale;
        for (divisor_first, row) in divisor.coefficients.iter().enumerate() {
            let target_first = quotient_first_power + divisor_first;
            if remainder.len() <= target_first {
                remainder.resize_with(target_first + 1, Vec::new);
            }
            for (divisor_second, coefficient) in row.iter().enumerate() {
                if (divisor_first, divisor_second) == (divisor_first_power, divisor_second_power)
                    || exact_real_is_zero(coefficient)
                {
                    continue;
                }
                let target_second = quotient_second_power + divisor_second;
                if remainder[target_first].len() <= target_second {
                    remainder[target_first].resize_with(target_second + 1, Real::zero);
                }
                remainder[target_first][target_second] -= &scale * coefficient;
            }
        }
        // This coefficient cancels by construction. Publishing that identity
        // avoids re-proving `(a / b) * b == a` from an expanded exact DAG.
        remainder[first_power][second_power] = Real::zero();
    }
    Some(canonical_exact_bivariate(quotient))
}

fn leading_bivariate_term(coefficients: &[Vec<Real>]) -> Option<(usize, usize, Real)> {
    coefficients
        .iter()
        .enumerate()
        .rev()
        .find_map(|(first_power, row)| {
            row.iter()
                .enumerate()
                .rev()
                .find(|(_, coefficient)| !exact_real_is_zero(coefficient))
                .map(|(second_power, coefficient)| (first_power, second_power, coefficient.clone()))
        })
}

fn add_exact_polynomials(first: &[Real], second: &[Real]) -> Vec<Real> {
    let mut sum = vec![Real::zero(); first.len().max(second.len())];
    for (target, coefficient) in sum.iter_mut().zip(first) {
        *target += coefficient;
    }
    for (target, coefficient) in sum.iter_mut().zip(second) {
        *target += coefficient;
    }
    while sum.len() > 1 && sum.last().is_some_and(exact_real_is_zero) {
        sum.pop();
    }
    sum
}

fn multiply_exact_polynomials(first: &[Real], second: &[Real]) -> Vec<Real> {
    if first.is_empty() || second.is_empty() {
        return vec![Real::zero()];
    }
    let mut product = vec![Real::zero(); first.len() + second.len() - 1];
    for (first_power, first_coefficient) in first.iter().enumerate() {
        for (second_power, second_coefficient) in second.iter().enumerate() {
            product[first_power + second_power] += first_coefficient * second_coefficient;
        }
    }
    while product.len() > 1 && product.last().is_some_and(exact_real_is_zero) {
        product.pop();
    }
    product
}

fn first_subresultant_coefficients(
    first: &[Real],
    second: &[Real],
    min_precision: i32,
) -> Result<[Real; 2], BareissError> {
    let coefficients = subresultant_coefficients(first, second, 1, min_precision)?;
    Ok([coefficients[0].clone(), coefficients[1].clone()])
}

fn subresultant_coefficients(
    first: &[Real],
    second: &[Real],
    order: usize,
    min_precision: i32,
) -> Result<Vec<Real>, BareissError> {
    let first_degree = first.len() - 1;
    let second_degree = second.len() - 1;
    debug_assert!(order > 0);
    debug_assert!(first_degree > order && second_degree > order);
    let row_count = first_degree + second_degree - 2 * order;
    let column_count = first_degree + second_degree - order;
    let first_row_count = second_degree - order;
    let second_row_count = first_degree - order;
    let mut matrix = vec![vec![Real::zero(); column_count]; row_count];
    for (row, matrix_row) in matrix.iter_mut().take(first_row_count).enumerate() {
        for (power, coefficient) in first.iter().enumerate() {
            matrix_row[row + first_degree - power] = coefficient.clone();
        }
    }
    for (row, matrix_row) in matrix
        .iter_mut()
        .skip(first_row_count)
        .take(second_row_count)
        .enumerate()
    {
        for (power, coefficient) in second.iter().enumerate() {
            matrix_row[row + second_degree - power] = coefficient.clone();
        }
    }

    let mut coefficients = vec![Real::zero(); order + 1];
    for (power, coefficient) in coefficients.iter_mut().enumerate() {
        let last_column = column_count - 1 - power;
        let minor = matrix
            .iter()
            .map(|row| {
                row.iter()
                    .take(row_count - 1)
                    .chain(std::iter::once(&row[last_column]))
                    .cloned()
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        *coefficient = determinant_bareiss(&minor, min_precision)?.determinant;
    }
    Ok(coefficients)
}

fn signed_cofactor(
    matrix: &[Vec<Real>],
    removed_row: usize,
    removed_column: usize,
    min_precision: i32,
) -> Result<Real, BareissError> {
    let minor = matrix
        .iter()
        .enumerate()
        .filter(|(row, _)| *row != removed_row)
        .map(|(_, row)| {
            row.iter()
                .enumerate()
                .filter(|(column, _)| *column != removed_column)
                .map(|(_, coefficient)| coefficient.clone())
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    let determinant = determinant_bareiss(&minor, min_precision)?.determinant;
    Ok(if (removed_row + removed_column).is_multiple_of(2) {
        determinant
    } else {
        -determinant
    })
}

fn interpolate_parameter_values(
    parameters: &[Real],
    values: &[Real],
    min_precision: i32,
) -> Option<Vec<Real>> {
    if parameters.len() != values.len() {
        return None;
    }
    let samples = parameters
        .iter()
        .zip(values)
        .map(|(parameter_value, resultant)| PolynomialSample {
            parameter_value: parameter_value.clone(),
            value: resultant.clone(),
        })
        .collect::<Vec<_>>();
    interpolate_samples(&samples, min_precision).ok()
}

fn undecided_report(
    retained_parameter: CurveResultantParameter,
    eliminated_parameter: CurveResultantParameter,
) -> CurveIntersectionResultantReport {
    curve_resultant_report(
        CurveIntersectionResultantStatus::UndecidedCoefficient,
        retained_parameter,
        eliminated_parameter,
        0,
        Vec::new(),
        None,
    )
}

#[derive(Clone, Copy)]
struct BivariateDegree {
    first: usize,
    second: usize,
}

const fn opposite_parameter(parameter: CurveResultantParameter) -> CurveResultantParameter {
    match parameter {
        CurveResultantParameter::First => CurveResultantParameter::Second,
        CurveResultantParameter::Second => CurveResultantParameter::First,
    }
}

const fn oriented_bidegree(
    degree: BivariateDegree,
    retained_parameter: CurveResultantParameter,
) -> (usize, usize) {
    match retained_parameter {
        CurveResultantParameter::First => (degree.first, degree.second),
        CurveResultantParameter::Second => (degree.second, degree.first),
    }
}

fn axis_factor_failure(
    status: BivariatePolynomialAxisFactorStatus,
) -> BivariatePolynomialAxisFactorReport {
    BivariatePolynomialAxisFactorReport {
        status,
        first_parameter_factor: Vec::new(),
        second_parameter_factor: Vec::new(),
        reduced_equations: None,
    }
}

fn common_axis_factor(
    equations: &[&BivariatePolynomial; 2],
    parameter: CurveResultantParameter,
) -> Option<Vec<Real>> {
    let mut factor = vec![Real::zero()];
    for equation in equations {
        match parameter {
            CurveResultantParameter::First => {
                let column_count = equation
                    .coefficients
                    .iter()
                    .map(Vec::len)
                    .max()
                    .unwrap_or(0);
                for second_power in 0..column_count {
                    let column = equation
                        .coefficients
                        .iter()
                        .map(|row| row.get(second_power).cloned().unwrap_or_else(Real::zero))
                        .collect::<Vec<_>>();
                    factor = exact_polynomial_gcd(&factor, &column)?;
                    if exact_unit_polynomial(&factor) {
                        return Some(factor);
                    }
                }
            }
            CurveResultantParameter::Second => {
                for row in &equation.coefficients {
                    factor = exact_polynomial_gcd(&factor, row)?;
                    if exact_unit_polynomial(&factor) {
                        return Some(factor);
                    }
                }
            }
        }
    }
    Some(factor)
}

fn exact_polynomial_gcd(left: &[Real], right: &[Real]) -> Option<Vec<Real>> {
    primitive_integer_polynomial_gcd(left, right).or_else(|| {
        polynomial_gcd(
            left.to_vec(),
            right.to_vec(),
            hyperlimit::PredicatePolicy::STRICT,
        )
    })
}

fn divide_bivariate_by_axis(
    polynomial: &BivariatePolynomial,
    factor: &[Real],
    parameter: CurveResultantParameter,
) -> Option<BivariatePolynomial> {
    let coefficients = match parameter {
        CurveResultantParameter::First => {
            let column_count = polynomial
                .coefficients
                .iter()
                .map(Vec::len)
                .max()
                .unwrap_or(0);
            let mut quotient_columns = Vec::with_capacity(column_count);
            let mut row_count = 0;
            for second_power in 0..column_count {
                let column = polynomial
                    .coefficients
                    .iter()
                    .map(|row| row.get(second_power).cloned().unwrap_or_else(Real::zero))
                    .collect::<Vec<_>>();
                let quotient = divide_polynomial_exact(column, factor)?;
                row_count = row_count.max(quotient.len());
                quotient_columns.push(quotient);
            }
            let mut coefficients = vec![vec![Real::zero(); column_count]; row_count];
            for (second_power, column) in quotient_columns.into_iter().enumerate() {
                for (first_power, coefficient) in column.into_iter().enumerate() {
                    coefficients[first_power][second_power] = coefficient;
                }
            }
            coefficients
        }
        CurveResultantParameter::Second => polynomial
            .coefficients
            .iter()
            .map(|row| divide_polynomial_exact(row.clone(), factor))
            .collect::<Option<Vec<_>>>()?,
    };
    Some(canonical_exact_bivariate(coefficients))
}

fn divide_polynomial_exact(dividend: Vec<Real>, divisor: &[Real]) -> Option<Vec<Real>> {
    let (quotient, remainder) = polynomial_div_rem_borrowed_divisor(
        dividend,
        divisor,
        hyperlimit::PredicatePolicy::STRICT,
    )?;
    exact_polynomial_is_zero(&remainder).then_some(quotient)
}

fn canonical_exact_bivariate(mut coefficients: Vec<Vec<Real>>) -> BivariatePolynomial {
    for row in &mut coefficients {
        while row.last().is_some_and(exact_real_is_zero) {
            row.pop();
        }
    }
    while coefficients.last().is_some_and(Vec::is_empty) {
        coefficients.pop();
    }
    if coefficients.is_empty() {
        coefficients.push(vec![Real::zero()]);
    }
    BivariatePolynomial::new(coefficients)
}

fn canonical_exact_trivariate(mut coefficients: Vec<Vec<Vec<Real>>>) -> TrivariatePolynomial {
    for plane in &mut coefficients {
        for row in plane.iter_mut() {
            while row.last().is_some_and(exact_real_is_zero) {
                row.pop();
            }
        }
        while plane.last().is_some_and(Vec::is_empty) {
            plane.pop();
        }
    }
    while coefficients.last().is_some_and(Vec::is_empty) {
        coefficients.pop();
    }
    if coefficients.is_empty() {
        coefficients.push(vec![vec![Real::zero()]]);
    }
    TrivariatePolynomial::new(coefficients)
}

fn exact_bivariate_is_zero(polynomial: &BivariatePolynomial) -> bool {
    polynomial
        .coefficients
        .iter()
        .flatten()
        .all(exact_real_is_zero)
}

const fn trivariate_axis_from_index(index: usize) -> TrivariatePolynomialAxis {
    match index {
        0 => TrivariatePolynomialAxis::First,
        1 => TrivariatePolynomialAxis::Second,
        2 => TrivariatePolynomialAxis::Third,
        _ => unreachable!(),
    }
}

fn trivariate_polynomial_is_empty(polynomial: &TrivariatePolynomial) -> bool {
    polynomial.coefficients.is_empty()
        || polynomial
            .coefficients
            .iter()
            .all(|rows| rows.iter().all(Vec::is_empty))
}

fn quadrivariate_polynomial_is_empty(polynomial: &QuadrivariatePolynomial) -> bool {
    polynomial.coefficients.is_empty()
        || polynomial
            .coefficients
            .iter()
            .all(|cubes| cubes.iter().all(|planes| planes.iter().all(Vec::is_empty)))
}

fn normalized_constraint(constraint: &[Real], min_precision: i32) -> Result<Option<Vec<Real>>, ()> {
    let constraint = trim_trailing_zeroes(constraint.to_vec(), min_precision)?;
    if constraint.len() <= 1 {
        return Ok(None);
    }
    let leading = constraint
        .last()
        .expect("a nonconstant constraint has a leading coefficient");
    let leading_reciprocal =
        crate::policy_division::reciprocal_after_certified_nonzero(leading).map_err(|_| ())?;
    Ok(Some(
        constraint
            .iter()
            .map(|coefficient| coefficient * &leading_reciprocal)
            .collect(),
    ))
}

fn quadrivariate_grid_exceeds_budget(degree_bounds: [usize; 3], maximum_degree: usize) -> bool {
    degree_bounds
        .into_iter()
        .any(|degree| degree > maximum_degree)
        || degree_bounds
            .into_iter()
            .try_fold(1_usize, |count, degree| count.checked_mul(degree + 1))
            .is_none()
}

#[inline]
fn certified_quadrivariate_degree(
    polynomial: &QuadrivariatePolynomial,
    min_precision: i32,
) -> Result<Option<[usize; 4]>, ()> {
    let mut degrees = None;
    for (first, cubes) in polynomial.coefficients.iter().enumerate() {
        for (second, planes) in cubes.iter().enumerate() {
            for (third, row) in planes.iter().enumerate() {
                for (fourth, coefficient) in row.iter().enumerate() {
                    match coefficient.certified_sign_until(min_precision) {
                        CertifiedRealSign::Known {
                            sign: RealSign::Zero,
                            ..
                        } => {}
                        CertifiedRealSign::Known { .. } => {
                            let degrees = degrees.get_or_insert([0, 0, 0, 0]);
                            degrees[0] = degrees[0].max(first);
                            degrees[1] = degrees[1].max(second);
                            degrees[2] = degrees[2].max(third);
                            degrees[3] = degrees[3].max(fourth);
                        }
                        CertifiedRealSign::Unknown { .. } => {
                            match crate::policy_division::strict_sign_after_refinement_failure(
                                coefficient,
                            ) {
                                Some(RealSign::Zero) => {}
                                Some(RealSign::Negative | RealSign::Positive) => {
                                    let degrees = degrees.get_or_insert([0, 0, 0, 0]);
                                    degrees[0] = degrees[0].max(first);
                                    degrees[1] = degrees[1].max(second);
                                    degrees[2] = degrees[2].max(third);
                                    degrees[3] = degrees[3].max(fourth);
                                }
                                None => return Err(()),
                            }
                        }
                    }
                }
            }
        }
    }
    Ok(degrees)
}

fn quadrivariate_fourth_axis_coefficient(
    polynomial: &QuadrivariatePolynomial,
    power: usize,
) -> TrivariatePolynomial {
    canonical_exact_trivariate(
        polynomial
            .coefficients
            .iter()
            .map(|cubes| {
                cubes
                    .iter()
                    .map(|planes| {
                        planes
                            .iter()
                            .map(|row| row.get(power).cloned().unwrap_or_else(Real::zero))
                            .collect()
                    })
                    .collect()
            })
            .collect(),
    )
}

fn evaluate_quadrivariate_at_first_three_parameters(
    polynomial: &QuadrivariatePolynomial,
    first_value: &Real,
    second_value: &Real,
    third_value: &Real,
) -> Vec<Real> {
    let dimensions = [
        polynomial.coefficients.len(),
        polynomial
            .coefficients
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0),
        polynomial
            .coefficients
            .iter()
            .flat_map(|cubes| cubes.iter())
            .map(Vec::len)
            .max()
            .unwrap_or(0),
        polynomial
            .coefficients
            .iter()
            .flat_map(|cubes| cubes.iter())
            .flat_map(|planes| planes.iter())
            .map(Vec::len)
            .max()
            .unwrap_or(0),
    ];
    let powers = |value: &Real, count: usize| {
        let mut powers = Vec::with_capacity(count);
        let mut power = Real::one();
        for _ in 0..count {
            powers.push(power.clone());
            power *= value;
        }
        powers
    };
    let first_powers = powers(first_value, dimensions[0]);
    let second_powers = powers(second_value, dimensions[1]);
    let third_powers = powers(third_value, dimensions[2]);
    let mut fiber = vec![Real::zero(); dimensions[3]];
    for (first, cubes) in polynomial.coefficients.iter().enumerate() {
        for (second, planes) in cubes.iter().enumerate() {
            for (third, row) in planes.iter().enumerate() {
                let scale = &first_powers[first] * &second_powers[second] * &third_powers[third];
                for (fourth, coefficient) in row.iter().enumerate() {
                    fiber[fourth] += coefficient * &scale;
                }
            }
        }
    }
    fiber
}

#[inline]
fn certified_trivariate_degree(
    polynomial: &TrivariatePolynomial,
    min_precision: i32,
) -> Result<Option<[usize; 3]>, ()> {
    let mut degrees = None;
    for (first, rows) in polynomial.coefficients.iter().enumerate() {
        for (second, row) in rows.iter().enumerate() {
            for (third, coefficient) in row.iter().enumerate() {
                match coefficient.certified_sign_until(min_precision) {
                    CertifiedRealSign::Known {
                        sign: RealSign::Zero,
                        ..
                    } => {}
                    CertifiedRealSign::Known { .. } => {
                        let degrees = degrees.get_or_insert([0, 0, 0]);
                        degrees[0] = degrees[0].max(first);
                        degrees[1] = degrees[1].max(second);
                        degrees[2] = degrees[2].max(third);
                    }
                    CertifiedRealSign::Unknown { .. } => {
                        match crate::policy_division::strict_sign_after_refinement_failure(
                            coefficient,
                        ) {
                            Some(RealSign::Zero) => {}
                            Some(RealSign::Negative | RealSign::Positive) => {
                                let degrees = degrees.get_or_insert([0, 0, 0]);
                                degrees[0] = degrees[0].max(first);
                                degrees[1] = degrees[1].max(second);
                                degrees[2] = degrees[2].max(third);
                            }
                            None => return Err(()),
                        }
                    }
                }
            }
        }
    }
    Ok(degrees)
}

fn evaluate_trivariate_at_retained_parameters(
    polynomial: &TrivariatePolynomial,
    eliminated_axis: TrivariatePolynomialAxis,
    first_retained_value: &Real,
    second_retained_value: &Real,
) -> Vec<Real> {
    let dimensions = [
        polynomial.coefficients.len(),
        polynomial
            .coefficients
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0),
        polynomial
            .coefficients
            .iter()
            .flat_map(|rows| rows.iter())
            .map(Vec::len)
            .max()
            .unwrap_or(0),
    ];
    let eliminated_axis = eliminated_axis.index();
    let retained_axes = match eliminated_axis {
        0 => [1, 2],
        1 => [0, 2],
        2 => [0, 1],
        _ => unreachable!(),
    };
    let powers = |value: &Real, count: usize| {
        let mut powers = Vec::with_capacity(count);
        let mut power = Real::one();
        for _ in 0..count {
            powers.push(power.clone());
            power *= value;
        }
        powers
    };
    let first_powers = powers(first_retained_value, dimensions[retained_axes[0]]);
    let second_powers = powers(second_retained_value, dimensions[retained_axes[1]]);
    let mut fiber = vec![Real::zero(); dimensions[eliminated_axis]];
    for (first, rows) in polynomial.coefficients.iter().enumerate() {
        for (second, row) in rows.iter().enumerate() {
            for (third, coefficient) in row.iter().enumerate() {
                let exponents = [first, second, third];
                fiber[exponents[eliminated_axis]] += coefficient
                    * &first_powers[exponents[retained_axes[0]]]
                    * &second_powers[exponents[retained_axes[1]]];
            }
        }
    }
    fiber
}

fn exact_polynomial_is_zero(polynomial: &[Real]) -> bool {
    polynomial.iter().all(exact_real_is_zero)
}

fn exact_unit_polynomial(polynomial: &[Real]) -> bool {
    polynomial.len() == 1
        && polynomial[0]
            .exact_rational_ref()
            .is_some_and(|coefficient| coefficient.is_one())
}

fn strict_reciprocal(value: &Real) -> Option<Real> {
    crate::policy_division::reciprocal_with_policy(value, hyperlimit::PredicatePolicy::STRICT)
}

fn strict_reciprocal_after_inverse_failure(value: &Real) -> Option<Real> {
    hyperlimit::reciprocal_real(value, hyperlimit::PredicatePolicy::STRICT)
        .ok()?
        .value()
}

fn exact_real_is_zero(value: &Real) -> bool {
    if let Some(coefficient) = value.exact_rational_ref() {
        return coefficient.is_zero();
    }
    match value.certified_sign_until(hyperlimit::PredicatePolicy::MAX_REFINEMENT_PRECISION) {
        CertifiedRealSign::Known {
            sign: RealSign::Zero,
            ..
        } => true,
        CertifiedRealSign::Known { .. } => false,
        CertifiedRealSign::Unknown { .. } => value
            .exact_rational_normal_form()
            .is_some_and(|value| value.is_zero()),
    }
}

fn bivariate_polynomial_is_empty(polynomial: &BivariatePolynomial) -> bool {
    polynomial.coefficients.is_empty() || polynomial.coefficients.iter().all(Vec::is_empty)
}

fn certified_bivariate_degree(
    polynomial: &BivariatePolynomial,
    min_precision: i32,
) -> Result<Option<BivariateDegree>, ()> {
    let first = certified_first_parameter_degree(polynomial, min_precision)?;
    let second = certified_second_parameter_degree(polynomial, min_precision)?;
    match (first, second) {
        (Some(first), Some(second)) => Ok(Some(BivariateDegree { first, second })),
        (None, None) => Ok(None),
        _ => unreachable!("a nonzero bivariate polynomial has both axis degrees"),
    }
}

#[inline]
fn certified_first_parameter_degree(
    polynomial: &BivariatePolynomial,
    min_precision: i32,
) -> Result<Option<usize>, ()> {
    for (index, row) in polynomial.coefficients.iter().enumerate().rev() {
        let mut unknown = false;
        for coefficient in row {
            match coefficient.certified_sign_until(min_precision) {
                CertifiedRealSign::Known {
                    sign: RealSign::Zero,
                    ..
                } => {}
                CertifiedRealSign::Known { .. } => return Ok(Some(index)),
                CertifiedRealSign::Unknown { .. } => {
                    match crate::policy_division::strict_sign_after_refinement_failure(coefficient)
                    {
                        Some(RealSign::Zero) => {}
                        Some(RealSign::Negative | RealSign::Positive) => return Ok(Some(index)),
                        None => unknown = true,
                    }
                }
            }
        }
        if unknown {
            return Err(());
        }
    }
    Ok(None)
}

#[inline]
fn certified_second_parameter_degree(
    polynomial: &BivariatePolynomial,
    min_precision: i32,
) -> Result<Option<usize>, ()> {
    let coefficient_count = polynomial
        .coefficients
        .iter()
        .map(Vec::len)
        .max()
        .unwrap_or(0);
    for index in (0..coefficient_count).rev() {
        let mut unknown = false;
        for row in &polynomial.coefficients {
            let Some(coefficient) = row.get(index) else {
                continue;
            };
            match coefficient.certified_sign_until(min_precision) {
                CertifiedRealSign::Known {
                    sign: RealSign::Zero,
                    ..
                } => {}
                CertifiedRealSign::Known { .. } => return Ok(Some(index)),
                CertifiedRealSign::Unknown { .. } => {
                    match crate::policy_division::strict_sign_after_refinement_failure(coefficient)
                    {
                        Some(RealSign::Zero) => {}
                        Some(RealSign::Negative | RealSign::Positive) => return Ok(Some(index)),
                        None => unknown = true,
                    }
                }
            }
        }
        if unknown {
            return Err(());
        }
    }
    Ok(None)
}

#[inline]
fn certified_nonzero_degree(
    coefficients: &[Real],
    min_precision: i32,
) -> Result<Option<usize>, ()> {
    for (index, coefficient) in coefficients.iter().enumerate().rev() {
        match coefficient.certified_sign_until(min_precision) {
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            } => {}
            CertifiedRealSign::Known { .. } => return Ok(Some(index)),
            CertifiedRealSign::Unknown { .. } => {
                match crate::policy_division::strict_sign_after_refinement_failure(coefficient) {
                    Some(RealSign::Zero) => {}
                    Some(RealSign::Negative | RealSign::Positive) => return Ok(Some(index)),
                    None => return Err(()),
                }
            }
        }
    }
    Ok(None)
}

#[inline]
fn trim_trailing_zeroes(coefficients: Vec<Real>, min_precision: i32) -> Result<Vec<Real>, ()> {
    for (index, coefficient) in coefficients.iter().enumerate().rev() {
        match coefficient.certified_sign_until(min_precision) {
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            } => {}
            CertifiedRealSign::Known { .. } => return Ok(coefficients[..=index].to_vec()),
            CertifiedRealSign::Unknown { .. } => {
                return trim_trailing_zeroes_strict_fallback(&coefficients, index, min_precision);
            }
        }
    }
    Ok(vec![Real::zero()])
}

#[cold]
fn trim_trailing_zeroes_strict_fallback(
    coefficients: &[Real],
    start: usize,
    min_precision: i32,
) -> Result<Vec<Real>, ()> {
    for (index, coefficient) in coefficients[..=start].iter().enumerate().rev() {
        match crate::policy_division::strict_sign_after_refinement(coefficient, min_precision) {
            Some(RealSign::Zero) => {}
            Some(RealSign::Negative | RealSign::Positive) => {
                return Ok(coefficients[..=index].to_vec());
            }
            None => return Err(()),
        }
    }
    Ok(vec![Real::zero()])
}

fn rational_curve_has_empty_polynomial(curve: &RationalParametricCurve2) -> bool {
    curve.x_numerator.is_empty() || curve.y_numerator.is_empty() || curve.weight.is_empty()
}

#[inline]
fn is_certified_zero_polynomial(coefficients: &[Real], min_precision: i32) -> Result<bool, ()> {
    for (index, coefficient) in coefficients.iter().enumerate() {
        match coefficient.certified_sign_until(min_precision) {
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            } => {}
            CertifiedRealSign::Known { .. } => return Ok(false),
            CertifiedRealSign::Unknown { .. } => {
                return is_certified_zero_polynomial_strict_fallback(
                    coefficients,
                    index,
                    min_precision,
                );
            }
        }
    }
    Ok(true)
}

#[cold]
fn is_certified_zero_polynomial_strict_fallback(
    coefficients: &[Real],
    start: usize,
    min_precision: i32,
) -> Result<bool, ()> {
    for coefficient in &coefficients[start..] {
        match crate::policy_division::strict_sign_after_refinement(coefficient, min_precision) {
            Some(RealSign::Zero) => {}
            Some(RealSign::Negative | RealSign::Positive) => return Ok(false),
            None => return Err(()),
        }
    }
    Ok(true)
}

fn parametric_coordinate_difference(first: &[Real], second: &[Real]) -> BivariatePolynomial {
    let mut coefficients = vec![vec![Real::zero(); second.len()]; first.len()];
    for (index, coefficient) in first.iter().enumerate() {
        coefficients[index][0] += coefficient;
    }
    for (index, coefficient) in second.iter().enumerate() {
        coefficients[0][index] -= coefficient;
    }
    BivariatePolynomial::new(coefficients)
}

fn rational_cross_equation(
    first_coordinate: &[Real],
    first_weight: &[Real],
    second_coordinate: &[Real],
    second_weight: &[Real],
) -> BivariatePolynomial {
    let first_count = first_coordinate.len().max(first_weight.len());
    let second_count = second_coordinate.len().max(second_weight.len());
    let mut coefficients = vec![vec![Real::zero(); second_count]; first_count];
    for (first_index, first_coordinate) in first_coordinate.iter().enumerate() {
        for (second_index, second_weight) in second_weight.iter().enumerate() {
            coefficients[first_index][second_index] += first_coordinate * second_weight;
        }
    }
    for (first_index, first_weight) in first_weight.iter().enumerate() {
        for (second_index, second_coordinate) in second_coordinate.iter().enumerate() {
            coefficients[first_index][second_index] -= first_weight * second_coordinate;
        }
    }
    BivariatePolynomial::new(coefficients)
}

fn evaluate_bivariate_at_retained_parameter(
    polynomial: &BivariatePolynomial,
    parameter: &Real,
    retained_parameter: CurveResultantParameter,
) -> Vec<Real> {
    match retained_parameter {
        CurveResultantParameter::First => {
            let coefficient_count = polynomial
                .coefficients
                .iter()
                .map(Vec::len)
                .max()
                .unwrap_or(0);
            (0..coefficient_count)
                .map(|second_power| {
                    polynomial
                        .coefficients
                        .iter()
                        .rev()
                        .fold(Real::zero(), |value, row| {
                            value * parameter
                                + row.get(second_power).cloned().unwrap_or_else(Real::zero)
                        })
                })
                .collect()
        }
        CurveResultantParameter::Second => polynomial
            .coefficients
            .iter()
            .map(|row| eval_univariate(row, parameter))
            .collect(),
    }
}

fn eval_univariate(coefficients: &[Real], value: &Real) -> Real {
    let mut result = Real::zero();
    for coefficient in coefficients.iter().rev() {
        result = result * value.clone() + coefficient.clone();
    }
    result
}

/// Why exact interpolation could not publish a trimmed polynomial.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum InterpolationFailure {
    /// A divided difference had no exact quotient.
    Division,
    /// The interpolant exists, but a trailing coefficient's zero status is
    /// undecided, so its degree cannot be certified.
    UndecidedCoefficient,
}

const fn trivariate_interpolation_status(
    failure: InterpolationFailure,
) -> TrivariateConstraintResultantStatus {
    match failure {
        InterpolationFailure::Division => {
            TrivariateConstraintResultantStatus::InterpolationDivisionFailed
        }
        InterpolationFailure::UndecidedCoefficient => {
            TrivariateConstraintResultantStatus::UndecidedCoefficient
        }
    }
}

fn interpolate_samples(
    samples: &[PolynomialSample],
    min_precision: i32,
) -> Result<Vec<Real>, InterpolationFailure> {
    trim_trailing_zeroes(interpolate_samples_untrimmed(samples)?, min_precision)
        .map_err(|_| InterpolationFailure::UndecidedCoefficient)
}

/// Interpolates exact values at the nodes `0, 1, ..., n - 1` by divided
/// differences, keeping all `n` coefficients including trailing zeros.
pub fn interpolate_integer_node_samples(values: &[Real]) -> Option<Vec<Real>> {
    let samples = values
        .iter()
        .enumerate()
        .map(|(node, value)| PolynomialSample {
            parameter_value: Real::from(node as u64),
            value: value.clone(),
        })
        .collect::<Vec<_>>();
    interpolate_samples_untrimmed(&samples).ok()
}

fn interpolate_samples_untrimmed(
    samples: &[PolynomialSample],
) -> Result<Vec<Real>, InterpolationFailure> {
    // Divided differences retain the exact sampled polynomial on arbitrary
    // distinct nodes, including grids with omitted degree-drop fibers. Unlike
    // rebuilding every Lagrange basis, construction takes quadratic work and
    // linear live storage. Coefficients remain arbitrary exact Real values.
    // Interpolation is linear in its ordinates. Remove their common rational
    // content once instead of carrying it through every divided difference;
    // restore its signed value only after reconstruction. Arbitrary exact
    // ordinates retain the same general coefficient-field path.
    let rational_values = samples
        .iter()
        .map(|sample| sample.value.exact_rational_ref())
        .collect::<Option<Vec<_>>>();
    let (mut differences, scale) = if let Some(values) = rational_values {
        let integers = Rational::primitive_bigint_ratio(&values);
        let scale = values
            .iter()
            .zip(&integers)
            .find(|(value, _)| !value.is_zero())
            .map(|(value, integer)| Real::from(*value / Rational::from_bigint(integer.clone())));
        (
            integers
                .into_iter()
                .map(|value| Real::from(Rational::from_bigint(value)))
                .collect::<Vec<_>>(),
            scale,
        )
    } else {
        (
            samples.iter().map(|sample| sample.value.clone()).collect(),
            None,
        )
    };
    for order in 1..samples.len() {
        for index in (order..samples.len()).rev() {
            differences[index] = ((&differences[index] - &differences[index - 1])
                / (&samples[index].parameter_value - &samples[index - order].parameter_value))
                .map_err(|_| InterpolationFailure::Division)?;
        }
    }
    let mut result = Vec::new();
    for (sample, coefficient) in samples.iter().zip(differences).rev() {
        result = multiply_by_linear_factor(result, -sample.parameter_value.clone());
        result[0] += coefficient;
    }
    if let Some(scale) = scale {
        for coefficient in &mut result {
            *coefficient *= &scale;
        }
    }
    Ok(result)
}

fn multiply_by_linear_factor(polynomial: Vec<Real>, constant: Real) -> Vec<Real> {
    let mut result = vec![Real::zero(); polynomial.len() + 1];
    for (index, coefficient) in polynomial.into_iter().enumerate() {
        result[index] += coefficient.clone() * constant.clone();
        result[index + 1] += coefficient;
    }
    result
}

/// Keeps a bounded resultant as the hot schedule while removing its degree
/// limit as a mathematical boundary. The continuation changes only resource
/// scheduling: coefficient certification and every later candidate replay
/// retain their requested exact predicate policy.
#[inline]
pub fn continue_resultant_after_degree_bound(
    report: CurveIntersectionResultantReport,
    config: CurveIntersectionResultantConfig,
    continuation: impl FnOnce(CurveIntersectionResultantConfig) -> CurveIntersectionResultantReport,
) -> CurveIntersectionResultantReport {
    if report.status != CurveIntersectionResultantStatus::DegreeBoundExceeded
        || config.max_resultant_degree == usize::MAX
    {
        return report;
    }
    #[cfg(feature = "dispatch-trace")]
    hyperreal::dispatch_trace::record(
        "hypersolve",
        "bivariate-resultant",
        "unbounded-cold-continuation",
    );
    continuation(CurveIntersectionResultantConfig {
        max_resultant_degree: usize::MAX,
        ..config
    })
}

/// Keeps the bounded bivariate system resultant as the hot schedule while
/// retrying past its degree budget, which is never a mathematical boundary.
pub fn resultant_bivariate_polynomial_system_complete(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionResultantReport {
    let report = resultant_bivariate_polynomial_system(
        first_equation,
        second_equation,
        retained_parameter,
        config,
    );
    continue_resultant_after_degree_bound(report, config, |config| {
        resultant_bivariate_polynomial_system(
            first_equation,
            second_equation,
            retained_parameter,
            config,
        )
    })
}

/// Keeps bounded cofactor interpolation on the hot path while ensuring that
/// its degree budget cannot discard an otherwise exact parameter pairing.
#[inline]
pub fn linear_parameter_lifts_bivariate_polynomial_system_complete(
    first_equation: &BivariatePolynomial,
    second_equation: &BivariatePolynomial,
    retained_parameter: CurveResultantParameter,
    config: CurveIntersectionResultantConfig,
) -> CurveIntersectionParameterLiftReport {
    let report = linear_parameter_lifts_bivariate_polynomial_system(
        first_equation,
        second_equation,
        retained_parameter,
        config,
    );
    if report.status != CurveIntersectionParameterLiftStatus::DegreeBoundExceeded
        || config.max_resultant_degree == usize::MAX
    {
        return report;
    }
    #[cfg(feature = "dispatch-trace")]
    hyperreal::dispatch_trace::record(
        "hypersolve",
        "bivariate-parameter-lift",
        "unbounded-cold-continuation",
    );
    linear_parameter_lifts_bivariate_polynomial_system(
        first_equation,
        second_equation,
        retained_parameter,
        CurveIntersectionResultantConfig {
            max_resultant_degree: usize::MAX,
            ..config
        },
    )
}

#[cfg(test)]
mod tests {
    mod budget;
    mod component_budget;
    mod fixed_budget;
    mod lift_budget;

    use proptest::prelude::*;

    use super::*;

    fn real(value: i64) -> Real {
        Real::from(value)
    }

    #[test]
    fn interpolation_preserves_scaled_integer_valued_polynomials() {
        // Binomial(t,6) has integer values on integer nodes but fractional
        // coefficients. Nonuniform samples omit some zero fibers. Content
        // extraction must preserve the complete polynomial, not just its roots.
        let magnitude = (0..12).fold(real(1), |value, _| value * real(1009));
        for scale in [real(0), real(1), (-magnitude / real(37)).unwrap()] {
            let evaluate = |parameter: &Real| {
                (0..6).fold(scale.clone(), |value, index| {
                    value * (parameter - real(index))
                }) / real(720)
            };
            for reversed in [false, true] {
                let mut samples = [0, 1, 2, 4, 5, 8, 11]
                    .into_iter()
                    .map(|node| {
                        let parameter_value = real(node);
                        let value = evaluate(&parameter_value).unwrap();
                        PolynomialSample {
                            parameter_value,
                            value,
                        }
                    })
                    .collect::<Vec<_>>();
                if reversed {
                    samples.reverse();
                }
                let coefficients = interpolate_samples(&samples, -512).unwrap();
                assert!(coefficients.len() <= 7);
                for node in -4..=16 {
                    let node = real(node);
                    assert!(eval_univariate(&coefficients, &node) == evaluate(&node).unwrap());
                }
            }
        }
    }

    #[test]
    fn interpolation_preserves_arbitrary_exact_values_on_nonuniform_nodes() {
        let coefficients = vec![
            Real::pi(),
            real(2).sqrt().unwrap(),
            Real::from(Rational::fraction(-3, 5).unwrap()),
            real(7),
        ];
        let nodes = [
            real(-3),
            Real::from(Rational::fraction(1, 2).unwrap()),
            real(2),
            real(5),
        ];
        for reversed in [false, true] {
            let mut samples = nodes
                .iter()
                .map(|parameter| PolynomialSample {
                    parameter_value: parameter.clone(),
                    value: eval_univariate(&coefficients, parameter),
                })
                .collect::<Vec<_>>();
            if reversed {
                samples.reverse();
            }
            let interpolated =
                interpolate_samples(&samples, -512).expect("distinct exact nodes interpolate");
            assert_eq!(interpolated.len(), coefficients.len());
            for (actual, expected) in interpolated.iter().zip(&coefficients) {
                assert!(matches!(
                    (actual - expected).certified_sign_until(-512),
                    CertifiedRealSign::Known {
                        sign: RealSign::Zero,
                        ..
                    }
                ));
            }
        }
        let duplicate = vec![
            PolynomialSample {
                parameter_value: real(1),
                value: real(2),
            },
            PolynomialSample {
                parameter_value: real(1),
                value: real(3),
            },
        ];
        assert_eq!(
            interpolate_samples(&duplicate, -512),
            Err(InterpolationFailure::Division)
        );
        assert!(interpolate_samples(&[], -512).unwrap() == vec![real(0)]);
    }

    #[test]
    fn bivariate_affine_substitution_preserves_ragged_exact_polynomials() {
        let evaluate = |polynomial: &BivariatePolynomial, x: &Real, y: &Real| {
            let rows = polynomial
                .coefficients
                .iter()
                .map(|row| Real::eval_poly(row, y))
                .collect::<Vec<_>>();
            Real::eval_poly(&rows, x)
        };
        let polynomials = [
            BivariatePolynomial::new(vec![]),
            BivariatePolynomial::new(vec![vec![], vec![real(0)], vec![]]),
            BivariatePolynomial::new(vec![vec![real(7)]]),
            BivariatePolynomial::new(vec![
                vec![real(2), real(-3), real(5), real(0)],
                vec![],
                vec![real(-7)],
                vec![real(11), real(13)],
                vec![],
            ]),
        ];
        for polynomial in polynomials {
            for [a, b, c, d] in [
                [1, 0, 1, 0],
                [-2, 3, 4, -5],
                [0, 3, -1, 2],
                [2, -3, 0, 4],
                [0, 2, 0, -1],
            ] {
                let [a, b, c, d] = [a, b, c, d].map(real);
                let transformed = polynomial.substitute_affine(&a, &b, &c, &d);
                // A complete interpolation grid independently determines this
                // bounded-degree polynomial, including reversed/exterior maps.
                for x in -2..=3 {
                    for y in -2..=2 {
                        let x = (real(x) / real(3)).unwrap();
                        let y = (real(y) / real(5)).unwrap();
                        let expected = evaluate(&polynomial, &(&a * &x + &b), &(&c * &y + &d));
                        assert_eq!(evaluate(&transformed, &x, &y), expected);
                    }
                }
            }
        }
    }

    #[test]
    fn bivariate_affine_substitution_retains_general_exact_coefficients_and_maps() {
        let root = real(2).sqrt().unwrap();
        let pi = Real::pi();
        // P(x,y) = sqrt(2) + pi*x + x*y + sqrt(2)*y^2.
        let polynomial = BivariatePolynomial::new(vec![
            vec![root.clone(), real(0), root.clone()],
            vec![pi.clone(), real(1)],
        ]);
        let transformed = polynomial.substitute_affine(&root, &pi, &real(-2), &root);
        assert!(
            transformed
                .coefficients
                .iter()
                .flatten()
                .any(|value| value.exact_rational_ref().is_none())
        );
        for x in -1..=1 {
            for y in -1..=1 {
                let x = real(x);
                let y = real(y);
                let source_x = &root * &x + &pi;
                let source_y = real(-2) * &y + &root;
                let expected =
                    &root + &pi * &source_x + &source_x * &source_y + &root * &source_y * &source_y;
                let actual = Real::eval_poly(
                    &transformed
                        .coefficients
                        .iter()
                        .map(|row| Real::eval_poly(row, &y))
                        .collect::<Vec<_>>(),
                    &x,
                );
                assert!(matches!(
                    (actual - expected).certified_sign_until(-512),
                    CertifiedRealSign::Known {
                        sign: RealSign::Zero,
                        ..
                    }
                ));
            }
        }
    }

    fn reported_rational_component(
        report: &BivariatePolynomialComponentReport,
    ) -> BivariatePolynomial {
        match report.retained_parameter {
            CurveResultantParameter::First => {
                let row_count = report
                    .numerator_coefficients
                    .len()
                    .max(report.denominator_coefficients.len());
                BivariatePolynomial::new(
                    (0..row_count)
                        .map(|power| {
                            vec![
                                -report
                                    .numerator_coefficients
                                    .get(power)
                                    .cloned()
                                    .unwrap_or_else(Real::zero),
                                report
                                    .denominator_coefficients
                                    .get(power)
                                    .cloned()
                                    .unwrap_or_else(Real::zero),
                            ]
                        })
                        .collect(),
                )
            }
            CurveResultantParameter::Second => BivariatePolynomial::new(vec![
                report
                    .numerator_coefficients
                    .iter()
                    .cloned()
                    .map(std::ops::Neg::neg)
                    .collect(),
                report.denominator_coefficients.clone(),
            ]),
        }
    }

    fn line_x_axis() -> PolynomialParametricCurve2 {
        PolynomialParametricCurve2::new(vec![real(0), real(1)], vec![real(0)])
    }

    fn multiply_axis_factors(
        polynomial: &BivariatePolynomial,
        first_factor: &[Real],
        second_factor: &[Real],
    ) -> BivariatePolynomial {
        let first_degree_count = polynomial.coefficients.len() + first_factor.len() - 1;
        let second_degree_count = polynomial
            .coefficients
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0)
            + second_factor.len()
            - 1;
        let mut coefficients = vec![vec![Real::zero(); second_degree_count]; first_degree_count];
        for (first_power, row) in polynomial.coefficients.iter().enumerate() {
            for (second_power, coefficient) in row.iter().enumerate() {
                for (first_delta, first_scale) in first_factor.iter().enumerate() {
                    for (second_delta, second_scale) in second_factor.iter().enumerate() {
                        coefficients[first_power + first_delta][second_power + second_delta] +=
                            coefficient * first_scale * second_scale;
                    }
                }
            }
        }
        canonical_exact_bivariate(coefficients)
    }

    fn multiply_bivariate(
        first: &BivariatePolynomial,
        second: &BivariatePolynomial,
    ) -> BivariatePolynomial {
        let first_columns = first.coefficients.iter().map(Vec::len).max().unwrap_or(0);
        let second_columns = second.coefficients.iter().map(Vec::len).max().unwrap_or(0);
        let mut coefficients = vec![
            vec![Real::zero(); first_columns + second_columns - 1];
            first.coefficients.len() + second.coefficients.len() - 1
        ];
        for (first_power, first_row) in first.coefficients.iter().enumerate() {
            for (second_power, second_row) in second.coefficients.iter().enumerate() {
                for (first_column, first_coefficient) in first_row.iter().enumerate() {
                    for (second_column, second_coefficient) in second_row.iter().enumerate() {
                        coefficients[first_power + second_power][first_column + second_column] +=
                            first_coefficient * second_coefficient;
                    }
                }
            }
        }
        canonical_exact_bivariate(coefficients)
    }

    fn assert_bivariate_exactly_equal(left: &BivariatePolynomial, right: &BivariatePolynomial) {
        let first_count = left.coefficients.len().max(right.coefficients.len());
        let second_count = left
            .coefficients
            .iter()
            .chain(&right.coefficients)
            .map(Vec::len)
            .max()
            .unwrap_or(0);
        for first_power in 0..first_count {
            for second_power in 0..second_count {
                let left = left
                    .coefficients
                    .get(first_power)
                    .and_then(|row| row.get(second_power))
                    .cloned()
                    .unwrap_or_else(Real::zero);
                let right = right
                    .coefficients
                    .get(first_power)
                    .and_then(|row| row.get(second_power))
                    .cloned()
                    .unwrap_or_else(Real::zero);
                let difference = left - right;
                assert!(
                    matches!(
                        difference.certified_sign_until(-512),
                        CertifiedRealSign::Known {
                            sign: RealSign::Zero,
                            ..
                        }
                    ) || hyperlimit::compare_reals(
                        &difference,
                        &Real::zero(),
                        hyperlimit::PredicatePolicy::STRICT,
                    )
                    .value()
                        == Some(std::cmp::Ordering::Equal)
                );
            }
        }
    }

    fn swap_bivariate(polynomial: &BivariatePolynomial) -> BivariatePolynomial {
        let second_count = polynomial
            .coefficients
            .iter()
            .map(Vec::len)
            .max()
            .unwrap_or(0);
        let mut coefficients =
            vec![vec![Real::zero(); polynomial.coefficients.len()]; second_count];
        for (first_power, row) in polynomial.coefficients.iter().enumerate() {
            for (second_power, coefficient) in row.iter().enumerate() {
                coefficients[second_power][first_power] = coefficient.clone();
            }
        }
        canonical_exact_bivariate(coefficients)
    }

    #[test]
    fn curve_resultant_finds_parabola_horizontal_intersections() {
        let parabola = PolynomialParametricCurve2::new(
            vec![real(0), real(1)],
            vec![real(0), real(0), real(1)],
        );
        let horizontal = PolynomialParametricCurve2::new(vec![real(0), real(1)], vec![real(1)]);

        let report = resultant_parametric_curve_intersection(
            &parabola,
            &horizontal,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        assert_eq!(report.degree_bound, 2);
        assert_eq!(
            report.resultant_coefficients,
            vec![real(-1), real(0), real(1)]
        );
    }

    #[test]
    fn curve_resultant_reports_parallel_disjoint_line_constant() {
        let first = line_x_axis();
        let second = PolynomialParametricCurve2::new(vec![real(0), real(1)], vec![real(1)]);

        let report = resultant_parametric_curve_intersection(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        assert_eq!(report.resultant_coefficients, vec![real(-1)]);
    }

    #[test]
    fn curve_resultant_retaining_second_swaps_parameters() {
        let vertical = PolynomialParametricCurve2::new(vec![real(2)], vec![real(0), real(1)]);
        let horizontal = line_x_axis();

        let report = resultant_parametric_curve_intersection(
            &vertical,
            &horizontal,
            CurveResultantParameter::Second,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        assert_eq!(report.retained_parameter, CurveResultantParameter::Second);
        assert_eq!(report.eliminated_parameter, CurveResultantParameter::First);
        assert_eq!(report.resultant_coefficients, vec![real(-2), real(1)]);
    }

    #[test]
    fn bivariate_system_eliminates_either_parameter_with_the_same_root() {
        // `u-t=0` and `u+t-1=0` meet only at `t=u=1/2`.
        let first = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let second = BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]);

        for retained_parameter in [
            CurveResultantParameter::First,
            CurveResultantParameter::Second,
        ] {
            let report = resultant_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            assert_eq!(report.degree_bound, 2);
            assert_eq!(report.resultant_coefficients.len(), 2);
            assert_eq!(
                &report.resultant_coefficients[0] * real(2),
                -report.resultant_coefficients[1].clone()
            );
        }
    }

    #[test]
    fn equal_degree_bezout_resultant_preserves_exact_orientation_on_either_axis() {
        // Eliminating `u` from `u^2-t` and `u^2-1` gives `(t-1)^2`.
        // Degree two exercises the sign correction between the Bezout
        // determinant convention and `resultant(first, second)`.
        let first = BivariatePolynomial::new(vec![vec![real(0), real(0), real(1)], vec![real(-1)]]);
        let second = BivariatePolynomial::new(vec![vec![real(-1), real(0), real(1)]]);
        let expected = vec![real(1), real(-2), real(1)];

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            assert_eq!(
                symbolic_bivariate_bezout_resultant(&first, &second, retained_parameter, 2),
                Some(expected.clone())
            );
            let report = resultant_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            assert_eq!(report.resultant_coefficients, expected);
        }
    }

    #[test]
    fn dense_resultant_preserves_signed_scale_and_repeated_factors() {
        // Res_u(u^n-A(t), u^n-A(t)+Q(t)) = Q(t)^n. Choosing a
        // dense Q=(t-2)^32 exercises packed determinant arithmetic; the
        // binomial theorem independently supplies all output coefficients.
        let binomial_power = |degree: usize| {
            let mut choose = num::BigInt::from(1_u8);
            (0..=degree)
                .map(|power| {
                    if power > 0 {
                        choose = choose.clone() * (degree + 1 - power) / power;
                    }
                    Real::from(Rational::from_bigint(
                        &choose * num::BigInt::from(-2_i8).pow((degree - power) as u32),
                    ))
                })
                .collect::<Vec<_>>()
        };
        let first_scale = (real(2) / real(3)).unwrap();
        let second_scale = (real(-3) / real(5)).unwrap();
        for degree in 1..=3 {
            let mut first = vec![vec![Real::zero(); degree + 1]; 34];
            first[0][degree] = first_scale.clone();
            first[33][0] = -first_scale.clone();
            let mut second = vec![vec![Real::zero(); degree + 1]; 34];
            second[0][degree] = second_scale.clone();
            second[33][0] = -second_scale.clone();
            for (power, coefficient) in binomial_power(32).into_iter().enumerate() {
                second[power][0] = coefficient * &second_scale;
            }
            let scale =
                (0..degree).fold(Real::one(), |value, _| value * &first_scale * &second_scale);
            let expected = binomial_power(32 * degree)
                .into_iter()
                .map(|coefficient| coefficient * &scale)
                .collect::<Vec<_>>();
            let first = BivariatePolynomial::new(first);
            let second = BivariatePolynomial::new(second);
            for (first, second, retained_parameter) in [
                (
                    first.clone(),
                    second.clone(),
                    CurveResultantParameter::First,
                ),
                (
                    swap_bivariate(&first),
                    swap_bivariate(&second),
                    CurveResultantParameter::Second,
                ),
            ] {
                let report = resultant_bivariate_polynomial_system(
                    &first,
                    &second,
                    retained_parameter,
                    CurveIntersectionResultantConfig {
                        max_resultant_degree: 66 * degree,
                        ..CurveIntersectionResultantConfig::default()
                    },
                );
                assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
                assert_eq!(report.resultant_coefficients, expected);
            }
        }
    }

    #[test]
    fn equal_degree_bezout_matches_sylvester_through_degree_five() {
        for degree in 1..=5 {
            let coefficients = |salt: usize| {
                (0..=2)
                    .map(|retained_power| {
                        (0..=degree)
                            .map(|eliminated_power| {
                                let value = ((retained_power + 2) * (eliminated_power + 3)
                                    + salt * (retained_power + eliminated_power + 1))
                                    % 11;
                                real(value as i64 - 5)
                            })
                            .collect::<Vec<_>>()
                    })
                    .collect::<Vec<_>>()
            };
            let mut first = coefficients(1);
            let mut second = coefficients(3);
            first[0][degree] = real(1);
            second[0][degree] = real(-2);
            let first = BivariatePolynomial::new(first);
            let second = BivariatePolynomial::new(second);

            for (first, second, retained_parameter) in [
                (
                    first.clone(),
                    second.clone(),
                    CurveResultantParameter::First,
                ),
                (
                    swap_bivariate(&first),
                    swap_bivariate(&second),
                    CurveResultantParameter::Second,
                ),
            ] {
                assert_eq!(
                    symbolic_bivariate_bezout_resultant(
                        &first,
                        &second,
                        retained_parameter,
                        degree,
                    ),
                    symbolic_bivariate_sylvester_resultant(
                        &first,
                        &second,
                        retained_parameter,
                        degree,
                        degree,
                    ),
                    "degree {degree}, retained {retained_parameter:?}"
                );
            }
        }
    }

    #[test]
    fn bivariate_axis_factors_extract_first_parameter_content_exactly() {
        let factor = vec![real(-2), real(1)];
        let first_primitive = BivariatePolynomial::new(vec![vec![real(1), real(2)], vec![real(3)]]);
        let second_primitive =
            BivariatePolynomial::new(vec![vec![real(4)], vec![real(5), real(6)]]);
        let first = multiply_axis_factors(&first_primitive, &factor, &[real(1)]);
        let second = multiply_axis_factors(&second_primitive, &factor, &[real(1)]);

        let report = extract_bivariate_polynomial_system_axis_factors(&first, &second);

        assert_eq!(report.status, BivariatePolynomialAxisFactorStatus::Reduced);
        assert_eq!(report.first_parameter_factor, factor);
        assert_eq!(report.second_parameter_factor, vec![real(1)]);
        assert_eq!(
            report.reduced_equations,
            Some([first_primitive, second_primitive])
        );
    }

    #[test]
    fn bivariate_axis_factors_extract_both_axes_sequentially() {
        let first_factor = vec![real(-2), real(1)];
        let second_factor = vec![real(3), real(1)];
        let first_primitive = BivariatePolynomial::new(vec![vec![real(1), real(2)], vec![real(3)]]);
        let second_primitive =
            BivariatePolynomial::new(vec![vec![real(4)], vec![real(5), real(6)]]);
        let first = multiply_axis_factors(&first_primitive, &first_factor, &second_factor);
        let second = multiply_axis_factors(&second_primitive, &first_factor, &second_factor);

        let report = extract_bivariate_polynomial_system_axis_factors(&first, &second);

        assert_eq!(report.status, BivariatePolynomialAxisFactorStatus::Reduced);
        assert_eq!(report.first_parameter_factor, first_factor);
        assert_eq!(report.second_parameter_factor, second_factor);
        assert_eq!(
            report.reduced_equations,
            Some([first_primitive, second_primitive])
        );
    }

    #[test]
    fn bivariate_axis_factor_preserves_nonrational_coefficient_tower() {
        let first_factor = vec![(real(1) / real(2)).unwrap().sqrt().unwrap(), real(1)];
        let second_factor = vec![real(1)];
        let first_primitive = BivariatePolynomial::new(vec![vec![real(1), real(2)], vec![real(3)]]);
        let second_primitive =
            BivariatePolynomial::new(vec![vec![real(4)], vec![real(5), real(6)]]);
        let first = multiply_axis_factors(&first_primitive, &first_factor, &second_factor);
        let second = multiply_axis_factors(&second_primitive, &first_factor, &second_factor);

        let report = extract_bivariate_polynomial_system_axis_factors(&first, &second);

        assert_eq!(report.status, BivariatePolynomialAxisFactorStatus::Reduced);
        assert_eq!(report.first_parameter_factor, first_factor);
        assert_eq!(report.second_parameter_factor, second_factor);
        let reduced = report
            .reduced_equations
            .expect("the non-rational axis factor retains authored residuals");
        assert_bivariate_exactly_equal(
            &multiply_axis_factors(&reduced[0], &first_factor, &second_factor),
            &first,
        );
        assert_bivariate_exactly_equal(
            &multiply_axis_factors(&reduced[1], &first_factor, &second_factor),
            &second,
        );
    }

    #[test]
    fn bivariate_axis_factors_remove_independent_nonrational_equation_scales() {
        let first_factor = vec![real(-2), real(1)];
        let second_factor = vec![real(3), real(1)];
        let mut first = multiply_axis_factors(
            &BivariatePolynomial::new(vec![vec![real(1), real(2)], vec![real(3)]]),
            &first_factor,
            &second_factor,
        );
        let mut second = multiply_axis_factors(
            &BivariatePolynomial::new(vec![vec![real(4)], vec![real(5), real(6)]]),
            &first_factor,
            &second_factor,
        );
        scale_bivariate_in_place(&mut first, &real(2).sqrt().unwrap());
        scale_bivariate_in_place(&mut second, &real(3).sqrt().unwrap());

        let report = extract_bivariate_polynomial_system_axis_factors(&first, &second);

        assert_eq!(report.status, BivariatePolynomialAxisFactorStatus::Reduced);
        assert_eq!(report.first_parameter_factor, first_factor);
        assert_eq!(report.second_parameter_factor, second_factor);
        let reduced = report
            .reduced_equations
            .expect("projective scales retain both authored residual equations");
        assert_bivariate_exactly_equal(
            &multiply_axis_factors(&reduced[0], &first_factor, &second_factor),
            &first,
        );
        assert_bivariate_exactly_equal(
            &multiply_axis_factors(&reduced[1], &first_factor, &second_factor),
            &second,
        );
    }

    #[test]
    fn bivariate_axis_factors_leave_primitive_system_unallocated() {
        let first = BivariatePolynomial::new(vec![vec![real(1), real(2)], vec![real(3)]]);
        let second = BivariatePolynomial::new(vec![vec![real(4)], vec![real(5), real(6)]]);

        let report = extract_bivariate_polynomial_system_axis_factors(&first, &second);

        assert_eq!(
            report.status,
            BivariatePolynomialAxisFactorStatus::Primitive
        );
        assert_eq!(report.first_parameter_factor, vec![real(1)]);
        assert_eq!(report.second_parameter_factor, vec![real(1)]);
        assert!(report.reduced_equations.is_none());
    }

    #[test]
    fn bivariate_axis_factors_reduce_one_zero_equation_without_losing_evidence() {
        let zero = BivariatePolynomial::new(vec![vec![real(0)]]);
        let first_factor = vec![real(-2), real(1)];
        let second_factor = vec![real(3), real(1)];
        let nonzero = multiply_axis_factors(
            &BivariatePolynomial::new(vec![vec![real(5)]]),
            &first_factor,
            &second_factor,
        );

        let report = extract_bivariate_polynomial_system_axis_factors(&zero, &nonzero);

        assert_eq!(report.status, BivariatePolynomialAxisFactorStatus::Reduced);
        assert_eq!(report.first_parameter_factor, first_factor);
        assert_eq!(report.second_parameter_factor, second_factor);
        assert_eq!(
            report.reduced_equations,
            Some([
                BivariatePolynomial::new(vec![vec![real(0)]]),
                BivariatePolynomial::new(vec![vec![real(5)]])
            ])
        );
    }

    #[test]
    fn bivariate_axis_factors_report_zero_and_reduce_transcendental_content() {
        let zero = BivariatePolynomial::new(vec![vec![real(0)]]);
        let zero_report = extract_bivariate_polynomial_system_axis_factors(&zero, &zero);
        assert_eq!(
            zero_report.status,
            BivariatePolynomialAxisFactorStatus::ZeroSystem
        );
        assert!(zero_report.first_parameter_factor.is_empty());
        assert!(zero_report.second_parameter_factor.is_empty());
        assert!(zero_report.reduced_equations.is_none());

        let transcendental = BivariatePolynomial::new(vec![vec![Real::pi(), real(1)]]);
        let transcendental_report =
            extract_bivariate_polynomial_system_axis_factors(&transcendental, &zero);
        assert_eq!(
            transcendental_report.status,
            BivariatePolynomialAxisFactorStatus::Reduced
        );
        assert_eq!(transcendental_report.first_parameter_factor, vec![real(1)]);
        assert_eq!(
            transcendental_report.second_parameter_factor,
            vec![Real::pi(), real(1)]
        );
        assert_eq!(
            transcendental_report.reduced_equations,
            Some([
                BivariatePolynomial::new(vec![vec![real(1)]]),
                BivariatePolynomial::new(vec![vec![real(0)]])
            ])
        );
    }

    #[test]
    fn bivariate_component_retains_an_identically_zero_equation() {
        let zero = BivariatePolynomial::new(vec![vec![real(0)]]);
        let line = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let nonlinear = BivariatePolynomial::new(vec![
            vec![real(-1), real(0), real(1)],
            vec![],
            vec![],
            vec![real(-1)],
        ]);
        let with_content = multiply_bivariate(
            &nonlinear,
            &BivariatePolynomial::new(vec![vec![real(2)], vec![real(1)]]),
        );
        for equation in [line, nonlinear, with_content] {
            for zero_index in 0..2 {
                let equations = if zero_index == 0 {
                    [&zero, &equation]
                } else {
                    [&equation, &zero]
                };
                for axis in [
                    CurveResultantParameter::First,
                    CurveResultantParameter::Second,
                ] {
                    let report = parameter_component_bivariate_polynomial_system(
                        equations[0],
                        equations[1],
                        axis,
                        CurveIntersectionResultantConfig {
                            min_precision: -64,
                            max_resultant_degree: 64,
                        },
                    );
                    let component = match report.status {
                        BivariatePolynomialComponentStatus::Rational => {
                            reported_rational_component(&report)
                        }
                        BivariatePolynomialComponentStatus::Implicit => {
                            report.implicit_component.clone().unwrap()
                        }
                        status => panic!("gcd(F,0) must retain F's common component: {status:?}"),
                    };
                    let residual = report.reduced_equations.unwrap();
                    assert_eq!(residual[zero_index], zero);
                    for index in 0..2 {
                        assert_eq!(
                            multiply_bivariate(&component, &residual[index]),
                            *equations[index]
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn bivariate_rational_component_recovers_primitive_nonlinear_map() {
        // F(x,y)=(2+x)y-x(1+x), so y=x(1+x)/(2+x). Multiplying F by
        // independent linear cofactors makes the generic fiber degrees two
        // while preserving exactly one common root.
        let factor = BivariatePolynomial::new(vec![
            vec![real(0), real(2)],
            vec![real(-1), real(1)],
            vec![real(-1)],
        ]);
        let first = multiply_bivariate(
            &factor,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
        );
        let second = multiply_bivariate(
            &factor,
            &BivariatePolynomial::new(vec![vec![real(3), real(1)], vec![real(1)]]),
        );
        let report = parameter_component_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                max_resultant_degree: 16,
            },
        );

        assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
        assert_eq!(report.retained_parameter, CurveResultantParameter::First);
        assert_eq!(report.lifted_parameter, CurveResultantParameter::Second);
        assert_eq!(
            eval_univariate(&report.numerator_coefficients, &real(0)),
            real(0)
        );
        let numerator_at_one = eval_univariate(&report.numerator_coefficients, &real(1));
        let denominator_at_one = eval_univariate(&report.denominator_coefficients, &real(1));
        assert_eq!(numerator_at_one * real(3), denominator_at_one * real(2));
        let component = reported_rational_component(&report);
        let reduced = report
            .reduced_equations
            .as_ref()
            .expect("a constructed component retains both residual equations");
        assert_eq!(multiply_bivariate(&component, &reduced[0]), first);
        assert_eq!(multiply_bivariate(&component, &reduced[1]), second);
        assert_eq!(
            eval_univariate(
                &evaluate_bivariate_at_retained_parameter(
                    &reduced[0],
                    &real(-2),
                    CurveResultantParameter::First,
                ),
                &real(-1),
            ),
            real(0)
        );
        assert_eq!(
            eval_univariate(
                &evaluate_bivariate_at_retained_parameter(
                    &reduced[1],
                    &real(-2),
                    CurveResultantParameter::First,
                ),
                &real(-1),
            ),
            real(0)
        );
    }

    #[test]
    fn bivariate_rational_component_preserves_nonrational_map_coefficients() {
        let alpha = (real(1) / real(2)).unwrap().sqrt().unwrap();
        let component =
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![-alpha.clone()]]);
        let first = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
        );
        let second = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(2)], vec![real(1)]]),
        );

        let report = parameter_component_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                max_resultant_degree: 16,
            },
        );

        assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
        let image_at_one = (eval_univariate(&report.numerator_coefficients, &real(1))
            / eval_univariate(&report.denominator_coefficients, &real(1)))
        .unwrap();
        assert!(matches!(
            (image_at_one - alpha).certified_sign_until(-512),
            CertifiedRealSign::Known {
                sign: RealSign::Zero,
                ..
            }
        ));
        let extracted = reported_rational_component(&report);
        let reduced = report
            .reduced_equations
            .expect("the non-rational component retains both residual equations");
        assert_eq!(multiply_bivariate(&extracted, &reduced[0]), first);
        assert_eq!(multiply_bivariate(&extracted, &reduced[1]), second);
    }

    #[test]
    fn bivariate_component_removes_independent_nonrational_equation_scales() {
        let component = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let first = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
        );
        let second = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(2)], vec![real(1)]]),
        );
        let first_scale = real(2).sqrt().unwrap();
        let second_scale = real(3).sqrt().unwrap();
        let scaled = |polynomial: &BivariatePolynomial, scale: &Real| {
            BivariatePolynomial::new(
                polynomial
                    .coefficients
                    .iter()
                    .map(|row| row.iter().map(|coefficient| coefficient * scale).collect())
                    .collect(),
            )
        };
        let first = scaled(&first, &first_scale);
        let second = scaled(&second, &second_scale);

        let report = parameter_component_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                max_resultant_degree: 16,
            },
        );

        assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
        let extracted = reported_rational_component(&report);
        let reduced = report
            .reduced_equations
            .expect("projective equation scales retain both authored residuals");
        assert_eq!(multiply_bivariate(&extracted, &reduced[0]), first);
        assert_eq!(multiply_bivariate(&extracted, &reduced[1]), second);
    }

    #[test]
    fn bivariate_component_retains_an_irreducible_quadratic_fiber() {
        let factor = BivariatePolynomial::new(vec![
            vec![real(-1), real(0), real(1)],
            vec![real(0), real(-1)],
        ]);
        let first = multiply_bivariate(
            &factor,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
        );
        let second = multiply_bivariate(
            &factor,
            &BivariatePolynomial::new(vec![vec![real(2)], vec![real(1)]]),
        );
        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let report = parameter_component_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig {
                    min_precision: -64,
                    max_resultant_degree: 16,
                },
            );
            assert_eq!(report.status, BivariatePolynomialComponentStatus::Implicit);
            assert!(report.numerator_coefficients.is_empty());
            assert!(report.denominator_coefficients.is_empty());
            let component = report
                .implicit_component
                .expect("the irreducible quadratic remains an implicit component");
            let reduced = report
                .reduced_equations
                .expect("the implicit component retains both exact residuals");
            assert_eq!(
                leading_bivariate_term(&component.coefficients)
                    .expect("the implicit component is nonzero")
                    .2,
                real(1)
            );
            assert_eq!(multiply_bivariate(&component, &reduced[0]), first);
            assert_eq!(multiply_bivariate(&component, &reduced[1]), second);
        }
    }

    #[test]
    fn sampled_fiber_gcd_removes_high_degree_cofactor_scale_exactly() {
        // H(t,u)=(6-3u)(t^2+t)+2u^2-8u is irreducible in either
        // parameter. The unrelated cofactors reproduce the bidegrees of the
        // analytic-parallel fixture that motivated the sampled fast path:
        // (7,6) and (8,12). Scaling each monic specialized GCD by an authored
        // leading coefficient leaves polynomial content, which must be
        // removed before exact two-equation division authorizes H.
        let component = BivariatePolynomial::new(vec![
            vec![real(0), real(-8), real(2)],
            vec![real(6), real(-3)],
            vec![real(6), real(-3)],
        ]);
        let first_cofactor = BivariatePolynomial::new(vec![
            vec![real(1), real(0), real(0), real(0), real(1)],
            vec![],
            vec![],
            vec![],
            vec![],
            vec![real(1)],
        ]);
        let second_cofactor = BivariatePolynomial::new(vec![
            vec![
                real(2),
                real(0),
                real(0),
                real(0),
                real(0),
                real(0),
                real(0),
                real(0),
                real(0),
                real(0),
                real(1),
            ],
            vec![],
            vec![],
            vec![],
            vec![],
            vec![],
            vec![real(1)],
        ]);
        let first = multiply_bivariate(&component, &first_cofactor);
        let second = multiply_bivariate(&component, &second_cofactor);
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 256,
        };

        for (retained_parameter, expected_interpolation_degree) in [
            (CurveResultantParameter::First, 7),
            (CurveResultantParameter::Second, 6),
        ] {
            let report = parameter_component_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                config,
            );
            assert_eq!(report.status, BivariatePolynomialComponentStatus::Implicit);
            assert_eq!(report.degree_bound, expected_interpolation_degree);
            let extracted = report
                .implicit_component
                .expect("the sampled fiber GCD must publish its exact component");
            let residual = report
                .reduced_equations
                .expect("the sampled component must retain exact residuals");
            assert_eq!(multiply_bivariate(&extracted, &residual[0]), first);
            assert_eq!(multiply_bivariate(&extracted, &residual[1]), second);
        }
    }

    #[test]
    fn bivariate_rational_component_extracts_two_linear_quadratic_factors() {
        // C1(x,y)=y-x and C2(x,y)=y+x-1. Their product is the generic
        // quadratic fiber GCD, while the independent cofactors keep both
        // authored lifted degrees above two so the quadratic subresultant is
        // reconstructed rather than copied from an equation.
        let first_component =
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let second_component =
            BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]);
        let common = multiply_bivariate(&first_component, &second_component);
        let first = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)]]),
        );
        let second = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(2), real(1)], vec![real(-1)]]),
        );
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 32,
        };

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let first_report = parameter_component_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                config,
            );
            assert_eq!(
                first_report.status,
                BivariatePolynomialComponentStatus::Rational
            );
            let first_factor = reported_rational_component(&first_report);
            let first_reduced = first_report
                .reduced_equations
                .as_ref()
                .expect("the first quadratic factor retains its residual system");
            assert_eq!(multiply_bivariate(&first_factor, &first_reduced[0]), first);
            assert_eq!(multiply_bivariate(&first_factor, &first_reduced[1]), second);

            let second_report = parameter_component_bivariate_polynomial_system(
                &first_reduced[0],
                &first_reduced[1],
                retained_parameter,
                config,
            );
            assert_eq!(
                second_report.status,
                BivariatePolynomialComponentStatus::Rational
            );
            let retained = (real(1) / real(4)).unwrap();
            let image = |report: &BivariatePolynomialComponentReport| {
                (eval_univariate(&report.numerator_coefficients, &retained)
                    / eval_univariate(&report.denominator_coefficients, &retained))
                .unwrap()
            };
            let mut images = [image(&first_report), image(&second_report)];
            images.sort_by(|left, right| {
                left.partial_cmp(right)
                    .expect("rational component images are ordered")
            });
            assert_eq!(images, [retained.clone(), real(1) - retained]);
        }
    }

    #[test]
    fn bivariate_rational_component_extracts_repeated_quadratic_factor() {
        let component = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let repeated = multiply_bivariate(&component, &component);
        let first = multiply_bivariate(
            &repeated,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
        );
        let second = multiply_bivariate(
            &repeated,
            &BivariatePolynomial::new(vec![vec![real(2)], vec![real(1)]]),
        );
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 32,
        };

        let first_report = parameter_component_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            config,
        );
        assert_eq!(
            first_report.status,
            BivariatePolynomialComponentStatus::Rational
        );
        let first_reduced = first_report.reduced_equations.as_ref().unwrap();
        let second_report = parameter_component_bivariate_polynomial_system(
            &first_reduced[0],
            &first_reduced[1],
            CurveResultantParameter::First,
            config,
        );
        assert_eq!(
            second_report.status,
            BivariatePolynomialComponentStatus::Rational
        );
        assert_eq!(
            multiply_exact_polynomials(
                &first_report.numerator_coefficients,
                &second_report.denominator_coefficients,
            ),
            multiply_exact_polynomials(
                &second_report.numerator_coefficients,
                &first_report.denominator_coefficients,
            )
        );
    }

    #[test]
    fn bivariate_rational_component_extracts_repeated_cubic_factor() {
        let repeated_component =
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let distinct_component =
            BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]);
        let common = multiply_bivariate(
            &multiply_bivariate(&repeated_component, &repeated_component),
            &distinct_component,
        );
        let first = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)]]),
        );
        let second = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(2), real(1)], vec![real(-1)]]),
        );
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 32,
        };

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let mut residual = [first, second];
            let retained = (real(1) / real(4)).unwrap();
            let mut images = Vec::new();
            for _ in 0..3 {
                let report = parameter_component_bivariate_polynomial_system(
                    &residual[0],
                    &residual[1],
                    retained_parameter,
                    config,
                );
                assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
                images.push(
                    (eval_univariate(&report.numerator_coefficients, &retained)
                        / eval_univariate(&report.denominator_coefficients, &retained))
                    .unwrap(),
                );
                residual = report
                    .reduced_equations
                    .expect("each cubic factor retains the exact residual");
            }
            images.sort_by(|left, right| {
                left.partial_cmp(right)
                    .expect("rational component images are ordered")
            });
            assert_eq!(
                images,
                vec![retained.clone(), retained.clone(), real(1) - retained]
            );
        }
    }

    #[test]
    fn bivariate_rational_component_extracts_triple_cubic_factor() {
        let component = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let common = multiply_bivariate(&multiply_bivariate(&component, &component), &component);
        let first = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)]]),
        );
        let second = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(2), real(1)], vec![real(-1)]]),
        );
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 32,
        };

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let mut residual = [first, second];
            let retained = (real(1) / real(4)).unwrap();
            for _ in 0..3 {
                let report = parameter_component_bivariate_polynomial_system(
                    &residual[0],
                    &residual[1],
                    retained_parameter,
                    config,
                );
                assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
                assert_eq!(
                    (eval_univariate(&report.numerator_coefficients, &retained)
                        / eval_univariate(&report.denominator_coefficients, &retained))
                    .unwrap(),
                    retained
                );
                residual = report
                    .reduced_equations
                    .expect("each cubic factor retains the exact residual");
            }
        }
    }

    #[test]
    fn bivariate_component_retains_square_free_distinct_cubic_implicitly() {
        let first_component =
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let second_component =
            BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]);
        let third_component =
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-2)]]);
        let common = multiply_bivariate(
            &multiply_bivariate(&first_component, &second_component),
            &third_component,
        );
        let first = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)]]),
        );
        let second = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(2), real(1)], vec![real(-1)]]),
        );
        let report = parameter_component_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                max_resultant_degree: 32,
            },
        );

        assert_eq!(report.status, BivariatePolynomialComponentStatus::Implicit);
        let component = report
            .implicit_component
            .expect("the square-free cubic remains an implicit component");
        let reduced = report
            .reduced_equations
            .expect("the implicit component retains both exact residuals");
        assert_eq!(
            leading_bivariate_term(&component.coefficients)
                .expect("the implicit component is nonzero")
                .2,
            real(1)
        );
        assert_eq!(multiply_bivariate(&component, &reduced[0]), first);
        assert_eq!(multiply_bivariate(&component, &reduced[1]), second);
    }

    #[test]
    fn bivariate_component_retains_degree_four_common_fiber_implicitly() {
        let components = [
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]),
            BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]),
            BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-2)]]),
            BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(2)]]),
        ];
        let common = components.iter().fold(
            BivariatePolynomial::new(vec![vec![real(1)]]),
            |product, component| multiply_bivariate(&product, component),
        );
        let first = common.clone();
        let second = multiply_bivariate(
            &common,
            &BivariatePolynomial::new(vec![vec![real(2), real(1)], vec![real(1)]]),
        );
        let config = CurveIntersectionResultantConfig {
            min_precision: -64,
            max_resultant_degree: 64,
        };

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let report = parameter_component_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                config,
            );
            assert_eq!(report.status, BivariatePolynomialComponentStatus::Implicit);
            let component = report
                .implicit_component
                .expect("the degree-four common fiber remains implicit");
            let reduced = report
                .reduced_equations
                .expect("the implicit component retains both exact residuals");
            assert_eq!(multiply_bivariate(&component, &reduced[0]), first);
            assert_eq!(multiply_bivariate(&component, &reduced[1]), second);
        }
    }

    #[test]
    fn exact_bivariate_division_replays_non_monic_ragged_products() {
        let divisor = BivariatePolynomial::new(vec![
            vec![real(2), real(-3), real(1)],
            vec![real(0), real(4)],
        ]);
        let quotient =
            BivariatePolynomial::new(vec![vec![real(-1), real(2)], vec![], vec![real(3)]]);
        let dividend = multiply_bivariate(&divisor, &quotient);

        assert_eq!(
            divide_bivariate_polynomial_exact(&dividend, &divisor),
            Some(quotient.clone())
        );
        assert!(
            divide_bivariate_polynomial_exact(
                &dividend,
                &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)],])
            )
            .is_none()
        );

        let zero = BivariatePolynomial::new(vec![vec![real(0)]]);
        assert_eq!(
            divide_bivariate_polynomial_exact(&zero, &divisor),
            Some(zero.clone())
        );
        assert!(divide_bivariate_polynomial_exact(&dividend, &zero).is_none());

        let alpha = real(2).sqrt().unwrap();
        let nonrational_divisor =
            BivariatePolynomial::new(vec![vec![alpha.clone(), real(1)], vec![real(1)]]);
        let nonrational_dividend = multiply_bivariate(&nonrational_divisor, &quotient);
        assert_bivariate_exactly_equal(
            &divide_bivariate_polynomial_exact(&nonrational_dividend, &nonrational_divisor)
                .expect("the exact Real divisor must replay"),
            &quotient,
        );

        let deep_scale = crate::test_support::exact_normal_positive();
        let half = (Real::from(1) / Real::from(2)).unwrap();
        let deep_divisor =
            BivariatePolynomial::new(vec![vec![deep_scale.clone(), deep_scale.clone()]]);
        let deep_quotient = BivariatePolynomial::new(vec![vec![half.clone()]]);
        // Keep the product cold: multiply_bivariate canonicalizes its
        // coefficients and retains the shared scale's exact nonzero proof.
        let deep_dividend = BivariatePolynomial::new(vec![vec![&deep_scale * &half; 2]]);
        assert_bivariate_exactly_equal(
            &divide_bivariate_polynomial_exact(&deep_dividend, &deep_divisor)
                .expect("the strict nonzero divisor leading term should be reused"),
            &deep_quotient,
        );
        assert_eq!(
            &deep_dividend.coefficients[0][1] / &deep_divisor.coefficients[0][1],
            Ok(half),
            "ordinary division must reuse the leading coefficient's exact nonzero proof"
        );

        let normalized = normalize_bivariate_projective_scale(&deep_divisor)
            .expect("the strict projective scale should normalize");
        assert_bivariate_exactly_equal(
            &normalized.0,
            &BivariatePolynomial::new(vec![vec![Real::one(), Real::one()]]),
        );
        assert!(
            normalize_bivariate_projective_scale(&BivariatePolynomial::new(vec![vec![
                crate::test_support::terminal_zero(),
                crate::test_support::terminal_zero(),
            ]]))
            .is_none()
        );
    }

    #[test]
    fn exact_bivariate_monomial_division_retains_nonrational_coefficients() {
        let atom = Real::e().sin() + Real::from(2);
        let leading = atom.clone().sqrt().unwrap() + Real::pi();
        let numerator = atom.clone().sqrt().unwrap() + Real::e().cos();
        for scale in [leading, -atom, Real::from(2).sqrt().unwrap()] {
            let divisor = BivariatePolynomial::new(vec![vec![], vec![Real::zero(), scale.clone()]]);
            let dividend = BivariatePolynomial::new(vec![
                vec![],
                vec![],
                vec![],
                vec![Real::zero(), Real::zero(), numerator.clone()],
            ]);
            let quotient = divide_bivariate_polynomial_exact(&dividend, &divisor)
                .expect("a nonzero exact Real monomial coefficient can be inverted");
            let expected = BivariatePolynomial::new(vec![
                vec![],
                vec![],
                vec![Real::zero(), (&numerator / scale).unwrap()],
            ]);
            assert_bivariate_exactly_equal(&quotient, &expected);
        }
    }

    #[test]
    fn zero_dividend_still_requires_a_certified_nonzero_divisor() {
        let zero = BivariatePolynomial::new(vec![vec![Real::zero()]]);
        let unresolved = BivariatePolynomial::new(vec![vec![crate::test_support::terminal_zero()]]);
        assert!(divide_bivariate_polynomial_exact(&zero, &unresolved).is_none());
    }

    #[test]
    fn exact_univariate_gcd_and_division_replay_axis_content() {
        let left = vec![real(2), real(3), real(1)];
        let right = vec![real(1), real(1), real(1), real(1)];
        let factor = greatest_common_divisor_univariate_polynomials_exact(&left, &right)
            .expect("the exact common axis factor must be recovered");

        assert_eq!(factor, vec![real(1), real(1)]);
        assert_eq!(
            divide_univariate_polynomial_exact(&left, &factor),
            Some(vec![real(2), real(1)])
        );
        assert!(divide_univariate_polynomial_exact(&left, &right).is_none());

        let sqrt_two = real(2).sqrt().expect("positive square root");
        let exact_real_divisor = vec![Real::one(), sqrt_two.clone()];
        let exact_real_quotient = vec![
            real(3).sqrt().expect("positive square root"),
            sqrt_two + Real::one(),
            Real::one(),
        ];
        let exact_real_dividend =
            multiply_exact_polynomials(&exact_real_divisor, &exact_real_quotient);
        let recovered =
            divide_univariate_polynomial_exact(&exact_real_dividend, &exact_real_divisor)
                .expect("exact-real long division should reuse its leading proof");
        assert_eq!(recovered.len(), exact_real_quotient.len());
        for (actual, expected) in recovered.iter().zip(&exact_real_quotient) {
            assert_eq!(
                hyperlimit::compare_reals(actual, expected, hyperlimit::PredicatePolicy::STRICT,)
                    .value(),
                Some(std::cmp::Ordering::Equal)
            );
        }
    }

    #[test]
    fn bivariate_rational_component_handles_unequal_degrees_in_both_orientations() {
        // C(x,y)=(2+x)y-(x^2+3x+1). Independent degree-one and degree-two
        // cofactors leave C as the unique generic common fiber factor while
        // exercising rectangular first-subresultant minors.
        let component = BivariatePolynomial::new(vec![
            vec![real(-1), real(2)],
            vec![real(-3), real(1)],
            vec![real(-1)],
        ]);
        let first = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(1), real(1)], vec![real(1)]]),
        );
        let second = multiply_bivariate(
            &component,
            &BivariatePolynomial::new(vec![vec![real(1), real(1), real(1)]]),
        );

        for (first, second, retained_parameter) in [
            (
                first.clone(),
                second.clone(),
                CurveResultantParameter::First,
            ),
            (
                swap_bivariate(&first),
                swap_bivariate(&second),
                CurveResultantParameter::Second,
            ),
        ] {
            let report = parameter_component_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig {
                    min_precision: -64,
                    max_resultant_degree: 32,
                },
            );
            assert_eq!(report.status, BivariatePolynomialComponentStatus::Rational);
            let component = reported_rational_component(&report);
            let reduced = report
                .reduced_equations
                .as_ref()
                .expect("both orientations retain exact residual equations");
            assert_eq!(multiply_bivariate(&component, &reduced[0]), first);
            assert_eq!(multiply_bivariate(&component, &reduced[1]), second);
            for value in [real(0), real(1), real(2), real(3)] {
                let numerator = eval_univariate(&report.numerator_coefficients, &value);
                let denominator = eval_univariate(&report.denominator_coefficients, &value);
                let component_denominator = real(2) + &value;
                let component_numerator = &value * &value + real(3) * &value + real(1);
                assert_eq!(
                    numerator * component_denominator,
                    denominator * component_numerator
                );
            }
        }
    }

    #[test]
    fn bivariate_linear_lifts_recover_either_parameter_from_adjugate_ratios() {
        // `u-t=0` and `u+t-1=0` meet only at `t=u=1/2`.
        let first = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let second = BivariatePolynomial::new(vec![vec![real(-1), real(1)], vec![real(1)]]);
        let half = (real(1) / real(2)).unwrap();

        for retained_parameter in [
            CurveResultantParameter::First,
            CurveResultantParameter::Second,
        ] {
            let report = linear_parameter_lifts_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(
                report.status,
                CurveIntersectionParameterLiftStatus::Constructed
            );
            assert_eq!(report.retained_parameter, retained_parameter);
            assert_eq!(
                report.lifted_parameter,
                opposite_parameter(retained_parameter)
            );
            assert_eq!(report.degree_bound, 1);
            assert!(!report.maps.is_empty());
            assert!(report.maps.iter().any(|map| {
                let denominator = eval_univariate(&map.denominator_coefficients, &half);
                if denominator == real(0) {
                    return false;
                }
                let numerator = eval_univariate(&map.numerator_coefficients, &half);
                numerator == &half * denominator
            }));
        }
    }

    #[test]
    fn bivariate_linear_lifts_recover_a_nonlinear_common_root() {
        // `u^2-t=0` and `4u+4t-3=0` share `(t,u)=(1/4,1/2)`.
        let first = BivariatePolynomial::new(vec![vec![real(0), real(0), real(1)], vec![real(-1)]]);
        let second = BivariatePolynomial::new(vec![vec![real(-3), real(4)], vec![real(4)]]);
        let quarter = (real(1) / real(4)).unwrap();
        let half = (real(1) / real(2)).unwrap();

        for (retained_parameter, retained, lifted) in [
            (CurveResultantParameter::First, &quarter, &half),
            (CurveResultantParameter::Second, &half, &quarter),
        ] {
            let report = linear_parameter_lifts_bivariate_polynomial_system(
                &first,
                &second,
                retained_parameter,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(
                report.status,
                CurveIntersectionParameterLiftStatus::Constructed
            );
            assert!(report.maps.iter().any(|map| {
                let denominator = eval_univariate(&map.denominator_coefficients, retained);
                if denominator == real(0) {
                    return false;
                }
                let numerator = eval_univariate(&map.numerator_coefficients, retained);
                numerator == lifted * denominator
            }));
        }
    }

    #[test]
    fn bivariate_linear_lifts_report_nonlinear_fibers_explicitly() {
        // The first equation vanishes as a polynomial in `u` at `t=1/2`, so
        // the specialized common-root fiber is not certified by a nullity-one
        // Sylvester lift.
        let first = BivariatePolynomial::new(vec![vec![real(-1)], vec![real(2)]]);
        let second = BivariatePolynomial::new(vec![vec![real(-1), real(0), real(2)]]);
        let report = linear_parameter_lifts_bivariate_polynomial_system(
            &first,
            &second,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            CurveIntersectionParameterLiftStatus::UnsupportedEliminatedDegree
        );
        assert!(report.maps.is_empty());
    }

    #[test]
    fn bivariate_system_reports_an_identically_degenerate_equation() {
        let zero = BivariatePolynomial::new(vec![vec![real(0)]]);
        let nonzero = BivariatePolynomial::new(vec![vec![real(0), real(1)], vec![real(-1)]]);
        let report = resultant_bivariate_polynomial_system(
            &zero,
            &nonzero,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        assert_eq!(report.resultant_coefficients, vec![real(0)]);
    }

    #[test]
    fn curve_resultant_rejects_empty_inputs_and_degree_over_budget() {
        let invalid = PolynomialParametricCurve2::new(Vec::new(), vec![real(0)]);
        let line = line_x_axis();
        let invalid_report = resultant_parametric_curve_intersection(
            &invalid,
            &line,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );
        assert_eq!(
            invalid_report.status,
            CurveIntersectionResultantStatus::EmptyCoordinatePolynomial
        );

        let quadratic = PolynomialParametricCurve2::new(
            vec![real(0), real(0), real(1)],
            vec![real(0), real(1)],
        );
        let limited = resultant_parametric_curve_intersection(
            &quadratic,
            &quadratic,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig {
                max_resultant_degree: 0,
                ..CurveIntersectionResultantConfig::default()
            },
        );
        assert_eq!(
            limited.status,
            CurveIntersectionResultantStatus::DegreeBoundExceeded
        );
    }

    #[test]
    fn rational_curve_resultant_cross_multiplies_weighted_parabola() {
        let weighted_parabola = RationalParametricCurve2::new(
            vec![real(0), real(1)],
            vec![real(0), real(0), real(1)],
            vec![real(1), real(1)],
        );
        let horizontal = RationalParametricCurve2::from_polynomial(
            &PolynomialParametricCurve2::new(vec![real(0), real(1)], vec![real(1)]),
        );

        let report = resultant_rational_parametric_curve_intersection(
            &weighted_parabola,
            &horizontal,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        assert_eq!(
            report.resultant_coefficients,
            vec![real(-1), real(-1), real(1)]
        );
    }

    #[test]
    fn rational_curve_resultant_rejects_certified_zero_weight() {
        let invalid =
            RationalParametricCurve2::new(vec![real(0), real(1)], vec![real(1)], vec![real(0)]);
        let line = RationalParametricCurve2::from_polynomial(&line_x_axis());

        let report = resultant_rational_parametric_curve_intersection(
            &invalid,
            &line,
            CurveResultantParameter::First,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            CurveIntersectionResultantStatus::InvalidHomogeneousWeight
        );
    }

    #[test]
    fn nonrational_resultant_preserves_specialized_degree_drop_identity() {
        // F(t,u) = (t-1)u^2 + u, G(u) = u-sqrt(2). The generic
        // quadratic/linear resultant is 2(t-1)+sqrt(2). At t=1 the
        // lower-degree resultant has the opposite sign, so interpolating
        // that specialization would produce the wrong polynomial.
        let alpha = real(2).sqrt().unwrap();
        let first = BivariatePolynomial::new(vec![
            vec![real(0), real(1), real(-1)],
            vec![real(0), real(0), real(1)],
        ]);
        let second = BivariatePolynomial::new(vec![vec![-alpha.clone(), real(1)]]);
        for retained in [
            CurveResultantParameter::First,
            CurveResultantParameter::Second,
        ] {
            let (first, second, orientation) = match retained {
                CurveResultantParameter::First => (first.clone(), second.clone(), real(1)),
                CurveResultantParameter::Second => {
                    (swap_bivariate(&first), swap_bivariate(&second), real(-1))
                }
            };
            let report = resultant_bivariate_polynomial_system(
                &first,
                &second,
                retained,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            assert_eq!(report.resultant_coefficients.len(), 2);
            // Compare exact values, including the degree-drop point and
            // points not used by reconstruction. This tests the public
            // polynomial contract without exposing interpolation history.
            for parameter in [-3, 0, 1, 2, 5].map(real) {
                let expected = &orientation * (real(2) * (&parameter - real(1)) + &alpha);
                let actual = eval_univariate(&report.resultant_coefficients, &parameter);
                assert!(matches!(
                    (actual - expected).certified_sign_until(-512),
                    CertifiedRealSign::Known {
                        sign: RealSign::Zero,
                        ..
                    }
                ));
            }
        }
    }

    #[test]
    fn rational_interpolation_preserves_signed_scale_at_degree_drops_on_either_axis() {
        // F=c(t u^7-(t+2)), G=d((t-1)u^6-(t+3)). Coprime exponents
        // give Res(F,G)=c^6 d^7 ((t-1)^7(t+2)^6-t^6(t+3)^7).
        // Dimension 13 uses interpolation; t=0 and t=1 must be skipped as
        // samples without losing their values in the completed polynomial.
        let c = Real::from(Rational::fraction(2, 3).unwrap());
        let d = Real::from(Rational::fraction(-5, 7).unwrap());
        let mut first = vec![vec![real(0); 8]; 2];
        first[0][0] = -real(2) * &c;
        first[1][0] = -c.clone();
        first[1][7] = c.clone();
        let first = BivariatePolynomial::new(first);
        let mut second = vec![vec![real(0); 7]; 2];
        second[0][0] = -real(3) * &d;
        second[1][0] = -d.clone();
        second[0][6] = -d.clone();
        second[1][6] = d.clone();
        let second = BivariatePolynomial::new(second);
        let pow = |value: &Real, exponent: usize| {
            (0..exponent).fold(Real::one(), |result, _| result * value)
        };
        let scale = pow(&c, 6) * pow(&d, 7);
        for retained in [
            CurveResultantParameter::First,
            CurveResultantParameter::Second,
        ] {
            let (first, second, orientation) = match retained {
                CurveResultantParameter::First => (first.clone(), second.clone(), real(1)),
                CurveResultantParameter::Second => {
                    (swap_bivariate(&first), swap_bivariate(&second), real(-1))
                }
            };
            let report = resultant_bivariate_polynomial_system(
                &first,
                &second,
                retained,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            assert_eq!(report.degree_bound, 13);
            assert!(report.resultant_coefficients.len() <= 14);
            // Nineteen independent values determine the entire polynomial
            // of degree at most 13, including both exceptional fibers.
            for parameter in (-3..=15).map(real) {
                let expected = &orientation
                    * &scale
                    * (pow(&(&parameter - real(1)), 7) * pow(&(&parameter + real(2)), 6)
                        - pow(&parameter, 6) * pow(&(&parameter + real(3)), 7));
                assert!(eval_univariate(&report.resultant_coefficients, &parameter) == expected);
            }
        }
    }

    #[test]
    fn rational_resultant_preserves_specialized_degree_drop_identity() {
        let first = RationalParametricCurve2::new(
            vec![real(5), real(51), real(-15), real(-18)],
            vec![real(6), real(12), real(-12)],
            vec![real(1), real(3), real(-3)],
        );
        let second = RationalParametricCurve2::new(
            vec![real(28), real(160), real(-252), real(69)],
            vec![real(4), real(84), real(-84)],
            vec![real(1), real(9), real(-9)],
        );
        let report = resultant_rational_parametric_curve_intersection(
            &first,
            &second,
            CurveResultantParameter::Second,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
        let expected = [
            -1, -491, -9495, 66678, 1737203, 1859523, -33269637, 76011300, -71374833, 24098715,
            5240457, -5130702, 771282,
        ]
        .map(real);
        assert_eq!(report.resultant_coefficients.len(), expected.len());
        for (coefficient, expected_coefficient) in
            report.resultant_coefficients.iter().zip(&expected)
        {
            assert_eq!(
                coefficient * &expected[0],
                expected_coefficient * &report.resultant_coefficients[0]
            );
        }
    }

    #[test]
    fn trivariate_constraint_resultant_eliminates_every_tensor_axis() {
        // F(a,b,t) = a + b + t and P(x) = x^2 - 2. For any eliminated
        // axis, Res(P,F) is (u+v)^2 - 2 on the two retained axes.
        let polynomial = TrivariatePolynomial::new(vec![
            vec![vec![real(0), real(1)], vec![real(1)]],
            vec![vec![real(1)]],
        ]);
        let expected = BivariatePolynomial::new(vec![
            vec![real(-2), real(0), real(1)],
            vec![real(0), real(2)],
            vec![real(1)],
        ]);
        for axis in [
            TrivariatePolynomialAxis::First,
            TrivariatePolynomialAxis::Second,
            TrivariatePolynomialAxis::Third,
        ] {
            let report = resultant_trivariate_polynomial_univariate_constraint(
                &polynomial,
                &[real(-2), real(0), real(1)],
                axis,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(
                report.status,
                TrivariateConstraintResultantStatus::Constructed
            );
            assert_eq!(report.degree_bounds, [2, 2]);
            assert_eq!(report.resultant, Some(expected.clone()));
        }
    }

    #[test]
    fn curve_resultant_degree_helpers_complete_strict_exact_boundaries() {
        let positive = crate::test_support::exact_normal_positive();
        let normalized_zero = real(2).powi_i64(-3000).unwrap() - positive.clone();

        assert_eq!(
            certified_nonzero_degree(&[real(1), positive.clone(), normalized_zero.clone()], -64,),
            Ok(Some(1))
        );
        assert_eq!(
            trim_trailing_zeroes(
                vec![real(1), positive.clone(), normalized_zero.clone()],
                -64,
            )
            .unwrap()
            .len(),
            2
        );
        assert_eq!(
            is_certified_zero_polynomial(std::slice::from_ref(&normalized_zero), -64),
            Ok(true)
        );

        let bivariate = BivariatePolynomial::new(vec![
            vec![normalized_zero.clone(), normalized_zero.clone()],
            vec![positive.clone()],
        ]);
        let bivariate_degree = certified_bivariate_degree(&bivariate, -64)
            .unwrap()
            .expect("the strict nonzero coefficient sets both axis degrees");
        assert_eq!(bivariate_degree.first, 1);
        assert_eq!(bivariate_degree.second, 0);
        let trivariate = TrivariatePolynomial::new(vec![
            vec![vec![normalized_zero.clone()]],
            vec![vec![positive.clone()]],
        ]);
        assert_eq!(
            certified_trivariate_degree(&trivariate, -64),
            Ok(Some([1, 0, 0]))
        );
        let quadrivariate = QuadrivariatePolynomial::new(vec![
            vec![vec![vec![normalized_zero]]],
            vec![vec![vec![positive]]],
        ]);
        assert_eq!(
            certified_quadrivariate_degree(&quadrivariate, -64),
            Ok(Some([1, 0, 0, 0]))
        );

        let terminal = crate::test_support::terminal_zero();
        assert_eq!(
            certified_nonzero_degree(std::slice::from_ref(&terminal), -64),
            Err(())
        );
        assert!(matches!(
            certified_bivariate_degree(
                &BivariatePolynomial::new(vec![vec![terminal.clone()]]),
                -64,
            ),
            Err(())
        ));
        assert_eq!(
            certified_trivariate_degree(
                &TrivariatePolynomial::new(vec![vec![vec![terminal.clone()]]]),
                -64,
            ),
            Err(())
        );
        assert_eq!(
            certified_quadrivariate_degree(
                &QuadrivariatePolynomial::new(vec![vec![vec![vec![terminal.clone()]]]]),
                -64,
            ),
            Err(())
        );
        assert_eq!(is_certified_zero_polynomial(&[terminal], -64), Err(()));
    }

    #[test]
    fn constrained_trivariate_resultant_uses_strict_constraint_normalization() {
        let positive = crate::test_support::exact_normal_positive();
        let normalized_zero = real(2).powi_i64(-3000).unwrap() - positive.clone();
        let polynomial = TrivariatePolynomial::new(vec![vec![vec![real(1), positive.clone()]]]);
        let report = resultant_trivariate_polynomial_univariate_constraint(
            &polynomial,
            &[
                real(-2) * &positive,
                Real::zero(),
                positive,
                normalized_zero,
            ],
            TrivariatePolynomialAxis::Third,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                ..CurveIntersectionResultantConfig::default()
            },
        );
        assert_eq!(
            report.status,
            TrivariateConstraintResultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [0, 0]);
        assert!(report.resultant.is_some());

        let terminal = resultant_trivariate_polynomial_univariate_constraint(
            &TrivariatePolynomial::new(vec![vec![vec![real(1), real(1)]]]),
            &[
                real(-2),
                Real::zero(),
                Real::one(),
                crate::test_support::terminal_zero(),
            ],
            TrivariatePolynomialAxis::Third,
            CurveIntersectionResultantConfig {
                min_precision: -64,
                ..CurveIntersectionResultantConfig::default()
            },
        );
        assert_eq!(
            terminal.status,
            TrivariateConstraintResultantStatus::UndecidedCoefficient
        );
    }

    #[test]
    fn trivariate_constraint_resultant_obeys_each_retained_degree_budget() {
        let polynomial = TrivariatePolynomial::new(vec![
            vec![vec![real(0), real(1)], vec![real(1)]],
            vec![vec![real(1)]],
        ]);
        let report = resultant_trivariate_polynomial_univariate_constraint(
            &polynomial,
            &[real(-2), real(0), real(1)],
            TrivariatePolynomialAxis::First,
            CurveIntersectionResultantConfig {
                max_resultant_degree: 1,
                ..CurveIntersectionResultantConfig::default()
            },
        );
        assert_eq!(
            report.status,
            TrivariateConstraintResultantStatus::DegreeBoundExceeded
        );
        assert_eq!(report.degree_bounds, [2, 2]);
        assert!(report.resultant.is_none());
    }

    #[test]
    fn constrained_trivariate_subresultant_recovers_a_specialized_tangent_gcd() {
        // F(a,b,t)=(t-a)^2 and H(t)=t^2-2. At the selected value a=sqrt(2),
        // their first nonzero subresultant is a nonzero multiple of t-a even
        // though the ordinary resultant has an even zero in a.
        let polynomial = TrivariatePolynomial::new(vec![
            vec![vec![real(0), real(0), real(1)]],
            vec![vec![real(0), real(-2)]],
            vec![vec![real(1)]],
        ]);
        let constraint = [real(-2), real(0), real(1)];
        let report = subresultant_trivariate_polynomial_univariate_constraint(
            &polynomial,
            &constraint,
            TrivariatePolynomialAxis::Third,
            1,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            TrivariateConstraintSubresultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [2, 0]);
        assert_eq!(report.coefficients.len(), 2);
        let alpha = real(2).sqrt().unwrap();
        let coefficients = report
            .coefficients
            .iter()
            .map(|coefficient| {
                evaluate_bivariate_at_retained_parameter(
                    coefficient,
                    &alpha,
                    CurveResultantParameter::First,
                )[0]
                .clone()
            })
            .collect::<Vec<_>>();
        assert_ne!(coefficients[1], Real::zero());
        assert_eq!(&coefficients[0] + &alpha * &coefficients[1], Real::zero());

        let terminal = subresultant_trivariate_polynomial_univariate_constraint(
            &polynomial,
            &constraint,
            TrivariatePolynomialAxis::Third,
            2,
            CurveIntersectionResultantConfig::default(),
        );
        assert_eq!(
            terminal.status,
            TrivariateConstraintSubresultantStatus::Constructed
        );
        assert_eq!(
            terminal.coefficients,
            constraint
                .into_iter()
                .map(|coefficient| BivariatePolynomial::new(vec![vec![coefficient]]))
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn trivariate_system_subresultant_recovers_tangent_selected_pair_gcd() {
        // H(a,u,v)=v^2-a and G(a,u,v)=(v-u)^2. Their resultant in v is
        // (u^2-a)^2, but at a=u=1 the first positive subresultant recovers
        // the simple common factor v-1 despite G's even contact.
        let image = TrivariatePolynomial::new(vec![
            vec![vec![real(0), real(0), real(1)]],
            vec![vec![real(-1)]],
        ]);
        let incidence = TrivariatePolynomial::new(vec![vec![
            vec![real(0), real(0), real(1)],
            vec![real(0), real(-2)],
            vec![real(1)],
        ]]);
        let config = CurveIntersectionResultantConfig::default();
        let evaluate_at_one = |coefficient: &BivariatePolynomial| {
            let fiber = evaluate_bivariate_at_retained_parameter(
                coefficient,
                &real(1),
                CurveResultantParameter::First,
            );
            eval_univariate(&fiber, &real(1))
        };

        let resultant = subresultant_trivariate_polynomial_system(
            &image,
            &incidence,
            TrivariatePolynomialAxis::Third,
            0,
            config,
        );
        assert_eq!(
            resultant.status,
            TrivariatePolynomialSystemSubresultantStatus::Constructed
        );
        assert_eq!(resultant.degree_bounds, [2, 4]);
        assert_eq!(resultant.coefficients.len(), 1);
        assert_eq!(evaluate_at_one(&resultant.coefficients[0]), Real::zero());

        let gcd = subresultant_trivariate_polynomial_system(
            &image,
            &incidence,
            TrivariatePolynomialAxis::Third,
            1,
            config,
        );
        assert_eq!(
            gcd.status,
            TrivariatePolynomialSystemSubresultantStatus::Constructed
        );
        assert_eq!(gcd.degree_bounds, [1, 2]);
        assert_eq!(gcd.coefficients.len(), 2);
        let constant = evaluate_at_one(&gcd.coefficients[0]);
        let linear = evaluate_at_one(&gcd.coefficients[1]);
        assert_ne!(linear, Real::zero());
        assert_eq!(constant + linear, Real::zero());
    }

    #[test]
    fn trivariate_system_resultant_preserves_nominal_degree_at_grid_drop() {
        // F(a,u,v)=1+a*v drops from degree one to zero at the first sampling
        // plane a=0. G(a,u,v)=v-u remains linear, and the nominal Sylvester
        // determinant must still reconstruct 1+a*u up to a global sign.
        let first =
            TrivariatePolynomial::new(vec![vec![vec![real(1)]], vec![vec![real(0), real(1)]]]);
        let second = TrivariatePolynomial::new(vec![vec![vec![real(0), real(1)], vec![real(-1)]]]);
        let report = subresultant_trivariate_polynomial_system(
            &first,
            &second,
            TrivariatePolynomialAxis::Third,
            0,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            TrivariatePolynomialSystemSubresultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [1, 1]);
        let [resultant] = report.coefficients.as_slice() else {
            panic!("an order-zero subresultant must have one coefficient")
        };
        let expected =
            BivariatePolynomial::new(vec![vec![real(1), real(0)], vec![real(0), real(1)]]);
        let scale = resultant.coefficients[0][0].clone();
        assert_ne!(scale, Real::zero());
        for first_power in 0..2 {
            for second_power in 0..2 {
                let actual = resultant
                    .coefficients
                    .get(first_power)
                    .and_then(|row| row.get(second_power))
                    .cloned()
                    .unwrap_or_else(Real::zero);
                assert_eq!(
                    actual,
                    &scale * &expected.coefficients[first_power][second_power]
                );
            }
        }
    }

    #[test]
    fn trivariate_system_resultant_handles_constant_eliminated_operand() {
        // F(a,u,v)=1+a is constant in v while G(a,u,v)=v-u is linear.
        // Their v-resultant is the retained coefficient 1+a.
        let first = TrivariatePolynomial::new(vec![vec![vec![real(1)]], vec![vec![real(1)]]]);
        let second = TrivariatePolynomial::new(vec![vec![vec![real(0), real(1)], vec![real(-1)]]]);
        let report = subresultant_trivariate_polynomial_system(
            &first,
            &second,
            TrivariatePolynomialAxis::Third,
            0,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            TrivariatePolynomialSystemSubresultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [1, 0]);
        assert_eq!(
            report.coefficients,
            vec![BivariatePolynomial::new(vec![vec![real(1)], vec![real(1)]])]
        );
    }

    #[test]
    fn trivariate_system_resultant_ignores_trailing_zero_storage() {
        // F(v)=1+v is deliberately stored with a zero v^2 coefficient. Its
        // certified degree, rather than ragged tensor capacity, must define
        // the Sylvester matrix against G(u,v)=v-u.
        let first = TrivariatePolynomial::new(vec![vec![vec![real(1), real(1), real(0)]]]);
        let second = TrivariatePolynomial::new(vec![vec![vec![real(0), real(1)], vec![real(-1)]]]);
        let report = subresultant_trivariate_polynomial_system(
            &first,
            &second,
            TrivariatePolynomialAxis::Third,
            0,
            CurveIntersectionResultantConfig::default(),
        );

        assert_eq!(
            report.status,
            TrivariatePolynomialSystemSubresultantStatus::Constructed
        );
        let [resultant] = report.coefficients.as_slice() else {
            panic!("an order-zero subresultant must have one coefficient")
        };
        let fiber = evaluate_bivariate_at_retained_parameter(
            resultant,
            &real(0),
            CurveResultantParameter::First,
        );
        let at_zero = eval_univariate(&fiber, &real(0));
        let at_one = eval_univariate(&fiber, &real(1));
        assert_ne!(at_zero, Real::zero());
        assert_eq!(at_one, &real(2) * at_zero);
    }

    #[test]
    fn trivariate_system_resultant_eliminates_every_tensor_axis() {
        let axes = [
            TrivariatePolynomialAxis::First,
            TrivariatePolynomialAxis::Second,
            TrivariatePolynomialAxis::Third,
        ];
        for eliminated_axis in axes {
            let eliminated = eliminated_axis.index();
            let retained = match eliminated_axis {
                TrivariatePolynomialAxis::First => [1, 2],
                TrivariatePolynomialAxis::Second => [0, 2],
                TrivariatePolynomialAxis::Third => [0, 1],
            };
            let mut first = vec![vec![vec![Real::zero(); 2]; 2]; 2];
            let mut second = first.clone();
            let mut exponents = [0; 3];
            exponents[eliminated] = 1;
            first[exponents[0]][exponents[1]][exponents[2]] = Real::one();
            second[exponents[0]][exponents[1]][exponents[2]] = Real::one();
            exponents = [0; 3];
            exponents[retained[0]] = 1;
            first[exponents[0]][exponents[1]][exponents[2]] = real(-1);
            exponents = [0; 3];
            exponents[retained[1]] = 1;
            second[exponents[0]][exponents[1]][exponents[2]] = real(-1);

            let report = subresultant_trivariate_polynomial_system(
                &TrivariatePolynomial::new(first),
                &TrivariatePolynomial::new(second),
                eliminated_axis,
                0,
                CurveIntersectionResultantConfig::default(),
            );
            assert_eq!(
                report.status,
                TrivariatePolynomialSystemSubresultantStatus::Constructed
            );
            assert_eq!(
                report.retained_axes,
                retained.map(trivariate_axis_from_index)
            );
            let [resultant] = report.coefficients.as_slice() else {
                panic!("an order-zero subresultant must have one coefficient")
            };
            let evaluate = |first: i64, second: i64| {
                let fiber = evaluate_bivariate_at_retained_parameter(
                    resultant,
                    &real(first),
                    CurveResultantParameter::First,
                );
                eval_univariate(&fiber, &real(second))
            };
            let forward = evaluate(2, 3);
            let reverse = evaluate(3, 2);
            assert_ne!(forward, Real::zero());
            assert_eq!(&forward + &reverse, Real::zero());
            assert_eq!(evaluate(2, 2), Real::zero());
        }
    }

    #[test]
    fn constrained_quadrivariate_fourth_axis_recovers_a_specialized_tangent_gcd() {
        // F(a,b,c,t)=(t-a)^2 and H(t)=t^2-2.  The retained b/c axes are
        // deliberately present but inactive: the fourth-axis API must return
        // the same exact tangent GCD while preserving trivariate coefficients.
        let mut coefficients = vec![vec![vec![vec![real(0); 3]; 1]; 1]; 3];
        coefficients[0][0][0][2] = real(1);
        coefficients[1][0][0][1] = real(-2);
        coefficients[2][0][0][0] = real(1);
        let polynomial = QuadrivariatePolynomial::new(coefficients);
        let constraint = [real(-2), real(0), real(1)];
        let resultant = resultant_quadrivariate_polynomial_fourth_axis_constraint(
            &polynomial,
            &constraint,
            CurveIntersectionResultantConfig::default(),
        );
        assert_eq!(
            resultant.status,
            TrivariateConstraintResultantStatus::Constructed
        );
        assert_eq!(resultant.degree_bounds, [4, 0, 0]);

        let report = subresultant_quadrivariate_polynomial_fourth_axis_constraint(
            &polynomial,
            &constraint,
            1,
            CurveIntersectionResultantConfig::default(),
        );
        assert_eq!(
            report.status,
            TrivariateConstraintSubresultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [2, 0, 0]);
        assert_eq!(report.coefficients.len(), 2);
        let alpha = real(2).sqrt().unwrap();
        let power = |value: &Real, exponent: usize| {
            (0..exponent).fold(Real::one(), |product, _| product * value)
        };
        let evaluate = |polynomial: &TrivariatePolynomial| {
            polynomial.coefficients.iter().enumerate().fold(
                Real::zero(),
                |sum, (exponent, planes)| {
                    sum + planes
                        .first()
                        .and_then(|row| row.first())
                        .cloned()
                        .unwrap_or_else(Real::zero)
                        * power(&alpha, exponent)
                },
            )
        };
        let gcd = report.coefficients.iter().map(evaluate).collect::<Vec<_>>();
        assert_ne!(gcd[1], Real::zero());
        assert_eq!(&gcd[0] + &alpha * &gcd[1], Real::zero());
    }

    #[test]
    fn quadrivariate_fourth_axis_resultant_retains_all_three_source_axes() {
        // F=t-(a+b+c), H=t^2-2, so Res_t(H,F)=(a+b+c)^2-2.
        let mut coefficients = vec![vec![vec![vec![real(0); 2]; 2]; 2]; 2];
        coefficients[0][0][0][1] = real(1);
        coefficients[1][0][0][0] = real(-1);
        coefficients[0][1][0][0] = real(-1);
        coefficients[0][0][1][0] = real(-1);
        let report = resultant_quadrivariate_polynomial_fourth_axis_constraint(
            &QuadrivariatePolynomial::new(coefficients),
            &[real(-2), real(0), real(1)],
            CurveIntersectionResultantConfig::default(),
        );
        assert_eq!(
            report.status,
            TrivariateConstraintResultantStatus::Constructed
        );
        assert_eq!(report.degree_bounds, [2, 2, 2]);
        let resultant = report.resultant.unwrap();
        let values = [real(1), real(2), real(3)];
        let power = |value: &Real, exponent: usize| {
            (0..exponent).fold(Real::one(), |product, _| product * value)
        };
        let mut evaluated = Real::zero();
        for (first, planes) in resultant.coefficients.iter().enumerate() {
            for (second, row) in planes.iter().enumerate() {
                for (third, coefficient) in row.iter().enumerate() {
                    evaluated += coefficient
                        * power(&values[0], first)
                        * power(&values[1], second)
                        * power(&values[2], third);
                }
            }
        }
        assert_eq!(evaluated, real(34));
    }

    #[test]
    fn polynomial_determinant_preserves_singular_and_swapped_pivots() {
        assert_eq!(determinant_polynomial_matrix(&[], 0), Some(vec![real(1)]));
        assert_eq!(determinant_polynomial_matrix(&[], 1), None);
        let matrix = vec![
            vec![real(0)],
            vec![real(1), real(1)],
            vec![real(2)],
            vec![real(0), real(1)],
            vec![real(3)],
            vec![real(0)],
            vec![real(2)],
            vec![real(0)],
            vec![real(0), real(1)],
        ];
        assert_eq!(
            determinant_polynomial_matrix(&matrix, 3),
            Some(vec![real(-12), real(0), real(-1), real(-1)])
        );
        let mut singular = matrix;
        for column in 0..3 {
            singular[6 + column] = singular[column].clone();
        }
        assert_eq!(
            determinant_polynomial_matrix(&singular, 3),
            Some(vec![real(0)])
        );
    }

    #[test]
    fn polynomial_determinant_restores_wide_rational_row_scales() {
        let matrix = vec![
            vec![],
            vec![real(1), real(1)],
            vec![real(2)],
            vec![real(0), real(1)],
            vec![real(3)],
            vec![],
            vec![real(2)],
            vec![],
            vec![real(0), real(1)],
        ];
        let wide = real(2).powi_i64(1024).unwrap() + real(17);
        let scales = [
            (&wide / real(3)).unwrap(),
            (real(-7) / real(31)).unwrap(),
            (real(11) / (real(5) * &wide)).unwrap(),
        ];
        let determinant_scale = scales
            .iter()
            .fold(Real::one(), |value, scale| value * scale);
        let scaled = matrix
            .iter()
            .enumerate()
            .map(|(index, entry)| {
                entry
                    .iter()
                    .map(|value| value * &scales[index / 3])
                    .collect()
            })
            .collect::<Vec<_>>();
        let expected = [-12, 0, -1, -1]
            .into_iter()
            .map(|value| real(value) * &determinant_scale)
            .collect::<Vec<_>>();
        assert_eq!(determinant_polynomial_matrix(&scaled, 3), Some(expected));
        assert!(determinant_polynomial_matrix(&[vec![Real::pi()]], 1).is_none());
    }

    #[test]
    fn axis_saturation_preserves_rootful_fibers_and_closed_boundaries() {
        let expected = [
            BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
            BivariatePolynomial::new(vec![vec![real(2), real(1)]]),
        ];
        let alpha = (real(1) / real(2)).unwrap().sqrt().unwrap();
        for (constant, slope, rootless) in [
            (real(2), real(1), true),
            (alpha.clone(), real(1), true),
            (-alpha, real(1), false),
            (real(-1), real(2), false),
            (real(0), real(1), false),
            (real(-1), real(1), false),
        ] {
            for parameter in [
                CurveResultantParameter::First,
                CurveResultantParameter::Second,
            ] {
                let factor = match parameter {
                    CurveResultantParameter::First => {
                        BivariatePolynomial::new(vec![vec![constant.clone()], vec![slope.clone()]])
                    }
                    CurveResultantParameter::Second => {
                        BivariatePolynomial::new(vec![vec![constant.clone(), slope.clone()]])
                    }
                };
                let equations = [
                    multiply_bivariate(&factor, &expected[0]),
                    multiply_bivariate(&factor, &expected[1]),
                ];
                let result =
                    saturate_rootless_bivariate_axis_factors(&equations, [[&real(0), &real(1)]; 2]);
                if rootless {
                    let Classification::Decided(Some(result)) = result else {
                        panic!("rootless factors may be removed exactly");
                    };
                    for (actual, expected) in result.iter().zip(&expected) {
                        assert_bivariate_exactly_equal(actual, expected);
                    }
                } else {
                    assert!(
                        matches!(result, Classification::Decided(None)),
                        "a factor root belongs to the closed solution set"
                    );
                }
            }
        }
        assert_eq!(
            saturate_rootless_bivariate_axis_factors(&expected, [[&real(0), &real(1)]; 2]),
            Classification::Decided(None)
        );
    }

    #[test]
    fn axis_saturation_uses_the_requested_exact_rectangle() {
        let common = BivariatePolynomial::new(vec![vec![real(-2)], vec![real(1)]]);
        let equations = [
            multiply_bivariate(
                &common,
                &BivariatePolynomial::new(vec![vec![real(1), real(1)]]),
            ),
            multiply_bivariate(
                &common,
                &BivariatePolynomial::new(vec![vec![real(2), real(1)]]),
            ),
        ];
        assert!(matches!(
            saturate_rootless_bivariate_axis_factors(&equations, [[&real(0), &real(1)]; 2]),
            Classification::Decided(Some(_))
        ));
        assert!(matches!(
            saturate_rootless_bivariate_axis_factors(&equations, [[&real(1), &real(3)]; 2]),
            Classification::Decided(None)
        ));
        assert!(matches!(
            saturate_rootless_bivariate_axis_factors(&equations, [[&real(1), &real(0)]; 2]),
            Classification::Decided(None)
        ));
        assert!(matches!(
            saturate_rootless_bivariate_axis_factors(&equations, [[&real(1), &real(1)]; 2]),
            Classification::Decided(Some(_))
        ));
    }

    proptest! {
        #[test]
        fn generated_polynomial_determinant_matches_scalar_permutation_expansion(
            coefficients in prop::collection::vec(-3_i8..=3, 48),
        ) {
            let matrix = coefficients.chunks(3).enumerate()
                .map(|(index, entry)| entry.iter().enumerate().map(|(power, value)| {
                    (real(i64::from(*value)) / real(2 + ((index + power) % 5) as i64)).unwrap()
                }).collect())
                .collect::<Vec<Vec<Real>>>();
            let determinant = determinant_polynomial_matrix(&matrix, 4)
                .expect("a rational polynomial matrix admits exact fraction-free elimination");
            // Both determinants have degree at most eight. Nine independent
            // scalar evaluations certify equality as polynomials, including
            // values where the polynomial elimination's pivots vanish.
            for sample in -4..=4 {
                let parameter = real(sample);
                let entries = matrix.iter().map(|entry| Real::eval_poly(entry, &parameter))
                    .collect::<Vec<_>>();
                let mut expected = Real::zero();
                for a in 0..4 {
                    for b in 0..4 {
                        for c in 0..4 {
                            for d in 0..4 {
                                let columns = [a, b, c, d];
                                if (0..4).any(|i| (i + 1..4).any(|j| columns[i] == columns[j])) {
                                    continue;
                                }
                                let inversions = (0..4).map(|i| (i + 1..4)
                                    .filter(|j| columns[i] > columns[*j]).count()).sum::<usize>();
                                let term = &entries[a] * &entries[4 + b]
                                    * &entries[8 + c] * &entries[12 + d];
                                if inversions % 2 == 0 { expected += term; } else { expected -= term; }
                            }
                        }
                    }
                }
                prop_assert_eq!(Real::eval_poly(&determinant, &parameter), expected);
            }
        }

        #[test]
        fn generated_exact_bivariate_division_replays_ragged_products(
            divisor_coefficients in prop::collection::vec(-3_i8..=3, 1..=9),
            quotient_coefficients in prop::collection::vec(-3_i8..=3, 1..=9),
        ) {
            let polynomial = |coefficients: Vec<i8>| {
                canonical_exact_bivariate(
                    coefficients
                        .chunks(3)
                        .map(|row| row.iter().map(|coefficient| real(i64::from(*coefficient))).collect())
                        .collect(),
                )
            };
            let divisor = polynomial(divisor_coefficients);
            prop_assume!(!exact_bivariate_is_zero(&divisor));
            let quotient = polynomial(quotient_coefficients);
            let dividend = multiply_bivariate(&divisor, &quotient);

            prop_assert_eq!(
                divide_bivariate_polynomial_exact(&dividend, &divisor),
                Some(quotient)
            );
        }

        #[test]
        fn generated_exact_bivariate_division_rejects_a_perturbed_product(
            divisor_coefficients in prop::collection::vec(-3_i8..=3, 2..=9),
            quotient_coefficients in prop::collection::vec(-3_i8..=3, 1..=9),
        ) {
            let polynomial = |coefficients: Vec<i8>| {
                canonical_exact_bivariate(
                    coefficients
                        .chunks(3)
                        .map(|row| row.iter().map(|coefficient| real(i64::from(*coefficient))).collect())
                        .collect(),
                )
            };
            let divisor = polynomial(divisor_coefficients);
            let Some((first_power, second_power, _)) =
                leading_bivariate_term(&divisor.coefficients)
            else {
                prop_assume!(false);
                unreachable!();
            };
            prop_assume!(first_power != 0 || second_power != 0);
            let quotient = polynomial(quotient_coefficients);
            let mut perturbed = multiply_bivariate(&divisor, &quotient);
            if perturbed.coefficients[0].is_empty() {
                perturbed.coefficients[0].push(Real::zero());
            }
            perturbed.coefficients[0][0] += real(1);

            prop_assert!(divide_bivariate_polynomial_exact(&perturbed, &divisor).is_none());
        }

        #[test]
        fn generated_horizontal_line_intersects_parabola_at_exact_height(
            height in 1_i16..=32,
        ) {
            let height = i64::from(height);
            let parabola = PolynomialParametricCurve2::new(
                vec![real(0), real(1)],
                vec![real(0), real(0), real(1)],
            );
            let horizontal = PolynomialParametricCurve2::new(
                vec![real(0), real(1)],
                vec![real(height)],
            );

            let report = resultant_parametric_curve_intersection(
                &parabola,
                &horizontal,
                CurveResultantParameter::First,
                CurveIntersectionResultantConfig::default(),
            );

            prop_assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            prop_assert_eq!(
                report.resultant_coefficients,
                vec![real(-height), real(0), real(1)]
            );
        }

        #[test]
        fn generated_rational_weighted_parabola_resultant_cross_multiplies_height(
            height in 1_i16..=32,
        ) {
            let height = i64::from(height);
            let weighted_parabola = RationalParametricCurve2::new(
                vec![real(0), real(1)],
                vec![real(0), real(0), real(1)],
                vec![real(1), real(1)],
            );
            let horizontal = RationalParametricCurve2::from_polynomial(
                &PolynomialParametricCurve2::new(vec![real(0), real(1)], vec![real(height)]),
            );

            let report = resultant_rational_parametric_curve_intersection(
                &weighted_parabola,
                &horizontal,
                CurveResultantParameter::First,
                CurveIntersectionResultantConfig::default(),
            );

            prop_assert_eq!(report.status, CurveIntersectionResultantStatus::Constructed);
            prop_assert_eq!(
                report.resultant_coefficients,
                vec![real(-height), real(-height), real(1)]
            );
        }
    }
}
