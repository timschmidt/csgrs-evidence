fn acosh_near_one(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Near one, acosh(x) is ln1p((x - 1) + sqrt(x^2 - 1)). Deferring the graph
    // keeps construction cheap for endpoint-adjacent scalar rows without
    // changing the cancellation-avoiding approximation identity.
    let one = Computable::one();
    let shifted = c.clone().add(one.clone().negate());
    let radicand = c.clone().square().add(one.negate());
    shifted
        .add(radicand.sqrt())
        .ln_1p()
        .approx_signal(signal, p)
}

fn acosh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Large acosh inputs use ln(x + sqrt(x^2 - 1)); this node is used by Real
    // construction paths where allocating that graph eagerly is the bottleneck.
    let one = Computable::one();
    let radicand = c.clone().square().add(one.negate());
    c.clone().add(radicand.sqrt()).ln().approx_signal(signal, p)
}

fn asinh_near_zero(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Near zero, asinh(x) is evaluated through ln1p(x + x^2/(sqrt(1+x^2)+1)).
    // This deferred node removes construction overhead but preserves the
    // cancellation-resistant formula used by the public Real path.
    let square = c.clone().square();
    let one = Computable::one();
    let denominator = square.clone().add(one.clone()).sqrt().add(one);
    c.clone()
        .add(square.multiply(denominator.inverse()))
        .ln_1p()
        .approx_signal(signal, p)
}

fn asinh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Large asinh inputs use ln(x + sqrt(1+x^2)); deferring the direct identity
    // keeps scalar construction from allocating the sqrt/log graph eagerly.
    let radicand = c.clone().square().add(Computable::one());
    c.clone().add(radicand.sqrt()).ln().approx_signal(signal, p)
}

fn asinh_outside_series(
    signal: &Option<Signal>,
    c: &Computable,
    negative: bool,
    p: Precision,
) -> BigInt {
    // A separated series sample (or the exact rational) proves this sign.
    // Use odd symmetry before the existing logarithmic identity so a large
    // negative argument cannot cancel against sqrt(1+x^2).
    if negative {
        -asinh_direct(signal, &c.clone().negate(), p)
    } else {
        asinh_direct(signal, c, p)
    }
}

// Approximate asinh(c) for small |c|.
fn asinh_computable(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Dedicated tiny-argument asinh series. It avoids constructing the generic
    // ln(x + sqrt(1+x^2)) or ln1p expression for exact tiny rational inputs.
    if should_stop(signal) {
        return Zero::zero();
    }

    let series_precision = p.min(0);
    let iterations_needed: i32 = -series_precision / 2 + 4;
    let calc_precision = series_precision - bound_log2(2 * iterations_needed) - 5;
    let op_prec = calc_precision - 3;
    let op_appr = c.approx_signal(signal, op_prec);
    // bits(|a|) <= -op_prec-1, including the sample's one-unit error,
    // proves |c| <= 1/2. An imported tag is not this range certificate.
    if op_appr.magnitude().bits()
        > u64::try_from(-op_prec - 1).expect("asinh series scale is positive")
    {
        if should_stop(signal) {
            return Zero::zero();
        }
        return asinh_outside_series(signal, c, op_appr.sign() == Sign::Minus, p);
    }
    // |asinh(c)| <= |c| <= 1/2 justifies the coarse approximation only
    // after the range proof, independently of the requested precision.
    if p >= 1 {
        return Zero::zero();
    }
    let op_squared = scale(&op_appr * &op_appr, op_prec);

    // This is the asin recurrence with alternating sign:
    // asinh(x) = x - x^3/6 + 3x^5/40 - ...
    let max_trunc_error = BigUint::one()
        << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
    let mut current_term = scale(op_appr, op_prec - calc_precision);
    let mut sum = current_term.clone();
    let mut n = 0_i32;

    while current_term.magnitude() > &max_trunc_error {
        if should_stop(signal) {
            break;
        }
        n += 1;
        current_term = scale(current_term * &op_squared, op_prec);
        let (numerator, denominator) = inverse_sine_series_coefficients(n);
        current_term *= numerator;
        current_term /= denominator;
        current_term = -current_term;
        sum += &current_term;
    }

    scale(sum, calc_precision - p)
}

fn asinh_rational(signal: &Option<Signal>, r: &Rational, p: Precision) -> BigInt {
    // Direct exact-rational variant of the tiny asinh series. It is the same
    // recurrence as `asinh_computable`, but it feeds the stored Rational
    // straight to the final precision request instead of allocating a temporary
    // Ratio node and child cache.
    // Only zero or a proved small magnitude admits the series. A magnitude
    // outside the metadata's i32 range is not a small-argument certificate.
    if r.sign() != Sign::NoSign && r.msd_exact().is_none_or(|msd| msd >= -1) {
        if should_stop(signal) {
            return Zero::zero();
        }
        return asinh_outside_series(
            signal,
            &Computable::rational(r.clone()),
            r.sign() == Sign::Minus,
            p,
        );
    }
    if p >= 1 {
        return Zero::zero();
    }

    let iterations_needed: i32 = -p / 2 + 4;
    let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
    let op_prec = calc_precision - 3;
    let op_appr = ratio(r, op_prec);
    let op_squared = scale(&op_appr * &op_appr, op_prec);

    let max_trunc_error = BigUint::one()
        << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
    let mut current_term = scale(op_appr, op_prec - calc_precision);
    let mut sum = current_term.clone();
    let mut n = 0_i32;

    while current_term.magnitude() > &max_trunc_error {
        if should_stop(signal) {
            break;
        }
        n += 1;
        current_term = scale(current_term * &op_squared, op_prec);
        let (numerator, denominator) = inverse_sine_series_coefficients(n);
        current_term *= numerator;
        current_term /= denominator;
        current_term = -current_term;
        sum += &current_term;
    }

    scale(sum, calc_precision - p)
}

fn atanh_direct(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Endpoint atanh construction should not eagerly allocate the full exact
    // log-ratio graph. Approximation still uses the stable identity
    // atanh(x) = 1/2 * ln((1+x)/(1-x)).
    let one = Computable::one();
    let numerator = one.clone().add(c.clone());
    let denominator = one.add(c.clone().negate());
    numerator
        .multiply(denominator.inverse())
        .ln()
        .multiply(Computable::rational(HALF_RATIONAL.clone()))
        .approx_signal(signal, p)
}

// Approximate atanh(c) for small |c|.
fn atanh_computable(signal: &Option<Signal>, c: &Computable, p: Precision) -> BigInt {
    // Dedicated tiny-argument atanh series. Prove its domain before both the
    // fixed error budget and the coarse-zero shortcut, including stored nodes.
    if should_stop(signal) {
        return Zero::zero();
    }
    if p >= 1 {
        if c.inverse_series_argument_is_small(signal) || should_stop(signal) {
            return Zero::zero();
        }
        return atanh_direct(signal, c, p);
    }

    let iterations_needed: i32 = -p / 2 + 4;
    let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
    let op_prec = calc_precision - 3;
    let op_appr = c.approx_signal(signal, op_prec);
    // The sample is already required by the series. bits(|a|) <= -op_prec-3
    // leaves one integer unit for its error and proves |c| <= 1/8.
    if op_appr.magnitude().bits()
        > u64::try_from(-op_prec - 3).expect("tiny-series scale is positive")
    {
        if should_stop(signal) {
            return Zero::zero();
        }
        return atanh_direct(signal, c, p);
    }
    let op_squared = scale(&op_appr * &op_appr, op_prec);

    // Borrowed magnitude checks matter here because tiny inverse-hyperbolic
    // benches run many short series from cold caches.
    let max_trunc_error = BigUint::one()
        << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
    let mut current_power = scale(op_appr, op_prec - calc_precision);
    let mut current_term = current_power.clone();
    let mut sum = current_term.clone();
    let mut n = 1_i32;

    while current_term.magnitude() > &max_trunc_error {
        if should_stop(signal) {
            break;
        }
        n += 2;
        current_power = scale(current_power * &op_squared, op_prec);
        current_term = &current_power / n;
        sum += &current_term;
    }

    scale(sum, calc_precision - p)
}

fn atanh_rational(signal: &Option<Signal>, r: &Rational, p: Precision) -> BigInt {
    // Direct exact-rational variant of the tiny atanh series. This mirrors the
    // direct rational trig kernels: preserve the symbolic rational payload and
    // round only once at the requested working precision.
    // A stored rational tag does not prove the tiny-series range. For nonzero
    // r, an exact MSD <= -4 proves |r| < 1/8 and justifies both this series
    // and the coarse-zero shortcut. Missing metadata is not a range proof.
    if r.sign() != Sign::NoSign && r.msd_exact().is_none_or(|msd| msd >= -3) {
        if should_stop(signal) {
            return Zero::zero();
        }
        // Native rational atanh uses this kernel only for MSD <= -4, so this
        // fallback instead reaches its exact logarithm reduction or endpoint
        // identities without recreating the inadmissible series node.
        return Computable::rational(r.clone())
            .atanh()
            .approx_signal(signal, p);
    }
    if p >= 1 {
        return Zero::zero();
    }

    let iterations_needed: i32 = -p / 2 + 4;
    let calc_precision = p - bound_log2(2 * iterations_needed) - 5;
    let op_prec = calc_precision - 3;
    let op_appr = ratio(r, op_prec);
    let op_squared = scale(&op_appr * &op_appr, op_prec);

    let max_trunc_error = BigUint::one()
        << usize::try_from(p - 4 - calc_precision).expect("truncation shift is nonnegative");
    let mut current_power = scale(op_appr, op_prec - calc_precision);
    let mut current_term = current_power.clone();
    let mut sum = current_term.clone();
    let mut n = 1_i32;

    while current_term.magnitude() > &max_trunc_error {
        if should_stop(signal) {
            break;
        }
        n += 2;
        current_power = scale(current_power * &op_squared, op_prec);
        current_term = &current_power / n;
        sum += &current_term;
    }

    scale(sum, calc_precision - p)
}
