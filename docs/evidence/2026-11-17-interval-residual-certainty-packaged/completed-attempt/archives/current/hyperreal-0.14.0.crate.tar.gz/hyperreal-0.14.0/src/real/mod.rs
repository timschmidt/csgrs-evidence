//! Public symbolic real type and its semantic operation groups.
//!
//! Most implementation still lives in `arithmetic` because the representation
//! invariants, constructor simplifications, structural facts, and borrowed
//! arithmetic fast paths share the same private fields. The sibling modules
//! name the semantic areas so readers can discover the intended split without
//! paying performance risk from moving hot code prematurely.

mod approximation;
mod arithmetic;
mod constructors;
mod convert;
mod exact_set;
mod facts;
mod linear_combination;
#[cfg(test)]
mod normal_reference;
mod tests;

#[cfg(test)]
mod immediate_equality_tests;

#[cfg(feature = "serde")]
pub(crate) use arithmetic::RealWire;
pub use arithmetic::*;
pub use exact_set::{
    RealExactSetDenominatorKind, RealExactSetDyadicExponentClass, RealExactSetFacts,
    RealExactSetSignPattern,
};
