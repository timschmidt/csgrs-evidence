from pathlib import Path
import json
d=Path(__file__).resolve().parent
allrows={}
for s in ['fixed','preceding','candidate']:
    ss={}
    for k in ['stack','life']:
        rows={}
        for i in range(8):
            p=d/'observations'/s/f'{k}-{i}.tsv'
            for ln in p.read_text().splitlines():
                rep,case,warm,pattern,peak,*rest=ln.split('\t')
                key=i,rep,case,warm,pattern
                assert key not in rows
                rows[key]=(int(peak),tuple(rest))
        assert len(rows)==12800
        ss[k]=rows
    allrows[s]=ss
counts={}
for kind in ['stack','life']:
    b=allrows['preceding'][kind]
    for s in ('candidate','fixed'):
        other=allrows[s][kind]
        assert set(other)==set(b)
        changes={}
        for key,(bs,extra) in b.items():
            cs,other_extra=other[key]
            assert extra==other_extra,(s,kind,key,extra,other_extra)
            if cs!=bs:
                k=(key[2],key[3],cs-bs)
                changes[k]=changes.get(k,0)+1
        counts[kind+' '+s+' minus preceding']=[[*k,v] for k,v in sorted(changes.items())]
(d/'matched-observations.json').write_text(json.dumps(counts,indent=2)+'\n')
print(counts)
