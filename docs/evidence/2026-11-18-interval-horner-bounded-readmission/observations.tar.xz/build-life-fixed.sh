set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env-fixed"
stage=$1
cargo +stable build --locked --release --manifest-path "$d/life/Cargo.toml" >"$d/$stage/life-build.log" 2>&1
cp "$CARGO_TARGET_DIR/release/horner-life-harness" "$d/$stage/life"
