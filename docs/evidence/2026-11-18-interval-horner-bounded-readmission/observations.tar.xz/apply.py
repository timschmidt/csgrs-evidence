from pathlib import Path
import subprocess as sp
d=Path(__file__).parent
w=d/'src'
sp.run(['git','apply','--exclude=crates/hypersolve/Cargo.toml',d/'historical.patch'],cwd=w,check=True)
p=w/'crates/hypersolve/Cargo.toml'
s=p.read_text()
old='hyperinterval = { version = "0.1.0", path = "../hyperinterval", default-features = false, optional = true }\n[dev-dependencies]\n# Test-only interval migration candidates; production remains gated by cost.\n'
assert s.count(old)==1;s=s.replace(old,'')
old='features = ["rational"] }\n# Fresh-process';assert s.count(old)==1;s=s.replace(old,'features = ["rational"] }\n[dev-dependencies]\n# Fresh-process')
p.write_text(s.replace('"dep:hyperinterval", ','').replace('hyperinterval?/serde','hyperinterval/serde').replace('dispatch-trace = [\n','dispatch-trace = [\n    "hyperinterval/dispatch-trace",\n'))
