set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env"
test -f "$d/candidate/rational.log" && grep -q 'test result: ok' "$d/candidate/rational.log"
mv "$d/src" "$d/candidate-source"
mkdir "$d/src"
git archive c9f1f9ac5 | tar xf - -C "$d/src"
mkdir "$d/fixed"
for h in stack life; do
 cp "$d/src/Cargo.lock" "$d/$h/Cargo.lock"
 cargo +stable metadata --offline --manifest-path "$d/$h/Cargo.toml" --format-version 1 >"$d/fixed/$h-metadata.json"
 cp "$d/$h/Cargo.lock" "$d/fixed/$h.lock"
done
sed 's|^export CARGO_TARGET_DIR=.*|export CARGO_TARGET_DIR=/dev/shm/interval-horner-readmission/target-fixed|' "$d/env" > "$d/env-fixed"
for n in build build-life; do
 sed 's|"$d/env"|"$d/env-fixed"|' "$d/$n.sh" > "$d/$n-fixed.sh"
 bash "$d/$n-fixed.sh" fixed
done
python3 "$d/sizes.py"
python3 "$d/probes.py" fixed
python3 "$d/review.py" fixed preceding candidate
