set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env"
for i in $(seq 1 120); do
 if test -f "$d/observations/fixed/life-7.json" && grep -q "'fixed'" "$d/fixed-run.log"; then break; fi
 sleep 2
done
test -f "$d/observations/fixed/life-7.json"
python3 "$d/timing.py" 0 > "$d/timing-0.log" 2>&1
python3 "$d/timing.py" 1 > "$d/timing-1.log" 2>&1
