from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess, sys, json, hashlib, time
root=Path(__file__).resolve().parent
stages=sys.argv[1:]
def lane(i):
    for block in (i,i+4):
        for kind in ('stack','life'):
            for stage in (stages if block%2==0 else stages[::-1]):
                dest=root/'observations'/stage
                dest.mkdir(parents=True,exist_ok=True)
                stem=dest/f'{kind}-{block}'
                start=time.monotonic()
                cmd=['taskset','-c',str(1+4*i),str(root/stage/kind)]
                with stem.with_suffix('.tsv').open('w') as out,stem.with_suffix('.stderr').open('w') as err:
                    subprocess.run(cmd,stdout=out,stderr=err,check=True,timeout=180)
                stem.with_suffix('.json').write_text(json.dumps(dict(command=cmd,seconds=time.monotonic()-start,sha256=hashlib.sha256(stem.with_suffix('.tsv').read_bytes()).hexdigest()))+'\n')
with ThreadPoolExecutor(4) as pool:list(pool.map(lane,range(4)))
