import hashlib, json, re, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
def size(p):
    sections=0
    for line in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
        m=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',line)
        if m and 'A' in m[3] and 'X' in m[3]:sections+=int(m[2],16)
    ranges=[]
    for line in subprocess.check_output(['nm','--print-size','--radix=d',p],text=True).splitlines():
        r=line.split(maxsplit=3)
        if len(r)==4 and r[2] in ('t','T'):
            start=int(r[0]);ranges.append((start,start+int(r[1])))
    hi=total=0
    for start,end in sorted(ranges):
        total+=max(0,end-max(start,hi));hi=max(hi,end)
    return dict(file=p.stat().st_size,executable_sections=sections,named_functions=total,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
result={s:size(root/s/'certification') for s in ('fixed','preceding','candidate') if (root/s/'certification').exists()}
(root/'sizes.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
