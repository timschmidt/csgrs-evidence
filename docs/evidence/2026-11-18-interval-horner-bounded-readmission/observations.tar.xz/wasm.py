from pathlib import Path
import sys, os, json, hashlib
d=Path(__file__).resolve().parent
src=d/'candidate-source'
sys.path.insert(0,str(src/'crates/hyperinterval/conformance'))
import wasi_libtest as lib
out=d/'wasi-production'
out.mkdir()
base=['cargo','+stable','test','--release','--locked','-p','hypersolve','--features','dispatch-trace']
env=os.environ|{'CARGO_TARGET_DIR':str(d/'target-wasi'),'CARGO_BUILD_JOBS':'10'}
guest=lib.build_tests([*base,'--target',lib.TARGET],['--lib'],env)['hypersolve']
host=next(p for p in (d/'target/release/deps').glob('hypersolve-*') if p.is_file() and os.access(p,os.X_OK) and p.suffix=='')
summary={}
for prefix,count in [('algebraic::interval_migration::rational_horner',1404),('root_isolation::interval_migration::rational_horner_exclusion',2808)]:
    exact=prefix+'_exact_differential'
    done=lib.execute(['node',str(lib.RUNNER),guest,'--exact',exact],out/(exact.replace('::','.')+'.log'))
    assert done.returncode==0 and lib.completed(done.stdout,{exact}),done.stdout[-1000:]
    case=prefix+'_production_dispatch_differential'
    summary[case]=lib.compare_dispatch(guest,host,case,'HYPERSOLVE_HORNER_BACKEND','HORNER',count,out)
(out/'report.json').write_text(json.dumps(dict(windows=summary,guest_sha256=hashlib.sha256(Path(guest).read_bytes()).hexdigest(),host_sha256=hashlib.sha256(host.read_bytes()).hexdigest()),indent=2)+'\n')
