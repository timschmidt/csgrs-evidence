set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env"
mv "$d/src" "$d/fixed-source"
mkdir "$d/src"
git archive 79b183c51 | tar xf - -m -C "$d/src"
python3 "$d/apply.py"
git diff 0f604c194 80337035e -- crates >"$d/second.patch"
(cd "$d/src"; git apply "$d/second.patch")
mkdir -p "$d/second"
for h in stack life; do cp "$d/candidate/$h.lock" "$d/$h/Cargo.lock"; done
bash "$d/build.sh" second
bash "$d/build-life.sh" second
python3 "$d/probes.py" second
python3 "$d/second-review.py" >"$d/second-review.log"
