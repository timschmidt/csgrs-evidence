set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env"
for i in $(seq 1 180); do
 if test -f "$d/timing-1/review.json"; then break; fi
 sleep 2
done
test -f "$d/timing-1/review.json"
python3 "$d/wasm.py" >"$d/wasm.log" 2>&1
