from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib, json, math, os, random, shutil, statistics, subprocess, sys, time
d=Path(__file__).resolve().parent
n=int(sys.argv[1])
p=json.loads((d/'benchmark-plan.json').read_text())
caps=json.loads((d/'sizes.json').read_text())
out=d/f'timing-{n}'
out.mkdir()
lanes=[2,4,6,8,12,14,16,18]
def run(block):
    lane=out/str(block)
    lane.mkdir()
    exe=lane/'certification'
    order=['preceding','candidate','candidate','preceding']
    if (block+n)%2:order.reverse();order=['candidate','preceding','preceding','candidate']
    rows=[]
    for i,stage in enumerate(order):
        dest=lane/f'{i}-{stage}'
        dest.mkdir()
        shutil.copy2(d/stage/'certification',exe)
        digest=hashlib.sha256(exe.read_bytes()).hexdigest()
        assert digest==caps[stage]['sha256']
        cmd=['taskset','-c',str(lanes[(block+3*n)%8]),str(exe),'--bench',p['pattern'],'--sample-size','40','--measurement-time','2','--warm-up-time','0.5','--nresamples','10000','--noplot']
        start=time.monotonic()
        with (dest/'output.log').open('w') as log:
            subprocess.run(cmd,check=True,timeout=120,stdout=log,stderr=subprocess.STDOUT,
                env=os.environ|{'CRITERION_HOME':str(dest/'criterion'),'RAYON_NUM_THREADS':'1'},cwd=d)
        cases={}
        for source in dest.glob('criterion/**/new/estimates.json'):
            name=json.loads((source.parent/'benchmark.json').read_text())['full_id']
            cases[name]=json.loads(source.read_text())['mean']['point_estimate']
        assert set(cases)==set(p['cases']),(dest,list(cases))
        row=dict(block=block,stage=stage,command=cmd,seconds=time.monotonic()-start,sha256=digest,cases=cases)
        (dest/'result.json').write_text(json.dumps(row,indent=2)+'\n')
        rows.append(row)
    return rows
with ThreadPoolExecutor(8) as pool:rows=sum(pool.map(run,range(8)),[])
summary={}
rng=random.Random(p['bootstrap_seed']+n)
for name in p['cases']:
    diffs=[]
    for block in range(8):
        b,c=([math.log(row['cases'][name]) for row in rows if row['block']==block and row['stage']==stage] for stage in ['preceding','candidate'])
        assert len(b)==len(c)==2
        diffs.append(statistics.mean(c)-statistics.mean(b))
    boot=sorted(math.exp(statistics.mean(rng.choices(diffs,k=8))) for _ in range(10000))
    summary[name]=dict(ratio=math.exp(statistics.mean(diffs)),interval=[boot[250],boot[9749]],paired_log_ratios=diffs)
(out/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:[v['ratio'],v['interval']] for k,v in summary.items()})
