set -eu
d=/dev/shm/interval-horner-readmission
. "$d/env"
stage=$1
cd "$d/src"
mkdir -p "$d/$stage"
cargo +stable build --locked -p hypersolve --bench certification --release --message-format=json-render-diagnostics >"$d/$stage/bench.jsonl" 2>"$d/$stage/bench-build.log"
f=$(python3 -c 'import json,sys; print(next(j["executable"] for j in map(json.loads,open(sys.argv[1])) if j.get("executable") and j["target"]["name"]=="certification"))' "$d/$stage/bench.jsonl")
cp "$f" "$d/$stage/certification"
cargo +stable build --locked --release --manifest-path "$d/stack/Cargo.toml" >"$d/$stage/stack-build.log" 2>&1
cp "$CARGO_TARGET_DIR/release/horner-stack-harness" "$d/$stage/stack"
