from pathlib import Path
from collections import defaultdict
import sys,json
root=Path(__file__).resolve().parent
def load(stage,kind):
    data=defaultdict(list)
    for block in range(8):
        stem=root/'observations'/stage/f'{kind}-{block}'
        assert stem.with_suffix('.json').is_file()
        lines=stem.with_suffix('.tsv').read_text().splitlines()
        assert len(lines)==1600,len(lines)
        seen=set()
        for line in lines:
            rep,case,warm,pattern,stack,*values=line.split('\t')
            key=(case,warm); ident=(rep,pattern,key)
            assert ident not in seen;seen.add(ident)
            extra=values if kind=='stack' else list(map(int,values))
            assert len(extra)==(1 if kind=='stack' else 6)
            data[key].append([int(stack),*extra])
        assert {int(k[0]) for k in seen}==set(range(8))
        assert {int(k[1]) for k in seen}=={90,165}
    assert len(data)==100 and all(len(rows)==128 for rows in data.values())
    return {key:list(map(max,zip(*rows))) for key,rows in data.items()}, {key:set(r[-1] for r in rows) for key,rows in data.items()} if kind=='stack' else {}
stages=sys.argv[1:]
for kind in ['stack','life']:
    all_data={s:load(s,kind) for s in stages}
    ref=all_data['preceding']
    assert all(set(v[0])==set(ref[0]) and v[1]==ref[1] for v in all_data.values())
    if kind=='stack':assert all(len(s)==1 for s in ref[1].values())
    rows=[]
    for key in sorted(ref[0]):
        values={s:v[0][key][:(1 if kind=='stack' else 7)] for s,v in all_data.items()}
        b,c=values['preceding'],values['candidate']
        deltas=[y-x for x,y in zip(b,c)]
        def split(x):return max(0,x)
        fixed=values.get('fixed')
        charges=([split(y-x)+split(z-y) for x,y,z in zip(fixed,b,c)] if fixed is not None else [])
        fail=[]
        if deltas[0]>32 or 100*deltas[0]>b[0]:fail.append('incremental stack')
        if fixed and (charges[0]>64 or 100*charges[0]>2*fixed[0]):fail.append('cumulative stack')
        if c[0]>32768 or 2097152-4096-c[0]<1048576:fail.append('capacity')
        if any(x>0 for x in deltas[1:]):fail.append('incremental heap/count')
        if any(x>0 for x in charges[1:]):fail.append('cumulative heap/count')
        rows.append(dict(case=key[0],warm=key[1]=='true',maxima=values,delta=deltas,positive_charges=charges,failed=fail))
    (root/f'review-{kind}.json').write_text(json.dumps(rows,indent=1)+'\n')
    print(kind,'counts',len(rows),'incremental failures',sum(bool(r['failed']) for r in rows),'largest peaks', {s:max(r['maxima'][s][0] for r in rows) for s in stages})
    print('Largest incremental growth',sorted([(r['delta'][0],r['case'],r['warm']) for r in rows],reverse=True)[:5])
    print('heap largest incremental deltas',list(map(max,zip(*(r['delta'][1:] for r in rows)))))
