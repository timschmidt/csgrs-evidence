from pathlib import Path
import hashlib,importlib.util,io,json,lzma,shutil,subprocess,tarfile,sys
s=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
e=r.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-horner-bounded-readmission'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p):files[str(p.relative_to(s))]=p.read_bytes()
for p in s.iterdir():
 if p.is_file() and p.name not in ('evidence-revision','archive-result','life-metadata.json','stack-metadata.json') and not p.name.endswith('.pyc'):add(p)
for stage in ('fixed','preceding','candidate','second'):
 for p in (s/stage).iterdir():
  if p.suffix in ('.lock','.log') or p.name in ('all-features.json','all-accounted.json'):add(p)
  if p.name=='all-build.jsonl':
   files[stage+'/all-executables.json']=json.dumps([{k:row[k] for k in ('target','profile','features','executable','fresh')} for line in p.open() if (row:=json.loads(line)).get('executable')],indent=1).encode()
  if p.name in ('certification','stack','life'): files[stage+'/'+p.name+'.sha256']=h(p.read_bytes()).encode()
for kind in ('stack','life'):
 for p in (s/kind).rglob('*'):
  if p.is_file() and p.suffix in ('.rs','.c','.toml'):add(p)
for p in (s/'observations').rglob('*'):
 if p.is_file():add(p)
for out in s.glob('timing-[01]'):
 if (out/'review.json').exists():add(out/'review.json')
 for p in out.rglob('result.json'):add(p)
 for p in out.rglob('output.log'):add(p)
 for p in out.glob('*/*/criterion/*/new/sample.json'):add(p)
for p in (s/'wasi-production').glob('*'):
 if p.is_file():add(p)
for f in ['sizes.json','scope','historical.patch','paired.py','review-life.json','review-stack.json','matched-observations.json']:assert f in files
if 'commit' in sys.argv:
 for f in ['timing-0/review.json','timing-1/review.json','wasi-production/report.json','candidate/production-traces.log','candidate/rational.log','all-budget-review.json','second-review.log']:assert f in files
 assert len([k for k in files if k.endswith('/sample.json')])==576
 assert {k for k in files if k.startswith('observations/') and k.endswith('.tsv')}=={f'observations/{stage}/{kind}-{i}.tsv' for stage in ('fixed','preceding','candidate','second') for kind in ('stack','life') for i in range(8)}
digests={k:h(v) for k,v in sorted(files.items())}
archive=s/'record'
archive.mkdir(exist_ok=True)
with tarfile.open(archive/'observations.tar.xz','w:xz',preset=6) as t:
 for k,b in sorted(files.items()):
    m=tarfile.TarInfo(k);m.size=len(b);t.addfile(m,io.BytesIO(b))
with tarfile.open(archive/'observations.tar.xz','r|xz') as t: assert {m.name:h(t.extractfile(m).read()) for m in t}==digests
(archive/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(digests,indent=1).encode()))
assert json.loads(lzma.decompress((archive/'sha256.json.xz').read_bytes()))==digests
size=sum(p.stat().st_size for p in archive.iterdir())
print(len(files),size,shutil.disk_usage(e).free,flush=True)
if 'commit' not in sys.argv:sys.exit()
assert shutil.disk_usage(e).free-3*size-1024**2>=20*1024**3,(size,shutil.disk_usage(e).free)
assert not git(e,'status','--porcelain') and not (e/record).exists()
shutil.copytree(archive,e/record)
git(e,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(e,'diff','--cached','--name-only').decode().splitlines())
git(e,'-c','gc.auto=0','commit','-m','Archive cumulative Horner stack, heap and replicated runtime measurements')
rev=git(e,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(e,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('m',r/'scripts/evidence_archive.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
row=m.manifest(str(e),rev)[1]
idx=r/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(row+'\n')
(s/'evidence-revision').write_text(rev+'\n')
print(rev,row)
