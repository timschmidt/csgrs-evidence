from pathlib import Path
import json
p=Path(__file__).resolve().parent
for kind in ['stack','life']:
    src=json.loads((p/f'review-{kind}.json').read_text())
    rows={}
    for b in range(8):
        s=(p/'observations/second'/f'{kind}-{b}.tsv').read_text().splitlines()
        c=(p/'observations/preceding'/f'{kind}-{b}.tsv').read_text().splitlines()
        assert len(s)==len(c)==1600
        for x,y in zip(s,c):
            a=x.split('\t');z=y.split('\t')
            assert a[:4]==z[:4] and a[5:]==z[5:]
            rows.setdefault((a[1],a[2]=='true'),[]).append(int(a[4]))
    result=[]
    for r in src:
        values=rows[r['case'],r['warm']]
        assert len(values)==128
        b=r['maxima']['preceding'][0];f=r['maxima']['fixed'][0];s=max(values)
        delta=s-b;charge=max(0,b-f)+max(0,delta)
        result.append(dict(case=r['case'],warm=r['warm'],fixed=f,preceding=b,second=s,delta=delta,
                       cumulative=charge,passed=(delta<=32 and 100*delta<=b and charge<=64 and 100*charge<=2*f and s<=32768)))
    assert len(rows)==len(result)==100
    print(kind,[r for r in result if not r['passed']])
    (p/f'second-{kind}-account.json').write_text(json.dumps(result,indent=2)+'\n')
