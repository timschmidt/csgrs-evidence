"""Run affected predicate, curve interchange and circuit interchange consumers."""
import json,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent
from cargo_harness_v1 import Harness,cargo,dump,rows
assert json.loads((W.parent/'owned-fold-scalar-v1/result-v1.json').read_text())['passed']
h=Harness('consumers-v1',W/'source-pins-v4.json.gz');summaries={};packages={}
for name,flags,targets in [
 ('hyperlimit',['--all-features'],[]),
 ('hypercircuit',['--features','interchange'],['interchange','event_interchange','package','edit','curved_outline']),
]:
 args=['test','--release','--locked','--offline','-p',name]+flags
 if targets:
  for target in targets:args+=['--test',target]
 else:args+=['--tests']
 keys=h.build(name+'-build',args);h.bind_programs(keys);counts=[]
 for i,key in enumerate(keys):
  if not h.artifacts[key]['profile']['test']:continue
  result,_,_,_=h.test(name+'-test-'+str(i),key)
  assert result and all(row[0]=='ok' and row[2]=='0' for row in result),result
  summaries[key]=result;counts.append(result[-1])
 h.execute(name+'-clippy',[cargo,'clippy','--release','--locked','-p',name,'--all-targets']+flags+['--','-D','warnings'])
 out,_,_=h.execute(name+'-doctests',[cargo,'test','--release','--locked','-p',name,'--doc']+flags+['--','--test-threads=1'])
 docs=rows(out);assert docs and all(r[0]=='ok' and r[2]=='0' for r in docs)
 h.execute(name+'-docs',[cargo,'doc','--release','--locked','-p',name,'--no-deps']+flags)
 packages[name]={'passed':sum(int(r[1]) for r in counts),'ignored':sum(int(r[3]) for r in counts),'doctests':docs,'features':flags,'selected_targets':targets or ['all test targets']}
 dump(h.R/'summaries-v1.json',{'summaries':summaries,'packages':packages})
curve_tests={}
for target,expected in [('hypercurve_svg',20),('svg_scalar_failures',1)]:
 keys=h.build(target+'-build',['test','--release','--locked','-p','hypercurve','--features','svg','--test',target])
 tests=[key for key in keys if h.artifacts[key]['profile']['test']]
 assert len(tests)==1
 result,_,_,_=h.test(target+'-run',tests[0])
 assert result==[('ok',str(expected),'0','0','0','0')],result
 curve_tests[target]=result
feature_matrix={}
for label,flags,expected in [
 ('geometry',['--features','interchange,geometry'],4),
 ('all',['--all-features'],5),
]:
 keys=h.build('curved-'+label+'-build',['test','--release','--locked','-p','hypercircuit','--test','curved_outline']+flags)
 tests=[key for key in keys if h.artifacts[key]['profile']['test']]
 assert len(tests)==1
 result,_,_,_=h.test('curved-'+label,tests[0])
 assert result==[('ok',str(expected),'0','0','0','0')],result
 feature_matrix[label]={'features':flags,'summaries':result,'test_bodies_unchanged':True}
 h.execute('curved-'+label+'-clippy',[cargo,'clippy','--release','--locked','-p','hypercircuit','--test','curved_outline']+flags+['--','-D','warnings'])
h.execute('hypercurve-clippy',[cargo,'clippy','--release','--locked','-p','hypercurve','--features','svg','--all-targets','--','-D','warnings'])
h.execute('hypercurve-docs',[cargo,'doc','--release','--locked','-p','hypercurve','--features','svg','--no-deps'])
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'feature_gate_matrix':feature_matrix,'curve_tests':curve_tests,'summaries':summaries,'commands':h.commands,'artifacts':h.artifacts,'main_source_without_overlays':True,'full_native_workloads_rerun':False,'full_plan_complete':False})
print(json.dumps({'passed':True,'packages':packages}),flush=True)
