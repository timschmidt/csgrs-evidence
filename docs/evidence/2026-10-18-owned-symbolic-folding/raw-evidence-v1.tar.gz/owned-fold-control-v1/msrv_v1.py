"""Check the owned-fold repair and immediate consumers at the compiler floor."""
import ast,json,os,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/owned-fold-control-v1')
N=W.parent;O=N.parent/'csgrs';U=Path('/tmp/csgrs-owned-fold-20261018-v1')
assert json.loads((N/'owned-fold-consumers-v1/result-v1.json').read_text())['passed']
target=U/'target-msrv-v1'
assert not target.exists()
target.mkdir()
source=W/'cargo_harness_v1.py'
helper=W/'owned_fold_msrv_harness_v1.py'
assert not helper.exists()
original=source.read_text()
old="self.target=U/'target'";new="self.target=U/'target-msrv-v1'"
assert original.count(old)==1
derived=original.replace(old,new)
ast.parse(derived)
helper.write_text(derived)
sys.path.insert(0,str(W))
from owned_fold_msrv_harness_v1 import Harness,sha,dump
h=Harness('msrv-v1',W/'source-pins-v4.json.gz')
assert h.target==target
tools=json.loads((O/'docs/evidence/2026-10-17-in-scope-msrv/review-v1.json').read_text())['tool_sha256']
assert all(sha(p)==v for p,v in tools.items())
root=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin')
os.environ.update(RUSTC=str(root/'rustc'),RUSTDOC=str(root/'rustdoc'),RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
dump(h.R/'compiler-v1.json',{
 'driver_sha256':sha(Path(__file__)),'compiler':'1.95.0','tools_sha256':tools,
 'environment':{k:os.environ[k] for k in ['RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN']},
 'runtime_tests_rerun':False,'clippy_on_msrv_run':False,
 'derived_harness':{'original_sha256':sha(source),'derived_sha256':sha(helper),'only_substitution':[old,new]},
 'target':str(target),'initial_target_empty':True,
})
h.execute('compiler-version',[root/'rustc','-Vv'],limit=60)
h.execute('cargo-version',[root/'cargo','-V'],limit=60)
for label,flags in [('all',['--all-features']),('minimal',['--no-default-features'])]:
 h.execute(label,[root/'cargo','check','--locked','-p','hyperreal','-p','hyperlimit','-p','hypercurve','--all-targets']+flags)
 print('MSRV_PASSED '+label,flush=True)
h.verify()
assert all(sha(p)==v for p,v in tools.items())
dump(h.R/'result-v1.json',{
 'passed':True,'commands':h.commands,'compiler':'1.95.0','all_targets':True,
 'features':['all','no-default'],'tools_sha256':tools,'runtime_tests_rerun':False,
 'clippy_on_msrv_run':False,'production_source_changed':True,
 'runtime_admitted':False,'full_plan_complete':False,
})
print('Affected compiler-floor checks passed.',flush=True)
