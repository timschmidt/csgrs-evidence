"""Owned symbolic folding acceptance checks."""
import gzip,json,os,re,shutil,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
U=Path('/tmp/csgrs-owned-fold-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
from validation_runner_v2 import run,dump,sha,resources,reasons

compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment'])
os.environ['CARGO_NET_OFFLINE']='true'
os.environ['CARGO_CACHE_AUTO_CLEAN_FREQUENCY']='never'
os.environ['RUSTDOCFLAGS']='-D warnings'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
rustfmt=str(Path(cargo).with_name('rustfmt'))

def rows(text):
    return re.findall(r'^test result: ([A-Za-z]+)[.] ([0-9]+) passed; ([0-9]+) failed; ([0-9]+) ignored; ([0-9]+) measured; ([0-9]+) filtered out;',text,re.M)
def file_state(path):
    st=Path(path).stat()
    return st.st_size,st.st_mtime_ns,st.st_ctime_ns
class Harness:
    def __init__(self,phase,pins_file):
        self.pins=json.loads(gzip.decompress(Path(pins_file).read_bytes()))
        self.phase=phase;self.R=N/('owned-fold-'+phase)
        self.A=U/'frozen'/phase;self.target=U/'target-msrv-v1'
        assert not self.R.exists() and not self.A.exists()
        self.R.mkdir();self.A.mkdir()
        self.commands={};self.artifacts={};self.runtime_bindings={};self.states={}
        for manifest in (U/'frozen').glob('*/executables-v1.json'):
            for item in json.loads(manifest.read_text()).values():
                assert sha(item['copy'])==item['sha256']
                self.states[item['copy']]=file_state(item['copy'])
        self.verify()
        dump(self.R/'protocol-v1.json',{
            'helper_sha256':sha(Path(__file__)),'phase':phase,
            'contract_sha256':sha(W/'contract-v1.md'),
            'source_pins_sha256':sha(pins_file),
            'temporary_storage_contract_sha256':sha(W/'tmp-contract-v2.json'),
            'registry_input_inventory_sha256':sha(W/'registry-inputs-v1.json.gz'),
            'registry_mounts_read_only':True,'cargo_bookkeeping_private':True,
            'source_overlays':{},
            'source_root':str(O),'target':str(self.target),
            'actual_main_source_without_overlays':True,'tmp_allowance_gib':32,'disk_b_allowance_gib':72,
            'frozen_copy_policy':'Hash each copy when created and each executed binary before/after use. All frozen outputs are mounted read-only for every command; verify all physical hashes at closure.',
            'inherited_frozen_copies':list(self.states)})
    def verify(self):
        assert all(sha(O/p)==h for p,h in self.pins.items())
        assert all(file_state(p)==st for p,st in self.states.items())
        stops=reasons(resources())
        if stops:raise RuntimeError(stops)
    def execute(self,label,args,*,binary=False,limit=1800,allow_failure=False):
        self.verify();name='owned-fold-'+self.phase+'-'+label
        scratch=U/'scratch'/name;assert not scratch.exists();scratch.mkdir()
        argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(U),str(U),'--ro-bind',str(U/'frozen'),str(U/'frozen'),'--chdir',str(scratch if binary else O)]
        for kind in ['index','cache','src']:
            argv+=['--ro-bind',str(V/'cargo-home-v1/registry'/kind),str(U/'cargo-home/registry'/kind)]
        if binary:
            for dest,src in self.runtime_bindings.items():argv+=['--ro-bind',str(src),str(dest)]
        for key,value in {
            'CARGO_HOME':str(U/'cargo-home'),'CARGO_TARGET_DIR':str(self.target),
            'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(U/'xdg-cache'),
            'GMP_MPFR_SYS_CACHE':str(U/'gmp-cache'),'CARGO_BUILD_JOBS':'2',
            'CARGO_INCREMENTAL':'0','CARGO_NET_OFFLINE':'true',
            'CARGO_CACHE_AUTO_CLEAN_FREQUENCY':'never',
        }.items():argv+=['--setenv',key,value]
        try:r=run(name,argv+list(map(str,args)),O,target=self.target,wall_seconds=limit)
        except RuntimeError:
            r=json.loads((N/'logs'/name/'result.json').read_text())
            self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands)
            if r['stops'] or not allow_failure or r['exit_code']!=101:raise
        self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands);self.verify()
        out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
        assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M),err[-3000:]
        return out,err,r
    def build(self,label,args):
        out,_,_=self.execute(label,[cargo]+args+['--no-run','--message-format=json'])
        found=[]
        for line in out.splitlines():
            if not line.startswith('{'):continue
            item=json.loads(line)
            if item.get('reason')!='compiler-artifact' or not item.get('executable'):continue
            name=item['target']['name']+'-'+item['target']['kind'][0]+('-tests' if item['profile']['test'] else '-program')
            key=label+'--'+name;assert key not in self.artifacts
            p=Path(item['executable']);copy=self.A/key;assert not copy.exists()
            needed=((p.stat().st_size+4095)//4096)*4096+65536
            contract=json.loads((W/'tmp-contract-v2.json').read_text())
            assert resources()['tmp_free_bytes']-needed>=contract['minimum_post_allowance_free_bytes'],str(p)
            h=sha(p);shutil.copy2(p,copy);assert sha(copy)==sha(p)==h
            self.states[str(copy)]=file_state(copy)
            self.artifacts[key]={'copy':str(copy),'compiled_path':str(p),'sha256':h,'bytes':copy.stat().st_size,'features':item['features'],'target':item['target'],'profile':item['profile'],'cargo_fresh':item['fresh']}
            found.append(key)
        assert found
        dump(self.A/'executables-v1.json',self.artifacts);self.verify()
        return found
    def bind_programs(self,keys):
        self.runtime_bindings={item['compiled_path']:item['copy'] for key in keys if not (item:=self.artifacts[key])['profile']['test']}
    def test(self,label,key,filters=None,*,allow_failure=False,limit=1800):
        item=self.artifacts[key];assert sha(item['copy'])==item['sha256']
        out,err,r=self.execute(label,[item['copy']]+list(filters or [])+['--nocapture','--test-threads=1'],binary=True,allow_failure=allow_failure,limit=limit)
        assert sha(item['copy'])==item['sha256']
        return rows(out),out,err,r
