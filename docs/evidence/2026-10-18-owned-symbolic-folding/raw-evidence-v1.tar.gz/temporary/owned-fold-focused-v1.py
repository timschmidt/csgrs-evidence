"""Verify the minimal shared-certificate repair against the unchanged tests."""
import gzip,json,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/owned-fold-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v1 import Harness,O,sha,dump
changes={'crates/hyperreal/src/real/convert.rs','crates/hyperreal/src/real/arithmetic/classification.rs'}
assert set(subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O).decode().splitlines())==changes
pins=json.loads(gzip.decompress((W/'source-pins-v3.json.gz').read_bytes()))
assert all(p in changes or sha(O/p)==h for p,h in pins.items())
for p in changes:pins[p]=sha(O/p)
path=W/'source-pins-v4.json.gz';assert not path.exists();path.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
h=Harness('focused-v1',path)
keys=h.build('build',['test','--release','--locked','-p','hyperreal','--all-features','--test','serde_owned_folding'])
tests=[key for key in keys if h.artifacts[key]['profile']['test']];assert len(tests)==1
result,_,_,_=h.test('run',tests[0],limit=60)
assert result==[('ok','5','0','0','0','0')],result
dump(h.R/'result-v1.json',{'passed':True,'summary':result,'commands':h.commands,'source_pins_sha256':sha(path),'new_tests_unchanged_since_failing_baseline':True})
print(json.dumps({'focused_passed':True,'summary':result}),flush=True)
