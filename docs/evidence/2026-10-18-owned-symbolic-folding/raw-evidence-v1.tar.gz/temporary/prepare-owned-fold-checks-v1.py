"""Prepare final-source scalar, consumer and compiler-floor checks."""
import ast,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
N=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2')
OLD=N/'scalar-ingress-control-v1';W=N/'owned-fold-control-v1'
assert json.loads((N/'owned-fold-focused-v1/result-v1.json').read_text())['passed']
for name in ['scalar','consumers','msrv']:
    source=(OLD/(name+'_v1.py')).read_text()
    source=source.replace('cargo_harness_v2','cargo_harness_v1').replace('scalar-ingress-','owned-fold-').replace('csgrs-scalar-ingress-','csgrs-owned-fold-').replace('source-pins-v7','source-pins-v4')
    source=source.replace('retained lazy reconstruction','the owned-fold repair').replace('required-payload repair','owned-fold repair').replace('lazy_msrv_harness','owned_fold_msrv_harness')
    if name=='scalar':
        source=source.replace("'819'","'817'")
        source=source.replace("O/'crates/hyperreal/tests/serde_lazy_certificates.rs',O/'crates/hyperlimit/tests/lazy_scalar_certificates.rs'","O/'crates/hyperreal/tests/serde_owned_folding.rs'")
    elif name=='consumers':
        needle="feature_matrix={}"
        insertion="""curve_tests={}
for target,expected in [('hypercurve_svg',20),('svg_scalar_failures',1)]:
 keys=h.build(target+'-build',['test','--release','--locked','-p','hypercurve','--features','svg','--test',target])
 tests=[key for key in keys if h.artifacts[key]['profile']['test']]
 assert len(tests)==1
 result,_,_,_=h.test(target+'-run',tests[0])
 assert result==[('ok',str(expected),'0','0','0','0')],result
 curve_tests[target]=result
"""
        assert source.count(needle)==1;source=source.replace(needle,insertion+needle)
        source=source.replace("'feature_gate_matrix':feature_matrix,","'feature_gate_matrix':feature_matrix,'curve_tests':curve_tests,")
    ast.parse(source);p=W/(name+'_v1.py');assert not p.exists();p.write_text(source)
print('Prepared full scalar, predicate, SVG, circuit interchange and compiler-floor checks.',flush=True)
