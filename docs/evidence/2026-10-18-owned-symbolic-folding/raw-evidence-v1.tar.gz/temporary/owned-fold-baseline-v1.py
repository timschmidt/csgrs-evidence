"""Run the owned-fold regressions before any production edit."""
import gzip,json,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/owned-fold-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v1 import Harness,O,sha,dump
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
pins=json.loads(gzip.decompress((W/'source-pins-v1.json.gz').read_bytes()))
assert all(sha(O/p)==v for p,v in pins.items())
new='crates/hyperreal/tests/serde_owned_folding.rs';assert new not in pins;pins[new]=sha(O/new)
p=W/'source-pins-v2.json.gz';assert not p.exists();p.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
h=Harness('baseline-v1',p)
keys=h.build('build',['test','--release','--locked','-p','hyperreal','--all-features','--test','serde_owned_folding']);assert len(keys)==1
result,out,err,r=h.test('run',keys[0],allow_failure=True,limit=60)
assert result==[('FAILED','1','4','0','0','0')],result
dump(h.R/'result-v1.json',{'production_source_changed':False,'summary':result,'commands':h.commands,'helper_sha256':sha(Path(__file__)),'new_test_sha256':pins[new]})
print(json.dumps({'baseline':result,'production_unchanged':True}),flush=True)
