"""Stage and verify every closed E79 evidence blob; do not commit here."""
import gzip,hashlib,json,os,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';E=O/'docs/evidence/2026-10-18-lazy-scalar-investigation';BASE='0fa83aea7aae9d57a578da0cf28299f12ca75409'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def span(raw):
    start=re.search(rb'"current_work"\s*:\s*',raw).end();_,count=json.JSONDecoder().raw_decode(raw[start:].decode());return start,start+len(raw[start:].decode()[:count].encode())
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--cached','--name-only')
c=json.loads((E/'checkpoint-v1.json').read_text());assert not c['runtime_admitted'] and not c['new_implementation_admission'] and c['source_restored_to']==BASE and not c['full_plan_complete']
sys.path.insert(0,str(N/'scalar-ingress-control-v1'))
from validation_runner_v2 import resources,reasons
assert not reasons(resources())
physical=json.loads(gzip.decompress((E/'artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
assert len(physical)==c['new_physical_artifacts_verified'] and all(sha(path)==h for path,h in physical.items())
archive=json.loads(gzip.decompress((E/'archive-members-v1.json.gz').read_bytes()))
assert sha(E/'raw-evidence-v1.tar.gz')==archive['archive_sha256']
with tarfile.open(E/'raw-evidence-v1.tar.gz','r:gz') as tf:
    assert set(tf.getnames())==set(archive['members'])
    for name,entry in archive['members'].items():
        data=tf.extractfile(name).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
pinsfile=O/c['main_source_pins'];assert sha(pinsfile)==c['main_source_pins_sha256']
pins=json.loads(gzip.decompress(pinsfile.read_bytes()));assert len(pins)==2656 and all(sha(O/path)==h for path,h in pins.items())
assert all(sha(O/p)==h for p,h in c['inherited_implementation_sha256'].items())
assert all(sha(O/p)==h for p,h in c['evidence_files_sha256'].items())
assert sha(O/'docs/properties-status.json')==c['ledger_after_sha256']
raw=(O/'docs/properties-status.json').read_bytes();reference=git('show','9025de62:docs/properties-status.json');s,e=span(raw);rs,re_=span(reference);assert (raw[:s],raw[e:])==(reference[:rs],reference[re_:])
protected='docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py';assert sha(O/protected)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
evidence=set(c['evidence_files_sha256'])|{str((E/'checkpoint-v1.json').relative_to(O))};assert {str(p.relative_to(O)) for p in E.rglob('*') if p.is_file()}==evidence
paths=sorted(evidence|{'docs/properties-status.json'});expected={p:sha(O/p) for p in paths}
assert set(git('diff','--name-only').decode().splitlines())=={'docs/properties-status.json'}
subprocess.run(GIT+['add','--']+paths,cwd=O,check=True)
out=N/'lazy-scalar-final-stage-whitespace-v1.stdout';err=N/'lazy-scalar-final-stage-whitespace-v1.stderr';assert not out.exists() and not err.exists()
with out.open('wb') as stdout,err.open('wb') as stderr:r=subprocess.run(GIT+['diff','--cached','--check'],cwd=O,stdout=stdout,stderr=stderr)
assert r.returncode==0
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
staged={p:hashlib.sha256(git('show',':'+p)).hexdigest() for p in paths};assert staged==expected and all(sha(O/p)==h for p,h in expected.items())
assert not reasons(resources())
p=N/'lazy-scalar-final-stage-verification-v1.json';assert not p.exists();p.write_text(json.dumps({'parent_revision':BASE,'helper_sha256':sha(Path(__file__)),'staged_blobs_sha256':staged,'verified_blob_count':len(staged),'checkpoint_sha256':sha(E/'checkpoint-v1.json'),'only_current_work_ledger_value_changed':True,'whitespace_exit_code':0,'whitespace_outputs_sha256':{str(out):sha(out),str(err):sha(err)},'protected_untracked_unchanged':protected,'commit_not_executed_by_this_helper':True,'closed_physical_files_verified':len(physical),'archive_members_verified':len(archive['members']),'main_source_paths_verified':len(pins)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified_staged_blobs':len(staged),'parent':BASE,'receipt':str(p)}),flush=True)
