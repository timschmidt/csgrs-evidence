"""Prepare separate staging and postcommit verification for the narrow repair."""
import ast
from pathlib import Path
source=Path('/tmp/stage-lazy-scalar-investigation-v1.py').read_text()
source=source.replace('E79','owned-fold').replace('2026-10-18-lazy-scalar-investigation','2026-10-18-owned-symbolic-folding').replace('0fa83aea7aae9d57a578da0cf28299f12ca75409','39bdea5aed282e76d9639535e41d00ae9a2cec15').replace('scalar-ingress-control-v1','owned-fold-control-v1').replace('lazy-scalar-final-','owned-fold-final-')
old="assert not c['runtime_admitted'] and not c['new_implementation_admission'] and c['source_restored_to']==BASE and not c['full_plan_complete']"
new="assert c['runtime_admitted'] and c['new_implementation_admission'] and c['source_changes_applied'] and not c['full_plan_complete']"
assert old in source;source=source.replace(old,new).replace('len(pins)==2656','len(pins)==2657')
source=source.replace("paths=sorted(evidence|{'docs/properties-status.json'})","paths=sorted(set(c['implementation_sha256'])|evidence|{'docs/properties-status.json'})")
source=source.replace("assert set(git('diff','--name-only').decode().splitlines())=={'docs/properties-status.json'}","assert set(git('diff','--name-only').decode().splitlines())==({'docs/properties-status.json'}|set(c['implementation_sha256']))-{'crates/hyperreal/tests/serde_owned_folding.rs'}\nassert all(sha(O/p)==h for p,h in c['implementation_sha256'].items())")
ast.parse(source);p=Path('/tmp/stage-owned-fold-v1.py');assert not p.exists();p.write_text(source)
source=Path('/tmp/verify-lazy-scalar-commit-v1.py').read_text().replace('E79','owned-fold').replace('lazy-scalar-final-','owned-fold-final-')
ast.parse(source);p=Path('/tmp/verify-owned-fold-commit-v1.py');assert not p.exists();p.write_text(source)
print('Prepared separate staging and postcommit verifiers; neither has run.')
