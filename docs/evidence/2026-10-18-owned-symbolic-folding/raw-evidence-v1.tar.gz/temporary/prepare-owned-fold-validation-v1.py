"""Start a fresh owned-fold repair target under the unchanged storage baselines."""
import ast,gzip,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
OLD=N/'scalar-ingress-control-v1';W=N/'owned-fold-control-v1';U=Path('/tmp/csgrs-owned-fold-20261018-v1')
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(OLD))
from validation_runner_v2 import sha,resources,reasons
assert not reasons(resources())
receipt=json.loads((N/'lazy-scalar-final-commit-verification-v1.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=O).decode().strip();assert receipt['commit']==head
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
pins=json.loads(gzip.decompress((OLD/'source-pins-v1.json.gz').read_bytes()))
assert len(pins)==2656 and all(sha(O/p)==h for p,h in pins.items())
assert not W.exists() and not U.exists();W.mkdir();U.mkdir()
for name in ['target','cargo-home','gmp-cache','xdg-cache','scratch','frozen','probes']:(U/name).mkdir()
for name in ['index','cache','src']:(U/'cargo-home/registry'/name).mkdir(parents=True,exist_ok=True)
(U/'cargo-home/config.toml').write_text('[net]\noffline = true\n[cache]\nauto-clean-frequency = "never"\n')
for name in ['tmp-contract-v1.json','tmp-contract-v2.json','validation_runner_v1.py','validation_runner_v2.py','registry-inputs-v1.json.gz','source-pins-v1.json.gz']:
    shutil.copy2(OLD/name,W/name);assert sha(OLD/name)==sha(W/name)
text=(OLD/'cargo_harness_v2.py').read_text().replace('Scalar ingress diagnostic and acceptance checks.','Owned symbolic folding acceptance checks.')
text=text.replace('/tmp/csgrs-scalar-ingress-20261018-v1',str(U)).replace("'scalar-ingress-'","'owned-fold-'").replace("'lazy-contract-v1.md'","'contract-v1.md'")
ast.parse(text);(W/'cargo_harness_v1.py').write_text(text)
(W/'contract-v1.md').write_text('''# Owned folding preserves the symbolic value

Owner: Hyperreal Real::fold in real/convert.rs. Properties P1, P2, P3,
P6, P18, P26 and P35-P39. The parent is recorded in preparation-v1.json.
The committed library produces e instead of exp(pi), and asinh(1) instead
of asinh(pi), when it directly consumes a valid lazy serialized Pi.

Domain: valid named Class certificates constructed by public APIs, with
null or omitted Computable payloads and zero, unit and negative nonunit
outer scales. Irrational still requires a payload. Existing Some graphs
must remain authoritative and movable, with their cancellation signal.

Use Class::computable_certificate, already used by borrowed folding, for
the two missing-payload branches of owned folding. Share that implementation
without duplicating formulas, changing layout/cache ownership or eagerly
rewriting serialized fields. This does not admit arbitrary forged tags or
undefined graphs, or claim that every other lazy query is repaired.

Missing regression: consume the decoded value directly; cloning can
materialize it and hide the bug. Cover all 21 public named-certificate
recipes through JSON and CBOR, null and omission, scales 0/1/-3. For
exp followed by ln require independent strict rational bounds of the
original value, with an exact zero check. Include materialized controls
and independent forward exp/asinh bounds for Pi at unit and nonunit
scales. Those forward checks guard against paired inverse mistakes.
Serialization checks and tag coverage are separate from semantic checks.
Run the tests on unchanged production before editing it.

After the final edit run full scalar default/all-feature tests and docs,
debug units, strict Clippy, formatting, the complete predicate suite,
curve SVG consumers and circuit interchange targets. Check affected crates
at their declared compiler floor. Preserve all old hard cases, policy and
fixture sizes. A narrow successful repair does not close the rejected
lazy-cache experiment or the invalid-domain/certificate findings.

No performance gain is claimed. Existing stored graphs move unchanged;
the missing graph uses the established certificate constructor. Its work
has no new internal total-work bound. External containment remains root
16 GiB, Disk B 72 GiB, tmp 32 GiB, cumulative logs 96 MiB, 8 GiB child
address space, two jobs, focused 60 seconds and build/full suite 1800
seconds. Original baselines remain unchanged. The inherited tmp contract
names the preceding target; its capacity applies cumulatively to all tmp
artifacts, including this new target. Registry mounts are read-only;
Cargo bookkeeping and builds are private. Preserve every closed artifact.
Hypervoxel is excluded. No push or complete release claim.
''')
registry=json.loads(gzip.decompress((W/'registry-inputs-v1.json.gz').read_bytes()))
assert len(registry)==48478 and all(sha(p)==h for p,h in registry.items())
gmp={}
for p in sorted((V/'gmp-cache-v1').rglob('*')):
    assert not p.is_symlink();dest=U/'gmp-cache'/p.relative_to(V/'gmp-cache-v1')
    if p.is_dir():dest.mkdir(exist_ok=True)
    elif p.is_file():
        digest=sha(p);shutil.copy2(p,dest);assert sha(dest)==sha(p)==digest;gmp[str(p)]={'copy':str(dest),'sha256':digest}
(W/'native-cache-copy-v1.json').write_text(json.dumps(gmp,indent=2,sort_keys=True)+'\n')
(W/'preparation-v1.json').write_text(json.dumps({'parent_revision':head,'helper_sha256':sha(Path(__file__)),'source_pins_sha256':sha(W/'source-pins-v1.json.gz'),'registry_physical_inputs_verified':len(registry),'contract_sha256':sha(W/'contract-v1.md'),'temporary_contract_sha256':sha(W/'tmp-contract-v2.json'),'resources':resources(),'target_initially_empty':not any((U/'target').iterdir()),'storage_baselines_reset':False},indent=2,sort_keys=True)+'\n')
print(json.dumps({'prepared':str(W),'parent':head,'resources':resources()}),flush=True)
