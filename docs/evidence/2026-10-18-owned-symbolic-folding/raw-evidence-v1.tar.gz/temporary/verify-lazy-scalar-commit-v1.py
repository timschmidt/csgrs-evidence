"""Verify the separate E79 commit against the staged receipt."""
import hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(GIT+list(args),cwd=O)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'lazy-scalar-final-stage-verification-v1.json').read_text());head=git('rev-parse','HEAD').decode().strip()
assert git('rev-parse','HEAD^').decode().strip()==r['parent_revision']
expected=r['staged_blobs_sha256'];assert all(hashlib.sha256(git('show','HEAD:'+p)).hexdigest()==h and sha(O/p)==h for p,h in expected.items())
assert set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(expected)
assert not git('diff','HEAD','--name-only')
protected=r['protected_untracked_unchanged'];assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())=={protected}
assert sha(O/protected)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
p=N/'lazy-scalar-final-commit-verification-v1.json';assert not p.exists();p.write_text(json.dumps({'commit':head,'parent_revision':r['parent_revision'],'verified_blob_count':len(expected),'verified_committed_blobs_sha256':expected,'helper_sha256':sha(Path(__file__)),'worktree_task_clean':True,'protected_untracked_unchanged':protected},indent=2,sort_keys=True)+'\n')
print(json.dumps({'commit':head,'verified_committed_blobs':len(expected),'worktree_task_clean':True}),flush=True)
