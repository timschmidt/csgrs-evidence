"""Select the test artifact explicitly; retain the initial setup failure."""
import gzip,json,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/owned-fold-control-v1')
sys.path.insert(0,str(W))
from cargo_harness_v1 import Harness,O,U,sha,dump
assert not subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=O)
pins=json.loads(gzip.decompress((W/'source-pins-v1.json.gz').read_bytes()))
assert all(sha(O/p)==v for p,v in pins.items())
new='crates/hyperreal/tests/serde_owned_folding.rs';pins[new]=sha(O/new)
p=W/'source-pins-v3.json.gz';assert not p.exists();p.write_bytes(gzip.compress((json.dumps(pins,sort_keys=True)+'\n').encode(),mtime=0))
dump(W/'baseline-preparation-v2.json',{'initial_build_passed':True,'initial_helper_stopped_before_running_tests':'Cargo also reports an executable program; the helper incorrectly required one artifact total. Select the test artifact by its Cargo profile instead.','strengthened_ln_product_bound':'0 < ln(2)*ln(3) < 1, from ln(2)<3/4 and ln(3)<5/4. The earlier weaker bound 0..2 is preserved. Production is unchanged.','previous_test_sha256':sha(U/'probes/serde_owned_folding-baseline-v1.rs'),'new_test_sha256':pins[new]})
h=Harness('baseline-v2',p)
keys=h.build('build',['test','--release','--locked','-p','hyperreal','--all-features','--test','serde_owned_folding'])
tests=[key for key in keys if h.artifacts[key]['profile']['test']];assert len(tests)==1
result,out,err,r=h.test('run',tests[0],allow_failure=True,limit=60)
assert result==[('FAILED','1','4','0','0','0')],result
dump(h.R/'result-v1.json',{'production_source_changed':False,'summary':result,'commands':h.commands,'helper_sha256':sha(Path(__file__)),'new_test_sha256':pins[new]})
print(json.dumps({'baseline':result,'production_unchanged':True}),flush=True)
