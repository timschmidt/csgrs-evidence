#!/usr/bin/env bash
set -euo pipefail
s=/dev/shm/interval-jacobian-memory
cd "$s/fixed"
for variant in slot existing; do
 git restore -- crates/hypersolve/src/{eval,jacobian}.rs
 git apply "$s/entry.patch"
 git show 89b58eb57:crates/hypersolve/src/jacobian_tests.rs >crates/hypersolve/src/jacobian_tests.rs
 python3 -B "$s/slot.py" "$variant"
 git diff -- crates/hypersolve/src/{eval,jacobian}.rs >"$s/$variant.patch"
 "$s/build.sh" "$variant"
done
