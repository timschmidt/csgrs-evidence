from pathlib import Path
p=Path('crates/hypersolve/src/jacobian.rs');a=p.read_text()
start=a.index('    let baseline = crate::eval::evaluate_residuals')
end=a.index('    let mut jacobian',start)
a=a[:start]+'    let baseline = dense_residuals(problem, context)?;\n'+a[end:]
start=a.index('        let next = crate::eval::evaluate_residuals')
end=a.index('        for (row,',start)
a=a[:start]+'        let next = dense_residuals(problem, &perturbed)?;\n'+a[end:]
i=a.index('pub fn symbolic_jacobian(')
a=a[:i]+'''fn dense_residuals(problem: &Problem, context: &EvaluationContext) -> Result<Vec<f64>, EvalError> {
    Ok(crate::eval::evaluate_residuals(problem, context)?
        .into_iter()
        .filter_map(|row| row.weighted_dense_solver_estimate)
        .collect())
}

'''+a[i:]
p.write_text(a)
