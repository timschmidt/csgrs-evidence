from concurrent.futures import ThreadPoolExecutor
from itertools import product
from pathlib import Path
import json,struct,subprocess
s=Path(__file__).resolve().parent
def check(case):
    label,x,y,h,fixed,col,delta=case
    center=x; authored=x+delta if label in ('borrowed','documented') else x
    if label=='documented': authored=x
    n=2*x+h+3*y if col==0 else 3*x-2*y-h
    value=0.0 if col==1 and fixed else float(n*h)/h
    expected=struct.pack('>d',value).hex()
    actual=subprocess.check_output([s/'images'/(label+'-portable'),*map(str,[authored,center,y,h,fixed,col])],text=True).strip()
    assert actual==expected,(case,actual,expected)
cases=list(product(['fixed','previous','borrowed','documented'],range(-3,4),range(-3,4),[-2,-1,1,2],[0,1],[0,1],[0,5]))
with ThreadPoolExecutor(max_workers=8) as ex: list(ex.map(check,cases))
print(len(cases),'matrix entries across four native revisions')
for label,expected in [('fixed',-5),('previous',-5),('borrowed',7),('documented',-5)]:
    actual=subprocess.check_output([s/'images'/(label+'-portable'),'1','3','0','1','0','0'],text=True).strip()
    assert actual==struct.pack('>d',expected).hex()
    print(label,'public rebound x²',expected)
