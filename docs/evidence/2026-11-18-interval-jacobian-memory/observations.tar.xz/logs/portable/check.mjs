import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const [file,mode]=process.argv.slice(2);
assert.ok(['reference','rebound'].includes(mode));
const m=await WebAssembly.compile(await readFile(file));
assert.deepEqual(WebAssembly.Module.imports(m), []);
const cases=[];
for(let x=-3;x<=3;x++) for(let y=-3;y<=3;y++)
  for(const h of [-2,-1,1,2]) for(const fixed of [0,1]) for(const col of [0,1]) for(const delta of [0,5])
    cases.push([x,y,h,fixed,col,delta]);
for (const order of [cases,[...cases].reverse()]) {
 const {exports:{proposal}}=await WebAssembly.instantiate(m);
 for(const [x,y,h,fixed,col,delta] of order) {
  const authored=mode==='reference'?x:x+delta;
  const dx=2*x+h+3*y, dy=3*x-2*y-h;
  const want=col && fixed ? 0 : ((col?dy:dx)===0?0:(col?dy:dx)*h)/h;
  assert.equal(proposal(authored,x,y,h,fixed,col),want,JSON.stringify([authored,x,y,h,fixed,col]));
 }
}
console.log(mode,cases.length,'entries checked per fresh instance; two instances');
