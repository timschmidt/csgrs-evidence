fn main() {
    let a:Vec<i32>=std::env::args().skip(1).map(|s|s.parse().unwrap()).collect();
    println!("{:016x}",jacobian_proposal_client::proposal(a[0],a[1],a[2],a[3],a[4],a[5]).to_bits());
}
