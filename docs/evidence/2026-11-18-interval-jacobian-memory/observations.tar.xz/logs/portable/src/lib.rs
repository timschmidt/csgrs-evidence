use hyperreal::Real;
use hypersolve::{Constraint, EvaluationContext, Expr, Problem, SymbolId};
use hypersolve::jacobian::{FiniteDifferenceConfig,finite_difference_jacobian};

// x² + 3xy - y², signed integer step, independently supplied model/context
// coordinates and fixed-y switch. The caller requests one complete matrix entry.
#[unsafe(no_mangle)]
pub extern "C" fn proposal(authored: i32, center: i32, y: i32, step: i32, fixed: i32, column: i32) -> f64 {
    let mut p=Problem::default();
    p.add_variable("x", Real::from(authored));
    p.add_variable("y", Real::from(if fixed!=0 {y+3} else {y}));
    p.variables[1].fixed=fixed!=0;
    let x=Expr::symbol(SymbolId(0),"x"); let sy=Expr::symbol(SymbolId(1),"y");
    p.add_constraint(Constraint::equality("mixed",x.clone().powi(2)+Expr::int(3)*x*sy.clone()-sy.powi(2)));
    let mut ctx=EvaluationContext::default();
    ctx.bind(SymbolId(0),Real::from(center)); ctx.bind(SymbolId(1),Real::from(y));
    let m=finite_difference_jacobian(&p,&ctx,FiniteDifferenceConfig{step:Real::from(step)}).unwrap();
    m[0][column as usize]
}
