mod allocation;
use hyperreal::Real;
use hypersolve::jacobian::{FiniteDifferenceConfig, finite_difference_jacobian};
use hypersolve::{
    Constraint, ConstraintKind, EvaluationContext, Expr, Problem, SymbolId, context_from_problem,
};
use std::ffi::c_void;

unsafe extern "C" {
    fn measure_stack(
        callback: unsafe extern "C" fn(*mut c_void),
        context: *mut c_void,
        warm: i32,
        pattern: u8,
    ) -> usize;
}

fn fixture(case: usize, synchronized: bool) -> (Problem, EvaluationContext, Real, Vec<Vec<f64>>) {
    let mut p = Problem::default();
    let x = Expr::symbol(SymbolId(0), "x");
    let mut step = Real::one();
    let expected = match case {
        0 | 1 => {
            let center = if case == 0 { 1 } else { -3 };
            p.add_variable("x", Real::from(center));
            p.add_constraint(Constraint::equality("square", x.powi(2)));
            vec![vec![f64::from(2 * center + 1)]]
        }
        2 => {
            p.add_variable("x", Real::one());
            p.add_variable("y", Real::from(2));
            let y = Expr::symbol(SymbolId(1), "y");
            p.add_constraint(Constraint::equality(
                "mixed",
                x.clone().powi(2) + y.clone().powi(2) + x * y,
            ));
            vec![vec![5.0, 6.0]]
        }
        3 => {
            p.add_variable("x", Real::one());
            p.add_variable("fixed", Real::from(2));
            p.variables[1].fixed = true;
            p.add_variable("unused", Real::from(4));
            let mut row = Constraint::equality(
                "weighted",
                x.clone().powi(2) + Expr::symbol(SymbolId(1), "fixed"),
            );
            row.weight = Real::from(2);
            p.add_constraint(row);
            let mut inactive = Constraint::equality("inactive", x);
            inactive.active = false;
            p.add_constraint(inactive);
            vec![vec![6.0, 0.0, 0.0]]
        }
        4 => {
            p.add_variable("unused", Real::one());
            vec![]
        }
        5 => {
            p.add_variable("x", Real::from(2));
            p.add_constraint(Constraint::equality(
                "linear",
                Expr::int(3) * x + Expr::int(1),
            ));
            vec![vec![3.0]]
        }
        6 | 7 => {
            p.add_variable("x", Real::one());
            let mut row = Constraint::equality("hinge", x - Expr::int(2));
            row.kind = if case == 6 {
                ConstraintKind::LessOrEqual
            } else {
                ConstraintKind::GreaterOrEqual
            };
            p.add_constraint(row);
            if case == 6 {
                step = Real::from(2);
            }
            vec![vec![if case == 6 { 0.5 } else { -1.0 }]]
        }
        8..=10 => {
            let center = if case == 8 { 3 } else { -7 };
            p.add_variable("x", Real::from(if synchronized { center } else { 1 }));
            p.add_constraint(Constraint::equality("rebound square", x.powi(2)));
            let h = if case == 10 { -2 } else { 1 };
            step = Real::from(h);
            vec![vec![f64::from(2 * center + h)]]
        }
        11 => {
            // A dense 8 x 8 proposal. Row j is (j+1)*sum(x_i²); h = 1.
            let mut sum = Expr::int(0);
            for i in 0..8 {
                let name = format!("x{i}");
                p.add_variable(&name, Real::from(i - 4));
                sum = sum + Expr::symbol(SymbolId(i as u32), &name).powi(2);
            }
            for j in 1..=8 {
                p.add_constraint(Constraint::equality(format!("row{j}"), Expr::int(j) * sum.clone()));
            }
            (1..=8).map(|j| (0..8).map(|i| f64::from(j * (2 * (i - 4) + 1))).collect()).collect()
        }
        _ => panic!("case"),
    };
    let context = if case == 3 {
        let mut context = EvaluationContext::default();
        context.bind(SymbolId(0), Real::one());
        context.bind(SymbolId(1), Real::from(2));
        context
    } else {
        context_from_problem(&p)
    };
    let mut context = context;
    if (8..=10).contains(&case) {
        context.bind(SymbolId(0), Real::from(if case == 8 { 3 } else { -7 }));
    }
    (p, context, step, expected)
}

fn bits(matrix: &[Vec<f64>]) -> Vec<Vec<u64>> {
    matrix
        .iter()
        .map(|row| row.iter().map(|value| value.to_bits()).collect())
        .collect()
}

struct Context {
    problem: Problem,
    values: EvaluationContext,
    step: Real,
    expected: Vec<Vec<f64>>,
}

unsafe extern "C" fn callback(opaque: *mut c_void) {
    let c = unsafe { &mut *opaque.cast::<Context>() };
    let result = finite_difference_jacobian(
            &c.problem,
            &c.values,
            FiniteDifferenceConfig {
                step: c.step.clone(),
            },
        )
        .unwrap();
    assert_eq!(result.len(), c.expected.len());
    for (row, wanted) in result.iter().zip(&c.expected) {
        assert_eq!(row.len(), wanted.len());
        for (x, y) in row.iter().zip(wanted) { assert_eq!(x.to_bits(), y.to_bits()); }
    }
    drop(std::hint::black_box(result));
}

fn main() {
    let args: Vec<_> = std::env::args().skip(1).collect();
    assert_eq!(args.len(), 4);
    let case: usize = args[0].parse().unwrap();
    let mode = args[1].as_str();
    let warm: i32 = args[2].parse().unwrap();
    assert!((0..=1).contains(&warm));
    let pattern: u8 = args[3].parse().unwrap();
    let (problem, values, step, expected) = fixture(case, std::env::var_os("SYNCHRONIZED_REFERENCE").is_some());
    if mode == "stack" {
        let mut c = Context {
            problem,
            values,
            step,
            expected,
        };
        let stack =
            unsafe { measure_stack(callback, (&mut c as *mut Context).cast(), warm, pattern) };
        println!("STACK {case} {warm} {pattern} {stack} {:?}", bits(&c.expected));
    } else {

        let run = || {
            finite_difference_jacobian(
                &problem,
                &values,
                FiniteDifferenceConfig { step: step.clone() },
            )
            .unwrap()
        };
        if mode == "time" {
            let repeats: u32 = if case == 11 { 140 } else { 16000 };
            for _ in 0..8 { drop(std::hint::black_box(run())); }
            let start = std::time::Instant::now();
            for _ in 0..repeats { drop(std::hint::black_box(run())); }
            let elapsed = start.elapsed().as_nanos();
            assert_eq!(bits(&run()), bits(&expected));
            println!("TIME {case} {repeats} {elapsed}");
            return;
        }
        assert_eq!(mode, "observe");
        if warm != 0 {
            for _ in 0..8 {
                drop(std::hint::black_box(run()));
            }
        }
        let (output, measured) = allocation::observe(run);
        assert_eq!(bits(&output), bits(&expected));
        println!("OUTPUT {case} {warm} {:?}", bits(&output));
        println!("ALLOCATION {case} {warm} {:?}", measured.values());
        let (_, cleanup) = allocation::observe(|| drop(output));
        println!("CLEANUP {case} {warm} {:?}", cleanup.values());
        #[cfg(feature = "trace")]
        {
            hyperreal::dispatch_trace::reset();
            let output = hyperreal::dispatch_trace::with_recording(run);
            let trace = hyperreal::dispatch_trace::take_trace();
            assert_eq!(trace.layer_count("hyperlimit"), 0);
            assert_eq!(bits(&output), bits(&expected));
            println!("TRACE {case} {warm} {trace:?}");
        }
    }
}
