from pathlib import Path
import subprocess
s=Path(__file__).resolve().parent
repo=s/'csgrs'
path=repo/'crates/hypersolve/src/jacobian.rs'
observed=path.read_bytes()
original=subprocess.check_output(['git','-C',repo,'show','HEAD:crates/hypersolve/src/jacobian.rs']).decode()
def run(label):
 p=subprocess.run(['cargo','+1.95.0','test','--locked','-p','hypersolve','--test','finite_difference_proposals'],cwd=repo,capture_output=True,text=True)
 (s/'logs'/('grid-'+label)).write_text(p.stdout+p.stderr)
 return p
try:
 path.write_text(original)
 assert run('control').returncode==0
 for label,old,new,fails in [
 ('authored-context','    let step_estimate =','    let _ = context;\n    let context = &crate::eval::context_from_problem(problem);\n    let step_estimate =',2),
 ('signed-zero','(next - base) / step_estimate;', '{ let v = (next - base) / step_estimate; if v == 0.0 { 0.0 } else { v } };',1),
 ('fixed-column','if variable.fixed {','if false && variable.fixed {',1)]:
    assert original.count(old)==1
    path.write_text(original.replace(old,new))
    p=run(label)
    assert p.returncode==101 and f'{fails} failed;' in p.stdout,(label,p.stdout[-1000:],p.stderr[-500:])
    print(label,'rejected',fails,flush=True)
finally: path.write_bytes(observed)
