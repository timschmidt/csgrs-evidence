from pathlib import Path
import hashlib,importlib.util,json,sys
s=Path(__file__).resolve().parent
sys.path.insert(0,str(s))
from image_metrics import sizes
def wasm(path):
    data=path.read_bytes()
    assert data[:8]==b'\0asm\1\0\0\0'
    i=8; code=None
    while i<len(data):
        section=data[i];i+=1;n=0;shift=0
        while True:
            b=data[i];i+=1;n|=(b&127)<<shift
            if b<128:break
            shift+=7
        if section==10:code=n
        i+=n
    assert i==len(data) and code
    return dict(file=len(data),code=code)
caps=json.loads((s/'caps.json').read_text())
result={}
for key in ['portable','wasm','default','trace']:
    entries={}
    for label in ['fixed','previous','borrowed']:
        p=s/'images'/(label+'.wasm' if key=='wasm' else label+'-'+key)
        entries[label]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'sizes':wasm(p) if key=='wasm' else sizes(p)}
    rows=[]
    f,b,a=[entries[l]['sizes'] for l in ('fixed','previous','borrowed')]
    for metric in sorted(set(f)|set(b)|set(a)):
        v,w,x=f.get(metric,0),b.get(metric,0),a.get(metric,0)
        k='wasm_final_file_and_code' if key=='wasm' else 'native_monomorphized_text_sum' if metric=='function_union' else 'native_final_file_and_allocated_sections'
        cap=caps[k];inc=max(0,x-w);charge=max(0,w-v)+inc
        ok=inc<=cap['incremental_bytes'] and 100*inc<=w*cap['incremental_percent'] and charge<=cap['cumulative_bytes'] and 100*charge<=v*cap['cumulative_percent']
        rows.append(dict(metric=metric,fixed=v,previous=w,candidate=x,incremental=inc,cumulative=charge,passes=ok))
    result[key]=dict(images=entries,accounts=rows)
    print(key,'failed',[(r['metric'],r['incremental'],r['cumulative']) for r in rows if not r['passes']])
(s/'final-sizes.json').write_text(json.dumps(result,indent=2)+'\n')
