from pathlib import Path
import json,sys,itertools
s=Path(__file__).resolve().parent
names=('fixed','previous',sys.argv[1])
data=[json.loads((s/(n+'-raw.json')).read_text()) for n in names]
get=lambda rows,f,c,w,m:[r for r in rows if (r['features'],r['case'],r['warm'],r['mode'])==(f,c,w,m)]
result=[]
for f,c,w in itertools.product(('default','trace'),range(12),range(2)):
    stack=[get(d,f,c,w,'stack') for d in data]
    obs=[get(d,f,c,w,'observe') for d in data]
    assert all(len(g)==8 for g in stack) and all(len(g)==4 for g in obs)
    assert all(r['output']==obs[1][0]['output'] for groups in [stack,obs] for g in groups for r in g)
    if f=='trace':
        assert all(r['trace']==obs[1][0]['trace'] for g in obs[1:] for r in g),(c,w)
    peaks=[max(r['stack'] for r in g) for g in stack]
    heaps=[max(r['allocation'][4] for r in g) for g in obs]
    live=[max(r['allocation'][5] for r in g) for g in obs]
    post=[max(r['allocation'][5]+r['cleanup'][5] for r in g) for g in obs]
    growth=max(0,peaks[2]-peaks[1])
    cumulative=max(0,peaks[1]-peaks[0])+growth
    issues=[]
    if growth>min(128,peaks[1]//100): issues.append('incremental stack')
    if cumulative>min(256,peaks[0]*2//100): issues.append('cumulative stack')
    for key,vals in [('peak requested',heaps),('returned requested',live),('after drop',post)]:
        if max(0,vals[2]-vals[1])+max(0,vals[1]-vals[0]): issues.append(key)
    result.append(dict(features=f,case=c,warm=w,stack=peaks,previous_charge=max(0,peaks[1]-peaks[0]),incremental=growth,cumulative=cumulative,headroom=min(r['free'] for r in stack[2]),requested_peak=heaps,requested_after_return=live,requested_after_drop=post,events_match=all(a['allocation']==b['allocation'] and a['cleanup']==b['cleanup'] for a,b in zip(obs[1],obs[2])),issues=issues))
(s/(names[2]+'-comparison.json')).write_text(json.dumps(result,indent=2)+'\n')
print(names[2], 'groups',len(result),'failed',sum(bool(r['issues']) for r in result),'max incremental',max(r['incremental'] for r in result),'max cumulative',max(r['cumulative'] for r in result),'max stack',max(r['stack'][-1] for r in result),'min headroom',min(r['headroom'] for r in result))
for r in result:
    if r['issues'] and not r['warm']:print(r['features'],r['case'],r['issues'],r['stack'],r['requested_peak'])
