import json,statistics,random
from pathlib import Path
s=Path(__file__).resolve().parent
files=sorted(s.glob('borrowed-24-3-4-5-8-cpu*.json'));assert len(files)==3
out=[]
for f in files:
 data=json.loads(f.read_text())
 for feature in ('default','trace'):
  for case in (3,4,5,8):
   v=[r for r in data if r['features']==feature and r['case']==case];assert len(v)==24
   ratios=[r['ns']['borrowed']/r['ns']['previous'] for r in v]
   rng=random.Random(1901);res=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(4000))
   out.append(dict(cpu=v[0]['cpu'],feature=feature,case=case,pairs=24,previous_ns=statistics.median(r['ns']['previous'] for r in v),borrowed_ns=statistics.median(r['ns']['borrowed'] for r in v),pair_median=statistics.median(ratios),bootstrap95=[res[99],res[3899]]))
(s/'timing-confirmed.json').write_text(json.dumps(out,indent=2)+'\n')
for r in out:
 if r['case']==3:print(r['cpu'],r['feature'],'paired median %.2f%%, interval [%.2f, %.2f]%%' % tuple(100*(v-1) for v in [r['pair_median'],*r['bootstrap95']]))
