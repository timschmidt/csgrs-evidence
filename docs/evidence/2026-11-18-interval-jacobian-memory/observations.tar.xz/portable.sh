#!/usr/bin/env bash
set -euo pipefail
s=/dev/shm/interval-jacobian-memory
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/portable-target" CARGO_BUILD_JOBS=9
cd "$s/fixed"
git restore -- crates/hypersolve/src/{eval,jacobian}.rs
rm -f -- crates/hypersolve/src/jacobian_tests.rs
cd "$s/portable"
cp "$s/client/Cargo.lock" Cargo.lock
sed -i 's/name = "jacobian-context-resource-probe"/name = "jacobian-proposal-client"/' Cargo.lock
for label in fixed previous borrowed; do
 if [[ "$label" == fixed ]]; then git -C "$s/fixed" switch --quiet --detach c9f1f9ac5
 elif [[ "$label" == previous ]]; then git -C "$s/fixed" switch --quiet --detach 29e2bfdf3
 else git -C "$s/fixed" apply "$s/borrowed.patch"; git -C "$s/fixed" show 9e88db0ca:crates/hypersolve/src/jacobian_tests.rs >"$s/fixed/crates/hypersolve/src/jacobian_tests.rs"; fi
 cargo +1.95.0 build --release --locked --bin jacobian-proposal-client > "$s/logs/portable-$label-native-build" 2>&1
 cp "$CARGO_TARGET_DIR/release/jacobian-proposal-client" "$s/images/$label-portable"
 cargo +1.95.0 build --release --locked --lib --target wasm32-unknown-unknown > "$s/logs/portable-$label-wasm-build" 2>&1
 cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/jacobian_proposal_client.wasm" "$s/images/$label.wasm"
 node check.mjs "$s/images/$label.wasm" reference > "$s/logs/portable-$label-wasm-reference"
 if [[ "$label" == borrowed ]]; then node check.mjs "$s/images/$label.wasm" rebound > "$s/logs/portable-$label-wasm-rebound"; else
  if node check.mjs "$s/images/$label.wasm" rebound > "$s/logs/portable-$label-wasm-red" 2>&1; then exit 1; fi
  rg -q 'AssertionError' "$s/logs/portable-$label-wasm-red"
 fi
done
