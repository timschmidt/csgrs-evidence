#!/usr/bin/env bash
set -euo pipefail
s=/dev/shm/interval-jacobian-memory
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/build" CARGO_BUILD_JOBS=12
for mode in default trace; do
 args=()
 if [[ "$mode" == trace ]]; then args+=(--features trace); fi
 cargo +1.95.0 build --manifest-path "$s/client/Cargo.toml" --locked --release "${args[@]}" >"$s/logs/build-$1-$mode" 2>&1
 cp "$CARGO_TARGET_DIR/release/jacobian-context-resource-probe" "$s/images/$1-$mode"
done
