import ast,hashlib,json,os,re,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
from itertools import product
from pathlib import Path

s=Path(__file__).resolve().parent
label=sys.argv[1]
def run(entry):
    features,case,warm,rep,mode,pattern=entry
    env=os.environ.copy()
    if label in ('fixed','previous') and 8<=case<=10: env['SYNCHRONIZED_REFERENCE']='1'
    image=s/'images'/f'{label}-{features}'
    p=subprocess.run([image,str(case),mode,str(warm),str(pattern)],env=env,capture_output=True,text=True,timeout=60)
    if p.returncode: raise RuntimeError((entry,p.stdout,p.stderr))
    row=dict(features=features,case=case,warm=warm,rep=rep,mode=mode,pattern=pattern)
    if mode=='stack':
        limits=tuple(map(int,re.search(r'HEADROOM (\d+) (\d+) (\d+) (\d+) (\d+)',p.stderr).groups()))
        assert sum(limits[1:])==limits[0] and 0<limits[3]<=16384 and limits[4]>=1048576,(entry,limits)
        row.update(boundary=limits[2],stack=limits[3],free=limits[4],output=p.stdout.split(' ',5)[5].strip())
    else:
        for line in p.stdout.splitlines():
            name,_,_,value=line.split(' ',3)
            row[name.lower()]=ast.literal_eval(value) if name in ('ALLOCATION','CLEANUP') else value
        assert row['allocation'][4]<=(262144 if case==11 else 16384)
    return row

entries=[(f,c,w,r,m,p) for f,c,w,r in product(('default','trace'),range(12),range(2),range(4)) for m,p in [('stack',165),('stack',90),('observe',165)]]
with ThreadPoolExecutor(max_workers=6) as pool: records=list(pool.map(run,entries))
(s/(label+'-raw.json')).write_text(json.dumps(records,separators=(',',':'))+'\n')
print(label,len(records),'fresh processes',flush=True)
