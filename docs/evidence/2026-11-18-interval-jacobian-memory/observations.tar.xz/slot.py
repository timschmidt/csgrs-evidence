from pathlib import Path
import sys
p=Path('crates/hypersolve/src/eval.rs');a=p.read_text()
l=a.index('        let value = self\n            .bindings\n            .entry(symbol)')
r=a.index('        self.generation += 1;',l)
b='''        match self.bindings.entry(symbol) {
            std::collections::hash_map::Entry::Occupied(mut slot) => {
                *slot.get_mut() = slot.get() + step;
            }
            std::collections::hash_map::Entry::Vacant(slot) => {
                slot.insert(model_value + step);
            }
        }
''' if sys.argv[1]=='slot' else '''        if let Some(value) = self.bindings.get_mut(&symbol) {
            *value = &*value + step;
        } else {
            self.bindings.insert(symbol, model_value + step);
        }
'''
p.write_text(a[:l]+b+a[r:])
