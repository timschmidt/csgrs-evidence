from pathlib import Path
import json,os,random,statistics,subprocess,sys
from concurrent.futures import ThreadPoolExecutor
s=Path(__file__).resolve().parent
crossover=int(os.environ.get('REVERSE_CROSSOVER','0')); candidate=sys.argv[1]; count=int(sys.argv[2]); cases=list(map(int,sys.argv[3:])) or list(range(12)); name=f'{candidate}-{count}-'+('-'.join(map(str,cases)))
def campaign(cpu):
 rows=[]
 for rep in range(count):
    jobs=[(f,c) for f in ['default','trace'] for c in cases]
    random.Random(cpu*1009+rep+crossover*7139).shuffle(jobs)
    for f,c in jobs:
        pair={}
        for label in (['previous',candidate] if (cpu+rep+c+crossover)%2 else [candidate,'previous']):
            env=os.environ.copy()
            if label=='previous' and 8<=c<=10: env['SYNCHRONIZED_REFERENCE']='1'
            out=subprocess.check_output(['taskset','-c',str(cpu),s/'images'/f'{label}-{f}',str(c),'time','0','0'],text=True,env=env)
            _,_,n,elapsed=out.split()
            pair[label]=int(elapsed)/int(n)
        rows.append(dict(cpu=cpu,rep=rep,features=f,case=c,ns=pair))
 (s/(name+f'-cpu{cpu}.json')).write_text(json.dumps(rows)+'\n')
 return rows
with ThreadPoolExecutor(max_workers=3) as ex: records=sum(ex.map(campaign,[3,5,15]),[])
stats=[]
for f in ['default','trace']:
 for c in cases:
    groups=[[r for r in records if (r['cpu'],r['case'],r['features'])==(cpu,c,f)] for cpu in (3,5,15)]
    ratios=[statistics.median(r['ns'][candidate] for r in g)/statistics.median(r['ns']['previous'] for r in g) for g in groups]
    stats.append(dict(features=f,case=c,ratios=ratios))
    print(f,c,*(round(100*(v-1),2) for v in ratios))
(s/(name+'-summary.json')).write_text(json.dumps(stats,indent=2)+'\n')
