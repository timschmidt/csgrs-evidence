from pathlib import Path
import subprocess as sp,os
s=Path(__file__).parent; p=Path('crates/hyperlattice-interval/conformance/alumina-foc')
root=s/'csgrs'; path=root/p/'wasm/lib.rs'; old=path.read_text()
header='pub extern "C" fn output_word(index: u32, action: u32, word: u32) -> u64 {'
mutants={
'lane':('u64::from(lane.lower().bits() as u32) | (u64::from(lane.upper().bits() as u32) << 32)',
        '(u64::from(lane.lower().bits() as u32) | (u64::from(lane.upper().bits() as u32) << 32)) ^ u64::from(cfg!(target_arch = "arm") && index == 4 && matches!(action, samples::Action::InverseClarke) && word == 2)',
        'output_word[4, 3, 2] returned'),
'budget':(header,header+'\n    #[cfg(target_arch = "arm")]\n    if index == 4 && action == 4 && word == 3 { loop {} }',
          'output_word[4, 4, 3] did not return within the 1,000,000-instruction limit'),
'stack':(header,header+'\n    #[cfg(target_arch = "arm")]\n    if index == 4 && action == 4 && word == 3 { let buffer = [0x79u8; 8192]; core::hint::black_box(&buffer); }',
         'Thumb execution fault in output_word')
}
try:
 for name,(a,b,want) in mutants.items():
    assert old.count(a)==1;path.write_text(old.replace(a,b))
    (s/(name+'-mutation.patch')).write_bytes(sp.check_output(['git','-C',root,'diff','--',p/'wasm/lib.rs']))
    f=s/(name+'-mutation.log')
    with f.open('w') as out:
        result=sp.run([s/'venv/bin/python','-B',root/p/'check-thumb.py','--output',s/('mutant-'+name)],cwd=root,stdout=out,stderr=sp.STDOUT,timeout=120)
    log=f.read_text()
    assert result.returncode!=0 and want in log and '825 full transform outputs and 251 range checks passed' in log and 'Cortex-M4 replay passed' not in log,(name,log[-2500:])
finally:path.write_text(old)
