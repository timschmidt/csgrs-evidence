from elftools.elf.elffile import ELFFile
from unicorn import *
from unicorn.arm_const import *
c=Uc(UC_ARCH_ARM,UC_MODE_THUMB|UC_MODE_MCLASS)
c.ctl_set_cpu_model(UC_CPU_ARM_CORTEX_M4)
flash=0x08000000;ram=0x20000000;stop=flash+65534
c.mem_map(flash,65536,UC_PROT_READ|UC_PROT_EXEC);c.mem_map(ram,8192,UC_PROT_READ|UC_PROT_WRITE)
with open('/dev/shm/interval-thumb-replay/compact.elf','rb') as f:
 e=ELFFile(f)
 for seg in e.iter_segments(type='PT_LOAD'):c.mem_write(seg['p_vaddr'],seg.data())
 addr=e.get_section_by_name('.symtab').get_symbol_by_name('conformance_probe')[0]['st_value']
c.reg_write(UC_ARM_REG_SP,ram+8192);c.reg_write(UC_ARM_REG_LR,stop|1)
c.reg_write(UC_ARM_REG_R0,0);c.reg_write(UC_ARM_REG_R1,4)
c.emu_start(addr,stop,count=1000000)
print(hex(c.reg_read(UC_ARM_REG_PC)),hex(c.reg_read(UC_ARM_REG_SP)),hex(c.reg_read(UC_ARM_REG_R0)|(c.reg_read(UC_ARM_REG_R1)<<32)))
