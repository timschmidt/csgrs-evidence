from pathlib import Path
from hashlib import sha256
from statistics import median
from elftools.elf.elffile import ELFFile
import json
s=Path(__file__).parent
tags=['fixed-pair','previous-pair','retained-pair','previous-full','retained-full','shared-full']
allrows={t:json.loads((s/(t+'-calls.json')).read_text()) for t in tags}
assert allrows['fixed-pair']==allrows['previous-pair']==allrows['retained-pair']
assert allrows['previous-full']==allrows['retained-full']
assert allrows['retained-pair']==[r for r in allrows['retained-full'] if r[2]!='output_word']
base=allrows['retained-full'];alt=allrows['shared-full']
assert len(base)==len(alt)==17564
assert [r[:5] for r in base]==[r[:5] for r in alt]
def image(path):
 with path.open('rb') as f:
    elf=ELFFile(f)
    segs=[v for v in elf.iter_segments(type='PT_LOAD')]
    return {'elf_length':path.stat().st_size,'sha256':sha256(path.read_bytes()).hexdigest(),
            'load_extent':max(v['p_vaddr']+v['p_memsz'] for v in segs)-0x08000000,
            'text':elf.get_section_by_name('.text')['sh_size'],'rodata':elf.get_section_by_name('.rodata')['sh_size']}
imgs={t:image(s/(t+'.elf')) for t in tags}
imgs['primary']=image(s/'retained/foc.elf')
result={'images':imgs,'primary_free':65536-imgs['primary']['load_extent'],'word_observers':{},'legacy':{}}
for i in range(5):
 def select(rows):
    return [r for r in rows if r[0]==0 and r[1]==0 and r[2]=='output_word' and r[3][1]==i and r[3][2]<4]
 observations={}
 for path,rs in [('firmware',select(base)),('shared',select(alt))]:
    # Drop the extra read of word zero in the alias check at sample zero.
    samples={tuple(r[3]):r for r in rs}
    assert len(samples)==165*4
    data=list(samples.values())
    observations[path]={'max_sp_bytes':max(r[-1] for r in data),'instructions_min':min(r[-2] for r in data),
       'instructions_max':max(r[-2] for r in data),'instructions_total':sum(r[-2] for r in data)}
 result['word_observers'][str(i)]=observations
 vals=[r for r in base if r[2]=='conformance_probe' and r[3][1]==i]
 result['legacy'][str(i)]={'max_sp_bytes':max(r[-1] for r in vals),'max_instructions':max(r[-2] for r in vals)}
vals=[r for r in base if r[2]=='range_probe']
result['legacy']['range']={'max_sp_bytes':max(r[-1] for r in vals),'max_instructions':max(r[-2] for r in vals)}
assert imgs['previous-full']==imgs['retained-full']
assert all(max(r[-1] for r in rows)<=4096 for rows in allrows.values())
(s/'results.json').write_text(json.dumps(result,indent=2)+'\n')
for i,o in result['word_observers'].items():
 print(i,[(k,v['max_sp_bytes'],v['instructions_total']) for k,v in o.items()])
print(result['legacy'],result['primary_free'])
