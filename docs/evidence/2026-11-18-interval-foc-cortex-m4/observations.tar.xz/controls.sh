set -eu
s=/dev/shm/interval-thumb-replay
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/control-target"
root=$PWD
p=crates/hyperlattice-interval/conformance/alumina-foc
linker="$(rustc +1.88.0 --print sysroot)/lib/rustlib/x86_64-unknown-linux-gnu/bin/rust-lld"
cd "$s/csgrs"
for rev in fixed previous retained; do
    case $rev in
        fixed) git checkout -q --detach c9f1f9ac5
               git -C "$s/alumina-firmware" checkout -q --detach 2d68e82b7
               if cargo +1.88.0 rustc --release --locked --lib --target thumbv7em-none-eabihf --manifest-path "$p/wasm/Cargo.toml" --crate-type staticlib > "$s/historical-lock.log" 2>&1; then exit 1; fi
               rg -q 'lock file' "$s/historical-lock.log"
               git diff c9f1f9ac5 7a65d7a07 -- "$p/wasm/Cargo.lock" > "$s/historical-lock.patch"
               cp "$root/$p/wasm/Cargo.lock" "$p/wasm/Cargo.lock";;
        previous) git restore -- "$p/wasm/Cargo.lock"
                  git checkout -q --detach 7a65d7a07
                  git -C "$s/alumina-firmware" checkout -q --detach 96ac22cad;;
        retained) cp "$root/$p/wasm/check.mjs" "$p/wasm/check.mjs"
                  cp "$root/$p/check-thumb.py" "$p/check-thumb.py";;
    esac
    cargo +1.88.0 rustc --release --locked --lib --target thumbv7em-none-eabihf --manifest-path "$p/wasm/Cargo.toml" --crate-type staticlib
    archive="$CARGO_TARGET_DIR/thumbv7em-none-eabihf/release/libinterval_foc_wasm_consumer.a"
    "$linker" -flavor gnu --nmagic -Ttext=0x08000000 --gc-sections --strip-debug -e conformance_probe -u range_probe "$archive" -o "$s/$rev-pair.elf"
    if test "$rev" != fixed; then
        "$linker" -flavor gnu --nmagic -Ttext=0x08000000 --gc-sections --strip-debug -e conformance_probe -u range_probe -u output_word "$archive" -o "$s/$rev-full.elf"
    fi
    cargo +1.88.0 build --release --locked --lib --target wasm32-unknown-unknown --manifest-path "$p/wasm/Cargo.toml"
    cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/interval_foc_wasm_consumer.wasm" "$s/$rev.wasm"
done
cmp "$s/previous-full.elf" "$s/retained-full.elf"
cmp "$s/previous.wasm" "$s/retained.wasm"
