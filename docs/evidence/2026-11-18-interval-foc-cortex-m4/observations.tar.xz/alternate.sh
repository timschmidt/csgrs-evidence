set -eu
s=/dev/shm/interval-thumb-replay
p=crates/hyperlattice-interval/conformance/alumina-foc
. /dev/shm/hyperinterval-coverage/env
export CARGO_TARGET_DIR="$s/control-target"
cd "$s/csgrs"
git diff --exit-code -- "$p/wasm/lib.rs"
trap 'git restore -- "$p/wasm/lib.rs"' EXIT
sed -i 's/let Ok(output) = samples::native/let Ok(output) = samples::shared/' "$p/wasm/lib.rs"
git diff -- "$p/wasm/lib.rs" > "$s/shared-observer.patch"
"$s/venv/bin/python" -B "$p/check-thumb.py" --output "$s/shared" > "$s/shared.log" 2>&1
cp "$s/shared/foc.elf" "$s/shared-full.elf"
cmp "$s/final/calls.json" "$s/shared/calls.json"
