from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;root=Path.cwd();other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-foc-cortex-m4'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in s.iterdir():
 if p.is_file() and (p.suffix in ('.py','.c','.sh','.patch','.log','.json','.txt') or p.name in ('scope','source-revision')):
    files[p.name]=p.read_bytes()
assert files['source-revision'].decode().strip()==git(root,'rev-parse','HEAD').decode().strip()
for name in ('fixed-pair','previous-pair','retained-pair','previous-full','retained-full','shared-full'):
    files['images/'+name+'.elf']=(s/(name+'.elf')).read_bytes()
for n in ['foc.elf','calls.json']:
    files['primary/'+n]=(s/'retained'/n).read_bytes()
for n in ['lane','stack','budget']:
    files['images/'+n+'-mutation.elf']=(s/('mutant-'+n)/'foc.elf').read_bytes()
assert all(k in files for k in ['audit.log','fmt.log','wasm-lint.log','native-lint.log','results.json','retained-full-calls.json'])
files['commands.txt']=(sp.check_output(['rustc','+1.88.0','-vV'])+sp.check_output(['node','--version'])+sp.check_output(['uv','--version']))
archive=s/'record';archive.mkdir()
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
digests={k:sha(v) for k,v in sorted(files.items())}
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive linked Cortex-M4 FOC replay, stack and instruction measurements')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1])
