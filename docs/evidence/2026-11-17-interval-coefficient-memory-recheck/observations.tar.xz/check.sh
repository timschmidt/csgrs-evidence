set -eu
s=/dev/shm/interval-stage-memory
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/target"
cd "$s/allocation-probe"
cargo +1.95.0 build --release --locked
exe="$s/images/$1-allocation"
cp "$CARGO_TARGET_DIR/release/adaptive-stage-allocation-probe" "$exe"
python3 - "$s" "$1" "$exe" <<'PY'
from pathlib import Path
import json,sys,hashlib
p=Path(sys.argv[3]);(Path(sys.argv[1])/(sys.argv[2]+'-probe-artifact.json')).write_text(json.dumps(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
PY
if [ ! -e "$s/$1-allocation/samples.json" ]; then python3 "$s/measure-allocation.py" "$1"; fi
cd "$s/csgrs"
cargo +1.95.0 build --release --locked -p hyperdynamics --bench adaptive_taylor --features adaptive-taylor,taylor-evolution --message-format=json > "$s/logs/$1-bench.json"
python3 - "$s" "$1" <<'PY'
import sys,shutil,json
from pathlib import Path
s=Path(sys.argv[1]);v=sys.argv[2]
r=next(r for l in (s/'logs'/(v+'-bench.json')).read_text().splitlines() if (r:=json.loads(l)).get('executable') and r['target']['name']=='adaptive_taylor')
shutil.copy2(r['executable'],s/'images'/(v+'-bench'))
PY
