import json,collections,re,hashlib,subprocess,sys
from pathlib import Path
s=Path(__file__).parent
primary,proposed=sys.argv[1:]
labels=['fixed',primary,proposed]
def observations(path):
 return {(r['case'],r['mode'],r['order'],r['warmup_16'],r['repeat']):r for r in json.loads(path.read_text())}
o=[observations(s/(v+'-allocation/samples.json')) for v in labels]
historical=Path('/tmp/interval-refactor/adaptive-stage-ownership-reconsideration')
h=[observations(historical/(v+'-allocation/samples.json')) for v in ['baseline','candidate']]
assert all(o[0].keys()==x.keys() for x in h+o)
groups=collections.defaultdict(list)
for k in o[0]:
 f,b,a=[x[k] for x in o]
 result={}
 for stage,metric in [('retained','live_bytes'),('retained','peak_live_bytes'),('after','live_bytes'),('retained','allocation_count')]:
  low,base,new=[x[stage][metric] for x in [f,b,a]]
  historical_variation=h[1][k][stage][metric]-h[0][k][stage][metric]
  delta=new-base
  # Keep the historical rejected candidate as a separate observation. Check
  # even a conservative hypothetical charge carrying both positive deltas.
  charge=max(0,base-low)+max(0,delta)+max(0,historical_variation)
  if metric!='allocation_count':
   assert new <= 524288
   if stage=='after':assert delta<=0 and charge==0,(k,delta,charge)
   else:
    assert max(0,delta)<=32 and 100*max(0,delta)<=base,(k,metric,delta,base)
    assert charge<=64 and 100*charge<=2*low,(k,metric,charge,low)
  result[stage+'_'+metric]=dict(fixed=low,primary=base,proposed=new,delta=delta,historical=historical_variation,conservative_charge=charge)
  assert delta==historical_variation,(k,metric,delta,historical_variation)
 groups[k[1],k[2]].append(result)
for k,rs in sorted(groups.items()):
 print('MEMORY',k,len(rs),{m:sorted({r[m]['delta'] for r in rs}) for m in rs[0]})
 print('RETAINED',k,'highest incremental percent',max(100*max(0,r['retained_live_bytes']['delta'])/max(1,r['retained_live_bytes']['primary']) for r in rs))
print('PEAK', max(r['retained_peak_live_bytes']['proposed'] for rs in groups.values() for r in rs))
print('CLEANUP max live',max(r['after_live_bytes']['proposed'] for rs in groups.values() for r in rs))
p=s/'logs'/('proposed-tests' if proposed=='proposed' else 'candidate-tests')
pat=r'^(PREP\d|PREP_TRACE\d|PREP_WORK\d|REPORT\d|TRACE\d|WORK\d)='
def artifact(p):return [l for l in p.read_text().splitlines() if re.match(pat,l)]
b=artifact(s/'logs/baseline-observer');a=artifact(p)
assert len(b)==18 and len(a)==36 and collections.Counter(b*2)==collections.Counter(a)
print('ARTIFACT',len(('\n'.join(b)+'\n').encode()),hashlib.sha256(('\n'.join(b)+'\n').encode()).hexdigest())
subprocess.run([sys.executable,'/dev/shm/interval-bisection/sizes.py',*[s/'images'/(v+'-'+n) for n in ['allocation','bench'] for v in labels]],check=True)
