set -eu
s=/dev/shm/interval-stage-memory
bash "$s/check.sh" fixed > "$s/logs/fixed-build-retry" 2>&1
git -C "$s/csgrs" switch --detach --quiet 6de319edf
bash "$s/check.sh" current > "$s/logs/current-build" 2>&1
cd "$s/csgrs"
git apply --include='crates/hyperdynamics/tests/field_taylor_orders.rs' "$s/candidate.patch"
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$s/target"
if cargo +1.95.0 test --locked -p hyperdynamics --features taylor-flow --test field_taylor_orders complete_coefficient_association_is_shared_by_restriction > "$s/logs/missing" 2>&1; then exit 1; fi
rg 'immutable coefficient association was copied' "$s/logs/missing"
git apply --exclude='crates/hyperdynamics/tests/field_taylor_orders.rs' "$s/candidate.patch"
bash "$s/check.sh" candidate > "$s/logs/candidate-build" 2>&1
cargo +1.95.0 test --locked -p hyperdynamics --features adaptive-taylor,taylor-evolution,dispatch-trace --test field_taylor_orders --test adaptive_order_sharing --test stage_ownership_baseline --test adaptive_preparation_baseline -- --nocapture > "$s/logs/candidate-tests" 2>&1
