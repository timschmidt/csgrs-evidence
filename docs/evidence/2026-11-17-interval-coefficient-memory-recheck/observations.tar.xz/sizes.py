from pathlib import Path
import sys, subprocess
for arg in sys.argv[1:]:
 p=Path(arg)
 regions=[]
 for line in subprocess.check_output(['readelf','-Ws',p],text=True).splitlines():
  r=line.split()
  if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit() and int(r[2]):
   a=int(r[1],16); regions.append((a,a+int(r[2])))
 last=0; total=0
 for a,b in sorted(regions):
  total+=max(0,b-max(a,last)); last=max(b,last)
 sec=dict((r[0],int(r[1])) for l in subprocess.check_output(['size','-A',p],text=True).splitlines() if len(r:=l.split())==3 and r[0].startswith('.'))
 print(p,p.stat().st_size,sec['.text'],total)
