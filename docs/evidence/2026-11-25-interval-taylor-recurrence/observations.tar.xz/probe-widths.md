# Taylor-mode remainder probes (2026-11-25)

Temporary test `tests/zz_probe.rs` (removed after use), hypersolve with
`taylor-combination`, release profile for the cost table. "Natural" is the
prior behavior (natural interval evaluation of generated partials, selected by
a temporary environment switch); "recurrence" is the committed behavior.
Widths are full widths of the order-(n+1) remainder interval (or of the
generated range for the u/v rows), domain [-1/4, 1/4] about 0 unless noted,
precision 2^-64.

## u/v via join + apply, (1+x)/(1+x) from centers 0 and 1/32

| Domain | Order | Natural | Recurrence |
| --- | --- | --- | --- |
| [-1/16,1/16] | 1 | 2.316e-2 | 1.393e-2 |
| [-1/16,1/16] | 2 | 5.856e-3 | 1.264e-3 |
| [-1/16,1/16] | 3 | 3.095e-3 | 6.189e-5 |
| [-1/16,1/16] | 4 | 6.715e-3 | 5.619e-6 |
| [-1/16,1/16] | 5 | 1.437e-1 | 2.751e-7 |
| [-1/16,1/16] | 6 | 2.510e-1 | 2.497e-8 |
| [-1/16,1/16] | 7 | 2.510e-1 | 1.223e-9 |
| [-1/4,1/4] | 1 | 1.067 | 4.074e-1 |
| [-1/4,1/4] | 2 | 1.067 | 1.975e-1 |
| [-1/4,1/4] | 3 | 1.067 | 4.527e-2 |
| [-1/4,1/4] | 4 | 1.067 | 2.195e-2 |
| [-1/4,1/4] | 5 | 1.067 | 5.030e-3 |
| [-1/4,1/4] | 6 | 1.067 | 2.439e-3 |
| [-1/4,1/4] | 7 | error: ContainsZero in a generated partial | 5.589e-4 |

## Direct models

| Source | Order | Natural | Recurrence |
| --- | --- | --- | --- |
| 1/(1+x) | 2 | 1.012 | 9.877e-2 |
| 1/(1+x) | 4 | 5.490e4 | 1.097e-2 |
| 1/(1+x) | 6 | 2.124e26 | 1.219e-3 |
| 1/(1+x) | 8 | error: ContainsZero | 1.355e-4 |
| sin(x)cos(x) | 2 / 4 / 6 / 8 | 2.211e-2 / 2.764e-4 / 1.645e-6 / 5.712e-9 | identical |
| sqrt(1+x) | 2 | 4.787e-3 | 4.009e-3 |
| sqrt(1+x) | 4 | 2.272e-3 | 1.949e-4 |
| sqrt(1+x) | 6 | NaN in the f64 report (endpoint mantissa or exponent outside f64) | 1.276e-5 |
| sqrt(1+x) | 8 | NaN in the f64 report | 9.601e-7 |
| ln(2+x) | 2 | 2.499e-3 | 1.944e-3 |
| ln(2+x) | 4 | 1.001e-3 | 2.380e-5 |
| ln(2+x) | 6 | 2.628e1 | 3.469e-7 |
| atanh(x) | 2 / 4 / 6 | 1.522e-2 / 1.538e-3 / 1.715e-3 | 1.501e-2 / 8.870e-4 / 6.715e-5 |
| asin(x) | 2 / 4 / 6 | 6.910e-3 / 3.533e-4 / 4.615e-5 | 6.885e-3 / 2.958e-4 / 1.840e-5 |
| (1+x)^-3 | 2 / 4 / 6 | 1.756 / 4.097e-1 / 7.804e-2 | identical (power composition) |
| x/(2+y)+sin(xy), box [-1/4,1/4]^2 | 2 | 1.027e-1 | 8.291e-3 |
| x/(2+y)+sin(xy) | 4 | 8.020 | 6.273e-4 |
| x/(2+y)+sin(xy) | 6 | 4.106e22 | 4.685e-6 |
| x/(2+y)+sin(xy) | 8 | inf | 2.182e-7 |

A quotient recurrence for negative powers (before switching `PowI` to
composition through certified power images) gave (1+x)^-3 widths 1.008e2,
7.917e2 and 6.343e3 at orders 2, 4 and 6; composition restores the natural
widths. Division by composition (reciprocal then product) and by the quotient
recurrence gave identical widths on every probe row, so division keeps the
recurrence.

## Build cost, single run each, release, one-variable domain [-1/4,1/4]

Graph work and arithmetic work are the budget units consumed.

| Source | Order | Natural: time / graph / arithmetic | Recurrence: time / graph / arithmetic |
| --- | --- | --- | --- |
| 1/(1+x) | 4 | 290 us / 2781 / 2.55e6 | 220 us / 2211 / 8.81e5 |
| 1/(1+x) | 8 | 1.36 ms / 23819 / 2.42e7 (fails) | 1.20 ms / 19293 / 1.33e6 |
| sin*cos | 8 | 6.56 ms / 69088 / 1.48e8 | 3.94 ms / 52531 / 3.98e7 |
| sqrt(1+x) | 8 | 6.87 ms / 93576 / 5.13e9 | 4.09 ms / 70165 / 7.46e6 |
| x/(2+y)+sin(xy) | 6 | 9.24 ms / 74183 / 2.72e8 | 4.56 ms / 57798 / 2.82e7 |
| x/(2+y)+sin(xy) | 8 | 28.5 ms / 332994 / 4.87e9 | 17.1 ms / 252761 / 3.28e7 |

Intersecting both bounds (computing both) gave the same widths as the
recurrence alone on every row once powers used composition, at 5-20% more
time than natural alone; the committed path uses the recurrence alone and
falls back to natural partial bounds only when a recurrence is unavailable.
