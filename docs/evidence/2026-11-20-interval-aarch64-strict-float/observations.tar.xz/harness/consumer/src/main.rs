use hyperinterval::{F32Enclosure,F64Enclosure};
fn main(){
 let a=std::hint::black_box(f32::from_bits(1));let b=std::hint::black_box(3.0_f32);
 let span=F32Enclosure::point(a).and_then(|x| x.div(&F32Enclosure::point(b)?));
 println!("qualified32={} qualified64={} verdict={:?}",F32Enclosure::backend_supported(),F64Enclosure::backend_supported(),span);
 let (lower,upper)=span.unwrap().bounds().unwrap();
 assert_eq!((lower.to_bits(),upper.to_bits()),(0,1));
 assert!(F64Enclosure::backend_supported());
}
