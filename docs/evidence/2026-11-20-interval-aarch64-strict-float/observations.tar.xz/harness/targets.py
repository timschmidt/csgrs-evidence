import os,subprocess,tomllib,hashlib
from pathlib import Path
w=Path(os.environ['w'])
for tc in ['1.88.0','1.95.0','stable']:
 prefix=Path(subprocess.check_output(['rustc','+'+tc,'--print','sysroot'],text=True).strip());m=tomllib.loads((prefix/'lib/rustlib/multirust-channel-manifest.toml').read_text())
 target='aarch64-unknown-linux-gnu';r=m['pkg']['rust-std']['target'][target];p=w/(tc+'.tar.xz')
 subprocess.run(['curl','-fsSL','--retry','2',r['xz_url'],'-o',p],check=True)
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==r['xz_hash']
 d=w/('sysroot-'+tc);d.mkdir();member=next(l for l in subprocess.check_output(['tar','-tf',p],text=True).splitlines() if l.endswith('/lib/rustlib/'+target))
 subprocess.run(['tar','-xf',p,'--strip-components=2','-C',d,member],check=True);p.unlink()
