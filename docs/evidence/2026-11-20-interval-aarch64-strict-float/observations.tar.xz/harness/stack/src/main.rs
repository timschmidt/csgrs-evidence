use std::{ffi::c_void,hint::black_box};
use hyperlattice_interval::{IntervalMatrix,IntervalVector,hyperinterval::{F32Enclosure,F64Enclosure,IntervalError}};
mod allocations;
unsafe extern "C"{fn measure_stack(f:extern "C" fn(*mut c_void),data:*mut c_void,warm:i32,paint:u8)->usize;}
#[inline(never)]
fn consume()->u64 {
 macro_rules! chain {($i:ty,$f:ty)=>{{
  let x=<$i>::new(black_box(-1.0),black_box(2.0))?;
  let y=<$i>::point(black_box(0.5))?;
  let z=<$i>::point(black_box(0.0))?;
  let v=IntervalVector::new([x,y]).unwrap();
  let m=IntervalMatrix::new([[y,z],[z,y]]).unwrap();
  let image=m.mul_vector(&v,&mut ()).unwrap();let dot=image.dot(&image,&mut ()).unwrap();
  // Independent endpoint products: [-1/2,1]^2 as independent intervals
  // gives [-1/2,1], and (1/4)^2 adds 1/16.
  assert_eq!(dot.bounds(),Some((-0.4375,1.0625)));
  let tiny=<$i>::point(<$f>::from_bits(black_box(1)))?;
  assert_eq!(tiny.div(&<$i>::point(3.0)?)?.bounds().unwrap().1.to_bits(),1);
  assert_eq!(black_box(tiny).square()?.bounds().unwrap().0.to_bits(),0);
  black_box(dot).bounds().unwrap().1.to_bits() as u64
 }}}
 let both=|| -> Result<u64,IntervalError>{Ok(chain!(F32Enclosure,f32)^chain!(F64Enclosure,f64))};
 match both(){Ok(value)=>value,Err(IntervalError::UnqualifiedEnvironment)=>21,err=>panic!("{err:?}")}
}
extern "C" fn run(_:*mut c_void){black_box(consume());}
fn main(){
 let value=consume();let expected=if F32Enclosure::backend_supported(){u64::from(1.0625_f32.to_bits())^1.0625_f64.to_bits()}else{21};assert_eq!(value,expected);
 for warm in [0,1] {for paint in [0x55,0xaa]{let peak=unsafe{measure_stack(run,std::ptr::null_mut(),warm,paint)};println!("stack {value} {warm} {paint} {peak}");}}
 let (_,n,bytes)=allocations::measure(||{run(std::ptr::null_mut());run(std::ptr::null_mut())});println!("alloc {n} {bytes}");assert_eq!((n,bytes),(0,0));
}
