use std::{env,path::PathBuf,process::Command};
fn main(){
 let out=PathBuf::from(env::var_os("OUT_DIR").unwrap());let arm=env::var("CARGO_CFG_TARGET_ARCH").unwrap()=="aarch64";
 let cc=if arm{env::var("CC_aarch64_unknown_linux_gnu").unwrap()}else{"cc".into()};
 let mut cmd=Command::new(cc);
 cmd.args(["-O2","-Wall","-Werror","-fno-omit-frame-pointer"]);
 if !arm{cmd.arg("-mno-red-zone");}
 assert!(cmd.args(["-c","stack.c","-o"]).arg(out.join("stack.o")).status().unwrap().success());
 assert!(Command::new("ar").arg("crs").arg(out.join("libstack.a")).arg(out.join("stack.o")).status().unwrap().success());
 println!("cargo:rustc-link-search=native={}",out.display());println!("cargo:rustc-link-lib=static=stack");println!("cargo:rerun-if-changed=stack.c");
}
