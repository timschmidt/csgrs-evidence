mod kernel;
use std::{fs,env,hint::black_box,arch::asm};
use kernel::*;
fn rank(x:u64, width:u64)->i128{
 let sign=1u64<<(width-1);
 if x<sign{i128::from(x)}else{-i128::from(x-sign)}
}
fn main(){
 let args:Vec<_>=env::args().collect();
 let rows=fs::read(&args[1]).unwrap();
 assert!(rows.len() % 112 == 0);assert_eq!(qualification(),3);
 let mut original:u64;unsafe{asm!("mrs {},fpcr",out(reg) original)};
 let mut modes=0;
 for mode in 0u64..64{
  let mask=(15<<22)|3;let requested=((mode>>2)<<22)|(mode&3);
  let control=(original & !mask)|requested;
  let mut active:u64;
  unsafe{asm!("msr fpcr, {}","isb","mrs {},fpcr",in(reg) control,out(reg) active)};
  assert_eq!((active>>22)&15, mode>>2);
  if active&mask!=requested {continue;}
  for (i,bytes) in rows.chunks_exact(112).enumerate(){
    let v:[u64;14]=std::array::from_fn(|k|u64::from_le_bytes(bytes[k*8..k*8+8].try_into().unwrap()));
    let [width,op,flags,a,b,c,d,e,expected,lo,hi,outerlo,outerhi,allowed]=black_box(v);
    let call=|selector|match (width,op) {
     (32,22)=>properties32(flags as u32,a as u32,b as u32,c as u32,d as u32,e as u32),
     (64,22)=>properties64(flags as u32,a,b,c,d,e),
     (32,21)=>convert32(selector,flags as u32 & 1,a as u32,b as u32),
     (64,21)=>convert64(selector,flags as u32 & 1,a,b),
     (32,_)=>query32(op as u32,selector,flags as u32,a as u32,b as u32,c as u32,d as u32,e as u32),
     (64,_)=>query64(op as u32,selector,flags as u32,a,b,c,d,e as u32),_=>unreachable!()
    };
    assert_eq!(call(0),expected,"status {i} mode {mode}");
    if op!=22 && (expected==0 || expected==2){
      let actual=(call(1),call(2));
      if allowed==0 {assert_eq!(actual,(lo,hi),"bits {i} mode {mode}");}else{
        let (x,y)=actual;let sign=1u64<<(width-1);
        assert!(x!=sign && y!=sign && (width==64 || (x|y)<1u64<<32));
        assert!((rank(outerlo,width)..=rank(lo,width)).contains(&rank(x,width)));
        assert!((rank(hi,width)..=rank(outerhi,width)).contains(&rank(y,width)));
      }
    }
  }
  modes+=1;
 }
 unsafe{asm!("msr fpcr, {}","isb",in(reg)original)};
 println!("{} cases per mode; {} verified FPCR modes",rows.len()/112,modes);
}
