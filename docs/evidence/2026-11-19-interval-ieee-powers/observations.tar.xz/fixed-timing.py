import itertools,os,random,subprocess,resource,statistics,time,json
from pathlib import Path
w=Path(__file__).parent; root=Path('/mnt/development/csgrs')
script=Path('crates/hyperinterval/conformance/wasm-float/check.mjs')
core=sorted(os.sched_getaffinity(0))[14];os.sched_setaffinity(0,{core})
rng=random.Random(3287);records=[];summary={}
for target in ('wasm32-unknown-unknown','wasm32-wasip1'):
 orders=list(itertools.permutations(['previous','same_corpus','expanded']))*2;rng.shuffle(orders)
 for rep,order in enumerate([orders[0]]+orders):
  for stage in order:
   c=(w/'previous-source' if stage=='previous' else root)/script
   data=w/('after.json' if stage=='expanded' else 'before.json')
   start=time.monotonic_ns();before=resource.getrusage(resource.RUSAGE_CHILDREN)
   out=subprocess.check_output([w/'bin/node',c,w/f'original-stable-{target}.wasm',data,*(['--wasi-p1'] if target.endswith('wasip1') else [])],stderr=subprocess.DEVNULL)
   elapsed=(time.monotonic_ns()-start)/1e6;end=resource.getrusage(resource.RUSAGE_CHILDREN)
   assert json.loads(out)['cases']==(55988 if stage=='expanded' else 55802)
   records.append(dict(target=target,stage=stage,round=rep,cpu=core,wall_ms=elapsed,user_ms=1000*(end.ru_utime-before.ru_utime)))
 for stage in ('previous','same_corpus','expanded'):
  runs=[r for r in records if (r['target'],r['stage'])==(target,stage) and r['round']>0]
  summary[target+'/'+stage]={k:statistics.median(r[k] for r in runs) for k in ('wall_ms','user_ms')}
(w/'final-timing.json').write_text(json.dumps(dict(summary=summary,samples=records),indent=2)+'\n')
