set -eu
. /mnt/development/.interval-refactor-build/ieee-powers.c8DISS/env
c=$PWD/crates/hyperinterval/conformance/wasm-float
test -s "$w/after.json"
python3 - "$w" <<'PY'
from pathlib import Path
import sys,json
w=Path(sys.argv[1])
for width in (32,64):
 data=json.loads((w/f'normal-{width}.json').read_bytes());assert len(data['cases'])==66
 data['cases']=[r for r in data['cases'] if r[7]>127];assert len(data['cases'])==10
 (w/f'near-{width}.json').write_text(json.dumps(data))
PY
for trial in truncate inward; do
 wasm="$w/$trial-stable-wasm32-unknown-unknown.wasm"
 if node "$c/check.mjs" "$wasm" "$w/after.json" > "$w/logs/final-$trial-all" 2>&1; then exit 1; fi
 for width in 32 64; do
  for kind in normal full near; do
   if node "$w/mutation-check.mjs" "$wasm" "$w/$kind-$width.json" "$c/check.mjs" > "$w/logs/final-$trial-$kind-$width" 2>&1; then exit 1; fi
   rg -q 'Error: Case [0-9]+:' "$w/logs/final-$trial-$kind-$width"
  done
 done
done
export TMPDIR="$(cat "$w/browser-tmp-path")" XDG_CACHE_HOME="$w/browser-cache" XDG_CONFIG_HOME="$w/browser-config" CHROMIUM="$w/bin/chromium-local"
ulimit -c 0
for v in 1.88.0 1.95.0 stable; do
 node "$c/browser.mjs" "$w/original-$v-wasm32-unknown-unknown.wasm" "$w/after.json" > "$w/logs/final-browser-$v" 2>&1
done
