import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const [w, root] = process.argv.slice(2);
const {verifyInstance}=await import(pathToFileURL(path.join(root,'crates/hyperinterval/conformance/wasm-float/check.mjs')));
const {instance}=await WebAssembly.instantiate(await readFile(path.join(w,'original-stable-wasm32-unknown-unknown.wasm')));
for(const width of [32,64]){
 const data=JSON.parse(await readFile(path.join(w,`normal-${width}.json`)));
 const encode=width===32?Number:BigInt;
 let widened=0,exact=0,loose=0;
 for(const row of data.cases){
  const [width,op,flags,a,b,c,d,n,,lower,upper]=row;
  const q=instance.exports[`query${width}`];
  const args=[flags,...[a,b,c,d].map(encode),n];
  const real=i=>BigInt.asUintN(64,q(op,i,...args));
  if(real(1)!==BigInt(lower)||real(2)!==BigInt(upper))widened++;
  const point={...data,cases:[row]};
  // The tightest possible directed projection is also a conforming implementation.
  const shim={qualification:()=>3,[`query${width}`]:(_,i)=>[0n,BigInt(lower),BigInt(upper)][i]};
  verifyInstance(shim,point);exact++;
  // Replacing the result by the whole finite format must fail the width bound.
  const max=width===32?0x7f7fffffn:0x7fefffffffffffffn;
  shim[`query${width}`]=(_,i)=>[0n,max|(1n<<BigInt(width-1)),max][i];
  try{verifyInstance(shim,point)}catch(e){if(!e.message.includes('outside endpoint allowances'))throw e;loose++;}
 }
 if(widened===0 || loose!==66 || exact!==66)throw Error('ineffective allowance');
 console.log(width,JSON.stringify({widened,tight_projection_passes:exact,whole_format_rejected:loose}));
}
