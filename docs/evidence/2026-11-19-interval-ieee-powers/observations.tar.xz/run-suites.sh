set -eu
. /mnt/development/.interval-refactor-build/ieee-powers.c8DISS/env
for v in 1.88.0 1.95.0 stable; do
 export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-$v"
 for target in wasm32-unknown-unknown wasm32-wasip1; do
  stage="$w/suite-$v-$target"
  [ "$(df -P -B1 /mnt/development | awk 'END {print $4}')" -gt 21474836480 ]
  python3 scripts/check_interval_wasm.py --target "$target" --toolchain "$v" --output "$stage" > "$w/logs/suite-$v-$target" 2>&1
  test -s "$stage/report.json"
  python3 - "$stage/target" <<'PY'
from pathlib import Path
import shutil,sys
p=Path(sys.argv[1]);assert p.name=='target' and p.parent.parent.name=='ieee-powers.c8DISS'
shutil.rmtree(p)
PY
 done
done
