from pathlib import Path
import sys,json,subprocess,hashlib
w=Path(__file__).parent
name='crates/hyperinterval/conformance/wasm-float/oracle.py'
if len(sys.argv)>1:
 stage=sys.argv[1];root=w/'previous-source' if stage=='before' else Path('/mnt/development/csgrs')
 p=w/'final-oracle-result.json'
 run=subprocess.run([sys.executable,root/name,p],capture_output=True,check=True)
 assert json.loads(run.stdout)['cases']==(55802 if stage=='before' else 55988)
 assert hashlib.file_digest(p.open('rb'),'sha256').digest()==hashlib.file_digest((w/(stage+'.json')).open('rb'),'sha256').digest()
 p.unlink()
 cg=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
 peak=int((cg/'memory.peak').read_text())
 assert int((cg/'memory.max').read_text())==256<<20 and int((cg/'memory.swap.max').read_text())==0 and peak<=192<<20
 events={k:int(v) for k,v in (line.split() for line in (cg/'memory.events').read_text().splitlines())};assert not any(events.values())
 print(json.dumps(dict(stage=stage,peak=peak,events=events)))
else:
 g=lambda k:subprocess.check_output(['git','rev-parse',k+':'+name],text=True).strip()
 assert g('0ba14a211')==g('56f976d80')
 rows=[]
 for k in ('before','after','after','before','before','after'):
  rows.append(json.loads(subprocess.check_output(['systemd-run','--quiet','--user','--scope','-p','MemoryMax=256M','-p','MemorySwapMax=0',sys.executable,__file__,k],text=True)))
 (w/'final-generation.json').write_text(json.dumps(rows,indent=2)+'\n')
