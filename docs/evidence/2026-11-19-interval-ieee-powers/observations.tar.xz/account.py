from pathlib import Path
import json,tarfile,hashlib
w=Path(__file__).parent
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
root=Path('/mnt/development/csgrs');p=root/'docs/research/interval-memory-accounts.json';accounts=read(p)
anchor=accounts['wasm_float_endpoint_qualification_jobs']['targets']
obs=read(w/'lifetimes.json');assert len(obs)==60
record='docs/evidence/2026-11-19-interval-ieee-powers'
summary={'source_previous':'56f976d80','evidence':record,'scope':'Completed sequential Node arithmetic verification with 24 fresh trap checks, and Python generation through publication of the deterministic corpus. Host group peaks include the observer. Previous positive verifier charges carry forward. The generator at its first commit 0ba14a211 has the same source blob as the predecessor.','capacity_bytes':256<<20,'reserve_bytes':64<<20,'swap_bytes':0,'positive_incremental_cap':'minimum of 4 MiB and 5% of the preceding measured peak','positive_cumulative_cap':'minimum of 8 MiB and 10% of the fixed preceding peak','targets':{}}
def account(j,prior,fixed):
 a,b=[max(r['peak'] for r in j if r['stage']==stage) for stage in ('before','after')]
 inc=max(0,b-a);charged=prior+inc;growth=charged-fixed
 icap=min(4<<20,a//20);ccap=min(8<<20,fixed//10)
 assert inc<=icap and growth<=ccap and max(b,charged)<=192<<20,(inc,icap,growth,ccap)
 return dict(fixed_peak=fixed,previous_charge=prior,previous_peak=a,measured_peak=b,increment=inc,cumulative_charged_peak=charged,incremental_remaining_bytes=icap-inc,cumulative_remaining_bytes=ccap-growth,remaining_above_reserve_bytes=(192<<20)-max(b,charged))
suite={}
with tarfile.open(w/'previous.tar.xz') as tar:
 for k,c in anchor.items():
  runs=[r for r in obs if r['toolchain']+'-'+r['target']==k];assert len(runs)==10
  summary['targets'][k]=account(runs,c['cumulative_charged_peak_bytes'],c['preceding_peak_bytes'])
  previous=json.load(tar.extractfile('final/'+k+'/report.json'));pdir=w/('suite-'+k);d=w/'final'/k;r=read(pdir/'report.json');ex=read(d/'execute.log');stk=read(d/'guest-stack.log')
  assert ex['cases']==55988 and ex['properties']==8862 and ex['endpoint_traps']==24 and not ex['imports']
  assert r['binary_sha256']==previous['binary_sha256']==sha(pdir/'interval_float.wasm')
  assert sha(w/('original-'+k+'.wasm'))==sha(w/('retained-'+k+'.wasm'))
  for new,old in zip(stk,previous['guest_stack'],strict=True):
   for field in ('temperature','sentinel','linearBytes','stackBytes','touchedBytes','reservedBytes'):assert new[field]==old[field]
   assert (new['cases'],new['properties'])==(55988,8862)
  lat=read(d/'lattice.log');dy=read(d/'dyadic.log')
  assert lat['floating_chains']==lat['fixed_chains']==612 and dy['dyadic_egress_cases']==56 and r['fixed_lattice']['calls']==172284
  assert not r['floating_arithmetic'] and not r['memory_grow'] and r['no_allocator_consumer']
  if k.endswith('wasip1'):assert sum(r['lattice_guest_tests'].values())==65
  suite[k]=dict(primary_file_bytes=r['binary_bytes'],main_linked_sha256=r['binary_sha256'],matched_detached_sha256=sha(w/('retained-'+k+'.wasm')),stack_bytes=max(x['reservedBytes'] for x in stk),arithmetic=ex['cases'],properties=ex['properties'],endpoint_traps=ex['endpoint_traps'],corpus_sha256=sha(w/'after.json'),fixed_calls=r['fixed_lattice']['calls'],lattice_chains_each=612,dyadic_egress=56,wasi_tests=r.get('lattice_guest_tests'),real_bridge=r['real_bridge'].get('executed'))
gens=read(w/'final-generation.json');assert len(gens)==6
fixed=max(r['peak'] for r in gens if r['stage']=='before')
summary['generator']=account(gens,fixed,fixed)
for v in ('1.88.0','1.95.0','stable'):
 b=read(w/('logs/final-browser-'+v));assert b['cases']==55988 and b['properties']==8862 and b['endpoint_traps']==24
 assert read(w/('logs/default-test-'+v))['endpoint_traps']==8
assert 'ieee_power_qualification' not in accounts
accounts['ieee_power_qualification']=summary
write(w/'result.json',{'targets':suite,'budget':summary,'timing':read(w/'final-timing.json')['summary'],'oracle':(w/'logs/corpus-check').read_text().strip(),'per_width_verifier_controls':(w/'logs/allowances').read_text().splitlines()})
write(p,accounts)
