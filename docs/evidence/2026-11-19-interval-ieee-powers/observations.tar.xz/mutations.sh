set -eu
. /mnt/development/.interval-refactor-build/ieee-powers.c8DISS/env
p=crates/hyperinterval/src/ieee.rs
for v in 1.88.0 1.95.0 stable; do
 for target in wasm32-unknown-unknown wasm32-wasip1; do bash "$w/guest.sh" "$v" original "$target"; done
done
for trial in truncate inward; do
 git -C "$w/control" restore -- "$p"
 python3 - "$w/control/$p" "$trial" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
if sys.argv[2]=='truncate':
 q='let negative = bits & self.sign != 0 && !exponent.is_multiple_of(2);'
 assert s.count(q)==1;s=s.replace(q,'exponent &= 15;\n        '+q)
else:
 for a in ['result.1, base.1','base.1, base.1']:
  q='self.mul('+a+')?.1';assert s.count(q)==1;s=s.replace(q,'self.mul('+a+')?.0')
p.write_text(s)
PY
 git -C "$w/control" diff -- "$p" > "$w/$trial.patch"
 bash "$w/guest.sh" stable "$trial" wasm32-unknown-unknown
done
git -C "$w/control" restore -- "$p"
