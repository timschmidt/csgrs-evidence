set -eu
. /mnt/development/.interval-refactor-build/ieee-powers.c8DISS/env
v=$1; stage=$2; target=$3
cd "$w/control"
features=()
if [ "$target" = wasm32-wasip1 ]; then
 export CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $w/sysroot-$v"
 features=(--features float-enclosure-wasip1)
fi
export CARGO_TARGET_DIR="$w/build-$v"
cargo +"$v" build --offline --locked --release --target "$target" --manifest-path crates/hyperinterval/conformance/wasm-float/Cargo.toml "${features[@]}"
cp "$CARGO_TARGET_DIR/$target/release/interval_float_wasm_conformance.wasm" "$w/$stage-$v-$target.wasm"
