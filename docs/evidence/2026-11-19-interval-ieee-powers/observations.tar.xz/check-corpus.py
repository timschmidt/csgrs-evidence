from pathlib import Path
import json,sys,collections,hashlib
w=Path(__file__).parent
old=json.loads((w/'before.json').read_bytes());new=json.loads((w/'after.json').read_bytes())
for k in ['cases','properties']:assert old[k]==new[k][:len(old[k])]
assert new['lattice']==old['lattice']
extra=new['cases'][len(old['cases']):]
assert len(extra)==186
for width in (32,64):
 normal=[r for r in extra if r[0]==width and len(r)==13]
 full=[r for r in extra if r[0]==width and r[7]>=(1<<31)-1 and len(r)!=13]
 assert len(normal)==66 and len(full)==27 and {r[8] for r in full}=={0,18}
 for label,rows in [('normal',normal),('full',full)]:
  (w/f'{label}-{width}.json').write_text(json.dumps(dict(cases=rows,seed=new['seed'],properties=[],lattice=[])))
print('arithmetic rows',len(old['cases']),len(new['cases']),'property queries',len(old['properties']),len(new['properties']),'SHA256',hashlib.sha256((w/'after.json').read_bytes()).hexdigest())
