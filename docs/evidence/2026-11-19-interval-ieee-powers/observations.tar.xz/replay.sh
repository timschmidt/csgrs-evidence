set -eu
. /mnt/development/.interval-refactor-build/ieee-powers.c8DISS/env
v=$1; target=$2
p="$w/suite-$v-$target"; out="$w/final/$v-$target"; mkdir -p "$out"
c=crates/hyperinterval/conformance/wasm-float
opts=()
if [ "$target" = wasm32-wasip1 ]; then opts=(--wasi-p1); fi
node "$c/check.mjs" "$p/interval_float.wasm" "$w/after.json" "${opts[@]}" > "$out/execute.log"
node "$c/stack.mjs" "$p/interval_float.wasm" "$p/module.wat" "$w/after.json" > "$out/guest-stack.log"
node "$c/check.mjs" "$p/interval_layout.wasm" "$w/after.json" --lattice "${opts[@]}" > "$out/lattice.log"
node "$c/check.mjs" "$p/interval_dyadic.wasm" "$w/after.json" --egress "${opts[@]}" > "$out/dyadic.log"
