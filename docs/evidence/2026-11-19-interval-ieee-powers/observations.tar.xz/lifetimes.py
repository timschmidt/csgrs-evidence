from pathlib import Path
import json,os,subprocess,sys
w=Path(__file__).parent
if len(sys.argv)==4:
 v,t,k=sys.argv[1:]
 cg=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
 assert int((cg/'memory.max').read_text())==256<<20 and int((cg/'memory.swap.max').read_text())==0
 repo=w/'control' if k=='before' else Path('/mnt/development/csgrs')
 p=subprocess.run([w/'bin/node',repo/'crates/hyperinterval/conformance/wasm-float/check.mjs',w/f'original-{v}-{t}.wasm',w/f'{k}.json',*(['--wasi-p1'] if t=='wasm32-wasip1' else [])],check=True,capture_output=True)
 r=json.loads(p.stdout)
 assert r['cases']==(55802 if k=='before' else 55988) and r['endpoint_traps']==24
 events={a:int(b) for a,b in (line.split() for line in (cg/'memory.events').read_text().splitlines())}
 peak=int((cg/'memory.peak').read_text());assert not any(events.values()) and peak<=192<<20
 print(json.dumps(dict(toolchain=v,target=t,stage=k,peak=peak,events=events)))
else:
 results=[]
 for v in ('1.88.0','1.95.0','stable'):
  for t in ('wasm32-unknown-unknown','wasm32-wasip1'):
   for rep in range(5):
    order=('before','after') if rep%2==0 else ('after','before')
    for k in order:
     cmd=['systemd-run','--quiet','--user','--scope','-p','MemoryMax=256M','-p','MemorySwapMax=0',sys.executable,__file__,v,t,k]
     results.append(json.loads(subprocess.check_output(cmd,text=True)))
 (w/'lifetimes.json').write_text(json.dumps(results,indent=2)+'\n')
