from pathlib import Path
import hashlib,importlib.util,io,json,lzma,subprocess,tarfile,shutil
s=Path(__file__).parent;r=Path('/mnt/development/csgrs');e=r.parent/'csgrs-evidence'
key='docs/evidence/2026-11-19-interval-ieee-powers'
def git(repo,*args):return subprocess.check_output(['git','-C',repo,*args])
def h(b):return hashlib.sha256(b).hexdigest()
files={}
def add(p,name=None):files[name or str(p.relative_to(s))]=p.read_bytes()
for n in ['after.json','result.json','lifetimes.json','final-generation.json','final-timing.json','scope','source-commit','method.md','guest.sh','sysroot.py','run-suites.sh','replay.sh','mutations.sh','truncate.patch','inward.patch','retained.patch','check-corpus.py','verify-allowances.mjs','mutation-check.mjs','final-cases.sh','lifetimes.py','fixed-generator-jobs.py','fixed-timing.py','account.py','pack.py','env','bin/chromium-local']:
 add(s/n)
for p in sorted((s/'logs').iterdir()):
 if p.name in ('timing','jobs','generation'):continue
 add(p)
for p in sorted(s.glob('suite-*/report.json')):
 k=p.parent.name[6:]
 for f in p.parent.glob('*.log'):add(f,'build/'+k+'/'+f.name)
 for n in ('report.json','commands.json'):add(p.parent/n,'build/'+k+'/'+n)
 for f in (s/'final'/k).glob('*.log'):add(f)
assert len(list(s.glob('final/*/execute.log')))==6
for t in ['1.88.0','1.95.0','stable']:assert json.loads(files['logs/final-browser-'+t])['cases']==55988
for m in ['truncate','inward']:
 assert json.loads(files['logs/'+m+'-before'])['cases']==55802
 for group in ('near','normal','full'):
  for width in (32,64):assert b'Error: Case ' in files[f'logs/final-{m}-{group}-{width}']
header=(s/'source-commit').read_text().strip()
for n in git(r,'diff-tree','--no-commit-id','--name-only','-r',header).decode().splitlines():files['source/'+n]=git(r,'show',header+':'+n)
assert not git(e,'status','--porcelain') and not (e/key).exists()
assert shutil.disk_usage(e).free > 20*1024**3
dest=e/key;dest.mkdir()
index={k:h(v) for k,v in sorted(files.items())}
with tarfile.open(dest/'observations.tar.xz','w:xz') as tar:
 for k,b in sorted(files.items()):
  m=tarfile.TarInfo(k);m.size=len(b);tar.addfile(m,io.BytesIO(b))
(dest/'sha256.json.xz').write_bytes(lzma.compress(json.dumps(index,indent=1).encode()))
git(e,'add','--sparse','--',key)
assert len(git(e,'diff','--cached','--name-only').splitlines())==2
git(e,'-c','gc.auto=0','commit','-m','Archive directed higher-power qualification on six WebAssembly targets and toolchains')
head=git(e,'rev-parse','HEAD').decode().strip()
def blob(n):return git(e,'show',head+':'+key+'/'+n)
with tarfile.open(fileobj=io.BytesIO(blob('observations.tar.xz')),mode='r:xz') as ar:assert {m.name:h(ar.extractfile(m).read()) for m in ar}==index==json.loads(lzma.decompress(blob('sha256.json.xz')))
spec=importlib.util.spec_from_file_location('archive',r/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={key:False}
row=m.manifest(str(e),head)[1];p=r/'docs/evidence-archive.tsv';old=git(r,'show','HEAD:docs/evidence-archive.tsv');assert p.read_bytes()==old and key not in old.decode()
with p.open('a') as f:f.write(row+'\n')
assert p.read_bytes()==old+(row+'\n').encode()
(s/'archive.json').write_text(json.dumps(dict(members=len(files),commit=head,row=row),indent=2)+'\n')
