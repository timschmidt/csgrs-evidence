import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const [guest, corpus, checker] = process.argv.slice(2);
const {verifyInstance}=await import(pathToFileURL(checker));
const {instance}=await WebAssembly.instantiate(await readFile(guest));
const data=JSON.parse(await readFile(corpus));
console.log(JSON.stringify(verifyInstance(instance.exports,data)));
