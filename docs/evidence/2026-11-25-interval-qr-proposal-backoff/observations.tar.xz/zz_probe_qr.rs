#![cfg(feature = "qr-evolution")]
use hyperdynamics::field::{
    EnclosureBudget, EnclosurePolicy, ExpressionField, FieldDefinition,
    coordinates::{CoordinateField, qr_evolution::{QrEvolutionOptions, QrEvolutionStatus, QrFrameChoice, QrProposalPolicy}},
    evolution::{EvolutionOptions, EvolutionRequest},
};
use hyperinterval::DyadicInterval;
use hyperlattice_interval::BoxN;
use hyperreal::{Rational, Real};
use hypersolve::{Expr, SymbolId, expression_program::{CoordinateChange, ExpressionBudget, ExpressionProgram}};
const T: SymbolId = SymbolId(100);
fn s(i: u32) -> Expr { Expr::anonymous_symbol(SymbolId(i)) }
fn b() -> EnclosureBudget { EnclosureBudget::new(EnclosurePolicy { graph_entries: 100_000_000, graph_work: 1 << 40, scalar_work: 1 << 62, ..EnclosurePolicy::default() }) }
fn field<const N: usize>(outputs: &[Expr]) -> ExpressionField<N> {
    let state: Vec<_> = (0..N as u32).map(SymbolId).collect();
    let mut v = state.clone(); v.push(T);
    let p = ExpressionProgram::compile(outputs, &v, &mut ExpressionBudget::new(100_000, 10_000_000)).unwrap();
    ExpressionField::from_definition(FieldDefinition { source: p.definition().clone(), time: T, state }, &mut b()).unwrap()
}
fn r(n: i64, d: i64) -> Real { Real::from(Rational::from(n) / Rational::from(d)) }
fn chart<const N: usize>(f: &ExpressionField<N>, a: Option<(Vec<Vec<Real>>, Vec<Vec<Real>>)>) -> CoordinateField<N> {
    let id: Vec<Vec<Real>> = (0..N).map(|i| (0..N).map(|j| Real::from(u8::from(i == j))).collect()).collect();
    let (to, from) = a.unwrap_or((id.clone(), id));
    f.in_coordinates(CoordinateChange { variables: (0..N).map(|i| SymbolId(i as u32)).collect(), to_source: to, from_source: from, origin: vec![Real::zero(); N] }, &mut b()).unwrap()
}
fn lg(x: &DyadicInterval) -> f64 {
    let r = x.width(&mut hyperinterval::DyadicBudget::new(1 << 20, 1 << 40)).unwrap();
    let (m, e) = r.upper().unwrap();
    let d = m.to_string(); let k = d.len().min(17);
    d[..k].parse::<f64>().unwrap().log10() + (d.len() - k) as f64 + e as f64 * 2f64.log10()
}
fn run<const N: usize>(name: &str, c: &CoordinateField<N>, center: [i64; N], cexp: i32, radius: i32, end: (i64, i32), window: i32) {
    for order in [None, Some(3)] {
        for policy in [QrProposalPolicy::EveryWindow, QrProposalPolicy::Backoff { maximum_interval: 16 }] {
            let initial = BoxN::new(std::array::from_fn(|i| {
                let m = center[i] << (cexp - radius);
                DyadicInterval::new((m - 1).into(), (m + 1).into(), radius).unwrap()
            })).unwrap();
            let request = EvolutionRequest { start: DyadicInterval::point(0.into(), 0).unwrap(), end: DyadicInterval::point(end.0.into(), end.1).unwrap(), initial };
            let mut best = f64::MAX; let mut out = None;
            for _ in 0..3 {
                let t0 = std::time::Instant::now();
                let r = c.integrate_qr(request.clone(), QrEvolutionOptions { window: DyadicInterval::point(1.into(), window).unwrap(), maximum_windows: 1000, taylor_order: order, native: EvolutionOptions { maximum_step: Some(DyadicInterval::point(1.into(), window - 1).unwrap()), ..Default::default() }, proposals: policy }, &mut b());
                best = best.min(t0.elapsed().as_secs_f64()); out = Some(r);
            }
            let r = out.unwrap();
            let choices: String = r.completed_windows().iter().map(|w| match (w.deferred(), w.choice().unwrap()) { (true, _) => '.', (false, QrFrameChoice::Proposed) => 'P', (false, QrFrameChoice::Retained) => 'R' }).collect();
            let diam = r.prefix_source_end_enclosure().map(|e| e.lanes().unwrap().iter().map(lg).fold(f64::MIN, f64::max)).unwrap_or(f64::NAN);
            let ok = matches!(r.status(), QrEvolutionStatus::Completed);
            let pol = if matches!(policy, QrProposalPolicy::EveryWindow) { "every" } else { "backoff" };
            println!("{name:10} order={order:?} {pol:7} ok={ok} reached={:?} time={best:.3}s log10diam={diam:.3} choices={choices}", r.reached_time().upper());
        }
    }
}
#[test]
fn probe() {
    let rot = field::<2>(&[-s(1), s(0)]);
    run::<2>("rotation", &chart(&rot, None), [1, 0], 0, -6, (4, 0), -3);
    let sad = field::<2>(&[s(1), s(0)]);
    run::<2>("saddle", &chart(&sad, None), [1, 0], 0, -6, (2, 0), -3);
    let pen = field::<2>(&[s(1), -s(0).sin()]);
    run::<2>("pendulum", &chart(&pen, None), [1, 0], -1, -6, (4, 0), -3);
    let sheared = Some((vec![vec![r(1, 1), r(1, 1)], vec![r(0, 1), r(2, 1)]], vec![vec![r(1, 1), r(-1, 2)], vec![r(0, 1), r(1, 2)]]));
    run::<2>("pend-shear", &chart(&pen, sheared.clone()), [1, 0], -1, -10, (2, 0), -3);
    let ell = field::<2>(&[Expr::int(4) * s(1), -s(0)]);
    let lower = Some((vec![vec![r(1, 1), r(0, 1)], vec![r(1, 1), r(1, 1)]], vec![vec![r(1, 1), r(0, 1)], vec![r(-1, 1), r(1, 1)]]));
    run::<2>("ellipse-lo", &chart(&ell, lower), [1, 0], 0, -6, (4, 0), -3);
    let sh = field::<2>(&[Expr::int(4) * s(1), Expr::int(0)]);
    run::<2>("shear-shear", &chart(&sh, sheared), [1, 0], 0, -6, (2, 0), -3);
}
