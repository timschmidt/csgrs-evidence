from pathlib import Path
import json
s=Path(__file__).parent;root=Path.cwd()
metrics=json.loads((s/'results.json').read_text())['linked']
name='wasip1_float_qualification'
source={'fixed':'c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb','preceding':(s/'baseline').read_text().strip(),'fixed_lattice_client_first_revision':'700888155','real_bridge_client_first_revision':'3ad284efe'}
result={'benefit':'Explicit qualification of binary32/binary64, lattice composition and dyadic conversions on ordinary WASI Preview 1. All previous feature configurations retain their artifact bytes.','evidence':'docs/evidence/2026-11-18-interval-wasip1-qualified','source':source,'toolchain':'Rust 1.95.0, locked release artifacts, identical Cargo home and source path per stage. File, Wasm code section and sum of function bodies are independently measured.','existing':{'caps':{'incremental_bytes':128,'incremental_percent':0.25,'cumulative_bytes':512,'cumulative_percent':1},'default_requalified':{},'explicit_feature_on_other_targets':{}},'new_selected_preview1':{}}
for key,a in metrics.items():
 isnew=key in ['p1-float.wasm','p1-layout.wasm','p1-dyadic.wasm']
 isprim=key.endswith('-float.wasm')
 cap=128*1024 if isprim else 4*1024**2;reserve=16*1024 if isprim else 1024**2
 prev,base,cur,sel,auto=map(a.get,['preceding','fixed','default','selected','automatic'])
 assert prev==cur
 measures=['file','code','function_bodies']
 # Preserve individual charges, including a positive delta not cancelled by another artifact.
 charges={}
 for k in measures:
    assert cur[k]==base[k] and prev[k]==cur[k]
    charges[k]={'fixed':base[k],'preceding':prev[k],'retained':cur[k],'incremental_charge':0,'cumulative_charge':0}
 result['existing']['default_requalified'][key]={'metrics':charges,'file_sha256':cur['sha256'],'slot_bytes':cap,'minimum_free_bytes':reserve,'free_bytes':cap-cur['file']}
 assert cap-cur['file']>=reserve
 if isnew:
    first={'p1-float.wasm':65536,'p1-layout.wasm':640*1024,'p1-dyadic.wasm':96*1024}[key]
    rec={'slot_bytes':cap,'minimum_free_bytes':reserve,'free_bytes':cap-sel['file'],'first_release_cap_bytes':first,'first_release_cap_percent_of_slot':100*first/cap,'comparable_completed_revision':'nonretained automatic same-ABI selector, same final client','comparable_incremental_cap_bytes':128,'comparable_incremental_cap_percent':0.25,'metrics':{}}
    for k in measures:
        charge=max(0,sel[k]-auto[k])
        assert sel[k]<=first and charge<=128 and charge*100<=auto[k]*.25
        rec['metrics'][k]={'default_abi_build':cur[k],'default_to_enabled_delta':sel[k]-cur[k],'automatic_completed':auto[k],'retained_enabled':sel[k],'initial_cumulative_charge':sel[k],'remaining_initial_budget_bytes':first-sel[k],'additional_charge_vs_completed':charge,'remaining_comparison_bytes':128-charge,'remaining_comparison_percent':round(.25-charge*100/auto[k],6)}
    if isprim:
        assert sel['code']<=56*1024
        bare=metrics['bare-float.wasm']['selected']
        for k in ('file','code'):assert sel[k]-bare[k]<=4096
        rec['extra_scalar_code_cap_bytes']=56*1024;rec['remaining_scalar_code_bytes']=56*1024-sel['code']
    result['new_selected_preview1'][key]=rec
 else:
    delta={}
    for k in measures:
        add=max(0,sel[k]-cur[k]);cum=max(0,sel[k]-base[k])
        assert add<=128 and add*100<=.25*cur[k] and cum<=512 and cum*100<=base[k]
        delta[k]={'retained':sel[k],'incremental_charge':add,'cumulative_charge':cum,'remaining_incremental_bytes':128-add,'remaining_cumulative_bytes':512-cum,'remaining_incremental_percent':round(.25-add*100/cur[k],6),'remaining_cumulative_percent':round(1-cum*100/base[k],6)}
    result['existing']['explicit_feature_on_other_targets'][key]={'metrics':delta,'free_bytes':cap-sel['file'],'selection':'forwarded for scalar, dyadic and mixed lattice; fixed-only and Real bridge controls do not select this feature'}
 assert cap-sel['file']>=reserve
p=root/'docs/research/interval-size-accounts.json';d=json.loads(p.read_text());assert name not in d;d[name]=result
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
