from pathlib import Path
import io,json,hashlib,subprocess as sp,re
s=Path(__file__).parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def leb(data):
 n=0;shift=0
 while True:
    b=data.read(1);assert b
    n|=(b[0]&127)<<shift
    if b[0]<128:return n
    shift+=7
def wasm(p):
 raw=p.read_bytes();r=io.BytesIO(raw);assert r.read(8)==b'\0asm\x01\0\0\0';sections={}
 while token:=r.read(1):
    length=leb(r);blob=r.read(length);assert len(blob)==length
    if token==b'\0':
        part=io.BytesIO(blob);name=part.read(leb(part)).decode()
    else:name=str(token[0])
    assert name not in sections
    sections[name]={'bytes':length,'sha256':sha(blob)}
    if token==b'\x0a':
        part=io.BytesIO(blob);bodies=[part.read(leb(part)) for _ in range(leb(part))];assert not part.read()
        func=sum(map(len,bodies));count=len(bodies)
 return {'file':len(raw),'code':sections['10']['bytes'],'function_bodies':func,'functions':count,'sha256':sha(raw),'sections':sections}
m={}
for p in sorted((s/'matched-preceding').glob('*.wasm')):
 f=p.name;k=f.split('-')[1].split('.')[0];key='first-'+k if k in ('fixed','bridge') else 'fixed'
 z={t:wasm(s/('matched-'+stage)/f) for t,stage in [('fixed',key),('preceding','preceding'),('default','default'),('selected','selected'),('automatic','automatic')]}
 print(f,[v['file'] for v in z.values()],[v['code'] for v in z.values()],z['preceding']['sha256']==z['default']['sha256'])
 assert z['preceding']==z['default'];m[f]=z
r={'linked':m,'memory':{},'runs':{},'native':{},'board':{}}
for v in ['1.88.0','1.95.0','stable']:
 for t in ['p1','bare']:
    rep=json.loads((s/f'tuple-{v}-{t}/report.json').read_text())
    obs=json.loads((s/f'stack-{v}-{t}.json').read_text())
    assert obs==rep['guest_stack']
    assert all(x['reservedBytes']==x['touchedBytes']==704 for x in obs)
    r['runs'][v+'/'+t]={k:rep[k] for k in ['cases','properties','binary_sha256','fixed_lattice','lattice','real_bridge','dependencies','guest_stack']}
for k in ['preceding','candidate','tuple']:
 p=s/('native-'+k);r['native'][k]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
assert r['native']['tuple']==r['native']['preceding']
for k in ['preceding','candidate','optional','isolated','tuple','matched_previous']:
 p=s/f'board-{k}.elf';log=(s/f'package-{k}.log').read_text();app=int(re.search(r'Supplied ELF image of (\d+)B',log)[1]);cap=int(re.search(r'partition of (\d+)B',log)[1])
 r['board'][k]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'app_bytes':app,'partition':cap,'shortfall':app-cap}
assert r['board']['tuple']==r['board']['matched_previous'] and r['board']['isolated']==r['board']['preceding']
names=['preceding-bare','candidate-bare','candidate-p1','tuple-p1'];fu=[(s/('fuel-'+k+'.json')).read_bytes() for k in names]
assert all(z==fu[0] for z in fu);vals=json.loads(fu[0]);r['fuel']={'calls':len(vals),'total':sum(vals),'maximum':max(vals),'sha256':sha(fu[0])}
(s/'results.json').write_text(json.dumps(r,indent=2)+'\n')
