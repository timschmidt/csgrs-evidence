set -eu
s=/dev/shm/interval-wasi-reconsider
. /dev/shm/hyperinterval-coverage/env
unset RUSTUP_TOOLCHAIN CARGO_TARGET_DIR CARGO_PROFILE_TEST_DEBUG CARGO_PROFILE_RELEASE_DEBUG RUSTFLAGS CARGO_ENCODED_RUSTFLAGS ALUMINA_AP_PASSWORD
export CARGO_HOME=/dev/shm/interval-wasi-reconsider/registry-home
export CARGO_BUILD_JOBS=8 CARGO_INCREMENTAL=0
cd "$s/board/alumina-firmware"
for tag in matched_previous; do
  cargo +1.88.0 run --locked -p xtask -- build --board mks-esp32-foc-v1 --profile release > "$s/board-$tag.log" 2>&1
  file=$(sed -n 's/^board-qualified artifact: //p' "$s/board-$tag.log" | tail -1)
  cp "$file" "$s/board-$tag.elf"
  if /dev/shm/interval-inverse-clarke/espflash save-image --chip esp32 --flash-size 4mb --merge --skip-padding "$file" "$s/board-$tag.bin" > "$s/package-$tag.log" 2>&1; then echo "image fit"; else rg 'fit configured app' "$s/package-$tag.log"; fi
done
