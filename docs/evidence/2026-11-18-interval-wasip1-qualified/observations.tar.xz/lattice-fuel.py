from pathlib import Path
import json,wasmtime as wt
s=Path(__file__).parent;cfg=wt.Config();cfg.consume_fuel=True;e=wt.Engine(cfg)
corpus=json.loads((s/'tuple-1.95.0-p1/corpus.json').read_text())['lattice']
tables={}
for stage,target in [('preceding','p1'),('preceding','bare'),('automatic','p1'),('selected','p1')]:
    out={};st=wt.Store(e);st.set_fuel(1000000000);wasi=wt.WasiConfig();st.set_wasi(wasi)
    linker=wt.Linker(e);linker.define_wasi();m=wt.Module.from_file(e,str(s/('matched-'+stage)/(target+'-layout.wasm')));ex=linker.instantiate(st,m).exports(st)
    for action in ['floating','fixed']:
        if action=='floating' and (stage,target)==('preceding','p1'):continue
        fuel=[];fn=ex[action]
        for width,dim,seed,lower,upper,lo,hi in corpus:
            for soa in [0,1]:
                for which in [0,1]:
                    st.set_fuel(1000000000);value=fn(st,soa,int(width==64),dim,seed,which)
                    if action=='fixed':expected=int([lo,hi][which])<<(24 if width==64 else 0)
                    else:value%=2**64;expected=int([lower,upper][which],0)
                    assert value==expected,(value,expected)
                    fuel.append(1000000000-st.get_fuel())
        out[action]=fuel
    tables[stage+'/'+target]=out
(s/'lattice-fuel.json').write_text(json.dumps(tables,separators=(',',':'))+'\n')
for name,rows in tables.items():print(name,{k:(len(v),sum(v),max(v)) for k,v in rows.items()})
