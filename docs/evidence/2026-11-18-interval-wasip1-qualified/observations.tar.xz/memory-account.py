from pathlib import Path
import json
s=Path(__file__).parent;p=Path('docs/research/interval-memory-accounts.json');doc=json.loads(p.read_text())
r=json.loads((s/'results.json').read_text());rows=json.loads((s/'downstream-frames.json').read_text());ctrl=json.loads((s/'control-frames.json').read_text())
def comparable(data,key):
 return [{k:v for k,v in d.items() if k!='name'} for d in data if d['name']==key]
assert comparable(rows,'automatic')==comparable(rows,'selected')
assert comparable(ctrl,'old-fixed')==comparable(ctrl,'new-fixed')
for new,old in zip(comparable(rows,'selected'),comparable(ctrl,'bare'),strict=True):
 for k in new:
    if k in ('initial','final'):assert new[k]<=old[k]
    else:assert new[k]==old[k]
rec={'source':(s/'source-revision').read_text().strip(),'evidence':'docs/evidence/2026-11-18-interval-wasip1-qualified','target':'Rust 1.95 wasm32-wasip1, opt-in scalar and mixed lattice/dyadic release conformance clients','basis':'New target registration. All previously selected default artifacts remain byte-identical. Existing successful fixed-only WASI work is measured before and after selection. New mixed arithmetic is compared with the previously supported bare workload and the automatic same-ABI prototype. The stack and requested-heap observations match the controls. Bare dyadic conversion committed one extra 64 KiB linear-memory page; ordinary Preview 1 stayed at its initial capacity. No positive memory exception is charged.','memory_model':'Single guest instance at a time. Cold/warm, two fresh instances with complementary stack fills. Record original linked primitive writes, instrumented SP minima, and Rust system allocator requests in the standard-library clients, including releases through completed output. Guest linear memory never grew. Engine/host memory is outside this account.','guest_stack_capacity_bytes':1048576,'guest_linear_initial_and_final_bytes':1114112,'primitive_reserved_cap_bytes':2048,'primitive_observed_stack_bytes':704,'primitive_free_stack_bytes':1048576-704,'primitive_retained_heap_bytes':0,'primitive_temporary_heap_bytes':0,'other_columns':['reserved_stack_bytes','deepest_touched_bytes','free_stack_bytes','peak_requested_heap_bytes','retained_heap_bytes','allocations','deallocations','reallocations']}
rec['other_completed_workloads']={}
for key,seq in [('mixed lattice',comparable(rows,'selected')),('fixed-only lattice',comparable(ctrl,'old-fixed')),('dyadic conversions',comparable(rows,'selected'))]:
 c='dyadic' if key.startswith('dyadic') else 'layout'
 sample=[r for r in seq if r['kind']==c]
 vals=lambda k:max(r[k] for r in sample)
 rec['other_completed_workloads'][key]=[vals('reserved'),vals('touched'),1048576-vals('reserved'),vals('logical_peak'),vals('retained'),vals('alloc'),vals('free'),vals('realloc')]
doc['wasip1_qualification']=rec;p.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
