// Rust's target cfgs coincide for wasm32-wasip1 and wasm32-wasip1-threads.
// Only the first has qualified the import-free IEEE reactor.
fn main() {
    println!("cargo::rerun-if-changed=build.rs");
    println!("cargo::rustc-check-cfg=cfg(interval_wasip1)");
    if std::env::var("TARGET").as_deref() == Ok("wasm32-wasip1") {
        println!("cargo::rustc-cfg=interval_wasip1");
    }
}
