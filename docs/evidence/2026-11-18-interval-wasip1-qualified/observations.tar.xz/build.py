from pathlib import Path
import subprocess as sp,os,sys,shutil
s=Path(__file__).parent;src=s/'src'
targets={'bare':'wasm32-unknown-unknown','p1':'wasm32-wasip1','threads':'wasm32-wasip1-threads','none':'wasm32v1-none'}
clients={'float':('hyperinterval/conformance/wasm-float','interval_float_wasm_conformance'),'layout':('hyperlattice-interval/conformance/primitive-layouts/wasm','interval_layout_wasm'),'fixed':('hyperlattice-interval/conformance/fixed-wasm','interval_fixed_lattice_wasm'),'dyadic':('hyperinterval/conformance/wasm-dyadic','interval_dyadic_wasm_conformance'),'bridge':('hyperinterval/conformance/wasm-real-bridge','interval_real_bridge_wasm_conformance')}
tag,compiler=sys.argv[1:3];out=s/tag/compiler;out.mkdir(parents=True,exist_ok=True)
for k in sys.argv[3:]:
  t=targets[k]
  for c,(path,stem) in clients.items():
    if (k in ['threads','none'] and c!='float') or (compiler=='1.88.0' and c=='bridge'):continue
    manifest=src/'crates'/path/'Cargo.toml'
    sp.run(['cargo','+'+compiler,'build','--locked','--release','--target',t,'--manifest-path',manifest],cwd=src,check=True)
    shutil.copyfile(Path(os.environ['CARGO_TARGET_DIR'])/t/'release'/(stem+'.wasm'),out/(k+'-'+c+'.wasm'))
