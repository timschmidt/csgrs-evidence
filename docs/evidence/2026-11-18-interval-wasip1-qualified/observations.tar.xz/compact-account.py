from pathlib import Path
import json
p=Path('docs/research/interval-size-accounts.json');name='wasip1_float_qualification';doc=json.loads(p.read_text());a=doc[name];m=a['existing'];r={k:a[k] for k in ['benefit','evidence','source','toolchain']}
r['metrics']=['file','code','function_bodies']
r['slots']={'primitive_capacity':131072,'primitive_reserve':16384,'other_capacity':4194304,'other_reserve':1048576}
r['existing_caps']=m['caps']
r['default_requalification']='Each row gives the same three values for fixed, preceding and retained. Incremental and cumulative charges are zero. The full file and section hashes, including first-revision references for the two newer clients, are in results.json.'
r['default_columns']=[*r['metrics'],'remaining_slot_bytes']
r['default_artifacts']={k:[*(v['metrics'][i]['retained'] for i in r['metrics']),v['free_bytes']] for k,v in m['default_requalified'].items()}
r['explicit_feature_comparisons']='On other targets, file, code and function bodies have zero positive charges except the listed row. This includes both unsupported ABI controls. The fixed-only and Real bridge controls keep their original feature sets. Positive charges never offset another artifact.'
r['existing_positive_charges']={k:{i:v['metrics'][i] for i in r['metrics'] if v['metrics'][i]['cumulative_charge'] or v['metrics'][i]['incremental_charge']} for k,v in m['explicit_feature_on_other_targets'].items() if any(v['metrics'][i]['cumulative_charge'] or v['metrics'][i]['incremental_charge'] for i in r['metrics'])}
r['new_preview1']='Each explicit opt-in artifact has a separate host test slot. Its full retained size is charged at introduction. Percentage caps refer to slot capacity. An additional 128-byte AND 0.25% cap applies against the unretained automatic implementation on the same completed contract. Existing default builds keep their original accounting.'
r['new_metric_columns']=['default_abi_build','default_to_enabled_delta','automatic_completed','initial_cumulative_charge','remaining_initial_budget_bytes','additional_charge_vs_completed','remaining_comparison_bytes','remaining_comparison_percent']
r['new_artifacts']={}
for k,v in a['new_selected_preview1'].items():
    z={i:v[i] for i in ['first_release_cap_bytes','first_release_cap_percent_of_slot','free_bytes']}
    if k=='p1-float.wasm':z.update(extra_scalar_code_cap_bytes=v['extra_scalar_code_cap_bytes'],remaining_scalar_code_bytes=v['remaining_scalar_code_bytes'])
    for metric in r['metrics']:z[metric]=[v['metrics'][metric][c] for c in r['new_metric_columns']]
    r['new_artifacts'][k]=z
doc[name]=r
p.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n')
