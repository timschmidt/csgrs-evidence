import {readFile} from "node:fs/promises";
import {verifyInstance} from "./src/crates/hyperinterval/conformance/wasm-float/check.mjs";
const root=new URL("./",import.meta.url);
const corpus=JSON.parse(await readFile(new URL("tuple-1.95.0-p1/corpus.json",root)));
const names=["automatic","selected"];
const apis={};
const reverse=Number(process.argv[2])%2;
for(const k of reverse?[...names].reverse():names){
 const bytes=await readFile(new URL("matched-"+k+"/p1-float.wasm",root));
 const {instance}=await WebAssembly.instantiate(bytes);apis[k]=instance.exports;
}
for(let i=0;i<21;i++){
 const row={};
 for(const k of (i+reverse)%2?[...names].reverse():names){
  const start=process.hrtime.bigint();
  const result=verifyInstance(apis[k],corpus);
  row[k]=Number(process.hrtime.bigint()-start);
  if(result.cases!==55802 || result.properties!==8836)throw Error("incomplete corpus");
 }
 if(i>=5)console.log(JSON.stringify(row));
}
