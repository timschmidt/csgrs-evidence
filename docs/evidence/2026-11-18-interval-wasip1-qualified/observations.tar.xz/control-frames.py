from pathlib import Path
import re,subprocess as sp
s=Path(__file__).parent
for variant in ['old-fixed','new-fixed','bare']:
 for c in ['layout','dyadic']:
    if variant.endswith('fixed') and c!='layout': continue
    stage='selected' if variant=='new-fixed' else 'preceding'
    target='bare' if variant=='bare' else 'p1'
    f=s/('matched-'+stage)/(target+'-'+c+'.wasm');a=sp.check_output(['wasm-dis',f],text=True)
    assert a.count('(global $__stack_pointer (mut i32) (i32.const 1048576))')==1
    a=a.replace('(global.set $__stack_pointer','(call $track_sp')
    n=0
    for k,params,index,size in [('alloc',2,0,0),('realloc',4,0,3),('dealloc',3,0,1)]:
        pat=r'^ \(func (\$\w+___rdl_'+k+r') (?=\(param)'
        match,=re.finditer(pat,a,re.M);name=match[1];a=a[:match.start(1)]+name+'_original'+a[match.end(1):]
        imp=f'(import "heap" "{k}" (func $track_{k} (param i32 i32 i32 i32)))'
        a=a.replace('\n (global ', '\n '+imp+'\n (global ',1)
        args=' '.join(f'(local.get {i})' for i in range(params))
        ret='' if k=='dealloc' else '(result i32) (local $returned i32)'
        call=f'(call {name}_original {args})'
        if k=='dealloc':body=f'{call} (call $track_dealloc (local.get 0) (local.get 1) (i32.const 0) (i32.const 0))'
        else:
            old='(local.get 0) (local.get 1)' if k=='realloc' else '(i32.const 0) (i32.const 0)'
            body=f'(local.set $returned {call}) (call $track_{k} {old} (local.get $returned) (local.get {size})) (local.get $returned)'
        wrapper=f'(func {name} (param {" ".join(["i32"]*params)}) {ret} {body})'
        a=a.rstrip()[:-1]+' '+wrapper+'\n)';n+=1
    assert n==3
    a=a.rstrip()[:-1]+'''
 (global $min (mut i32) (i32.const 1048576))
 (export "probe_min" (global $min)) (export "probe_sp" (global $__stack_pointer))
 (func $track_sp (param $value i32)
    (global.set $__stack_pointer (local.get $value))
    (if (i32.lt_u (local.get $value) (global.get $min)) (then (global.set $min (local.get $value)))))
)'''
    p=s/f'frames-{variant}-{c}.wat';p.write_text(a);sp.run(['wasm-as',p,'--all-features','-o',p.with_suffix('.wasm')],check=True)
