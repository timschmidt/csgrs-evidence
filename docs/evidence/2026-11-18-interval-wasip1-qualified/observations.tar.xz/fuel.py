from pathlib import Path
from collections import defaultdict
import json,sys,wasmtime as w
s=Path(__file__).parent;tag,key=sys.argv[1:]
cfg=w.Config();cfg.consume_fuel=True;engine=w.Engine(cfg);st=w.Store(engine)
mod=w.Module.from_file(engine,str(s/tag/'1.95.0'/(key+'-float.wasm')));assert not mod.imports
st.set_fuel(1000000);api=w.Instance(st,mod,[]).exports(st);assert api['qualification'](st)==3
corpus=json.loads((s/'run-1.95.0-p1/corpus.json').read_text());raw=[];totals=defaultdict(list)
def num(n):return int(n,0) if isinstance(n,str) else n
def check(fn,label,args,expected):
    st.set_fuel(1000000);actual=fn(st,*args)%(1<<64)
    assert actual==num(expected),(label,args,actual,expected)
    used=1000000-st.get_fuel();raw.append(used);totals[label].append(used)
for width,op,flags,a,b,c,d,e,status,*ends in corpus['cases']:
    f=api['query'+str(width)];args=[flags,*map(num,(a,b,c,d)),e]
    check(f,f'{width}/{op}/status',[op,0,*args],status)
    if status in (0,2):
        lower,upper=ends
        check(f,f'{width}/{op}/lower',[op,1,*args],lower);check(f,f'{width}/{op}/upper',[op,2,*args],upper)
for width,flags,a,b,c,d,p,expected in corpus['properties']:
    check(api['properties'+str(width)],f'{width}/property',[flags,*map(num,(a,b,c,d,p))],expected)
name=f'fuel-{tag}-{key}'
(s/(name+'.json')).write_text(json.dumps(raw,separators=(',',':'))+'\n')
(s/(name+'-summary.json')).write_text(json.dumps({k:[len(v),sum(v),max(v)] for k,v in totals.items()},indent=2)+'\n')
print(name,len(raw),sum(raw),max(raw))
