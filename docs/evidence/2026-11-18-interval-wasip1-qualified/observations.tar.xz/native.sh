set -eu
s=/dev/shm/interval-wasi-reconsider
. "$s/env"
cd "$s/src"
for stage in candidate preceding candidate_final; do
    if test "$stage" = preceding; then
        cp crates/hyperinterval/Cargo.toml "$s/qualified-manifest"
        cp crates/hyperinterval/src/float.rs "$s/qualified-float.rs"
        cp crates/hyperinterval/build.rs "$s/qualified-build.rs"
        git restore crates/hyperinterval/Cargo.toml crates/hyperinterval/src/float.rs
        rm crates/hyperinterval/build.rs
    elif test "$stage" = candidate_final; then
        cp "$s/qualified-manifest" crates/hyperinterval/Cargo.toml
        cp "$s/qualified-float.rs" crates/hyperinterval/src/float.rs
        cp "$s/qualified-build.rs" crates/hyperinterval/build.rs
    fi
    cargo +1.95.0 build --locked --release -p hyperinterval --example float_cost --features float-enclosure
    cp "$CARGO_TARGET_DIR/release/examples/float_cost" "$s/native-$stage"
done
