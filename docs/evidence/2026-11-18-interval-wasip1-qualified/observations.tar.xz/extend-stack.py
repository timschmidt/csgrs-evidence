from pathlib import Path
p=Path('crates/hyperinterval/conformance/wasm-float/stack.mjs')
a=p.read_text().replace('import { readFile } from "node:fs/promises";','''import { execFileSync } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";''')
key='const observations = [];'
block='''// Measure unwritten reservations on a second copy. wasm-dis names every
// reference to this global; replace each write with a guest-only observer.
async function measureReservations() {
  const writes = "(global.set $__stack_pointer";
  assert.ok(assembly.includes(writes), "missing guest stack updates");
  assert.doesNotMatch(assembly, /interval_probe_/);
  const instrumented = assembly.trimEnd().replaceAll(writes, "(call $interval_probe_set");
  assert.ok(instrumented.endsWith(")"));
  const source = instrumented.slice(0, -1) + `
    (global $interval_probe_min (mut i32) (i32.const ${stackBytes}))
    (export "interval_probe_min" (global $interval_probe_min))
    (export "interval_probe_sp" (global $__stack_pointer))
    (func $interval_probe_set (param $sp i32)
      (if (i32.gt_u (local.get $sp) (i32.const ${stackBytes})) (then (unreachable)))
      (global.set $__stack_pointer (local.get $sp))
      (if (i32.lt_u (local.get $sp) (global.get $interval_probe_min))
        (then (global.set $interval_probe_min (local.get $sp)))))
  )`;
  const dir = await mkdtemp(join(tmpdir(), "interval-stack-"));
  let tracked;
  try {
    const wat = join(dir, "tracked.wat"), wasm = join(dir, "tracked.wasm");
    await writeFile(wat, source);
    execFileSync("wasm-as", [wat, "--all-features", "-o", wasm]);
    tracked = await WebAssembly.compile(await readFile(wasm));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
  const { exports: api } = await WebAssembly.instantiate(tracked);
  const checked = {};
  for (const [name, fn] of Object.entries(api)) {
    if (typeof fn !== "function") continue;
    checked[name] = (...args) => {
      const result = fn(...args);
      assert.equal(api.interval_probe_sp.value, stackBytes, `${name} left an open stack frame`);
      return result;
    };
  }
  const depths = {};
  for (const temperature of ["cold", "warm"]) {
    api.interval_probe_min.value = stackBytes;
    verifyInstance(checked, corpus);
    depths[temperature] = stackBytes - api.interval_probe_min.value;
  }
  return depths;
}

const reservations = await measureReservations();
'''
a=a.replace(key,block+key)
a=a.replace('touchedBytes: stackBytes - firstWrite, untouchedBytes: firstWrite,','''touchedBytes: stackBytes - firstWrite, untouchedBytes: firstWrite,
      reservedBytes: reservations[temperature],''')
p.write_text(a)
