from pathlib import Path
p=Path('scripts/check_interval_wasm.py');a=p.read_text().replace('"--edges", "normal", "--prefix", "none", *ieee','"--edges", "normal", "--prefix", "none", "--target", target, *ieee')
a=a.replace('    if len(dependencies) != 2 or not any(line.startswith("hyperinterval ") for line in dependencies):','''    expected = ["interval-float-wasm-conformance", "hyperinterval"]
    if target == "wasm32-wasip1":
        expected.append("target-tuple")
    if [line.split()[0] for line in dependencies] != expected:''');p.write_text(a)
p=Path('crates/hyperinterval/README.md');a=p.read_text().replace('and FTZ/DAZ. Nonempty ingress requires x86_64 or wasm32-unknown-unknown; other targets\nreturn UnqualifiedEnvironment. Optional serde validates endpoint bit pairs.', '''and FTZ/DAZ. Nonempty ingress supports x86_64 and wasm32-unknown-unknown.
Enable `float-enclosure-wasip1` to add ordinary wasm32-wasip1 support. Cargo's
exact target name distinguishes it from the threaded Preview 1 ABI. Unqualified
targets return `UnqualifiedEnvironment`. Optional serde validates endpoint bit pairs.''');a=a.replace('enclosures on x86_64 and wasm32-unknown-unknown.','enclosures on x86_64 and wasm32-unknown-unknown, with opt-in wasm32-wasip1 support.');p.write_text(a)
p=Path('crates/hyperlattice-interval/README.md');a=p.read_text();i=a.index('<!-- quickstart:start -->');a=a[:i]+'''The optional `float-enclosure-wasip1` feature forwards ordinary WASI
Preview 1 qualification to Hyperinterval for floating-point lattice operations.

'''+a[i:];p.write_text(a)
p=Path('crates/hyperinterval/CHANGELOG.md');a=p.read_text().replace('## 0.1.0 (unreleased)\n','''## 0.1.0 (unreleased)

- Add opt-in certified binary32 and binary64 enclosures on `wasm32-wasip1`
  through `float-enclosure-wasip1`. The threaded ABI retains typed refusal.
''');p.write_text(a)
p=Path('.github/workflows/hyperinterval.yml');a=p.read_text().replace('rustup target add --toolchain "$INTERVAL_RUST" wasm32-unknown-unknown\n','rustup target add --toolchain "$INTERVAL_RUST" wasm32-unknown-unknown wasm32-wasip1\n',1)
a=a.replace('      - name: Exercise unqualified WASI targets','''          python3 scripts/check_interval_wasm.py --toolchain "$INTERVAL_RUST" --target wasm32-wasip1 --output "$RUNNER_TEMP/interval-float-wasip1"
      - name: Exercise unqualified WASI targets''')
key='          done\n      - name: Verify firmware dependency closure'
a=a.replace(key,'''          done
          cargo +"$INTERVAL_RUST" build --locked --release --target wasm32-wasip1-threads --target-dir "$RUNNER_TEMP/interval-wasi" --manifest-path crates/hyperinterval/conformance/wasm-float/Cargo.toml --features hyperinterval/float-enclosure-wasip1
          node crates/hyperinterval/conformance/wasm-float/unqualified.mjs "$RUNNER_TEMP/interval-wasi/wasm32-wasip1-threads/release/interval_float_wasm_conformance.wasm"
      - name: Verify firmware dependency closure''');p.write_text(a)
p=Path('crates/hyperinterval/conformance/wasm-float/README.md');a=p.read_text().replace('CI builds the same public client for both WASI Preview 1 targets and runs','''Pass `--target wasm32-wasip1` to the Python command to exercise the opt-in
`float-enclosure-wasip1` feature. The no-allocator primitive reactor imports
nothing. The standard-library clients receive only their listed Preview 1
functions. CI also builds the client with its default features on both WASI
Preview 1 targets, and with the opt-in feature on the threaded target, and runs''');p.write_text(a)
