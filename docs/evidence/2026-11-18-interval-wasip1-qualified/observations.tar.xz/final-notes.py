from pathlib import Path
import json,statistics as st,re
s=Path(__file__).parent
l=json.loads((s/'lattice-fuel.json').read_text())
assert l['preceding/p1']['fixed']==l['selected/p1']['fixed']
assert l['automatic/p1']==l['selected/p1']
a={}
for p in sorted(s.glob('timing-*-?.log')):
 r=[json.loads(i) for i in p.read_text().splitlines()]
 assert len(r)==16
 old,new=(st.median(j[k] for j in r) for k in ('automatic','selected'));a[p.name]={'median_automatic_ns':old,'median_selected_ns':new,'percent':100*(new/old-1)}
d={'timings':a,'test_totals':{},'expected_rejections':{},'stacks':json.loads((s/'verified-reserved.json').read_text())}
for n in ['host-all','host-doc-tests','host-min','msrv-host','msrv-layout']:
 data=(s/(n+'.log')).read_text();d['test_totals'][n]=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',data)))
for n,ss in [('tuple-default-negative',3),('tuple-negative',2)]:
 lines=list(map(json.loads,(s/(n+'.log')).read_text().splitlines()));assert len(lines)==ss and all(r['status']==21 and r['endpoint_traps']==8 for r in lines);d['expected_rejections'][n]=lines
assert 'No findings' in (s/'zizmor.log').read_text() and 'Done 10000 runs' in (s/'fuzz-run.log').read_text()
assert 'left an open stack frame' in (s/'verified-leak.log').read_text() and 'does not match linked binary' in (s/'mismatch.log').read_text()
assert '3 !== 0' in (s/'thread-mutant.log').read_text() and all(v['reservedBytes']==4096 and v['touchedBytes']==704 for v in d['stacks'])
(s/'final-notes.json').write_text(json.dumps(d,indent=2)+'\n')
