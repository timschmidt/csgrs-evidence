from pathlib import Path
import os,sys,shutil,subprocess as sp
s=Path(__file__).parent;src=s/'matched';root=Path.cwd()
clients={'float':('hyperinterval/conformance/wasm-float','interval_float_wasm_conformance'),'dyadic':('hyperinterval/conformance/wasm-dyadic','interval_dyadic_wasm_conformance'),'layout':('hyperlattice-interval/conformance/primitive-layouts/wasm','interval_layout_wasm'),'fixed':('hyperlattice-interval/conformance/fixed-wasm','interval_fixed_lattice_wasm'),'bridge':('hyperinterval/conformance/wasm-real-bridge','interval_real_bridge_wasm_conformance')}
targets={'bare':'wasm32-unknown-unknown','p1':'wasm32-wasip1','none':'wasm32v1-none','threads':'wasm32-wasip1-threads'}
def run(*args):sp.run(args,cwd=src,check=True)
def stage(name,rev,keys,selected=False):
 if rev:run('git','switch','--detach',rev)
 out=s/('matched-'+name);out.mkdir(exist_ok=True)
 for k,t in targets.items():
    for c in keys:
        if k in ('none','threads') and c!='float':continue
        p,stem=clients[c];flags=['--features','float-enclosure-wasip1'] if selected and c in ('float','layout','dyadic') else []
        run('cargo','+1.95.0','build','--locked','--release','--target',t,'--manifest-path','crates/'+p+'/Cargo.toml',*flags)
        shutil.copyfile(Path(os.environ['CARGO_TARGET_DIR'])/t/'release'/(stem+'.wasm'),out/(k+'-'+c+'.wasm'))
stage('fixed','c9f1f9ac5',['float','dyadic','layout'])
stage('first-bridge','3ad284efe',['bridge'])
stage('first-fixed','700888155',['fixed'])
stage('preceding','3ebe192ae',clients)
revision=(s/'source-revision').read_text().strip()
for line in sp.check_output(['git','diff','--name-only','3ebe192ae',revision],cwd=root,text=True).splitlines():
 (src/line).write_bytes(sp.check_output(['git','show',revision+':'+line],cwd=root))
stage('default',None,clients)
stage('selected',None,clients,True)
