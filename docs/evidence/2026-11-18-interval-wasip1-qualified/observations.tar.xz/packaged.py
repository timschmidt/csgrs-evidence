from pathlib import Path
import shutil,subprocess as sp,os
s=Path(__file__).parent;root=Path.cwd()
packroot=s/'package-target/package'
crate='hyperinterval';p=s/'package-client';p.mkdir()
src=root/'crates/hyperinterval/conformance/wasm-float'
shutil.copytree(src/'src',p/'src')
manifest=(src/'Cargo.toml').read_text().replace('path = "../.."','version = "=0.1.0"')
manifest+='\n[patch.crates-io]\n'
for crate,version in [('hyperreal','0.14.0'),('hyperinterval','0.1.0')]:
 manifest+=f'{crate} = {{ path = "{packroot}/{crate}-{version}" }}\n'
(p/'Cargo.toml').write_text(manifest)
for target in ('wasm32-wasip1','wasm32-wasip1-threads'):
 for opt in [False,True]:
    opts=['--features','float-enclosure-wasip1'] if opt else []
    argv=['cargo','+1.95.0','build','--offline','--release','--target',target,'--manifest-path',p/'Cargo.toml',*opts]
    sp.run(argv,check=True);img=Path(os.environ['CARGO_TARGET_DIR'])/target/'release/interval_float_wasm_conformance.wasm'
    args=[src/'check.mjs',img,s/'tuple-1.95.0-p1/corpus.json','--wasi-p1'] if opt and target.endswith('p1') else [src/'unqualified.mjs',img]
    sp.run(['node',*args],check=True)
    shutil.copyfile(img,s/f'packaged-{target}-{opt}.wasm')
