//! Cargo target identity for the opt-in Hyperinterval WASI backend.
#![no_std]
#![forbid(unsafe_code)]

/// True only when Cargo selected the ordinary, single-threaded Preview 1 ABI.
pub const ORDINARY_PREVIEW_1: bool = cfg!(interval_wasip1);
