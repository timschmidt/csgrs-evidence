from pathlib import Path
import hashlib,importlib.util,io,json,shutil,subprocess as sp,tarfile
s=Path(__file__).parent;root=Path.cwd();other=root.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-wasip1-qualified'
def git(r,*args):return sp.check_output(['git','-C',r,*args])
assert not git(other,'status','--porcelain')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for p in s.iterdir():
 if p.is_file() and (p.suffix in ('.py','.mjs','.sh','.patch','.log','.json','.txt','.rs') or p.name in ('scope','source-revision','baseline','env','qualified-manifest')):
    if p.name!='isolated-metadata.json':files[p.name]=p.read_bytes()
for p in (s/'isolated-marker').rglob('*'):
 if p.is_file():files[str(p.relative_to(s))]=p.read_bytes()
for tag in ['tuple-1.88.0','tuple-1.95.0','tuple-stable','run-1.95.0','opt-1.95.0','primary']:
 for abi in ['bare','p1']:
    d=s/(tag+'-'+abi)
    if not d.is_dir():continue
    for p in d.iterdir():
        if p.is_file() and (p.suffix=='.log' or p.name in ('commands.json','report.json')):
            files[str(p.relative_to(s))]=p.read_bytes()
for tag in ['fixed','preceding','default','automatic','selected']:
 p=s/('matched-'+tag)/'p1-float.wasm'
 files['images/'+tag+'-p1-float.wasm']=p.read_bytes()
for name in ['verified-leak','verified-reserved']:
 files['images/'+name+'.wasm']=(s/(name+'.wasm')).read_bytes()
files['versions.txt']=sp.check_output(['rustc','+1.95.0','-vV'])+sp.check_output(['node','--version'])+sp.check_output(['wasm-as','--version'])
assert files['source-revision'].decode().strip()==git(root,'rev-parse','HEAD').decode().strip()
for name in ['results.json','final-notes.json','scope','frames-optional.log','jit.json','zizmor.log','downstream-frames.json','control-frames.json','lattice-fuel.json','matched.log','packaged-wasi.log','tuple-1.95.0-p1/report.json','reproduce.txt']:
 if name!='frames-optional.log':assert name in files
archive=s/'record';archive.mkdir()
with tarfile.open(archive/'observations.tar.xz','w:xz') as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
digests={k:sha(v) for k,v in sorted(files.items())}
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {m.name:sha(tar.extractfile(m).read()) for m in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record);git(other,'add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git(other,'diff','--cached','--name-only').decode().splitlines())
git(other,'-c','gc.auto=0','commit','-m','Archive opt-in WASI Preview 1 qualification and matched resource measurements')
rev=git(other,'rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git(other,'show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',root/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=root/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1])
