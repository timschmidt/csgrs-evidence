import assert from "node:assert/strict";
import {readFile} from "node:fs/promises";
import {WASI} from "node:wasi";
const s=new URL("./",import.meta.url);
const {lattice}=JSON.parse(await readFile(new URL("tuple-1.95.0-p1/corpus.json",s)));
const rows=[];
for(const name of ["old-fixed","new-fixed","bare"])for(const kind of ["layout","dyadic"])for(const fill of [85,170]){
 if(name.endsWith("fixed") && kind!=="layout")continue;
 const mod=await WebAssembly.compile(await readFile(new URL(`frames-${name}-${kind}.wasm`,s)));
 const wasi=new WASI({version:"preview1",env:{},args:[],preopens:{}});
 const live=new Map();let bytes=0,peak=0,alloc=0,free=0,realloc=0;
 function add(ptr,size){assert.ok(ptr);assert.ok(!live.has(ptr));live.set(ptr,size);bytes+=size;peak=Math.max(peak,bytes);}
 function remove(ptr,size){assert.equal(live.get(ptr),size);live.delete(ptr);bytes-=size;}
 const heap={alloc:(_a,_b,p,n)=>{add(p,n);alloc++;},dealloc:(p,n)=>{remove(p,n);free++;},
   realloc:(p,n,q,m)=>{assert.ok(q);remove(p,n);add(q,m);realloc++;}};
 const instance=await WebAssembly.instantiate(mod,{heap,wasi_snapshot_preview1:wasi.wasiImport});wasi.initialize(instance);
 const api=instance.exports;assert.equal(api.probe_sp.value,1048576);
 for(const temp of ["cold","warm"]){
    const initial=api.memory.buffer.byteLength;peak=bytes;alloc=free=realloc=0;
    new Uint8Array(api.memory.buffer,0,1048576).fill(fill);api.probe_min.value=1048576;
    if(kind==="dyadic"){assert.equal(api.verify_dyadic_egress(),56);}
    else for(const [width,dim,seed,lower,upper,lo,hi] of lattice)for(const soa of [0,1])for(const bit of [0,1]){
      if(!name.endsWith("fixed"))assert.equal(BigInt.asUintN(64,api.floating(soa,Number(width===64),dim,seed,bit)),BigInt(bit?upper:lower));
      assert.equal(api.fixed(soa,Number(width===64),dim,seed,bit),BigInt(bit?hi:lo)<<(width===64?24n:0n));}
    assert.equal(api.probe_sp.value,1048576);assert.equal(live.size,0);
    const first=new Uint8Array(api.memory.buffer,0,1048576).findIndex(b=>b!==fill);
    rows.push({name,kind,fill,temp,reserved:1048576-api.probe_min.value,touched:first<0?0:1048576-first,
       initial,final:api.memory.buffer.byteLength,alloc,free,realloc,logical_peak:peak,retained:bytes});
 }
}
console.log(JSON.stringify(rows,null,2));
