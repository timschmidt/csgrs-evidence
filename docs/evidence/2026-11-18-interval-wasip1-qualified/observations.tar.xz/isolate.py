from pathlib import Path
import sys
root=Path(sys.argv[1]);p=root/'crates/hyperinterval'
marker=p/'wasip1';(marker/'src').mkdir(parents=True,exist_ok=True)
(p/'build.rs').rename(marker/'build.rs')
(marker/'Cargo.toml').write_text('''[package]
name = "hyperinterval-wasip1"
version = "0.1.0"
edition = "2024"
rust-version = "1.88"
license = "MIT OR Apache-2.0"
description = "Exact Cargo target selection for the Hyperinterval WASI Preview 1 backend"
repository = "https://github.com/timschmidt/csgrs"

[lib]
path = "src/lib.rs"
''')
(marker/'src/lib.rs').write_text('''//! Cargo target identity for the opt-in Hyperinterval WASI backend.
#![no_std]
#![forbid(unsafe_code)]

/// True only when Cargo selected the ordinary, single-threaded Preview 1 ABI.
pub const ORDINARY_PREVIEW_1: bool = cfg!(interval_wasip1);
''')
f=p/'Cargo.toml';a=f.read_text().replace('"/build.rs", ','').replace('float-enclosure-wasip1 = ["float-enclosure"]','float-enclosure-wasip1 = ["float-enclosure", "dep:hyperinterval-wasip1"]')
a=a.replace('[dependencies]',"""[target.'cfg(all(target_arch = "wasm32", target_os = "wasi"))'.dependencies]
hyperinterval-wasip1 = { version = "0.1.0", path = "wasip1", optional = true }

[dependencies]""")
f.write_text(a)
f=p/'src/float.rs';a=f.read_text().replace('    all(interval_wasip1, feature = "float-enclosure-wasip1"),','').replace('));\n\nfn qualify()', ''')) || wasi_supported();

const fn wasi_supported() -> bool {
    #[cfg(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1"))]
    { hyperinterval_wasip1::ORDINARY_PREVIEW_1 }
    #[cfg(not(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1")))]
    { false }
}

fn qualify()''')
f.write_text(a)
f=p/'tests/float.rs';a=f.read_text().replace('                        all(interval_wasip1, feature = "float-enclosure-wasip1")','')
a=a.replace('                assert_eq!(\n                    $interval::backend_supported(),','''                #[cfg(not(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1")))]
                assert_eq!(
                    $interval::backend_supported(),''')
f.write_text(a)
