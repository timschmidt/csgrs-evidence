from pathlib import Path
import sys,hashlib,io,json
import wasmtime as wt
from elftools.elf.elffile import ELFFile
s=Path(__file__).parent; sha=lambda b:hashlib.sha256(b).hexdigest()
d={}
for fuel in (False,True):
 cfg=wt.Config();cfg.consume_fuel=fuel;e=wt.Engine(cfg)
 for stage,k in [('preceding','bare'),('default','bare'),('automatic','p1'),('selected','p1')]:
    p=s/('matched-'+stage)/(k+'-float.wasm');m=wt.Module.from_file(e,str(p))
    elf=ELFFile(io.BytesIO(m.serialize()));sec=elf.get_section_by_name('.text')
    d[f'{stage}/{k}/fuel={fuel}']={'host_text_bytes':sec['sh_size'],'sha256':sha(sec.data())}
print(json.dumps(d,indent=2))
