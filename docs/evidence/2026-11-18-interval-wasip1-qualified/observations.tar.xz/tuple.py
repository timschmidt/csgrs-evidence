from pathlib import Path
import shutil,sys
root=Path(sys.argv[1]);p=root/'crates/hyperinterval'
if (p/'wasip1').is_dir():shutil.rmtree(p/'wasip1')
f=p/'Cargo.toml';a=f.read_text().replace('dep:hyperinterval-wasip1','dep:target-tuple').replace('hyperinterval-wasip1 = { version = "0.1.0", path = "wasip1", optional = true }','target-tuple = { version = "1", optional = true }');f.write_text(a)
f=p/'src/float.rs';a=f.read_text();lo=a.index('const BACKEND_SUPPORTED:');hi=a.index('fn qualify()',lo)
a=a[:lo]+'''// Cargo distinguishes the ordinary and threaded Preview 1 targets even on
// compilers whose stable target cfgs coincide for the two ABIs.
#[cfg(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1"))]
const BACKEND_SUPPORTED: bool = matches!(target_tuple::TARGET.as_bytes(), b"wasm32-wasip1");
#[cfg(not(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1")))]
const BACKEND_SUPPORTED: bool = cfg!(any(
    target_arch = "x86_64",
    all(target_arch = "wasm32", target_os = "unknown")
));

'''+a[hi:]
a=a.replace('qualified on x86_64, wasm32-unknown-unknown and wasm32-wasip1. Other targets return','qualified on x86_64 and wasm32-unknown-unknown. The optional\n        /// `float-enclosure-wasip1` feature also qualifies wasm32-wasip1. Other targets return')
f.write_text(a)
f=p/'tests/float.rs';a=f.read_text().replace('                #[cfg(not(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1")))]\n','')
lo=a.index('                assert_eq!(\n                    $interval::backend_supported()');hi=a.index('                assert!($interval::empty()',lo)
a=a[:lo]+'''                #[cfg(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1"))]
                let expected = target_tuple::TARGET == "wasm32-wasip1";
                #[cfg(not(all(target_arch = "wasm32", target_os = "wasi", feature = "float-enclosure-wasip1")))]
                let expected = cfg!(any(target_arch = "x86_64", all(target_arch = "wasm32", target_os = "unknown")));
                assert_eq!($interval::backend_supported(), expected);
'''+a[hi:];f.write_text(a)
