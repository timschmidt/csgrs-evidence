from pathlib import Path
import subprocess as sp
s=Path(__file__).parent
base=s/'preceding/1.95.0/bare-float.wasm';sp.run(['wasm-dis',base,'-o',s/'base.wat'],check=True)
a=(s/'base.wat').read_text()
k=' (func $qualification (result i32)\n';assert a.count(k)==1
for name,body in {'reserved':'''  (global.set $__stack_pointer (i32.sub (global.get $__stack_pointer) (i32.const 4096)))
  (global.set $__stack_pointer (i32.add (global.get $__stack_pointer) (i32.const 4096)))
''','leak':'''  (global.set $__stack_pointer (i32.sub (global.get $__stack_pointer) (i32.const 16)))
'''}.items():
    p=s/(name+'.wat');p.write_text(a.replace(k,k+body));sp.run(['wasm-as',p,'--all-features','-o',s/(name+'.wasm')],check=True)
