set -eu
s=/dev/shm/interval-wasi-reconsider
. "$s/env"
cd "$s/src"
git switch --detach c9f1f9ac5
trap 'git switch --detach 3ebe192ae' EXIT
for t in wasm32-unknown-unknown wasm32-wasip1; do
  for p in crates/hyperinterval/conformance/wasm-float crates/hyperlattice-interval/conformance/primitive-layouts/wasm crates/hyperinterval/conformance/wasm-dyadic; do
    cargo +1.95.0 build --locked --release --manifest-path "$p/Cargo.toml" --target "$t"
    case "$p" in *wasm-float) name=interval_float_wasm_conformance; key=float;; *primitive-layouts*) name=interval_layout_wasm; key=layout;; *) name=interval_dyadic_wasm_conformance; key=dyadic;; esac
    case "$t" in wasm32-wasip1) prefix=p1;; *) prefix=bare;; esac
    mkdir -p "$s/fixed/1.95.0"; cp "$CARGO_TARGET_DIR/$t/release/$name.wasm" "$s/fixed/1.95.0/$prefix-$key.wasm"
  done
done
