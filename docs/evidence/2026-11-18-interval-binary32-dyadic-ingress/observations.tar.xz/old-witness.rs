use hyperinterval::{DyadicBudget,DyadicInterval,IntervalError};
fn main() {
 let mut budget=DyadicBudget::new(24,48);
 assert_eq!(DyadicInterval::from_f64(f64::from(std::hint::black_box(1.0_f32)),&mut budget),Err(IntervalError::SizeExhausted));
 assert_eq!(budget.remaining_work(),48);
 println!("binary64 widening of 1f32 rejects 24 bits / 48 work");
 let x=DyadicInterval::from_f64(1.0,&mut DyadicBudget::new(53,106)).unwrap();
 assert_eq!(x,DyadicInterval::point(1.into(),0).unwrap());
}
