set -eu
s=/dev/shm/interval-f32-ingress
. /dev/shm/hyperinterval-coverage/env
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_TARGET_DIR="$s/matched-target"
cd "$s/client"
cargo +1.95.0 generate-lockfile --offline
for stage in fixed preceding direct; do
  case "$stage" in
    preceding) git -C "$s/control" checkout --quiet --detach cc54dd856 ;;
    direct) cp /mnt/development/csgrs/crates/hyperinterval/src/dyadic.rs "$s/control/crates/hyperinterval/src/dyadic.rs"
            cp "$s/direct-client.rs" src/lib.rs ;;
  esac
  mkdir -p "$s/images/$stage"
  for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown wasm32-wasip1; do
    cargo +1.95.0 build --release --locked --target "$target"
    cp "$CARGO_TARGET_DIR/$target/release/"*binary32_dyadic_consumer.* "$s/images/$stage/" 2>/dev/null
    if [ "$target" != x86_64-unknown-linux-gnu ]; then
      mv "$s/images/$stage/binary32_dyadic_consumer.wasm" "$s/images/$stage/$target.wasm"
    fi
  done
done
