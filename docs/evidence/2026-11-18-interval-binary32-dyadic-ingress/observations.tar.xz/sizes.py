from pathlib import Path
import re,subprocess as sp,hashlib,json,io
s=Path(__file__).parent
def leb(f):
 out=shift=0
 while True:
  b=f.read(1)[0];out|=(b&127)<<shift
  if b<128:return out
  shift+=7
def metrics(p):
 raw=p.read_bytes()
 out={'file':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if p.suffix=='.wasm':
  f=io.BytesIO(raw);assert f.read(8)==b'\0asm\x01\0\0\0'
  while k:=f.read(1):
   length=leb(f);block=f.read(length);assert len(block)==length
   if k==b'\x0a':
    out['code']=length;out['function_bodies']=leb(io.BytesIO(block))
 else:
  rows=[l.split() for l in sp.check_output(['readelf','-Ws',p],text=True).splitlines()];ranges=[]
  for a in rows:
   if len(a)>=8 and a[3]=='FUNC' and a[6].isdigit() and a[2].isdigit() and int(a[2]):
    v=int(a[1],16);ranges.append((v,v+int(a[2])))
  end=total=0
  for a,b in sorted(ranges):
   total+=max(0,b-max(end,a));end=max(end,b)
  out['function_union']=total
  sections=sp.check_output(['size','-A',p],text=True)
  out['code']=int(re.search(r'^\.text\s+(\d+)',sections,re.M)[1]);out['relro_padding']=int(re.search(r'^\.relro_padding\s+(\d+)',sections,re.M)[1])
  headers=sp.check_output(['readelf','-lW',p],text=True)
  out['load_pages']=[]
  for line in headers.splitlines():
   a=line.split()
   if a and a[0]=='LOAD':
    address=int(a[2],16);length=int(a[5],16);out['load_pages'].append([address//4096,(address+length+4095)//4096])
 return out
data={}
for group in ['workspace','images']:
 for name in ['libbinary32_dyadic_consumer.so','wasm32-unknown-unknown.wasm','wasm32-wasip1.wasm']:
  vals={st:metrics(s/group/st/name) for st in ['fixed','preceding','direct']}
  if group=='images':vals['inline']=metrics(s/group/'inline'/name)
  data[group+'/'+name]=vals
  for k in ['file','code','function_union']:
   if k not in vals['direct']:continue
   a,b,c=[vals[v][k] for v in ['fixed','preceding','direct']]
   charge=max(0,b-a)+max(0,c-b)
   assert max(0,c-b)<=min(512,b*.005) and charge<=min(512,a*.005),(name,k,a,b,c)
   print(group,name,k,[a,b,c],charge)
  cap=(16 if name.endswith('.so') else 2)*1024**2
  assert cap-vals['direct']['file']>=cap/4
  if name.endswith('.so'):assert vals['preceding']['load_pages']==vals['direct']['load_pages']
old=Path('/dev/shm/interval-ieee-branches/retained-1.95.0')
data['surviving_wasm']={}
for p in (s/'wasm-final').glob('interval*.wasm'):
 assert p.read_bytes()==(old/p.name).read_bytes()
 data['surviving_wasm'][p.name]=metrics(p)
data['existing_native']=metrics(s/'cost/release/examples/float_cost')
data['released_test']=metrics(next(p for p in (s/'cost/release/deps').glob('dyadic_f32_ingress-*') if p.suffix!='.d'))
(s/'logs/sizes.json').write_text(json.dumps(data,indent=2)+'\n')
