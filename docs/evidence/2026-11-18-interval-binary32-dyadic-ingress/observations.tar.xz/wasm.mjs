import fs from 'node:fs';
import assert from 'node:assert/strict';
import {WASI} from 'node:wasi';
const [file,corpus,stage,target]=process.argv.slice(2);
const mod=await WebAssembly.compile(fs.readFileSync(file));
const records=JSON.parse(fs.readFileSync(corpus));
let calls=0;
for(let instance=0;instance<2;instance++){
 const wasi=new WASI({version:'preview1',args:[],env:{},preopens:{}});
 const api=await WebAssembly.instantiate(mod,target==='wasm32-wasip1'?{wasi_snapshot_preview1:wasi.wasiImport}:{});
 if(target==='wasm32-wasip1')wasi.initialize(api);
 const run=(...args)=>{calls++;return Number(api.exports.inspect(...args));};
 for(const [raw,status,m,e,bits] of records){
   assert.equal(run(raw,64,256,0),status);
   if(status===0){
     assert.equal(run(raw,64,256,1),m);
     assert.equal(run(raw,64,256,2),e);
   }
   if(stage==='direct'){
     const work=Math.max(1,bits)*2;
     assert.equal(run(raw,bits,work,3),status===0?0:-1);
     assert.equal(run(raw,bits,work-1,0),status===0?-3:-1);
     if(bits)assert.equal(run(raw,bits-1,work,0),-2);
   }
 }
}
console.log(JSON.stringify({file,stage,target,cases:records.length,instances:2,calls}));
