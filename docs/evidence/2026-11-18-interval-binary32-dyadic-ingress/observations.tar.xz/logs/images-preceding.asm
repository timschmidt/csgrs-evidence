0000000000014e60 <inspect>:
   14e60:	push   %rbp
   14e61:	push   %r15
   14e63:	push   %r14
   14e65:	push   %r12
   14e67:	push   %rbx
   14e68:	sub    $0xc0,%rsp
   14e6f:	mov    %ecx,%ebp
   14e71:	movabs $0x8000000000000000,%r15
   14e7b:	mov    %esi,%eax
   14e7d:	mov    %edx,%ecx
   14e7f:	mov    %rax,0x58(%rsp)
   14e84:	mov    %rcx,0x60(%rsp)
   14e89:	movd   %edi,%xmm0
   14e8d:	cvtss2sd %xmm0,%xmm0
   14e91:	lea    0x78(%rsp),%rdi
   14e96:	lea    0x58(%rsp),%rsi
   14e9b:	call   *0x4a357(%rip)        # 5f1f8 <_DYNAMIC+0x238>
   14ea1:	lea    0x2(%r15),%rax
   14ea5:	cmp    %rax,0x78(%rsp)
   14eaa:	jne    14eda <inspect+0x7a>
   14eac:	movzbl 0x80(%rsp),%eax
   14eb4:	test   %eax,%eax
   14eb6:	je     14f9b <inspect+0x13b>
   14ebc:	cmp    $0xb,%eax
   14ebf:	je     14f8f <inspect+0x12f>
   14ec5:	cmp    $0xc,%eax
   14ec8:	jne    15169 <inspect+0x309>
   14ece:	mov    $0xfffffffffffffffe,%r14
   14ed5:	jmp    15074 <inspect+0x214>
   14eda:	movups 0x78(%rsp),%xmm0
   14edf:	movups 0x88(%rsp),%xmm1
   14ee7:	movups 0x98(%rsp),%xmm2
   14eef:	movups 0xa8(%rsp),%xmm3
   14ef7:	movaps %xmm0,0x10(%rsp)
   14efc:	mov    0xb8(%rsp),%rax
   14f04:	mov    %rax,0x50(%rsp)
   14f09:	movaps %xmm3,0x40(%rsp)
   14f0e:	movaps %xmm2,0x30(%rsp)
   14f13:	movaps %xmm1,0x20(%rsp)
   14f18:	mov    0x10(%rsp),%rbx
   14f1d:	lea    0x1(%r15),%rax
   14f21:	cmp    %rax,%rbx
   14f24:	je     1515c <inspect+0x2fc>
   14f2a:	lea    0x30(%rsp),%rax
   14f2f:	movslq 0x50(%rsp),%r14
   14f34:	lea    0x10(%rsp),%rcx
   14f39:	mov    %rcx,0x68(%rsp)
   14f3e:	mov    %rax,0x70(%rsp)
   14f43:	movzbl 0x28(%rsp),%r12d
   14f49:	cmp    0x48(%rsp),%r12b
   14f4e:	jne    1514d <inspect+0x2ed>
   14f54:	cmp    $0x1,%r12d
   14f58:	je     15005 <inspect+0x1a5>
   14f5e:	cmp    %r15,%rbx
   14f61:	jne    14fa7 <inspect+0x147>
   14f63:	cmpl   $0x1,0x18(%rsp)
   14f68:	jne    14fd3 <inspect+0x173>
   14f6a:	mov    $0x1,%edx
   14f6f:	lea    0x20(%rsp),%rdi
   14f74:	cmp    %r15,0x30(%rsp)
   14f79:	je     14fb8 <inspect+0x158>
   14f7b:	mov    0x38(%rsp),%rsi
   14f80:	mov    0x40(%rsp),%rax
   14f85:	cmp    %rax,%rdx
   14f88:	je     14ff3 <inspect+0x193>
   14f8a:	jmp    1514d <inspect+0x2ed>
   14f8f:	mov    $0xfffffffffffffffd,%r14
   14f96:	jmp    15074 <inspect+0x214>
   14f9b:	mov    $0xffffffffffffffff,%r14
   14fa2:	jmp    15074 <inspect+0x214>
   14fa7:	mov    0x18(%rsp),%rdi
   14fac:	mov    0x20(%rsp),%rdx
   14fb1:	cmp    %r15,0x30(%rsp)
   14fb6:	jne    14f7b <inspect+0x11b>
   14fb8:	cmpl   $0x1,0x38(%rsp)
   14fbd:	jne    14fe3 <inspect+0x183>
   14fbf:	mov    $0x1,%eax
   14fc4:	lea    0x40(%rsp),%rsi
   14fc9:	cmp    %rax,%rdx
   14fcc:	je     14ff3 <inspect+0x193>
   14fce:	jmp    1514d <inspect+0x2ed>
   14fd3:	mov    $0x8,%edi
   14fd8:	xor    %edx,%edx
   14fda:	cmp    %r15,0x30(%rsp)
   14fdf:	je     14fb8 <inspect+0x158>
   14fe1:	jmp    14f7b <inspect+0x11b>
   14fe3:	mov    $0x8,%esi
   14fe8:	xor    %eax,%eax
   14fea:	cmp    %rax,%rdx
   14fed:	jne    1514d <inspect+0x2ed>
   14ff3:	shl    $0x3,%rdx
   14ff7:	call   *0x4a203(%rip)        # 5f200 <bcmp@GLIBC_2.2.5>
   14ffd:	test   %eax,%eax
   14fff:	jne    1514d <inspect+0x2ed>
   15005:	cmp    $0x3,%ebp
   15008:	ja     15182 <inspect+0x322>
   1500e:	mov    %ebp,%eax
   15010:	lea    -0x10717(%rip),%rcx        # 4900 <std::thread::current::id::ID+0x48b8>
   15017:	movslq (%rcx,%rax,4),%rdx
   1501b:	add    %rcx,%rdx
   1501e:	jmp    *%rdx
   15020:	mov    %rax,%r14
   15023:	jmp    1503a <inspect+0x1da>
   15025:	test   %r12d,%r12d
   15028:	je     15087 <inspect+0x227>
   1502a:	cmp    $0x1,%r12d
   1502e:	jne    1509a <inspect+0x23a>
   15030:	xor    %r14d,%r14d
   15033:	jmp    1503a <inspect+0x1da>
   15035:	mov    0x60(%rsp),%r14
   1503a:	test   %rbx,%rbx
   1503d:	jle    15056 <inspect+0x1f6>
   1503f:	mov    0x18(%rsp),%rdi
   15044:	shl    $0x3,%rbx
   15048:	mov    $0x8,%edx
   1504d:	mov    %rbx,%rsi
   15050:	call   *0x4a1b2(%rip)        # 5f208 <_DYNAMIC+0x248>
   15056:	mov    0x30(%rsp),%rsi
   1505b:	test   %rsi,%rsi
   1505e:	jle    15074 <inspect+0x214>
   15060:	mov    0x38(%rsp),%rdi
   15065:	shl    $0x3,%rsi
   15069:	mov    $0x8,%edx
   1506e:	call   *0x4a194(%rip)        # 5f208 <_DYNAMIC+0x248>
   15074:	mov    %r14,%rax
   15077:	add    $0xc0,%rsp
   1507e:	pop    %rbx
   1507f:	pop    %r12
   15081:	pop    %r14
   15083:	pop    %r15
   15085:	pop    %rbp
   15086:	ret
   15087:	cmp    %r15,%rbx
   1508a:	jne    150b1 <inspect+0x251>
   1508c:	cmpl   $0x1,0x18(%rsp)
   15091:	jne    150fd <inspect+0x29d>
   15093:	mov    0x20(%rsp),%r14
   15098:	jmp    15100 <inspect+0x2a0>
   1509a:	cmp    %r15,%rbx
   1509d:	jne    150cf <inspect+0x26f>
   1509f:	cmpb   $0x0,0x18(%rsp)
   150a4:	je     15137 <inspect+0x2d7>
   150aa:	lea    0x20(%rsp),%rax
   150af:	jmp    150ec <inspect+0x28c>
   150b1:	mov    0x20(%rsp),%rax
   150b6:	test   %rax,%rax
   150b9:	je     150fd <inspect+0x29d>
   150bb:	cmp    $0x1,%rax
   150bf:	jne    1519b <inspect+0x33b>
   150c5:	mov    0x18(%rsp),%rax
   150ca:	mov    (%rax),%r14
   150cd:	jmp    15100 <inspect+0x2a0>
   150cf:	mov    0x20(%rsp),%rax
   150d4:	test   %rax,%rax
   150d7:	je     15030 <inspect+0x1d0>
   150dd:	cmp    $0x1,%rax
   150e1:	jne    1519b <inspect+0x33b>
   150e7:	mov    0x18(%rsp),%rax
   150ec:	mov    (%rax),%r14
   150ef:	test   %r14,%r14
   150f2:	jns    1503a <inspect+0x1da>
   150f8:	jmp    1519b <inspect+0x33b>
   150fd:	xor    %r14d,%r14d
   15100:	movabs $0x8000000000000000,%rax
   1510a:	cmp    %rax,%r14
   1510d:	seta   %al
   15110:	sbb    $0x0,%al
   15112:	je     1512f <inspect+0x2cf>
   15114:	movzbl %al,%eax
   15117:	cmp    $0xff,%eax
   1511c:	jne    1519b <inspect+0x33b>
   1511e:	cmp    %r15,%r14
   15121:	je     151c0 <inspect+0x360>
   15127:	neg    %r14
   1512a:	jmp    1503a <inspect+0x1da>
   1512f:	mov    %r15,%r14
   15132:	jmp    1503a <inspect+0x1da>
   15137:	xor    %r14d,%r14d
   1513a:	mov    0x30(%rsp),%rsi
   1513f:	test   %rsi,%rsi
   15142:	jg     15060 <inspect+0x200>
   15148:	jmp    15074 <inspect+0x214>
   1514d:	lea    0x68(%rsp),%rdi
   15152:	lea    0x70(%rsp),%rsi
   15157:	call   14dd5 <core::panicking::assert_failed>
   1515c:	lea    0x47fbd(%rip),%rdi        # 5d120 <__frame_dummy_init_array_entry+0x80>
   15163:	call   *0x4a0a7(%rip)        # 5f210 <_DYNAMIC+0x250>
   15169:	lea    -0xf118(%rip),%rdi        # 6058 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x16a>
   15170:	lea    0x48009(%rip),%rdx        # 5d180 <__frame_dummy_init_array_entry+0xe0>
   15177:	mov    $0xe,%esi
   1517c:	call   *0x4a096(%rip)        # 5f218 <_DYNAMIC+0x258>
   15182:	lea    -0xf131(%rip),%rdi        # 6058 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x16a>
   15189:	lea    0x47fd8(%rip),%rdx        # 5d168 <__frame_dummy_init_array_entry+0xc8>
   15190:	mov    $0xe,%esi
   15195:	call   *0x4a07d(%rip)        # 5f218 <_DYNAMIC+0x258>
   1519b:	lea    -0xf1aa(%rip),%rdi        # 5ff8 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x10a>
   151a2:	lea    0x47f17(%rip),%rcx        # 5d0c0 <__frame_dummy_init_array_entry+0x20>
   151a9:	lea    0x47fa0(%rip),%r8        # 5d150 <__frame_dummy_init_array_entry+0xb0>
   151b0:	lea    0xf(%rsp),%rdx
   151b5:	mov    $0x2b,%esi
   151ba:	call   *0x4a060(%rip)        # 5f220 <_DYNAMIC+0x260>
   151c0:	lea    0x47ee1(%rip),%rdi        # 5d0a8 <__frame_dummy_init_array_entry+0x8>
   151c7:	call   *0x4a05b(%rip)        # 5f228 <_DYNAMIC+0x268>
   151cd:	int3
   151ce:	int3
   151cf:	int3

0000000000015770 <hyperinterval::dyadic::DyadicInterval::from_f64>:
   15770:	push   %r15
   15772:	push   %r14
   15774:	push   %rbx
   15775:	sub    $0x40,%rsp
   15779:	mov    %rsi,%r15
   1577c:	mov    %rdi,%rbx
   1577f:	movabs $0x8000000000000000,%r14
   15789:	movq   %xmm0,%rcx
   1578e:	mov    %rsp,%rdi
   15791:	movabs $0x7ff0000000000000,%rdx
   1579b:	mov    %r14,%rsi
   1579e:	call   158e0 <hyperinterval::ieee::Format::finite>
   157a3:	cmpb   $0x1,(%rsp)
   157a7:	jne    157b3 <hyperinterval::dyadic::DyadicInterval::from_f64+0x43>
   157a9:	movzbl 0x1(%rsp),%eax
   157ae:	mov    %al,0x8(%rbx)
   157b1:	jmp    15831 <hyperinterval::dyadic::DyadicInterval::from_f64+0xc1>
   157b3:	mov    0x8(%rsp),%rdx
   157b8:	mov    %rdx,%rax
   157bb:	shr    $0x34,%rax
   157bf:	and    $0x7ff,%eax
   157c4:	movabs $0xfffffffffffff,%rsi
   157ce:	mov    %rdx,%rdi
   157d1:	and    %rsi,%rdi
   157d4:	lea    -0x433(%rax),%r8d
   157db:	test   %rax,%rax
   157de:	mov    $0xfffffbce,%ecx
   157e3:	cmovne %r8d,%ecx
   157e7:	lea    0x1(%rdi,%rsi,1),%rsi
   157ec:	cmove  %rdi,%rsi
   157f0:	mov    %rsi,%rax
   157f3:	neg    %rax
   157f6:	test   %rdx,%rdx
   157f9:	cmovns %rsi,%rax
   157fd:	mov    $0x7f,%edx
   15802:	bsr    %rsi,%rdx
   15806:	xor    $0xffffffffffffffc0,%rdx
   1580a:	add    $0x41,%rdx
   1580e:	mov    $0xc,%sil
   15811:	cmp    (%r15),%rdx
   15814:	ja     1582d <hyperinterval::dyadic::DyadicInterval::from_f64+0xbd>
   15816:	cmp    $0x1,%rdx
   1581a:	adc    $0x0,%rdx
   1581e:	add    %rdx,%rdx
   15821:	mov    0x8(%r15),%rdi
   15825:	mov    $0xb,%sil
   15828:	sub    %rdx,%rdi
   1582b:	jae    15845 <hyperinterval::dyadic::DyadicInterval::from_f64+0xd5>
   1582d:	mov    %sil,0x8(%rbx)
   15831:	add    $0x2,%r14
   15835:	mov    %r14,(%rbx)
   15838:	mov    %rbx,%rax
   1583b:	add    $0x40,%rsp
   1583f:	pop    %rbx
   15840:	pop    %r14
   15842:	pop    %r15
   15844:	ret
   15845:	mov    %rdi,0x8(%r15)
   15849:	test   %rax,%rax
   1584c:	js     15872 <hyperinterval::dyadic::DyadicInterval::from_f64+0x102>
   1584e:	mov    $0x2,%dl
   15850:	jne    15885 <hyperinterval::dyadic::DyadicInterval::from_f64+0x115>
   15852:	movups -0xf7e1(%rip),%xmm0        # 6078 <anon.c8dfaf1cf540a3dfc1495b08facdd45a.0.llvm.16609981888948643531+0x10>
   15859:	movaps %xmm0,0x30(%rsp)
   1585e:	movdqu -0xf7fe(%rip),%xmm0        # 6068 <anon.c8dfaf1cf540a3dfc1495b08facdd45a.0.llvm.16609981888948643531>
   15866:	movdqa %xmm0,0x20(%rsp)
   1586c:	mov    $0x1,%dl
   1586e:	xor    %esi,%esi
   15870:	jmp    158a1 <hyperinterval::dyadic::DyadicInterval::from_f64+0x131>
   15872:	mov    %rax,%rsi
   15875:	neg    %rsi
   15878:	not    %rax
   1587b:	cmp    %rax,%rsi
   1587e:	jb     158c9 <hyperinterval::dyadic::DyadicInterval::from_f64+0x159>
   15880:	xor    %edx,%edx
   15882:	mov    %rsi,%rax
   15885:	mov    %dl,0x38(%rsp)
   15889:	mov    %r14,0x20(%rsp)
   1588e:	movq   $0x1,0x28(%rsp)
   15897:	mov    %rax,0x30(%rsp)
   1589c:	mov    $0x1,%esi
   158a1:	mov    %dl,0x18(%rsp)
   158a5:	mov    %r14,(%rsp)
   158a9:	mov    %rsi,0x8(%rsp)
   158ae:	mov    %rax,0x10(%rsp)
   158b3:	mov    %rsp,%rsi
   158b6:	lea    0x20(%rsp),%rdx
   158bb:	mov    %rbx,%rdi
   158be:	call   *0x4998c(%rip)        # 5f250 <_DYNAMIC+0x290>
   158c4:	jmp    15838 <hyperinterval::dyadic::DyadicInterval::from_f64+0xc8>
   158c9:	lea    0x478c8(%rip),%rdi        # 5d198 <__frame_dummy_init_array_entry+0xf8>
   158d0:	call   *0x499ea(%rip)        # 5f2c0 <_DYNAMIC+0x300>
   158d6:	int3
   158d7:	int3
   158d8:	int3
   158d9:	int3
   158da:	int3
   158db:	int3
   158dc:	int3
   158dd:	int3
   158de:	int3
   158df:	int3

00000000000158e0 <hyperinterval::ieee::Format::finite>:
   158e0:	mov    %rcx,%rax
   158e3:	not    %rax
   158e6:	test   %rax,%rdx
   158e9:	jne    158f7 <hyperinterval::ieee::Format::finite+0x17>
   158eb:	movb   $0x0,0x1(%rdi)
   158ef:	mov    $0x1,%al
   158f1:	mov    %al,(%rdi)
   158f3:	mov    %rdi,%rax
   158f6:	ret
   158f7:	test   %rsi,%rsi
   158fa:	je     15920 <hyperinterval::ieee::Format::finite+0x40>
   158fc:	dec    %rsi
   158ff:	test   %rsi,%rcx
   15902:	je     15910 <hyperinterval::ieee::Format::finite+0x30>
   15904:	mov    %rcx,0x8(%rdi)
   15908:	xor    %eax,%eax
   1590a:	mov    %al,(%rdi)
   1590c:	mov    %rdi,%rax
   1590f:	ret
   15910:	movq   $0x0,0x8(%rdi)
   15918:	xor    %eax,%eax
   1591a:	mov    %al,(%rdi)
   1591c:	mov    %rdi,%rax
   1591f:	ret
   15920:	push   %rax
   15921:	lea    0x478a0(%rip),%rdi        # 5d1c8 <anon.f82134d8c3ea0a52de317b9b570b4bdc.2.llvm.13065751716895374897+0x18>
   15928:	call   *0x49982(%rip)        # 5f2b0 <_DYNAMIC+0x2f0>
   1592e:	int3
   1592f:	int3

