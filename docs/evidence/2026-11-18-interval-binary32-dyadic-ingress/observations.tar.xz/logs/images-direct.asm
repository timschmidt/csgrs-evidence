0000000000014e60 <inspect>:
   14e60:	push   %rbp
   14e61:	push   %r15
   14e63:	push   %r14
   14e65:	push   %r12
   14e67:	push   %rbx
   14e68:	sub    $0xc0,%rsp
   14e6f:	mov    %ecx,%ebp
   14e71:	movabs $0x8000000000000000,%r15
   14e7b:	mov    %esi,%eax
   14e7d:	mov    %edx,%ecx
   14e7f:	mov    %rax,0x58(%rsp)
   14e84:	mov    %rcx,0x60(%rsp)
   14e89:	movd   %edi,%xmm0
   14e8d:	lea    0x78(%rsp),%rdi
   14e92:	lea    0x58(%rsp),%rsi
   14e97:	call   *0x4a34b(%rip)        # 5f1e8 <_DYNAMIC+0x238>
   14e9d:	lea    0x2(%r15),%rax
   14ea1:	cmp    %rax,0x78(%rsp)
   14ea6:	jne    14ed6 <inspect+0x76>
   14ea8:	movzbl 0x80(%rsp),%eax
   14eb0:	test   %eax,%eax
   14eb2:	je     14f99 <inspect+0x139>
   14eb8:	cmp    $0xb,%eax
   14ebb:	je     14f8d <inspect+0x12d>
   14ec1:	cmp    $0xc,%eax
   14ec4:	jne    15167 <inspect+0x307>
   14eca:	mov    $0xfffffffffffffffe,%r14
   14ed1:	jmp    15072 <inspect+0x212>
   14ed6:	movdqu 0x78(%rsp),%xmm0
   14edc:	movups 0x88(%rsp),%xmm1
   14ee4:	movups 0x98(%rsp),%xmm2
   14eec:	movups 0xa8(%rsp),%xmm3
   14ef4:	movdqa %xmm0,0x10(%rsp)
   14efa:	mov    0xb8(%rsp),%rax
   14f02:	mov    %rax,0x50(%rsp)
   14f07:	movaps %xmm3,0x40(%rsp)
   14f0c:	movaps %xmm2,0x30(%rsp)
   14f11:	movaps %xmm1,0x20(%rsp)
   14f16:	mov    0x10(%rsp),%rbx
   14f1b:	lea    0x1(%r15),%rax
   14f1f:	cmp    %rax,%rbx
   14f22:	je     1515a <inspect+0x2fa>
   14f28:	lea    0x30(%rsp),%rax
   14f2d:	movslq 0x50(%rsp),%r14
   14f32:	lea    0x10(%rsp),%rcx
   14f37:	mov    %rcx,0x68(%rsp)
   14f3c:	mov    %rax,0x70(%rsp)
   14f41:	movzbl 0x28(%rsp),%r12d
   14f47:	cmp    0x48(%rsp),%r12b
   14f4c:	jne    1514b <inspect+0x2eb>
   14f52:	cmp    $0x1,%r12d
   14f56:	je     15003 <inspect+0x1a3>
   14f5c:	cmp    %r15,%rbx
   14f5f:	jne    14fa5 <inspect+0x145>
   14f61:	cmpl   $0x1,0x18(%rsp)
   14f66:	jne    14fd1 <inspect+0x171>
   14f68:	mov    $0x1,%edx
   14f6d:	lea    0x20(%rsp),%rdi
   14f72:	cmp    %r15,0x30(%rsp)
   14f77:	je     14fb6 <inspect+0x156>
   14f79:	mov    0x38(%rsp),%rsi
   14f7e:	mov    0x40(%rsp),%rax
   14f83:	cmp    %rax,%rdx
   14f86:	je     14ff1 <inspect+0x191>
   14f88:	jmp    1514b <inspect+0x2eb>
   14f8d:	mov    $0xfffffffffffffffd,%r14
   14f94:	jmp    15072 <inspect+0x212>
   14f99:	mov    $0xffffffffffffffff,%r14
   14fa0:	jmp    15072 <inspect+0x212>
   14fa5:	mov    0x18(%rsp),%rdi
   14faa:	mov    0x20(%rsp),%rdx
   14faf:	cmp    %r15,0x30(%rsp)
   14fb4:	jne    14f79 <inspect+0x119>
   14fb6:	cmpl   $0x1,0x38(%rsp)
   14fbb:	jne    14fe1 <inspect+0x181>
   14fbd:	mov    $0x1,%eax
   14fc2:	lea    0x40(%rsp),%rsi
   14fc7:	cmp    %rax,%rdx
   14fca:	je     14ff1 <inspect+0x191>
   14fcc:	jmp    1514b <inspect+0x2eb>
   14fd1:	mov    $0x8,%edi
   14fd6:	xor    %edx,%edx
   14fd8:	cmp    %r15,0x30(%rsp)
   14fdd:	je     14fb6 <inspect+0x156>
   14fdf:	jmp    14f79 <inspect+0x119>
   14fe1:	mov    $0x8,%esi
   14fe6:	xor    %eax,%eax
   14fe8:	cmp    %rax,%rdx
   14feb:	jne    1514b <inspect+0x2eb>
   14ff1:	shl    $0x3,%rdx
   14ff5:	call   *0x4a1f5(%rip)        # 5f1f0 <bcmp@GLIBC_2.2.5>
   14ffb:	test   %eax,%eax
   14ffd:	jne    1514b <inspect+0x2eb>
   15003:	cmp    $0x3,%ebp
   15006:	ja     15180 <inspect+0x320>
   1500c:	mov    %ebp,%eax
   1500e:	lea    -0x10715(%rip),%rcx        # 4900 <std::thread::current::id::ID+0x48b8>
   15015:	movslq (%rcx,%rax,4),%rdx
   15019:	add    %rcx,%rdx
   1501c:	jmp    *%rdx
   1501e:	mov    %rax,%r14
   15021:	jmp    15038 <inspect+0x1d8>
   15023:	test   %r12d,%r12d
   15026:	je     15085 <inspect+0x225>
   15028:	cmp    $0x1,%r12d
   1502c:	jne    15098 <inspect+0x238>
   1502e:	xor    %r14d,%r14d
   15031:	jmp    15038 <inspect+0x1d8>
   15033:	mov    0x60(%rsp),%r14
   15038:	test   %rbx,%rbx
   1503b:	jle    15054 <inspect+0x1f4>
   1503d:	mov    0x18(%rsp),%rdi
   15042:	shl    $0x3,%rbx
   15046:	mov    $0x8,%edx
   1504b:	mov    %rbx,%rsi
   1504e:	call   *0x4a1a4(%rip)        # 5f1f8 <_DYNAMIC+0x248>
   15054:	mov    0x30(%rsp),%rsi
   15059:	test   %rsi,%rsi
   1505c:	jle    15072 <inspect+0x212>
   1505e:	mov    0x38(%rsp),%rdi
   15063:	shl    $0x3,%rsi
   15067:	mov    $0x8,%edx
   1506c:	call   *0x4a186(%rip)        # 5f1f8 <_DYNAMIC+0x248>
   15072:	mov    %r14,%rax
   15075:	add    $0xc0,%rsp
   1507c:	pop    %rbx
   1507d:	pop    %r12
   1507f:	pop    %r14
   15081:	pop    %r15
   15083:	pop    %rbp
   15084:	ret
   15085:	cmp    %r15,%rbx
   15088:	jne    150af <inspect+0x24f>
   1508a:	cmpl   $0x1,0x18(%rsp)
   1508f:	jne    150fb <inspect+0x29b>
   15091:	mov    0x20(%rsp),%r14
   15096:	jmp    150fe <inspect+0x29e>
   15098:	cmp    %r15,%rbx
   1509b:	jne    150cd <inspect+0x26d>
   1509d:	cmpb   $0x0,0x18(%rsp)
   150a2:	je     15135 <inspect+0x2d5>
   150a8:	lea    0x20(%rsp),%rax
   150ad:	jmp    150ea <inspect+0x28a>
   150af:	mov    0x20(%rsp),%rax
   150b4:	test   %rax,%rax
   150b7:	je     150fb <inspect+0x29b>
   150b9:	cmp    $0x1,%rax
   150bd:	jne    15199 <inspect+0x339>
   150c3:	mov    0x18(%rsp),%rax
   150c8:	mov    (%rax),%r14
   150cb:	jmp    150fe <inspect+0x29e>
   150cd:	mov    0x20(%rsp),%rax
   150d2:	test   %rax,%rax
   150d5:	je     1502e <inspect+0x1ce>
   150db:	cmp    $0x1,%rax
   150df:	jne    15199 <inspect+0x339>
   150e5:	mov    0x18(%rsp),%rax
   150ea:	mov    (%rax),%r14
   150ed:	test   %r14,%r14
   150f0:	jns    15038 <inspect+0x1d8>
   150f6:	jmp    15199 <inspect+0x339>
   150fb:	xor    %r14d,%r14d
   150fe:	movabs $0x8000000000000000,%rax
   15108:	cmp    %rax,%r14
   1510b:	seta   %al
   1510e:	sbb    $0x0,%al
   15110:	je     1512d <inspect+0x2cd>
   15112:	movzbl %al,%eax
   15115:	cmp    $0xff,%eax
   1511a:	jne    15199 <inspect+0x339>
   1511c:	cmp    %r15,%r14
   1511f:	je     151be <inspect+0x35e>
   15125:	neg    %r14
   15128:	jmp    15038 <inspect+0x1d8>
   1512d:	mov    %r15,%r14
   15130:	jmp    15038 <inspect+0x1d8>
   15135:	xor    %r14d,%r14d
   15138:	mov    0x30(%rsp),%rsi
   1513d:	test   %rsi,%rsi
   15140:	jg     1505e <inspect+0x1fe>
   15146:	jmp    15072 <inspect+0x212>
   1514b:	lea    0x68(%rsp),%rdi
   15150:	lea    0x70(%rsp),%rsi
   15155:	call   14dd5 <core::panicking::assert_failed>
   1515a:	lea    0x47faf(%rip),%rdi        # 5d110 <__frame_dummy_init_array_entry+0x80>
   15161:	call   *0x4a099(%rip)        # 5f200 <_DYNAMIC+0x250>
   15167:	lea    -0xf116(%rip),%rdi        # 6058 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x16a>
   1516e:	lea    0x47ffb(%rip),%rdx        # 5d170 <__frame_dummy_init_array_entry+0xe0>
   15175:	mov    $0xe,%esi
   1517a:	call   *0x4a088(%rip)        # 5f208 <_DYNAMIC+0x258>
   15180:	lea    -0xf12f(%rip),%rdi        # 6058 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x16a>
   15187:	lea    0x47fca(%rip),%rdx        # 5d158 <__frame_dummy_init_array_entry+0xc8>
   1518e:	mov    $0xe,%esi
   15193:	call   *0x4a06f(%rip)        # 5f208 <_DYNAMIC+0x258>
   15199:	lea    -0xf1a8(%rip),%rdi        # 5ff8 <anon.37dfeab560d677ae39a2c3a3ace1e446.0.llvm.3523899251868836429+0x10a>
   151a0:	lea    0x47f09(%rip),%rcx        # 5d0b0 <__frame_dummy_init_array_entry+0x20>
   151a7:	lea    0x47f92(%rip),%r8        # 5d140 <__frame_dummy_init_array_entry+0xb0>
   151ae:	lea    0xf(%rsp),%rdx
   151b3:	mov    $0x2b,%esi
   151b8:	call   *0x4a052(%rip)        # 5f210 <_DYNAMIC+0x260>
   151be:	lea    0x47ed3(%rip),%rdi        # 5d098 <__frame_dummy_init_array_entry+0x8>
   151c5:	call   *0x4a04d(%rip)        # 5f218 <_DYNAMIC+0x268>
   151cb:	int3
   151cc:	int3
   151cd:	int3
   151ce:	int3
   151cf:	int3

0000000000015770 <hyperinterval::dyadic::DyadicInterval::from_f32>:
   15770:	push   %r15
   15772:	push   %r14
   15774:	push   %rbx
   15775:	sub    $0x40,%rsp
   15779:	mov    %rsi,%r14
   1577c:	mov    %rdi,%rbx
   1577f:	movabs $0x8000000000000000,%r15
   15789:	movd   %xmm0,%ecx
   1578d:	mov    %rsp,%rdi
   15790:	mov    $0x80000000,%esi
   15795:	mov    $0x7f800000,%edx
   1579a:	call   158d0 <hyperinterval::ieee::Format::finite>
   1579f:	cmpb   $0x1,(%rsp)
   157a3:	jne    157af <hyperinterval::dyadic::DyadicInterval::from_f32+0x3f>
   157a5:	movzbl 0x1(%rsp),%eax
   157aa:	mov    %al,0x8(%rbx)
   157ad:	jmp    1581f <hyperinterval::dyadic::DyadicInterval::from_f32+0xaf>
   157af:	mov    0x8(%rsp),%rdx
   157b4:	mov    %edx,%eax
   157b6:	shr    $0x17,%eax
   157b9:	movzbl %al,%eax
   157bc:	mov    %edx,%esi
   157be:	and    $0x7fffff,%esi
   157c4:	lea    -0x96(%rax),%edi
   157ca:	test   %eax,%eax
   157cc:	mov    $0xffffff6b,%ecx
   157d1:	cmovne %edi,%ecx
   157d4:	lea    0x800000(%rsi),%rdi
   157db:	cmove  %rsi,%rdi
   157df:	mov    %rdi,%rax
   157e2:	neg    %rax
   157e5:	test   %edx,%edx
   157e7:	cmovns %rdi,%rax
   157eb:	mov    $0x7f,%edx
   157f0:	bsr    %rdi,%rdx
   157f4:	xor    $0xffffffffffffffc0,%rdx
   157f8:	add    $0x41,%rdx
   157fc:	mov    $0xc,%sil
   157ff:	cmp    (%r14),%rdx
   15802:	ja     1581b <hyperinterval::dyadic::DyadicInterval::from_f32+0xab>
   15804:	cmp    $0x1,%rdx
   15808:	adc    $0x0,%rdx
   1580c:	add    %rdx,%rdx
   1580f:	mov    0x8(%r14),%rdi
   15813:	mov    $0xb,%sil
   15816:	sub    %rdx,%rdi
   15819:	jae    15833 <hyperinterval::dyadic::DyadicInterval::from_f32+0xc3>
   1581b:	mov    %sil,0x8(%rbx)
   1581f:	add    $0x2,%r15
   15823:	mov    %r15,(%rbx)
   15826:	mov    %rbx,%rax
   15829:	add    $0x40,%rsp
   1582d:	pop    %rbx
   1582e:	pop    %r14
   15830:	pop    %r15
   15832:	ret
   15833:	mov    %rdi,0x8(%r14)
   15837:	test   %rax,%rax
   1583a:	js     15860 <hyperinterval::dyadic::DyadicInterval::from_f32+0xf0>
   1583c:	mov    $0x2,%dl
   1583e:	jne    15871 <hyperinterval::dyadic::DyadicInterval::from_f32+0x101>
   15840:	movups -0xf7cf(%rip),%xmm0        # 6078 <anon.769a2ada85e5dd24347a18cb71414845.0.llvm.8452990580343394626+0x10>
   15847:	movaps %xmm0,0x30(%rsp)
   1584c:	movdqu -0xf7ec(%rip),%xmm0        # 6068 <anon.769a2ada85e5dd24347a18cb71414845.0.llvm.8452990580343394626>
   15854:	movdqa %xmm0,0x20(%rsp)
   1585a:	mov    $0x1,%dl
   1585c:	xor    %esi,%esi
   1585e:	jmp    1588d <hyperinterval::dyadic::DyadicInterval::from_f32+0x11d>
   15860:	mov    %rax,%rsi
   15863:	neg    %rsi
   15866:	not    %eax
   15868:	cmp    %eax,%esi
   1586a:	jb     158b5 <hyperinterval::dyadic::DyadicInterval::from_f32+0x145>
   1586c:	xor    %edx,%edx
   1586e:	mov    %rsi,%rax
   15871:	mov    %dl,0x38(%rsp)
   15875:	mov    %r15,0x20(%rsp)
   1587a:	movq   $0x1,0x28(%rsp)
   15883:	mov    %rax,0x30(%rsp)
   15888:	mov    $0x1,%esi
   1588d:	mov    %dl,0x18(%rsp)
   15891:	mov    %r15,(%rsp)
   15895:	mov    %rsi,0x8(%rsp)
   1589a:	mov    %rax,0x10(%rsp)
   1589f:	mov    %rsp,%rsi
   158a2:	lea    0x20(%rsp),%rdx
   158a7:	mov    %rbx,%rdi
   158aa:	call   *0x49990(%rip)        # 5f240 <_DYNAMIC+0x290>
   158b0:	jmp    15826 <hyperinterval::dyadic::DyadicInterval::from_f32+0xb6>
   158b5:	lea    0x478cc(%rip),%rdi        # 5d188 <__frame_dummy_init_array_entry+0xf8>
   158bc:	call   *0x499ee(%rip)        # 5f2b0 <_DYNAMIC+0x300>
   158c2:	int3
   158c3:	int3
   158c4:	int3
   158c5:	int3
   158c6:	int3
   158c7:	int3
   158c8:	int3
   158c9:	int3
   158ca:	int3
   158cb:	int3
   158cc:	int3
   158cd:	int3
   158ce:	int3
   158cf:	int3

00000000000158d0 <hyperinterval::ieee::Format::finite>:
   158d0:	mov    %rcx,%rax
   158d3:	not    %rax
   158d6:	test   %rax,%rdx
   158d9:	jne    158e7 <hyperinterval::ieee::Format::finite+0x17>
   158db:	movb   $0x0,0x1(%rdi)
   158df:	mov    $0x1,%al
   158e1:	mov    %al,(%rdi)
   158e3:	mov    %rdi,%rax
   158e6:	ret
   158e7:	test   %rsi,%rsi
   158ea:	je     15910 <hyperinterval::ieee::Format::finite+0x40>
   158ec:	dec    %rsi
   158ef:	test   %rsi,%rcx
   158f2:	je     15900 <hyperinterval::ieee::Format::finite+0x30>
   158f4:	mov    %rcx,0x8(%rdi)
   158f8:	xor    %eax,%eax
   158fa:	mov    %al,(%rdi)
   158fc:	mov    %rdi,%rax
   158ff:	ret
   15900:	movq   $0x0,0x8(%rdi)
   15908:	xor    %eax,%eax
   1590a:	mov    %al,(%rdi)
   1590c:	mov    %rdi,%rax
   1590f:	ret
   15910:	push   %rax
   15911:	lea    0x478a0(%rip),%rdi        # 5d1b8 <anon.f82134d8c3ea0a52de317b9b570b4bdc.2.llvm.13065751716895374897+0x18>
   15918:	call   *0x49982(%rip)        # 5f2a0 <_DYNAMIC+0x2f0>
   1591e:	int3
   1591f:	int3

