00000000000145e0 <inspect>:
   145e0:	push   %rbp
   145e1:	push   %r15
   145e3:	push   %r14
   145e5:	push   %r12
   145e7:	push   %rbx
   145e8:	sub    $0xc0,%rsp
   145ef:	mov    %ecx,%ebp
   145f1:	movabs $0x8000000000000000,%r15
   145fb:	mov    %esi,%eax
   145fd:	mov    %edx,%ecx
   145ff:	mov    %rax,0x58(%rsp)
   14604:	mov    %rcx,0x60(%rsp)
   14609:	movd   %edi,%xmm0
   1460d:	lea    0x78(%rsp),%rdi
   14612:	lea    0x58(%rsp),%rsi
   14617:	call   *0x450a3(%rip)        # 596c0 <_DYNAMIC+0x238>
   1461d:	lea    0x1(%r15),%rax
   14621:	cmp    %rax,0x78(%rsp)
   14626:	jne    14656 <inspect+0x76>
   14628:	movzbl 0x80(%rsp),%eax
   14630:	test   %eax,%eax
   14632:	je     14729 <inspect+0x149>
   14638:	cmp    $0xb,%eax
   1463b:	je     14720 <inspect+0x140>
   14641:	cmp    $0xc,%eax
   14644:	jne    14832 <inspect+0x252>
   1464a:	mov    $0xfffffffffffffffe,%r14
   14651:	jmp    14781 <inspect+0x1a1>
   14656:	movdqu 0x78(%rsp),%xmm0
   1465c:	movups 0x88(%rsp),%xmm1
   14664:	movups 0x98(%rsp),%xmm2
   1466c:	movups 0xa8(%rsp),%xmm3
   14674:	movdqa %xmm0,0x10(%rsp)
   1467a:	mov    0xb8(%rsp),%rax
   14682:	mov    %rax,0x50(%rsp)
   14687:	movaps %xmm3,0x40(%rsp)
   1468c:	movaps %xmm2,0x30(%rsp)
   14691:	movaps %xmm1,0x20(%rsp)
   14696:	mov    0x10(%rsp),%rbx
   1469b:	cmp    %r15,%rbx
   1469e:	je     14825 <inspect+0x245>
   146a4:	lea    0x30(%rsp),%rax
   146a9:	movslq 0x50(%rsp),%r14
   146ae:	lea    0x10(%rsp),%rcx
   146b3:	mov    %rcx,0x68(%rsp)
   146b8:	mov    %rax,0x70(%rsp)
   146bd:	movzbl 0x28(%rsp),%r12d
   146c3:	cmp    0x48(%rsp),%r12b
   146c8:	jne    14816 <inspect+0x236>
   146ce:	cmp    $0x1,%r12d
   146d2:	je     14700 <inspect+0x120>
   146d4:	mov    0x20(%rsp),%rdx
   146d9:	cmp    0x40(%rsp),%rdx
   146de:	jne    14816 <inspect+0x236>
   146e4:	mov    0x18(%rsp),%rdi
   146e9:	mov    0x38(%rsp),%rsi
   146ee:	shl    $0x3,%rdx
   146f2:	call   *0x44fd0(%rip)        # 596c8 <bcmp@GLIBC_2.2.5>
   146f8:	test   %eax,%eax
   146fa:	jne    14816 <inspect+0x236>
   14700:	cmp    $0x3,%ebp
   14703:	ja     1484b <inspect+0x26b>
   14709:	mov    %ebp,%eax
   1470b:	lea    -0x10012(%rip),%rcx        # 4700 <std::thread::current::id::ID+0x46b8>
   14712:	movslq (%rcx,%rax,4),%rdx
   14716:	add    %rcx,%rdx
   14719:	jmp    *%rdx
   1471b:	mov    %rax,%r14
   1471e:	jmp    14747 <inspect+0x167>
   14720:	mov    $0xfffffffffffffffd,%r14
   14727:	jmp    14781 <inspect+0x1a1>
   14729:	mov    $0xffffffffffffffff,%r14
   14730:	jmp    14781 <inspect+0x1a1>
   14732:	test   %r12d,%r12d
   14735:	je     14794 <inspect+0x1b4>
   14737:	cmp    $0x1,%r12d
   1473b:	jne    147b2 <inspect+0x1d2>
   1473d:	xor    %r14d,%r14d
   14740:	jmp    14747 <inspect+0x167>
   14742:	mov    0x60(%rsp),%r14
   14747:	test   %rbx,%rbx
   1474a:	je     14763 <inspect+0x183>
   1474c:	mov    0x18(%rsp),%rdi
   14751:	shl    $0x3,%rbx
   14755:	mov    $0x8,%edx
   1475a:	mov    %rbx,%rsi
   1475d:	call   *0x44f6d(%rip)        # 596d0 <_DYNAMIC+0x248>
   14763:	mov    0x30(%rsp),%rsi
   14768:	test   %rsi,%rsi
   1476b:	je     14781 <inspect+0x1a1>
   1476d:	mov    0x38(%rsp),%rdi
   14772:	shl    $0x3,%rsi
   14776:	mov    $0x8,%edx
   1477b:	call   *0x44f4f(%rip)        # 596d0 <_DYNAMIC+0x248>
   14781:	mov    %r14,%rax
   14784:	add    $0xc0,%rsp
   1478b:	pop    %rbx
   1478c:	pop    %r12
   1478e:	pop    %r14
   14790:	pop    %r15
   14792:	pop    %rbp
   14793:	ret
   14794:	mov    0x20(%rsp),%rax
   14799:	test   %rax,%rax
   1479c:	je     147dc <inspect+0x1fc>
   1479e:	cmp    $0x1,%rax
   147a2:	jne    14864 <inspect+0x284>
   147a8:	mov    0x18(%rsp),%rax
   147ad:	mov    (%rax),%r14
   147b0:	jmp    147df <inspect+0x1ff>
   147b2:	mov    0x20(%rsp),%r14
   147b7:	test   %r14,%r14
   147ba:	je     14747 <inspect+0x167>
   147bc:	cmp    $0x1,%r14
   147c0:	jne    14864 <inspect+0x284>
   147c6:	mov    0x18(%rsp),%rax
   147cb:	mov    (%rax),%r14
   147ce:	test   %r14,%r14
   147d1:	jns    14747 <inspect+0x167>
   147d7:	jmp    14864 <inspect+0x284>
   147dc:	xor    %r14d,%r14d
   147df:	movabs $0x8000000000000000,%rax
   147e9:	cmp    %rax,%r14
   147ec:	seta   %al
   147ef:	sbb    $0x0,%al
   147f1:	je     1480e <inspect+0x22e>
   147f3:	movzbl %al,%eax
   147f6:	cmp    $0xff,%eax
   147fb:	jne    14864 <inspect+0x284>
   147fd:	cmp    %r15,%r14
   14800:	je     14889 <inspect+0x2a9>
   14806:	neg    %r14
   14809:	jmp    14747 <inspect+0x167>
   1480e:	mov    %r15,%r14
   14811:	jmp    14747 <inspect+0x167>
   14816:	lea    0x68(%rsp),%rdi
   1481b:	lea    0x70(%rsp),%rsi
   14820:	call   1454c <core::panicking::assert_failed>
   14825:	lea    0x42fb4(%rip),%rdi        # 577e0 <__frame_dummy_init_array_entry+0x80>
   1482c:	call   *0x44ea6(%rip)        # 596d8 <_DYNAMIC+0x250>
   14832:	lea    -0xea59(%rip),%rdi        # 5de0 <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x18c>
   14839:	lea    0x43000(%rip),%rdx        # 57840 <__frame_dummy_init_array_entry+0xe0>
   14840:	mov    $0xe,%esi
   14845:	call   *0x44e95(%rip)        # 596e0 <_DYNAMIC+0x258>
   1484b:	lea    -0xea72(%rip),%rdi        # 5de0 <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x18c>
   14852:	lea    0x42fcf(%rip),%rdx        # 57828 <__frame_dummy_init_array_entry+0xc8>
   14859:	mov    $0xe,%esi
   1485e:	call   *0x44e7c(%rip)        # 596e0 <_DYNAMIC+0x258>
   14864:	lea    -0xeaec(%rip),%rdi        # 5d7f <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x12b>
   1486b:	lea    0x42f0e(%rip),%rcx        # 57780 <__frame_dummy_init_array_entry+0x20>
   14872:	lea    0x42f97(%rip),%r8        # 57810 <__frame_dummy_init_array_entry+0xb0>
   14879:	lea    0xf(%rsp),%rdx
   1487e:	mov    $0x2b,%esi
   14883:	call   *0x44e5f(%rip)        # 596e8 <_DYNAMIC+0x260>
   14889:	lea    0x42ed8(%rip),%rdi        # 57768 <__frame_dummy_init_array_entry+0x8>
   14890:	call   *0x44e5a(%rip)        # 596f0 <_DYNAMIC+0x268>
   14896:	int3
   14897:	int3
   14898:	int3
   14899:	int3
   1489a:	int3
   1489b:	int3
   1489c:	int3
   1489d:	int3
   1489e:	int3
   1489f:	int3

0000000000014d20 <hyperinterval::dyadic::DyadicInterval::from_f32>:
   14d20:	push   %rbp
   14d21:	push   %r15
   14d23:	push   %r14
   14d25:	push   %r12
   14d27:	push   %rbx
   14d28:	sub    $0x40,%rsp
   14d2c:	mov    %rsi,%r14
   14d2f:	mov    %rdi,%rbx
   14d32:	movd   %xmm0,%ecx
   14d36:	mov    %rsp,%rdi
   14d39:	mov    $0x80000000,%esi
   14d3e:	mov    $0x7f800000,%edx
   14d43:	call   14f40 <hyperinterval::ieee::Format::finite>
   14d48:	cmpb   $0x1,(%rsp)
   14d4c:	jne    14d58 <hyperinterval::dyadic::DyadicInterval::from_f32+0x38>
   14d4e:	movzbl 0x1(%rsp),%eax
   14d53:	mov    %al,0x8(%rbx)
   14d56:	jmp    14dc5 <hyperinterval::dyadic::DyadicInterval::from_f32+0xa5>
   14d58:	mov    0x8(%rsp),%rax
   14d5d:	mov    %eax,%ecx
   14d5f:	shr    $0x17,%ecx
   14d62:	movzbl %cl,%ecx
   14d65:	mov    %eax,%edx
   14d67:	and    $0x7fffff,%edx
   14d6d:	lea    -0x96(%rcx),%esi
   14d73:	test   %ecx,%ecx
   14d75:	mov    $0xffffff6b,%ebp
   14d7a:	cmovne %esi,%ebp
   14d7d:	lea    0x800000(%rdx),%rcx
   14d84:	cmove  %rdx,%rcx
   14d88:	mov    %rcx,%r15
   14d8b:	neg    %r15
   14d8e:	test   %eax,%eax
   14d90:	cmovns %rcx,%r15
   14d94:	mov    $0x7f,%eax
   14d99:	bsr    %rcx,%rax
   14d9d:	xor    $0xffffffffffffffc0,%rax
   14da1:	add    $0x41,%rax
   14da5:	mov    $0xc,%cl
   14da7:	cmp    (%r14),%rax
   14daa:	ja     14dc2 <hyperinterval::dyadic::DyadicInterval::from_f32+0xa2>
   14dac:	cmp    $0x1,%rax
   14db0:	adc    $0x0,%rax
   14db4:	add    %rax,%rax
   14db7:	mov    0x8(%r14),%rdx
   14dbb:	mov    $0xb,%cl
   14dbd:	sub    %rax,%rdx
   14dc0:	jae    14de2 <hyperinterval::dyadic::DyadicInterval::from_f32+0xc2>
   14dc2:	mov    %cl,0x8(%rbx)
   14dc5:	movabs $0x8000000000000001,%rax
   14dcf:	mov    %rax,(%rbx)
   14dd2:	mov    %rbx,%rax
   14dd5:	add    $0x40,%rsp
   14dd9:	pop    %rbx
   14dda:	pop    %r12
   14ddc:	pop    %r14
   14dde:	pop    %r15
   14de0:	pop    %rbp
   14de1:	ret
   14de2:	mov    %rdx,0x8(%r14)
   14de6:	test   %r15,%r15
   14de9:	js     14e26 <hyperinterval::dyadic::DyadicInterval::from_f32+0x106>
   14deb:	je     14eae <hyperinterval::dyadic::DyadicInterval::from_f32+0x18e>
   14df1:	movdqu -0xefa9(%rip),%xmm0        # 5e50 <anon.53cf31723ae822dc8dd898361f531073.0.llvm.13889084832344244462+0x40>
   14df9:	movdqa %xmm0,(%rsp)
   14dfe:	movq   $0x0,0x10(%rsp)
   14e07:	mov    %rsp,%rdi
   14e0a:	call   *0x44950(%rip)        # 59760 <_DYNAMIC+0x2d8>
   14e10:	mov    0x8(%rsp),%rax
   14e15:	mov    %r15,(%rax)
   14e18:	mov    (%rsp),%r12
   14e1c:	mov    0x8(%rsp),%r15
   14e21:	mov    $0x2,%r14b
   14e24:	jmp    14e6b <hyperinterval::dyadic::DyadicInterval::from_f32+0x14b>
   14e26:	mov    %r15,%r14
   14e29:	neg    %r14
   14e2c:	not    %r15d
   14e2f:	cmp    %r15d,%r14d
   14e32:	jb     14f27 <hyperinterval::dyadic::DyadicInterval::from_f32+0x207>
   14e38:	movdqu -0xeff0(%rip),%xmm0        # 5e50 <anon.53cf31723ae822dc8dd898361f531073.0.llvm.13889084832344244462+0x40>
   14e40:	movdqa %xmm0,(%rsp)
   14e45:	movq   $0x0,0x10(%rsp)
   14e4e:	mov    %rsp,%rdi
   14e51:	call   *0x44909(%rip)        # 59760 <_DYNAMIC+0x2d8>
   14e57:	mov    0x8(%rsp),%rax
   14e5c:	mov    %r14,(%rax)
   14e5f:	mov    (%rsp),%r12
   14e63:	mov    0x8(%rsp),%r15
   14e68:	xor    %r14d,%r14d
   14e6b:	call   *0x4489f(%rip)        # 59710 <_DYNAMIC+0x288>
   14e71:	mov    $0x8,%edi
   14e76:	mov    $0x8,%esi
   14e7b:	call   *0x44877(%rip)        # 596f8 <_DYNAMIC+0x270>
   14e81:	test   %rax,%rax
   14e84:	je     14f17 <hyperinterval::dyadic::DyadicInterval::from_f32+0x1f7>
   14e8a:	movq   $0x1,0x20(%rsp)
   14e93:	mov    %rax,0x28(%rsp)
   14e98:	mov    (%r15),%rcx
   14e9b:	mov    %rcx,(%rax)
   14e9e:	movq   $0x1,0x30(%rsp)
   14ea7:	mov    $0x1,%eax
   14eac:	jmp    14ed7 <hyperinterval::dyadic::DyadicInterval::from_f32+0x1b7>
   14eae:	movq   $0x0,0x20(%rsp)
   14eb7:	movq   $0x8,0x28(%rsp)
   14ec0:	movq   $0x0,0x30(%rsp)
   14ec9:	mov    $0x1,%r14b
   14ecc:	mov    $0x8,%r15d
   14ed2:	xor    %r12d,%r12d
   14ed5:	xor    %eax,%eax
   14ed7:	mov    %r14b,0x38(%rsp)
   14edc:	mov    %r12,(%rsp)
   14ee0:	mov    %r15,0x8(%rsp)
   14ee5:	mov    %rax,0x10(%rsp)
   14eea:	mov    %r14b,0x18(%rsp)
   14eef:	movl   $0x0,0x19(%rsp)
   14ef7:	movl   $0x0,0x1c(%rsp)
   14eff:	lea    0x20(%rsp),%rsi
   14f04:	mov    %rsp,%rdx
   14f07:	mov    %rbx,%rdi
   14f0a:	mov    %ebp,%ecx
   14f0c:	call   *0x44806(%rip)        # 59718 <_DYNAMIC+0x290>
   14f12:	jmp    14dd2 <hyperinterval::dyadic::DyadicInterval::from_f32+0xb2>
   14f17:	mov    $0x8,%edi
   14f1c:	mov    $0x8,%esi
   14f21:	call   *0x44801(%rip)        # 59728 <_DYNAMIC+0x2a0>
   14f27:	lea    0x4292a(%rip),%rdi        # 57858 <__frame_dummy_init_array_entry+0xf8>
   14f2e:	call   *0x44854(%rip)        # 59788 <_DYNAMIC+0x300>
   14f34:	int3
   14f35:	int3
   14f36:	int3
   14f37:	int3
   14f38:	int3
   14f39:	int3
   14f3a:	int3
   14f3b:	int3
   14f3c:	int3
   14f3d:	int3
   14f3e:	int3
   14f3f:	int3

0000000000014f40 <hyperinterval::ieee::Format::finite>:
   14f40:	mov    %rcx,%rax
   14f43:	not    %rax
   14f46:	test   %rax,%rdx
   14f49:	jne    14f57 <hyperinterval::ieee::Format::finite+0x17>
   14f4b:	movb   $0x0,0x1(%rdi)
   14f4f:	mov    $0x1,%al
   14f51:	mov    %al,(%rdi)
   14f53:	mov    %rdi,%rax
   14f56:	ret
   14f57:	test   %rsi,%rsi
   14f5a:	je     14f80 <hyperinterval::ieee::Format::finite+0x40>
   14f5c:	dec    %rsi
   14f5f:	test   %rsi,%rcx
   14f62:	je     14f70 <hyperinterval::ieee::Format::finite+0x30>
   14f64:	mov    %rcx,0x8(%rdi)
   14f68:	xor    %eax,%eax
   14f6a:	mov    %al,(%rdi)
   14f6c:	mov    %rdi,%rax
   14f6f:	ret
   14f70:	movq   $0x0,0x8(%rdi)
   14f78:	xor    %eax,%eax
   14f7a:	mov    %al,(%rdi)
   14f7c:	mov    %rdi,%rax
   14f7f:	ret
   14f80:	push   %rax
   14f81:	lea    0x42900(%rip),%rdi        # 57888 <anon.b929e642be06ab33e60b1a6aaa84cad1.2.llvm.16587406844078298691+0x18>
   14f88:	call   *0x44812(%rip)        # 597a0 <_DYNAMIC+0x318>
   14f8e:	int3
   14f8f:	int3

