00000000000145e0 <inspect>:
   145e0:	push   %rbp
   145e1:	push   %r15
   145e3:	push   %r14
   145e5:	push   %r12
   145e7:	push   %rbx
   145e8:	sub    $0xc0,%rsp
   145ef:	mov    %ecx,%ebp
   145f1:	movabs $0x8000000000000000,%r15
   145fb:	mov    %esi,%eax
   145fd:	mov    %edx,%ecx
   145ff:	mov    %rax,0x58(%rsp)
   14604:	mov    %rcx,0x60(%rsp)
   14609:	movd   %edi,%xmm0
   1460d:	cvtss2sd %xmm0,%xmm0
   14611:	lea    0x78(%rsp),%rdi
   14616:	lea    0x58(%rsp),%rsi
   1461b:	call   *0x450af(%rip)        # 596d0 <_DYNAMIC+0x238>
   14621:	lea    0x1(%r15),%rax
   14625:	cmp    %rax,0x78(%rsp)
   1462a:	jne    1465a <inspect+0x7a>
   1462c:	movzbl 0x80(%rsp),%eax
   14634:	test   %eax,%eax
   14636:	je     1472b <inspect+0x14b>
   1463c:	cmp    $0xb,%eax
   1463f:	je     14722 <inspect+0x142>
   14645:	cmp    $0xc,%eax
   14648:	jne    14834 <inspect+0x254>
   1464e:	mov    $0xfffffffffffffffe,%r14
   14655:	jmp    14783 <inspect+0x1a3>
   1465a:	movups 0x78(%rsp),%xmm0
   1465f:	movups 0x88(%rsp),%xmm1
   14667:	movups 0x98(%rsp),%xmm2
   1466f:	movups 0xa8(%rsp),%xmm3
   14677:	movaps %xmm0,0x10(%rsp)
   1467c:	mov    0xb8(%rsp),%rax
   14684:	mov    %rax,0x50(%rsp)
   14689:	movaps %xmm3,0x40(%rsp)
   1468e:	movaps %xmm2,0x30(%rsp)
   14693:	movaps %xmm1,0x20(%rsp)
   14698:	mov    0x10(%rsp),%rbx
   1469d:	cmp    %r15,%rbx
   146a0:	je     14827 <inspect+0x247>
   146a6:	lea    0x30(%rsp),%rax
   146ab:	movslq 0x50(%rsp),%r14
   146b0:	lea    0x10(%rsp),%rcx
   146b5:	mov    %rcx,0x68(%rsp)
   146ba:	mov    %rax,0x70(%rsp)
   146bf:	movzbl 0x28(%rsp),%r12d
   146c5:	cmp    0x48(%rsp),%r12b
   146ca:	jne    14818 <inspect+0x238>
   146d0:	cmp    $0x1,%r12d
   146d4:	je     14702 <inspect+0x122>
   146d6:	mov    0x20(%rsp),%rdx
   146db:	cmp    0x40(%rsp),%rdx
   146e0:	jne    14818 <inspect+0x238>
   146e6:	mov    0x18(%rsp),%rdi
   146eb:	mov    0x38(%rsp),%rsi
   146f0:	shl    $0x3,%rdx
   146f4:	call   *0x44fde(%rip)        # 596d8 <bcmp@GLIBC_2.2.5>
   146fa:	test   %eax,%eax
   146fc:	jne    14818 <inspect+0x238>
   14702:	cmp    $0x3,%ebp
   14705:	ja     1484d <inspect+0x26d>
   1470b:	mov    %ebp,%eax
   1470d:	lea    -0x10014(%rip),%rcx        # 4700 <std::thread::current::id::ID+0x46b8>
   14714:	movslq (%rcx,%rax,4),%rdx
   14718:	add    %rcx,%rdx
   1471b:	jmp    *%rdx
   1471d:	mov    %rax,%r14
   14720:	jmp    14749 <inspect+0x169>
   14722:	mov    $0xfffffffffffffffd,%r14
   14729:	jmp    14783 <inspect+0x1a3>
   1472b:	mov    $0xffffffffffffffff,%r14
   14732:	jmp    14783 <inspect+0x1a3>
   14734:	test   %r12d,%r12d
   14737:	je     14796 <inspect+0x1b6>
   14739:	cmp    $0x1,%r12d
   1473d:	jne    147b4 <inspect+0x1d4>
   1473f:	xor    %r14d,%r14d
   14742:	jmp    14749 <inspect+0x169>
   14744:	mov    0x60(%rsp),%r14
   14749:	test   %rbx,%rbx
   1474c:	je     14765 <inspect+0x185>
   1474e:	mov    0x18(%rsp),%rdi
   14753:	shl    $0x3,%rbx
   14757:	mov    $0x8,%edx
   1475c:	mov    %rbx,%rsi
   1475f:	call   *0x44f7b(%rip)        # 596e0 <_DYNAMIC+0x248>
   14765:	mov    0x30(%rsp),%rsi
   1476a:	test   %rsi,%rsi
   1476d:	je     14783 <inspect+0x1a3>
   1476f:	mov    0x38(%rsp),%rdi
   14774:	shl    $0x3,%rsi
   14778:	mov    $0x8,%edx
   1477d:	call   *0x44f5d(%rip)        # 596e0 <_DYNAMIC+0x248>
   14783:	mov    %r14,%rax
   14786:	add    $0xc0,%rsp
   1478d:	pop    %rbx
   1478e:	pop    %r12
   14790:	pop    %r14
   14792:	pop    %r15
   14794:	pop    %rbp
   14795:	ret
   14796:	mov    0x20(%rsp),%rax
   1479b:	test   %rax,%rax
   1479e:	je     147de <inspect+0x1fe>
   147a0:	cmp    $0x1,%rax
   147a4:	jne    14866 <inspect+0x286>
   147aa:	mov    0x18(%rsp),%rax
   147af:	mov    (%rax),%r14
   147b2:	jmp    147e1 <inspect+0x201>
   147b4:	mov    0x20(%rsp),%r14
   147b9:	test   %r14,%r14
   147bc:	je     14749 <inspect+0x169>
   147be:	cmp    $0x1,%r14
   147c2:	jne    14866 <inspect+0x286>
   147c8:	mov    0x18(%rsp),%rax
   147cd:	mov    (%rax),%r14
   147d0:	test   %r14,%r14
   147d3:	jns    14749 <inspect+0x169>
   147d9:	jmp    14866 <inspect+0x286>
   147de:	xor    %r14d,%r14d
   147e1:	movabs $0x8000000000000000,%rax
   147eb:	cmp    %rax,%r14
   147ee:	seta   %al
   147f1:	sbb    $0x0,%al
   147f3:	je     14810 <inspect+0x230>
   147f5:	movzbl %al,%eax
   147f8:	cmp    $0xff,%eax
   147fd:	jne    14866 <inspect+0x286>
   147ff:	cmp    %r15,%r14
   14802:	je     1488b <inspect+0x2ab>
   14808:	neg    %r14
   1480b:	jmp    14749 <inspect+0x169>
   14810:	mov    %r15,%r14
   14813:	jmp    14749 <inspect+0x169>
   14818:	lea    0x68(%rsp),%rdi
   1481d:	lea    0x70(%rsp),%rsi
   14822:	call   1454c <core::panicking::assert_failed>
   14827:	lea    0x42fc2(%rip),%rdi        # 577f0 <__frame_dummy_init_array_entry+0x80>
   1482e:	call   *0x44eb4(%rip)        # 596e8 <_DYNAMIC+0x250>
   14834:	lea    -0xea5b(%rip),%rdi        # 5de0 <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x18c>
   1483b:	lea    0x4300e(%rip),%rdx        # 57850 <__frame_dummy_init_array_entry+0xe0>
   14842:	mov    $0xe,%esi
   14847:	call   *0x44ea3(%rip)        # 596f0 <_DYNAMIC+0x258>
   1484d:	lea    -0xea74(%rip),%rdi        # 5de0 <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x18c>
   14854:	lea    0x42fdd(%rip),%rdx        # 57838 <__frame_dummy_init_array_entry+0xc8>
   1485b:	mov    $0xe,%esi
   14860:	call   *0x44e8a(%rip)        # 596f0 <_DYNAMIC+0x258>
   14866:	lea    -0xeaee(%rip),%rdi        # 5d7f <anon.8e907809e063a7a381d94359941f1cdb.4.llvm.4831172576184067427+0x12b>
   1486d:	lea    0x42f1c(%rip),%rcx        # 57790 <__frame_dummy_init_array_entry+0x20>
   14874:	lea    0x42fa5(%rip),%r8        # 57820 <__frame_dummy_init_array_entry+0xb0>
   1487b:	lea    0xf(%rsp),%rdx
   14880:	mov    $0x2b,%esi
   14885:	call   *0x44e6d(%rip)        # 596f8 <_DYNAMIC+0x260>
   1488b:	lea    0x42ee6(%rip),%rdi        # 57778 <__frame_dummy_init_array_entry+0x8>
   14892:	call   *0x44e68(%rip)        # 59700 <_DYNAMIC+0x268>
   14898:	int3
   14899:	int3
   1489a:	int3
   1489b:	int3
   1489c:	int3
   1489d:	int3
   1489e:	int3
   1489f:	int3

0000000000014d20 <hyperinterval::dyadic::DyadicInterval::from_f64>:
   14d20:	push   %rbp
   14d21:	push   %r15
   14d23:	push   %r14
   14d25:	push   %r12
   14d27:	push   %rbx
   14d28:	sub    $0x40,%rsp
   14d2c:	mov    %rsi,%r14
   14d2f:	mov    %rdi,%rbx
   14d32:	movabs $0x8000000000000001,%r15
   14d3c:	movq   %xmm0,%rcx
   14d41:	lea    -0x1(%r15),%rsi
   14d45:	mov    %rsp,%rdi
   14d48:	movabs $0x7ff0000000000000,%rdx
   14d52:	call   14f50 <hyperinterval::ieee::Format::finite>
   14d57:	cmpb   $0x1,(%rsp)
   14d5b:	jne    14d6d <hyperinterval::dyadic::DyadicInterval::from_f64+0x4d>
   14d5d:	movzbl 0x1(%rsp),%eax
   14d62:	mov    %al,0x8(%rbx)
   14d65:	mov    %r15,(%rbx)
   14d68:	jmp    14f1f <hyperinterval::dyadic::DyadicInterval::from_f64+0x1ff>
   14d6d:	mov    0x8(%rsp),%rax
   14d72:	mov    %rax,%rcx
   14d75:	shr    $0x34,%rcx
   14d79:	and    $0x7ff,%ecx
   14d7f:	movabs $0xfffffffffffff,%rdx
   14d89:	mov    %rax,%rsi
   14d8c:	and    %rdx,%rsi
   14d8f:	lea    -0x433(%rcx),%edi
   14d95:	test   %rcx,%rcx
   14d98:	mov    $0xfffffbce,%ebp
   14d9d:	cmovne %edi,%ebp
   14da0:	lea    0x1(%rsi,%rdx,1),%rcx
   14da5:	cmove  %rsi,%rcx
   14da9:	mov    %rcx,%r12
   14dac:	neg    %r12
   14daf:	test   %rax,%rax
   14db2:	cmovns %rcx,%r12
   14db6:	mov    $0x7f,%eax
   14dbb:	bsr    %rcx,%rax
   14dbf:	xor    $0xffffffffffffffc0,%rax
   14dc3:	add    $0x41,%rax
   14dc7:	mov    $0xc,%cl
   14dc9:	cmp    (%r14),%rax
   14dcc:	ja     14de4 <hyperinterval::dyadic::DyadicInterval::from_f64+0xc4>
   14dce:	cmp    $0x1,%rax
   14dd2:	adc    $0x0,%rax
   14dd6:	add    %rax,%rax
   14dd9:	mov    0x8(%r14),%rdx
   14ddd:	mov    $0xb,%cl
   14ddf:	sub    %rax,%rdx
   14de2:	jae    14def <hyperinterval::dyadic::DyadicInterval::from_f64+0xcf>
   14de4:	mov    %cl,0x8(%rbx)
   14de7:	mov    %r15,(%rbx)
   14dea:	jmp    14f1f <hyperinterval::dyadic::DyadicInterval::from_f64+0x1ff>
   14def:	mov    %rdx,0x8(%r14)
   14df3:	test   %r12,%r12
   14df6:	js     14e33 <hyperinterval::dyadic::DyadicInterval::from_f64+0x113>
   14df8:	je     14ebb <hyperinterval::dyadic::DyadicInterval::from_f64+0x19b>
   14dfe:	movdqu -0xefb6(%rip),%xmm0        # 5e50 <anon.01be079ac99a956f7c1b4709c9de7b80.0.llvm.18091967735760447062+0x40>
   14e06:	movdqa %xmm0,(%rsp)
   14e0b:	movq   $0x0,0x10(%rsp)
   14e14:	mov    %rsp,%rdi
   14e17:	call   *0x44953(%rip)        # 59770 <_DYNAMIC+0x2d8>
   14e1d:	mov    0x8(%rsp),%rax
   14e22:	mov    %r12,(%rax)
   14e25:	mov    (%rsp),%r12
   14e29:	mov    0x8(%rsp),%r15
   14e2e:	mov    $0x2,%r14b
   14e31:	jmp    14e78 <hyperinterval::dyadic::DyadicInterval::from_f64+0x158>
   14e33:	mov    %r12,%r14
   14e36:	neg    %r14
   14e39:	not    %r12
   14e3c:	cmp    %r12,%r14
   14e3f:	jb     14f3f <hyperinterval::dyadic::DyadicInterval::from_f64+0x21f>
   14e45:	movdqu -0xeffd(%rip),%xmm0        # 5e50 <anon.01be079ac99a956f7c1b4709c9de7b80.0.llvm.18091967735760447062+0x40>
   14e4d:	movdqa %xmm0,(%rsp)
   14e52:	movq   $0x0,0x10(%rsp)
   14e5b:	mov    %rsp,%rdi
   14e5e:	call   *0x4490c(%rip)        # 59770 <_DYNAMIC+0x2d8>
   14e64:	mov    0x8(%rsp),%rax
   14e69:	mov    %r14,(%rax)
   14e6c:	mov    (%rsp),%r12
   14e70:	mov    0x8(%rsp),%r15
   14e75:	xor    %r14d,%r14d
   14e78:	call   *0x448a2(%rip)        # 59720 <_DYNAMIC+0x288>
   14e7e:	mov    $0x8,%edi
   14e83:	mov    $0x8,%esi
   14e88:	call   *0x4487a(%rip)        # 59708 <_DYNAMIC+0x270>
   14e8e:	test   %rax,%rax
   14e91:	je     14f2f <hyperinterval::dyadic::DyadicInterval::from_f64+0x20f>
   14e97:	movq   $0x1,0x20(%rsp)
   14ea0:	mov    %rax,0x28(%rsp)
   14ea5:	mov    (%r15),%rcx
   14ea8:	mov    %rcx,(%rax)
   14eab:	movq   $0x1,0x30(%rsp)
   14eb4:	mov    $0x1,%eax
   14eb9:	jmp    14ee4 <hyperinterval::dyadic::DyadicInterval::from_f64+0x1c4>
   14ebb:	movq   $0x0,0x20(%rsp)
   14ec4:	movq   $0x8,0x28(%rsp)
   14ecd:	movq   $0x0,0x30(%rsp)
   14ed6:	mov    $0x1,%r14b
   14ed9:	mov    $0x8,%r15d
   14edf:	xor    %r12d,%r12d
   14ee2:	xor    %eax,%eax
   14ee4:	mov    %r14b,0x38(%rsp)
   14ee9:	mov    %r12,(%rsp)
   14eed:	mov    %r15,0x8(%rsp)
   14ef2:	mov    %rax,0x10(%rsp)
   14ef7:	mov    %r14b,0x18(%rsp)
   14efc:	movl   $0x0,0x19(%rsp)
   14f04:	movl   $0x0,0x1c(%rsp)
   14f0c:	lea    0x20(%rsp),%rsi
   14f11:	mov    %rsp,%rdx
   14f14:	mov    %rbx,%rdi
   14f17:	mov    %ebp,%ecx
   14f19:	call   *0x44809(%rip)        # 59728 <_DYNAMIC+0x290>
   14f1f:	mov    %rbx,%rax
   14f22:	add    $0x40,%rsp
   14f26:	pop    %rbx
   14f27:	pop    %r12
   14f29:	pop    %r14
   14f2b:	pop    %r15
   14f2d:	pop    %rbp
   14f2e:	ret
   14f2f:	mov    $0x8,%edi
   14f34:	mov    $0x8,%esi
   14f39:	call   *0x447f9(%rip)        # 59738 <_DYNAMIC+0x2a0>
   14f3f:	lea    0x42922(%rip),%rdi        # 57868 <__frame_dummy_init_array_entry+0xf8>
   14f46:	call   *0x4484c(%rip)        # 59798 <_DYNAMIC+0x300>
   14f4c:	int3
   14f4d:	int3
   14f4e:	int3
   14f4f:	int3

0000000000014f50 <hyperinterval::ieee::Format::finite>:
   14f50:	mov    %rcx,%rax
   14f53:	not    %rax
   14f56:	test   %rax,%rdx
   14f59:	jne    14f67 <hyperinterval::ieee::Format::finite+0x17>
   14f5b:	movb   $0x0,0x1(%rdi)
   14f5f:	mov    $0x1,%al
   14f61:	mov    %al,(%rdi)
   14f63:	mov    %rdi,%rax
   14f66:	ret
   14f67:	test   %rsi,%rsi
   14f6a:	je     14f90 <hyperinterval::ieee::Format::finite+0x40>
   14f6c:	dec    %rsi
   14f6f:	test   %rsi,%rcx
   14f72:	je     14f80 <hyperinterval::ieee::Format::finite+0x30>
   14f74:	mov    %rcx,0x8(%rdi)
   14f78:	xor    %eax,%eax
   14f7a:	mov    %al,(%rdi)
   14f7c:	mov    %rdi,%rax
   14f7f:	ret
   14f80:	movq   $0x0,0x8(%rdi)
   14f88:	xor    %eax,%eax
   14f8a:	mov    %al,(%rdi)
   14f8c:	mov    %rdi,%rax
   14f8f:	ret
   14f90:	push   %rax
   14f91:	lea    0x42900(%rip),%rdi        # 57898 <anon.b929e642be06ab33e60b1a6aaa84cad1.2.llvm.16587406844078298691+0x18>
   14f98:	call   *0x44812(%rip)        # 597b0 <_DYNAMIC+0x318>
   14f9e:	int3
   14f9f:	int3

