from pathlib import Path
import random, subprocess as sp,statistics as st,json,os
s=Path(__file__).parent
os.sched_setaffinity(0,{8});rng=random.Random(0x320)
def run(stage):
 r=sp.run([s/'cost-probe',s/'images'/stage/'libbinary32_dyadic_consumer.so',stage,'0'],check=True,text=True,capture_output=True)
 return list(map(int,r.stdout.split()))
for _ in range(3):
 for stage in ['preceding','direct']:run(stage)
rows=[]
for j in range(48):
 order=['preceding','direct'] if j%2==0 else ['direct','preceding']
 row={k:run(k) for k in order}
 assert row['preceding'][1]==row['direct'][1]
 rows.append(row)
rat=[r['direct'][0]/r['preceding'][0] for r in rows]
samples=sorted(st.median(rng.choices(rat,k=len(rat))) for _ in range(4000))
print('median paired ratio',st.median(rat),'95% bootstrap interval',samples[100],samples[3899], 'median ns', {k:st.median([r[k][0] for r in rows]) for k in rows[0]})
(s/'logs/timing.json').write_text(json.dumps(rows,indent=1))
