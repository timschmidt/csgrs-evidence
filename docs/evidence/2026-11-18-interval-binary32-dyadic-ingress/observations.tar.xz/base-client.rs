use hyperinterval::{DyadicInterval,DyadicBudget,IntervalError};
#[unsafe(no_mangle)]
pub extern "C" fn inspect(bits:u32, limit:u32, units:u32, field:u32) -> i64 {
    let mut budget = DyadicBudget::new(limit.into(), units.into());
    let value = f32::from_bits(bits);
    let result = DyadicInterval::from_f64(f64::from(value), &mut budget);
    match result {
        Ok(point) => {
            let (lo,hi,e) = point.bounds().unwrap();
            assert_eq!(lo,hi);
            match field {
                0 => 0, 1 => lo.try_into().unwrap(), 2 => e.into(),
                3 => budget.remaining_work() as i64, _ => panic!(),
            }
        }
        Err(err) => match err {
            IntervalError::NonFiniteEndpoint => -1,
            IntervalError::SizeExhausted => -2,
            IntervalError::WorkExhausted => -3,
            _ => panic!(),
        }
    }
}
