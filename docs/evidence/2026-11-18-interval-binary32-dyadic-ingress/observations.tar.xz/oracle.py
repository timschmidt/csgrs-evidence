from pathlib import Path
import json,struct,random,math
p=Path(__file__).parent
rng=random.Random(0x3217f)
patterns={rng.getrandbits(32) for _ in range(32768)}
patterns.update(sign|(e<<23)|m for sign in [0,1<<31] for e in range(256) for m in [0,1,0x400000,0x555555,0x7fffff])
patterns.update(sign|(1<<b) for sign in [0,1<<31] for b in range(23))
rows=[]
for raw in sorted(patterns):
 v=struct.unpack('>f',raw.to_bytes(4,'big'))[0]
 if not math.isfinite(v):
  rows.append([raw,-1,0,0,0]);continue
 n,d=v.as_integer_ratio()
 e=0
 if n:
  t=(n&-n).bit_length()-1;n>>=t;e=t-(d.bit_length()-1)
 bits=(raw & 0x7fffff).bit_length() if (raw>>23)&255==0 else 24
 rows.append([raw,0,n,e,bits])
(p/'corpus.json').write_text(json.dumps(rows,separators=(',',':')))
with (p/'corpus.bin').open('wb') as f:
 for row in rows:f.write(struct.pack('<Iiiii',*row))
print(len(rows),sum(r[1]==0 for r in rows))
