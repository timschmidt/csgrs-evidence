set -eu
s=/dev/shm/interval-f32-ingress
. /dev/shm/hyperinterval-coverage/env
export RUSTUP_HOME=/dev/shm/interval-ieee-branches/rustup CARGO_TARGET_DIR="$s/workspace-target"
cd "$s/client"
cp Cargo.lock "$s/external.lock"
cargo update --offline -p num-bigint --precise 0.4.6
cargo update --offline -p num-integer --precise 0.1.46
cargo update --offline -p autocfg --precise 1.5.0
cp Cargo.lock "$s/workspace.lock"
git -C "$s/control" restore -- crates/hyperinterval/src/dyadic.rs
cp "$s/base-client.rs" src/lib.rs
for stage in fixed preceding direct; do
 case "$stage" in
   fixed) git -C "$s/control" checkout --quiet --detach c9f1f9ac ;;
   preceding) git -C "$s/control" checkout --quiet --detach cc54dd856 ;;
   direct) cp /mnt/development/csgrs/crates/hyperinterval/src/dyadic.rs "$s/control/crates/hyperinterval/src/dyadic.rs"
           cp "$s/direct-client.rs" src/lib.rs ;;
 esac
 mkdir -p "$s/workspace/$stage"
 for target in x86_64-unknown-linux-gnu wasm32-unknown-unknown wasm32-wasip1; do
   cargo +1.95.0 build --locked --release --target "$target"
   case "$target" in
     x86_64-unknown-linux-gnu) cp "$CARGO_TARGET_DIR/$target/release/libbinary32_dyadic_consumer.so" "$s/workspace/$stage/";;
     *) cp "$CARGO_TARGET_DIR/$target/release/binary32_dyadic_consumer.wasm" "$s/workspace/$stage/$target.wasm"
        node "$s/wasm.mjs" "$s/workspace/$stage/$target.wasm" "$s/corpus.json" "$stage" "$target" ;;
   esac
 done
 "$s/native" "$s/workspace/$stage/libbinary32_dyadic_consumer.so" "$s/corpus.bin" "$stage"
done
sed "s#s/'images'#s/'workspace'#g;s#logs/memory.json#logs/workspace-memory.json#" "$s/cost.py" > "$s/workspace-cost.py"
python3 "$s/workspace-cost.py" > "$s/logs/workspace-memory"
sed "s#s/'images'#s/'workspace'#g;s#logs/timing.json#logs/workspace-timing.json#" "$s/timing.py" > "$s/workspace-timing.py"
python3 "$s/workspace-timing.py" > "$s/logs/workspace-timing"
