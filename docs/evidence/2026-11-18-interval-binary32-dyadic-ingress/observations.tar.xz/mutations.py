from pathlib import Path
import subprocess as sp, os, shutil
s=Path(__file__).parent; co=s/'control';rel=Path('crates/hyperinterval/src/dyadic.rs')
p=co/rel;orig=p.read_text();a=orig.index('        let bits = crate::ieee::BINARY32.finite(u64::from(value.to_bits()))?;',orig.index('pub fn from_f32'))
b=orig.index('\n    }',a)
test=Path('crates/hyperinterval/tests/dyadic_f32_ingress.rs')
shutil.copyfile(test,co/test)
try:
 for name,body in {
  'widen':'        Self::from_f64(f64::from(value), budget)',
  'nonfinite':'        crate::ieee::BINARY32.dyadic_point(u64::from(value.to_bits()), budget)',
  'sign':'        let bits = crate::ieee::BINARY32.finite(u64::from(value.to_bits() & 0x7fffffff))?;\n        crate::ieee::BINARY32.dyadic_point(bits, budget)',
 }.items():
  p.write_text(orig[:a]+body+orig[b:])
  with (s/'logs'/('mutant-'+name)).open('w') as log:
   r=sp.run(['cargo','+1.88.0','test','--locked','-p','hyperinterval','--no-default-features','--features','dyadic,float-proposal','--test','dyadic_f32_ingress'],cwd=co,stdout=log,stderr=sp.STDOUT)
  t=(s/'logs'/('mutant-'+name)).read_text()
  assert r.returncode and 'test result: FAILED' in t and 'source_width_budget_errors_and_retry' in t,name
finally:
 p.write_text(orig);(co/test).unlink()
