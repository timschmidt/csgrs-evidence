#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <xmmintrin.h>
#include <assert.h>
typedef int64_t (*inspect_fn)(uint32_t,uint32_t,uint32_t,uint32_t);
typedef struct { uint32_t raw; int32_t status, mantissa, exponent, bits; } Case;
int main(int argc,char **argv){
    assert(argc==4);
    void *lib=dlopen(argv[1],RTLD_NOW);assert(lib);
    inspect_fn inspect=(inspect_fn)dlsym(lib,"inspect");assert(inspect);
    FILE *f=fopen(argv[2],"rb");assert(f);
    unsigned original=_mm_getcsr(), total=0; int direct=strcmp(argv[3],"direct")==0;
    for(unsigned mode=0;mode<(direct?16:1);mode++){
        rewind(f);
        unsigned csr=(original&~0xe040u)|((mode&3)<<13)|((mode&4)<<13)|((mode&8)<<3);
        _mm_setcsr(csr);
        Case c;
        while(fread(&c,sizeof(c),1,f)==1){
            assert(inspect(c.raw,64,256,0)==c.status);
            if(!c.status){
                assert(inspect(c.raw,64,256,1)==c.mantissa);
                assert(inspect(c.raw,64,256,2)==c.exponent);
            }
            if(direct){
                unsigned w=(c.bits?c.bits:1)*2;
                assert(inspect(c.raw,c.bits,w,3)==(c.status?-1:0));
                assert(inspect(c.raw,c.bits,w-1,0)==(c.status?-1:-3));
                if(c.bits)assert(inspect(c.raw,c.bits-1,w,0)==-2);
            }
            total++;
        }
    }
    _mm_setcsr(original); fclose(f); dlclose(lib);
    printf("%s %u exact rows across %u MXCSR modes\n",argv[3],total,direct?16:1);
}
