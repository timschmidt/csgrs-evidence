from pathlib import Path
import subprocess as sp,re,sys,runpy,hashlib,json
s=Path(__file__).parent
findops=runpy.run_path('scripts/check_interval_wasm.py')['floating_operations']
data={}
for group in ['workspace','images']:
 for stage in ['preceding','direct']:
  for t in ['wasm32-unknown-unknown','wasm32-wasip1']:
   p=s/group/stage/(t+'.wasm')
   assembly=sp.check_output(['wasm-dis',p],text=True)
   ops=findops(assembly)
   if stage=='direct':assert ops==[]
   else:assert 'f64.promote_f32' in ops
   data[f'{group}/{stage}/{t}']=dict(operations=ops,wat_sha256=hashlib.sha256(assembly.encode()).hexdigest())
  path=s/group/stage/'libbinary32_dyadic_consumer.so'
  objdump=sp.check_output(['objdump','-d','-C','--no-show-raw-insn',path],text=True)
  selected=[];capture=False
  width='32' if stage=='direct' else '64'
  for line in objdump.splitlines():
   m=re.match(r'^[0-9a-f]+ <(.*)>:',line)
   if m:capture=m[1] in ['inspect','hyperinterval::dyadic::DyadicInterval::from_f'+width,'hyperinterval::ieee::Format::finite']
   if capture:selected.append(line)
  detail='\n'.join(selected);assert '::from_f'+width+'>:' in detail and '::finite>:' in detail
  ops=sorted(set(re.findall(r'\b(?:v?cvt\w+|v?(?:u?comi|add|sub|mul|div|sqrt)(?:ss|sd|ps|pd))\b',detail)))
  if stage=='direct':assert not ops,ops
  else:assert 'cvtss2sd' in ops,ops
  (s/'logs'/f'{group}-{stage}.asm').write_text(detail+'\n')
  data[f'{group}/{stage}/x86_64']=ops
(s/'logs/codegen.json').write_text(json.dumps(data,indent=2)+'\n')
