import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {WASI} from 'node:wasi';
const root=process.argv[2],rows=JSON.parse(fs.readFileSync(root+'/corpus.json'));
const results=[];
for(const group of ['workspace','images'])for(const stage of ['fixed','preceding','direct'])for(const target of ['wasm32-unknown-unknown','wasm32-wasip1']){
 const file=root+'/'+group+'/'+stage+'/'+target+'.wasm';
 const wat=execFileSync('wasm-dis',[file],{encoding:'utf8',maxBuffer:8*1024*1024});
 assert(!/^\s*\(start\s/m.test(wat));
 const stackBytes=Number(/\(global \$__stack_pointer \(mut i32\) \(i32.const (\d+)\)\)/.exec(wat)[1]);
 for(const line of wat.split('\n'))if(/^\s*\(data\s/.test(line)){
   const m=/^\s*\(data (?:\$\S+ )?\(i32.const (\d+)\) "/.exec(line);
   assert(m && Number(m[1])>=stackBytes);
 }
 const module=await WebAssembly.compile(fs.readFileSync(file));
 for(const pattern of [85,170]){
   const wasi=new WASI({version:'preview1',args:[],env:{},preopens:{}});
   const inst=await WebAssembly.instantiate(module,target==='wasm32-wasip1'?{wasi_snapshot_preview1:wasi.wasiImport}:{});
   if(target==='wasm32-wasip1')wasi.initialize(inst);
   const {memory,inspect}=inst.exports;
   for(const cold of [true,false]){
     const before=memory.buffer.byteLength;
     new Uint8Array(memory.buffer,0,stackBytes).fill(pattern);
     for(const [raw,status,m,e] of rows){
       assert.equal(Number(inspect(raw,64,256,0)),status);
       if(status===0){
         assert.equal(Number(inspect(raw,64,256,1)),m);
         assert.equal(Number(inspect(raw,64,256,2)),e);
       }
     }
     const first=new Uint8Array(memory.buffer,0,stackBytes).findIndex(v=>v!==pattern);
     assert(first>=0);
     results.push({group,stage,target,pattern,cold,before,after:memory.buffer.byteLength,touched:stackBytes-first});
   }
 }
}
console.log(JSON.stringify(results,null,1));
