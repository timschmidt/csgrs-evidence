from pathlib import Path
import json,subprocess as sp,os,random
s=Path(__file__).parent
stages=['fixed','preceding','direct']
def run(stage,*args):
 cmd=[s/'cost-probe',s/'images'/stage/'libbinary32_dyadic_consumer.so',stage,*map(str,args)]
 return sp.run(cmd,check=True,text=True,capture_output=True)
rows=[]
for repeat in range(2):
 for stage in stages:
  for i in range(7 if stage=='direct' else 6):
   for warm in [0,1]:
    for pattern in [85,170]:
     r=run(stage,i,warm,pattern);rows.append(dict(stage=stage,i=i,warm=warm,pattern=pattern,repeat=repeat,
     measures=list(map(int,r.stdout.split())),stack_limits=list(map(int,r.stderr.split()[1:]))))
(s/'logs/memory.json').write_text(json.dumps(rows,indent=1))
for stage in stages:
 print(stage,max(r['measures'][0] for r in rows if r['stage']==stage),max(r['measures'][1] for r in rows if r['stage']==stage))
