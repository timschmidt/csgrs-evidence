#define _GNU_SOURCE
#include <assert.h>
#include <dlfcn.h>
#include <malloc.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
extern void *__libc_malloc(size_t);
extern void *__libc_calloc(size_t,size_t);
extern void *__libc_realloc(void *,size_t);
extern void __libc_free(void *);
extern void *__libc_memalign(size_t,size_t);
typedef struct { void *ptr; size_t bytes,usable; } Slot;
static _Thread_local int tracking;
static _Thread_local Slot slots[64];
typedef struct { size_t live,real,peak,peak_real,count,deallocs,reallocs; } Counts;
static _Thread_local Counts counts;
static void on_alloc(void *p,size_t n){
    if(!tracking || !p)return;
    unsigned i=0;while(i<64 && slots[i].ptr)i++;assert(i<64);
    size_t u=malloc_usable_size(p);slots[i]=(Slot){p,n,u};
    counts.live+=n;counts.real+=u;counts.count++;
    if(counts.live>counts.peak)counts.peak=counts.live;
    if(counts.real>counts.peak_real)counts.peak_real=counts.real;
}
static void on_free(void *p){
    if(!tracking || !p)return;
    unsigned i=0;while(i<64 && slots[i].ptr!=p)i++;assert(i<64);
    counts.live-=slots[i].bytes;counts.real-=slots[i].usable;counts.deallocs++;slots[i]=(Slot){0};
}
void *malloc(size_t n){void *p=__libc_malloc(n);on_alloc(p,n);return p;}
void *calloc(size_t n,size_t m){void *p=__libc_calloc(n,m);on_alloc(p,n*m);return p;}
void *realloc(void *p,size_t n){if(tracking)counts.reallocs++;on_free(p);p=__libc_realloc(p,n);on_alloc(p,n);return p;}
int posix_memalign(void **out,size_t align,size_t n){
    if(align<sizeof(void*) || (align&(align-1)))return 22;
    void *p=__libc_memalign(align,n);if(!p)return 12;*out=p;on_alloc(p,n);return 0;
}
void free(void *p){on_free(p);__libc_free(p);}
extern size_t measure_stack(void(*)(void*),void*,int,unsigned char);
typedef int64_t (*inspect_fn)(uint32_t,uint32_t,uint32_t,uint32_t);
struct Job { inspect_fn inspect; int i; int direct; Counts result; };
static const uint32_t inputs[]={0,1,0x807fffff,0x3dcccccd,0xff7fffff,0xffc00000,0x3f800000};
static const int mantissas[]={0,1,-8388607,13421773,-16777215,0,1};
static const int exponents[]={0,-149,-149,-27,104,0,0};
static void run(void *ctx){
    struct Job *j=ctx;int i=j->i; uint32_t raw=inputs[i];
    memset(&counts,0,sizeof(counts));tracking=1;
    if(i==7){
        void *p=malloc(313);assert(p);__asm__ volatile("" : : "r"(p) : "memory");free(p);
        assert(counts.peak==313 && counts.deallocs==1 && counts.count==1);
        tracking=0;j->result=counts;return;
    }
    if(i==6){
        assert(j->direct);
        assert(j->inspect(raw,23,48,0)==-2);
        assert(j->inspect(raw,24,47,0)==-3);
    }
    unsigned bits=i==6?24:64, work=i==6?48:256;
    assert(j->inspect(raw,bits,work,0)==(i==5?-1:0));
    if(i!=5){
        assert(j->inspect(raw,bits,work,1)==mantissas[i]);
        assert(j->inspect(raw,bits,work,2)==exponents[i]);
    }
    tracking=0;j->result=counts;assert(!counts.live && !counts.real);
}
static uint64_t nanos(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;}
int main(int argc,char **argv){
    assert(argc>=4);
    void *lib=dlopen(argv[1],RTLD_NOW);assert(lib);
    struct Job j={.inspect=(inspect_fn)dlsym(lib,"inspect"),.i=atoi(argv[3]),.direct=!strcmp(argv[2],"direct")};assert(j.inspect);
    if(argc==4){
        volatile int64_t acc=0;
        uint64_t begin=nanos();
        for(unsigned round=0;round<150000;round++){
            unsigned i=round%6;
            acc+=j.inspect(inputs[i],64,256,0);
            if(i!=5){acc+=j.inspect(inputs[i],64,256,1);acc+=j.inspect(inputs[i],64,256,2);}
        }
        printf("%lu %ld\n",nanos()-begin,(long)acc);
    }else{
        assert(argc==6);
        size_t stack=measure_stack(run,&j,atoi(argv[4]),(unsigned char)atoi(argv[5]));
        printf("%zu %zu %zu %zu %zu %zu %zu %zu\n",stack,j.result.peak,j.result.peak_real,j.result.count,j.result.deallocs,j.result.reallocs,j.result.live,j.result.real);
    }
}
