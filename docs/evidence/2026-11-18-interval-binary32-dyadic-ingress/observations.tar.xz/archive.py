from pathlib import Path
import hashlib,io,json,tarfile,shutil,subprocess as sp,importlib.util
s=Path(__file__).parent; repo=Path.cwd();other=repo.parent/'csgrs-evidence'
record='docs/evidence/2026-11-18-interval-binary32-dyadic-ingress'
def git(*args):return sp.check_output(['git','-C',other,*args])
assert not git('status','--porcelain')
archive=s/'archive';archive.mkdir()
files={}
for n in ['scope','reproduce.txt','archive.py','client/Cargo.toml','base-client.rs','direct-client.rs','external.lock','workspace.lock','old-witness.rs','build.sh','workspace.sh','oracle.py','native.c','wasm.mjs','cost.c','old-stack.c','cost.py','timing.py','sizes.py','mutations.py','codegen.py','guest-memory.mjs','package-consumer/Cargo.toml','package-consumer/Cargo.lock']:
 files[n]=s/n
for p in (s/'logs').iterdir():
 if p.is_file():files['logs/'+p.name]=p
for n in ['commands.json','report.json','compiler.log']:
 files['existing-wasm/'+n]=s/'wasm-final'/n
sha=lambda b:hashlib.sha256(b).hexdigest()
digests={}
with tarfile.open(archive/'observations.tar.xz','w:xz',preset=6) as tar:
 for n,p in sorted(files.items()):
  b=p.read_bytes(); i=tarfile.TarInfo(n);i.size=len(b);tar.addfile(i,io.BytesIO(b));digests[n]=sha(b)
with tarfile.open(archive/'observations.tar.xz','r|xz') as tar:assert {i.name:sha(tar.extractfile(i).read()) for i in tar}==digests
(archive/'sha256.json').write_text(json.dumps(digests,indent=2)+'\n')
size=sum(p.stat().st_size for p in archive.iterdir())
assert shutil.disk_usage(other).free-3*size-1024**2>=20*1024**3
assert not (other/record).exists()
shutil.copytree(archive,other/record); git('add','--sparse','--',record)
assert all(n.startswith(record+'/') for n in git('diff','--cached','--name-only').decode().splitlines())
git('-c','gc.auto=0','commit','-m','Archive exact binary32 ingress qualification on both dependency locks')
rev=git('rev-parse','HEAD').decode().strip()
for p in archive.iterdir():assert git('show',rev+':'+record+'/'+p.name)==p.read_bytes()
spec=importlib.util.spec_from_file_location('manifest',repo/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(other),rev);assert len(rows)==2
idx=repo/'docs/evidence-archive.tsv';assert record not in idx.read_text()
with idx.open('a') as f:f.write(rows[1]+'\n')
print(rev,rows[1],len(digests))
