"""Append adaptive-order-continuation size charges to interval-size-accounts.json by text splicing."""
import json,sys
p=sys.argv[1]; s=open(p).read(); d=json.loads(s); m=json.load(open(sys.argv[2])); m1=json.load(open(sys.argv[3]))
BEFORE="9f96f14128112ee307ac4ee7b41df00fa421fa65"; AFTER="8b9f48bf50a45389aba8d97885a8c265c2fd79e7"
def path(k):
    kind,name,_=k.split('.')
    return {'bench':f'crates/hyperdynamics/benches/{name}.rs','example':f'crates/hyperdynamics/examples/{name}.rs','lib':'crates/hyperdynamics/src/lib.rs'}[kind]
def block(obj,indent):
    t=json.dumps(obj,indent=2,ensure_ascii=False)
    return '\n'.join(' '*indent+l if i else l for i,l in enumerate(t.split('\n')))
acc={a['artifact']:a for a in d['accounts'] if 'metrics' in a}
charged=[]; unchanged=[]; largest=None; new_art={}
for k,v in sorted(m.items()):
    deltas={met:v['cand'][met]-v['base'][met] for met in ('file','text','named_text')}
    a=acc.get(path(k))
    if a is None:
        if any(deltas.values()):
            new_art[path(k).split('crates/hyperdynamics/')[1]]={met:{'before':v['base'][met],'after':v['cand'][met],'growth_bytes':deltas[met]} for met in deltas}
        continue
    if not any(deltas.values()):
        unchanged.append(path(k)); continue
    entries=[]
    for met,delta in deltas.items():
        mm=a['metrics'][met]; c=mm['caps']; pct=round(100*delta/v['base'][met],6)
        prior=mm['accepted_positive_growth_bytes']+sum(x['charged_bytes'] for x in a.get('subsequent_charges',[]) if x['metric']==met)
        ch=max(0,delta); cum=prior+ch
        ok_inc=delta<=c['incremental_bytes'] and pct<=c['incremental_percent']
        ok_cum=cum<=c['cumulative_bytes'] and 100*cum/mm['baseline']<=c['cumulative_percent']
        assert ok_inc and ok_cum,(k,met)
        entries.append({"change":"adaptive-order-continuation","metric":met,"csgrs_before":BEFORE,"csgrs_after":AFTER,"before":v['base'][met],"after":v['cand'][met],"incremental_growth_bytes":delta,"incremental_growth_percent":pct,"charged_bytes":ch,"passes_incremental_caps":ok_inc,"cumulative_charged_bytes":cum,"passes_cumulative_caps":ok_cum})
        if met=='named_text' and (largest is None or delta>largest[1]): largest=(path(k),delta)
    key=f'"artifact": "{path(k)}"'
    assert s.count(key)==1,key
    i=s.index(key); j=s.index('\n      ],\n      "subsequent_charge_method"',i)
    assert j < s.index('"artifact"', i+len(key)) if '"artifact"' in s[i+len(key):] else True
    s=s[:j]+''.join(',\n        '+block(e,8) for e in entries)+s[j:]
    charged.append(path(k))
one={path(k):{met:v['cand'][met]-v['base'][met] for met in ('file','text','named_text')} for k,v in sorted(m1.items()) if any(v['cand'][x]!=v['base'][x] for x in ('text','named_text'))}
rec={
 "revisions":{"before":BEFORE,"after":AFTER},
 "record":"2026-11-22-interval-adaptive-order-continuation",
 "benefit":"Performance: the adaptive Taylor controller continues the previous candidate order's prepared stages instead of re-deriving them; prepared programs equal fresh preparations stage by stage.",
 "existing_charges":f"Positive per-artifact deltas charged to {len(charged)} Hyperdynamics accounts under subsequent_charges, with cumulative totals; the largest named-text charge is {largest[0]} at +{largest[1]} bytes. Unchanged: "+", ".join(unchanged)+".",
 "new_artifact_charges":{"artifacts":new_art,"note":"No account exists for these development artifacts; growth is from the first measurements recorded under flow_noise_evolution_2026_11_22, which equal the before sizes here."},
 "attribution":{"method":"Diagnostic only: both revisions rebuilt with codegen-units=1 (release and bench) at one path, isolating code growth from codegen-unit partition shifts. Charges use the ledger's default-profile method.","text_or_named_text_changes":one},
 "result":"Every incremental and cumulative cap passes.",
 "evidence":"docs/evidence/2026-11-22-interval-adaptive-order-continuation"}
assert s.endswith('\n  }\n}\n')
s=s[:-3]+',\n  "adaptive_order_continuation_2026_11_22": '+block(rec,2)+'\n}\n'
json.loads(s); open(p,'w').write(s)
print(len(charged),'charged', largest, len(unchanged),'unchanged', json.dumps(new_art)[:300])
