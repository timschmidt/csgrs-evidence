Adaptive Taylor controller order continuation, 22 November 2026.
Before: CSGRS 9f96f1412. After: 8b9f48bf5 (review branch head a7233233d adds only a test-gating fix).
Rust 1.100.0, all hyperdynamics features, both revisions built at one checkout path and target directory.

The controller prepares candidate orders lazily in one ascending run. Before, each order was prepared
from scratch with flow_taylor(order). After, it continues the previous order's retained stages
(ExpressionField::continue_flow_taylor with that program's stages as prefix), differentiating only the
missing normalized Lie coefficients. flow_taylor is the empty-prefix case of the same body.
tests/adaptive_taylor.rs::ascending_orders_continue_shared_stages_and_equal_fresh_preparation checks
stage-by-stage equality with fresh preparation and handle sharing; it fails against the old controller.

callgrind-counts.txt: hosted run 45108691290 (order-ir.yml, valgrind from ubuntu-latest).
Columns: binary, case, revision, repetition, Ir with case, Ir baseline, per-iteration difference.
- taylor_flow / taylor_evolution: whole-program Ir with a criterion --test filter minus a filter
  matching nothing (one routine iteration plus criterion overhead). Whole-program counts jitter by
  about +-1,500 Ir between repetitions, so these bound fresh-preparation change only to that noise.
- adaptive_taylor (harness=false): (Ir at ADAPTIVE_TAYLOR_ITERATIONS=3 - Ir at 1) / 2, whole program
  and with collection toggled on AdaptiveTaylorField<1>::integrate. Deterministic; repetitions agree.
- adaptive_probe: adaptive_probe.rs (Van der Pol, mu=1, two states, maximum order 3/6/8, remainder
  limits 2^-40, maximum step 2^-4, horizon 1/4), copied into examples/ at build time only and never
  committed. (Ir at PROBE_N=3 - Ir at 1) / 2. Deterministic; repetitions agree.

sizes-default-profile.json: file, .text and address-deduplicated named FUNC union (sizes.py) for every
hyperdynamics bench, example and the library test harness, default release/bench profiles (the
ledger's method). sizes-one-codegen-unit.json: the same with codegen-units=1, diagnostic only, to
separate code growth from codegen-unit partition shifts. adaptive-symbols-*.txt: nmdiff.py symbol
deltas for the adaptive bench. collect*.sh: build scripts. ledger.py: the ledger splice.
image-sha256.txt: measured executables, deleted after measurement.
