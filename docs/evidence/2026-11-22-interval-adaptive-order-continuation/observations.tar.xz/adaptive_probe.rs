use hyperdynamics::field::{
    EnclosureBudget, EnclosurePolicy, ExpressionField, FieldDefinition,
    evolution::{EvolutionOptions, EvolutionRequest},
    taylor_flow::adaptive::AdaptiveTaylorOptions,
};
use hyperinterval::DyadicInterval;
use hyperlattice_interval::BoxN;
use hypersolve::{
    Expr, SymbolId,
    expression_program::{ExpressionBudget, ExpressionProgram},
};
use std::time::Instant;
fn d(l: i64, u: i64, e: i32) -> DyadicInterval {
    DyadicInterval::new(l.into(), u.into(), e).unwrap()
}
fn main() {
    let (t, x, v) = (SymbolId(0), SymbolId(1), SymbolId(2));
    let (ex, ev) = (Expr::anonymous_symbol(x), Expr::anonymous_symbol(v));
    // Van der Pol, mu = 1: x' = v, v' = (1 - x^2) v - x
    let out = [
        ev.clone(),
        (Expr::int(1) - ex.clone() * ex.clone()) * ev - ex,
    ];
    let src = ExpressionProgram::compile(
        &out,
        &[t, x, v],
        &mut ExpressionBudget::new(1_000_000, 100_000_000),
    )
    .unwrap();
    let f = ExpressionField::<2>::from_definition(
        FieldDefinition {
            source: src.definition().clone(),
            time: t,
            state: vec![x, v],
        },
        &mut EnclosureBudget::new(EnclosurePolicy::default()),
    )
    .unwrap();
    let max: usize = std::env::var("MAXO")
        .map(|s| s.parse().unwrap())
        .unwrap_or(6);
    let o = AdaptiveTaylorOptions {
        maximum_order: max,
        remainder_limits: [d(1, 1, -40), d(1, 1, -40)],
        native: EvolutionOptions {
            maximum_step: Some(d(1, 1, -4)),
            ..Default::default()
        },
        ..Default::default()
    };
    let c = f.adaptive_taylor(o);
    let req = EvolutionRequest {
        start: d(0, 0, 0),
        end: d(1, 1, -2),
        initial: BoxN::new([d(1, 1, 0), d(0, 0, 0)]).unwrap(),
    };
    let n: u128 = std::env::var("PROBE_N").map(|s| s.parse().unwrap()).unwrap_or(20);
    let s = Instant::now();
    let mut orders = vec![];
    for _ in 0..n {
        let r = c.integrate(
            req.clone(),
            &mut EnclosureBudget::new(EnclosurePolicy::default()),
        );
        orders = r.programs().iter().map(|p| p.order()).collect();
        std::hint::black_box(&r);
    }
    println!(
        "max={max} ns/op={} orders={orders:?}",
        s.elapsed().as_nanos() / n
    );
}
