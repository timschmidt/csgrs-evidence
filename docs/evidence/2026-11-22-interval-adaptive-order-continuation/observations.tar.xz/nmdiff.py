import sys,subprocess,re,collections
def load(p):
    d=collections.Counter()
    for l in subprocess.check_output(['nm','-C','--size-sort','-S',p],text=True).splitlines():
        r=l.split(' ',3)
        if len(r)==4 and r[2] in 'tT':
            d[re.sub(r'::h[0-9a-f]{16}$','',r[3])]+=int(r[1],16)
    return d
a,b=load(sys.argv[1]),load(sys.argv[2])
diff=sorted(((b[k]-a[k],a[k],b[k],k) for k in set(a)|set(b) if a[k]!=b[k]))
n=int(sys.argv[3]) if len(sys.argv)>3 else 8
for x in diff[:n]+[None]+diff[-n:]:
    print('...' if x is None else f"{x[0]:+7d} {x[1]:7d} {x[2]:7d} {x[3][:150]}")
print('total',sum(x[0] for x in diff))
