#!/bin/bash
# collect.sh TAG : build all hyperdynamics benches/examples/lib-test, copy to $B/<kind>.<name>.<prof>-TAG
set -e; tag=$1; B=/mnt/development/.xo-bins/c1; export CARGO_TARGET_DIR=/mnt/development/.xo-target1 CARGO_PROFILE_BENCH_CODEGEN_UNITS=1 CARGO_PROFILE_RELEASE_CODEGEN_UNITS=1; cd /mnt/development/csgrs
rm -f $B/*-$tag
{ cargo bench --locked -q -p hyperdynamics --all-features --no-run --message-format=json; cargo build --locked -q --release -p hyperdynamics --all-features --examples --message-format=json; cargo test --locked -q --release -p hyperdynamics --all-features --lib --no-run --message-format=json; } 2>/dev/null | python3 -c "
import json,sys,shutil
for l in sys.stdin:
    r=json.loads(l)
    if r.get('reason')=='compiler-artifact' and r.get('executable'):
        k=r['target']['kind'][0]; n=r['target']['name']; prof='test' if r['profile']['test'] else 'x'
        if k=='lib': n='lib'
        shutil.copy(r['executable'], f'$B/{k}.{n}.{prof}-$tag')
"
