const fs = require("node:fs");
const assert = require("node:assert/strict");
(async () => {
 const p=process.argv[2], expected=Number(process.argv[3]);
 const {instance}=await WebAssembly.instantiate(fs.readFileSync(p));
 const split=instance.exports.split;
 for (let a=-8;a<=8;a++) for (let b=a;b<=9;b++) for(const e of [-2147483648,-7,0,2147483647]){
   assert.equal(split(a,b,e,256,100000), e===-2147483648 && (a+b)%2!==0 ? -1:1);
 }
 assert.equal(split(-3,4,-20,4,16),expected);
 console.log("All exponent and bounded cover assertions passed",p);
})().catch(e=>{console.error(e);process.exit(1);});
