set -eu
s=/dev/shm/interval-bisection
mkdir -p "$s/timings"
i=0
for version in control final final control final control control final; do
    i=$((i+1))
    setarch "$(uname -m)" -R taskset -c 0 "$s/$version/subdivision" > "$s/timings/$i-$version"
done
