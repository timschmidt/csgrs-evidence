set -eu
s=/dev/shm/interval-bisection
. "$s/env"
cd "$s/memory"
export CARGO_TARGET_DIR="$s/consumer-target"
cargo +1.95.0 build --release --offline
cp "$CARGO_TARGET_DIR/release/split-lifetime" "$s/$1/lifetime"
for i in 0 1 2; do "$s/$1/lifetime" "$i"; done
