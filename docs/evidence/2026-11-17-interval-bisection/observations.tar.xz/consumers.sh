set -eu
s=/dev/shm/interval-bisection
. "$s/env"
cd "$s/csgrs"
export CARGO_TARGET_DIR="$s/consumer-target"
cargo +1.95.0 build --locked --release -p hyperdynamics --features reachability --example reachability
cp "$CARGO_TARGET_DIR/release/examples/reachability" "$s/$1/reachability"
"$s/$1/reachability" > "$s/logs/$1-reachability"
cd "$s/wasm"
cargo +1.88.0 build --release --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/dyadic_box_client.wasm" "$s/$1/box.wasm"
node check.cjs "$s/$1/box.wasm" "$2"
