set -eu
s=/dev/shm/interval-bisection
. "$s/env"
cd crates/hyperinterval
export PATH=/tmp/interval-refactor/tools/bin:$PATH
export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/fuzz-target
mkdir -p "$s/corpus"
cargo +nightly fuzz run dyadic_arithmetic "$s/corpus" -- -runs=100000 -max_len=14 -max_total_time=30 -seed=20261112
