set -eu
s=/dev/shm/interval-bisection
. "$s/env"
export CARGO_TARGET_DIR="$s/consumer-target"
cd "$s/csgrs"
cargo +1.95.0 build --release --locked -p hyperdynamics --all-features --example reachability
cp "$CARGO_TARGET_DIR/release/examples/reachability" "$s/$1/reachability-all"
"$s/$1/reachability-all" > "$s/logs/$1-all-reachability"
