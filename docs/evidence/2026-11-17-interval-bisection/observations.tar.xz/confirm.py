from pathlib import Path
import subprocess,re
s=Path(__file__).parent
def rows(n,v,prefix):
 return [l for l in (s/'logs'/(v+'-'+n)).read_text().splitlines() if l.split('|')[0] in prefix]
for v in ['control','on-use']:
 assert rows('cover',v,['ROW','DEFINITION','ARITH','ALLOC'])==rows('cover','fixed',['ROW','DEFINITION','ARITH','ALLOC'])
 assert rows('lifetimes',v,['STACK','HEAP'])==rows('lifetimes','fixed',['STACK','HEAP'])
 assert (s/'logs'/(v+'-reachability')).read_bytes()==(s/'logs/fixed-reachability').read_bytes()
 assert (s/'logs'/(v+'-all-reachability')).read_bytes()==(s/'logs/fixed-all-reachability').read_bytes()
for v in ['final','move','direct','inline-consumer']:
 assert rows('cover',v,['ROW','DEFINITION'])==rows('cover','fixed',['ROW','DEFINITION'])
 assert (s/'logs'/(v+'-reachability')).read_bytes()==(s/'logs/fixed-reachability').read_bytes()
for n in ['axis','subdivision','reachability','reachability-all','box.wasm']:
 def sec(v):
  if n.endswith('wasm'):return {}
  ans={}
  for l in subprocess.check_output(['readelf','-SW',s/v/n],text=True).splitlines():
   r=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',l)
   if r and 'A' in r[3]:ans[r[1]]=int(r[2],16)
  return ans
 if n=='reachability-all':assert {k:y for k,y in sec('on-use').items() if y>sec('control')[k]}=={'.eh_frame':132328}
 print(n,[(v,(s/v/n).stat().st_size,sec(v).get('.eh_frame')) for v in ['fixed','control','on-use']])
print('Retained closed covers, graph and arithmetic work, allocations, complete lifetimes, reachability and all-feature outputs verified.')
