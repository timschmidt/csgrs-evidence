set -eu
s=/dev/shm/interval-bisection
. "$s/env"
export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/msrv-target
cargo +1.88.0 test --locked -p hyperinterval --no-default-features --features dyadic --test dyadic_bisection
cargo +1.88.0 build --release --locked -p hyperlattice-interval --no-default-features --features dyadic --target thumbv7em-none-eabihf
cargo +1.88.0 build --release --locked -p hyperlattice-interval --no-default-features --features dyadic --target wasm32-unknown-unknown
