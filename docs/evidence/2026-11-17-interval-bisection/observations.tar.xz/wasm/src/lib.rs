use hyperinterval::{DyadicBudget, DyadicInterval};
use hyperlattice_interval::BoxN;
#[unsafe(no_mangle)]
pub extern "C" fn split(a:i32,b:i32,exponent:i32,bits:u32,work:u32)->i32 {
    let d=|a:i64,b:i64,e:i32| DyadicInterval::new(a.into(),b.into(),e).unwrap();
    let a=i64::from(a); let b=i64::from(b);
    let x=BoxN::new([d(a,b,exponent)]).unwrap();
    let mut budget=DyadicBudget::new(bits.into(),work.into());
    match x.bisect_axis(0,&mut budget) {
      Ok(None)=>i32::from(a==b),
      Ok(Some([l,r]))=> {
        let expected=if exponent==i32::MIN {
          [d(a,(a+b)/2,exponent),d((a+b)/2,b,exponent)]
        } else {
          [d(2*a,a+b,exponent-1),d(a+b,2*b,exponent-1)]
        };
        i32::from(l.lanes().unwrap()[0]==expected[0] && r.lanes().unwrap()[0]==expected[1])
      }
      Err(_)=>-1
    }
}
