from pathlib import Path
import json,sys,subprocess,re
s=Path(__file__).parent
def wasm(p):
 data=p.read_bytes(); i=8
 def leb():
  nonlocal i
  n=0; shift=0
  while True:
   b=data[i]; i+=1; n|=(b&127)<<shift
   if b<128:return n
   shift+=7
 while i<len(data):
  k=data[i]; i+=1; length=leb()
  if k==10:return length
  i+=length
 raise ValueError('missing code')
def elf(p):
 regions=[]
 for l in subprocess.check_output(['readelf','-Ws',p],text=True).splitlines():
  r=l.split()
  if len(r)>=8 and r[3]=='FUNC' and r[6].isdigit() and r[2].isdigit() and int(r[2]):
   a=int(r[1],16);regions.append((a,a+int(r[2])))
 end=total=0
 for a,b in sorted(regions):total+=max(0,b-max(a,end));end=max(end,b)
 result={'defined_function_union':total}
 for l in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
  r=re.match(r'^\s*\[\s*\d+\]\s+(\.\S+)\s+\S+\s+\S+\s+\S+\s+([a-fA-F0-9]+)\s+\S+\s+(\S+)',l)
  if r and 'A' in r[3]:result[r[1]]=int(r[2],16)
 return result
path=Path('docs/research/interval-size-accounts.json')
data=json.loads(path.read_text())
records=[]
for n in ['axis','subdivision','reachability','box.wasm']:
 values=[]
 for v in ['fixed','control','on-use']:
  p=s/v/n
  values.append({'file':p.stat().st_size,**({'code':wasm(p)} if n.endswith('wasm') else elf(p))})
 assert values[0]==values[1],n
 f,c,r=values
 positive={}
 for k,y in r.items():
  d=y-c[k]
  if d<=0:continue
  cap=('wasm_final_file_and_code' if n.endswith('wasm') else 'native_monomorphized_text_sum' if k=='defined_function_union' else 'native_final_file_and_allocated_sections')
  limits=data['existing_artifacts'][cap]
  inc=100*d/c[k]
  assert all(d<=limits[t+'_bytes'] and inc<=limits[t+'_percent'] for t in ['incremental','cumulative']),(n,k,d,inc)
  positive[k]=dict(fixed=f[k],current=c[k],retained=y,incremental_bytes=d,cumulative_charged_bytes=d,percent=round(inc,6),cap_schedule=cap,remaining_incremental_bytes=limits['incremental_bytes']-d,remaining_cumulative_bytes=limits['cumulative_bytes']-d,remaining_cumulative_percent=round(limits['cumulative_percent']-inc,6))
 records.append(dict(artifact=n,metrics_positive=positive))
 print(n,positive)
out=dict(id='exact-dyadic-scalar-bisection',commit='f402f67bde54f0785b270fd8947170c8947a6c03',current_baseline='b6c95bb4e96ad0be5a17306442e04c779ea049c2',program_baseline=data['baseline_commit'],scope='x86_64-unknown-linux-gnu release clients and wasm32-unknown-unknown box client using the previous box algorithm. New direct scalar caller measured separately. No firmware configuration or allowance changed.',benefit='Exact midpoint partition can complete in four magnitude bits and sixteen work units. Unlike a box migration, the new scalar API preserves existing caller budgets.',capacity='Qualification clients run on a host with a 64 MiB image allowance and require 16 MiB free within that allowance. Every measured client occupies less than 4 MiB. This host capacity does not establish a deployment capacity for firmware.',caps='Existing target schedules. Each native allocated section and union of defined ELF function ranges checked independently. Positive charges remain separate. Fixed and current metric values agree for all four clients.',artifacts=records,evidence='docs/evidence/2026-11-17-interval-bisection')
(s/'size-accounts.json').write_text(json.dumps(out,indent=2)+'\n')
