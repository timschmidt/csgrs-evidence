import re,sys,statistics,subprocess,hashlib,json
from pathlib import Path
s=Path(__file__).parent
def rows(p,kind):
 return [line for line in p.read_text().splitlines() if line.split('|')[0] in kind]
for v in ['fixed','control','final']:
 p=s/'logs'/(v+'-cover')
 assert rows(p,['ROW','DEFINITION'])==rows(s/'logs/fixed-cover',['ROW','DEFINITION'])
 assert (s/'logs'/(v+'-reachability')).read_bytes()==(s/'logs/fixed-reachability').read_bytes()
subprocess.run([sys.executable,s/'sizes.py',*[s/v/n for v in ['fixed','control','final'] for n in ['axis','subdivision','reachability']]],check=True)
for name in ('axis','subdivision','reachability','box.wasm'):
 print('ARTIFACT',name,[(v,(s/v/name).stat().st_size,hashlib.sha256((s/v/name).read_bytes()).hexdigest()) for v in ['fixed','control','final']])
paths=sorted((s/'timings').glob('*'))
if paths:
 for j in [0,4]:
  blocks={}
  for path in paths[j:j+4]:
   for l in rows(path,['TIME']):
    _,case,_,_,ns=l.split('|')
    blocks.setdefault(case,{}).setdefault(path.name.split('-')[1],[]).append(int(ns))
  for k,x in blocks.items():
   c=statistics.median(x['control']);f=statistics.median(x['final'])
   print('TIMING',j//4+1,k,round(c/128),round(f/128),round((f/c-1)*100,2))
for n in ['fixed','control','final']:
 p=s/'logs'/(n+'-lifetimes')
 if p.exists():print(n,rows(p,['STACK','HEAP']))
