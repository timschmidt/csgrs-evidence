set -eu
s=/dev/shm/interval-bisection
. "$s/env"
cd "$s/controls/probe"
export CARGO_TARGET_DIR="$s/qualification-target"
cargo +1.95.0 build --offline --release --bins
for exe in subdivision axis; do cp "$CARGO_TARGET_DIR/release/$exe" "$s/$1/$exe"; done
"$s/$1/axis" > "$s/logs/$1-axis"
taskset -c 0 "$s/$1/subdivision" > "$s/logs/$1-cover"
