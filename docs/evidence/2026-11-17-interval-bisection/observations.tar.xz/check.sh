set -eu
s=/dev/shm/interval-bisection
. "$s/env"
cargo +1.95.0 test --locked -p hyperinterval -p hyperlattice-interval -p hypersdf --all-features
cargo +1.95.0 test --locked -p hyperdynamics --features reachability --test reachability
cargo +1.95.0 clippy --locked -p hyperinterval -p hyperlattice-interval -p hypersdf -p hyperdynamics --all-features --all-targets -- -D warnings
cargo +1.95.0 fmt --all -- --check
cargo +1.95.0 fmt --manifest-path crates/hyperinterval/fuzz/Cargo.toml -- --check
git diff --check
