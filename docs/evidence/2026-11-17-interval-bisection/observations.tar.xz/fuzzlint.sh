set -eu
s=/dev/shm/interval-bisection
. "$s/env"
export CARGO_TARGET_DIR=/dev/shm/interval-atanh-oracle/fuzz-check-target
cargo +1.95.0 clippy --locked --manifest-path crates/hyperinterval/fuzz/Cargo.toml --all-features --bins -- -D warnings
