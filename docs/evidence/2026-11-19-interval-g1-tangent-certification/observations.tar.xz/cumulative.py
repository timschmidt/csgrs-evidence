import json,os,re
from pathlib import Path
s=Path(os.environ['s'])
def read(p):return json.loads((s/p).read_text())
def size_sections(raw):
 out={}
 for l in raw.splitlines():
  m=re.match(r'^(\.\S+)\s+(\d+)\s+',l)
  if m:out[m[1]]=int(m[2])
 return out
def elfsecs(raw):
 out={}
 for l in raw.splitlines():
  m=re.search(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\w+)',l)
  if m and 'A' in m[3]:out[m[1]]=int(m[2],16)
 return out
prior=read('history-6ba224717.json');linked=read('history-candidate.json')
accounts={};issues=[]
for tc in ('1.95.0','stable'):
 anchor=read(f'hist-anchor-{tc}.json');before=read(f'before-native-{tc}-metrics.json');after=read(f'final-native-{tc}-metrics.json')
 for name in sorted(before):
  b=before[name];c=after[name];ref='c9f1f9ac5'
  if name in anchor:
   if (s/f'hist-proposed-{tc}.json').exists():
    b=read(f'hist-predecessor-{tc}.json')[name];c=read(f'hist-proposed-{tc}.json')[name];old=anchor[name]
    # Restrict to allocated sections present in the registered normal release.
    keys=before[name]['allocated_sections']
    sec=lambda r:{k:size_sections(r['sections']).get(k,0) for k in keys}
    a,bsec,csec=map(sec,(old,b,c))
   else:continue
  else:
   ref='df9cb4dde' if name=='certified_schedule' else 'd8eb6fa0c'; prefix='history' if tc=='1.95.0' else 'stable-history';old=read(f'{prefix}-{ref}.json')[name];b=read(f'{prefix}-6ba224717.json')[name];c=read(f'{prefix}-candidate.json')[name]
   a,bsec,csec=[elfsecs(r['-SW']) for r in (old,b,c)]
  output={}
  for k in ['file','code','functions',*a]:
   x,y,z=(r[k] for r in (old,b,c)) if k in ('file','code','functions') else (d.get(k,0) for d in (a,bsec,csec))
   cap,rate=(4096,.01) if k!='functions' else (1024,.005)
   cum,crate=(16384,.02) if k!='functions' else (4096,.01)
   historic=max(0,y-x);add=max(0,z-y);charge=historic+add
   if tc=='1.95.0' and name in ('schedule_equivalence','certified_schedule') and k=='.relro_padding':
    cap,cum=64,256;ratio_limit=cap;c_ratio_limit=cum
   else:ratio_limit=x*0+y*rate;c_ratio_limit=x*crate
   if add and (add>min(cap,ratio_limit) or charge>min(cum,c_ratio_limit)):issues.append((tc,name,k,x,y,z))
   if add or historic:
    output[k]=dict(fixed=x,previous=y,current=z,historical_charge=historic,new_charge=add,cumulative_charge=charge,remaining_absolute=cum-charge,remaining_relative_bytes=int(c_ratio_limit)-charge)
  accounts[f'{tc}/{name}']=dict(fixed=ref,metrics=output)
(s/'cumulative.json').write_text(json.dumps({'accounts':accounts,'positive_growth_failures':issues},indent=2)+'\n')
print(issues)
