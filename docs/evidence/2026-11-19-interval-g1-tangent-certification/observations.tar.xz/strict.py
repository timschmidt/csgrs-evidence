from pathlib import Path
root=Path('crates/hypersolve/src')
def edit(path,old,new):
 t=path.read_text()
 assert old in t,(path,old)
 path.write_text(t.replace(old,new))
edit(root/'model.rs','    Soft,\n}', '''    Soft,
    /// The raw residual must be strictly positive. A certified zero violates
    /// this row. Numerical distance to the feasible set is only a proposal
    /// metric and can vanish on the excluded boundary.
    GreaterThan,
}''')
for name in ['active_set','certification']:
 edit(root/(name+'.rs'),'ConstraintKind::GreaterOrEqual => -value','ConstraintKind::GreaterOrEqual | ConstraintKind::GreaterThan => -value')
for name in ['analysis','eval']:
 edit(root/(name+'.rs'),'ConstraintKind::GreaterOrEqual => positive_part(-value)','ConstraintKind::GreaterOrEqual | ConstraintKind::GreaterThan => positive_part(-value)')
edit(root/'jacobian.rs','ConstraintKind::GreaterOrEqual => !matches!','ConstraintKind::GreaterOrEqual | ConstraintKind::GreaterThan => !matches!')
p=root/'active_set.rs'
edit(p,'        ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual => match (active, sign) {','''        ConstraintKind::GreaterThan if sign == RealSign::Zero => {
            ActiveSetRowStatus::CertifiedViolation { sign, certificate }
        }
        ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual | ConstraintKind::GreaterThan => match (active, sign) {''')
p=root/'certification.rs'
edit(p,'                satisfied: true,\n','                satisfied: row.kind != ConstraintKind::GreaterThan,\n') if False else None
edit(p,'sign: RealSign::Zero,\n                certainty,\n                satisfied: true,','sign: RealSign::Zero,\n                certainty,\n                satisfied: row.kind != ConstraintKind::GreaterThan,')
edit(p,'row.kind,\n                    ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual','row.kind,\n                    ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual | ConstraintKind::GreaterThan')
edit(p,'            ) => CertifiedCandidateStatus::CertifiedSatisfiedInequality { certificate },','            ) | (ConstraintKind::GreaterThan, RealSign::Negative) => CertifiedCandidateStatus::CertifiedSatisfiedInequality { certificate },')
edit(p,'            | (ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual, RealSign::Positive) => {','            | (ConstraintKind::GreaterThan, RealSign::Zero | RealSign::Positive)\n            | (ConstraintKind::LessOrEqual | ConstraintKind::GreaterOrEqual, RealSign::Positive) => {')
edit(Path('crates/hyperpath/src/tangent.rs'),'kind: ConstraintKind::GreaterOrEqual,','kind: ConstraintKind::GreaterThan,')
edit(Path('crates/hyperpath/src/tangent.rs'),'candidate · target >= 0','candidate · target > 0')
