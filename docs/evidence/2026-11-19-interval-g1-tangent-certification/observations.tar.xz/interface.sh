set -eu
tag=$1
export CARGO_TARGET_DIR="$s/interface-build" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-stable" RUSTUP_TOOLCHAIN=stable
export PATH="/home/tim/.cache/trunk/wasm-bindgen-0.2.122:$PATH"
cd "$s/related/alumina-interface"
cargo test --locked --release -p alumina-interface-core --lib -- --test-threads=1 > "$s/logs/iface-native-$tag" 2>&1
scripts/check-wasi-core.sh > "$s/logs/iface-wasi-$tag" 2>&1
python3 - "$tag" <<'PY'
import os,sys,json,subprocess
from pathlib import Path
s=Path(os.environ['s']);sys.path.insert(0,str(s));from metrics import metrics
files={}
for arch,root,flags in [('native','release/deps',[]),('wasi','wasm32-wasip1/release/deps',['--target','wasm32-wasip1'])]:
 lines=subprocess.check_output(['cargo','test','--release','--locked','-p','alumina-interface-core','--lib','--no-run','--message-format=json',*flags],text=True)
 p=next(Path(r['executable']) for r in map(json.loads,lines.splitlines()) if r.get('executable'))
 files[arch]=metrics(p)
 if arch=='wasi':
  dest=s/'iface-glue';subprocess.run(['wasm-bindgen','--target','bundler','--out-dir',dest,'--out-name','interface',p],check=True)
  files['linked_command']=metrics(dest/'interface_bg.wasm')
(s/f'iface-metrics-{sys.argv[1]}.json').write_text(json.dumps(files,indent=2)+'\n')
PY
