set -eu
cd "$s/fixed"
export CARGO_TARGET_DIR="$s/solver-cost" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-1.95.0"
for tag in before strict; do
 if test "$tag" = strict; then git apply "$s/strict-owner.patch"; fi
 for t in x86_64-unknown-linux-gnu wasm32-wasip1; do
  cargo +1.95.0 build --locked --release --target "$t" -p hypersolve --all-features --bench certification --lib --message-format=json-render-diagnostics > "$s/logs/cost-$tag-$t.jsonl" 2> "$s/logs/cost-$tag-$t"
  python3 - "$tag" "$t" <<'PY'
import subprocess,os,sys,json
from pathlib import Path
s=Path(os.environ['s']);sys.path.insert(0,str(s));from metrics import metrics
tag,t=sys.argv[1:];rows=map(json.loads,(s/f'logs/cost-{tag}-{t}.jsonl').read_text().splitlines())
p=next(Path(r['executable']) for r in rows if r.get('executable'));v=metrics(p)
if t.startswith('x86'):v['sections']=subprocess.check_output(['size','-A',p],text=True)
(s/f'cost-{tag}-{t}.json').write_text(json.dumps(v,indent=2)+'\n')
PY
 done
done
