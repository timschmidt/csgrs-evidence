import json, math, os
from pathlib import Path
s=Path(os.environ['s'])
def read(name):
    return json.loads((s/(name+'.json')).read_bytes())
def write(kind,data):
    p=Path(f'docs/research/interval-{kind}-accounts.json'); raw=p.read_text().rstrip()
    key='hyperpath_certified_tangent_joins'
    original=json.loads(raw)
    assert key not in original
    add=json.dumps({key:data},indent=2)
    # Keep triples and metric vectors on one line in each target record.
    import re
    add=re.sub(r'\[\s*(-?\d+(?:,\s*-?\d+)+)\s*\]',lambda m:'['+re.sub(r',\s*',', ',m[1])+']',add)
    output=raw[:-1].rstrip()+',\n'+add[2:]+'\n'
    assert json.loads(output)==(original | {key:data})
    p.write_text(output)
size_old=json.loads(Path('docs/research/interval-size-accounts.json').read_text())
slot=64*1024**2
entry={'source':'e8b1bef51','budget_revision':'688e25c18','previous':'6ba224717',
       'evidence_record':'2026-11-19-interval-g1-tangent-certification',
       'units':'Bytes in file, executable .text or WASI code payload, and union of named text ranges or sum of WASI function bodies, in that order.',
       'caps':'Hosted slot 64 MiB with 16 MiB reserved per target. Native file, .text and allocated sections 4096 B/1% incremental, 16384 B/2% cumulative. Native named text 1024 B/0.5% incremental and 4096 B/1% cumulative. WASI file/code/bodies 1024 B/5% incremental and 4096 B/10% cumulative. See hyperpath_two_hosted_relro_padding_limits for the two named ELF reservations.',
       'accounting':'Same-location before and after for each delta. Cumulative totals charge positive growth for each metric independently. Native historic deltas and all nonzero section charges with both remaining limits are in cumulative.json in the evidence archive. WASI uses the same-source reconstruction of the originally registered guest release. New test commands establish separate initial measurements.',
       'owner_targets':{}}
cumul=read('cumulative')
assert not cumul['positive_growth_failures']
keys=['file','code','functions']
for tc in ['1.95.0','stable']:
    for arch in ['native','wasi']:
        before=read(f'before-{arch}-{tc}-metrics'); after=read(f'final-{arch}-{tc}-metrics')
        group={};entry['owner_targets'][f'{tc if tc!="stable" else "1.99.0"}/{arch}']=group
        for name,a in sorted(after.items()):
            cur=[a[k] for k in keys]
            row=group[name]={'current':cur,'free_slot':slot-cur[0]}
            assert row['free_slot']>=16*1024**2
            if name not in before:
                assert name=='tangent_certification'
                row['anchor']='e8b1bef51';continue
            b=before[name]; row['delta']=[a[k]-b[k] for k in keys]
            if arch=='wasi':
                row['anchor']='f34587258'; row['cumulative']=[max(0,x) for x in row['delta']]
                row['remaining']=[min(4096,b[k]//10)-n for k,n in zip(keys,row['cumulative'])]
            else:
                hist=cumul['accounts'][tc+'/'+name];row['anchor']=hist['fixed']
                ms=hist['metrics']
                row['cumulative']=[ms.get(k,{}).get('cumulative_charge',0) for k in keys]
                prefix='history' if tc=='1.95.0' else 'stable-history'
                fixed=read(f'hist-anchor-{tc}').get(name) or read(prefix+'-'+hist['fixed'])[name]
                row['remaining']=[min(4096 if k=='functions' else 16384,fixed[k]//(100 if k=='functions' else 50))-debit for k,debit in zip(keys,row['cumulative'])]
                assert all(row['remaining'][i]==min(ms[k]['remaining_absolute'],ms[k]['remaining_relative_bytes']) for i,k in enumerate(keys) if k in ms)
entry['relro_padding']={name:{k:m[k] for k in ('fixed','previous','current','new_charge','cumulative_charge','remaining_absolute')} for name in ['certified_schedule','schedule_equivalence'] for m in [cumul['accounts']['1.95.0/'+name]['metrics']['.relro_padding']]}
iface={}
b=read('iface-metrics-before'); a=read('iface-metrics-c')
for source,registered in [('native',None),('wasi','linked'),('linked_command','command')]:
    v=[a[source][k] for k in keys];delta=[a[source][k]-b[source][k] for k in keys]
    row=iface[source]={'current':v,'delta':delta,'free_slot':slot-v[0]}
    if registered:
        d=size_old['wasi_path_and_interface_tests_2026_11_19']['targets']['1.99.0']['alumina_interface'][registered]
        row['cumulative']=[d['incremental_and_cumulative'][k]+max(0,x) for k,x in zip(['file','code','bodies'],delta)]
        row['remaining']=[min(262144,d['baseline'][k]*4//100)-n for k,n in zip(['file','code','bodies'],row['cumulative'])]
entry['alumina_interface_rust_1_99']=iface
entry['native_interface_symbols']='Release strips native symbols. .text measures native machine code; zero named-range bytes is the symbol table observation.'
write('size',entry)
memory={'source':'e8b1bef51','previous':'6ba224717','evidence_record':entry['evidence_record'],
        'workload':'Two and six spans under STRICT and APPROXIMATE_512. Construct inputs, classify chain, plan, independently replay, assert and drop. Native cold and warm calls, four iterations, passive and active dispatch tracing, 2 MiB guarded thread stack, complementary fills. WASI guest inputs use both fills with a 1 MiB stack.',
        'linux_x86_64':{'compilers':['1.95.0','1.99.0'],'report_and_trace_pairs_identical':16,'whole_stack_pairs_identical':32,'largest_touched_stack':18656,'minimum_stack_remaining':2097152-18656,'passive_heap_histories_identical':16,'requested_peaks_and_live_counts_match_all_pairs':True,'active_recorder':'Pointer-hash groups affect the recorder’s own tree allocations. Balanced repeat with 320 fresh processes and another 256 Rust 1.99 six-span STRICT processes. In that repeated cell both sides reached 47088 usable bytes at peak, with 45415 requested.'},
        'wasm32_wasip1':{},'exception_charge':0}
for tc in ['1.95.0','stable']:
    files=[(s/f'guest-{v}-{tc}.jsonl').read_text().splitlines() for v in ['before','final']]
    assert files[0]==files[1]
    rs=[json.loads(l) for l in files[0]];pk=max(r['stack_bytes'] for r in rs)
    memory['wasm32_wasip1'][tc if tc!='stable' else '1.99.0']={'stack_bytes':pk,'remaining_stack':1048576-pk,'linear_bytes_by_span_count':{n:max(r['linear_bytes'] for r in rs if r['args'][0]==n) for n in ['2','6']},'same_complete_pairs':len(rs)}
write('memory',memory)
