from pathlib import Path
import json,sys,subprocess,re,os
from metrics import metrics
s=Path(os.environ['s']);tag,tc,arch=sys.argv[1:]
out={}
log=s/'logs'/f'{tag}-{arch}-{tc}.jsonl'
for r in map(json.loads,log.read_text().splitlines()):
 if not r.get('executable'):continue
 p=Path(r['executable']);v=metrics(p)
 if arch=='native':
  sec={}
  for line in subprocess.check_output(['readelf','-SW',p],text=True).splitlines():
   m=re.search(r'^\s*\[\s*\d+\]\s+(\S+)\s+\S+\s+\S+\s+\S+\s+(\S+)\s+\S+\s+(\w+)',line)
   if m and 'A' in m[3]:sec[m[1]]=int(m[2],16)
  assert sec.get('.text')==v['code']
  v['allocated_sections']=sec
 out[r['target']['name']]=v
 if r['target']['name']=='path_predicates' and arch=='native':
  from shutil import copy2
  copy2(p,s/f'bench-{tag}-{tc}')
assert {'hyperpath','certified_schedule','path_primitives','dispatch_trace','schedule_equivalence','readme','path_predicates'}<=out.keys()
(s/f'{tag}-{arch}-{tc}-metrics.json').write_text(json.dumps(out,indent=2)+'\n')
