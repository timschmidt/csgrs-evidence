import json,os,subprocess,sys,statistics
from pathlib import Path
s=Path(os.environ['s']);tc,core=sys.argv[1:]; names=['tangent_alignment_exact_predicate','tangent_join_exact_predicate','tangent_chain_exact_predicate','corner_lookahead_feed_limit_certification','lookahead_feed_schedule_certification']
rows=[]
for i in range(6):
 row={}
 for tag in (['before','current'] if i%2==0 else ['current','before']):
  home=s/'timing'/tc/str(i)/tag
  home.mkdir(parents=True,exist_ok=True)
  cmd=['taskset','-c',core,s/f'bench-{tag}-{tc}','--bench','^('+'|'.join(names)+')$','--noplot','--warm-up-time','0.2','--measurement-time','0.5','--sample-size','20','--nresamples','5000']
  with (home/'log').open('w') as log:subprocess.run(cmd,env=os.environ|{'CRITERION_HOME':str(home),'RAYON_NUM_THREADS':'1'},stdout=log,stderr=log,check=True)
  row[tag]={}
  for n in names:
   data=json.loads((home/n/'new/sample.json').read_text()); row[tag][n]=statistics.median(t/k for t,k in zip(data['times'],data['iters']))
 rows.append(row)
(s/f'timing-{tc}.json').write_text(json.dumps(rows,indent=2)+'\n')
