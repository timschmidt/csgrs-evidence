import os,subprocess,json,statistics,sys
from pathlib import Path
s=Path(os.environ['s']);tc=sys.argv[1];core=sys.argv[2]
names=['tangent_chain_exact_predicate','corner_lookahead_feed_limit_certification','lookahead_feed_schedule_certification']
rows=[]
for i in range(8):
 row={}
 for tag in (['control','current','before'] if i%2==0 else ['before','current','control']):
  home=s/'repeat-timing'/tc/str(i)/tag;home.mkdir(parents=True,exist_ok=True)
  binary='before' if tag=='control' else tag
  with (home/'log').open('w') as log:
   subprocess.run(['taskset','-c',core,s/f'bench-{binary}-{tc}','--bench','^('+'|'.join(names)+')$','--noplot','--warm-up-time','0.2','--measurement-time','0.5','--sample-size','25','--nresamples','3000'],env=os.environ|{'CRITERION_HOME':str(home),'RAYON_NUM_THREADS':'1'},stdout=log,stderr=log,check=True)
  result={}
  for n in names:
   d=json.loads((home/n/'new/sample.json').read_text());result[n]=statistics.median(v/i for v,i in zip(d['times'],d['iters']))
  row[tag]=result
 rows.append(row)
(s/f'timing-repeat-{tc}.json').write_text(json.dumps(rows,indent=2)+'\n')
