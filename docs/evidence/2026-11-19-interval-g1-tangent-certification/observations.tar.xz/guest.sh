set -eu
cd "$s/guest"
for tag in final before; do
 if [ "$tag" = before ]; then git -C "$s/related/csgrs" apply -R "$s/direct-c.patch"; fi
 for tc in stable 1.95.0; do (set -e
  export CARGO_TARGET_DIR="$s/guest-target-$tc" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-$tc"
  cargo +"$tc" build --locked --release --target wasm32-wasip1 > "$s/logs/guest-build-$tag-$tc" 2>&1
  for n in 2 6; do for p in strict approximate; do for f in 90 165; do
   node "$s/command-stack.mjs" "$CARGO_TARGET_DIR/wasm32-wasip1/release/g1-admission.wasm" "$f" "$n" "$p" >> "$s/guest-$tag-$tc.jsonl" 2>> "$s/logs/guest-stacks-$tag-$tc"
  done; done; done
 ) & done
 wait
done
