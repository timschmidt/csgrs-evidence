set -eu
cd "$s/historical"
for tag in anchor predecessor proposed; do
 if [ "$tag" = predecessor ]; then git -c advice.detachedHead=false checkout -q 6ba224717; fi
 if [ "$tag" = proposed ]; then git apply "$s/direct-c.patch"; fi
 for tc in 1.95.0 stable; do (
 export CARGO_TARGET_DIR="$s/hist-$tc" CARGO_BUILD_JOBS=8
 cargo +"$tc" build --locked --release -p hyperpath --all-features --tests --bench path_predicates --message-format=json-render-diagnostics > "$s/logs/hist-$tag-$tc.jsonl" 2> "$s/logs/hist-$tag-$tc"
 python3 - "$tag" "$tc" <<'PY'
import os,json,sys,re,subprocess
from pathlib import Path
s=Path(os.environ['s']);sys.path.insert(0,str(s));from metrics import metrics
tag,tc=sys.argv[1:];res={}
for r in map(json.loads,(s/f'logs/hist-{tag}-{tc}.jsonl').read_text().splitlines()):
 if not r.get('executable'):continue
 p=Path(r['executable']);v=metrics(p);v['sections']=subprocess.check_output(['size','-A',p],text=True)
 res[r['target']['name']]=v
(s/f'hist-{tag}-{tc}.json').write_text(json.dumps(res,indent=2)+'\n')
PY
 ) & done
 wait
done
