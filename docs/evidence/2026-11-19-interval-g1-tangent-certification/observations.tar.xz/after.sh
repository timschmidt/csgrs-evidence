set -eu
tc=$1
export CARGO_TARGET_DIR="$s/target-$tc" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-$tc"
bash "$s/native.sh" "$tc" after
python3 "$s/snapshot.py" after "$tc" native
cargo +"$tc" build --release --locked -p hyperpath --all-features --tests --example certified_schedule --bench path_predicates --target wasm32-wasip1 --message-format=json-render-diagnostics > "$s/logs/after-wasi-$tc.jsonl" 2> "$s/logs/after-wasi-$tc"
python3 "$s/snapshot.py" after "$tc" wasi
python3 crates/hyperinterval/conformance/wasi-path.py --toolchain "$tc" --output "$s/suites-$tc" > "$s/logs/suites-$tc" 2>&1
for target in wasm32-wasip1 x86_64-unknown-linux-gnu; do
 cargo +"$tc" clippy -p hyperpath --locked --release --all-targets --all-features --target "$target" -- -D warnings > "$s/logs/clippy-$tc-$target" 2>&1
done
