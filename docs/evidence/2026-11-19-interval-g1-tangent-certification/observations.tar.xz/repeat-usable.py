import json,ast,os,concurrent.futures,subprocess
from pathlib import Path
s=Path(os.environ['s'])
def run(item):
 tc,n,p,repeat,tag=item
 r=subprocess.run([s/f'mem-{tag}-{tc}',str(n),'1',p,'active',str([90,165][repeat%2])],capture_output=True,text=True,check=True)
 lines=r.stdout.splitlines()
 def vals(line):return sum((ast.literal_eval(t) for t in line[line.index('('):].replace(') (',')|(').split('|')),())
 return dict(tc=tc,n=n,p=p,repeat=repeat,tag=tag,stack=int(lines[0].split()[-1]),rows=list(map(vals,lines[1:])),headroom=r.stderr.strip())
items=[(tc,n,p,i,t) for tc in ['stable'] for n in [6] for p in ['strict'] for i in range(128) for t in (['before','final'] if i%2==0 else ['final','before'])]
with concurrent.futures.ThreadPoolExecutor(6) as ex:data=list(ex.map(run,items))
(s/'memory-usable-repeat.json').write_text(json.dumps(data)+'\n')
