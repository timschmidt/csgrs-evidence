from pathlib import Path
import json,sys,subprocess,os
from metrics import metrics
s=Path(os.environ['s']);rev=sys.argv[1]
table={}
for r in map(json.loads,(s/f'logs/history-{rev}.jsonl').read_text().splitlines()):
 if not r.get('executable'):continue
 p=Path(r['executable']);row=metrics(p)
 for mode in ('-lW','-SW'):
  row[mode]=subprocess.check_output(['readelf',mode,p],text=True)
 table[r['target']['name']]=row
(s/f'history-{rev}.json').write_text(json.dumps(table,indent=2)+'\n')
