#![allow(deprecated)] // Exercise legacy callers through the coordinated release.
mod allocation;
use allocation::{AllocationStats, observe};
use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::{LinePathSegment, TangentSpan, TangentJoinClass, FeedPathElement,
    LookaheadFeedPlanningLimits, classify_tangent_chain, certify_lookahead_feed_schedule,
    plan_lookahead_feed_schedule};
use hyperreal::Real;
use std::ffi::c_void;

unsafe extern "C" {
    fn measure_stack(
        callback: extern "C" fn(*mut c_void),
        context: *mut c_void,
        warm: i32,
        pattern: u8,
    ) -> usize;
}

struct Job {
    spans: usize,
    policy: PredicatePolicy,
    #[cfg(feature = "trace")]
    active: bool,
    control: bool,
    samples: [[Option<AllocationStats>; 5]; 4],
}

fn cycle(job: &Job, row: &mut [Option<AllocationStats>; 5]) {
    #[cfg(feature = "trace")]
    let guard = job.active.then(hyperreal::dispatch_trace::recording_scope);
    let points=|x:i64| Point2::new(x.into(), Real::zero());
    let lines:Vec<_>=(0..job.spans).map(|i|LinePathSegment::new(points(2*i as i64), points(2*i as i64+2),job.policy).unwrap()).collect();
    let spans:Vec<_>=lines.iter().map(TangentSpan::from_line_segment).collect();
    let route:Vec<_>=lines.into_iter().map(FeedPathElement::Line).collect();
    let limits=LookaheadFeedPlanningLimits { maximum_entry_feed: Real::zero(),maximum_exit_feed:Real::zero(),maximum_corner_feeds:vec![Real::one();spans.len()-1],corner_radii:vec![Real::zero();spans.len()-1] };
    row[0]=Some(AllocationStats::snapshot());
    let chain=classify_tangent_chain(&spans,job.policy);
    assert!(chain.all_g1_continuous() && chain.joins.iter().all(|r|r.class==TangentJoinClass::G1Continuous));
    row[1]=Some(AllocationStats::snapshot());
    let plan=plan_lookahead_feed_schedule(&route,&spans,&limits,Real::one(),Real::one(),job.policy).unwrap();
    assert!(plan.all_satisfied());
    let replay=certify_lookahead_feed_schedule(&route,&spans,&plan.schedule,Real::one(),Real::one(),job.policy).unwrap();
    assert!(replay.all_satisfied());
    row[2]=Some(AllocationStats::snapshot());
    #[cfg(feature = "trace")]
    let trace=job.active.then(hyperreal::dispatch_trace::take_trace);
    #[cfg(feature = "trace")]
    drop(guard);
    if job.control {
        println!("OUTPUT {chain:?} {plan:?} {replay:?}");
        #[cfg(feature="trace")]
        println!("TRACE {trace:?}");
    }
    drop((chain,plan,replay,route,limits,spans));
    row[3]=Some(AllocationStats::snapshot());
    #[cfg(feature = "trace")]
    drop(trace);
    row[4]=Some(AllocationStats::snapshot());
}

extern "C" fn worker(ptr: *mut c_void) {
    let job = unsafe { &mut *ptr.cast::<Job>() };
    let (rows, _) = observe(|| {
        let mut rows = [[None; 5]; 4];
        for row in &mut rows {
            cycle(job, row);
        }
        rows
    });
    job.samples = rows;
}

fn main() {
    let args: Vec<_> = std::env::args().skip(1).collect();
    let mut job = Job {
        spans: args[0].parse().unwrap(),
        policy: if args[2] == "strict" {
            PredicatePolicy::STRICT
        } else {
            PredicatePolicy::APPROXIMATE_512
        },
        #[cfg(feature = "trace")]
        active: args[3] == "active",
        control: args[4] == "control",
        samples: [[None; 5]; 4],
    };
    if job.control {
        cycle(&job, &mut [None; 5]);
        return;
    }
    let peak = unsafe { measure_stack(worker, (&raw mut job).cast(), 0, args[4].parse().unwrap()) };
    println!("STACK {peak}");
    for (i, row) in job.samples.iter().enumerate() {
        for (j, s) in row.iter().enumerate() {
            let s = s.unwrap();
            println!("ROW {i} {j} {:?} {:?}", s.values(), s.usable());
        }
    }
}
