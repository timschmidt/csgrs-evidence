import os,json,sys
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1]
out={}
for tc in ['1.95.0','stable']:
 for arch in ['native','wasi']:
  read=lambda phase: json.loads((s/f'{phase}-{arch}-{tc}-metrics.json').read_text())
  if not (s/f'{tag}-{arch}-{tc}-metrics.json').exists():continue
  pre,post=read('before'),read(tag)
  for name,v in post.items():
   if name not in pre:
    assert v['file']<=48*1024**2;continue
   b=pre[name];d={k:v[k]-b[k] for k in ['file','code','functions']}
   bs=b.get('allocated_sections',{});cs=v.get('allocated_sections',{})
   issues=[]
   def check(metric,prior,change,cap,percent):
    if change>0 and (change>cap or 100*change>percent*prior):issues.append([metric,prior,change,cap,percent])
   for k,x in d.items():
    cap,percent=(1024,5) if arch=='wasi' else ((1024,0.5) if k=='functions' else (4096,1))
    check(k,b[k],x,cap,percent)
   secs={k:cs.get(k,0)-bs.get(k,0) for k in bs.keys()|cs.keys()}
   for k,delta in secs.items():check(k,bs.get(k,0),delta,4096,1)
   out[f'{tc}/{arch}/{name}']=dict(delta=d,sections={k:n for k,n in secs.items() if n},issues=issues)
   if issues:print(tc,arch,name,issues)
(s/f'{tag}-deltas.json').write_text(json.dumps(out,indent=2)+'\n')
