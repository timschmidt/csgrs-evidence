import hashlib, io, json, lzma, os, tarfile
from pathlib import Path
s=Path(os.environ['s'])
e=Path('/mnt/development/csgrs-evidence/docs/evidence/2026-11-19-interval-g1-tangent-certification')
e.mkdir(parents=True,exist_ok=True)
paths=set()
for pat in ['*.py','*.rs','*.mjs','*.patch','*.sh','*.md','*.json','*.jsonl','baseline.log','env','logs/*','final-suites-*/*','commits/*','timing/**/new/sample.json','repeat-timing/**/new/sample.json']:
    paths.update(p for p in s.glob(pat) if p.is_file())
for folder in ['memory','guest','g1','trace-before','trace-after','solver-oracle','record','unpacked-stable/client','unpacked-1.95.0/client']:
    for p in (s/folder).rglob('*'):
        if p.is_file() and (p.name in ['Cargo.toml','Cargo.lock'] or p.suffix in ['.rs','.c']):paths.add(p)
manifest={}
with tarfile.open(e/'observations.tar.xz','w:xz',preset=5) as tar:
    for p in sorted(paths):
        n=p.relative_to(s).as_posix()
        assert not p.is_symlink(),n
        data=p.read_bytes();manifest[n]=hashlib.sha256(data).hexdigest()
        info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
(e/'members.sha256.json.xz').write_bytes(lzma.compress((json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode(),preset=6))
print(len(manifest),'members;',sum(p.stat().st_size for p in e.iterdir()),'archive bytes')
