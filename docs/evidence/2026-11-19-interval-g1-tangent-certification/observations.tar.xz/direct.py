from pathlib import Path
p=Path('crates/hyperpath/src/tangent.rs')
txt=p.read_text().replace('/// direction vectors without introducing square roots.','/// direction vectors without introducing square roots. A definite alignment\n/// requires a certificate even when the caller permits terminal approximation.').replace(') -> TangentAlignment {\n    if is_zero_vector',') -> TangentAlignment {\n    let policy = policy.certified_only();\n    if is_zero_vector').replace('match point2_equal(first_endpoint, second_endpoint, policy).value()','match point2_equal(first_endpoint, second_endpoint, policy.certified_only()).value()')
p.write_text(txt)
p=Path('crates/hyperpath/src/routing/lookahead.rs')
t=p.read_text().replace('fn lookahead_join_class_from_tangent(', 'pub(super) fn lookahead_join_class_from_tangent(').replace('TangentJoinClass::DegenerateTangent\n        | TangentJoinClass::EndpointMismatch\n        | TangentJoinClass::Unknown => Err(RouteCertificationError::UnsupportedRouteGeometry),','TangentJoinClass::DegenerateTangent | TangentJoinClass::EndpointMismatch => {\n            Err(RouteCertificationError::UnsupportedRouteGeometry)\n        }\n        TangentJoinClass::Unknown => Err(RouteCertificationError::PredicateUnresolved),')
assert 'TangentJoinClass::Unknown => Err(RouteCertificationError::PredicateUnresolved)' in t
p.write_text(t)
p=Path('crates/hyperpath/src/routing/feed.rs')
t=p.read_text()
a=t.index('        let class = match tangent_join.class {')
b=t.index('        let certification',a)
t=t[:a]+'        let class = super::lookahead::lookahead_join_class_from_tangent(tangent_join.class)?;\n'+t[b:]
p.write_text(t)
