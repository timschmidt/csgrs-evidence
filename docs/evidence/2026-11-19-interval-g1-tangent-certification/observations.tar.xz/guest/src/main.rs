use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::{LinePathSegment, TangentSpan, TangentJoinClass, FeedPathElement,
    LookaheadFeedPlanningLimits, classify_tangent_chain, certify_lookahead_feed_schedule,
    plan_lookahead_feed_schedule};
use hyperreal::Real;
fn main(){
let mut args=std::env::args().skip(1);
let n:usize=args.next().unwrap().parse().unwrap();
let policy=if args.next().unwrap()=="strict"{PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512};
for _ in 0..4 {
    let points=|x:i64| Point2::new(x.into(), Real::zero());
    let lines:Vec<_>=(0..n).map(|i|LinePathSegment::new(points(2*i as i64), points(2*i as i64+2),policy).unwrap()).collect();
    let spans:Vec<_>=lines.iter().map(TangentSpan::from_line_segment).collect();
    let route:Vec<_>=lines.into_iter().map(FeedPathElement::Line).collect();
    let limits=LookaheadFeedPlanningLimits { maximum_entry_feed: Real::zero(),maximum_exit_feed:Real::zero(),maximum_corner_feeds:vec![Real::one();spans.len()-1],corner_radii:vec![Real::zero();spans.len()-1] };
    let chain=classify_tangent_chain(&spans,policy);
    assert!(chain.all_g1_continuous() && chain.joins.iter().all(|r|r.class==TangentJoinClass::G1Continuous));
    let plan=plan_lookahead_feed_schedule(&route,&spans,&limits,Real::one(),Real::one(),policy).unwrap();
    assert!(plan.all_satisfied());
    let replay=certify_lookahead_feed_schedule(&route,&spans,&plan.schedule,Real::one(),Real::one(),policy).unwrap();
    assert!(replay.all_satisfied());
std::hint::black_box((&plan,&replay));
}
}
