from pathlib import Path
import os,json
s=Path(os.environ['s']);accounts={}
for n,first in [('certified_schedule','df9cb4dde'),('schedule_equivalence','d8eb6fa0c')]:
 rows={}
 for tag in [first,'6ba224717','candidate']:
  r=json.loads((s/f'history-{tag}.json').read_text())[n]
  sec=next(l.split('NOBITS')[1].split() for l in r['-SW'].splitlines() if '.relro_padding' in l)
  seg=[]
  for line in r['-lW'].splitlines():
   a=line.split()
   if not a or a[0] not in ('LOAD','GNU_RELRO'):continue
   va=int(a[2],16);sz=int(a[5],16);seg.append(dict(kind=a[0],pages=(va%4096+sz+4095)//4096,permissions=''.join(a[6:-1]),start_page=va//4096,memsz=sz,filesz=int(a[4],16)))
  rows[tag]=dict(padding=int(sec[2],16),segments=seg,file=r['file'],text=r['code'],named_text=r['functions'])
 current=rows['candidate'];before=rows['6ba224717'];orig=rows[first]
 inc=current['padding']-before['padding'];prior=max(0,before['padding']-orig['padding']);cumulative=prior+max(0,inc)
 assert inc<=64 and cumulative<=256
 for x,y,z in zip(orig['segments'],before['segments'],current['segments'],strict=True):
  assert x['kind']==y['kind']==z['kind'] and x['permissions']==y['permissions']==z['permissions'] and x['pages']==y['pages']==z['pages']
 accounts[n]=dict(first=first,rows=rows,prior_charge=prior,increment=inc,cumulative=cumulative,remaining=256-cumulative)
(s/'padding.json').write_text(json.dumps(accounts,indent=2)+'\n')
