use hyperlimit::{Point2, PredicatePolicy};
use hyperpath::classify_tangent_join;
use hyperreal::{dispatch_trace, Real};
fn p(x:i32,y:i32)->Point2{ Point2::new(Real::from(x),Real::from(y)) }
fn main(){
 for policy in [PredicatePolicy::STRICT,PredicatePolicy::APPROXIMATE_512]{
  for (label,endpoint,tangent) in [("same",p(0,0),p(2,0)),("opposite",p(0,0),p(-1,0)),("corner",p(0,0),p(0,1)),("zero",p(0,0),p(0,0)),("mismatch",p(1,0),p(1,0))]{
   let first=p(0,0);let east=p(1,0);
   dispatch_trace::reset();
   let report=dispatch_trace::with_recording(||classify_tangent_join(&first,&east,&endpoint,&tangent,policy));
   let tr=dispatch_trace::snapshot_trace();
   println!("{policy:?}/{label}: {report:?} cmp={} endpoint={}\n{tr:?}",tr.operation_count("hyperlimit","compare_reals"),tr.operation_count("hyperlimit","point2_equal"));
  }
 }
}
