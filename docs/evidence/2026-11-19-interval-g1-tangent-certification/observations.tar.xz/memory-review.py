import json,os
from pathlib import Path
s=Path(os.environ['s']);rows={}
for p in sorted((s/'logs').glob('mem-before-*')):
 k=p.name.removeprefix('mem-before-');q=s/'logs'/('mem-final-'+k)
 a,b=(x.read_text().splitlines() for x in (p,q))
 if k.endswith('control'):
  rows[k]={'matched_reports_and_trace':a==b}
 else:
  x,y=int(a[0].split()[1]),int(b[0].split()[1])
  rows[k]={'baseline_stack':x,'candidate_stack':y,'stack_delta':y-x,'same_allocation_history':a[1:]==b[1:]}
 assert len(rows)>0
print('controls',sum(r.get('matched_reports_and_trace',False) for r in rows.values()),'allocation matches',sum(r.get('same_allocation_history',False) for r in rows.values()),'stack deltas',sorted({r['stack_delta'] for r in rows.values() if 'stack_delta' in r}))
print([(k,r['stack_delta']) for k,r in rows.items() if r.get('stack_delta',0)>0][:8])
(s/'memory-review.json').write_text(json.dumps(rows,indent=2)+'\n')
