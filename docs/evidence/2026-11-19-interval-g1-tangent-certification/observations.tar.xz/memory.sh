set -eu
cd "$s/memory"
for tag in before final; do
 if [ "$tag" = final ]; then git -C "$s/fixed" apply "$s/direct-c.patch"; fi
 for tc in stable 1.95.0; do (set -e
  export CARGO_TARGET_DIR="$s/mem-target-$tc"
  cargo +"$tc" build --locked --release --features trace > "$s/logs/mem-build-$tag-$tc" 2>&1
  for p in strict approximate; do for n in 2 6; do for tr in passive active; do
   for f in 90 165 control; do
    "$CARGO_TARGET_DIR/release/axis-consumer" "$n" 1 "$p" "$tr" "$f" > "$s/logs/mem-$tag-$tc-$n-$p-$tr-$f"
   done
  done; done; done
 ) & done
 wait
done
