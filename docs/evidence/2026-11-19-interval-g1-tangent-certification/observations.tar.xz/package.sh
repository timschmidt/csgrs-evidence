set -eu
tc=$1;tag=$2
export CARGO_TARGET_DIR="$s/pkg-$tc" CARGO_BUILD_JOBS=8
cargo +"$tc" package --locked --offline --allow-dirty --no-verify -p hyperreal -p hyperinterval -p hyperlattice-interval -p hyperlattice -p hyperlimit -p hypersolve -p hyperpath > "$s/logs/package-$tag-$tc" 2>&1
cp "$CARGO_TARGET_DIR/package/hyperpath-0.3.0.crate" "$s/hyperpath-$tag-$tc.crate"
