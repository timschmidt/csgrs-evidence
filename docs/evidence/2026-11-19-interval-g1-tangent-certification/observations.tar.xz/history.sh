set -eu
root="$s/fixed"
cd "$root"
export CARGO_TARGET_DIR="$s/history-target"
for entry in 'df9cb4dde certified_schedule' 'd8eb6fa0c schedule_equivalence' '6ba224717 both' 'candidate both'; do
 read -r rev target <<< "$entry"
 if [[ "$rev" == candidate ]]; then git apply "$s/direct-c.patch"; else git -c advice.detachedHead=false checkout -q "$rev"; fi
 args=()
 if [[ "$target" != schedule_equivalence ]]; then args+=(--example certified_schedule); fi
 if [[ "$target" != certified_schedule ]]; then args+=(--test schedule_equivalence); fi
 cargo +1.95.0 build --release --locked -p hyperpath --all-features "${args[@]}" --message-format=json-render-diagnostics > "$s/logs/history-$rev.jsonl" 2> "$s/logs/history-$rev"
 python3 "$s/elf-history.py" "$rev"
done
