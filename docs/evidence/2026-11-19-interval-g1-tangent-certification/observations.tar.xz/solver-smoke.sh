set -eu
cd "$s/fixed"
export CARGO_TARGET_DIR="$s/smoke" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-1.95.0"
for tag in strict before; do
 if [ "$tag" = before ]; then git apply -R "$s/strict-owner.patch"; fi
 cargo +1.95.0 build --locked --release --target wasm32-wasip1 -p hypersolve --all-features --test smoke --message-format=json-render-diagnostics > "$s/logs/smoke-$tag.jsonl" 2> "$s/logs/smoke-$tag"
 python3 - "$tag" <<'PY'
import json,sys,os,subprocess
from pathlib import Path
s=Path(os.environ['s']);sys.path.insert(0,str(s));from metrics import metrics
tag=sys.argv[1];rows=map(json.loads,(s/f'logs/smoke-{tag}.jsonl').read_text().splitlines())
p=next(Path(r['executable']) for r in rows if r.get('executable'))
(s/f'smoke-{tag}.json').write_text(json.dumps(metrics(p),indent=2)+'\n')
with (s/f'logs/smoke-executed-{tag}').open('w') as f:subprocess.run(['node','/mnt/development/csgrs/crates/hyperlattice-interval/conformance/run-wasi-test.mjs',p,'--test-threads=1'],stdout=f,stderr=f,check=True)
PY
done
