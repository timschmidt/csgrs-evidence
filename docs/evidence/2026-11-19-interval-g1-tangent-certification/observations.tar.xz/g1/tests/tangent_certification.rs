//! A terminal approximation cannot certify continuity in a retained path.
use hyperlimit::{Point2, PredicatePolicy, compare_reals};
use hyperpath::{
    FeedPathElement, LinePathSegment, LookaheadFeedPlanningLimits, RouteCertificationError,
    TangentAlignment, TangentJoinClass, TangentSpan, certify_corner_lookahead_limits,
    certify_lookahead_feed_schedule, classify_tangent_alignment, classify_tangent_chain,
    classify_tangent_join, plan_lookahead_feed_schedule,
};
use hyperreal::Real;
use std::cmp::Ordering;

fn point(x: i32, y: i32) -> Point2 {
    Point2::new(x.into(), y.into())
}

fn hidden_positive() -> Real {
    // The sine addition formula cancels the first three terms exactly.
    (Real::e() + Real::one()).sin()
        - Real::e().sin() * Real::one().cos()
        - Real::e().cos() * Real::one().sin()
        + Real::from(2).powi_i64(-2048).unwrap()
}

#[test]
fn endpoint_and_tangent_proofs_refuse_warm_approximate_zeroes() {
    let h = hidden_positive();
    let approximate = PredicatePolicy::APPROXIMATE_512;
    assert_eq!(compare_reals(&h, &Real::zero(), approximate).value(), Some(Ordering::Equal));
    let origin = point(0, 0);
    let east = point(1, 0);
    let shifted = Point2::new(h.clone(), Real::zero());
    let tilted = Point2::new(Real::one(), h.clone());
    for policy in [approximate, PredicatePolicy::STRICT] {
        let gap = classify_tangent_join(&origin, &east, &shifted, &east, policy);
        assert_eq!(gap.class, TangentJoinClass::Unknown);
        assert_eq!(gap.endpoints_equal, None);
        assert_eq!(gap.alignment, None);

        for tangent in [&tilted, &shifted] {
            assert_eq!(classify_tangent_alignment(&east, tangent, policy), TangentAlignment::Unknown);
            let join = classify_tangent_join(&origin, &east, &origin, tangent, policy);
            assert_eq!(join.class, TangentJoinClass::Unknown);
            assert_eq!(join.endpoints_equal, Some(true));
            assert_eq!(join.alignment, Some(TangentAlignment::Unknown));
        }

        // A certified second coordinate or second zero vector can decide the result.
        let separated = Point2::new(h.clone(), Real::one());
        assert_eq!(classify_tangent_join(&origin, &east, &separated, &east, policy).class, TangentJoinClass::EndpointMismatch);
        assert_eq!(classify_tangent_alignment(&shifted, &origin, policy), TangentAlignment::Degenerate);
    }
}

#[test]
fn corner_planning_and_replay_preserve_unresolved_join_evidence() {
    let strict = PredicatePolicy::STRICT;
    let lines = [
        LinePathSegment::new(point(-2, 0), point(0, 0), strict).unwrap(),
        LinePathSegment::new(point(0, 0), point(2, 0), strict).unwrap(),
    ];
    let mut spans = lines.each_ref().map(TangentSpan::from_line_segment);
    let route = lines.map(FeedPathElement::Line);
    let limits = LookaheadFeedPlanningLimits {
        maximum_entry_feed: Real::zero(),
        maximum_corner_feeds: vec![Real::one()],
        corner_radii: vec![Real::one()],
        maximum_exit_feed: Real::zero(),
    };
    let schedule = plan_lookahead_feed_schedule(&route, &spans, &limits, Real::one(), Real::one(), strict).unwrap().schedule;
    assert_eq!(schedule.corner_feeds, [Real::one()]);
    spans[1].start.x = hidden_positive();
    for policy in [strict, PredicatePolicy::APPROXIMATE_512] {
        let chain = classify_tangent_chain(&spans, policy);
        assert_eq!(chain.first_non_g1_join(), Some(0));
        assert_eq!(chain.joins[0].class, TangentJoinClass::Unknown);
        assert_eq!(certify_corner_lookahead_limits(&spans, Real::one(), Real::one(), Real::one(), Real::one(), policy).unwrap_err(), RouteCertificationError::PredicateUnresolved);
        assert_eq!(plan_lookahead_feed_schedule(&route, &spans, &limits, Real::one(), Real::one(), policy).unwrap_err(), RouteCertificationError::PredicateUnresolved);
        assert_eq!(certify_lookahead_feed_schedule(&route, &spans, &schedule, Real::one(), Real::one(), policy).unwrap_err(), RouteCertificationError::PredicateUnresolved);
    }
}
