set -eu
tc=$1
v=$2
export CARGO_TARGET_DIR="$s/target-$tc" CARGO_BUILD_JOBS=9
cargo +"$tc" tree --locked -p hyperpath --all-features --edges normal,dev,features > "$s/logs/$v-native-tree-$tc"
cargo +"$tc" build --locked --release -p hyperpath --all-features --example certified_schedule --bench path_predicates --tests --message-format=json-render-diagnostics > "$s/logs/$v-native-$tc.jsonl" 2>"$s/logs/$v-native-$tc"
python3 - "$v" "$tc" <<'PY'
import os,json,hashlib,sys
from pathlib import Path
s=Path(os.environ['s']);v,tc=sys.argv[1:]
out={}
for r in map(json.loads,(s/f'logs/{v}-native-{tc}.jsonl').read_text().splitlines()):
 if r.get('executable'):
  p=Path(r['executable']);b=p.read_bytes();out[p.name]=[len(b),hashlib.sha256(b).hexdigest()]
(s/f'{v}-native-{tc}.json').write_text(json.dumps(out,indent=2,sort_keys=True))
PY
