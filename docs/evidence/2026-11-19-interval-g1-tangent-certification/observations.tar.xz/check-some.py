from pathlib import Path
import os,json,subprocess,sys
from metrics import metrics
s=Path(os.environ['s'])
for tc in ('stable','1.95.0'):
 tag=sys.argv[1];p=s/f'logs/{tag}-native-{tc}.jsonl';base=json.loads((s/f'before-native-{tc}-metrics.json').read_text())
 if 'Finished' not in (s/f'logs/{tag}-native-{tc}').read_text():continue
 rows={}
 for r in map(json.loads,p.read_text().splitlines()):
  if not r.get('executable'):continue
  target=r['target']['name'];file=Path(r['executable']); b=base[target];current=metrics(file);rows[target]=current
  section=int(next(l.split()[1] for l in subprocess.check_output(['size','-A',file],text=True).splitlines() if l.startswith('.relro_padding')))
  print(tc,target,'padding',b['allocated_sections']['.relro_padding'],section,'file',current['file']-b['file'])
 (s/f'{tag}-subset-{tc}.json').write_text(json.dumps(rows,indent=2)+'\n')
