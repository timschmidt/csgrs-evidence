import csv, hashlib, os
from pathlib import Path
src=Path(os.environ['s'])/'scanned.tsv'
with src.open(newline='') as f:
    rows=list(csv.DictReader(f,delimiter='\t'))
details={
 'classify_tangent_alignment':('Two retained Real planar vectors','Exact sign comparisons under certified-only policy','Direct classification clients','Scalar proof scratch'),
 'classify_certified_alignment':('Two retained Real planar vectors','Ordered zero norms, cross product, then dot product when parallel','classify_tangent_alignment and classify_tangent_join','Scalar proof scratch'),
 'is_zero_vector':('One Real planar vector','Certified sign of its exact squared norm at alignment call sites','classify_certified_alignment','Scalar norm and proof scratch'),
 'classify_tangent_join':('Two retained endpoint and tangent pairs','Certified endpoint equality precedes alignment; unresolved alignment retains proven endpoint equality','Direct join, chain, corner limits and schedule','Scalar proof scratch and fixed report'),
 'classify_tangent_chain':('Slice of retained endpoint and tangent spans','Adjacent pair classification in traversal order','TangentChainReport clients','One report vector and per-join predicate scratch'),
 'from_tangent':('TangentJoinClass','Total mapping to a lookahead class or typed unresolved/unsuitable outcome','Local corner checks and schedule planning/replay','Enum conversion without allocation'),
 'certify_corner_lookahead_limits':('Exact joins, feeds, radii and policy','Classify retained spans and replay each admitted feed constraint','Public local corner certification','Join vector and solver replay reports'),
 'lookahead_join_class':('Incoming and outgoing exact tangent spans','Preserve the join classifier outcome in lookahead','Schedule planning','Local report and predicate scratch'),
 'certify_local_corner_limits':('Schedule junction feeds and retained spans','Independent replay maps the tangent report and checks local limits','Schedule replay','Join vector and solver replay reports'),
}
out=[]
for r in rows:
    if r['path'].startswith('crates/hyperpath/src/') and r['symbol'] in details and r['review_status'].startswith('lexical candidate;'):
        ep,sem,consumer,alloc=details[r['symbol']]
        sha=hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()
        out.append(dict(r,endpoint_representation=ep,semantics=sem,consumers=consumer,allocation=alloc,
            platform='Linux x86_64 and wasm32-wasip1; Rust 1.95 and 1.99',serialization='No codec at this function',
            owner='hyperpath',disposition='Retain with certified tangent and typed routing contract',
            baseline_tests='hyperpath tangent_certification, dispatch_trace, schedule_equivalence and complete owner suite',
            baseline_benchmarks='path_predicates tangent chain, corner lookahead and feed schedule',
            review_status=f'Body and immediate callers reviewed at e8b1bef51; file SHA-256 {sha}'))
assert len(out)==len(details)
with Path('interval-inventory.tsv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0],delimiter='\t',lineterminator='\n')
    w.writeheader(); w.writerows(rows+out)
