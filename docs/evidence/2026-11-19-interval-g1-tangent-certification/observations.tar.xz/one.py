import sys,os,subprocess,json,re
from pathlib import Path
s=Path(os.environ['s']);from metrics import metrics
tag=sys.argv[1];r=next(r for r in map(json.loads,(s/f'logs/{tag}-native-stable.jsonl').read_text().splitlines()) if r.get('executable'))
p=Path(r['executable']);v=metrics(p)
v['relro_padding']=int(re.search(r'^\.relro_padding\s+(\d+)',subprocess.check_output(['size','-A',p],text=True),re.M)[1])
(s/f'{tag}-single.json').write_text(json.dumps(v))
print(v)
