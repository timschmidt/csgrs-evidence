set -eu
tc=$1
export CARGO_TARGET_DIR="$s/target-$tc" CARGO_TARGET_WASM32_WASIP1_RUSTFLAGS="--sysroot $s/sysroot-$tc"
bash "$s/native.sh" "$tc" final
python3 "$s/snapshot.py" final "$tc" native
cargo +"$tc" build --release --locked -p hyperpath --all-features --tests --example certified_schedule --bench path_predicates --target wasm32-wasip1 --message-format=json-render-diagnostics > "$s/logs/final-wasi-$tc.jsonl" 2> "$s/logs/final-wasi-$tc"
python3 "$s/snapshot.py" final "$tc" wasi
python3 crates/hyperinterval/conformance/wasi-path.py --toolchain "$tc" --output "$s/final-suites-$tc" > "$s/logs/final-suites-$tc" 2>&1
for target in wasm32-wasip1 x86_64-unknown-linux-gnu; do
 cargo +"$tc" clippy -p hyperpath --locked --release --all-targets --all-features --target "$target" -- -D warnings > "$s/logs/final-clippy-$tc-$target" 2>&1
done
