from pathlib import Path
import importlib.util,json
s=Path(__file__).parent
spec=importlib.util.spec_from_file_location('archive','/dev/shm/interval-budget-receipt/width-record.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.s=s
items=set()
for pattern in ('base','revision','env','scope.md','README.md','*.sh','*.py','*.json','versions.txt','logs/*','seed/*','direct-ci/*','wide-seed','alumina/*.json','alumina/Cargo.toml','alumina/Cargo.lock','alumina/test.log'):
 items.update(p for p in s.glob(pattern) if p.is_file())
print(json.dumps(m.record('fixed-hull-oracle',items,'Archive fixed-point hull tightness witnesses, sanitizer campaigns and linked image accounts')))
