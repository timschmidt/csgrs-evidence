from pathlib import Path
import json
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
def read(p):return json.loads((s/p).read_text())
ev=read('archive-result');peak=read('memory-entry.json')['registered_peak_bytes'];fs=read('fuzz-sizes.json')
cov=read('coverage-summary.json')['production']
with (r/'INTERVAL_REFACTOR_PROGRESS.md').open('a') as f:f.write(f"""
## Phases 2 and 14, tight fixed-point arithmetic hulls, 18 November 2026

In `9fa17b080`, Hyperinterval's Q2.30 and Q31.32 checks require an exact
attainable extremum to fall beyond each inward lattice neighbor. Signed
integer cross-products prove containment, tightness and representability.
The square and absolute-value checks include zero when the interval crosses
it. The original 16-byte fuzz inputs retain their Q2.30 interpretation, and
a 32-byte input additionally supplies all four Q31.32 endpoints.
[Independent oracle](crates/hyperinterval/tests/support/fixed_hull_oracle.rs) · [Fuzz target](crates/hyperinterval/fuzz/fuzz_targets/fixed_arithmetic.rs)

On `5261b146c`, a product widened by one lattice unit passed the Q31.32
extreme matrix and 100,000 sanitizer fuzz runs. Both revised checks rejected
the mutation. A separate one-unit error confined to the 64-bit upper bound
was detected by a 32-byte seed. The native and WASI arithmetic suites
passed on Rust 1.88, 1.95 and 1.99. Three Alumina firmware Q30 differential
tests passed against firmware `35d1b0da6`. The CI fuzz command and three
bounded candidate campaigns completed 100,000 runs each, including an empty
starting corpus and all 4,050 width-specific boundary seeds. The latter
campaign peaked at {peak:,} bytes within its 1 GiB swap-disabled cgroup.

The largest ordinary executable growth was 688 bytes. Native and WASI emitted
code shrank on all three compilers. The sanitizer image added
{fs['candidate']['code']-fs['base']['code']:,} emitted code bytes and fit its
per-image allowance. All production accounts carry forward.
[Size accounts](docs/research/interval-size-accounts.json) · [Memory accounts](docs/research/interval-memory-accounts.json)

Native release tests, strict native Clippy, the fuzz target's strict Clippy
check, strict Rustdoc, formatting and the workflow security audit passed.
The whole-owner coverage gate is still open. The preceding and retained Rust
1.99 runs measured identical production coverage on every file, with
{cov['lines']['covered']:,}/{cov['lines']['count']:,} lines,
{cov['regions']['covered']:,}/{cov['regions']['count']:,} regions and
{cov['functions']['covered']}/{cov['functions']['count']} functions. This
compiler supplied no branch counts. Hosted CI and physical hardware
execution remain outside this qualification.

Evidence commit `{ev['commit']}` contains {ev['members']} files under
`{ev['record']}` with digest
`{ev['row'].split()[-1]}`. [Evidence index](docs/evidence-archive.tsv)
""")
