from pathlib import Path
s=Path(__file__).parent
p=s/'src/crates/hyperinterval/src/fixed_arithmetic.rs';t=p.read_text()
old='quotient_bounds(lower, scale).0,\n                            quotient_bounds(upper, scale).1,'
assert t.count(old)==1
p.write_text(t.replace(old,'(quotient_bounds(lower, scale).0 - 1).max(i128::from(<$endpoint>::MIN)).min(quotient_bounds(lower, scale).0.max(i128::from(<$endpoint>::MIN))),\n                            quotient_bounds(upper, scale).1,').replace('(quotient_bounds(lower, scale).0 - 1).max(i128::from(<$endpoint>::MIN)).min(quotient_bounds(lower, scale).0.max(i128::from(<$endpoint>::MIN)))','{ let lo = quotient_bounds(lower, scale).0; if lo > i128::from(<$endpoint>::MIN) && lo <= i128::from(<$endpoint>::MAX) { lo - 1 } else { lo } }'))
