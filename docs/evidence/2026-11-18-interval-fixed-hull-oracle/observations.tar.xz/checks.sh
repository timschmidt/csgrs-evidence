set -eu
s=/dev/shm/interval-fixed-hull
. "$s/env"
v=$1
features=(--all-features)
if test "$v" = 1.88.0; then features=(--no-default-features --features integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace); fi
export CARGO_TARGET_DIR="/dev/shm/interval-scalar-replay/lint-$v"
cargo "+$v" clippy --locked --release -p hyperinterval --all-targets "${features[@]}" -- -D warnings
cargo "+$v" test --locked --release -p hyperinterval "${features[@]}"
cargo "+$v" test --release --locked -p hyperinterval --no-default-features
RUSTDOCFLAGS="-D warnings" cargo "+$v" doc --locked --release -p hyperinterval --no-deps "${features[@]}"
cargo "+$v" clippy --locked --manifest-path crates/hyperinterval/fuzz/Cargo.toml --bin fixed_arithmetic -- -D warnings
echo PASSED
