set -eu
s=/dev/shm/interval-fixed-hull
cd /mnt/development/csgrs
for file in crates/hyperinterval/{tests/arithmetic.rs,tests/support/fixed_hull_oracle.rs,fuzz/fuzz_targets/fixed_arithmetic.rs}; do cp "$file" "$s/src/$file"; done
