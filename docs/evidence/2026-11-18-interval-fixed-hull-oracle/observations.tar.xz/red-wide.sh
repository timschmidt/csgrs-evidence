set -eu
s=/dev/shm/interval-fixed-hull
. "$s/env"
while ! rg -q 'an endpoint can move inward' "$s/logs/new-mutant-q30.log" 2>/dev/null; do sleep 1; done
p="$s/src/crates/hyperinterval/src/fixed_arithmetic.rs"
git show HEAD:crates/hyperinterval/src/fixed_arithmetic.rs > "$p"
python3 - <<'PY'
from pathlib import Path
p=Path('/dev/shm/interval-fixed-hull/src/crates/hyperinterval/src/fixed_arithmetic.rs');t=p.read_text()
key='quotient_bounds(lower, scale).0,\n                            quotient_bounds(upper, scale).1,'
assert t.count(key)==1
p.write_text(t.replace(key,'quotient_bounds(lower, scale).0,\n                            { let hi = quotient_bounds(upper, scale).1; if <$endpoint>::BITS == 64 && hi >= i128::from(<$endpoint>::MIN) && hi < i128::from(<$endpoint>::MAX) { hi + 1 } else { hi } },'))
import struct
s=p.parents[4]
(s/'wide-seed').write_bytes(struct.pack('<qqqq',2**32,2**32,2**32,2**32))
PY
cd "$s/src/crates/hyperinterval/fuzz"
cargo +nightly fuzz build fixed_arithmetic --target-dir "$s/fuzz-target" > "$s/logs/wide-mutant-build.log" 2>&1
exe="$s/fuzz-target/x86_64-unknown-linux-gnu/release/fixed_arithmetic"
"$exe" "$s/seed/0" > "$s/logs/wide-mutant-legacy-input.log" 2>&1
if "$exe" "$s/wide-seed" > "$s/logs/wide-mutant-q32.log" 2>&1; then exit 1; fi
rg -q 'an endpoint can move inward' "$s/logs/wide-mutant-q32.log"
