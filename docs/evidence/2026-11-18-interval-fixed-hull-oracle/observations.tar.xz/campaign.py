from pathlib import Path
import sys,subprocess as sp,json,time,os
s=Path(__file__).parent;stage=sys.argv[1];mode=sys.argv[2]
exe=s/(stage+'.fuzz')
group=Path('/sys/fs/cgroup'+Path('/proc/self/cgroup').read_text().strip().split(':')[-1])
log=s/'logs'/f'campaign-{stage}-{mode}.log';dest=s/f'corpus-{stage}-{mode}';dest.mkdir()
import shutil
if mode=='old':
 for p in (s/'seed').iterdir():shutil.copyfile(p,dest/p.name)
elif mode=='extremes':
 for p in (s/'extremes').iterdir():shutil.copyfile(p,dest/p.name)
start=time.monotonic()
args=[str(exe),str(dest),'-runs=100000','-max_len='+('16' if mode=='old' else '32'),'-max_total_time=30','-seed=20261112']
with log.open('w') as out:sp.run(args,stdout=out,stderr=sp.STDOUT,check=True,env=os.environ|{'ASAN_OPTIONS':'quarantine_size_mb=128'})
assert '#100000' in log.read_text() and 'DONE' in log.read_text()
result=dict(command=args,seconds=time.monotonic()-start,peak=int((group/'memory.peak').read_text()),max=int((group/'memory.max').read_text()),swap=int((group/'memory.swap.max').read_text()),events=(group/'memory.events').read_text(),corpus_lengths=sorted({p.stat().st_size for p in dest.iterdir()}))
assert result['max']==2**30 and result['swap']==0 and 'oom_kill 0' in result['events'] and result['peak']+256*2**20<=2**30
print(json.dumps(result,indent=1))
