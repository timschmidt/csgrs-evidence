set -eu
s=/dev/shm/interval-fixed-hull
. "$s/env"
cd "$s/src"
cargo +1.95.0 test --locked --release -p hyperinterval --test arithmetic --all-features -- q31_32_extreme_matrix_matches_exact_cross_product_oracle
cd crates/hyperinterval/fuzz
cargo +nightly fuzz build fixed_arithmetic --target-dir "$s/fuzz-target"
exe="$s/fuzz-target/x86_64-unknown-linux-gnu/release/fixed_arithmetic"
cp "$exe" "$s/$1.fuzz"
"$exe" "$s/seed" -runs=100000 -max_len=16 -max_total_time=30 -seed=20261112
