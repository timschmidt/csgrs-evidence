set -eu
s=/dev/shm/interval-fixed-hull
. "$s/env"
bash "$s/stage.sh"
cd "$s/src"
if cargo +1.95.0 test --locked --release -p hyperinterval --test arithmetic --all-features -- q31_32_extreme_matrix_matches_exact_cross_product_oracle > "$s/logs/new-mutant-test.log" 2>&1; then exit 1; fi
rg -q 'an endpoint can move inward' "$s/logs/new-mutant-test.log"
cd crates/hyperinterval/fuzz
cargo +nightly fuzz build fixed_arithmetic --target-dir "$s/fuzz-target" > "$s/logs/new-mutant-fuzz-build.log" 2>&1
exe="$s/fuzz-target/x86_64-unknown-linux-gnu/release/fixed_arithmetic"
if "$exe" "$s/seed/0" > "$s/logs/new-mutant-q30.log" 2>&1; then exit 1; fi
rg -q 'an endpoint can move inward' "$s/logs/new-mutant-q30.log"
