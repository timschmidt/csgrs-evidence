from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess as sp,sys,shutil
s=Path(__file__).parent;repo=Path('/mnt/development/csgrs');src=s/'images-src';src.mkdir(exist_ok=True)
sys.path.insert(0,'/dev/shm/interval-budget-receipt')
from metrics import metrics
sdk=Path('/dev/shm/interval-scalar-wasi/ubuntu/sdk/usr')
def build(v):
 base=['cargo','+'+v,'test','--release','--locked','-p','hyperinterval','--test','arithmetic']
 if v=='1.88.0':base+=['--no-default-features','--features','integer,fixed,dyadic,float-proposal,float-enclosure-wasip1,serde,dispatch-trace']
 else:base+=['--all-features']
 result={}
 for target in ('native','wasm32-wasip1'):
  env=os.environ|{'CARGO_TARGET_DIR':'/dev/shm/interval-scalar-replay/target-'+v,'CARGO_BUILD_JOBS':'4'}
  cmd=base.copy()
  if target!='native':
   env.update(CC=str(sdk/'bin/clang-18')+' --target=wasm32-wasi --sysroot='+str(sdk),CC_FOR_BUILD='cc',CPPFLAGS='-D_WASI_EMULATED_SIGNAL',LIBS='-lwasi-emulated-signal',GMP_MPFR_SYS_CACHE='/dev/shm/interval-scalar-wasi/final-'+v+'/gmp-cache',CARGO_ENCODED_RUSTFLAGS='-C\x1flink-arg='+str(sdk/'lib/wasm32-wasi/libwasi-emulated-signal.a'))
   cmd+=['--target',target]
  cmd+=['--no-run','--message-format=json-render-diagnostics']
  data=sp.check_output(cmd,env=env,cwd=src,text=True)
  [exe]=[Path(row['executable']) for row in map(json.loads,data.splitlines()) if row.get('executable')]
  result[target]=metrics(exe)
  call=[exe] if target=='native' else ['node',str(src/'crates/hyperlattice-interval/conformance/run-wasi-test.mjs'),exe]
  log=sp.check_output(call,stderr=sp.STDOUT,text=True)
  (s/'logs'/f'{stage}-{v}-{target}-arithmetic.log').write_text(log)
  assert '11 passed; 0 failed' in log
 return v,result
for stage in sys.argv[1:]:
 rev='933c9ae56' if stage=='fixed' else (s/'base').read_text().strip()
 with sp.Popen(['git','archive',rev],cwd=repo,stdout=sp.PIPE) as p:
  sp.run(['tar','-xmC',src],stdin=p.stdout,check=True);assert p.wait()==0
 if stage not in ('fixed','base'):
  for f in ['tests/arithmetic.rs','tests/support/fixed_hull_oracle.rs']:
   p=Path('crates/hyperinterval')/f;shutil.copyfile(repo/p,src/p)
 with ThreadPoolExecutor(3) as pool:result=dict(pool.map(build,['1.88.0','1.95.0','stable']))
 (s/f'{stage}-images.json').write_text(json.dumps(result,indent=2)+'\n')
