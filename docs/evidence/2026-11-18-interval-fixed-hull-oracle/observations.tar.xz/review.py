from pathlib import Path
import hashlib,json,re
s=Path(__file__).parent
def load(p):return json.loads((s/p).read_text())
def save(p,x):(s/p).write_text(json.dumps(x,indent=2)+'\n')
source=(s/'revision').read_text().strip()
obs='docs/evidence/2026-11-18-interval-fixed-hull-oracle'
f,b,c=[load(x+'-images.json') for x in ('fixed','base','candidate')]
fs=load('fuzz-sizes.json')
rows={}
def account(a,x,y,inc,rel,total,totrel):
 prior=max(0,x-a);charge=max(0,y-x)
 room=min(inc,x*rel//100)-charge;remaining=min(total,a*totrel//100)-prior-charge
 assert min(room,remaining)>=0
 return [a,x,y,prior,charge,prior+charge,room,remaining]
for v in b:
 for target in b[v]:
  rows[v+' '+target]={m:account(f[v][target][m],b[v][target][m],c[v][target][m],4096,1,8192,2) for m in ('file','code','functions')}
  assert '11 passed; 0 failed;' in (s/'logs'/f'candidate-{v}-{target}-arithmetic.log').read_text()
 assert (s/'logs'/f'checks-{v}.log').read_text().endswith('PASSED\n')
rows['nightly native ASan libFuzzer']={m:account(fs['base'][m],fs['base'][m],fs['candidate'][m],256*1024,5,512*1024,10) for m in ('file','code','functions')}
cap=64*2**20
assert all(cap-row['file'][2]>=16*2**20 for row in rows.values())
save('size-entry.json',dict(source=source,evidence=obs,workload='Fixed-point arithmetic integration tests on native and WASI plus the hosted sanitizer-instrumented fixed_arithmetic fuzz executable. Production artifacts have no source, feature or dependency changes. Existing accounts carry forward.',fixed='933c9ae56 for ordinary test images. First sanitizer image registration at '+(s/'base').read_text().strip(),preceding=(s/'base').read_text().strip(),caps='Ordinary images 4096 bytes / 1% incremental and 8192 bytes / 2% cumulative. ASan image 256 KiB / 5% incremental and 512 KiB / 10% cumulative. Percentages use preceding and fixed bytes respectively. Smaller of the absolute and relative limits governs.',file_slot_bytes=cap,required_free_bytes=16*2**20,columns=['fixed','preceding','accepted','previous_positive','incremental_positive','cumulative_positive','remaining_incremental','remaining_cumulative'],bytes=rows,free_file_slot_bytes={k:cap-v['file'][2] for k,v in rows.items()}))
runs={x:load('campaign-'+x+'.json') for x in ('base-old','candidate-old','candidate-empty','candidate-extremes')}
assert 32 in runs['candidate-empty']['corpus_lengths'] and all(x['seconds']<30 for x in runs.values())
memcap=2**30;reserve=256*2**20
save('memory-entry.json',dict(source=source,evidence=obs,scope='Hosted sanitizer conformance campaigns only. Fresh swap-disabled cgroup per invocation through result and cleanup. One worker, ASan quarantine 128 MiB, max 100000 runs, 30 s, 16 or 32 input bytes. The baseline and candidate legacy invocations consume the same input seeds. The new workload includes both formats. Production heap and stack accounts carry forward independently.',capacity_bytes=memcap,required_free_bytes=reserve,unit='whole cgroup peak bytes, including input corpus reads, fuzzer, sanitizer and allocator overhead',legacy_baseline_peak_bytes=runs['base-old']['peak'],legacy_observed_peak_bytes=runs['candidate-old']['peak'],legacy_positive_increase_bytes=max(0,runs['candidate-old']['peak']-runs['base-old']['peak']),ordinary_new_job_peak_bytes=runs['candidate-empty']['peak'],seeded_extreme_job_peak_bytes=runs['candidate-extremes']['peak'],registered_peak_bytes=max(v['peak'] for v in runs.values()),remaining_above_reserve_bytes=memcap-reserve-max(v['peak'] for v in runs.values())))
assert 'Done 100000 runs' in (s/'logs/ci-fuzz.log').read_text()
assert 'Done 100000 runs' in (s/'logs/before-mutant.log').read_text() and 'test result: ok. 1 passed' in (s/'logs/before-mutant.log').read_text()
assert all('an endpoint can move inward' in (s/'logs'/n).read_text() for n in ('new-mutant-test.log','new-mutant-q30.log','wide-mutant-q32.log'))
assert load('alumina/result.json')['exit']==0 and '3 passed' in (s/'logs/alumina.log').read_text()
assert 'No findings to report.' in (s/'logs/zizmor.log').read_text()
cov=[]
for stage in ('control-coverage','coverage'):
 txt=(s/'logs'/(stage+'.log')).read_text()
 path=Path(re.search(r'^Coverage artifacts in (.+)$',txt,re.M)[1]);rec=json.loads((path/'summary.json').read_text())
 assert 'Production coverage is below 100%' in txt
 save(stage+'-summary.json',rec);cov.append(rec)
assert cov[0]['production']==cov[1]['production'] and cov[0]['files']==cov[1]['files']
save('corpus-digests.json',{d.name:{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.iterdir())} for d in (s/'seed',s/'extremes',s/'direct-ci')})
print(cov[1]['production'])
