set -eu
s=/dev/shm/interval-fixed-hull
. "$s/env"
cd /mnt/development/csgrs
git show HEAD:crates/hyperinterval/src/fixed_arithmetic.rs > "$s/src/crates/hyperinterval/src/fixed_arithmetic.rs"
bash "$s/stage.sh"
cd "$s/src/crates/hyperinterval/fuzz"
cargo +nightly fuzz build fixed_arithmetic --target-dir "$s/fuzz-target" > "$s/logs/accepted-fuzz-build.log" 2>&1
cp "$s/fuzz-target/x86_64-unknown-linux-gnu/release/fixed_arithmetic" "$s/candidate.fuzz"
python3 - <<'PY'
from itertools import combinations_with_replacement,product
from pathlib import Path
import struct,sys,json
s=Path('/dev/shm/interval-fixed-hull')
sys.path.insert(0,'/dev/shm/interval-budget-receipt')
from metrics import metrics
data={n:metrics(s/(n+'.fuzz')) for n in ('base','candidate')}
(s/'fuzz-sizes.json').write_text(json.dumps(data,indent=1)+'\n')
dest=s/'extremes';dest.mkdir(exist_ok=True)
for bits,fmt,scale in [(32,'i',30),(64,'q',32)]:
 vals=[-(1<<(bits-1)),-(1<<(bits-1))+1,-(1<<scale),-1,0,1,(1<<scale),(1<<(bits-1))-2,(1<<(bits-1))-1]
 pairs=list(combinations_with_replacement(vals,2))
 for i,(ab,cd) in enumerate(product(pairs,pairs)):
  (dest/f'{bits}-{i}').write_bytes(struct.pack('<4'+fmt,*ab,*cd))
PY
for run in 'base old' 'candidate old' 'candidate empty' 'candidate extremes'; do
 read -r stage mode <<< "$run"
 systemd-run --user --scope -q -p MemoryMax=1G -p MemorySwapMax=0 -- python3 "$s/campaign.py" "$stage" "$mode" > "$s/campaign-$stage-$mode.json"
done
