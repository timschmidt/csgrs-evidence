"""Verify the completed commit against the separately verified staged blobs."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
stage=N/'point-facts-stage-verification-v1.json';previous=json.loads(stage.read_text())
head=git('rev-parse','HEAD').decode().strip();parent=git('rev-parse','HEAD^').decode().strip();assert parent==previous['parent_revision']
expected=previous['staged_blobs_sha256']
assert set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(expected)
committed={p:hashlib.sha256(git('show','HEAD:'+p)).hexdigest() for p in expected}
assert committed==expected and all(sha(O/p)==h for p,h in expected.items())
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
status=git('status','--short').decode();assert status=='?? docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py\n',status
assert sha(O/'docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py')=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
receipt=N/'point-facts-commit-verification-v1.json';assert not receipt.exists()
receipt.write_text(json.dumps({'commit':head,'parent':parent,'stage_receipt_sha256':sha(stage),'helper_sha256':sha(Path(__file__)),'verified_committed_blobs_sha256':committed,'verified_blob_count':len(committed),'tracked_worktree_clean':True,'preexisting_untracked_helper_unchanged':True,'status':status,'push_performed':False,'full_plan_complete':False},indent=2,sort_keys=True)+'\n')
print(json.dumps({'commit':head,'verified_blobs':len(committed),'tracked_worktree_clean':True,'preexisting_untracked_helper_unchanged':True,'receipt':str(receipt)}),flush=True)
