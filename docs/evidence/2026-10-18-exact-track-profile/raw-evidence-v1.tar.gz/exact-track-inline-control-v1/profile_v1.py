"""Profile the current exact-ingress candidate without modifying closed evidence."""
import gzip,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
T=M/'targets/exact-track-inline-profile-v1';A=V/'exact-track-inline-profile-artifacts-v1';R=N/'exact-track-inline-profile-v1'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert (N/'exact-track-inline-candidate-v1/result-v1.json').is_file(), 'finish original gates before profiling'
assert not R.exists() and not A.exists() and not (V/'targets/exact-track-inline-profile-v1').exists()
R.mkdir();A.mkdir();(V/'targets/exact-track-inline-profile-v1').mkdir()
prep=json.loads((W/'preparation-v1.json').read_text());compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text())
assert all(sha(p)==h for p,h in compiler['tool_sha256'].items())
os.environ.update(compiler['additional_environment']);os.environ.update(CARGO_NET_OFFLINE='true',RUSTFLAGS='-Cforce-frame-pointers=yes',CARGO_PROFILE_RELEASE_DEBUG='1',DEBUGINFOD_URLS='')
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
base=json.loads(gzip.decompress((N/'point-rational-native-facts-source-v1.json.gz').read_bytes()))
effective=json.loads(gzip.decompress((W/'effective-source-pins-v1.json.gz').read_bytes()));commands={};artifact=None
protocol={'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'profile-contract-v1.md'),'preparation_sha256':sha(W/'preparation-v1.json'),'original_gate_result_sha256':sha(N/'exact-track-inline-candidate-v1/result-v1.json'),'compiler_sha256':compiler['tool_sha256'],'perf_sha256':sha('/usr/bin/perf'),'perf_version':subprocess.check_output(['/usr/bin/perf','version'],text=True),'perf_event_paranoid':Path('/proc/sys/kernel/perf_event_paranoid').read_text().strip(),'cpuinfo':Path('/proc/cpuinfo').read_text(),'target_initially_absent':True,'source_frozen':True,'closed_target_mutated':False,'sampling_hz':3,'sampling_event':'cycles:u','call_graph':'fp','inline_expansion':False,'features':'hyperdrc default features, library test','diagnostic_only':True,'profile_runtime_is_not_matched_benchmark':True,'build_environment':{k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_PROFILE_RELEASE_DEBUG','RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN','CARGO_NET_OFFLINE','DEBUGINFOD_URLS']},'retention_contract_sha256':sha(N/'point-rational-equality-control-v1/retention-contract-v2.json'),'runner_sha256':sha(N/'point-rational-equality-control-v1/validation_runner_v4.py'),'hypervoxel_excluded':True}
dump(R/'protocol-v1.json',protocol)
def verify():
    assert all(sha(S/p)==h for p,h in base.items())
    assert all(sha(Path(prep['overlays'][p]['physical_path']) if p in prep['overlays'] else S/p)==h for p,h in effective.items())
    if artifact:assert sha(artifact['compiled_physical_path'])==sha(artifact['copy'])==artifact['sha256']
    assert not reasons(resources())
def execute(label,args,allow_test_failure=False,wall_seconds=1800):
    verify();name='exact-track-inline-profile-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(V/'targets/exact-track-inline-profile-v1'),str(T),'--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(S if label=='build' else scratch)]
    for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
    for dest,row in prep['overlays'].items():argv+=['--ro-bind',row['physical_path'],str(S/dest)]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,S,target=T,wall_seconds=wall_seconds)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands)
        if r['stops'] or not allow_test_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(R/'progress-v1.json',commands);verify()
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M)
    return out,err,r
execute('permission',['/usr/bin/perf','stat','-e','cycles:u','--','/usr/bin/true'],wall_seconds=60)
out,err,r=execute('build',[cargo,'test','--release','--locked','-p','hyperdrc','--lib','--no-run','--message-format=json'])
rows=[]
for line in out.splitlines():
    if not line.startswith('{'):continue
    item=json.loads(line)
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item['target']['name']=='hyperdrc':rows.append(item)
assert len(rows)==1,rows
item=rows[0];assert 'lib' in item['target']['kind'] and item['profile']['test']
path=Path(item['executable']);physical=V/path.relative_to(M);copy=A/'hyperdrc-lib';shutil.copy2(physical,copy);assert sha(physical)==sha(copy)
artifact={'compiled_child_path':str(path),'compiled_physical_path':str(physical),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'features':item['features'],'profile':item['profile'],'manifest_path':item['manifest_path']};dump(A/'executable-v1.json',artifact)
profile=A/'perf.data'
out,err,r=execute('record',['/usr/bin/perf','record','-F','3','-e','cycles:u','--call-graph','fp','--compression-level=5','--no-buildid-cache','-o',str(profile),'--',str(copy),'zz_complex_project_performance_tests::kicad_board_completes_smoke_check_suite','--exact','--nocapture','--test-threads=1'],allow_test_failure=True)
combined=out+err;assert profile.is_file() and profile.stat().st_size>0
assert 'skipping complex project fixture' not in combined
assert combined.count('hyperdrc: finished emit report')==2
assert len(re.findall(r'^test result: (?:ok|FAILED)\. [01] passed; [01] failed; 0 ignored; 0 measured;',out,re.M))==1
record_result=r;worker=re.search(r'took ([0-9.]+)s of worker time',combined)
for label,args in [
 ('self',['report','--stdio','--stdio-color','never','--no-inline','--no-children','--call-graph','none','--sort','symbol,dso','--percent-limit','0.05']),
 ('inclusive',['report','--stdio','--stdio-color','never','--no-inline','--children','--call-graph','flat,1,caller','--sort','symbol,dso','--percent-limit','0.5']),
 ('header',['report','--header-only','--stdio']),
 ('stacks',['script','--show-lost-events','--no-inline','-F','comm,pid,tid,time,period,event,ip,sym,dso'])]:
    execute(label,['/usr/bin/perf']+args+['-i',str(profile)])
verify();dump(R/'result-v1.json',{'commands':commands,'complete_original_fixture':True,'profile_record_exit_code':record_result['exit_code'],'profile_worker_cpu_seconds':float(worker[1]) if worker else None,'artifact':artifact,'perf_data_sha256':sha(profile),'perf_data_bytes':profile.stat().st_size,'source_unchanged':True,'main_source_unchanged':True,'diagnostic_only':True,'importer_admitted':False,'full_plan_complete':False})
print(json.dumps({'profile_complete':True,'diagnostic_only':True,'importer_admitted':False}),flush=True)
