"""Attribute sampled cycle periods once per recovered symbol in the current profile."""
import collections,hashlib,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;R=N/'exact-track-inline-profile-v1'
def sha(p):
    with Path(p).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
result=json.loads((R/'result-v1.json').read_text());assert result['diagnostic_only']
assert sha(result['artifact']['copy'])==result['artifact']['sha256']
commands=result['commands']
for row in commands.values():
    for name,h in row['output_sha256'].items():assert sha(N/'logs'/Path(row['environment_overrides']['TMPDIR']).name/name)==h
stacks=N/'logs/exact-track-inline-profile-stacks-v1/stdout'
blocks=stacks.read_text().strip().split('\n\n');symbols=collections.Counter();leaves=collections.Counter();depths=collections.Counter();weights=collections.Counter();callers=collections.defaultdict(collections.Counter)
groups={'board_fixture':'kicad_board_completes_smoke_check_suite','point_equality':'<hypercurve::point::Point2 as core::cmp::PartialEq>::eq','rational_equality':'rational::Rational as core::cmp::PartialEq','polynomial_normal_form':'pi_laurent_polynomial','exact_sign':'::exact_sign','zero_status':'::zero_status','structural_facts':'::structural_facts','quadratic_projection':'exact_quadratic_surd_parts','regularized_fragment_classification':'regularized_fragment_geometric_decision','regularized_fragment_actions':'regularized_fragment_actions','retained_boundary_side_ray':'loop_windings_from_boundary_side_ray','native_minor_arc_winding':'process_minor_arc_winding','conic_line_relation':'relation_to_line_with','native_filled_area':'::filled_area','report_projection':'::try_to_multipolygon','layer_sanity':'::layer_sanity','copper_neck':'::min_copper_neck_width','native_subcurve':'::subcurve','circle_support':'same_circle_support'}
project=re.compile(r'^<?&?(?:hyperreal|hypercurve|hyperlimit|hypersolve|hyperlattice|hyperdrc|hypermesh|hyperpath|hypertri|csgrs)::')
allocator=re.compile(r'^(?:_int_malloc|_int_free|_int_realloc|unlink_chunk|malloc|cfree@|free@|__libc_malloc|__libc_free|__libc_realloc|__rustc::__rust_alloc|__rustc::__rust_dealloc|__rustc::__rust_realloc)')
total=empty=unknown=0;times=[]
for block in blocks:
    lines=block.splitlines();match=re.match(r'^\S+\s+\d+/\d+\s+([0-9.]+):\s+(\d+) cycles:u:',lines[0]);assert match,lines[0]
    times.append(float(match[1]));period=int(match[2]);total+=period;frames=[]
    for line in lines[1:]:
        frame=re.match(r'\s+[a-f0-9]+ (.*?) \((.*)\)$',line);assert frame,line;frames.append(frame[1])
    depths[len(frames)]+=1
    if frames:leaves[frames[0]]+=period
    else:empty+=period
    if not frames or frames[0]=='[unknown]':unknown+=period
    for symbol in set(frames):symbols[symbol]+=period
    for name,needle in groups.items():
        indices=[i for i,f in enumerate(frames) if needle in f]
        if indices:
            weights[name]+=period
            caller=next((f for f in frames[max(indices)+1:] if project.match(f)),'<no recovered project-prefixed ancestor>')
            callers[name][caller]+=period
    if frames and allocator.match(frames[0]):
        weights['allocator_leaf_subset']+=period
        caller=next((f for f in frames[1:] if project.match(f)),'<no recovered project-prefixed ancestor>');callers['allocator_leaf_subset'][caller]+=period
report=(N/'logs/exact-track-inline-profile-self-v1/stdout').read_text()
assert int(re.search(r'Event count \(approx\.\): (\d+)',report)[1])==total
lost=int(re.search(r'Total Lost Samples: (\d+)',report)[1])
def rows(counter):return [{'symbol':s,'period':p,'total_profile_percent':100*p/total} for s,p in counter.most_common()]
observed={'helper_sha256':sha(Path(__file__)),'profile_result_sha256':sha(R/'result-v1.json'),'stacks_sha256':sha(stacks),'scope':__doc__,'samples':len(blocks),'total_sample_period':total,'lost_samples':lost,'first_sample_time':min(times),'last_sample_time':max(times),'empty_stack_period_percent':100*empty/total,'unknown_leaf_period_percent':100*unknown/total,'depth_sample_counts':dict(sorted(depths.items())),'groups':{n:{'symbol_substring':s,'period':weights[n],'inclusive_percent':100*weights[n]/total} for n,s in groups.items()},'allocator_leaf_subset_percent':100*weights['allocator_leaf_subset']/total,'allocator_symbol_pattern':allocator.pattern,'nearest_recovered_project_callers':{name:rows(counter) for name,counter in callers.items()},'inclusive_symbols':rows(symbols),'leaf_symbols':rows(leaves),'limits':'Low-frequency sampled cycle periods, not calls, allocations, wall seconds, speedup predictions or semantic correctness evidence. Inclusive categories overlap; inline frames are absent; missing/truncated chains can undercount ancestors. This separate frame-pointer/line-table build is not a matched release comparison.','runtime_admitted':False}
p=R/'observations-v1.json';assert not p.exists();p.write_text(json.dumps(observed,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:observed[k] for k in ['samples','total_sample_period','lost_samples','empty_stack_period_percent','unknown_leaf_period_percent','allocator_leaf_subset_percent']}))
for name,row in observed['groups'].items():print(name,round(row['inclusive_percent'],3))
print('Top recovered inclusive symbols:')
for row in observed['inclusive_symbols'][:25]:print(round(row['total_profile_percent'],3),row['symbol'][:240])
