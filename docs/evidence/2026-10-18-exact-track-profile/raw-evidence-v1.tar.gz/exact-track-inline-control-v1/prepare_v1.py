"""Make the frozen importer source equivalent to current main plus its four differences."""
import gzip,json,os,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1')
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import dump,sha,GIT,resources,reasons
os.environ['GIT_OPTIONAL_LOCKS']='0'
assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()=='540074a8c05ccc676d7c70b8f0093f98804b81d9'
assert not subprocess.check_output(GIT+['diff','HEAD','--name-only'],cwd=O)
baseline=json.loads((N/'exact-track-inline-baseline-v1/result-v1.json').read_text())['summaries']
assert baseline=={'kicad_native_strokes':[['FAILED','0','10','0','0','0']],'kicad_native_aggregation':[['FAILED','9','3','0','0','0']],'existing_source_failures':[['ok','39','0','0','0','0']]}
assert not reasons(resources())
source_inventory=N/'point-rational-native-facts-source-v1.json.gz';base=json.loads(gzip.decompress(source_inventory.read_bytes()));assert all(sha(S/p)==h for p,h in base.items())
main=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));assert len(main)==2653 and all(sha(O/p)==h for p,h in main.items())
native=['crates/hyperdrc/src/kicad/tracks.rs','crates/hyperdrc/tests/kicad_track_failures.rs','crates/hyperdrc/tests/kicad_native_strokes.rs','crates/hyperdrc/tests/kicad_native_aggregation.rs']
effective=dict(main);effective.update({p:sha(S/p) for p in native});assert len(effective)==2655
overlays={}
for p,h in effective.items():
    if sha(S/p)==h:continue
    assert p not in native and sha(O/p)==h
    dest=W/'overlays'/p;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/p,dest);assert sha(dest)==h
    overlays[p]={'physical_path':str(dest),'sha256':h,'from_revision':'540074a8c05ccc676d7c70b8f0093f98804b81d9'}
assert len(overlays)==7
for p,h in effective.items():assert sha(Path(overlays[p]['physical_path']) if p in overlays else S/p)==h
inv=W/'effective-source-pins-v1.json.gz';assert not inv.exists();inv.write_bytes(gzip.compress((json.dumps(effective,sort_keys=True)+'\n').encode(),mtime=0))
p=W/'preparation-v1.json';assert not p.exists()
dump(p,{'parent_revision':'540074a8c05ccc676d7c70b8f0093f98804b81d9','helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'baseline_result_sha256':sha(N/'exact-track-inline-baseline-v1/result-v1.json'),'source_root':str(S),'source_inventory_sha256':sha(source_inventory),'effective_source_inventory_sha256':sha(inv),'main_paths_verified':len(main),'effective_paths':len(effective),'overlays':overlays,'candidate_differences_from_current_main':{p:sha(S/p) for p in native},'only_production_difference_from_current_main':'crates/hyperdrc/src/kicad/tracks.rs','importer_unchanged_from_e66':sha(S/native[0])==sha(N/'native-track-revisit-source-v1'/native[0]),'cache_proposal_present':False,'target':str(V/'targets/exact-track-inline-v1'),'target_initially_absent':not (V/'targets/exact-track-inline-v1').exists(),'source_frozen_read_only':True,'admitted':False})
assert all(sha(O/p)==h for p,h in main.items()) and all(sha(S/p)==h for p,h in base.items())
print(json.dumps({'effective_paths':len(effective),'overlays':list(overlays),'only_production_candidate':'crates/hyperdrc/src/kicad/tracks.rs'}),flush=True)
