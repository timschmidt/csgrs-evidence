# Current exact-ingress diagnostic profile

The unchanged current candidate passed 75 focused tests and failed the original
full-board gate at 369.825772873 seconds of worker CPU (120-second limit).
Complete the remaining original gates before this diagnostic. The importer
remains unadmitted; no source change is selected from an older profile.

Reuse exactly the effective source and default native features pinned by
preparation-v1.json. Build a separate release library-test binary with frame
pointers and release debug level 1. Keep the full original two-board fixture,
all checks, output materialization, policy, and assertions. Instrumentation
changes code generation, so profile time is not matched performance evidence.

First test userspace cycle-event permission under the same namespace. Sample
cycles:u at 3 Hz with frame-pointer stacks and no inline expansion. Low frequency
keeps decoded stacks within the existing cumulative 64 MiB command-log allowance;
no sample is a semantic oracle. Retain raw perf.data, full decoded stacks,
self/inclusive reports, header and lost-event diagnostics. State the actual
sample denominator, missing symbols, ancestry coverage, and uncertainty before
attributing cost or proposing an owning-layer repair.

Use a fresh Disk B target and artifact directory, read-only source overlays and
closed evidence, and only explicitly writable target, scratch and existing
mutable caches. Preserve every physical copy independently. The approved
72 GiB Disk B ceiling, original 16 GiB root ceiling and free baselines, 8 GiB
child address-space limit, two jobs, 1800-second command limit, reserves and
64 MiB total command-log limit remain unchanged. A containment stop remains a
failure, not a partial successful profile. Hypervoxel is excluded. No production
admission, uniform speedup, package-release or full-plan completion is claimed.
