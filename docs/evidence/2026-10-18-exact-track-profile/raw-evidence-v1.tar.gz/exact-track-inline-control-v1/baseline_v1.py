"""Reproduce archived exact-track findings against E69's admitted libraries."""
import gzip,json,os,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
S=N/'point-rational-native-facts-source-v1';A=V/'exact-track-inline-baseline-v1';R=N/'exact-track-inline-baseline-v1'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,reasons,resources,GIT
import subprocess
os.environ['GIT_OPTIONAL_LOCKS']='0'
assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()=='540074a8c05ccc676d7c70b8f0093f98804b81d9'
assert not subprocess.check_output(GIT+['diff','HEAD','--name-only'],cwd=O)
assert not A.exists() and not R.exists();A.mkdir();R.mkdir()
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment'])
expected=json.loads(gzip.decompress((O/'docs/evidence/2026-10-18-point-equality-facts/artifact-expectations-v1.json.gz').read_bytes()))['added_physical_artifacts_sha256']
mainpins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()))
assert all(sha(O/p)==h for p,h in mainpins.items())
log=N/'logs/point-rational-main-integration-native-compile-v2/stdout';assert sha(log)==expected[str(log)]
libraries={}
for line in log.read_text().splitlines():
    if not line.startswith('{'):continue
    row=json.loads(line);target=row.get('target',{})
    if row.get('reason')=='compiler-artifact' and target.get('name') in ['hyperdrc','hypercurve','hyperlimit'] and 'lib' in target['kind']:
        path=Path(next(p for p in row['filenames'] if p.endswith('.rlib')));physical=V/path.relative_to(M)
        assert sha(physical)==expected[str(physical)]
        libraries[target['name']]={'child_path':str(path),'physical_path':str(physical),'sha256':sha(physical)}
assert len(libraries)==3
tests={name:S/'crates/hyperdrc/tests'/name for name in ['kicad_native_strokes.rs','kicad_native_aggregation.rs']}
for p in tests.values():assert sha(p)==expected[str(p)]
existing=V/'point-rational-main-integration-artifacts-v2/kicad_track_failures';assert sha(existing)==expected[str(existing)]
dump(R/'protocol-v1.json',{'parent_revision':'540074a8c05ccc676d7c70b8f0093f98804b81d9','helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'libraries':libraries,'archived_test_sources_sha256':{str(p):sha(p) for p in tests.values()},'current_39_test_binary_sha256':sha(existing),'compiler_sha256':compiler['tool_sha256'],'main_source_pins_sha256':sha(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'retention_contract_sha256':sha(N/'point-rational-equality-control-v1/retention-contract-v2.json'),'artifacts':str(A)})
commands={};summaries={}
def execute(label,args,allow_failure=False):
    assert not reasons(resources());name='exact-track-inline-baseline-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(A),str(M/A.relative_to(V)),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch)]
    try:r=run(name,argv+args,O,wall_seconds=60)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text())
        if r['stops'] or not allow_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(R/'progress-v1.json',commands)
    return (N/'logs'/name/'stdout').read_text()
def rows(text):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
for filename,source in tests.items():
    name=source.stem;binary=M/A.relative_to(V)/name
    args=[compiler['additional_environment']['RUSTC'],'--test','--edition=2024','-C','opt-level=3','-D','warnings',str(source),'-o',str(binary),'-L','dependency='+str(Path(libraries['hyperdrc']['child_path']).parent)]
    for crate,row in libraries.items():args+=['--extern',crate+'='+row['child_path']]
    execute(name+'-compile',args)
    out=execute(name,[str(binary),'--nocapture','--test-threads=1'],allow_failure=True);summaries[name]=rows(out);assert len(summaries[name])==1
out=execute('existing-source-failures',[str(existing),'--test-threads=1']);summaries['existing_source_failures']=rows(out)
assert summaries['existing_source_failures']==[('ok','39','0','0','0','0')]
assert all(sha(O/p)==h for p,h in mainpins.items()) and all(sha(p)==expected[str(p)] for p in tests.values())
assert all(sha(row['physical_path'])==row['sha256'] for row in libraries.values())
dump(R/'result-v1.json',{'summaries':summaries,'commands':commands,'libraries':libraries,'source_revision':'540074a8c05ccc676d7c70b8f0093f98804b81d9','source_unchanged':True,'binaries':{p.name:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in A.iterdir() if p.is_file()},'exact_importer_admitted':False,'full_plan_complete':False})
print(json.dumps({'summaries':summaries,'source_unchanged':True}),flush=True)
