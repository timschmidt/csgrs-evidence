"""Build and evaluate unchanged exact-track ingress on current admitted scalar facts."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
T=M/'targets/exact-track-inline-v1';A=V/'exact-track-inline-artifacts-v1';R=N/'exact-track-inline-candidate-v1'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert not R.exists() and not A.exists() and not (V/'targets/exact-track-inline-v1').exists()
R.mkdir();A.mkdir();(V/'targets/exact-track-inline-v1').mkdir()
prep=json.loads((W/'preparation-v1.json').read_text());assert prep['importer_unchanged_from_e66']
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'))
base=json.loads(gzip.decompress((N/'point-rational-native-facts-source-v1.json.gz').read_bytes()))
effective=json.loads(gzip.decompress((W/'effective-source-pins-v1.json.gz').read_bytes()));commands={};summaries={};artifacts={}
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'preparation_sha256':sha(W/'preparation-v1.json'),'contract_sha256':sha(W/'contract-v1.md'),'compiler_sha256':compiler['tool_sha256'],'target_initially_absent':True,'cargo_and_gmp_caches_reused':True,'closed_target_mutated':False,'retention_contract_sha256':sha(N/'point-rational-equality-control-v1/retention-contract-v2.json'),'runner_sha256':sha(N/'point-rational-equality-control-v1/validation_runner_v4.py'),'hypervoxel_excluded':True,'current_main_revision':prep['parent_revision']})
def verify():
    assert all(sha(S/p)==h for p,h in base.items())
    assert all(sha(Path(prep['overlays'][p]['physical_path']) if p in prep['overlays'] else S/p)==h for p,h in effective.items())
    assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
    assert not reasons(resources())
def execute(label,args,binary=False,allow_failure=False):
    verify();name='exact-track-inline-candidate-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(V/'targets/exact-track-inline-v1'),str(T),'--bind',str(scratch),str(scratch),'--chdir',str(scratch if binary else S)]
    for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
    for dest,row in prep['overlays'].items():argv+=['--ro-bind',row['physical_path'],str(S/dest)]
    if binary:argv+=['--ro-bind',artifacts['hyperdrc-cli']['copy'],str(T/'release/hyperdrc')]
    for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
    try:r=run(name,argv+args,S,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands)
        if r['stops'] or not allow_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(R/'progress-v1.json',commands);verify()
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M)
    return out,err,r
def rows(text):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
out,err,r=execute('build',[cargo,'test','--release','--locked','-p','hyperdrc','--tests','--no-run','--message-format=json'])
for line in out.splitlines():
    if not line.startswith('{'):continue
    item=json.loads(line)
    if item.get('reason')!='compiler-artifact' or not item.get('executable'):continue
    target=item['target'];name=target['name']
    if name=='hyperdrc':
        name='hyperdrc-lib' if 'lib' in target['kind'] else ('hyperdrc-bin-tests' if item['profile']['test'] else 'hyperdrc-cli')
    path=Path(item['executable']);physical=V/path.relative_to(M);copy=A/name;assert not copy.exists();shutil.copy2(physical,copy);assert sha(physical)==sha(copy)
    artifacts[name]={'compiled_child_path':str(path),'compiled_physical_path':str(physical),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size}
assert {'hyperdrc-cli','hyperdrc-lib','kicad_native_strokes','kicad_native_aggregation','kicad_track_failures','native_aggregation','native_aggregation_memory'}<=set(artifacts)
dump(A/'executables-v1.json',artifacts)
for name,count in {'kicad_native_strokes':10,'kicad_native_aggregation':12,'kicad_track_failures':39,'native_aggregation':13,'native_aggregation_memory':1}.items():
    out,err,r=execute(name,[artifacts[name]['copy'],'--nocapture','--test-threads=1'],binary=True)
    summary=rows(out);assert summary==[('ok',str(count),'0','0','0','0')],summary;summaries[name]=summary
dump(R/'focused-result-v1.json',{'passed':True,'tests':75,'summaries':summaries,'commands':commands,'importer_admitted':False})
gates={}
for label,test in [('full-board','kicad_board_completes_smoke_check_suite'),('copper-neck','min_copper_neck_width_completes_on_copper_layers'),('gerber','gerber_package_completes_smoke_check_suite')]:
    out,err,r=execute(label,[artifacts['hyperdrc-lib']['copy'],'zz_complex_project_performance_tests::'+test,'--exact','--nocapture','--test-threads=1'],binary=True,allow_failure=True)
    assert 'skipping complex project fixture' not in out+err
    summary=rows(out);assert len(summary)==1 and sum(map(int,summary[0][1:3]))==1 and summary[0][3:5]==('0','0'),summary
    gates[label]={'summary':summary,'exit_code':r['exit_code'],'process_elapsed_seconds':r['elapsed_seconds'],'assertion_diagnostic_lines':[line for line in (out+err).splitlines() if any(term in line.lower() for term in ['took','worker','seconds','budget','expected'])]}
    dump(R/'gates-progress-v1.json',gates)
verify();dump(R/'result-v1.json',{'focused_tests':75,'focused_passed':True,'gates':gates,'gates_passed':all(v['exit_code']==0 for v in gates.values()),'commands':commands,'source_unchanged':True,'current_main_revision':prep['parent_revision'],'exact_importer_admitted':False,'full_plan_complete':False})
print(json.dumps({'focused_tests_passed':75,'gates':gates,'importer_admitted':False}),flush=True)
