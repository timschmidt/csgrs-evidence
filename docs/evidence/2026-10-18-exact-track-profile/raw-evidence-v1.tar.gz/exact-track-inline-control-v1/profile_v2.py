"""Continue the unchanged profile with explicitly userspace-only callchains."""
import gzip,json,os,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;S=N/'point-rational-native-facts-source-v1'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
T=M/'targets/exact-track-inline-profile-v1';A=V/'exact-track-inline-profile-artifacts-v2';R=N/'exact-track-inline-profile-v2'
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha,reasons,resources
assert not R.exists() and not A.exists();R.mkdir();A.mkdir()
prep=json.loads((W/'preparation-v1.json').read_text());base=json.loads(gzip.decompress((N/'point-rational-native-facts-source-v1.json.gz').read_bytes()));effective=json.loads(gzip.decompress((W/'effective-source-pins-v1.json.gz').read_bytes()))
artifact=json.loads((V/'exact-track-inline-profile-artifacts-v1/executable-v1.json').read_text());original=json.loads((N/'exact-track-inline-profile-v1/protocol-v1.json').read_text());commands={};os.environ['DEBUGINFOD_URLS']=''
assert json.loads((N/'logs/exact-track-inline-profile-user-probe-v1/result.json').read_text())['exit_code']==0
assert json.loads((N/'logs/exact-track-inline-profile-record-v1/result.json').read_text())['exit_code']==255
protocol=dict(original);protocol.update({'helper_sha256':sha(Path(__file__)),'original_profile_protocol_sha256':sha(N/'exact-track-inline-profile-v1/protocol-v1.json'),'build_reused_byte_identical':True,'sampling_change':'--user-callchains explicitly excludes kernel callchains. Host security settings unchanged; counting-only preflight was insufficient.','failed_record_sha256':sha(N/'logs/exact-track-inline-profile-record-v1/result.json'),'successful_sampling_probe_sha256':sha(N/'logs/exact-track-inline-profile-user-probe-v1/result.json'),'target_read_only':True,'artifact':artifact});dump(R/'protocol-v1.json',protocol)
def verify():
    assert all(sha(S/p)==h for p,h in base.items())
    assert all(sha(Path(prep['overlays'][p]['physical_path']) if p in prep['overlays'] else S/p)==h for p,h in effective.items())
    assert sha(artifact['compiled_physical_path'])==sha(artifact['copy'])==artifact['sha256']
    assert not reasons(resources())
def execute(label,args,allow_test_failure=False):
    verify();name='exact-track-inline-profile2-'+label+'-v1';scratch=N/'scratch'/name
    argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(A),str(A),'--bind',str(scratch),str(scratch),'--chdir',str(scratch),'--setenv','TMPDIR',str(scratch),'--setenv','DEBUGINFOD_URLS','']
    for dest,row in prep['overlays'].items():argv+=['--ro-bind',row['physical_path'],str(S/dest)]
    try:r=run(name,argv+args,S,target=T)
    except RuntimeError:
        r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands)
        if r['stops'] or not allow_test_failure or r['exit_code']!=101:raise
    commands[label]=r;dump(R/'progress-v1.json',commands);verify()
    out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text()
    return out,err,r
profile=A/'perf.data'
out,err,r=execute('record',['/usr/bin/perf','record','--user-callchains','-F','3','-e','cycles:u','--call-graph','fp','--compression-level=5','--no-buildid-cache','-o',str(profile),'--',artifact['copy'],'zz_complex_project_performance_tests::kicad_board_completes_smoke_check_suite','--exact','--nocapture','--test-threads=1'],allow_test_failure=True)
combined=out+err;assert profile.is_file() and profile.stat().st_size>0
assert 'skipping complex project fixture' not in combined
assert combined.count('hyperdrc: finished emit report')==2
assert len(re.findall(r'^test result: (?:ok|FAILED)\. [01] passed; [01] failed; 0 ignored; 0 measured;',out,re.M))==1
record_result=r;worker=re.search(r'took ([0-9.]+)s of worker time',combined)
for label,args in [
 ('self',['report','--stdio','--stdio-color','never','--no-inline','--no-children','--call-graph','none','--sort','symbol,dso','--percent-limit','0.05']),
 ('inclusive',['report','--stdio','--stdio-color','never','--no-inline','--children','--call-graph','flat,1,caller','--sort','symbol,dso','--percent-limit','0.5']),
 ('header',['report','--header-only','--stdio']),
 ('stacks',['script','--show-lost-events','--no-inline','-F','comm,pid,tid,time,period,event,ip,sym,dso'])]:execute(label,['/usr/bin/perf']+args+['-i',str(profile)])
verify();dump(R/'result-v1.json',{'commands':commands,'complete_original_fixture':True,'profile_record_exit_code':record_result['exit_code'],'profile_worker_cpu_seconds':float(worker[1]) if worker else None,'artifact':artifact,'perf_data_sha256':sha(profile),'perf_data_bytes':profile.stat().st_size,'source_unchanged':True,'main_source_unchanged':True,'diagnostic_only':True,'importer_admitted':False,'full_plan_complete':False,'original_denied_attempt_preserved':True,'original_build_reused':True,'host_permissions_unchanged':True})
print(json.dumps({'profile_complete':True,'diagnostic_only':True,'importer_admitted':False}),flush=True)
