"""Test explicit userspace-only callchains without changing host permissions."""
import json,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
from validation_runner_v4 import run,dump,sha
name='exact-track-inline-profile-user-probe-v1';scratch=N/'scratch'/name
argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(scratch),str(scratch),'--chdir',str(scratch),'/usr/bin/perf','record','-vv','--user-callchains','-F','3','-e','cycles:u','--call-graph','fp','--compression-level=5','--no-buildid-cache','-o',str(scratch/'perf.data'),'--','/usr/bin/python3','-c','import time\nstart=time.monotonic(); value=0\nwhile time.monotonic()-start<1: value+=1\nprint(value)']
p=W/'sampling-probe-contract-v1.json';assert not p.exists();dump(p,{'helper_sha256':sha(Path(__file__)),'scope':__doc__,'failed_record_result_sha256':sha(N/'logs/exact-track-inline-profile-record-v1/result.json'),'purpose':'Check explicit user callchains with the same event, rate and stack method. Kernel/system permissions remain unchanged. One-second synthetic permission check is not a geometry measurement.','argv':argv})
run(name,argv,W,wall_seconds=60)
