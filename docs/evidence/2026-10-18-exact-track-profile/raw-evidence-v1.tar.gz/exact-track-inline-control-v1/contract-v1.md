# Exact-track ingress with admitted scalar equality facts

Target revision: 540074a8c05ccc676d7c70b8f0093f98804b81d9. E69 admits shared exact
equality facts and the Point2 consumer. It does not admit exact-track ingress.
Reproduce the archived source-fidelity findings on this revision before
evaluating the unchanged one-file exact importer.

Owning layers: HyperDRC's KiCad boundary must preserve exact source values,
round-capped straight-stroke meaning, typed failures and strict receipts.
Hypercurve owns native analytic single-line stroke construction; reuse that
implementation rather than add formulas in the adapter. P1, P3-P6, P8-P9,
P12-P20, P25-P27 and P35-P39 apply.

Domain: valid straight segments with exact decimal/rational endpoints and
nonnegative width, including coincident endpoints, zero width, ordinary and
irrational directions, subrange/superrange coordinates and widths. Preserve
all malformed-source, exhausted-budget and construction-failure categories.
The existing canonical empty/complete-subtraction composition checks remain.
Round caps and exact source preservation are a declared semantic correction;
they are not a performance-only claim or permission to silently change reports.

First compile the unchanged archived ten stroke and twelve aggregation tests
against the current admitted native libraries, and rerun the existing 39
source-failure tests. Verify the source, library and toolchain hashes against
E69 and keep all failing outputs. Then evaluate exactly E66's track importer
and its reviewed 39-test migration, with the unchanged archived tests and
current flat aggregation. All six extreme fixtures retain exact area, bounds,
membership, strict receipt and handoff assertions; they are not removed or
reduced. No cache proposal is included.

Use read-only frozen source plus explicitly pinned overlays to represent the
current revision and the four importer/test differences. Verify all effective
source and fixture hashes against the current main checkout before compilation.
Use a new target and artifact directories on Disk B; all E69 roots, targets and
helpers are closed and remain unchanged. This avoids an unnecessary source
copy under the nearly exhausted root-volume allowance.

Run the unchanged 75 focused tests and the original full-board 120-second
worker-CPU, copper-neck 60-second body-wall and Gerber gates. A gate failure
keeps the importer unadmitted and directs further diagnosis at its owning
layer. A passing narrow run alone is insufficient for admission: broader
consumer checks, output migration evidence and final integration checks still
apply. Preserve every original workload, output and unfavorable measurement.

The original cumulative baselines remain: 16 GiB root and approved 72 GiB
Disk B retention; 8 GiB child address space, two build jobs, 1800-second
commands, 60-second focused probes, 512 MiB filesystem reserve, 2 GiB host
memory reserve and 64 MiB total command logs. These are external containment,
not an internal execution or heap bound. Hypervoxel is excluded. No push,
public-distribution completion or full-plan completion is claimed.
