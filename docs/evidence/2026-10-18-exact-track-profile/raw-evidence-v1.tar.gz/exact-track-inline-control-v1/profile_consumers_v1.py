"""Find recovered non-scalar consumers and overlaps of normal-form profile cost."""
import collections,hashlib,json,re
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;R=N/'exact-track-inline-profile-v2'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
observed=json.loads((R/'observations-v1.json').read_text());p=N/'logs/exact-track-inline-profile2-stacks-v1/stdout';assert sha(p)==observed['stacks_sha256']
non_scalar=re.compile(r'^<?&?(?:hypercurve|hyperlimit|hypersolve|hyperlattice|hyperdrc|hypermesh|hyperpath|hypertri|csgrs)::')
needles={'aggregation':'aggregate_native_regions','subcurve':'::subcurve','point_equality':'<hypercurve::point::Point2 as core::cmp::PartialEq>::eq','enclosure':'certified_f64_enclosure','boundary_side_ray':'loop_windings_from_boundary_side_ray'}
consumers=collections.Counter();overlaps=collections.Counter();total=0;selected=0
blocks=p.read_text().strip().split('\n\n')
for block in blocks:
    lines=block.splitlines();m=re.match(r'^\S+\s+\d+/\d+\s+([0-9.]+):\s+(\d+) cycles:u:',lines[0]);assert m;period=int(m[2]);total+=period
    frames=[]
    for line in lines[1:]:
        m=re.match(r'\s+[a-f0-9]+ (.*?) \((.*)\)$',line);assert m;frames.append(m[1])
    indices=[i for i,f in enumerate(frames) if 'pi_laurent_polynomial' in f]
    if not indices:continue
    selected+=period;caller=next((f for f in frames[max(indices)+1:] if non_scalar.match(f)),'<no recovered non-scalar project ancestor>');consumers[caller]+=period
    for name,needle in needles.items():
        if any(needle in f for f in frames):overlaps[name]+=period
assert total==observed['total_sample_period'] and len(blocks)==observed['samples']
r={'helper_sha256':sha(Path(__file__)),'observations_sha256':sha(R/'observations-v1.json'),'stacks_sha256':sha(p),'samples':len(blocks),'total_period':total,'normal_form_period':selected,'normal_form_total_percent':100*selected/total,'nearest_recovered_non_scalar_callers':[{'symbol':s,'period':v,'total_profile_percent':100*v/total,'normal_form_percent':100*v/selected} for s,v in consumers.most_common()],'normal_form_overlaps':{k:{'needle':v,'period':overlaps[k],'total_profile_percent':100*overlaps[k]/total} for k,v in needles.items()},'limits':'Inclusive sampled cycle periods; overlap categories are not additive. Recovered ancestors omit inline frames. A diagnostic attribution, not a call/allocation count or speedup prediction.'}
p=R/'consumers-v1.json';assert not p.exists();p.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
for row in r['nearest_recovered_non_scalar_callers'][:15]:print(round(row['total_profile_percent'],3),row['symbol'][:250])
print(json.dumps(r['normal_form_overlaps']))
