"""Stage only the admitted patch and verify every staged blob before commit."""
import hashlib,json,os,re,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2';E=O/'docs/evidence/2026-10-18-sign-cache-publication';BASE='79a67b140eac2251584c7ec6fe0205761dab892e'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def span(raw):
 start=re.search(rb'"current_work"\s*:\s*',raw).end();_,count=json.JSONDecoder().raw_decode(raw[start:].decode());return start,start+len(raw[start:].decode()[:count].encode())
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('diff','--cached','--name-only')
c=json.loads((E/'checkpoint-v1.json').read_text());assert c['exact_sign_publication_admitted'] and c['new_implementation_admission'] and c['main_runtime_tests_rerun'] and not c['full_plan_complete']
live=c['restored_native_sha256']|c['inherited_implementation_sha256']|c['implementation_sha256'];assert all(sha(O/p)==h for p,h in live.items())
assert all(sha(O/p)==h for p,h in c['evidence_files_sha256'].items())
assert sha(O/'docs/properties-status.json')==c['ledger_after_sha256']
raw=(O/'docs/properties-status.json').read_bytes();reference=git('show','9025de62:docs/properties-status.json');s,e=span(raw);rs,re_=span(reference);assert (raw[:s],raw[e:])==(reference[:rs],reference[re_:])
unchanged='docs/evidence/2026-10-14-scalar-integration/checkpoint_v4.py';assert sha(O/unchanged)=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
evidence=set(c['evidence_files_sha256'])|{str((E/'checkpoint-v1.json').relative_to(O))};assert {str(p.relative_to(O)) for p in E.rglob('*') if p.is_file()}==evidence
paths=sorted(set(c['implementation_sha256'])|evidence|{'docs/properties-status.json'});expected={p:sha(O/p) for p in paths}
assert set(git('diff','--name-only').decode().splitlines())<=set(paths)
subprocess.run(GIT+['add','--']+paths,cwd=O,check=True)
out=N/'sign-cache-final-stage-whitespace-v1.stdout';err=N/'sign-cache-final-stage-whitespace-v1.stderr';assert not out.exists() and not err.exists()
with out.open('wb') as stdout,err.open('wb') as stderr:r=subprocess.run(GIT+['diff','--cached','--check'],cwd=O,stdout=stdout,stderr=stderr)
assert r.returncode==0
assert set(git('diff','--cached','--name-only').decode().splitlines())==set(paths)
staged={p:hashlib.sha256(git('show',':'+p)).hexdigest() for p in paths};assert staged==expected and all(sha(O/p)==h for p,h in expected.items())
p=N/'sign-cache-final-stage-verification-v1.json';assert not p.exists();p.write_text(json.dumps({'parent_revision':BASE,'helper_sha256':sha(Path(__file__)),'staged_blobs_sha256':staged,'verified_blob_count':len(staged),'checkpoint_sha256':sha(E/'checkpoint-v1.json'),'only_current_work_ledger_value_changed':True,'whitespace_exit_code':0,'whitespace_outputs_sha256':{str(out):sha(out),str(err):sha(err)},'preexisting_untracked_unchanged':unchanged,'commit_not_executed_by_this_helper':True},indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified_staged_blobs':len(staged),'parent':BASE,'receipt':str(p)}),flush=True)
