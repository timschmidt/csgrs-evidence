"""Verify the separate commit contains exactly the previously reviewed blobs."""
import hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
O=Path('/home/tim/Documents/GitHub/workspace/csgrs');N=O.parent/'csgrs-properties-validation-2026-10-17-v2'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*a):return subprocess.check_output(GIT+list(a),cwd=O)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((N/'sign-cache-final-stage-verification-v1.json').read_text());head=git('rev-parse','HEAD').decode().strip();assert head!=r['parent_revision']
assert git('rev-parse','HEAD^').decode().strip()==r['parent_revision']
assert set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())==set(r['staged_blobs_sha256'])
committed={p:hashlib.sha256(git('show','HEAD:'+p)).hexdigest() for p in r['staged_blobs_sha256']};assert committed==r['staged_blobs_sha256']
assert all(sha(O/p)==h for p,h in committed.items());assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
assert sha(O/r['preexisting_untracked_unchanged'])=='08f03034be0ecf4141edae2ee9581b08cdbb05bbfc41a8da2eb478ad5340d4ef'
assert git('ls-files','--others','--exclude-standard').decode().splitlines()==[r['preexisting_untracked_unchanged']]
p=N/'sign-cache-final-commit-verification-v1.json';assert not p.exists();p.write_text(json.dumps({'commit':head,'parent':r['parent_revision'],'helper_sha256':sha(Path(__file__)),'verified_committed_blobs_sha256':committed,'verified_blob_count':len(committed),'tracked_worktree_clean':True,'preexisting_untracked_unchanged':r['preexisting_untracked_unchanged'],'full_plan_complete':False,'push_performed':False},indent=2,sort_keys=True)+'\n');print(json.dumps({'commit':head,'verified_blobs':len(committed),'tracked_worktree_clean':True}),flush=True)
