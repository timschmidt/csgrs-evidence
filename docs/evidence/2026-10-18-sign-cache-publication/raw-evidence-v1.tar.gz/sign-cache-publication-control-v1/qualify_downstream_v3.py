"""Resume frozen circuit tests and remaining quality checks after storage stop."""
import json
from harness_v6 import Harness,W,N,O,U,cargo,sha,dump,rows
source=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text())['candidate_source']
h=Harness('downstream-v3',{'crates/hyperreal/src/computable/node/representation.rs':source},target=U/'target-qualified-v2')
prior=json.loads((N/'sign-cache-publication-downstream-v2/summaries-progress-v1.json').read_text());summaries=prior['summaries'];parents=prior['parent_summaries'];packages=prior['packages']
assert set(packages)=={'hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc'}
commands=json.loads((N/'sign-cache-publication-downstream-v2/progress-v1.json').read_text());assert all(r['exit_code']==0 and not r['stops'] for r in commands.values())
manifest=U/'downstream-v2-artifacts/executables-v1.json';items=json.loads(manifest.read_text());h.artifacts={k:v for k,v in items.items() if k.startswith('hypercircuit-build--')};assert len(h.artifacts)==47
h.runtime_bindings={v['compiled_path']:v['copy'] for v in h.artifacts.values() if not v['profile']['test']}
dump(h.A/'executables-v1.json',h.artifacts);h.verify()
dump(h.R/'continuation-v1.json',{'prior_progress_sha256':sha(N/'sign-cache-publication-downstream-v2/progress-v1.json'),'prior_summaries_sha256':sha(N/'sign-cache-publication-downstream-v2/summaries-progress-v1.json'),'prior_completed_commands':commands,'earlier_continuation_sha256':sha(N/'sign-cache-publication-downstream-v2/continuation-v1.json'),'storage_stop_sha256':sha(W/'storage-stop-v2-review.json'),'storage_migration_sha256':sha(W/'storage-migration-v2.md'),'frozen_manifest_sha256':sha(manifest),'source_overlays_unchanged':True,'compilation_rerun':False})
for ordinal,key in enumerate(sorted(h.artifacts)):
 if not h.artifacts[key]['profile']['test']:continue
 label='hypercircuit-test-'+str(ordinal)+'-'+h.artifacts[key]['target']['name'];summary,out,err,_=h.test(label,key)
 assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary),summary
 assert 'skipping complex project fixture' not in out+err
 summaries[label]=summary;parents[label]=summary[-1]
out,_,_=h.execute('hypercircuit-doctests',[cargo,'test','--release','--locked','-p','hypercircuit','--all-features','--doc','--','--test-threads=1']);summary=rows(out);assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary)
summaries['hypercircuit-doctests']=summary;packages['hypercircuit']={'test_binaries':46,'parent_test_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith('hypercircuit-test-')),'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith('hypercircuit-test-')),'doctests_passed':sum(int(r[1]) for r in summary)}
dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages})
for package in ['hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc','hypercircuit']:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
h.verify();dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,'commands':h.commands,'prior_completed_commands':commands,'continuation_sha256':sha(h.R/'continuation-v1.json'),'original_native_gates_passed_in_downstream_v2':True,'all_original_workload_limits_unchanged':True,'tmp_storage_allowance_gib':12,'storage_exhaustion_history_preserved':True,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'downstream_qualification_passed':True,'packages':packages}),flush=True)
