"""Apply exactly the fully qualified isolated candidate to main."""
import gzip,hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
from validation_runner_v4_local import sha,dump,resources,reasons
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0'];os.environ['GIT_OPTIONAL_LOCKS']='0'
def git(*args):return subprocess.check_output(GIT+list(args),cwd=O)
assert not reasons(resources())
parent=git('rev-parse','HEAD').decode().strip();assert parent=='79a67b140eac2251584c7ec6fe0205761dab892e'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
checks={}
for name in ['scalar-v2','downstream-v3','msrv-v3']:
 p=N/('sign-cache-publication-'+name)/'result-v1.json';r=json.loads(p.read_text());assert r['passed'];checks[name]=sha(p)
p=N/'sign-cache-publication-reports-v3/result-v1.json';r=json.loads(p.read_text());assert r['all_report_bytes_equal'] and r['all_parsed_reports_equal'];checks['reports-v3']=sha(p)
assert json.loads((W/'cost-result-v1.json').read_text())['exact_csv_identity']
old=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));assert all(sha(O/p)==h for p,h in old.items())
representation=W/'candidate-formatted-representation-v1.rs'
assert sha(representation)==json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text())['candidate_source_sha256']
sources={'crates/hyperreal/src/computable/node/representation.rs':representation,'crates/hyperreal/src/computable/node.rs':W/'baseline-node.rs','crates/hyperreal/src/computable/node/exact_sign_cache_tests.rs':W/'baseline-node/exact_sign_cache_tests.rs'}
assert not (O/'crates/hyperreal/src/computable/node/exact_sign_cache_tests.rs').exists()
assert sha(sources['crates/hyperreal/src/computable/node/exact_sign_cache_tests.rs'])==sha(O/'docs/evidence/2026-10-18-sign-cache-local/exact_sign_cache_tests.rs')
assert sha(O/'docs/properties-status.json')=='09d9446104ac6b8e64a341c0d1b31dec54bcf836b246b13434ec154f53915eb9'
changes={p:{'before_sha256':old.get(p),'after_sha256':sha(src),'qualified_source':str(src)} for p,src in sources.items()}
assert not (W/'main-source-integration-v3.json').exists() and not (W/'main-source-pins-v3.json.gz').exists()
for p,src in sources.items():(O/p).write_bytes(src.read_bytes())
new=dict(old);new.update({p:row['after_sha256'] for p,row in changes.items()})
assert {p for p in new if new[p]!=old.get(p)}==set(sources)
assert all(sha(O/p)==h for p,h in new.items())
for p in (W/'baseline-node').rglob('*'):
 if p.is_file():
  dest=O/'crates/hyperreal/src/computable/node'/p.relative_to(W/'baseline-node')
  expected=representation if dest.name=='representation.rs' else p
  assert sha(dest)==sha(expected),dest
(W/'main-source-pins-v3.json.gz').write_bytes(gzip.compress(json.dumps(new,sort_keys=True).encode(),mtime=0))
dump(W/'main-source-integration-v3.json',{'parent_revision':parent,'helper_sha256':sha(Path(__file__)),'changes':changes,'qualification_results_sha256':checks,'allocation_result_sha256':sha(W/'cost-result-v1.json'),'original_pins_sha256':sha(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'final_pins_sha256':sha(W/'main-source-pins-v3.json.gz'),'exactly_three_source_paths_changed':True,'other_source_inputs_unchanged':True,'qualified_overlay_bytes_equal_actual_main':True,'actual_main_validation_pending':True,'runtime_admitted':False,'full_plan_complete':False})
assert not reasons(resources());print(json.dumps({'applied_paths':list(changes),'actual_main_checks_pending':True}),flush=True)
