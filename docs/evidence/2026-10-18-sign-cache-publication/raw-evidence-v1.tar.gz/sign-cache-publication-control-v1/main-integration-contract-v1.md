# Exact-sign publication main integration contract

Integrate only after the isolated local tests, complete affected downstream
suites, original native resource gates, full report replay and compiler-floor
checks pass. Apply exactly the qualified representation.rs, the original
node.rs facade with the new test include, and the unchanged four regression
tests. Preserve all other production and existing test bytes.

The final actual-main checks must omit every scalar source overlay. Verify the
three integrated files against the qualified candidate and all other pinned
source inputs against the original inventory before and after every command.
The original pre-fix inventory remains immutable; create a new final inventory
containing exactly the three intended differences. Preserve every previously
executed binary copy. The reusable candidate target remains open.

Rebuild the actual-main scalar tests, verify their compilation binding and run
the default/all-feature configurations and doctests. Run workspace formatting,
explicit included-source formatting, affected strict Clippy and documentation.
Rebuild affected downstream test targets against actual main, freeze binaries,
and replay the completed downstream suites, including the original native
CPU/wall gates, under unchanged workload limits. Record actual execution and
any reuse rather than claiming tests ran from evidence updates alone.

The broad isolated run already compiled exactly the intended source bytes; the
main checks verify integration and downstream behavior after the final source
edit. A Cargo cache hit is acceptable only with verified identical inputs; no
older-mtime overlay reversal is allowed. Record compilation freshness and
binary hashes explicitly. Keep any failed check or containment interruption.

Use the explicit 8 GiB temporary-storage migration, its original free-space
baseline, the approved 72 GiB Disk B storage allowance, and all unchanged time,
child-memory, job, root and log limits. No Hypervoxel, push, package release,
whole-cache concurrency proof or full-plan completion is claimed.
