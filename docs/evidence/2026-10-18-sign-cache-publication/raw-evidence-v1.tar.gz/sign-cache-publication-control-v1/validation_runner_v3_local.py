"""Add a small /tmp containment budget without changing inherited limits."""
import json,shutil,sys
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent
sys.path.insert(0,str(N/'control'));sys.path.insert(0,str(N/'point-rational-equality-control-v1'))
import validation_runner_v4 as inherited
import validation_runner_v3 as base
_contract=json.loads((W/'tmp-contract-v3.json').read_text())
_resources=base.resources;_reasons=base.reasons
def resources():
 value=_resources();value['tmp_free_bytes']=shutil.disk_usage(_contract['path']).free;return value
def reasons(value):
 failures=_reasons(value)
 if _contract['initial_free_bytes']-value['tmp_free_bytes']>_contract['net_consumption_limit_bytes']:failures.append('tmp_net_consumption_12_gib')
 if value['tmp_free_bytes']<512*1024**2:failures.append('tmp_free_bytes')
 return failures
base.resources=resources;base.reasons=reasons
from validation_runner_v3 import run,dump,sha
