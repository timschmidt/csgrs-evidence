"""Complete affected exact-kernel and modeling tests with the current importer."""
import json
from harness_v5 import Harness,W,N,O,U,cargo,sha,dump,rows
assert json.loads((N/'sign-cache-publication-scalar-v2/result-v1.json').read_text())['passed']
assert (W/'cost-result-v1.json').exists(), 'finish isolated allocation measurements first'
focused=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text());source=focused['candidate_source'];assert sha(source)==focused['candidate_source_sha256']
target=U/'target-qualified-v2';assert target.exists()
h=Harness('downstream-v2',{'crates/hyperreal/src/computable/node/representation.rs':source},target=target);prior=json.loads((N/'sign-cache-publication-downstream-v1/summaries-progress-v1.json').read_text());summaries=prior['summaries'];parent_summaries=prior['parent_summaries'];packages=prior['packages']
assert set(packages)=={'hyperlimit','hypercurve','hypermesh'}
prior_commands=json.loads((N/'sign-cache-publication-downstream-v1/progress-v1.json').read_text())
interrupted=prior_commands.pop('csgrs-build');assert interrupted['stops']==['tmp_net_consumption_5_gib'] and interrupted['exit_code']==-15
assert all(r['exit_code']==0 and not r['stops'] for r in prior_commands.values())
dump(h.R/'continuation-v1.json',{'prior_results_sha256':sha(N/'sign-cache-publication-downstream-v1/summaries-progress-v1.json'),'prior_commands_sha256':sha(N/'sign-cache-publication-downstream-v1/progress-v1.json'),'completed_commands':prior_commands,'interrupted_build':interrupted,'storage_migration_sha256':sha(W/'storage-migration-v1.md'),'source_overlays_unchanged':True})
for package,flags in [('csgrs',[]),('hyperdrc',[]),('hypercircuit',['--all-features'])]:
 keys=h.build(package+'-build',['test','--release','--locked','-p',package,'--tests']+flags)
 h.runtime_bindings={item['compiled_path']:item['copy'] for key in keys if not (item:=h.artifacts[key])['profile']['test']}
 dump(h.R/(package+'-runtime-bindings-v1.json'),h.runtime_bindings)
 for ordinal,key in enumerate(keys):
  item=h.artifacts[key]
  if not item['profile']['test']:continue
  label=package+'-test-'+str(ordinal)+'-'+item['target']['name']
  summary,out,err,_=h.test(label,key);assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary),summary;summaries[label]=summary;parent_summaries[label]=summary[-1]
  assert 'skipping complex project fixture' not in out+err
 out,_,_=h.execute(package+'-doctests',[cargo,'test','--release','--locked','-p',package,'--doc']+flags+['--','--test-threads=1']);summary=rows(out);assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary);summaries[package+'-doctests']=summary
 packages[package]={'test_binaries':sum(h.artifacts[k]['profile']['test'] for k in keys),'parent_test_passed':sum(int(row[1]) for key,row in parent_summaries.items() if key.startswith(package+'-test-')),'parent_ignored':sum(int(row[3]) for key,row in parent_summaries.items() if key.startswith(package+'-test-')),'doctests_passed':sum(int(row[1]) for row in summary)}
 dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parent_summaries,'packages':packages})
# Quality checks cover every affected local layer in its full feature graph.
for package in ['hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc','hypercircuit']:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
h.verify();dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parent_summaries,'child_results_not_counted_as_unique_parent_tests':True,'commands':h.commands,'artifacts_sha256':{k:v['sha256'] for k,v in h.artifacts.items()},'current_production_importer_unchanged':True,'rejected_circle_envelope_absent':True,'all_original_workload_limits_unchanged':True,'tmp_storage_allowance_gib':8,'original_5_gib_build_exhausted':True,'prior_completed_commands':prior_commands,'interrupted_build':interrupted,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'downstream_qualification_passed':True,'packages':packages,'runtime_admitted':False}),flush=True)
