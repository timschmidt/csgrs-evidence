"""Final validation log retention within unchanged root-volume containment."""
import json
from pathlib import Path
import validation_runner_v3_local as retained
import validation_runner_v3 as base
W=Path(__file__).resolve().parent
contract=json.loads((W/'log-contract-v1.json').read_text())
assert contract['old_cumulative_limit_bytes']==64*1024**2
assert contract['new_cumulative_limit_bytes']==96*1024**2
assert contract['log_counter_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
 result=[reason for reason in previous_reasons(sample) if reason!='command_log_bytes']
 if sample['log_bytes']>contract['new_cumulative_limit_bytes']:result.append('command_log_bytes')
 return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
