# Complete native report replay after scalar publication repair

Reuse the closed current-baseline CLI from E69 and the copied current-importer
candidate CLI from this experiment's downstream qualification. Hash both actual
executables and the original fixture inventory before and after every command.
Keep the full CPArti, HVP109A and Gerber-outline fixtures and their original
check selection, minimum width, policy, output materialization and shared input
paths. Run baseline / candidate / candidate / baseline for each case.

Compare complete raw JSON bytes, parsed exact-decimal values, every coverage
entry and repeated-run determinism. Reject duplicate JSON keys and non-finite
numbers. Do not normalize the reports. Record certainty, statuses, findings and
all differences. This is output compatibility evidence, not an independent
geometric oracle or general performance claim. Existing semantic tests and the
original native CPU/wall assertions remain separate gates. Preserve the shared
scalar source binding and toolchain evidence from E69; its older source root
is not the current mutable main worktree.

The current main source must still match its pre-repair pins while this isolated
candidate runs. Hypervoxel and the rejected exact importer/circle-envelope change
are excluded. The explicit storage migration in `storage-migration-v2.md` applies: the original /tmp baseline is retained with an 12 GiB storage allowance. All original workload, time, memory, root and Disk B limits remain unchanged.
