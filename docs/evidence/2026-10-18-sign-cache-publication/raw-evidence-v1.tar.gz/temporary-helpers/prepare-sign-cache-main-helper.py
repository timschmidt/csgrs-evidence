from pathlib import Path
import ast
w=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/sign-cache-publication-control-v1')
p=w/'qualify_main_v1.py';assert not p.exists()
s='''"""Validate the final actual-main source and every affected consumer."""
import json
from harness_main_v1 import Harness,W,N,O,U,cargo,rustfmt,sha,dump,rows
assert json.loads((N/'sign-cache-publication-downstream-v2/result-v1.json').read_text())['passed']
assert json.loads((N/'sign-cache-publication-msrv-v2/result-v1.json').read_text())['passed']
reports=json.loads((N/'sign-cache-publication-reports-v2/result-v1.json').read_text())
assert reports['all_report_bytes_equal'] and reports['all_parsed_reports_equal']
integration=json.loads((W/'main-source-integration-v1.json').read_text())
assert all(sha(O/p)==row['after_sha256'] for p,row in integration['changes'].items())
h=Harness('main-v1',target=U/'target-qualified-v2')
summaries={};parents={};packages={}
def run_package(package,flags,label):
 keys=h.build(label+'-build',['test','--release','--locked','-p',package,'--tests']+flags)
 h.runtime_bindings={item['compiled_path']:item['copy'] for key in keys if not (item:=h.artifacts[key])['profile']['test']}
 dump(h.R/(label+'-runtime-bindings-v1.json'),h.runtime_bindings)
 for ordinal,key in enumerate(keys):
  if not h.artifacts[key]['profile']['test']:continue
  name=label+'-test-'+str(ordinal)+'-'+h.artifacts[key]['target']['name']
  result,out,err,_=h.test(name,key)
  assert result and all(r[0]=='ok' and r[2]=='0' for r in result),result
  assert 'skipping complex project fixture' not in out+err
  summaries[name]=result;parents[name]=result[-1]
 out,_,_=h.execute(label+'-doctests',[cargo,'test','--release','--locked','-p',package,'--doc']+flags+['--','--test-threads=1'])
 result=rows(out);assert result and all(r[0]=='ok' and r[2]=='0' for r in result)
 summaries[label+'-doctests']=result
 packages[label]={'test_binaries':sum(h.artifacts[k]['profile']['test'] for k in keys),'parent_test_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith(label+'-test-')),'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith(label+'-test-')),'doctests_passed':sum(int(r[1]) for r in result)}
 dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages})
for label,flags in [('hyperreal-default',[]),('hyperreal-all',['--all-features'])]:run_package('hyperreal',flags,label)
keys=h.build('hyperreal-debug',['test','--locked','-p','hyperreal','--lib'])
assert len(keys)==1
result,_,_,_=h.test('hyperreal-debug-library',keys[0]);assert result==[('ok','817','0','0','0','0')],result
summaries['hyperreal-debug-library']=result
for package,flags in [('hyperlimit',['--all-features']),('hypercurve',['--all-features']),('hypermesh',['--all-features']),('csgrs',[]),('hyperdrc',[]),('hypercircuit',['--all-features'])]:run_package(package,flags,package)
for package in ['hyperreal','hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc','hypercircuit']:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
h.execute('hyperreal-default-clippy',[cargo,'clippy','--release','--locked','-p','hyperreal','--all-targets','--','-D','warnings'])
h.execute('workspace-fmt',[cargo,'fmt','--all','--','--check'])
h.execute('included-fmt',[rustfmt,'--check','--edition','2024','--config','max_width=100',O/'crates/hyperreal/src/computable/node/representation.rs',O/'crates/hyperreal/src/computable/node/exact_sign_cache_tests.rs'])
h.verify()
dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,'commands':h.commands,'source_integration_sha256':sha(W/'main-source-integration-v1.json'),'source_pins_sha256':sha(W/'main-source-pins-v1.json.gz'),'actual_main_without_scalar_source_overlays':True,'copied_binaries_verified_independently':True,'identical_frozen_copy_reuse_recorded':True,'original_native_workload_limits_unchanged':True,'hypervoxel_excluded':True,'source_changes_applied_to_main':True,'runtime_admission_record_pending':True,'full_plan_complete':False})
print(json.dumps({'actual_main_passed':True,'packages':packages,'full_plan_complete':False}),flush=True)
'''
ast.parse(s);p.write_text(s);print(p)
