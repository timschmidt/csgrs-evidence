import ast,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
w=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/sign-cache-publication-control-v1');n=w.parent;sys.path.insert(0,str(w))
from validation_runner_v3_local import sha,resources,reasons
r=resources();assert not reasons(r)
def write(name,s):
 p=w/name;assert not p.exists();p.write_text(s)
 if p.suffix=='.py':ast.parse(s)
reports=json.loads((n/'sign-cache-publication-reports-v3/result-v1.json').read_text());assert reports['all_report_bytes_equal'] and reports['all_parsed_reports_equal']
folders=[]
for pattern in ['sign-cache-publication-scalar-v2-*','sign-cache-publication-downstream-v1-*','sign-cache-publication-downstream-v2-*','sign-cache-publication-downstream-v3-*']:folders.extend((n/'logs').glob(pattern))
physical={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for folder in folders for p in folder.iterdir() if p.is_file()}
estimate=sum(v['bytes'] for v in physical.values());remaining=64*1024**2-r['log_bytes'];assert estimate>remaining
contract={'kind':'validation_log_storage_migration','old_cumulative_limit_bytes':64*1024**2,'new_cumulative_limit_bytes':96*1024**2,'log_counter_reset':False,'resources_before':r,'remaining_old_log_allowance_bytes':remaining,'conservative_prior_replay_log_bytes':estimate,'estimate_scope':'Sum of retained scalar-v2 and downstream-v1/v2/v3 logs; includes interrupted build overhead, so it is an estimate rather than an exact final size.','measured_files':physical,'unchanged_root_initial_free_bytes':75664232448,'unchanged_root_net_consumption_limit_bytes':16*1024**3,'unchanged_disk_b_allowance_gib':72,'unchanged_tmp_allowance_gib':12,'unchanged_command_seconds':1800,'unchanged_child_address_space_bytes':8*1024**3,'unchanged_build_jobs':2,'fixtures_policies_and_output_materialization_unchanged':True,'full_report_replay_sha256':sha(n/'sign-cache-publication-reports-v3/result-v1.json'),'reason':'Retain final actual-main validation logs without removing prior raw evidence. This agent-selected subordinate storage limit is raised before the next run; the original root-volume containment remains enforced.'}
write('log-contract-v1.json',json.dumps(contract,indent=2,sort_keys=True)+'\n')
write('log-storage-migration-v1.md',f'''# Final-validation log storage

All twelve complete report replays passed byte and parsed-value comparison.
Retained logs currently occupy {r['log_bytes']:,} bytes. The original 64 MiB
allowance leaves {remaining:,} bytes, while the corresponding completed scalar
and downstream log sets occupy {estimate:,} bytes. The latter is a conservative
planning estimate, including interrupted-build overhead, not a measured final
integration size. The file-level measurements and hashes are in the contract.

Raise only the cumulative validation-log storage allowance to 96 MiB before the
final run. The counter is not reset and every prior raw log remains retained.
This subordinate storage limit was agent-selected; the original root-volume
baseline and 16 GiB containment remain enforced. The approved 72 GiB Disk B
limit and recorded 12 GiB /tmp allowance also remain fixed. Workloads, fixtures,
resolution, policies, materialized outputs, time, child memory and job limits
are unchanged. No successful operation under a smaller log budget is claimed.

The final checks use new helper versions that record this storage migration.
This changes evidence retention only, not the mathematical or resource contract
of the geometry workloads. No historical log is compressed, moved or rewritten.
''')
s='''"""Final validation log retention within unchanged root-volume containment."""
import json
from pathlib import Path
import validation_runner_v3_local as retained
import validation_runner_v3 as base
W=Path(__file__).resolve().parent
contract=json.loads((W/'log-contract-v1.json').read_text())
assert contract['old_cumulative_limit_bytes']==64*1024**2
assert contract['new_cumulative_limit_bytes']==96*1024**2
assert contract['log_counter_reset'] is False
previous_reasons=base.reasons
def reasons(sample):
 result=[reason for reason in previous_reasons(sample) if reason!='command_log_bytes']
 if sample['log_bytes']>contract['new_cumulative_limit_bytes']:result.append('command_log_bytes')
 return result
base.reasons=reasons
from validation_runner_v3 import run,dump,sha,resources
'''
write('validation_runner_v4_local.py',s)
s=(w/'main-integration-contract-v2.md').read_text().replace('and log limits.','limits, and the explicitly migrated 96 MiB cumulative log allowance in\n`log-storage-migration-v1.md`.');assert '96 MiB' in s;write('main-integration-contract-v3.md',s)
s=(w/'harness_main_v2.py').read_text().replace('from validation_runner_v3_local import','from validation_runner_v4_local import').replace('main-source-pins-v2.json.gz','main-source-pins-v3.json.gz').replace('main-integration-contract-v2.md','main-integration-contract-v3.md').replace("'overlay_sha256':self.overlay_pins","'preserved_pre_fix_control_sources_sha256':self.overlay_pins,'log_contract_sha256':sha(W/'log-contract-v1.json')");write('harness_main_v3.py',s)
s=(w/'qualify_main_v2.py').read_text().replace('harness_main_v2','harness_main_v3').replace('main-source-integration-v2.json','main-source-integration-v3.json').replace('main-source-pins-v2.json.gz','main-source-pins-v3.json.gz').replace("Harness('main-v2'","Harness('main-v3'");write('qualify_main_v3.py',s)
s=(w/'integrate_main_v2.py').read_text().replace('from validation_runner_v3_local import','from validation_runner_v4_local import').replace('main-source-integration-v2.json','main-source-integration-v3.json').replace('main-source-pins-v2.json.gz','main-source-pins-v3.json.gz');write('integrate_main_v3.py',s)
print(json.dumps({'log_bytes':r['log_bytes'],'old_remaining':remaining,'prior_log_estimate':estimate,'new_log_limit':96*1024**2,'production_source_changed':False}))
