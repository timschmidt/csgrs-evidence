import ast
from pathlib import Path
w=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/sign-cache-publication-control-v1')
def write(name,s):
 p=w/name;assert not p.exists();p.write_text(s)
 if p.suffix=='.py':ast.parse(s)
s=(w/'qualify_msrv_v2.py').read_text().replace('harness_v5','harness_v6').replace('downstream-v2/result','downstream-v3/result').replace('target-msrv-v2','target-msrv-v3').replace("Harness('msrv-v2'","Harness('msrv-v3'");write('qualify_msrv_v3.py',s)
s=(w/'report-contract-v2.md').read_text().replace('storage-migration-v1.md','storage-migration-v2.md').replace('8 GiB storage','12 GiB storage');write('report-contract-v3.md',s)
s=(w/'qualify_reports_v2.py').read_text().replace('harness_v5','harness_v6').replace('downstream-v2/result','downstream-v3/result').replace('sign-cache-publication-reports-v2','sign-cache-publication-reports-v3').replace('report-contract-v2.md','report-contract-v3.md').replace("+mode+'-v2'","+mode+'-v3'");write('qualify_reports_v3.py',s)
s=(w/'main-integration-contract-v1.md').read_text().replace('8 GiB temporary-storage migration','12 GiB temporary-storage migration in `storage-migration-v2.md`');write('main-integration-contract-v2.md',s)
s=(w/'harness_v6.py').read_text().replace('Pinned scalar investigation with frozen executable copies for every build.','Actual-main source integration with byte-verified frozen binaries.')
s=s.replace("self.target=Path(target) if target is not None else T;assert self.target.is_dir()","assert not overrides, 'final integration cannot substitute source overlays'\n  self.target=Path(target) if target is not None else T;assert self.target.is_dir()")
s=s.replace("N/'point-rational-main-integration-v2/source-pins-v1.json.gz'","W/'main-source-pins-v2.json.gz'")
old="""  for kind in ['directory_overlay','file_overlay']:
   row=self.prep[kind];argv+=['--ro-bind',row['source'],row['destination']]
  for dest,p in self.overrides.items():argv+=['--ro-bind',str(p),str(O/dest)]
"""
assert old in s;s=s.replace(old,'').replace("'production_source_changed':False","'production_source_changed':True,'scalar_source_overlays_used':False,'main_integration_contract_sha256':sha(W/'main-integration-contract-v2.md')");write('harness_main_v2.py',s)
s=(w/'qualify_main_v1.py').read_text().replace('harness_main_v1','harness_main_v2').replace('downstream-v2/result','downstream-v3/result').replace('msrv-v2/result','msrv-v3/result').replace('reports-v2/result','reports-v3/result').replace('main-source-integration-v1.json','main-source-integration-v2.json').replace('main-source-pins-v1.json.gz','main-source-pins-v2.json.gz').replace("Harness('main-v1'","Harness('main-v2'");write('qualify_main_v2.py',s)
s=(w/'integrate_main_v1.py').read_text().replace('from validation_runner_v2 import','from validation_runner_v3_local import').replace("['scalar-v2','downstream-v2','msrv-v2']","['scalar-v2','downstream-v3','msrv-v3']").replace('reports-v2','reports-v3').replace('main-source-integration-v1.json','main-source-integration-v2.json').replace('main-source-pins-v1.json.gz','main-source-pins-v2.json.gz');write('integrate_main_v2.py',s)
print('Prepared storage-migrated compiler-floor, report replay, and actual-main checks; none executed yet.')
