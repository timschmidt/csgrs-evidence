import ast,hashlib,json,sys
sys.dont_write_bytecode=True
from pathlib import Path
w=Path('/home/tim/Documents/GitHub/workspace/csgrs-properties-validation-2026-10-17-v2/sign-cache-publication-control-v1');n=w.parent;u=Path('/tmp/csgrs-sign-cache-validation-20261018-v1');sys.path.insert(0,str(w))
from validation_runner_v2 import sha,resources,reasons
r=resources();assert reasons(r)==['tmp_net_consumption_8_gib']
def write(name,s):
 p=w/name;assert not p.exists();p.write_text(s)
def dump(name,v):write(name,json.dumps(v,indent=2,sort_keys=True)+'\n')
manifest=u/'downstream-v2-artifacts/executables-v1.json';items=json.loads(manifest.read_text());circuit={k:v for k,v in items.items() if k.startswith('hypercircuit-build--')};assert len(circuit)==47
assert all(sha(v['copy'])==v['sha256'] for v in items.values())
last=n/'logs/sign-cache-publication-downstream-v2-hypercircuit-build/result.json';build=json.loads(last.read_text());assert build['exit_code']==0 and not build['stops']
dump('storage-stop-v2-review.json',{'kind':'validation_artifact_storage_exhaustion','limit_bytes':8*1024**3,'initial_free_bytes':67482746880,'resources_after_copy_batch':r,'used_tmp_bytes':67482746880-r['tmp_free_bytes'],'overshoot_bytes':67482746880-r['tmp_free_bytes']-8*1024**3,'stop_reasons':reasons(r),'build_completed':True,'build_result_sha256':sha(last),'circuit_tests_started':False,'copied_executable_count':47,'copied_bytes':sum(v['bytes'] for v in circuit.values()),'all_copies_individually_verified':True,'manifest_sha256':sha(manifest),'harness_limitation':'The executed helper checked resource usage after the whole copy batch, so retention overshot the cap before its assertion stopped validation. No circuit test result or complete qualification was published. Future helpers preflight each new copy and return a structured storage diagnostic.','artifacts_deleted':False})
old=json.loads((w/'tmp-contract-v2.json').read_text());new=dict(old);new.update(net_consumption_limit_bytes=12*1024**3,previous_contract_sha256=sha(w/'tmp-contract-v2.json'),previous_storage_stop_sha256=sha(w/'storage-stop-v2-review.json'),minimum_post_allowance_free_bytes=67482746880-12*1024**3,migration='Retained validation storage only: 12 GiB against the original baseline; all workload, time, memory, root and Disk B limits unchanged.')
dump('tmp-contract-v3.json',new)
write('storage-migration-v2.md','''# Measured temporary-storage continuation

The unchanged Hypercircuit build completed in 384.987002006 seconds. Freezing its
47 executables required 812,019,256 bytes. The helper checked the 8 GiB allowance
after that batch and stopped with an assertion before any circuit test ran.
The retained files use 9,298,980,864 bytes relative to the original baseline;
the observed overshoot was 709,046,272 bytes. This copy-batch checking gap is a
validation-harness limitation, not successful containment within 8 GiB. The exact
resource observation and every copied executable hash are retained.

Continue under the existing user authorization for /tmp with a 12 GiB cumulative
storage allowance, preserving the original 67,482,746,880-byte baseline. The
observed retained set plus remaining lint, documentation, compiler-floor and
integration artifacts requires more than the earlier estimates. The new boundary
still leaves 54,597,844,992 bytes free. This changes storage containment only;
original workloads, fixtures, precision, command times, child address-space,
job count, host-memory and log limits, root baseline and approved Disk B ceiling
remain fixed. No previous artifact or adverse result is removed.

Resume the 46 circuit test binaries from their already frozen copies. The source
and copied executables are verified before each command. New harness versions
reuse byte-identical frozen copies and preflight each additional copy with a
structured storage-exhaustion diagnostic. Prepared but unexecuted checks use new
versions recording this migration. This is not a claim of completion under the
original 5 GiB or intermediate 8 GiB storage contracts.
''')
s=(w/'validation_runner_v2.py').read_text().replace('tmp-contract-v2.json','tmp-contract-v3.json').replace('tmp_net_consumption_8_gib','tmp_net_consumption_12_gib');write('validation_runner_v3_local.py',s)
s=(w/'harness_v5.py').read_text().replace('from validation_runner_v2 import','from validation_runner_v3_local import').replace("sha(W/'tmp-contract-v2.json')","sha(W/'tmp-contract-v3.json')")
s=s.replace('  assert not reasons(resources())',"  sample=resources();stops=reasons(sample)\n  if stops:raise RuntimeError({'kind':'validation_resource_exhaustion','stops':stops,'resources':sample})")
old="p=Path(item['executable']);copy=self.A/key;shutil.copy2(p,copy);assert sha(p)==sha(copy)"
new="""p=Path(item['executable']);digest=sha(p);previous=sorted(Path(path) for path,expected in self.inherited_artifacts.items() if expected==digest)
   copy=previous[0] if previous else self.A/key
   if not previous:
    sample=resources();contract=json.loads((W/'tmp-contract-v3.json').read_text());needed=((p.stat().st_size+4095)//4096)*4096+65536
    if sample['tmp_free_bytes']-needed<contract['initial_free_bytes']-contract['net_consumption_limit_bytes']:
     diagnostic={'kind':'validation_artifact_storage_exhaustion','path':str(p),'copy':str(copy),'estimated_copy_bytes':needed,'resources':sample,'copy_started':False}
     dump(self.R/(key+'-storage-stop.json'),diagnostic);raise RuntimeError(diagnostic)
    shutil.copy2(p,copy)
   assert sha(p)==sha(copy)==digest
   self.verify()"""
assert old in s;s=s.replace(old,new).replace("'cargo_fresh':item['fresh']","'cargo_fresh':item['fresh'],'reused_identical_frozen_copy':bool(previous)");write('harness_v6.py',s);ast.parse(s)
s='''"""Resume frozen circuit tests and remaining quality checks after storage stop."""
import json
from harness_v6 import Harness,W,N,O,U,cargo,sha,dump,rows
source=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text())['candidate_source']
h=Harness('downstream-v3',{'crates/hyperreal/src/computable/node/representation.rs':source},target=U/'target-qualified-v2')
prior=json.loads((N/'sign-cache-publication-downstream-v2/summaries-progress-v1.json').read_text());summaries=prior['summaries'];parents=prior['parent_summaries'];packages=prior['packages']
assert set(packages)=={'hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc'}
commands=json.loads((N/'sign-cache-publication-downstream-v2/progress-v1.json').read_text());assert all(r['exit_code']==0 and not r['stops'] for r in commands.values())
manifest=U/'downstream-v2-artifacts/executables-v1.json';items=json.loads(manifest.read_text());h.artifacts={k:v for k,v in items.items() if k.startswith('hypercircuit-build--')};assert len(h.artifacts)==47
h.runtime_bindings={v['compiled_path']:v['copy'] for v in h.artifacts.values() if not v['profile']['test']}
dump(h.A/'executables-v1.json',h.artifacts);h.verify()
dump(h.R/'continuation-v1.json',{'prior_progress_sha256':sha(N/'sign-cache-publication-downstream-v2/progress-v1.json'),'prior_summaries_sha256':sha(N/'sign-cache-publication-downstream-v2/summaries-progress-v1.json'),'prior_completed_commands':commands,'earlier_continuation_sha256':sha(N/'sign-cache-publication-downstream-v2/continuation-v1.json'),'storage_stop_sha256':sha(W/'storage-stop-v2-review.json'),'storage_migration_sha256':sha(W/'storage-migration-v2.md'),'frozen_manifest_sha256':sha(manifest),'source_overlays_unchanged':True,'compilation_rerun':False})
for ordinal,key in enumerate(sorted(h.artifacts)):
 if not h.artifacts[key]['profile']['test']:continue
 label='hypercircuit-test-'+str(ordinal)+'-'+h.artifacts[key]['target']['name'];summary,out,err,_=h.test(label,key)
 assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary),summary
 assert 'skipping complex project fixture' not in out+err
 summaries[label]=summary;parents[label]=summary[-1]
out,_,_=h.execute('hypercircuit-doctests',[cargo,'test','--release','--locked','-p','hypercircuit','--all-features','--doc','--','--test-threads=1']);summary=rows(out);assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary)
summaries['hypercircuit-doctests']=summary;packages['hypercircuit']={'test_binaries':46,'parent_test_passed':sum(int(r[1]) for k,r in parents.items() if k.startswith('hypercircuit-test-')),'parent_ignored':sum(int(r[3]) for k,r in parents.items() if k.startswith('hypercircuit-test-')),'doctests_passed':sum(int(r[1]) for r in summary)}
dump(h.R/'summaries-progress-v1.json',{'summaries':summaries,'parent_summaries':parents,'packages':packages})
for package in ['hyperlimit','hypercurve','hypermesh','csgrs','hyperdrc','hypercircuit']:
 h.execute(package+'-clippy',[cargo,'clippy','--release','--locked','-p',package,'--all-targets','--all-features','--','-D','warnings'])
 h.execute(package+'-docs',[cargo,'doc','--release','--locked','-p',package,'--all-features','--no-deps'])
h.verify();dump(h.R/'result-v1.json',{'passed':True,'packages':packages,'summaries':summaries,'parent_summaries':parents,'commands':h.commands,'prior_completed_commands':commands,'continuation_sha256':sha(h.R/'continuation-v1.json'),'original_native_gates_passed_in_downstream_v2':True,'all_original_workload_limits_unchanged':True,'tmp_storage_allowance_gib':12,'storage_exhaustion_history_preserved':True,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'downstream_qualification_passed':True,'packages':packages}),flush=True)
'''
write('qualify_downstream_v3.py',s);ast.parse(s)
print(json.dumps({'recorded_storage_stop':r,'new_allowance_gib':12,'frozen_circuit_tests_to_run':46}))
