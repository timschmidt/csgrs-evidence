from pathlib import Path
import os,tarfile,tomllib,hashlib,subprocess,shutil
s=Path(os.environ['s']);p=Path(subprocess.check_output(['rustc','+1.95.0','--print','sysroot'],text=True).strip())
t=s/'night-rustup/toolchains'/p.name
def mirror(src,dst):
 dst.mkdir()
 for child in src.iterdir():
  dest=dst/child.name;rel=child.relative_to(p).as_posix()
  if rel in ['bin','lib','lib/rustlib']:mirror(child,dest)
  elif rel=='bin/rustc' or child.name.startswith('librustc_driver') and rel.startswith('lib/'):shutil.copy2(child,dest)
  else:dest.symlink_to(child)
mirror(p,t)
m=tomllib.loads((p/'lib/rustlib/multirust-channel-manifest.toml').read_text())
row=m['pkg']['rust-std']['target']['wasm32-wasip1'];pkg=s/'wasi-std.tar.xz'
subprocess.run(['curl','-fsSL','--retry','2',row['xz_url'],'-o',pkg],check=True)
assert hashlib.file_digest(pkg.open('rb'),'sha256').hexdigest()==row['xz_hash']
with tarfile.open(pkg) as f:
 for member in f:
  if '/lib/rustlib/wasm32-wasip1/' not in member.name or not member.isfile():continue
  rel=member.name.split('/lib/rustlib/',1)[1];dest=t/'lib/rustlib'/rel
  assert dest.resolve().is_relative_to(t.resolve());dest.parent.mkdir(exist_ok=True,parents=True)
  with dest.open('wb') as out:shutil.copyfileobj(f.extractfile(member),out)
print(row['xz_hash'],pkg.name)
