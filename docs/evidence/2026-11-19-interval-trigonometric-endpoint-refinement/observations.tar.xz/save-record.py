from record import record,s
import json,subprocess
subprocess.run(['python3',s/'wasm-account.py'],check=True)
subprocess.run(['python3',s/'report.py'],check=True)
tag='trigonometric-endpoint-refinement'
files={p for p in s.iterdir() if p.is_file() and p.suffix in {'.py','.sh','.patch','.json','.txt'} and p.name not in ['historical.txt','receipt.json','edit.py']}
files.add(s/'env')
files.update(p for p in (s/'logs').iterdir() if p.is_file())
for v in ['stable','nightly']:
 for t in ['before','admitted']:files.update((s/f'{v}-{t}-coverage').iterdir())
result=record(tag,sorted(files),'Archive mixed-endpoint trigonometric range qualification')
(s/'receipt.json').write_text(json.dumps(result,indent=1)+'\n')
print(result)
