from pathlib import Path
import sys
mode=sys.argv[1]
for name in ['trigonometry','tangent']:
 p=Path('crates/hyperinterval/src')/(name+'.rs')
 z=p.read_text()
 i=z.index('            } else if let Some(right) = reduce(b, &half_pi, working, budget)? {')
 j=z.index('\n            }\n        }\n        working =',i)
 fallback='return whole();' if name=='tangent' else 'return complete(whole(precision, budget)?);'
 if mode=='right-phase': z=z[:j]+f'\n            }} else {{\n                {fallback}'+z[j:]
 elif mode=='right-value':
  # Return a whole range when a nondegenerate interval still needs endpoint refinement.
  k=z.rindex('\n                }',i,j)
  z=z[:k]+f'\n                }} else {{\n                    {fallback}'+z[k:]
 else: raise ValueError(mode)
 p.write_text(z)
