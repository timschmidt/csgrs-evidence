set -eu
cd "$s/compare"
export CARGO_TARGET_DIR="$s/release"
for mut in right-phase right-value; do
 python3 "$s/mutants.py" "$mut"
 for pkg in tangent trigonometry; do
  log="$s/logs/mutation-$mut-admitted-$pkg"
  if cargo +1.95.0 test --release --locked -p hyperinterval --all-features --test "$pkg" > "$log" 2>&1; then exit 1; fi
  rg 'test result: FAILED' "$log"
 done
 git restore -- crates/hyperinterval/src/{tangent,trigonometry}.rs
done
bash "$s/build-tests.sh" repeat
for pkg in tangent trigonometry; do cmp "$s/admitted-$pkg" "$s/repeat-$pkg"; done
