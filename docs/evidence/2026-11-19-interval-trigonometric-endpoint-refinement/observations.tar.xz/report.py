from pathlib import Path
import json,re,os,subprocess as sp
s=Path(__file__).parent;root=Path('/mnt/development/csgrs')
def loads(p):return json.loads((s/p).read_text())
def log(n):return (s/'logs'/n).read_text()
def ok(n):assert 'test result: ok.' in log(n) and 'test result: FAILED' not in log(n),n
for n in ['final-all-targets','final-doctests','minimal','final-lattice','msrv-dyadic','admitted-trigonometry','admitted-tangent']:ok(n)
for n in ['msrv-dyadic','final-all-targets','final-lattice','final-doctests','minimal','final-clippy','docs','examples','final-fmt','thumbv7em-none-eabihf','wasm32-unknown-unknown']:
 assert not re.search('^(error|warning):',log(n),re.M),n
for t in ['before','admitted']:
 for n,count in [('tangent',7),('trigonometry',6)]:
  l=f'wasi-{t}-{n}';ok(l);assert f'test result: ok. {count} passed;' in log(l)
for old in ['tangent','trigonometry']:ok('mutation-right-phase-original-'+old)
ok('mutation-right-value-original-trigonometry')
for mut in ['right-phase','right-value']:
 for n in ['tangent','trigonometry']:
  assert 'test result: FAILED' in log(f'mutation-{mut}-admitted-{n}')
for n in ['fuzz-trig-complete','fuzz-tangent-ci']:assert 'Done 10000 runs' in log(n)
assert '1006/1027' in log('nightly-admitted') and '1004/1027' in log('nightly-before')
assert '5002/5033' in log('stable-admitted') and '5000/5033' in log('stable-before')
assert 'Production coverage is below 100%' in log('nightly-admitted')
assert (s/'admitted.patch').read_bytes()==sp.check_output(['git','-C',root,'diff','ce8820eb1^','ce8820eb1','--','crates/'])
print('Verified both native and guest suites, numerical and domain failure controls, exact cost accounts, ASan completion and coverage results.')
