from pathlib import Path
import json,hashlib,re,subprocess as sp,statistics,shutil
s=Path(__file__).resolve().parent;root=Path('/mnt/development/csgrs')
def compact(file,results):file.write_text(json.dumps(results,indent=1)+'\n')
def probe(p):
 sections=sp.check_output(['size','-A',p],text=True)
 text=int(re.search(r'^\.text\s+(\d+)',sections,re.M)[1])
 symbols=sp.check_output(['nm','-S','--defined-only',p],text=True)
 spans=sorted((int(a,16),int(a,16)+int(n,16)) for a,n in re.findall(r'^([a-f0-9]+) ([a-f0-9]+) [tT] ',symbols,re.M))
 cursor=total=0
 for a,b in spans:
  total+=max(0,b-max(cursor,a));cursor=max(cursor,b)
 return dict(file=p.stat().st_size,executable_code=text,named_text=total,sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest())
previous=json.loads((root/'docs/research/interval-size-accounts.json').read_text())
def dicts(x):
 if isinstance(x, dict):
  yield x
  for v in x.values():yield from dicts(v)
 elif isinstance(x,list):
  for v in x:yield from dicts(v)
results={}
for n in ['trigonometry','tangent']:
 history=next(r for r in dicts(previous) if r.get('artifact')==f'crates/hyperinterval/tests/{n}.rs#release-tests')
 old=history['metrics']
 imgs=[probe(s/(t+'-'+n)) for t in ['fixed','before','admitted','repeat']]
 assert imgs[2]==imgs[3]
 metrics={}
 for k in old:
  a,b,c=[v[k] for v in imgs[:3]]
  caps=old[k]['caps']
  step=max(0,c-b);prev=max(0,b-a,old[k]['accepted_positive_growth_bytes'])
  total=prev+step
  maxinc=min(caps['incremental_bytes'],int(b*caps['incremental_percent']/100))
  maxcum=min(caps['cumulative_bytes'],int(a*caps['cumulative_percent']/100))
  assert step<=maxinc and total<=maxcum
  metrics[k]=dict(fixed=a,preceding=b,retained=c,previous_positive=prev,increment=step,cumulative=total,remaining=maxcum-total,caps=caps)
 results[n]=dict(metrics=metrics,sha256=[v['sha256'] for v in imgs],capacity=64*2**20,required_free=16*2**20,free=64*2**20-imgs[2]['file'])
 assert results[n]['free']>results[n]['required_free']
 print(n,[(k,r['increment'],r['cumulative'],r['remaining']) for k,r in metrics.items()])
compact(s/'size-account.json',results)
for v in ['stable','nightly']:
 for t in ['before','admitted']:
  log=(s/f'logs/{v}-{t}').read_text()
  assert 'Production coverage is below 100%' in log
  out=Path(re.search('^Coverage artifacts in (.+)$',log,re.M)[1]);dest=s/(v+'-'+t+'-coverage');dest.mkdir(exist_ok=True)
  for n in ['summary.json','merged.profdata','uncovered.txt']:shutil.copyfile(out/n,dest/n)
  summary=json.loads((dest/'summary.json').read_text())
  print(v,t,summary['production'])
  if v=='nightly':
   b={};name=''
   for l in (dest/'uncovered.txt').read_text().splitlines():
    if l.endswith('.rs:'):name=l.split('/')[-1].rstrip(':')
    if name not in ['tangent.rs','trigonometry.rs']:continue
    m=re.match(r'\s*\|  Branch \((\d+):(\d+)\): \[True: (.*?), False: (.*?)\]',l)
    if not m:continue
    line,col,yes,no=m.groups();key=f'{name}:{line}:{col}';seen=b.setdefault(key,[False,False]);seen[0]|=yes!='0';seen[1]|=no!='0'
   compact(dest/'per-branch.json',b)
   print('right-phase',[(key,b[key]) for key in ['tangent.rs:181:27','trigonometry.rs:236:27']])
for p in ['trigonometry','tangent']:
 a=json.loads((s/'suite-cost.json').read_text())[p]
 print(p,[(k,round(statistics.median(x['seconds'] for x in v),3),max(x['peak_rss_kib'] for x in v)) for k,v in a.items()])
