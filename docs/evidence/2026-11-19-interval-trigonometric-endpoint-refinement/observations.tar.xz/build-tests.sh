set -eu
cd "$s/compare"
tag=$1
export CARGO_TARGET_DIR="$s/release"
cargo +1.95.0 test --release -p hyperinterval --locked --all-features --test tangent --test trigonometry --no-run --message-format=json-render-diagnostics >"$s/logs/$tag-objects.jsonl" 2>"$s/logs/$tag-build"
python3 - "$tag" <<'PY'
import os,json,shutil,sys,subprocess
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1]
for line in (s/'logs'/f'{tag}-objects.jsonl').read_text().splitlines():
 r=json.loads(line)
 if r.get('executable') and r['target']['name'] in ['tangent','trigonometry']:
  dest=s/(tag+'-'+r['target']['name']);shutil.copy2(r['executable'],dest)
PY
