from pathlib import Path
import hashlib,json,struct
s=Path(__file__).parent
def measure(path):
 data=path.read_bytes();at=8
 assert data[:8]==b'\x00asm\x01\x00\x00\x00'
 def uleb():
  nonlocal at
  val=shift=0
  while True:
   n=data[at];at+=1;val|=(n&127)<<shift
   if n<128:return val
   shift+=7
 out=dict(file=len(data),sha256=hashlib.sha256(data).hexdigest())
 while at<len(data):
  kind=data[at];at+=1;size=uleb();end=at+size
  if kind==10:
   total=0
   for _ in range(uleb()):
    length=uleb();total+=length;at+=length
   assert at==end;out.update(code=size,function_bodies=total)
  at=end
 return out
results={}
for n in ['trigonometry','tangent']:
 images=[measure(s/f'{t}-{n}.wasm') for t in ['fixed','before','admitted']]
 metrics={}
 for m in ['file','code','function_bodies']:
  a,b,c=[v[m] for v in images];step=max(0,c-b);previous=max(0,b-a);total=step+previous
  cap=32768 if m=='file' else 16384
  rinc=min(cap,b*2//100);rcum=min(cap,a*2//100)
  metrics[m]=dict(fixed=a,preceding=b,retained=c,previous_positive=previous,increment=step,cumulative=total,remaining=rcum-total,caps=dict(incremental_bytes=cap,cumulative_bytes=cap,incremental_percent=2,cumulative_percent=2))
  assert step<=rinc and total<=rcum,(n,m,a,b,c,step,total,cap)
 free=(64<<20)-images[-1]['file'];assert free>=16<<20
 results[n]=dict(metrics=metrics,sha256=[v['sha256'] for v in images],capacity=64<<20,required_free=16<<20,free=free)
 print(n,[(k,r['increment'],r['cumulative'],r['remaining']) for k,r in metrics.items()])
(s/'wasm-size.json').write_text(json.dumps(results,indent=1)+'\n')
