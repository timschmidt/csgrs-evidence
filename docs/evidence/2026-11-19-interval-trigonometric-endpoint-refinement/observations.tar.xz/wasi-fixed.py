from pathlib import Path
p=Path('crates/hyperinterval/Cargo.toml');z=p.read_text()
if 'features = ["force-cross"]' not in z:
 z+='\n[target.\'cfg(target_os = "wasi")\'.dev-dependencies]\ngmp-mpfr-sys = { version = "1.7", default-features = false, features = ["force-cross"] }\n'
 p.write_text(z)
p=Path('Cargo.lock');z=p.read_text();a=z.index('\nname = "hyperinterval"');b=z.index('\n[[package]]',a)
entry=z[a:b]
if '"gmp-mpfr-sys"' not in entry:p.write_text(z[:a]+entry.replace('dependencies = [','dependencies = [\n "gmp-mpfr-sys",',1)+z[b:])
