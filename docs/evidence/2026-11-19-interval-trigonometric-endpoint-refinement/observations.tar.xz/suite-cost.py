import json,os,time,statistics
from pathlib import Path
s=Path(__file__).parent;out={}
# One thread per harness, on a fixed CPU, all runs include oracle and test assertions.
os.sched_setaffinity(0,{12})
for pkg in ['trigonometry','tangent']:
 runs={}
 for tag in ['before','admitted','admitted','before']*3:
  p=s/(tag+'-'+pkg);start=time.monotonic()
  pid=os.fork()
  if pid==0:
   with (s/'logs'/('cost-'+tag+'-'+pkg)).open('wb') as f:
    os.dup2(f.fileno(),1);os.dup2(f.fileno(),2)
    os.execv(p,[str(p),'--test-threads=1'])
  _,status,usage=os.wait4(pid,0);assert os.waitstatus_to_exitcode(status)==0
  runs.setdefault(tag,[]).append(dict(seconds=time.monotonic()-start,user=usage.ru_utime,system=usage.ru_stime,peak_rss_kib=usage.ru_maxrss))
 out[pkg]=runs
(s/'suite-cost.json').write_text(json.dumps(out,indent=1))
