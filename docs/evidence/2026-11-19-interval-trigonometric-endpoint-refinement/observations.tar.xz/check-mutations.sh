set -eu
cd "$s/compare"
export CARGO_TARGET_DIR="$s/release"
for mut in right-phase right-value; do
 python3 "$s/mutants.py" "$mut"
 git diff -- crates/hyperinterval/src > "$s/$mut.patch"
 for step in original witness; do
  if test "$step" = witness; then git apply "$s/witness.patch"; fi
  for n in tangent trigonometry; do
   log="$s/logs/mutation-$mut-$step-$n"
   if cargo +1.95.0 test --release --locked -p hyperinterval --all-features --test "$n" > "$log" 2>&1; then echo "passed $mut $step $n"; else rg 'test result: FAILED' "$log"; fi
  done
 done
 git restore -- crates/hyperinterval/{src,tests}/{tangent,trigonometry}.rs
done
git apply "$s/witness.patch"
bash "$s/build-tests.sh" retained
