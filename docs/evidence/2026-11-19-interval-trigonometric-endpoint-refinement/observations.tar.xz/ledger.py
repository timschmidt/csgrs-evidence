from pathlib import Path
import json
s=Path(__file__).parent;r=Path('/mnt/development/csgrs')
def read(n):return json.loads((s/n).read_text())
receipt=read('receipt.json');entry=dict(source=(s/'source-commit.txt').read_text().strip(),fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb',preceding='ace4bf62f11da551911f699754c7629916951236',evidence=receipt['record'],evidence_commit=receipt['commit'],
 benefit='Detect false whole images and incorrect domain coverage for unresolved right endpoints. Verify exact tight bounds and exhaustion/retry at dyadic output boundaries with nondegenerate inputs.',
 scope='Rust 1.95 release all-feature Hyperinterval integration test executables, one matched checkout and target path per compiler target. Host qualification slot 64 MiB, required free 16 MiB per image.',
 metrics=['fixed','preceding','retained','previous_positive','increment','cumulative','remaining'],limits='Both 2% and the absolute cap apply at each step and cumulatively. The file cap is 32 KiB. Executable code and defined-function bytes each have a 16 KiB cap. Remaining is after both limits. Native charges carry forward the larger of the published earlier charge and observed positive fixed-to-preceding growth.',
 wasm_control='The fixed historical manifest refused cross-compilation. Its isolated fixture adds the WASI-only GMP force-cross development feature and lock edge from the current build. The fixed Rust source is unchanged. Hashes and build-metadata diff are archived.',
 targets={})
for target,f in [('x86_64-unknown-linux-gnu','size-account.json'),('wasm32-wasip1','wasm-size.json')]:
 entry['targets'][target]={}
 for suite,row in read(f).items():
  entry['targets'][target][suite]={'free_bytes':row['free'], **{name:[values[k] for k in entry['metrics']] for name,values in row['metrics'].items()}}
key='trigonometric_endpoint_conformance'
p=r/'docs/research/interval-size-accounts.json';old=p.read_text()
assert old.endswith('\n}\n') and key not in json.loads(old)
new=old[:-3]+',\n'+json.dumps({key:entry},ensure_ascii=False,indent=2)[2:]+'\n'
assert json.loads(new)=={**json.loads(old),key:entry}
p.write_text(new)
p=r/'INTERVAL_REFACTOR_PROGRESS.md'
msg='''
## Phase 5 — refinement at one endpoint of a trigonometric interval

On `ace4bf62f`, both trigonometric suites accepted a control that returned
the whole range when the left endpoint's quadrant was known but the right
endpoint's quadrant was still unresolved. Commit `ce8820eb1` adds rational
intervals starting at 1/4 and ending just below or above π/2 and π. Directed
MPFR and independent pole counts check the exact outward grid bounds, the
number of components and domain coverage. Tangent and cotangent also cross
the output grid at one near π/4. The altered tangent implementation reported
partial coverage for a complete interval. Both suites now reject it.

For sine near π/6 and cosine near π/3, the tests now include nondegenerate
intervals from zero to either side of the point whose image is 1/2. They
check both endpoints at input spacings of 2^-64, 2^-256 and 2^-512. Each
interval exhausts one work unit below its measured debit and completes on
exact-budget retry. A separate control that published a full range after
endpoint evaluation failed passed the original sine/cosine suite. The new
fixture detected a lower bound of −1 where the exact grid bound is zero.

Nightly `8006091eb` now covers both outcomes of right-endpoint reduction
in each kernel. Across Hyperinterval, covered branch outcomes rose from
1,004 to 1,006 of 1,027. Rust 1.99 covered 5,002 of 5,033 lines and
10,095 of 10,546 regions, up two in each metric. The 100% gate remains open.
[Trigonometric tests](crates/hyperinterval/tests/trigonometry.rs) ·
[Pole and domain tests](crates/hyperinterval/tests/tangent.rs)

Rust 1.95 passed 296 Hyperinterval all-target tests, 15 doctests, five
minimal tests and 98 downstream Hyperlattice interval tests and doctests.
Formatting, strict Clippy, rustdoc and example/bench checks passed. Rust
1.88 passed the dyadic suites. The optional Hyperreal-backed rational
configuration requires Rust 1.95. Both ASan fuzz targets completed 10,000
inputs with their directed oracles. The dyadic library built for bare
Wasm and Thumb. On WASI Preview 1, all six sine/cosine cases and seven
tangent/cotangent cases passed. The native suite exercised the additional
process-spawning replay fixture.

The native sine/cosine and tangent/cotangent test executables grew by
2,136 and 1,152 bytes. Their WASI modules grew by 2,177 and 854 bytes.
All four met the file, code and function budgets including prior charges.
For the fixed historical WASI comparison, the archived build adds the
GMP cross-compilation feature required by the toolchain. The changes are
confined to test sources. [Size accounts](docs/research/interval-size-accounts.json)

'''
size=int(receipt['row'].split('\t')[2])
msg+=f"Evidence commit `{receipt['commit']}` records {receipt['members']} verified members in {size:,} compressed bytes. [Evidence index](docs/evidence-archive.tsv)\n"
assert '## Phase 5 — refinement at one endpoint' not in p.read_text()
with p.open('a') as out:out.write(msg)
