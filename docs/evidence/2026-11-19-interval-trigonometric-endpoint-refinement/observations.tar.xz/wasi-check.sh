set -eu
cd "$s/compare"
export RUSTUP_HOME="$s/night-rustup" RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR="$s/wasi-target"
export PATH="$s/node:$s/wasi-tools/usr/lib/llvm-19/bin:$s/wasi-tools/usr/bin:$PATH"
sys="$s/wasi-tools/usr"
rt="$sys/lib/llvm-19/lib/clang/19"
test -d "$rt/include" || ln -s /usr/lib/llvm-19/lib/clang/19/include "$rt/include"
export CC="clang --target=wasm32-wasi --sysroot=$sys -resource-dir=$rt" CC_FOR_BUILD=cc
export CPPFLAGS="-D_WASI_EMULATED_SIGNAL" LIBS="-lwasi-emulated-signal"
export GMP_MPFR_SYS_CACHE="$s/wasi-gmp"
export RUSTFLAGS="-C link-arg=$sys/lib/wasm32-wasi/libwasi-emulated-signal.a"
for tag in fixed before admitted; do
 case "$tag" in
 fixed) git restore -- crates/hyperinterval/tests/{tangent,trigonometry}.rs; git switch -q --detach c9f1f9ac5;;
 before) git restore -- crates/hyperinterval/Cargo.toml Cargo.lock; git switch -q --detach ace4bf62f;;
 admitted) git apply "$s/admitted.patch";;
 esac
 if test "$tag" = fixed; then
  python3 "$s/wasi-fixed.py"
  git diff -- crates/hyperinterval/Cargo.toml Cargo.lock > "$s/wasi-fixed-build-metadata.patch"
 fi
 cargo +1.95.0 test --locked --release --target wasm32-wasip1 -p hyperinterval --all-features --test tangent --test trigonometry --no-run --message-format=json-render-diagnostics >"$s/logs/wasi-$tag-objects.jsonl" 2>"$s/logs/wasi-$tag-build"
 python3 - "$tag" <<'PY'
import os,json,sys,shutil,subprocess as sp
from pathlib import Path
s=Path(os.environ['s']);tag=sys.argv[1]
for l in (s/f'logs/wasi-{tag}-objects.jsonl').read_text().splitlines():
 r=json.loads(l)
 if not r.get('executable'):continue
 n=r['target']['name'];assert n in ['tangent','trigonometry']
 p=s/f'{tag}-{n}.wasm';shutil.copy2(r['executable'],p)
 if tag=='fixed':continue
 cmd=['node','crates/hyperlattice-interval/conformance/run-wasi-test.mjs',p,'--exact','--test-threads=1']
 if n=='tangent':cmd+=['--skip','replay_then_another_pole_operation_in_fresh_process']
 with (s/f'logs/wasi-{tag}-{n}').open('wb') as f:sp.run(cmd,check=True,stdout=f,stderr=sp.STDOUT)
PY
done
