"""Compare unchanged public allocation lifecycles in separate fresh targets."""
import csv,io,json,shutil
from pathlib import Path
from harness_v3 import Harness,W,N,O,U,cargo,sha,dump
assert json.loads((N/'sign-cache-publication-scalar-v2/result-v1.json').read_text())['passed']
focus=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text());source=focus['candidate_source'];assert sha(source)==focus['candidate_source_sha256']
phases={};binaries={};rows={}
for mode in ['baseline','candidate']:
 target=U/('target-cost-'+mode+'-v1');assert not target.exists();target.mkdir()
 h=Harness('cost-'+mode+'-v1',{} if mode=='baseline' else {'crates/hyperreal/src/computable/node/representation.rs':source},target=target);phases[mode]=h
 out,_,_=h.execute('build',[cargo,'build','--release','--locked','-p','hyperreal','--example','allocation_profile','--message-format=json'])
 items=[json.loads(l) for l in out.splitlines() if l.startswith('{')];libs=[r for r in items if r.get('reason')=='compiler-artifact' and r['target']['name']=='hyperreal' and 'lib' in r['target']['kind']];assert len(libs)==1 and not libs[0]['fresh']
 executables=[r for r in items if r.get('reason')=='compiler-artifact' and r.get('executable')];assert len(executables)==1
 item=executables[0];assert item['target']['name']=='allocation_profile' and not item['fresh'];p=Path(item['executable']);copy=h.A/'allocation_profile';shutil.copy2(p,copy);assert sha(p)==sha(copy)
 h.artifacts['allocation_profile']={'copy':str(copy),'compiled_path':str(p),'sha256':sha(copy),'bytes':copy.stat().st_size,'features':item['features'],'target':item['target'],'profile':item['profile'],'cargo_fresh':item['fresh']};dump(h.A/'executables-v1.json',h.artifacts);binaries[mode]=h.artifacts['allocation_profile'];h.verify()
 out,_,_=h.execute('elf-size',['/usr/bin/size',str(copy)],binary=True,limit=60);dump(h.R/'binary-v1.json',{'artifact':h.artifacts['allocation_profile'],'size_stdout':out,'size_tool_sha256':sha('/usr/bin/size'),'cost_contract_sha256':sha(W/'cost-contract-v1.md')})
assert binaries['baseline']['sha256']!=binaries['candidate']['sha256']
assert binaries['baseline']['features']==binaries['candidate']['features']
for pair in range(5):
 for mode in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
  h=phases[mode];out,_,_=h.execute('pair-'+str(pair),[binaries[mode]['copy'],'64'],binary=True,limit=60)
  data=list(csv.DictReader(io.StringIO(out)));assert len(data)==20 and len({r['representation'] for r in data})==20
  parsed=[{k:v if k=='representation' else int(v) for k,v in row.items()} for row in data];assert all(r['iterations']==64 for r in parsed)
  rows[(mode,pair)]=parsed;dump(h.R/('pair-'+str(pair)+'.json'),parsed)
comparisons=[]
for pair in range(5):
 baseline=rows[('baseline',pair)];candidate=rows[('candidate',pair)];assert [r['representation'] for r in baseline]==[r['representation'] for r in candidate]
 for b,c in zip(baseline,candidate):comparisons.append({'pair':pair,'representation':b['representation'],'baseline':b,'candidate':c,'deltas':{k:c[k]-b[k] for k in b if k not in ['representation','iterations']}})
for h in phases.values():h.verify()
result={'completed_processes':10,'representation_rows_per_process':20,'comparisons':comparisons,'binaries':binaries,'cost_contract_sha256':sha(W/'cost-contract-v1.md'),'exact_csv_identity':all(b==rows[('candidate',i)] for (m,i),b in rows.items() if m=='baseline'),'all_observations_retained':True,'allocation_payload_only':True,'general_speedup_claimed':False,'runtime_admitted':False,'full_plan_complete':False}
p=W/'cost-result-v1.json';assert not p.exists();dump(p,result);print(json.dumps({'completed_processes':10,'allocation_rows_identical':result['exact_csv_identity'],'runtime_admitted':False}),flush=True)
