# Exact-sign publication acceptance contract

Revision: a1ffc2de7151f0a49229f186001ceae04839d38f. Owner: Hyperreal
AtomicFacts publication for immutable Computable nodes. P3-P5, P8-P9, P19,
P35-P37 apply. Every production writer already uses this shared method.
A delayed unresolved structural traversal must not erase a concurrently
published certified sign. Exact proofs for the same immutable node must agree;
this experiment does not make conflicting proofs valid or certify an
approximate-policy terminal. Retain construction hints and bound metadata.

First reproduce the source-review finding on the actual current method with
unchanged new tests: packed metadata and all three signs; barrier-ordered stale
publication; and an actual sqrt(2)-1 expression proved positive structurally
without an approximation cache. Include a successful Invalid -> Unknown -> Valid
control. Baseline tests must fail for the intended lost-certificate assertion,
not compilation, setup, resource exhaustion or an unrelated premise. Only then
prepare the smallest owning-layer repair. Do not change policies, precision
floors, recognition budgets, expression shapes or existing tests to make it pass.
An in-flight query may have observed an earlier cache state; the publication
repair alone is not a claim that every overlapping query observes the latest
proof. Subsequent queries after publication must retain that proof.

The circle-envelope experiment is independent and must finish before any new
build or timed workload. Preserve all its binaries, measurements and inputs.
Use a new /tmp target for this scalar investigation: the user already authorized
/tmp validation builds. Cap additional /tmp filesystem consumption at 5 GiB,
with a 512 MiB reserve; pin that initial free-space observation once before the
first build. Preserve the original 16 GiB root and approved 72 GiB Disk B
baselines and limits. Retain the 8 GiB child address-space, two build jobs,
1800-second command, 60-second focused-probe, 2 GiB available-host-memory and
64 MiB cumulative command-log limits. /tmp targets are explicitly volatile;
keep the source patches, raw results and reproduction protocol in the eventual
repository evidence. No prior artifact is deleted or rewritten.

Use read-only current main source with immutable per-file/directory test
overlays. Hash all relevant source inputs before/after commands. Freeze each
executed binary before any subsequent build, and hash each physical copy
independently. Keep failing baseline output and the exact tests for candidate
qualification. A narrow successful repair requires affected scalar feature,
cache/domain/abort, predicate and curve/native/modeling checks, appropriate
Clippy/docs/format checks, and proportionate cost/layout evidence before main
retention. No cache layout or allocation growth is proposed. Do not claim a
speedup from compilation or test-run times. Hypervoxel remains excluded.

No push, release acceptance, general concurrency proof or full-plan completion
is claimed. An artifact inventory is not a reread of prior evidence.
