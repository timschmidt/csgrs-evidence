"""Replay complete reports across current-baseline and fixed copied CLIs."""
import decimal,gzip,json,os
from pathlib import Path
from harness_v4 import W,N,O,U,V,sha,dump,run,resources,reasons
assert json.loads((N/'sign-cache-publication-downstream-v1/result-v1.json').read_text())['passed']
R=N/'sign-cache-publication-reports-v1';assert not R.exists();R.mkdir()
F=N/'native-aggregation-fixtures-v1';S=N/'point-rational-facts-source-v1'
main_pins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()))
baseline_manifest=V/'point-rational-inline-facts-artifacts-v1/executables-v1.json';old=json.loads(baseline_manifest.read_text())['hyperdrc-cli']
candidate_manifest=U/'downstream-v1-artifacts/executables-v1.json';items=json.loads(candidate_manifest.read_text());candidates=[v for k,v in items.items() if k.startswith('hyperdrc-build--') and v['target']['kind']==['bin'] and not v['profile']['test']];assert len(candidates)==1
artifacts={'baseline':{'copy':old['executed_copy'],'sha256':old['sha256']},'candidate':candidates[0]}
fixtures=json.loads((F/'verification-v1.json').read_text())['fixtures']
original_production=N/'point-rational-equality-control-v1/rational_comparison_inline_v2.rs'
nonruntime_differences={'crates/hypercurve/PERFORMANCE.md','crates/hypercurve/tests/point_equality_contract.rs','crates/hyperreal/PERFORMANCE.md','crates/hyperreal/README.md','crates/hyperreal/src/real/immediate_equality_tests.rs','crates/hyperreal/tests/gmp_api_coverage.rs'}
production_path='crates/hyperreal/src/rational/arithmetic/comparison.rs';assert sha(original_production)==main_pins[production_path]
def verify():
 assert all(sha(O/p)==h for p,h in main_pins.items())
 for path,expected in main_pins.items():
  if path in nonruntime_differences:continue
  actual=original_production if path==production_path else S/path
  assert sha(actual)==expected,path
 assert all(sha(v['copy'])==v['sha256'] for v in artifacts.values())
 assert all(sha(row['path'])==row['sha256'] for row in fixtures.values())
 assert not reasons(resources())
checks=['layer-sanity','board-outline-sanity','min-copper-neck','drill-spacing'];cases=[]
for label in ['cparti','hvp109a']:
 args=['--kicad-pcb',fixtures[label]['path']]
 for check in checks:args+=['--check',check]
 cases.append((label,args+['--min-width','0.0762','--format','json','--allow-findings'],checks))
cases.append(('gerber-outline',['--gerber-dir',str(F/'gerber-outline-smoke'),'--check','layer-sanity','--min-width','0.0762','--format','json','--allow-findings'],['layer-sanity']))
verify();dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'report-contract-v1.md'),'main_source_pins_sha256':sha(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'baseline_manifest_sha256':sha(baseline_manifest),'candidate_manifest_sha256':sha(candidate_manifest),'baseline_source_root':str(S),'baseline_production_overlay_sha256':sha(original_production),'nonruntime_source_differences':sorted(nonruntime_differences),'baseline_admission_checkpoint_sha256':sha(O/'docs/evidence/2026-10-18-point-equality-facts/checkpoint-v1.json'),'fixtures':fixtures,'binaries':artifacts,'cases':cases,'order':['baseline','candidate','candidate','baseline'],'common_cwd':str(F),'normalization':False,'independent_geometry_oracle':False,'performance_claim':False,'time_tool_sha256':sha('/usr/bin/time')})
def unique(pairs):
 result={}
 for k,v in pairs:assert k not in result;result[k]=v
 return result
def reject(value):raise ValueError(value)
reports={};commands={}
for label,args,expected in cases:
 raw=[];parsed=[];observations=[]
 for ordinal,mode in enumerate(['baseline','candidate','candidate','baseline']):
  verify();name='sign-cache-publication-report-'+label+'-'+str(ordinal)+'-'+mode+'-v1';scratch=N/'scratch'/name
  argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--bind',str(scratch),str(scratch),'--chdir',str(F),'--setenv','TMPDIR',str(scratch),'/usr/bin/time','-v','-o',str(scratch/'process-usage.txt'),artifacts[mode]['copy'],*args]
  commands[name]=run(name,argv,F,wall_seconds=1800);p=N/'logs'/name/'stdout';data=p.read_bytes();report=json.loads(data,parse_float=decimal.Decimal,parse_constant=reject,object_pairs_hook=unique)
  assert report['inputs'] and len(report['violations'])==report['violation_count'];coverage=report['coverage']['checks'];assert [r['check'] for r in coverage]==expected;assert all(r['status'] in ['passed','failed','not_applicable','uncertain','skipped'] for r in coverage)
  raw.append(data);parsed.append(report);observations.append({'mode':mode,'stdout_sha256':sha(p),'bytes':len(data),'violation_count':report['violation_count'],'coverage':coverage,'full_report_materialized':True,'process_usage_path':str(scratch/'process-usage.txt'),'process_usage_sha256':sha(scratch/'process-usage.txt')});dump(R/'progress-v1.json',{'commands':commands,'case':label,'observations':observations});verify()
 assert all(r['check_version']==22 for report in parsed for r in report['coverage']['checks'])
 reports[label]={'observations':observations,'all_bytes_equal':all(r==raw[0] for r in raw),'all_parsed_reports_equal':all(r==parsed[0] for r in parsed),'baseline_repeat_equal':raw[0]==raw[3],'candidate_repeat_equal':raw[1]==raw[2]};dump(R/(label+'-comparison-v1.json'),reports[label])
verify();result={'complete_for_declared_scope':True,'commands':commands,'cases':reports,'all_report_bytes_equal':all(r['all_bytes_equal'] for r in reports.values()),'all_parsed_reports_equal':all(r['all_parsed_reports_equal'] for r in reports.values()),'performance_claim':False,'independent_geometry_oracle':False,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False};dump(R/'result-v1.json',result);print(json.dumps({'all_report_bytes_equal':result['all_report_bytes_equal'],'all_parsed_reports_equal':result['all_parsed_reports_equal']}),flush=True);assert result['all_report_bytes_equal'] and result['all_parsed_reports_equal']
