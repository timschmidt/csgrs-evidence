"""Run complete scalar configurations and quality checks on the isolated fix."""
import json
from harness_v2 import Harness,W,N,O,cargo,sha,dump,rows,rustfmt
focused=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text());assert focused['passed']
source=focused['candidate_source'];assert sha(source)==focused['candidate_source_sha256']
h=Harness('scalar-v1',{'crates/hyperreal/src/computable/node/representation.rs':source});summaries={}
for features,flags in [('default',[]),('all',['--all-features'])]:
 keys=h.build(features+'-build',['test','--release','--locked','-p','hyperreal','--tests']+flags)
 for ordinal,key in enumerate(keys):
  item=h.artifacts[key]
  if not item['profile']['test']:continue
  label=features+'-test-'+str(ordinal)+'-'+item['target']['name']
  summary,_,_,_=h.test(label,key);assert len(summary)==1 and summary[0][0]=='ok' and summary[0][2]=='0',summary;summaries[label]=summary
 out,_,_=h.execute(features+'-doctests',[cargo,'test','--release','--locked','-p','hyperreal','--doc']+flags+['--','--test-threads=1']);summary=rows(out);assert summary and all(r[0]=='ok' and r[2]=='0' for r in summary);summaries[features+'-doctests']=summary
 h.execute(features+'-clippy',[cargo,'clippy','--release','--locked','-p','hyperreal','--all-targets']+flags+['--','-D','warnings'])
 dump(h.R/'summaries-progress-v1.json',summaries)
# Exercise the debug-only consistency assertion in the actual implementation.
keys=h.build('debug-build',['test','--locked','-p','hyperreal','--lib']);assert len(keys)==1
summary,_,_,_=h.test('debug-library',keys[0]);assert len(summary)==1 and summary[0][:5]==('ok','817','0','0','0'),summary;summaries['debug-library']=summary
h.execute('docs',[cargo,'doc','--release','--locked','-p','hyperreal','--all-features','--no-deps'])
h.execute('workspace-format',[cargo,'fmt','--all','--','--check'])
h.execute('included-source-format',[rustfmt,'--edition','2024','--check','--config','max_width=100,skip_children=true',source,str(W/'baseline-node/exact_sign_cache_tests.rs')],limit=60)
h.verify();dump(h.R/'result-v1.json',{'passed':True,'summaries':summaries,'commands':h.commands,'artifacts_sha256':{k:v['sha256'] for k,v in h.artifacts.items()},'debug_consistency_checks_executed':True,'original_existing_tests_restored_without_diagnostic_print':True,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'scalar_qualification_passed':True,'summary_groups':len(summaries),'runtime_admitted':False}),flush=True)
