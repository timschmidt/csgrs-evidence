# Publication-guard allocation and size control

This is a correctness repair; no speedup is required or claimed. Preserve the
fixed 20-representation public lifecycle in the repository's unchanged
hyperreal/examples/allocation_profile.rs. Each fresh process first warms shared
constants and then measures 64 construct/facts/refine/export-to-f64/invert/drop
lifecycles per representation. This fixture tests requested Rust allocation
payload, not allocator overhead, GMP allocation, RSS or mathematical correctness
by itself. Independent semantic regressions and complete consumer tests supply
the latter evidence.

Build baseline and candidate from the same pinned current source and lockfile
in two new empty /tmp targets, with the same compiler, flags and features.
Only the candidate's exact-sign publication method differs in production code.
Assert Cargo rebuilt the Hyperreal library and archive distinct copied binaries
before any other build. Preserve every source and artifact hash. Use five
alternating process pairs, AB / BA / AB / BA / AB, each with the original
60-second focused limit. Record all rows, including any allocation growth.
Require the same 20 representation labels, iteration counts and successful
completed processes. Report allocation calls, bytes, peak payload and retained
payload separately. Binary file size and ELF section sizes are descriptive.
The harness process duration includes startup and is not a per-operation
benchmark; do not interpret it as a speedup.

No policy, fixture, resolution or output materialization is changed. All
original root, Disk B, /tmp, memory, command, log and reserve limits remain in
force. No build or other workload runs concurrently with these measurements.
