"""Check the changed scalar and immediate consumers with Rust 1.95."""
import json,os
from pathlib import Path
from harness_v4 import Harness,W,N,O,U,sha,dump
assert json.loads((N/'sign-cache-publication-downstream-v1/result-v1.json').read_text())['passed']
source=json.loads((N/'sign-cache-publication-candidate-v1/result-v1.json').read_text())['candidate_source']
target=U/'target-msrv-v1';assert not target.exists();target.mkdir();h=Harness('msrv-v1',{'crates/hyperreal/src/computable/node/representation.rs':source},target=target)
tools=json.loads((O/'docs/evidence/2026-10-17-in-scope-msrv/review-v1.json').read_text())['tool_sha256'];assert all(sha(p)==v for p,v in tools.items())
root=Path('/home/tim/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin');os.environ.update(RUSTC=str(root/'rustc'),RUSTDOC=str(root/'rustdoc'),RUSTUP_TOOLCHAIN='1.95.0-x86_64-unknown-linux-gnu')
dump(h.R/'compiler-v1.json',{'compiler':'1.95.0','tools_sha256':tools,'environment':{k:os.environ[k] for k in ['RUSTC','RUSTDOC','RUSTUP_TOOLCHAIN']},'runtime_tests_rerun':False,'clippy_on_msrv_run':False})
for label,flags in [('all',['--all-features']),('minimal',['--no-default-features'])]:h.execute(label,[str(root/'cargo'),'check','--locked','-p','hyperreal','-p','hyperlimit','-p','hypercurve','--all-targets']+flags)
h.verify();dump(h.R/'result-v1.json',{'passed':True,'commands':h.commands,'compiler':'1.95.0','all_targets':True,'features':['all','no-default'],'tools_sha256':tools,'runtime_tests_rerun':False,'clippy_on_msrv_run':False,'source_changes_applied_to_main':False,'runtime_admitted':False,'full_plan_complete':False});print('affected compiler-floor checks passed',flush=True)
