"""Pinned scalar investigation with frozen executable copies for every build."""
import gzip,json,os,re,shutil,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs';U=Path('/tmp/csgrs-sign-cache-validation-20261018-v1');T=U/'target'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1')
from validation_runner_v1 import run,dump,sha,resources,reasons
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';os.environ['RUSTDOCFLAGS']='-D warnings'
cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'));rustfmt=str(Path(cargo).with_name('rustfmt'))
def rows(out):return re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
class Harness:
 def __init__(self,phase,overrides=None):
  self.phase=phase;self.R=N/('sign-cache-publication-'+phase);self.A=U/(phase+'-artifacts');assert not self.R.exists() and not self.A.exists();self.R.mkdir();self.A.mkdir();self.commands={};self.artifacts={};self.overrides=dict(overrides or {})
  self.prep=json.loads((W/'baseline-preparation-v1.json').read_text());self.pins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));self.overlay_pins=dict(self.prep['overlay_sha256']);self.overlay_pins.update({str(p):sha(p) for p in self.overrides.values()});self.base_artifact=json.loads((N/'sign-cache-publication-baseline-v1/result-v1.json').read_text())['artifact'];self.inherited_artifacts={}
  for manifest in sorted(U.glob('*-artifacts/executable*-v1.json')):
   data=json.loads(manifest.read_text());items=[data] if 'copy' in data else data.values()
   for row in items:self.inherited_artifacts[row['copy']]=row['sha256']
  dump(self.R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'phase':phase,'contract_sha256':sha(W/'contract-v1.md'),'tmp_contract_sha256':sha(W/'tmp-contract-v1.json'),'source_pins_sha256':sha(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'overlay_sha256':self.overlay_pins,'file_overrides':{k:str(v) for k,v in self.overrides.items()},'source_root':str(O),'target':str(T),'original_baseline_binary_preserved':self.base_artifact,'production_source_changed':False,'inherited_executed_copies_sha256':self.inherited_artifacts})
 def verify(self):
  assert all(sha(O/p)==h for p,h in self.pins.items())
  assert all(sha(p)==h for p,h in self.overlay_pins.items())
  assert sha(self.base_artifact['copy'])==self.base_artifact['sha256']
  assert all(sha(p)==h for p,h in self.inherited_artifacts.items())
  assert all(sha(v['copy'])==v['sha256'] for v in self.artifacts.values())
  assert not reasons(resources())
 def execute(self,label,args,binary=False,allow_failure=False,limit=1800):
  self.verify();name='sign-cache-publication-'+self.phase+'-'+label;scratch=N/'scratch'/name
  argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(T),str(T),'--bind',str(scratch),str(scratch),'--chdir',str(scratch if binary else O)]
  for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
  for kind in ['directory_overlay','file_overlay']:
   row=self.prep[kind];argv+=['--ro-bind',row['source'],row['destination']]
  for dest,p in self.overrides.items():argv+=['--ro-bind',str(p),str(O/dest)]
  for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
  try:r=run(name,argv+list(map(str,args)),O,target=T,wall_seconds=limit)
  except RuntimeError:
   r=json.loads((N/'logs'/name/'result.json').read_text());self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands)
   if r['stops'] or not allow_failure or r['exit_code']!=101:raise
  self.commands[label]=r;dump(self.R/'progress-v1.json',self.commands);self.verify()
  out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M);return out,err,r
 def build(self,label,args):
  out,_,_=self.execute(label,[cargo]+args+['--no-run','--message-format=json'])
  found=[]
  for line in out.splitlines():
   if not line.startswith('{'):continue
   item=json.loads(line)
   if item.get('reason')!='compiler-artifact' or not item.get('executable'):continue
   name=item['target']['name']+'-'+item['target']['kind'][0]+('-tests' if item['profile']['test'] else '-program');key=label+'--'+name;assert key not in self.artifacts
   p=Path(item['executable']);copy=self.A/key;shutil.copy2(p,copy);assert sha(p)==sha(copy)
   self.artifacts[key]={'copy':str(copy),'compiled_path':str(p),'sha256':sha(copy),'bytes':copy.stat().st_size,'features':item['features'],'target':item['target'],'profile':item['profile']};found.append(key)
  dump(self.A/'executables-v1.json',self.artifacts);self.verify();assert found;return found
 def test(self,label,key,filters=None,allow_failure=False,limit=1800):
  args=[self.artifacts[key]['copy']]+list(filters or [])+['--nocapture','--test-threads=1']
  out,err,r=self.execute(label,args,binary=True,allow_failure=allow_failure,limit=limit);return rows(out),out,err,r
