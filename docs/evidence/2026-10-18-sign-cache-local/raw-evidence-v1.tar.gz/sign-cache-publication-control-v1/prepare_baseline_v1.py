"""Freeze current native scalar source and add acceptance tests only."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
BASE='a1ffc2de7151f0a49229f186001ceae04839d38f'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
os.environ['GIT_OPTIONAL_LOCKS']='0'
GIT=['git','-c','core.splitIndex=true','-c','index.version=4','-c','maintenance.auto=false','-c','gc.auto=0']
assert subprocess.check_output(GIT+['rev-parse','HEAD'],cwd=O,text=True).strip()==BASE
review=json.loads((W/'source-review-v1.json').read_text());assert all(sha(O/p)==h for p,h in review['source_sha256'].items())
node=Path('crates/hyperreal/src/computable/node');dest=W/'baseline-node';assert not dest.exists();shutil.copytree(O/node,dest)
test=W/'formatted-tests-v1.rs';assert test.exists();shutil.copy2(test,dest/'exact_sign_cache_tests.rs')
facade=W/'baseline-node.rs';assert not facade.exists();facade.write_text((O/node.with_suffix('.rs')).read_text()+'include!("node/exact_sign_cache_tests.rs");\n')
files={str(p):sha(p) for p in dest.rglob('*') if p.is_file()};files[str(facade)]=sha(facade)
record={'revision':BASE,'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'source_review_sha256':sha(W/'source-review-v1.json'),'test_sha256':sha(test),'directory_overlay':{'source':str(dest),'destination':str(O/node)},'file_overlay':{'source':str(facade),'destination':str(O/node.with_suffix('.rs'))},'overlay_sha256':files,'production_change_prepared':False,'tests_executed':False,'runtime_admitted':False}
p=W/'baseline-preparation-v1.json';assert not p.exists();p.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(json.dumps({'overlay_files':len(files),'tests_prepared':4,'production_change_prepared':False}))
