"""Reproduce stale sign publication on the pinned current implementation."""
import gzip,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;N=W.parent;O=N.parent/'csgrs'
V=Path('/run/media/tim/Disk B/csgrs-properties-validation-2026-10-17-v1');M=Path('/dev/shm/csgrs-validation-disk-b-20261017-v1');U=Path('/tmp/csgrs-sign-cache-validation-20261018-v1');T=U/'target';A=U/'baseline-artifacts';R=N/'sign-cache-publication-baseline-v1'
assert (N/'circle-envelope-candidate-v1/result-v1.json').exists(), 'finish original circle gates first'
assert not U.exists() and not R.exists() and not (W/'tmp-contract-v1.json').exists()
U.mkdir(mode=0o700);T.mkdir();A.mkdir();R.mkdir()
(W/'tmp-contract-v1.json').write_text(json.dumps({'path':str(U),'initial_free_bytes':shutil.disk_usage(U).free,'net_consumption_limit_bytes':5*1024**3,'other_resource_contract_sha256':'6c8cce0beb66399e924b4571d516419132986eb18a181514c86a4fe0235ef4c7','user_previously_authorized_tmp_validation':True,'persistent_evidence_at':str(N),'volatile_targets':True},indent=2,sort_keys=True)+'\n')
sys.path.insert(0,str(W));from validation_runner_v1 import run,dump,sha,resources,reasons
compiler=json.loads((V/'cargo-preparation-protocol-v1.json').read_text());assert all(sha(p)==h for p,h in compiler['tool_sha256'].items());os.environ.update(compiler['additional_environment']);os.environ['CARGO_NET_OFFLINE']='true';cargo=str(Path(compiler['additional_environment']['RUSTC']).with_name('cargo'));rustfmt=str(Path(cargo).with_name('rustfmt'))
pins=json.loads(gzip.decompress((N/'point-rational-main-integration-v2/source-pins-v1.json.gz').read_bytes()));commands={};artifact=None
name='sign-cache-publication-baseline-format-v1';commands['format']=run(name,[rustfmt,'--edition','2024','--config','max_width=100,skip_children=true'],W,stdin=(W/'tests-v1.rs').read_bytes(),wall_seconds=60)
shutil.copy2(N/'logs'/name/'stdout',W/'formatted-tests-v1.rs')
subprocess.run([sys.executable,str(W/'prepare_baseline_v1.py')],check=True)
prep=json.loads((W/'baseline-preparation-v1.json').read_text());overlays=prep['overlay_sha256']
dump(R/'protocol-v1.json',{'helper_sha256':sha(Path(__file__)),'contract_sha256':sha(W/'contract-v1.md'),'preparation_sha256':sha(W/'baseline-preparation-v1.json'),'compiler':compiler,'source_root':str(O),'source_pins':str(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'source_pins_sha256':sha(N/'point-rational-main-integration-v2/source-pins-v1.json.gz'),'overlay_sha256':overlays,'target':str(T),'tmp_contract_sha256':sha(W/'tmp-contract-v1.json'),'no_circle_envelope_or_exact_importer_change':True,'production_change_prepared':False})
def verify():
 assert all(sha(O/p)==h for p,h in pins.items())
 assert all(sha(p)==h for p,h in overlays.items())
 if artifact:assert sha(artifact['copy'])==artifact['sha256']
 assert not reasons(resources())
def execute(label,args,binary=False,allow_failure=False):
 verify();name='sign-cache-publication-baseline-'+label+'-v1';scratch=N/'scratch'/name
 argv=['/usr/bin/bwrap','--die-with-parent','--ro-bind','/','/','--dev','/dev','--ro-bind','/proc','/proc','--ro-bind',str(V),str(M),'--bind',str(T),str(T),'--bind',str(scratch),str(scratch),'--chdir',str(scratch if binary else O)]
 for physical,child in [(V/'cargo-home-v1',M/'cargo-home-v1'),(V/'gmp-cache-v1',M/'gmp-cache-v1'),(N/'xdg-cache',N/'xdg-cache')]:argv+=['--bind',str(physical),str(child)]
 for kind in ['directory_overlay','file_overlay']:
  row=prep[kind];argv+=['--ro-bind',row['source'],row['destination']]
 for k,v in {'CARGO_HOME':str(M/'cargo-home-v1'),'CARGO_TARGET_DIR':str(T),'TMPDIR':str(scratch),'XDG_CACHE_HOME':str(N/'xdg-cache'),'GMP_MPFR_SYS_CACHE':str(M/'gmp-cache-v1')}.items():argv+=['--setenv',k,v]
 try:r=run(name,argv+args,O,target=T,wall_seconds=60 if binary else 1800)
 except RuntimeError:
  r=json.loads((N/'logs'/name/'result.json').read_text());commands[label]=r;dump(R/'progress-v1.json',commands)
  if r['stops'] or not allow_failure or r['exit_code']!=101:raise
 commands[label]=r;dump(R/'progress-v1.json',commands);verify()
 out=(N/'logs'/name/'stdout').read_text();err=(N/'logs'/name/'stderr').read_text();assert not re.search(r'^(?:warning:|warning\[)|(?:Compiling|Checking) hypervoxel\b',err,re.M);return out,err,r
out,_,_=execute('build',[cargo,'test','--release','--locked','-p','hyperreal','--lib','--no-run','--message-format=json'])
items=[json.loads(l) for l in out.splitlines() if l.startswith('{')];items=[r for r in items if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='hyperreal'];assert len(items)==1
item=items[0];physical=Path(item['executable']);copy=A/'hyperreal-lib';shutil.copy2(physical,copy);assert sha(copy)==sha(physical);artifact={'copy':str(copy),'compiled_path':str(physical),'sha256':sha(copy),'bytes':copy.stat().st_size,'features':item['features']};dump(A/'executable-v1.json',artifact)
out,err,r=execute('regressions',[str(copy),'exact_sign_cache_tests::','--nocapture','--test-threads=1'],binary=True,allow_failure=True)
summary=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',out,re.M)
expected=['unresolved_publications_preserve_certified_signs_and_other_facts','delayed_unresolved_writer_cannot_erase_a_completed_proof','late_unknown_preserves_a_structurally_proved_quadratic_sign']
assert len(summary)==1 and summary[0][:5]==('FAILED','1','3','0','0'),summary
for name in expected:assert re.search(r'^test .*::'+name+r' \.{3} FAILED$',out,re.M),name
assert '(None, None, true)' in err and 'assertion `left == right` failed' in err
verify();dump(R/'result-v1.json',{'reproduced':True,'expected_failed_tests':expected,'summary':summary,'baseline_positive_control_passed':True,'commands':commands,'artifact':artifact,'current_production_method_tested':True,'no_numeric_approximation_in_quadratic_case':True,'source_unchanged':True,'implementation_prepared':False,'runtime_admitted':False,'full_plan_complete':False});print(json.dumps({'reproduced':True,'expected_failed_tests':3,'positive_controls_passed':1}),flush=True)
