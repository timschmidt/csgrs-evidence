"""Qualify the owning-layer publication guard against unchanged regressions."""
import json,shutil
from pathlib import Path
from harness_v1 import Harness,W,N,O,sha,dump,run,rustfmt
baseline=json.loads((N/'sign-cache-publication-baseline-v1/result-v1.json').read_text());assert baseline['reproduced']
seed=json.loads((N/'sign-cache-publication-baseline-seed-v1/result-v1.json').read_text());assert seed['passed'] and seed['observations'][0].endswith(': Invalid')
prep=json.loads((W/'candidate-preparation-v1.json').read_text());raw=W/'candidate-node/representation.rs';assert sha(raw)==prep['candidate_source_sha256_before_format']
name='sign-cache-publication-candidate-format-v1';format_result=run(name,[rustfmt,'--edition','2024','--config','max_width=100,skip_children=true'],W,stdin=raw.read_bytes(),wall_seconds=60)
formatted=W/'candidate-formatted-representation-v1.rs';assert not formatted.exists();shutil.copy2(N/'logs'/name/'stdout',formatted)
h=Harness('candidate-v1',{'crates/hyperreal/src/computable/node/representation.rs':formatted,'crates/hyperreal/src/computable/node/tests.rs':W/'seed-control-tests-v1.rs'});h.commands['format']=format_result
keys=h.build('build',['test','--release','--locked','-p','hyperreal','--lib']);assert len(keys)==1
summary,_,_,_=h.test('regressions',keys[0],['exact_sign_cache_tests::'],limit=60);assert len(summary)==1 and summary[0][:5]==('ok','4','0','0','0'),summary
full,out,err,_=h.test('library',keys[0]);assert len(full)==1 and full[0][:5]==('ok','817','0','0','0'),full
assert 'preexisting atan fixture sign before unresolved seed: Invalid' in err
h.verify();dump(h.R/'result-v1.json',{'passed':True,'new_tests_summary':summary,'full_library_summary':full,'new_tests_included_in_full_total':True,'legacy_unresolved_fixture_remains_exercised':True,'baseline_regression_tests_byte_identical':True,'commands':h.commands,'artifact':h.artifacts[keys[0]],'candidate_source':str(formatted),'candidate_source_sha256':sha(formatted),'source_changes_applied_to_main':False,'runtime_admitted':False,'remaining':['additional scalar features and integration tests','debug assertions','affected downstream checks','proportionate cost/layout','Clippy/docs/format','final main integration'],'full_plan_complete':False});print(json.dumps({'regressions_passed':4,'default_library_passed':817,'runtime_admitted':False}),flush=True)
