"""Check that an existing deliberately unresolved test fixture stays meaningful."""
import json
from pathlib import Path
from harness_v1 import Harness,W,N,sha,dump,rows
h=Harness('baseline-seed-v1',{'crates/hyperreal/src/computable/node/tests.rs':W/'seed-control-tests-v1.rs'})
keys=h.build('build',['test','--release','--locked','-p','hyperreal','--lib']);assert len(keys)==1
summary,out,err,r=h.test('control',keys[0],['computable::node::tests::atan_reduction_requires_a_positive_sign_for_large_reciprocal_shortcut','--exact'],limit=60)
assert len(summary)==1 and summary[0][:5]==('ok','1','0','0','0'),summary
observations=[line for line in err.splitlines() if 'preexisting atan fixture sign' in line];assert len(observations)==1
h.verify();dump(h.R/'result-v1.json',{'passed':True,'summary':summary,'observations':observations,'commands':h.commands,'artifact':h.artifacts[keys[0]],'production_changed':False,'runtime_admitted':False});print(json.dumps({'fixture_control':observations}),flush=True)
