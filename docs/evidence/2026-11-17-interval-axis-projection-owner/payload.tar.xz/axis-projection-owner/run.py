import os, json, subprocess, time, pathlib, sys
stage=pathlib.Path('/tmp/interval-refactor/axis-projection-owner')
ledger=stage/'commands.json'
rows=json.loads(ledger.read_text()) if ledger.exists() else []
used=sum(r['wall_seconds'] for r in rows)
assert len(rows)<120 and used<3600
label=sys.argv[1]; cmd=sys.argv[2:]
env=os.environ.copy()
env.update(CARGO_HOME='/dev/shm/interval-cancellation-cargo-home', CARGO_TARGET_DIR='/dev/shm/interval-axis-projection/target', CARGO_BUILD_JOBS='12')
t=time.monotonic()
with (stage/(label+'.log')).open('wb') as out:
    try:
        p=subprocess.run(cmd,cwd='/dev/shm/interval-axis-projection/csgrs',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=min(1800,3600-used))
        code=p.returncode
    except subprocess.TimeoutExpired:
        code=124
row=dict(label=label,command=cmd,exit_code=code,wall_seconds=time.monotonic()-t)
rows.append(row); ledger.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(row),flush=True)
sys.exit(code)
