from pathlib import Path
import subprocess,sys,json,os
s=Path('/tmp/interval-refactor/axis-projection-owner');runner=[sys.executable,str(s/'run.py')]
commands=[
('final-path-clippy',['cargo','+1.95.0','clippy','--offline','--locked','-p','hyperpath','--all-features','--all-targets','--','-D','warnings']),
('final-owner-format',['cargo','+1.95.0','fmt','-p','hyperpath','-p','hyperdynamics','--','--check']),
('candidate-diff-check',['git','diff','--check']),
('rustc-version',['rustc','+1.95.0','-vV']),
('cargo-version',['cargo','+1.95.0','-V']),
('candidate-typos',['/tmp/interval-refactor/coordinated-ci/bin/typos','crates/hyperdynamics/src/axis_projection.rs','crates/hyperdynamics/tests/axis_projection.rs','crates/hyperdynamics/tests/fixtures/axis_projection_trace.txt','crates/hyperdynamics/examples/axis_projection.rs','crates/hyperpath/tests/axis_projection_compatibility.rs','crates/hyperpath/src/routing/axis_projection.rs','docs/MIGRATIONS.md','crates/hyperdynamics/README.md','crates/hyperdynamics/CHANGELOG.md','crates/hyperpath/CHANGELOG.md']),
]
for label,args in commands:
    p=subprocess.run(runner+[label]+args)
    if p.returncode:raise SystemExit(p.returncode)
(s/'build-environment.json').write_text(json.dumps({'explicit':{'CARGO_HOME':'/dev/shm/interval-cancellation-cargo-home','CARGO_TARGET_DIR':'/dev/shm/interval-axis-projection/target','CARGO_BUILD_JOBS':'12'},'inherited_build_flags':{k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTDOCFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']},'toolchain':'1.95.0','qualification':'native local functionality only'},indent=2)+'\n')
