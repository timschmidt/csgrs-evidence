from pathlib import Path
import re,json,hashlib
root=Path('/dev/shm/interval-axis-projection/csgrs')
old=root/'crates/hyperpath/src/routing/axis_projection.rs'
source=old.read_text()
variants=sorted(set(re.findall(r'RouteCertificationError::(\w+)',source)))
route=(root/'crates/hyperpath/src/routing.rs').read_text()
comments=dict(re.findall(r'    /// ([^\n]+)\n    (\w+),',route[route.index('pub enum RouteCertificationError'):]))
comments={v:k for k,v in comments.items()}
error='''/// A rejected or undecided exact affine-axis projection.
///
/// Preserves input validation, scalar failure and independent replay failures.
/// It does not establish a new total-work or retained-memory bound.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AxisProjectionError {
'''
for v in variants:
    error+=f'    /// {comments[v]}\n    {v},\n'
error+='}\n\nimpl core::fmt::Display for AxisProjectionError {\n    fn fmt(&self, f: &mut core::fmt::Formatter<\'_>) -> core::fmt::Result {\n        match self {\n'
for v in variants:
    error+=f'            Self::{v} => f.write_str({json.dumps(comments[v])}),\n'
error+='        }\n    }\n}\n\nimpl core::error::Error for AxisProjectionError {}\n'
new=source.replace('use super::RouteCertificationError;','').replace('RouteCertificationError','AxisProjectionError')
new=new.replace('/// Dense machine-axis limits',error+'\n/// Dense machine-axis limits',1) if '/// Dense machine-axis limits' in new else new+'\n'+error
# Verify all executable algorithm and report definitions are retained byte-for-byte.
assert new[:new.index('/// A rejected or undecided')] == source.replace('use super::RouteCertificationError;','').replace('RouteCertificationError','AxisProjectionError') if new.endswith(error) else True
(root/'crates/hyperdynamics/src/axis_projection.rs').write_text(new)
wrapper='''//! Compatibility adapters for the Hyperdynamics affine-axis projection owner.

use hyperlimit::PredicatePolicy;
use hyperreal::Real;
use super::RouteCertificationError;
pub use hyperdynamics::axis_projection::{
    AffineSpanAxisProjection, AxisMotionLimits, AxisProjectedMotionLimitsReport,
    AxisProjectionBottleneck, AxisProjectionRowReport, PlannedAxisProjectedMotionLimits,
};
use hyperdynamics::axis_projection::AxisProjectionError;

impl From<AxisProjectionError> for RouteCertificationError {
    fn from(error: AxisProjectionError) -> Self {
        match error {
'''
for v in variants:
    wrapper+=f'            AxisProjectionError::{v} => Self::{v},\n'
wrapper+='''        }
    }
}

/// Plan exact scalar limits through the Hyperdynamics affine-axis owner.
///
/// Retains the legacy error type and the original complete report without copying it.
#[deprecated(since = "0.4.0", note = "use hyperdynamics::axis_projection::plan_axis_projected_motion_limits")]
pub fn plan_axis_projected_motion_limits(
    projections: &[AffineSpanAxisProjection],
    axis_limits: &[AxisMotionLimits],
    policy: PredicatePolicy,
) -> Result<PlannedAxisProjectedMotionLimits, RouteCertificationError> {
    hyperdynamics::axis_projection::plan_axis_projected_motion_limits(projections, axis_limits, policy)
        .map_err(Into::into)
}

/// Replay exact scalar limits through the Hyperdynamics affine-axis owner.
///
/// Retains the legacy error type and the original complete report without copying it.
#[deprecated(since = "0.4.0", note = "use hyperdynamics::axis_projection::certify_axis_projected_motion_limits")]
pub fn certify_axis_projected_motion_limits(
    projections: &[AffineSpanAxisProjection],
    axis_limits: &[AxisMotionLimits],
    maximum_path_feed: Real,
    maximum_path_acceleration: Real,
    maximum_path_jerk: Real,
    policy: PredicatePolicy,
) -> Result<AxisProjectedMotionLimitsReport, RouteCertificationError> {
    hyperdynamics::axis_projection::certify_axis_projected_motion_limits(
        projections, axis_limits, maximum_path_feed, maximum_path_acceleration, maximum_path_jerk, policy,
    ).map_err(Into::into)
}
'''
old.write_text(wrapper)
p=root/'crates/hyperdynamics/Cargo.toml'; s=p.read_text().replace('default = []','default = []\naxis-projection = ["dep:hyperreal", "dep:hyperlimit", "dep:hypersolve"]',1).replace('dispatch-trace = [','dispatch-trace = ["hyperlimit?/dispatch-trace", "hyperreal?/dispatch-trace", ',1).replace('[dependencies]','[dependencies]\nhyperlimit = { version = "0.5.0", path = "../hyperlimit", default-features = false, optional = true }',1); p.write_text(s)
p=root/'crates/hyperdynamics/src/lib.rs'; p.write_text(p.read_text()+'\n/// Exact affine dense-axis limit projection with retained inequality and bottleneck proofs.\n#[cfg(feature = "axis-projection")]\npub mod axis_projection;\n')
p=root/'crates/hyperpath/Cargo.toml'; s=p.read_text().replace('dispatch-trace = [','dispatch-trace = ["hyperdynamics/dispatch-trace", ',1).replace('[dependencies]','[dependencies]\nhyperdynamics = { version = "0.1.0", path = "../hyperdynamics", default-features = false, features = ["axis-projection"] }',1); p.write_text(s)
p=root/'crates/hyperpath/src/routing.rs'; p.write_text(p.read_text().replace('pub use axis_projection::{','#[allow(deprecated)] // Preserve legacy exports during the coordinated minor release.\npub use axis_projection::{',1))
p=root/'crates/hyperpath/src/lib.rs'; p.write_text(p.read_text().replace('pub use routing::{','#[allow(deprecated)] // Preserve legacy exports during the coordinated minor release.\npub use routing::{',1))
p=root/'crates/hyperpath/tests/path_primitives.rs'; s=p.read_text().replace('use hyperpath::{','#[allow(deprecated)] // Exercise the retained one-release compatibility entry points.\nuse hyperpath::{',1)
for name in ['affine_axis_projection_selects_and_replays_distinct_exact_bottlenecks','affine_axis_projection_rejects_empty_mismatched_negative_and_stationary_inputs','affine_axis_projection_generated_exact_bottleneck_replays']:
    s=s.replace('fn '+name,'#[allow(deprecated)] // This test intentionally exercises the legacy API.\nfn '+name,1)
p.write_text(s)
(root/'crates/hyperdynamics/examples/axis_projection.rs').write_text('''//! Project affine path limits and independently replay the selected result.
use hyperdynamics::axis_projection::{
    AffineSpanAxisProjection, AxisMotionLimits, certify_axis_projected_motion_limits,
    plan_axis_projected_motion_limits,
};
use hyperlimit::PredicatePolicy;
use hyperreal::Real;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let spans = [AffineSpanAxisProjection { absolute_axis_derivatives: vec![Real::one()] }];
    let axes = [AxisMotionLimits {
        maximum_velocity: Real::from(3),
        maximum_acceleration: Real::from(4),
        maximum_jerk: Real::from(5),
    }];
    let planned = plan_axis_projected_motion_limits(&spans, &axes, PredicatePolicy::STRICT)?;
    assert!(planned.all_satisfied());
    let replay = certify_axis_projected_motion_limits(
        &spans, &axes, planned.maximum_path_feed.clone(),
        planned.maximum_path_acceleration.clone(), planned.maximum_path_jerk.clone(),
        PredicatePolicy::STRICT,
    )?;
    assert_eq!(replay, planned.certification);
    Ok(())
}
''')
p=root/'crates/hyperdynamics/Cargo.toml';p.write_text(p.read_text()+'\n[[example]]\nname = "axis_projection"\nrequired-features = ["axis-projection"]\n')
# Exact mechanical movement is a review assertion, not a correctness proof.
expected=source.replace('use super::RouteCertificationError;','').replace('RouteCertificationError','AxisProjectionError')
actual=(root/'crates/hyperdynamics/src/axis_projection.rs').read_text().replace(error+'\n','').removesuffix('\n'+error)
assert actual==expected
Path('/tmp/interval-refactor/axis-projection-owner/movement.json').write_text(json.dumps({'original_sha256':hashlib.sha256(source.encode()).hexdigest(),'algorithm_unchanged_except_error_type':True,'mapped_variants':variants},indent=2)+'\n')
print('moved algorithm; exact mapping for',len(variants),'error variants')
