from pathlib import Path
import re,json,subprocess,hashlib
s=Path('/tmp/interval-refactor/axis-projection-owner');r=Path('/dev/shm/interval-axis-projection/csgrs')
base=json.loads((s/'contract.json').read_text())['baseline']
def git(*args):return subprocess.check_output(['git','-C',str(r),*args])
original=git('show',base+':crates/hyperpath/src/routing/axis_projection.rs').decode()
expected=original.replace('use super::RouteCertificationError;','').replace('RouteCertificationError','AxisProjectionError')
actual=(r/'crates/hyperdynamics/src/axis_projection.rs').read_text().split('/// A rejected or undecided exact affine-axis projection.')[0]
assert re.sub(r'\s+','',actual)==re.sub(r'\s+','',expected)
trace=re.findall(r'^TRACE (TraceSnapshot \{.*?^\})',(s/'baseline-trace-output.log').read_text(),re.M|re.S)
assert len(trace)==16
assert (r/'crates/hyperdynamics/tests/fixtures/axis_projection_trace.txt').read_text()=='\n===\n'.join(trace)+'\n'
for row in json.loads((s/'consumer-comparison.json').read_text()):assert row['exact_match']
rows=json.loads((s/'commands.json').read_text());bad=[x for x in rows if x['exit_code']]
assert len(bad)==1 and bad[0]['label']=='baseline-missing-direct' and bad[0]['exit_code']==101
assert 'error[E0432]: unresolved import `hyperdynamics::axis_projection`' in (s/'baseline-missing-direct.log').read_text()
assert len(rows)<120 and sum(x['wall_seconds'] for x in rows)<3600
suites={}
for name in ['final-owner-tests','owner-minimal-tests','interface-core-tests']:
    text=(s/(name+'.log')).read_text(); counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed;',text)]
    assert counts and 'test result: FAILED' not in text
    suites[name]={'passed':sum(counts),'suites':len(counts)}
assert 'exact_diagonal_g1_uses_dense_axis_projection_and_lowers_to_terminal_steps ... ok' in (s/'interface-core-tests.log').read_text()
# Keep the canonical witness and all existing Interface fixtures byte-identical.
iroot=Path('/dev/shm/interval-axis-projection/alumina-interface')
assert subprocess.check_output(['git','-C',str(iroot),'diff','5b532c803af86dd9e3d7a66f3651163fd2f7c68b','--','crates/alumina-interface-core/src/machine_profile.rs'])==b''

original_tests=git('show',base+':crates/hyperpath/tests/path_primitives.rs').decode()
current_tests=(r/'crates/hyperpath/tests/path_primitives.rs').read_text()
current_tests=''.join(line for line in current_tests.splitlines(keepends=True) if not ('#[allow(deprecated)] // Exercise the retained one-release compatibility entry points.' in line or '#[allow(deprecated)] // This test intentionally exercises the legacy API.' in line))
assert current_tests==original_tests
assert json.loads((s/'baseline-reproduction.json').read_text())['both_fresh_process_complete_outputs_match_initial_baseline']

state=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert state[0]=='T' and state[19]=='38218939'
assert not Path('/proc/3416600').exists()
hashes={
'/tmp/interval-refactor/coordinated-ci/quiet-workflow-executed-plan.json':'1674343e351f5abe53f9c7bfdc9a5414f514ae15f38f3b328b1652ef6fb981b4',
'/mnt/development/.interval-refactor-build/coordinated-ci/stable/release/deps/hyperdrc-1844e5fbe37d2531':'dc5e86b407ce5d5134f584f6a970baf772240be1da6fc2502fe2f6902e97db11'}
for path,digest in hashes.items():assert hashlib.file_digest(open(path,'rb'),'sha256').hexdigest()==digest
result={'suites':suites,'algorithm_and_report_tokens_preserved_except_error_type':True,'baseline_trace_snapshots':16,'full_consumer_comparisons':4,'legacy_errors_mapped':13,'canonical_fixture_unchanged':True,'commands_recorded_before_audit':len(rows),'command_wall_seconds_before_audit':sum(x['wall_seconds'] for x in rows),'held_release_queue_unchanged':True,'performance_memory_size_admission':'not claimed'}
(s/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
