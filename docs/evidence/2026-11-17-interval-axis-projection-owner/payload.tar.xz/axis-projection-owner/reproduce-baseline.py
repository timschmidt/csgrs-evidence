from pathlib import Path
import subprocess,sys,json,hashlib,tomllib
s=Path('/tmp/interval-refactor/axis-projection-owner');base=s/'baseline-consumer';base.mkdir();(base/'src').mkdir()
manifest=(s/'consumer/Cargo.toml').read_text().replace('direct = ["hyperdynamics/axis-projection"]','direct = []').replace('/dev/shm/interval-axis-projection/csgrs','/mnt/development/csgrs')
(base/'Cargo.toml').write_text(manifest);(base/'src/main.rs').write_bytes((s/'consumer/src/main.rs').read_bytes())
runner=[sys.executable,str(s/'run.py')];cargo=['cargo','+1.95.0']
def run(label,args):
    p=subprocess.run(runner+[label]+args)
    if p.returncode:raise SystemExit(p.returncode)
run('reproduced-baseline-lock',cargo+['generate-lockfile','--offline','--manifest-path',str(base/'Cargo.toml')])
old=tomllib.loads((base/'Cargo.lock').read_text());new=tomllib.loads((s/'consumer/Cargo.lock').read_text())
def versions(lock):return sorted((p['name'],p['version'],p.get('source'),p.get('checksum')) for p in lock['package'])
assert versions(old)==versions(new)
for label,args in [('default',[]),('trace',['--features','trace'])]:
    run('reproduced-baseline-'+label+'-build',cargo+['build','--offline','--locked','--manifest-path',str(base/'Cargo.toml')]+args)
    run('reproduced-baseline-'+label+'-output',['/dev/shm/interval-axis-projection/target/debug/axis-projection-owner-consumer'])
    assert (s/('reproduced-baseline-'+label+'-output.log')).read_bytes()==(s/('baseline-'+label+'-output.log')).read_bytes()
(s/'baseline-reproduction.json').write_text(json.dumps({'baseline':'52b6d1bab627ab212eda80fbc0d4c08a4cd23176','source_path':'/mnt/development/csgrs','initial_lock_replaced_during_candidate_resolution':True,'baseline_lock_reconstructed_on_unchanged_source':True,'all_package_versions_sources_and_checksums_match_candidate':True,'reconstructed_lock_sha256':hashlib.sha256((base/'Cargo.lock').read_bytes()).hexdigest(),'both_fresh_process_complete_outputs_match_initial_baseline':True,'cost_or_artifact_equivalence_claim':False},indent=2)+'\n')
print('baseline locked builds reproduced original complete reports and traces',flush=True)
