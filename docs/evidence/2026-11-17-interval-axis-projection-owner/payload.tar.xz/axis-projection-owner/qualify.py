from pathlib import Path
import subprocess,sys,json,hashlib
s=Path('/tmp/interval-refactor/axis-projection-owner')
runner=[sys.executable,str(s/'run.py')]
cargo=['cargo','+1.95.0']
rows=[]
def run(label,args):
    result=subprocess.run(runner+[label]+args)
    if result.returncode:
        raise SystemExit(result.returncode)
run('consumer-lock',cargo+['generate-lockfile','--offline','--manifest-path',str(s/'consumer/Cargo.toml')])
run('direct-consumer-lock',cargo+['generate-lockfile','--offline','--manifest-path',str(s/'direct-consumer/Cargo.toml')])
for label,project,features,exe in [
    ('legacy-default','consumer',[], 'axis-projection-owner-consumer'),
    ('legacy-trace','consumer',['--features','trace'], 'axis-projection-owner-consumer'),
    ('direct-default','direct-consumer',[], 'axis-projection-direct-consumer'),
    ('direct-trace','direct-consumer',['--features','trace'], 'axis-projection-direct-consumer'),
]:
    manifest=str(s/project/'Cargo.toml')
    run('candidate-'+label+'-build',cargo+['build','--offline','--locked','--manifest-path',manifest]+features)
    run('candidate-'+label+'-output',['/dev/shm/interval-axis-projection/target/debug/'+exe])
    reference=s/('baseline-trace-output.log' if 'trace' in label else 'baseline-default-output.log')
    actual=s/('candidate-'+label+'-output.log')
    assert actual.read_bytes()==reference.read_bytes(),label+' full report/trace mismatch'
    rows.append(dict(case=label,bytes=actual.stat().st_size,sha256=hashlib.sha256(actual.read_bytes()).hexdigest(),exact_match=True))
    run('candidate-'+label+'-clippy',cargo+['clippy','--offline','--locked','--manifest-path',manifest]+features+['--','-D','warnings'])
(s/'consumer-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
run('owner-minimal-tests',cargo+['test','--offline','--locked','-p','hyperdynamics','--no-default-features','--features','axis-projection','--test','axis_projection'])
run('owner-minimal-clippy',cargo+['clippy','--offline','--locked','-p','hyperdynamics','--no-default-features','--features','axis-projection','--all-targets','--','-D','warnings'])
run('owner-default-clippy',cargo+['clippy','--offline','--locked','-p','hyperdynamics','--no-default-features','--all-targets','--','-D','warnings'])
run('owner-all-clippy',cargo+['clippy','--offline','--locked','-p','hyperpath','-p','hyperdynamics','--all-features','--all-targets','--','-D','warnings'])
run('owner-docs',['env','RUSTDOCFLAGS=-D warnings']+cargo+['doc','--offline','--locked','-p','hyperpath','-p','hyperdynamics','--all-features','--no-deps'])
run('direct-example',cargo+['run','--offline','--locked','-p','hyperdynamics','--no-default-features','--features','axis-projection','--example','axis_projection'])
run('direct-dependencies',cargo+['tree','--offline','--locked','--manifest-path',str(s/'direct-consumer/Cargo.toml'),'-e','normal'])
tree=(s/'direct-dependencies.log').read_text()
assert 'hyperpath' not in tree and 'hypercurve' not in tree and 'hypermesh' not in tree
run('final-format',cargo+['fmt','--all','--','--check'])
print('functional owner qualification complete',flush=True)
