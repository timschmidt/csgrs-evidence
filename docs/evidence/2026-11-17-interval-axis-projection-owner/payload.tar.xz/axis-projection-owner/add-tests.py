from pathlib import Path
import re,json
s=Path('/tmp/interval-refactor/axis-projection-owner')
r=Path('/dev/shm/interval-axis-projection/csgrs')
source=(s/'consumer/src/main.rs').read_text()
source=source[source.index('use hyperdynamics'):]
start=source.index('#[cfg(not(feature = "direct"))]'); end=source.index('use hyperlimit::PredicatePolicy;')
source=source[:start]+source[end:]
source=source.replace('feature="trace"','feature="dispatch-trace"')
a=source.index('fn trace() {'); b=source.index('fn main() {')
source=source[:a]+'''fn trace() -> String {
    #[cfg(feature = "dispatch-trace")]
    { format!("{:#?}", hyperreal::dispatch_trace::take_trace()) }
    #[cfg(not(feature = "dispatch-trace"))]
    { String::new() }
}
#[test]
fn affine_axis_projection_retains_exact_results_and_ordered_dispatch() {
    let mut traces = Vec::new();
'''+source[b+len('fn main() {'):]
source=source.replace('trace();','traces.push(trace());')
idx=source.rfind('}')
source=source[:idx]+'''    #[cfg(feature = "dispatch-trace")]
    assert_eq!(traces.join("\n===\n"), include_str!("fixtures/axis_projection_trace.txt").trim_end());
'''+source[idx:]
(r/'crates/hyperdynamics/tests/axis_projection.rs').write_text('#![cfg(feature = "axis-projection")]\n\n'+source)
traces=re.findall(r'^TRACE (TraceSnapshot \{.*?^\})',(s/'baseline-trace-output.log').read_text(),re.M|re.S)
assert len(traces)==16
(r/'crates/hyperdynamics/tests/fixtures/axis_projection_trace.txt').write_text('\n===\n'.join(traces)+'\n')
variants=json.loads((s/'movement.json').read_text())['mapped_variants']
test='''//! Legacy entry points preserve their report carrier and typed failures.
use hyperdynamics::axis_projection::AxisProjectionError;
use hyperpath::RouteCertificationError;

#[test]
fn all_projection_errors_preserve_legacy_variants() {
'''
for v in variants:
    test+=f'    assert_eq!(RouteCertificationError::from(AxisProjectionError::{v}), RouteCertificationError::{v});\n'
test+='}\n'
(r/'crates/hyperpath/tests/axis_projection_compatibility.rs').write_text(test)
p=r/'docs/MIGRATIONS.md';text=p.read_text();i=text.index('\n')+1
p.write_text(text[:i]+'''
## Affine axis projection ownership (next coordinated minor release)

Enable Hyperdynamics `axis-projection` and import the projection inputs, reports,
`plan_axis_projected_motion_limits`, and `certify_axis_projected_motion_limits`
from `hyperdynamics::axis_projection`. The operation accepts affine spans with
exact absolute axis derivatives; this does not admit nonlinear machine maps or
curved-span acceleration/jerk projection.

Hyperpath keeps its original input/report names as reexports and its two function
entry points as deprecated adapters for at least one coordinated minor release.
Their `RouteCertificationError` results retain every existing variant. Direct
Hyperdynamics callers receive `AxisProjectionError`; converting it with `Into`
retains the legacy variant when an existing consumer error requires it. Reports,
row order, selected bottlenecks, predicate policy and independent replay semantics
are unchanged. Feed, lookahead and jerk scheduling remain in Hyperpath pending
separate migration; this change does not complete the path extraction.

'''+text[i:])
p=r/'crates/hyperdynamics/README.md';p.write_text(p.read_text()+'''
Enable `axis-projection` for `hyperdynamics::axis_projection`, the exact affine
span projection planner and replay API. Inputs retain dense axis velocity,
acceleration and jerk limits; outputs retain all inequality rows and exact
bottleneck equalities. Run `cargo run -p hyperdynamics --features axis-projection
--example axis_projection` for a direct consumer. This feature needs no geometry
crate. Nonlinear maps and curved-span higher derivatives require separate proofs.
''')
p=r/'crates/hyperdynamics/CHANGELOG.md';p.write_text(p.read_text().replace('## 0.1.0 (unreleased)','## 0.1.0 (unreleased)\n\n- Add opt-in exact affine axis-limit projection with retained bottleneck and\n  inequality replay reports, extracted from Hyperpath.',1))
p=r/'crates/hyperpath/CHANGELOG.md';text=p.read_text();i=text.index('\n')+1;p.write_text(text[:i]+'''\n## Next coordinated minor release

- Move affine dense-axis projection to Hyperdynamics. Retain report reexports
  and deprecated adapters with unchanged route errors for at least one release.
'''+text[i:])
print('added direct tests with',len(traces),'baseline full trace assertions; all',len(variants),'legacy error mappings')
