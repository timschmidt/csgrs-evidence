import pathlib,subprocess,sys
s=pathlib.Path('/tmp/interval-refactor/axis-projection-owner')
manifest='/dev/shm/interval-axis-projection/alumina-interface/Cargo.toml'
runner=[sys.executable,str(s/'run.py')]
cargo=['cargo','+1.95.0']
def run(label,args):
    p=subprocess.run(runner+[label]+args)
    if p.returncode: raise SystemExit(p.returncode)
run('interface-format',cargo+['fmt','--manifest-path',manifest,'--all'])
run('interface-core-tests',cargo+['test','--offline','--manifest-path',manifest,'-p','alumina-interface-core'])
run('interface-core-clippy',cargo+['clippy','--offline','--locked','--manifest-path',manifest,'-p','alumina-interface-core','--all-targets','--','-D','warnings'])
run('interface-format-check',cargo+['fmt','--manifest-path',manifest,'--all','--','--check'])
print('Interface local functional qualification complete; release/browser/cost gates remain open',flush=True)
