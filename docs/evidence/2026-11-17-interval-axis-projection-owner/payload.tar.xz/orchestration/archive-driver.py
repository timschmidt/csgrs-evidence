from pathlib import Path
import gzip,hashlib,importlib.util,io,json,shutil,subprocess,tarfile,time
root=Path('/tmp/interval-refactor');stage=root/'axis-projection-owner';out=Path('/dev/shm/interval-axis-projection/evidence');repo=Path('/mnt/development/csgrs-evidence');main=Path('/mnt/development/csgrs');record='docs/evidence/2026-11-17-interval-axis-projection-owner';dest=repo/record
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
start=time.monotonic();before=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain=v1') and not out.exists() and not dest.exists()
audit=json.loads((stage/'audit.json').read_text());assert audit['full_consumer_comparisons']==4 and audit['held_release_queue_unchanged']
refs=json.loads((stage/'candidate-revisions.json').read_text())
for entry in refs['candidates']:
    assert subprocess.check_output(['git','-C',entry['worktree'],'rev-parse','HEAD']).decode().strip()==entry['revision']
    assert not subprocess.check_output(['git','-C',entry['worktree'],'status','--porcelain=v1'])
out.mkdir();members={};origins=[]
def include(p,name):
    raw=p.read_bytes();assert name not in members;members[name]=raw;origins.append({'source':str(p),'path':name,'bytes':len(raw),'sha256':sha(raw),'mode':p.stat().st_mode&0o777})
for p in sorted(stage.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:include(p,'axis-projection-owner/'+p.relative_to(stage).as_posix())
include(Path(__file__),'orchestration/archive-driver.py')
with tarfile.open(out/'payload.tar.xz','w:xz',preset=3,format=tarfile.PAX_FORMAT) as archive:
    for name,raw in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=next(x['mode'] for x in origins if x['path']==name);info.mtime=0;archive.addfile(info,io.BytesIO(raw))
(out/'origins.json.gz').write_bytes(gzip.compress((json.dumps(origins,indent=2)+'\n').encode(),mtime=0))
seen=set()
with tarfile.open(out/'payload.tar.xz','r:xz') as archive:
    for m in archive:
        assert m.isfile() and m.name in members and m.name not in seen;seen.add(m.name);assert archive.extractfile(m).read()==members[m.name]
assert seen==members.keys()
for entry in origins:assert sha(Path(entry['source']).read_bytes())==entry['sha256']
(out/'README.md').write_bytes((root/'axis-projection-owner-archive-readme.md').read_bytes())
total=sum(p.stat().st_size for p in out.iterdir());free=shutil.disk_usage(repo).free
assert free-3*total-20*1024**2>=20*1024**3,(total,free)
shutil.copytree(out,dest)
subprocess.run(['git','-C',str(repo),'add','--sparse','--',record],check=True)
subprocess.run(['git','-C',str(repo),'diff','--cached','--check'],check=True)
changed=git('diff','--cached','--name-only').decode().splitlines();assert changed and all(p.startswith(record+'/') for p in changed)
spec=importlib.util.spec_from_file_location('manifest',main/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False}
rows=m.manifest(str(repo),git('write-tree').decode().strip());assert len(rows)==2
subprocess.run(['git','-C',str(repo),'-c','gc.auto=0','commit','-m','Preserve isolated affine axis projection functional qualification'],check=True,stdout=subprocess.PIPE)
revision=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1') and m.manifest(str(repo),revision)==rows
assert git('diff','--name-only',before,revision).decode().splitlines()==changed
for p in out.iterdir():assert git('show',revision+':'+record+'/'+p.name)==p.read_bytes()
_,count,size,digest=rows[1].split('\t')
result={'previous_revision':before,'revision':revision,'record':record,'row':rows[1],'files':int(count),'bytes':int(size),'sha256':digest,'payload_members':len(members),'payload_raw_bytes':sum(map(len,members.values())),'all_original_and_decoded_hashes_verified':True,'all_committed_files_verified':True,'previous_archive_paths_unchanged':True,'seconds':time.monotonic()-start}
(root/'axis-projection-owner-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
