<!-- BEGIN promoted_slow_offender_score -->
## `promoted_slow_offender_score`

Deterministic lexicase score for Hypersolve's retained fuzz offenders. The score is the average current best-of-five replay time; lower is better. Delta compares with the previous score, and derivative is the change in delta.

<!-- promoted_slow_score_nanos: 111387 -->
<!-- promoted_slow_previous_score_nanos: 28867 -->
<!-- promoted_slow_score_delta_nanos: 82520 -->

| Metric | Value |
| --- | ---: |
| Cases scored | 100 |
| Average score | 111.387 us |
| Delta | 82.520 us |
| Delta derivative | 83.237 us |

| Rank | Current Time | Fuzz target | Input |
| ---: | ---: | --- | --- |
| 1 | 3.449 ms | `bivariate_vertical_components` | `seed[106]` |
| 2 | 132.852 us | `failed_constraint_minimal_removals` | `seed[14]` |
| 3 | 130.348 us | `sketch_projected_arc_cubic_curve_tangent` | `seed[50]` |
| 4 | 120.855 us | `sketch_projected_arc_cubic_curve_tangent` | `seed[21]` |
| 5 | 119.389 us | `sketch_projected_cubic_curve_cubic_curve_g2` | `seed[7]` |
| 6 | 118.846 us | `sketch_projected_arc_cubic_curve_tangent` | `seed[22]` |
| 7 | 116.015 us | `sketch_projected_arc_cubic_curve_second_order_contact` | `seed[20]` |
| 8 | 114.888 us | `sketch_projected_point_on_cubic_curve` | `seed[17]` |
| 9 | 114.195 us | `sketch_projected_cubic_curve_cubic_curve_g2` | `seed[22]` |
| 10 | 113.666 us | `sketch_projected_cubic_line_tangent` | `seed[22]` |

<!-- END promoted_slow_offender_score -->









# Hypersolve Benchmarks

This file is updated automatically by the benchmark binaries.

<!-- BEGIN COMPLETE BENCHMARK REPORT -->
## Complete generated benchmark report

Every registered benchmark target is catalogued below. Every Criterion result found under `target/criterion` is included without a name or implementation filter; non-Criterion targets write their own linked reports. Each timing binary refreshes this section after it runs.

Run the complete non-instrumented timing set with:

```sh
cargo bench
cargo bench --bench retained_fuzz --features interval-lattice
```

Regenerate this Markdown from stored Criterion data without rerunning benchmarks:

```sh
cargo run --example write_benchmarks_md
```

### Registered benchmark suites

| Target | Kind | Required features | Command | Generated report |
| --- | --- | --- | --- | --- |
| `algebraic_fiber` | custom timing | `default` | `cargo bench --bench algebraic_fiber` | [algebraic_fiber_benchmarks.md](algebraic_fiber_benchmarks.md) |
| `certification` | Criterion timing | `default` | `cargo bench --bench certification` | this file |
| `competitive` | Criterion timing | `default` | `cargo bench --bench competitive` | this file |
| `dispatch_trace` | diagnostic | `dispatch-trace` | `cargo bench --bench dispatch_trace --features dispatch-trace` | [dispatch_trace.md](dispatch_trace.md) |
| `expression_program` | Criterion timing | `expression-program` | `cargo bench --bench expression_program --features expression-program` | this file |
| `representations` | Criterion timing | `default` | `cargo bench --bench representations` | this file |
| `retained_fuzz` | Criterion timing | `interval-lattice` | `cargo bench --bench retained_fuzz --features interval-lattice` | this file |
| `taylor_composition` | Criterion timing | `taylor-composition` | `cargo bench --bench taylor_composition --features taylor-composition` | this file |
| `taylor_noise` | Criterion timing | `taylor-noise` | `cargo bench --bench taylor_noise --features taylor-noise` | this file |
| `taylor_polynomial` | Criterion timing | `taylor-polynomial` | `cargo bench --bench taylor_polynomial --features taylor-polynomial` | this file |
| `cgal_quadratic` | external exact comparison | `CGAL, GMP` | `benches/competitors/run_cgal_quadratic.sh` | [cgal_quadratic_benchmarks.md](cgal_quadratic_benchmarks.md) |

### Comparative results

Rows sharing a Criterion group and input are compared when they expose distinct implementations. Ratios are elapsed time relative to the fastest stored row; they do not imply identical guarantees or output semantics.

No paired Criterion results are currently stored.

### All Criterion results

| Benchmark | Mean | 95% CI | Median | Change vs baseline | Throughput |
| --- | ---: | ---: | ---: | ---: | ---: |
| `promoted_fuzz_worst_performers/bivariate_vertical_components_seed_106` | 3.67 ms | 3.45 ms - 4.02 ms | 3.49 ms | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_10` | 82.04 us | 73.65 us - 92.11 us | 73.63 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_14` | 73.60 us | 71.75 us - 77.16 us | 71.79 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_15` | 74.28 us | 74.17 us - 74.38 us | 74.33 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_18` | 110.46 us | 110.25 us - 110.69 us | 110.45 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_19` | 75.54 us | 75.43 us - 75.66 us | 75.44 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_2` | 72.73 us | 72.63 us - 72.81 us | 72.75 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_23` | 83.11 us | 72.47 us - 94.01 us | 72.37 us | - | - |
| `promoted_fuzz_worst_performers/failed_constraint_minimal_removals_seed_58` | 85.35 us | 72.49 us - 98.35 us | 72.51 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_12` | 107.89 us | 95.63 us - 116.84 us | 116.09 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_13` | 68.66 us | 68.61 us - 68.72 us | 68.63 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_20` | 93.48 us | 79.73 us - 107.14 us | 105.01 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_21` | 67.94 us | 67.83 us - 68.08 us | 67.88 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_22` | 93.25 us | 79.25 us - 107.29 us | 91.21 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_3` | 68.75 us | 68.71 us - 68.79 us | 68.76 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_7` | 68.65 us | 68.59 us - 68.70 us | 68.61 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_8` | 68.27 us | 68.21 us - 68.32 us | 68.23 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_second_order_contact_seed_9` | 88.55 us | 74.31 us - 102.80 us | 75.99 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_21` | 88.32 us | 75.08 us - 102.91 us | 70.36 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_22` | 69.00 us | 68.74 us - 69.31 us | 68.94 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_23` | 67.73 us | 67.66 us - 67.82 us | 67.70 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_50` | 81.38 us | 73.42 us - 92.61 us | 73.53 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_6` | 93.26 us | 79.08 us - 107.02 us | 96.75 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_cubic_curve_tangent_seed_9` | 84.76 us | 71.86 us - 97.81 us | 67.60 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_line_tangent_seed_12` | 68.09 us | 68.05 us - 68.13 us | 68.06 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_line_tangent_seed_6` | 99.51 us | 86.44 us - 111.26 us | 112.42 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_line_tangent_seed_7` | 67.88 us | 67.40 us - 68.71 us | 67.46 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_arc_line_tangent_seed_9` | 99.40 us | 85.42 us - 110.44 us | 114.81 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_c2_seed_9` | 82.24 us | 74.03 us - 90.97 us | 76.14 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_g2_seed_22` | 108.31 us | 95.35 us - 121.12 us | 121.02 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_g2_seed_42` | 67.62 us | 67.57 us - 67.67 us | 67.65 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_g2_seed_5` | 72.13 us | 72.01 us - 72.28 us | 72.10 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_g2_seed_7` | 121.39 us | 120.97 us - 121.88 us | 121.28 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_g2_seed_9` | 68.98 us | 68.87 us - 69.12 us | 68.93 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_tangent_seed_21` | 67.79 us | 67.66 us - 67.93 us | 67.69 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_tangent_seed_6` | 68.02 us | 67.89 us - 68.18 us | 67.98 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_cubic_curve_tangent_seed_9` | 86.76 us | 73.36 us - 100.16 us | 71.11 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_line_tangent_seed_17` | 68.14 us | 68.03 us - 68.29 us | 68.05 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_line_tangent_seed_21` | 83.90 us | 72.52 us - 97.61 us | 68.14 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_line_tangent_seed_47` | 111.46 us | 110.94 us - 111.97 us | 111.53 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_curve_line_tangent_seed_9` | 94.72 us | 80.52 us - 108.85 us | 96.80 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_20` | 95.54 us | 82.01 us - 108.93 us | 112.41 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_21` | 67.81 us | 67.67 us - 67.99 us | 67.73 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_22` | 92.33 us | 79.50 us - 104.92 us | 94.69 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_23` | 69.13 us | 69.08 us - 69.18 us | 69.13 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_6` | 94.52 us | 81.46 us - 106.84 us | 110.68 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_cubic_line_tangent_seed_9` | 67.96 us | 67.90 us - 68.03 us | 67.94 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_range_seed_1` | 73.33 us | 72.20 us - 75.04 us | 72.27 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_range_seed_10` | 69.20 us | 69.07 us - 69.36 us | 69.12 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_range_seed_8` | 69.98 us | 69.90 us - 70.10 us | 69.96 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_range_seed_9` | 68.47 us | 68.39 us - 68.59 us | 68.40 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_seed_17` | 71.40 us | 71.30 us - 71.54 us | 71.37 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_seed_22` | 95.85 us | 81.43 us - 110.19 us | 106.43 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_seed_6` | 68.75 us | 67.68 us - 70.70 us | 67.72 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_distance_seed_9` | 117.18 us | 116.94 us - 117.34 us | 117.25 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_equal_length_seed_28` | 68.37 us | 68.30 us - 68.46 us | 68.34 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_equal_point_line_distances_seed_19` | 94.03 us | 79.74 us - 108.35 us | 91.47 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_equal_point_line_distances_seed_9` | 101.41 us | 86.23 us - 116.32 us | 120.65 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_equal_point_point_distances_seed_6` | 114.76 us | 114.60 us - 114.94 us | 114.75 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_equal_point_point_distances_seed_9` | 105.57 us | 91.61 us - 119.40 us | 119.35 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_difference_seed_20` | 94.66 us | 80.29 us - 108.94 us | 99.80 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_difference_seed_246` | 95.62 us | 81.19 us - 109.90 us | 102.67 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_difference_seed_6` | 101.34 us | 86.54 us - 115.66 us | 119.95 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_point_line_distance_seed_20` | 98.22 us | 84.54 us - 109.72 us | 113.87 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_point_line_distance_seed_6` | 92.55 us | 78.14 us - 106.67 us | 95.48 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_ratio_seed_17` | 96.53 us | 82.44 us - 110.55 us | 113.52 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_ratio_seed_22` | 71.35 us | 71.28 us - 71.46 us | 71.31 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_ratio_seed_7` | 73.29 us | 73.19 us - 73.44 us | 73.22 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_length_ratio_seed_71` | 70.81 us | 67.84 us - 74.87 us | 67.85 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_arc_sweep_length_seed_17` | 70.19 us | 70.00 us - 70.43 us | 70.05 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_arc_sweep_length_seed_19` | 97.31 us | 82.88 us - 111.59 us | 110.83 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_circle_tangent_seed_17` | 102.53 us | 90.38 us - 114.11 us | 114.38 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_length_range_seed_22` | 109.65 us | 99.59 us - 116.68 us | 116.49 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_length_range_seed_5` | 73.12 us | 72.73 us - 73.67 us | 72.82 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_length_range_seed_8` | 96.93 us | 83.05 us - 110.59 us | 114.80 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_orientation_seed_92` | 101.70 us | 86.85 us - 116.54 us | 114.02 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_radius_equality_seed_7` | 68.19 us | 68.12 us - 68.31 us | 68.14 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_line_radius_equality_seed_92` | 74.11 us | 74.03 us - 74.20 us | 74.09 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_oriented_angle_seed_121` | 89.55 us | 75.70 us - 103.48 us | 85.00 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_oriented_angle_seed_20` | 68.15 us | 68.07 us - 68.26 us | 68.11 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_concentric_seed_18` | 68.16 us | 68.08 us - 68.27 us | 68.13 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_distance_difference_seed_17` | 90.41 us | 76.83 us - 104.17 us | 86.40 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_distance_ratio_seed_136` | 106.15 us | 93.61 us - 118.10 us | 117.97 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_distance_ratio_seed_21` | 68.27 us | 68.18 us - 68.38 us | 68.22 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_distance_ratio_seed_22` | 93.15 us | 79.16 us - 107.17 us | 92.60 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_distance_ratio_seed_8` | 113.49 us | 112.86 us - 113.94 us | 113.74 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_line_distance_range_seed_2` | 72.26 us | 72.15 us - 72.41 us | 72.20 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_line_radius_equality_seed_7` | 87.56 us | 74.08 us - 101.05 us | 75.72 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_arc_seed_17` | 102.86 us | 90.82 us - 112.33 us | 112.22 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_arc_seed_8` | 97.48 us | 83.10 us - 111.09 us | 115.65 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_circle_seed_2` | 99.15 us | 85.29 us - 110.74 us | 115.19 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_circle_seed_6` | 73.73 us | 73.67 us - 73.79 us | 73.71 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_curve_seed_17` | 94.72 us | 79.92 us - 109.51 us | 94.74 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_curve_seed_21` | 114.50 us | 114.27 us - 114.75 us | 114.47 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_curve_seed_8` | 95.24 us | 82.09 us - 108.33 us | 110.35 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_seed_17` | 102.64 us | 90.87 us - 112.74 us | 112.65 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_seed_18` | 69.05 us | 68.97 us - 69.16 us | 69.03 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_seed_22` | 68.07 us | 67.99 us - 68.15 us | 68.04 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_on_cubic_seed_6` | 67.80 us | 67.65 us - 67.95 us | 67.81 us | - | - |
| `promoted_fuzz_worst_performers/sketch_projected_point_radius_equality_seed_17` | 68.67 us | 68.61 us - 68.76 us | 68.65 us | - | - |
| `promoted_slow_offender_score/replay_promoted_100` | 13.34 ms | 11.98 ms - 14.73 ms | 12.73 ms | - | - |

<!-- END COMPLETE BENCHMARK REPORT -->
