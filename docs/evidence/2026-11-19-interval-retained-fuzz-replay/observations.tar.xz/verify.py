from pathlib import Path
import hashlib,re,tomllib,collections,subprocess
s=Path(__file__).resolve().parent
r=Path('/mnt/development/csgrs')
b=r/'crates/hypersolve'
m=tomllib.loads((b/'fuzz/Cargo.toml').read_text())
names={t['name'] for t in m['bin']}
report=(b/'slow_performers.txt').read_text()
rows={name:tuple(map(int,(n,h,p))) for name,n,h,p in re.findall(r'^\| `(\w+)` \| (\d+) \| [^|]+ \| (\d+) \| (\d+) \|$',report,re.M)}
assert set(rows)==names and len(names)==69
assert tuple(map(sum,zip(*rows.values())))==(20000,1000,100)
def score_keys(path):
 return {(line.split('\t')[0],line.split('\t')[1]) for line in path.read_text().splitlines() if line and not line.startswith('#')}
old=score_keys(s/'before/promoted_slow_offenders.txt')
new=score_keys(s/'measured/promoted_slow_offenders.txt')
assert len(old&new)==99 and new-old=={('bivariate_vertical_components','seed[106]')}
ids={p.parent.parent for p in (s/'criterion').glob('**/new/sample.json')}
assert len(ids)==101
for bin in ('jacobian_matrix','bivariate_vertical_components'):
 assert (s/f'seeded-{bin}.log').read_text().count('Executed exact-seeds/')==290
 assert 'Done 1000 runs' in (s/f'asan-{bin}.log').read_text()
old_oracle=subprocess.check_output(['git','-C',r,'show','07f1326a0:crates/hypersolve/fuzz/fuzz_targets/jacobian_matrix.rs'],text=True)
new_oracle=(b/'fuzz/fuzz_targets/support/jacobian_matrix.rs').read_text()
assert old_oracle.split('fuzz_target!(|data: &[u8]| {\n',1)[1].removesuffix('});\n')==new_oracle.split('pub fn check(data: &[u8]) {\n',1)[1].removesuffix('}\n')
print(len(names),'registered targets;',sum(t[0] for t in rows.values()),'samples;',len(ids),'Criterion measurements;',len(old&new),'promotions retained')
for name in ['jacobian_matrix','bivariate_vertical_components']:
 print(name,rows[name],'with 290 ASan seed replays and 1000 ASan mutations')
print('Jacobian oracle body matches the baseline byte for byte')
for p in [s/'base-retained_fuzz-cb2a2a5557bcf073',s/'target/release/deps/retained_fuzz-cb2a2a5557bcf073']:
 print(p.name,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
