from pathlib import Path
from fractions import Fraction
from collections import Counter
import math,random,struct
root=Path(__file__).resolve().parent/'independent'
root.mkdir(exist_ok=True)
rng=random.Random(20261119)
counts=Counter()
for i in range(2048):
    words=[rng.getrandbits(64) for j in range(4)]
    data=struct.pack('<4Q',*words)
    (root/f'range-{i:04}').write_bytes(data)
    for fmt,maximum in [('f','0x1.fffffep+127'),('d','0x1.fffffffffffffp+1023')]:
        vals=[struct.unpack_from('<'+fmt,data,offset)[0] for offset in range(0,32,8)]
        if not all(map(math.isfinite,vals)):
            counts[fmt,'nonfinite']+=1
            continue
        n=sorted(map(Fraction,vals[:2]))
        d=sorted(map(Fraction,vals[2:]))
        limit=Fraction(float.fromhex(maximum))
        for op in ['mul','div']:
            if op=='div' and d[0]<=0<=d[1]:
                counts[fmt,op,'ContainsZero']+=1
                continue
            corners=[a*b if op=='mul' else a/b for a in n for b in d]
            counts[fmt,op,'Overflow' if max(map(abs,corners))>limit else 'finite']+=1
    if i<64:
        (root/f'legacy-{i:02}').write_bytes(data[:24])
for k,v in sorted(counts.items()): print(' '.join(k),v)
