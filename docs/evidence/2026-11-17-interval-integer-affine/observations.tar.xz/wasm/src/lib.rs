#![no_std]
use hyperinterval::{IntegerRange, IntervalError};
#[panic_handler]
fn panic(_: &core::panic::PanicInfo<'_>) -> ! { loop { core::hint::spin_loop(); } }

#[unsafe(no_mangle)]
pub extern "C" fn query(kind:u32, selector:u32, al:u64, ah:u64, bl:u64, bh:u64, fl:u64, fh:u64, tl:u64, th:u64)->u64 {
    let pair=|lo,hi| u128::from(lo) | (u128::from(hi)<<64);
    let (a,b,f,t)=(pair(al,ah),pair(bl,bh),pair(fl,fh),pair(tl,th));
    macro_rules! image {
        ($ty:ty) => {{
            let source=IntegerRange::new(a as $ty,b as $ty).unwrap();
            source.affine(f as $ty,t as $ty).map(|r|{
                let (lo,hi)=r.bounds().unwrap();
                (lo as u128,hi as u128)
            })
        }};
    }
    let result=match kind {0=>image!(i128),1=>image!(u128),2=>image!(isize),3=>image!(usize),_=>unreachable!()};
    match result {
        Err(IntervalError::Overflow)=>0,
        Ok((lo,hi))=>match selector {0=>1,1=>lo as u64,2=>(lo>>64) as u64,3=>hi as u64,4=>(hi>>64) as u64,_=>unreachable!()},
        _=>unreachable!()
    }
}
