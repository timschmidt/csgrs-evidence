import {readFileSync} from "node:fs";
import assert from "node:assert/strict";
const {instance,module}=await WebAssembly.instantiate(readFileSync(process.argv[2]));
assert.equal(WebAssembly.Module.imports(module).length,0);
const query=instance.exports.query;
const word=x=>BigInt.asUintN(64,x);
let calls=0,accepted=0,overflow=0;
for(const [kind,width,signed] of [[0,128,true],[1,128,false],[2,32,true],[3,32,false]]){
    const bits=BigInt(width), extent=1n<<(signed?bits-1n:bits);
    const min=signed?-extent:0n, max=extent-1n;
    const points=[min,min+1n,-(1n<<(bits/2n)),-2n,-1n,0n,1n,2n,1n<<(bits/2n),max-1n,max];
    const values=[...new Set(points.filter(x=>min<=x&&x<=max))].sort((a,b)=>a<b?-1:1);
    for(const a of values)for(const b of values)if(a<=b)for(const f of values)for(const t of values){
        const args=[a,b,f,t].flatMap(x=>[word(x),word(x>>64n)]);
        const q=selection=>{calls++;return word(query(kind,selection,...args));};
        const [lo,hi]=f<0n?[b*f+t,a*f+t]:[a*f+t,b*f+t];
        if(lo<min||hi>max){assert.equal(q(0),0n);overflow++;continue;}
        assert.equal(q(0),1n);
        assert.equal(q(1),word(lo)); assert.equal(q(2),word(lo>>64n));
        assert.equal(q(3),word(hi)); assert.equal(q(4),word(hi>>64n));
        accepted++;
    }
}
console.log(JSON.stringify({accepted,overflow,calls,imports:WebAssembly.Module.imports(module)}));
