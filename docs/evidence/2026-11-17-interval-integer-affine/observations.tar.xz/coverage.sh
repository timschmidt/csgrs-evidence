set -eu
s=/dev/shm/interval-integer-affine
. "$s/env"
export CARGO_TARGET_DIR="$s/coverage-target"
export RUSTFLAGS="-C instrument-coverage"
mkdir -p "$s/profiles"
export LLVM_PROFILE_FILE="$s/profiles/%p-%m.profraw"
cargo +1.95.0 test --no-run --locked -p hyperinterval --no-default-features --features integer --test integer_affine --message-format=json > "$s/logs/coverage-build.json"
exe=$(python3 -c 'import json,sys; print(next(x["executable"] for x in map(json.loads,open(sys.argv[1])) if x.get("executable") and x["target"]["name"]=="integer_affine"))' "$s/logs/coverage-build.json")
export LLVM_PROFILE_FILE="$s/profiles/conversions-%p.profraw"
"$exe"
bin=$(rustc +1.95.0 --print target-libdir)/../bin
"$bin/llvm-profdata" merge -sparse "$s"/profiles/conversions-*.profraw -o "$s/profiles/merged.profdata"
"$bin/llvm-cov" show "$exe" -instr-profile="$s/profiles/merged.profdata" -show-instantiations=false crates/hyperinterval/src/integer_arithmetic.rs > "$s/logs/coverage-lines"
tail -43 "$s/logs/coverage-lines"
