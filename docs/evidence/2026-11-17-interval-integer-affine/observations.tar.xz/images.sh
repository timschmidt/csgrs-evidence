set -eu
s=/dev/shm/interval-integer-affine
. "$s/env"
cargo +1.95.0 build --locked --release -p hyperinterval --all-features --example order_cost
cp "$CARGO_TARGET_DIR/release/examples/order_cost" "$s/$1/order_cost"
cd /mnt/development/alumina-firmware
export CARGO_TARGET_DIR=/dev/shm/interval-fixed-host/fw-target
cargo +1.88.0 test --locked --release -p alumina-clock --lib --message-format=json > "$s/logs/clock-$1.json"
exe=$(python3 -c 'import json,sys; print(next(v["executable"] for v in (json.loads(s) for s in open(sys.argv[1]) if s.startswith("{")) if v.get("executable")))' "$s/logs/clock-$1.json")
cp "$exe" "$s/$1/clock"
