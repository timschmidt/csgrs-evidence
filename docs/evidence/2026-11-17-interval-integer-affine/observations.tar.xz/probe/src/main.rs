use hyperinterval::{IntegerRange,IntervalError};
use std::hint::black_box;
#[cfg(feature="heap")]
mod allocations;
fn measure<T: Eq+std::fmt::Debug>(name:&str, expected:T, mut work:impl FnMut()->T) {
    assert_eq!(work(),expected);
    #[cfg(feature="heap")]
    {
        let (_,calls,bytes)=allocations::measure(|| {
            for _ in 0..4096 { black_box(work()); }
        });
        assert_eq!((calls,bytes),(0,0));
        println!("{name},4096,{calls},{bytes}");
    }
    #[cfg(not(feature="heap"))]
    {
        for _ in 0..4096 { black_box(work()); }
        for block in 0..12 {
            let begin=std::time::Instant::now();
            for _ in 0..262144 { black_box(work()); }
            println!("{name},{block},262144,{}",begin.elapsed().as_nanos());
        }
    }
}
fn main() {
    macro_rules! case {
        ($name:literal,$src:expr,$f:expr,$t:expr,$expected:expr) => {{
            let src=$src;
            measure($name,$expected,||black_box(&src).affine(black_box($f),black_box($t)));
        }};
    }
    case!("i32_ticks", IntegerRange::<i32>::new(-2000,5000).unwrap(), 48, -17, IntegerRange::new(-96017,239983));
    case!("u64_ticks", IntegerRange::<u64>::new(130000,175000).unwrap(), 1500, 1000, IntegerRange::new(195001000,262501000));
    case!("i128_full_reversed", IntegerRange::<i128>::new(i128::MIN,i128::MAX).unwrap(), -1, -1, IntegerRange::new(i128::MIN,i128::MAX));
    case!("i128_cancellation", IntegerRange::<i128>::new(i128::MAX-1,i128::MAX).unwrap(), 2, i128::MIN, IntegerRange::new(i128::MAX-3,i128::MAX-1));
    case!("i128_irrecoverable", IntegerRange::<i128>::point(i128::MIN), -2, i128::MIN, Err(IntervalError::Overflow));
    case!("u128_final_overflow", IntegerRange::<u128>::new(0,u128::MAX/2).unwrap(), 2, 2, Err(IntervalError::Overflow));
    case!("u128_empty", IntegerRange::<u128>::empty(), u128::MAX, u128::MAX, Ok(IntegerRange::empty()));
}
