set -eu
t=/dev/shm/interval-box-aggregation
i=0
for v in control borrow-finish borrow-finish control borrow-finish control control borrow-finish; do
 i=$((i+1))
 CRITERION_HOME="$t/timing/$i-$v" setarch "$(uname -m)" -R taskset -c 2 "$t/images/$v-certification" --bench --noplot --warm-up-time 0.4 --measurement-time 1 --sample-size 25 'certify_(interval_box_candidate_report|quadratic_interval_rows|multivariate_quadratic_interval_rows)' > "$t/logs/combined-timing-$i-$v" 2>&1
done
