set -eu
s=/dev/shm/interval-box-coverage
t=/dev/shm/interval-box-aggregation
. "$s/build-environment.sh"
export CARGO_TARGET_DIR="$s/client-target"
cd "$s/client"
cargo +1.95.0 build --offline --release > "$t/logs/$1-client-build" 2>&1
cp "$CARGO_TARGET_DIR/release/box-coverage-client" "$t/images/$1-client"
"$t/images/$1-client" > "$t/logs/$1-client-rows"
python3 "$s/image_metrics.py" "$s/images/all-radii-client" "$t/images/$1-client" > "$t/logs/$1-client-sizes.json"
