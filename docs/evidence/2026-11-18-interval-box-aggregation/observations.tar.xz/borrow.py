from pathlib import Path
import re
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
a=s.index('fn validate_variable_balls');b=s.index('fn quadratic_variable_balls',a)
s=s[:a]+'''/// Borrow the exact source for interval arithmetic and retain the sign decision
/// needed to transport point evidence to a singleton coordinate.
struct ValidatedRadius<'a> {
    value: &'a Real,
    fixed: bool,
}

fn validate_variable_balls(
    variable_balls: &[VariableBall],
    policy: PredicatePolicy,
) -> Result<HashMap<SymbolId, ValidatedRadius<'_>>, AffineIntervalError> {
    let mut radii = HashMap::new();
    for ball in variable_balls {
        let sign = match ball.radius.structural_facts().sign {
            Some(sign) => Some(sign),
            None => compare_reals(&ball.radius, &Real::zero(), policy.certified_only())
                .value()
                .map(RealSign::from),
        };
        let fixed = match sign {
            Some(RealSign::Zero) => true,
            Some(RealSign::Positive) => false,
            Some(RealSign::Negative) => {
                return Err(AffineIntervalError::NegativeVariableRadius { symbol: ball.symbol });
            }
            None => {
                return Err(AffineIntervalError::UnknownVariableRadiusSign { symbol: ball.symbol });
            }
        };
        radii.insert(ball.symbol, ValidatedRadius { value: &ball.radius, fixed });
    }
    Ok(radii)
}

'''+s[b:]
s=s.replace('-> Result<HashMap<SymbolId, Real>, QuadraticIntervalError>','-> Result<HashMap<SymbolId, ValidatedRadius<\'_>>, QuadraticIntervalError>')
for name in ['certify_affine_enclosures','certify_univariate_quadratic_enclosures','certify_multivariate_quadratic_enclosures','interval_box_status']:
 a=s.index('fn '+name+'(');b=s.index('\n}',a)
 w=s[a:b].replace('HashMap<SymbolId, Real>',"HashMap<SymbolId, ValidatedRadius<'_>>",1)
 if name=='interval_box_status':
  u=w.index('.all(|symbol|');v=w.index('\n                }),',u)+len('\n                })')
  w=w[:u]+'.all(|symbol| radii.get(symbol).is_none_or(|radius| radius.fixed))'+w[v:]
 else:
  w=w.replace('coefficient_abs * variable_radius.clone()', 'coefficient_abs * variable_radius.value.clone()')
  w=re.sub(r'(radius_by_symbol\s*\.get\([^\n]+?\)\s*)\.cloned\(\)',r'\1.map(|radius| radius.value.clone())',w)
 s=s[:a]+w+s[b:]
p.write_text(s)
