from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs')
s=p.read_text()
a=s.index('            let status = if certification.all_satisfied()')
b=s.index('            IntervalBoxCertificationReport {',a)
s=s[:a]+'''            let status = interval_box_status(analysis, variable_balls, &certification, policy);
'''+s[b:]
pos=s.index('/// Certify a square affine equality system')
s=s[:pos]+'''/// A certified violation must cover the box on at least one row. Universal
/// satisfaction requires box evidence on every active row.
fn interval_box_status(
    analysis: &ProblemAnalysis<'_>,
    variable_balls: &[VariableBall],
    certification: &crate::CandidateCertificationReport,
    policy: PredicatePolicy,
) -> IntervalBoxCertificationStatus {
    let has_violation = certification.has_certified_violation();
    if !has_violation && !certification.all_satisfied() {
        return IntervalBoxCertificationStatus::Unknown;
    }
    for row in &certification.rows {
        if has_violation && !row.status.is_certified_violation() {
            continue;
        }
        let covers_box = match row.status {
            crate::CertifiedCandidateStatus::BallCertified { certainty, .. } => {
                policy.certified_only().accepts(certainty)
            }
            _ => analysis.constraints()[row.constraint_index]
                .residual
                .dependencies
                .iter()
                .all(|symbol| {
                    // Radius validation keeps the last supplied binding and
                    // treats an omitted symbol as fixed at its candidate value.
                    let Some(ball) = variable_balls.iter().rev().find(|ball| ball.symbol == *symbol)
                    else {
                        return true;
                    };
                    match ball.radius.immediate_sign() {
                        Some(sign) => sign == RealSign::Zero,
                        None => compare_reals(&ball.radius, &Real::zero(), policy.certified_only())
                            .value() == Some(Ordering::Equal),
                    }
                }),
        };
        if has_violation && covers_box {
            return IntervalBoxCertificationStatus::Violation;
        }
        if !has_violation && !covers_box {
            return IntervalBoxCertificationStatus::Unknown;
        }
    }
    if has_violation {
        IntervalBoxCertificationStatus::Unknown
    } else {
        IntervalBoxCertificationStatus::Certified
    }
}

'''+s[pos:]
s=s.replace('    /// Candidate certification report, when replay reached row certification.','    /// Candidate replay, including any point-only rows. Use the outer status\n    /// for the verdict on the entire box.')
p.write_text(s)
