set -eu
s=/dev/shm/interval-box-coverage
t=/dev/shm/interval-box-aggregation
cd "$s/csgrs"
bash "$s/build-bench.sh" "agg$1" > "$t/logs/$1-owner-build" 2>&1
mv "$s/images/agg$1-certification" "$t/images/$1-certification"
python3 "$s/image_metrics.py" "$s/images/all-radii-copy-certification" "$t/images/$1-certification" > "$t/logs/$1-owner-sizes.json"
