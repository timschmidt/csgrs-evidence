from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
# Input domain is validated exactly once, both for bounding and aggregating.
for stem,error,short in [('affine','Affine','affine'),('quadratic','Quadratic','univariate_quadratic'),('multivariate_quadratic','Quadratic','multivariate_quadratic')]:
 start=s.index(f'pub fn certify_{stem}_interval_candidate(')
 val=s.index('    let radius_by_symbol',start);stop=s.index('    let mut residual_balls',val)
 w=s[val:stop]
 if error=='Quadratic':
  if stem=='quadratic': q=w.strip().split('=\n',1)[1].strip().removesuffix('?;')
  w='    let radius_by_symbol = quadratic_variable_balls(variable_balls, policy)?;\n'
 name='certify_'+short+'_enclosures'
 inner_ret='crate::CandidateCertificationReport' if stem=='affine' else 'Result<crate::CandidateCertificationReport, QuadraticIntervalError>'
 call=name+'(analysis, context, &radius_by_symbol, policy)'
 s=s[:val]+w+'    '+('Ok('+call+')' if stem=='affine' else call)+'\n}\n\nfn '+name+'(\n    analysis: &ProblemAnalysis<\'_>,\n    context: &EvaluationContext,\n    radius_by_symbol: &HashMap<SymbolId, Real>,\n    policy: PredicatePolicy,\n) -> '+inner_ret+' {\n'+s[stop:]
 if stem=='affine':
  a=s.index('    if residual_balls.is_empty()',val);b=s.index('\n}',a)
  s=s[:a]+s[a:b].replace('Ok(certify_candidate(analysis, context))','certify_candidate(analysis, context)').replace('Ok(certify_candidate_with_residual_balls(', 'certify_candidate_with_residual_balls(').removesuffix('))')+')'+s[b:]
pos=s.index('fn interval_box_affine_error_message')
s=s[:pos]+'''fn quadratic_variable_balls(
    variable_balls: &[VariableBall],
    policy: PredicatePolicy,
) -> Result<HashMap<SymbolId, Real>, QuadraticIntervalError> {
    '''+q+'\n}\n\n'+s[pos:]
a=s.index('    let result = match package');b=s.index('            IntervalBoxCertificationReport {',a)
s=s[:a]+'''    let result = validate_variable_balls(variable_balls, policy)
        .map_err(interval_box_affine_error_message)
        .and_then(|radii| {
            let report = match package {
                IntervalBoxCertificationPackage::Affine => {
                    certify_affine_enclosures(analysis, context, &radii, policy)
                }
                IntervalBoxCertificationPackage::UnivariateQuadratic =>
                    certify_univariate_quadratic_enclosures(analysis, context, &radii, policy)
                        .map_err(interval_box_quadratic_error_message)?,
                IntervalBoxCertificationPackage::MultivariateQuadratic =>
                    certify_multivariate_quadratic_enclosures(analysis, context, &radii, policy)
                        .map_err(interval_box_quadratic_error_message)?,
            };
            let status = interval_box_status(analysis, &radii, &report, policy);
            Ok((report, status))
        });
    match result {
        Ok((certification, status)) => {
'''+s[b:]
a=s.index('fn interval_box_status');b=s.index('/// Certify a square affine',a)
w=s[a:b].replace('variable_balls: &[VariableBall]','radii: &HashMap<SymbolId, Real>')
u=w.index('                    // Radius validation');v=w.index('                        Some(sign)',u)
w=w[:u]+'''                    let Some(radius) = radii.get(symbol) else {
                        return true;
                    };
                    match radius.immediate_sign() {
'''+w[v:]
s=s[:a]+w.replace('&ball.radius,','radius,')+s[b:]
p.write_text(s)
