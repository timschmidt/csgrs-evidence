const fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const module=await WebAssembly.compile(fs.readFileSync(process.argv[2]));
 assert.deepEqual(WebAssembly.Module.imports(module),[]);
 const repaired=process.argv[3]==='repaired';let calls=0;
 for(let fresh=0;fresh<2;fresh++){
  const {exports}=await WebAssembly.instantiate(module);
  for(let round=0;round<2;round++)for(let mode=0;mode<2;mode++)for(let package=0;package<3;package++)for(let center=0;center<2;center++)for(let i=0;i<8;i++){
   const actual=exports.verdict(i,center,package,mode);
   let expected;
   if(i===7){
    if(mode===0||package===1){expected=1003;}
    else{expected=repaired?11003:10011;}
   }else{
    const point=center===0?1:2;
    const status=i===5?2:repaired && [0,4,6].includes(i)?3:point;
    expected=status+(center===0?10:100)+(i===4?10:i===5?100:0);
   }
   assert.equal(actual,expected,JSON.stringify({i,center,package,mode,actual,expected}));
   calls++;
  }
  console.log('linear memory bytes',exports.memory.buffer.byteLength);
 }
 console.log(calls,'ordered calls passed');
})().catch(e=>{console.error(e);process.exit(1)});
