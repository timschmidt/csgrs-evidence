from pathlib import Path
from collections import Counter
import json,hashlib,ast
s=Path('/dev/shm/interval-box-coverage');t=Path(__file__).parent
old=(t/'logs/control-client-rows').read_text().splitlines()
assert len(old)==252 and old==(s/'logs/all-radii-client-rows').read_text().splitlines()
out={}
for p in sorted((t/'logs').glob('*-client-sizes.json')):
 name=p.name.removesuffix('-client-sizes.json')
 row={}
 for role in ['client','owner']:
  metrics=json.loads((t/'logs'/f'{name}-{role}-sizes.json').read_text());row[role]=dict(file_delta=metrics['file']['delta'],code_delta=metrics['function_union']['delta'],padding_delta=metrics['.relro_padding']['delta'],exceeded=[k for k,v in metrics.items() if not v['incremental_pass']])
 data=(t/'logs'/f'{name}-client-rows').read_text().splitlines();assert len(data)==len(old)
 diff=Counter(x.split('|')[0] for x,y in zip(old,data) if x!=y)
 assert diff['VERDICT']==(0 if name=='control' else 24)
 heap=[(ast.literal_eval(x.split('|')[-1]),ast.literal_eval(y.split('|')[-1])) for x,y in zip(old,data) if x.startswith('HEAP|')]
 row.update(changed_records=dict(diff),peak_heap_delta_range=[min(b[4]-a[4] for a,b in heap),max(b[4]-a[4] for a,b in heap)])
 out[name]=row
 print(name,*[(row[r]['file_delta'],row[r]['exceeded']) for r in ['client','owner']],dict(diff))
(t/'native-results.json').write_text(json.dumps(out,indent=2)+'\n')
