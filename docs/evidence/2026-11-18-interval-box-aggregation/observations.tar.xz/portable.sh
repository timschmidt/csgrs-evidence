set -eu
t=/dev/shm/interval-box-aggregation
. /dev/shm/interval-bisection/env
export CARGO_TARGET_DIR="$t/wasm-target"
cd "$t/wasm"
cargo +1.95.0 build --release --offline --target wasm32-unknown-unknown
cp "$CARGO_TARGET_DIR/wasm32-unknown-unknown/release/box_scope_observer.wasm" "$t/images/$1.wasm"
node check.cjs "$t/images/$1.wasm" "$2"
