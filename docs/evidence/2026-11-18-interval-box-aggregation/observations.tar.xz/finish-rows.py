from pathlib import Path
p=Path('crates/hypersolve/src/certification.rs');s=p.read_text()
a=s.index('    let mut rows = Vec::with_capacity',s.index('pub fn certify_candidate_with_config('))
s=s[:a]+'''    report_from_rows(replay_rows(analysis, context, config))
}

fn replay_rows(
    analysis: &ProblemAnalysis<'_>,
    context: &EvaluationContext,
    config: CandidateCertificationConfig,
) -> Vec<CertifiedCandidateRow> {
'''+s[a:]
a=s.index('    let certified_satisfied_rows = rows');b=s.index('\n}',a)
s=s[:a]+'    rows'+s[b:]
a=s.index('    let mut report = certify_candidate(');b=s.index('\n}',a)
w=s[a:b].replace('let mut report = certify_candidate(analysis, context);','let mut rows = replay_rows(analysis, context, CandidateCertificationConfig::default());').replace('report.rows.get_mut','rows.get_mut').replace('    recompute_report_counts(&mut report);\n    report','    report_from_rows(rows)')
s=s[:a]+w+s[b:]
a=s.index('fn recompute_report_counts(');b=s.index('\n}',a)
s=s[:a]+'''fn report_from_rows(rows: Vec<CertifiedCandidateRow>) -> CandidateCertificationReport {
    let mut report = CandidateCertificationReport {
        rows,
        certified_satisfied_rows: 0,
        certified_violation_rows: 0,
        bounded_unknown_rows: 0,
        lossy_adapter_only_rows: 0,
        domain_failure_rows: 0,
    };
    for row in &report.rows {
        report.certified_satisfied_rows += usize::from(row.status.is_certified_satisfied());
        report.certified_violation_rows += usize::from(row.status.is_certified_violation());
        report.bounded_unknown_rows += usize::from(row.status.is_unknown());
        report.lossy_adapter_only_rows += usize::from(row.status.is_lossy_adapter_only());
        report.domain_failure_rows += usize::from(matches!(
            row.status,
            CertifiedCandidateStatus::DomainFailure { .. } | CertifiedCandidateStatus::InvalidBallRadius
        ));
    }
    report'''+s[b:]
p.write_text(s)
