from pathlib import Path
import hashlib,subprocess,json
s=Path('/dev/shm/interval-box-coverage');t=Path(__file__).parent
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index={}
for p in sorted((t/'images').iterdir()):
 if p.suffix=='.wasm':continue
 baseline='all-radii-client' if p.name.endswith('-client') else 'all-radii-copy-certification'
 base=s/'images'/baseline
 delta=t/'binary-deltas'/(p.name+'.zst')
 subprocess.run(['zstd','--quiet','--force','-16','--patch-from',base,p,'-o',delta],check=True)
 restored=t/('verify-'+p.name)
 subprocess.run(['zstd','--quiet','--force','-d','--patch-from',base,delta,'-o',restored],check=True)
 assert dig(restored)==dig(p);restored.unlink()
 index[p.name]={'base_member':'images/'+baseline,'base_sha256':dig(base),'sha256':dig(p),'length':p.stat().st_size,'delta_bytes':delta.stat().st_size}
(t/'delta-index.json').write_text(json.dumps(index,indent=2)+'\n')
