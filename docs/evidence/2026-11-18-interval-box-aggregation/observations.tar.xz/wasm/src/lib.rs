use hyperlimit::{Certainty, PredicatePolicy};
use hyperreal::Real;
use hypersolve::{CertifiedCandidateStatus, Constraint, Expr, IntervalBoxCertificationPackage as P, IntervalBoxCertificationStatus as S, Problem, SymbolId, VariableBall, certify_interval_box_candidate, context_from_problem};
#[unsafe(no_mangle)]
pub extern "C" fn verdict(case:u32, center:u32, package:u32, mode:u32)->u32 {
 let pkg=match package{0=>P::Affine,1=>P::UnivariateQuadratic,_=>P::MultivariateQuadratic};
 let policy=if mode==0 {PredicatePolicy::STRICT}else{PredicatePolicy::APPROXIMATE_512};
 let mut p=Problem::default();
 p.add_variable("x",Real::from(center));p.add_variable("y",Real::from(3));
 let x=Expr::anonymous_symbol(SymbolId(0));
 let y=Expr::anonymous_symbol(SymbolId(1));
 let mut inactive=Constraint::equality("inactive",Expr::int(1));inactive.active=false;
 p.add_constraint(inactive);
 let ball=|i,r|VariableBall{symbol:SymbolId(i),radius:Real::from(r)};
 let balls=match case {0|4|5=>vec![ball(0,1)],1=>vec![ball(0,0)],2=>vec![ball(1,1)],3=>vec![ball(0,1),ball(0,0)],6=>vec![ball(0,0),ball(0,1)],_=>vec![]};
 if case==7{
 let v=(Real::e()+Real::one()).sin()-Real::e().sin()*Real::one().cos()-Real::e().cos()*Real::one().sin()-Real::from(2).powi_i64(-2048).unwrap();
 p.add_constraint(Constraint::equality("hidden negative",Expr::real(v)));
 }else{
 p.add_constraint(Constraint::equality("cube",x.clone()*x.clone()*x));
 if case==4||case==5{p.add_constraint(Constraint::equality("fixed",y-Expr::int(if case==4{3}else{5})));}
 }
 let analysis=p.analyze();
 if case==7 {assert!(analysis.affine_residuals()[1].is_some());assert!(analysis.univariate_quadratic_residuals()[1].is_none());assert!(analysis.quadratic_residuals()[1].is_none());}
 let report=certify_interval_box_candidate(&analysis,&context_from_problem(&p),&balls,pkg,policy);
 let inner=report.certification.unwrap();assert_eq!(inner.rows[0].constraint_index,1);
 let approx=matches!(inner.rows[0].status,CertifiedCandidateStatus::BallCertified{certainty:Certainty::Approximate,..});
 let code=match report.status{S::Certified=>1,S::Violation=>2,S::Unknown=>3,S::InvalidInput=>4};
 code+10*inner.certified_satisfied_rows as u32+100*inner.certified_violation_rows as u32+1000*inner.bounded_unknown_rows as u32+10000*(approx as u32)
}
