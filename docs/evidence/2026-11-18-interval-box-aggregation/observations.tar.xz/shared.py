from pathlib import Path
p=Path('crates/hypersolve/src/interval.rs');s=p.read_text()
start=s.index('fn interval_box_status');end=s.index('/// Certify a square affine',start)
w=s[start:end].replace('    policy: PredicatePolicy,\n','')
w=w.replace('    for row in &certification.rows {','''    let active_constraints = analysis.constraints().iter().filter(|facts| facts.active);
    for (row, facts) in certification.rows.iter().zip(active_constraints) {''')
w=w.replace('policy.certified_only().accepts(certainty)','PredicatePolicy::STRICT.accepts(certainty)')
a=w.index('_ => analysis.constraints()');b=w.index('        };\n        if has_violation',a)
w=w[:a]+'''_ => facts.residual.dependencies.iter().all(|symbol| {
                variable_balls.iter().rev().find(|ball| ball.symbol == *symbol)
                    .is_none_or(|ball| variable_radius_sign(&ball.radius) == Some(Ordering::Equal))
            }),
'''+w[b:]
s=s[:start]+w+s[end:]
s=s.replace('variable_balls, &certification, policy)','variable_balls, &certification)')
a=s.index('fn validate_variable_balls(');b=s.index('            Some(Ordering::Less) =>',a)
s=s[:a]+'''/// A radius is admissible only with a certified sign. The same decision
/// establishes when a point proof covers an entire input coordinate.
fn variable_radius_sign(radius: &Real) -> Option<Ordering> {
    match radius.structural_facts().sign {
        Some(RealSign::Zero) => Some(Ordering::Equal),
        Some(RealSign::Positive) => Some(Ordering::Greater),
        Some(RealSign::Negative) => Some(Ordering::Less),
        None => compare_reals(radius, &Real::zero(), PredicatePolicy::STRICT).value(),
    }
}

fn validate_variable_balls(
    variable_balls: &[VariableBall],
) -> Result<HashMap<SymbolId, Real>, AffineIntervalError> {
    let mut radii = HashMap::new();
    for ball in variable_balls {
        match variable_radius_sign(&ball.radius) {
'''+s[b:]
s=s.replace('validate_variable_balls(variable_balls, policy)','validate_variable_balls(variable_balls)')
p.write_text(s)
