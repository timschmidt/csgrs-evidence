from pathlib import Path
import ast,json
s=Path('/dev/shm/interval-box-coverage');t=Path(__file__).parent
q={'__file__':str(s/'lifetime-summary.py')}
exec((s/'lifetime-summary.py').read_text().split('vs=')[0].replace("for line in p.read_text().splitlines():","if p.name.endswith('build'):continue\n  for line in p.read_text().splitlines():"),q)
fixed=q['collect']('fixed');prev=q['collect']('all-radii')
q['s']=t;new=q['collect']('combined')
history={(str(r['workload']),str({'cold':0,'warm':1}[r['temperature']])):r for r in json.loads((s/'memory-rows.json').read_text())}
out=[]
for k in prev:
 if k[1]=='HEAP':
  x,y=prev[k][-2],new[k][-2]; limit=0
  out.append(dict(metric='peak requested heap',key=k,previous=x,candidate=y,delta=y-x,passes=y<=x and new[k][-1]==0))
  continue
 h=history[(k[0],k[2])];x,y=prev[k],new[k]; assert x==h['retained']
 pos=max(0,y-x);cum=h['cumulative_charge_bytes']+pos
 out.append(dict(metric='stack',key=k,fixed=fixed[k],previous=x,candidate=y,incremental=pos,previous_charge=h['cumulative_charge_bytes'],cumulative=cum,passes=pos<=128 and pos*100<=x and cum<=256 and cum*100<=2*fixed[k]))
(t/'whole-call-memory.json').write_text(json.dumps(out,indent=2)+'\n')
for m in ['stack','peak requested heap']:
 rows=[r for r in out if r['metric']==m];print(m,'rows',len(rows),'fails',sum(not r['passes'] for r in rows),'max delta',max(r['candidate']-r['previous'] for r in rows),'min delta',min(r['candidate']-r['previous'] for r in rows))
 print('examples',[(r['key'],r['previous'],r['candidate']) for r in rows if not r['passes']][:3])
