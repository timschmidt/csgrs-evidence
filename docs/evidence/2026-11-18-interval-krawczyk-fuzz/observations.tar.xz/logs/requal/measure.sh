set -eu
s=/dev/shm/interval-krawczyk-fuzz/requal
b=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
v=$1
case $2 in
wasm)
cd "$b/portable-krawczyk"
CARGO_TARGET_DIR="$b/wasm-target" cargo +1.95.0 build --offline --locked --release --target wasm32-unknown-unknown
cp "$b/wasm-target/wasm32-unknown-unknown/release/box_radius_client.wasm" "$s/images/$v.wasm"
node check.cjs "$s/images/$v.wasm" repaired;;
lifetime)
cd "$b/lifetime"
CARGO_TARGET_DIR="$b/lifetime-target" cargo +1.95.0 build --offline --locked --release
cp "$b/lifetime-target/release/radius-lifetime" "$s/images/$v-lifetime"
for i in $(seq 1 24); do setarch "$(uname -m)" -R taskset -c 3 "$s/images/$v-lifetime" > "$s/logs/$v-life-$i" 2>"$s/logs/$v-guard-$i"; done;;
bench)
cd "$b/wasm-repo"
CARGO_TARGET_DIR="$b/target" cargo +1.95.0 bench --locked -p hypersolve --bench certification --features dispatch-trace --no-run --message-format=json > "$s/logs/$v-bench.json"
python3 - "$s" "$v" <<'PY'
import json,sys,shutil
from pathlib import Path
s=Path(sys.argv[1]);v=sys.argv[2]
r=next(r for l in (s/'logs'/(v+'-bench.json')).read_text().splitlines() if (r:=json.loads(l)).get('executable') and r['target']['name']=='certification')
shutil.copy2(r['executable'],s/'images'/(v+'-certification'))
PY
esac
