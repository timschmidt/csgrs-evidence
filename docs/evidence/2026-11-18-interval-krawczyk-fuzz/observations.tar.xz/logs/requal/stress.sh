set -eu
r=/dev/shm/interval-krawczyk-fuzz/requal
k=/dev/shm/interval-krawczyk-certainty
b=/dev/shm/interval-box-coverage
. /dev/shm/interval-bisection/env
cd "$k/stress"
CARGO_TARGET_DIR="$b/wasm-target" cargo +1.95.0 build --locked --offline --release --target wasm32-unknown-unknown
cp "$b/wasm-target/wasm32-unknown-unknown/release/kraw_stress.wasm" "$r/images/repair-stress.wasm"
cd "$k/stress-life"
CARGO_TARGET_DIR="$b/lifetime-target" cargo +1.95.0 build --locked --offline --release
cp "$b/lifetime-target/release/proof-stress-lifetime" "$r/images/repair-stress-life"
for suffix in -stress-life -stress.wasm;do
 cmp "$r/images/repair$suffix" "$k/images/entry$suffix"
 cp "$k/images/multi$suffix" "$r/images/primary$suffix"
done
cd "$k/stress"
node check.cjs "$r/images/repair-stress.wasm" entry
node check.cjs "$r/images/primary-stress.wasm" multi
for i in $(seq 1 48);do
 for v in primary repair;do
 setarch "$(uname -m)" -R taskset -c 4 "$r/images/$v-stress-life" > "$r/logs/$v-stress-life-$i" 2> "$r/logs/$v-stress-guard-$i"
 done
done
