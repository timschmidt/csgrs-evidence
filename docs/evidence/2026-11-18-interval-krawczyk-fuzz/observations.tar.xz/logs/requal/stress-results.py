from pathlib import Path
import json,ast
s=Path(__file__).parent
k=Path('/dev/shm/interval-krawczyk-certainty')
hist={tuple(m['key']):m for m in json.loads((k/'stress-memory-multi.json').read_text())}
def collect(name):
 out={}
 files=list((s/'logs').glob(name+'-stress-life-*'));assert len(files)==48
 for p in files:
  for l in p.read_text().splitlines():
   t,i,rest=l.split('|',2);key=(t.lower(),int(i))
   if t=='STACK':
    w,pattern,val=rest.split('|');key+=int(w),;v=int(val)
   else:v=ast.literal_eval(rest)
   out.setdefault(key,[]).append(v)
 return {key:max(vals) if key[0]=='stack' else [max(col) for col in zip(*vals)] for key,vals in out.items()}
a,b=map(collect,('primary','repair'));out=[]
for key,val in sorted(b.items()):
 case=key[1]
 ref=(key[0],case-6,*key[2:]) if case in (6,7,9,10) else key
 fixed=hist[ref]['fixed_reference']
 prev=a[ref];arch=hist[ref]['candidate']
 old_charge=max(hist[ref]['cumulative_charge'],hist[key]['cumulative_charge'])
 if key[0]=='stack':
  i=max(0,val-min(prev,arch));cum=i+old_charge
  passes=i<=128 and i*100<=min(prev,arch) and cum<=256 and cum*100<=2*fixed and val<=16384
 else:
  i=max(0,val[-2]-min(prev[-2],arch[-2]));cum=i+old_charge
  passes=cum==0 and val[-2]<=16384 and val[-1]==0
 out.append(dict(key=key,completed_reference=ref,same_policy=a[key],previous=prev,archived_previous=arch,fixed=fixed,candidate=val,prior_charge=old_charge,increment=i,cumulative=cum,passes=passes))
(s/'stress-results.json').write_text(json.dumps(out,indent=2)+'\n')
print('failed',[(x['key'],x['increment'],x['cumulative']) for x in out if not x['passes']]);print('peak charge',max(x['increment'] for x in out))
print('headroom',min(int(l.split()[-1]) for p in (s/'logs').glob('repair-stress-guard-*') for l in p.read_text().splitlines()))
