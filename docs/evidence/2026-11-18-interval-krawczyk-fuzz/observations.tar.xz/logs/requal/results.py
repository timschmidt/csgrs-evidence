from pathlib import Path
import json, hashlib, statistics, ast
r=Path(__file__).parent
h=Path('/dev/shm/interval-krawczyk-certainty')
def read(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
images=[{a['target']:a for a in read(h/f'images-{v}.json')} for v in ('multi','entry')]
size=[]
for target in ('lifetime','wasm','certification'):
 suffix='.wasm' if target=='wasm' else '-'+target
 for tag,old in [('primary','multi'),('repair','entry')]:
  assert sha(r/'images'/(tag+suffix))==sha(h/'images'/(old+suffix))
 for k,m in images[0][target]['metrics'].items():
  n=images[1][target]['metrics'][k]['measured'];prev=m['measured'];fixed=m['baseline'];i=max(0,n-prev);c=m['cumulative']+i
  lim=m['limits'];passes=i<=lim[0] and 100*i<=prev*lim[1] and c<=lim[2] and 100*c<=fixed*lim[3]
  size.append(dict(target=target,metric=k,fixed=fixed,previous=prev,candidate=n,increment=i,cumulative=c,limits=lim,passes=passes))
write(r/'size.json',size)
def life(tag):
 d={}
 paths=list((r/'logs').glob(tag+'-life-*'));assert len(paths)==24
 for f in paths:
  for line in f.read_text().splitlines():
   typ,i,rest=line.split('|',2);k=(typ,int(i))
   if typ=='STACK':
    w,pattern,val=rest.split('|');k+=int(w),;v=int(val)
   else:v=ast.literal_eval(rest)
   d.setdefault(k,[]).append(v)
 return {k:max(v) if k[0]=='STACK' else [max(vals) for vals in zip(*v)] for k,v in d.items()}
old,new=life('primary'),life('repair')
a={tuple(m['key']):m for m in read(h/'memory-multi.json')}
hist={(m['workload'],int(m['temperature']=='warm')):m for m in read(h/'regular-stack-accounts.json')}
life_rows=[]
for k,now in new.items():
 if k[0]=='STACK':
  m=hist[k[1:]];prev=min(old[k],m['candidate']);base=m['fixed'];i=max(0,now-prev);c=i+m['cumulative_charge_bytes']
  passes=i<=128 and i*100<=prev and c<=256 and c*100<=2*base and now<=16384
 else:
  prev=min(old[k][-2],a[k]['after'][-2]);i=max(0,now[-2]-prev);c=i;passes=now[-1]==0 and i==0 and now[-2]<=16384
 life_rows.append(dict(key=k,remeasured=old[k],reference=prev,candidate=now,increment=i,cumulative=c,passes=passes))
write(r/'lifetime.json',life_rows)
for name,d in [('size',size),('lifetime',life_rows)]:
 print(name,len(d),'failures',[str(m)[:300] for m in d if not m['passes']],'charged',sum(m['increment']>0 for m in d))
timings=[]
for campaign,cpus in [('crossover',[5,15]),('confirmation',[3,5]),('quiet',[5,15])]:
 for cpu in cpus:
  pair={}
  for variant in ('primary','repair'):
   paths=sorted((r/campaign/str(cpu)).glob('*-'+variant+'/**/new/estimates.json'))
   assert len(paths)==4
   pair[variant]=[read(p)['median']['point_estimate'] for p in paths]
  a,b=[statistics.median(v) for v in pair.values()]
  timings.append(dict(campaign=campaign,cpu=cpu,process_median_ns=pair,primary=a,repair=b,change_percent=100*(b/a-1)))
write(r/'timings.json',timings)
for t in timings: print(t['campaign'],t['cpu'],round(t['change_percent'],3),round(t['primary'],1),round(t['repair'],1))
