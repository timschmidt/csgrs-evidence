#[path="/mnt/development/csgrs/crates/hypersolve/tests/support/krawczyk_oracle.rs"]
mod oracle;
use std::{fs,time::Instant,hint::black_box,collections::BTreeSet};
fn main() {
    let mut corpus=BTreeSet::new();
    for dir in std::env::args().skip(1) {
        for entry in fs::read_dir(dir).unwrap() {
            if let Ok(input) = <[u8;8]>::try_from(fs::read(entry.unwrap().path()).unwrap()) {
                corpus.insert(input);
            }
        }
    }
    let mut cases:Vec<_>=corpus.into_iter().collect();
    for iteration in 0..9 {
        for input in &cases {
            let begin=Instant::now();
            for _ in 0..3 {oracle::check(black_box(*input));}
            println!("{} {} {}",u64::from_be_bytes(*input),iteration,begin.elapsed().as_nanos()/3);
        }
        cases.reverse();
        let half=cases.len()/2;
        cases.rotate_left(half);
    }
}
