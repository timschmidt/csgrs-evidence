from pathlib import Path
import re,json,subprocess,hashlib,sys
sys.path.insert(0,'/dev/shm/interval-box-coverage')
from image_metrics import sizes
s=Path(__file__).parent
def sections(f):
 raw=f.read_bytes();out={}
 for line in subprocess.check_output(['readelf','-SW',f],text=True).splitlines():
  m=re.match(r'\s*\[\s*\d+\]\s+(\.\S+)\s+(\S+)\s+\S+\s+(\S+)\s+(\S+)',line)
  if m and m[2]!='NOBITS':
   o,n=(int(x,16) for x in m.groups()[2:]);out[m[1]]=hashlib.sha256(raw[o:o+n]).hexdigest()
 return out
rows={}
for name in ['certification','retained_fuzz']:
 a,b=[s/(x+'-'+name) for x in ('doc-control','doc')]
 sa,sb=map(sections,(a,b))
 assert sa.keys()==sb.keys()
 changed=[k for k in sa if sa[k]!=sb[k]];assert set(changed)<=set(['.note.gnu.build-id','.strtab'])
 assert sizes(a)==sizes(b)
 rows[name]=dict(compared=['c9a94af00','d2a67f1d1'],changed_sections=changed,metrics=sizes(b),old_sections=sa,new_sections=sb)
 print(name,'changed sections',changed)
(s/'doc-images.json').write_text(json.dumps(rows,indent=2)+'\n')
