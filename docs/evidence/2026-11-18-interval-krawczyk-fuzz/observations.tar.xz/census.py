from pathlib import Path
from collections import Counter
from itertools import product
import json
s=Path(__file__).parent
def signed(x):return x if x<128 else x-256
def bins(args):
 x,y,shear,slope,offset,gap,widths,mode=args
 x,y,gap=map(signed,(x,y,gap));gap=(abs(gap)%17)*(1 if gap>=0 else -1)
 a=shear%5-2;k=slope%5-2;u=x+a*y;p=u+offset%5-2;q=p+gap;y0=y+(mode>>3)%3-1
 radius=[widths&15,widths>>4];der=2*u-p-q;f0=(u-p)*(u-q);g0=y-k*(u-p)-y0
 m=mode%5-2;scale=-2 if mode&64 else 1;rows=[(1,m),(scale,scale*m+(16 if mode&4 else 1))]
 if mode&32:rows.reverse()
 def root(t):
  yy=y0+k*(t-p)
  return (t-a*yy,yy)
 def inside(t):
  return all(4*abs(v-c)<=r for v,c,r in zip(root(t),(x,y),radius))
 uni=('singular' if der==0 else 'outside' if 16*abs(f0)+2*radius[0]**2>4*radius[0]*abs(der) else 'noncontractive' if 2*radius[0]>=4*abs(der) else 'certified')
 (i,j),(l,m)=[(v*der-w*k,(v*der-w*k)*a+w) for v,w in rows];d=i*m-j*l
 status='certified'
 if d==0:status=f'singular-{int(i!=0 or l!=0)}'
 else:
  width=radius[0]+abs(a)*radius[1];z=[v*f0+w*g0 for v,w in rows]
  for column,(left,right) in enumerate([(m,-j),(-l,i)]):
   weight=abs(left*rows[0][0])+abs(right*rows[1][0]);step=left*z[0]+right*z[1]
   if 16*abs(step)+weight*width*width>4*radius[column]*abs(d):status=f'outside-{column}';break
   if 2*weight*width*(1+abs(a))>=4*abs(d):status=f'noncontractive-{column}';break
 return {'univariate':uni,'coupled':status,'distinct_roots_inside':str(sum(inside(t) for t in set([p,q]))),'affine':'certified' if inside(p) else 'outside'}
def count(cases):
 out={}
 for b in cases:
  for axis,value in bins(b).items():out.setdefault(axis,Counter())[value]+=1
 return out
fixed=([3,251,shear,2,offset,gap,width,mode] for shear,gap,width,mode,offset in product([1,2,4],[0,1,4,15,255],[0,1,2,3,4,16,33,136,255],[8,12,40,104,136],[0,2,4]))
sets={'native':count(fixed)}
for name in ['ci-corpus','corpus','final-corpus']:
 sets[name]=count({p.read_bytes() for p in (s/name).iterdir() if p.is_file() and p.stat().st_size==8})
(s/'census.json').write_text(json.dumps(sets,indent=2)+'\n')
print(sets['native'])
