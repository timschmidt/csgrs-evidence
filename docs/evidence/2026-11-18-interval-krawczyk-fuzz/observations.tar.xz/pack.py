from pathlib import Path
import shutil,json,hashlib,subprocess
from collections import Counter
s=Path(__file__).parent;b=s/'bundle';b.mkdir()
for p in s.iterdir():
 if p.is_file() and p.suffix in ('.json','.py','.txt','.patch'):shutil.copyfile(p,b/p.name)
shutil.copytree(s/'logs',b/'logs')
for c in ['ci-corpus','final-corpus','corpus']:
 shutil.copytree(s/c,b/'logs'/c)
for name in ['Cargo.toml','Cargo.lock','src/main.rs']:
 f=b/'logs'/'replay'/name;f.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(s/'replay'/name,f)
for a in ('c9a94af00','5b149113d'):
 (b/(a+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary','dc1360012',a]))
(b/'raw-images.json').write_text(json.dumps({p.name:[p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()] for p in s.iterdir() if p.is_file() and p.read_bytes()[:4]==b'\x7fELF'},indent=2)+'\n')
r=s/'requal';dst=b/'logs'/'requal'
shutil.copytree(r/'logs',dst/'logs')
for p in r.iterdir():
 if p.is_file():shutil.copy2(p,dst/p.name)
for name in ['crossover','confirmation','quiet']:
 for p in (r/name).glob('**/new/*.json'):
  f=dst/p.relative_to(r);f.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(p,f)
(dst/'images.json').write_text(json.dumps({p.name:[p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()] for p in (r/'images').iterdir()},indent=2)+'\n')
for name in ('krawczyk_elimination','krawczyk_proof_policy'):
 (dst/(name+'.rs')).write_bytes(subprocess.check_output(['git','show','interval-krawczyk-proof-review:crates/hypersolve/tests/'+name+'.rs']))
