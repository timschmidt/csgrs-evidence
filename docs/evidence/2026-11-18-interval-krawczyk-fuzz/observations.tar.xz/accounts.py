from pathlib import Path
import re,json,hashlib,subprocess
s=Path(__file__).parent
r=Path('docs/research/interval-size-accounts.json')
j=json.loads(r.read_text());key='new_krawczyk_corpus_test_harnesses';assert key not in j
artifacts=[]
for mode,features in [('final-optimized','all Hypersolve features'),('retained-minimal','no default Hypersolve features')]:
 p=Path(re.search(r'Running tests/krawczyk_certificates.rs \(([^)]+)\)',(s/'logs'/mode).read_text()).group(1))
 artifacts.append((p,'crates/hypersolve/tests/krawczyk_certificates.rs','Rust 1.95.0 release',features+'; workspace lock'))
artifacts.append((s/'fuzz-target/x86_64-unknown-linux-gnu/release/krawczyk_certificates','crates/hyperinterval/fuzz/fuzz_targets/krawczyk_certificates.rs',subprocess.check_output(['rustc','+nightly','--version'],text=True).strip(),'solver-certificates; standalone interval fuzz workspace lock; cargo-fuzz 0.13.2; ASan and compressed ELF debug sections'))
j[key]=[]
for p,artifact,rust,features in artifacts:
 n=p.stat().st_size;cap=64*2**20
 assert cap-n>=16*2**20
 j[key].append(dict(artifact=artifact,target='x86_64-unknown-linux-gnu',toolchain=rust,features=features,source_snapshot=(s/'commit').read_text().strip(),file_bytes=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),qualification_capacity_bytes=cap,required_free_bytes=16*2**20,remaining_bytes=cap-n,evidence='docs/evidence/2026-11-18-interval-krawczyk-fuzz'))
r.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
(s/'qualified-images.json').write_text(json.dumps(j[key],indent=2)+'\n');print([(a['file_bytes'],a['remaining_bytes']) for a in j[key]])
