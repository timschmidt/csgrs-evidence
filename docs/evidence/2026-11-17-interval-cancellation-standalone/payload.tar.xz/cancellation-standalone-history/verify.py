from pathlib import Path
from collections import Counter
import ast,gzip,hashlib,json,time
s=Path(__file__).parent;new=s.parent/'cancellation-standalone-consumer-separated';load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();start=time.monotonic();done=load(s/'completion.json');began=load(s/'started.json');summary=load(s/'summary.json');assert done['exit_code']==0 and done['seconds']<300 and summary['admitted'] is False;assert sha((s/'run.py').read_bytes())==began['driver_sha256'] and sha((s/'PROTOCOL.md').read_bytes())==began['protocol_sha256'];calls=[n.func.attr for n in ast.walk(ast.parse((s/'run.py').read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess'];assert calls==['Popen'];commands=load(s/'commands.json');assert len(commands)==done['commands']<40
for c in commands:
 stored=(s/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and sha(raw)==c['raw_sha256'] and c['exit_code']==0 and not c['timeout']
for path,digest in load(s/'historical-source-hashes.json').items():assert sha(Path(path).read_bytes())==digest
source=load(s/'source-review.json');prefixes={x['production_prefix_sha256'] for x in source['records'] if 'production_prefix_sha256' in x};assert len(prefixes)==1 and source['only_test_changes'];assert all(set(x['changed_paths'])<={'crates/hyperreal/src/dispatch_trace.rs','crates/hyperreal/tests/gmp_api_coverage.rs'} for x in source['records'] if 'changed_paths' in x)
old={tuple(x['key']):x for x in load(new/'accounts.json')};accounts=load(s/'accounts.json');assert len(accounts)==len(old)==summary['resource_accounts'];floors={(tuple(x['key']),x['metric']):x['observations'] for x in load(s/'floors.json')};verified_metrics=0
for a in accounts:
 previous=old[tuple(a['key'])];assert a['values']==previous['values'] and set(previous['failures'])<=set(a['failures']);assert not a['prior_account_reconciliation_pending']
 for metric,e in a['metrics'].items():
  before=previous['metrics'][metric];assert e['values']==before['values'] and e['total_limit']==before['total_limit'] and e['total_pass']==before['total_pass']
  if a['added_functionality']:assert e==before;continue
  assert e['absolute_cap']==before['absolute_cap'] and e['percent_cap']==before['percent_cap'] and e['denominator']==before['denominator'];assert e['historical_observations']==floors[(tuple(a['key']),metric)];change=e['changes'];assert len(change)==2 and (change[0]['before'],change[0]['after'])==('fixed','primary') and (change[1]['before'],change[1]['after'])==('primary','candidate');assert change[0]['positive_charge']>=max(o['charge'] for o in e['historical_observations']);assert change[1]['positive_charge']==before['changes'][1]['positive_charge'];assert e['cumulative_positive_charge']==sum(x['positive_charge'] for x in change);assert e['cumulative_positive_charge']>=before['cumulative_positive_charge'];assert e['remaining_absolute']==e['absolute_cap']-e['cumulative_positive_charge'];verified_metrics+=1
assert summary['failed_accounts']==sum(bool(a['failures']) for a in accounts);assert summary['failed_metrics']==dict(Counter(f for a in accounts for f in a['failures']))
comparisons=load(s/'output-comparisons.json');assert len(comparisons)==summary['historical_output_trace_comparisons']==1644;assert len({x['new_log'] for x in comparisons})==1644
for c in comparisons:
 data=[]
 for root,name in [(new,c['new_log']),(s.parent/'solver-cancellation-matched-launch',c['historical_log'])]:
  raw=gzip.decompress((root/name).read_bytes());data.append(b'\n'.join(x for x in raw.splitlines() if x.startswith((b'OUTPUT ',b'TRACE '))))
 assert data[0]==data[1] and sha(data[0])==c['full_output_trace_sha256']
sizes=load(s/'size-accounts.json');prior_sizes={(a['features'],a['kind']):a for a in load(new/'size-accounts.json')}
for a in sizes:
 prior=prior_sizes[(a['features'],a['kind'])];assert a['images']==prior['images'] and a['headroom_pass']==prior['headroom_pass']
 for metric,e in a['metrics'].items():
  before=prior['metrics'][metric];assert e['values']==before['values']
  if 'cancel-retry' in a['features']:assert e==before;continue
  assert e['absolute_cap']==before['absolute_cap'] and e['percent_cap']==before['percent_cap'];assert e['cumulative_positive_charge']>=before['cumulative_positive_charge'];assert e['cumulative_positive_charge']==sum(x['positive_charge'] for x in e['changes'])
v=dict(commands_verified=len(commands),historical_output_trace_comparisons=len(comparisons),resource_metrics_with_historical_floors=verified_metrics,failed_accounts=summary['failed_accounts'],old_failures_preserved=True,old_unadmitted_bundle_ledger_unchanged=True,source_scope_verified=True,unchanged_caps_and_fixed_baseline=True,admitted=False,seconds=time.monotonic()-start);(s/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
