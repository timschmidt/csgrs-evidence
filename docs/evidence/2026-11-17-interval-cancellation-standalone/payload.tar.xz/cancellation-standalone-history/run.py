from pathlib import Path
import copy,gzip,hashlib,json,os,resource,shutil,signal,subprocess,sys,time
from collections import Counter
s=Path(__file__).parent;root=s.parent;new=root/'cancellation-standalone-consumer-separated';old=root/'solver-cancellation-cumulative';matched=root/'solver-cancellation-matched-launch';r=Path('/mnt/development/csgrs');start=time.monotonic();deadline=start+300;commands=[];sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];sys.path.insert(0,str(new));from resource_accounting import charges

def git(name,*args):
 assert time.monotonic()<deadline and len(commands)<40;assert shutil.disk_usage('/tmp').free>=2560*1024**2 and shutil.disk_usage('/mnt/development').free>=20*1024**3;assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<128*1024**2
 t=time.monotonic();p=s/(name+'.log');timed=False
 with p.open('wb') as out:
  child=subprocess.Popen(['git','-C',str(r),*args],stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(1024**3,hard)))
  try:child.wait(timeout=min(60,deadline-t))
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();timed=True
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();commands.append(dict(name=name,command=['git','-C',str(r),*args],exit_code=child.returncode,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_sha256=sha(raw),stored_sha256=sha(stored)));save('commands.json',commands);assert child.returncode==0 and not timed;return raw.decode()

assert not (s/'started.json').exists();assert load(new/'summary.json')['admitted'] is False;assert load(new/'independent-verification-command.json')['exit_code']==0;assert not Path('/proc/340681').exists();f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();save('started.json',dict(time=time.time(),producer=os.getpid(),driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes())))
try:
 fixed='c9f1f9ac55216b762e9eb97672de1e66f3b8a3fb';historical='ee4932b4cf8482e6d4d4672833395fd937e8047f';primary='e63cbf68aea24a5939332c738c4a6652be881627';paths=['Cargo.toml','Cargo.lock','.cargo','crates/hyperreal','crates/hyperlattice','crates/hyperlimit','crates/hypersolve'];allowed={'crates/hyperreal/src/dispatch_trace.rs','crates/hyperreal/tests/gmp_api_coverage.rs'};source_records=[]
 for label,revision in [('historical',historical),('primary',primary)]:
  changed=git(label+'-paths','diff','--name-only',fixed,revision,'--',*paths).splitlines();assert set(changed)<=allowed;patch=git(label+'-diff','diff',fixed,revision,'--',*paths);source_records.append(dict(label=label,revision=revision,changed_paths=changed,diff_sha256=sha(patch.encode())))
 prefixes=[]
 for label,revision in [('fixed',fixed),('historical',historical),('primary',primary)]:
  source=git(label+'-trace-source','show',revision+':crates/hyperreal/src/dispatch_trace.rs');marker='#[cfg(test)]\nmod tests {';assert source.count(marker)==1;prefixes.append(source.split(marker)[0]);source_records.append(dict(label=label,revision=revision,trace_source_sha256=sha(source.encode()),production_prefix_sha256=sha(prefixes[-1].encode())))
 assert prefixes[0]==prefixes[1]==prefixes[2];git('accepted-path-history','log','--format=%H %s',fixed+'..'+primary,'--',*paths);save('source-review.json',dict(records=source_records,only_test_changes=True,production_trace_prefix_equal=True,scope='four workspace dependencies, root manifests/lock/Cargo config for this consumer'))
 old_sources=[old/'accounts.json',matched/'accounts.json',old/'size-accounts.json'];source_hashes={str(p):sha(p.read_bytes()) for p in old_sources};original=load(old_sources[0]);matching=load(old_sources[1]);old_sizes=load(old_sources[2]);legacy={tuple(a['key']):a for a in original};matched_accounts={tuple(a['key']):a for a in matching};floors=[];accounts=copy.deepcopy(load(new/'accounts.json'));source_summary=load(new/'summary.json')
 def reconcile(entry,observations):
  prior={}
  if observations:
   largest=max(observations,key=lambda p:(p['charge'],-p['denominator']));prior[('fixed','primary')]=dict(charge=largest['charge'],denominator=largest['denominator'],source='historical observations retained individually')
  result=charges(entry['values'],['fixed','primary','candidate'],entry['absolute_cap'],entry['percent_cap'],prior);result['historical_observations']=observations;result['historical_obligations_pass']=all(o['previous_pass'] and o['charge']<=entry['absolute_cap'] and o['charge']*100<=entry['percent_cap']*o['denominator'] for o in observations);result['incremental_pass'] &= result['historical_obligations_pass'];result['cumulative_pass'] &= result['historical_obligations_pass'];return result
 for a in accounts:
  a['prior_account_reconciliation_pending']=False
  if a['added_functionality']:continue
  key=tuple(a['key']);assert key in legacy and key in matched_accounts
  for metric,e in a['metrics'].items():
   observations=[]
   for path,source,kind in [(old_sources[0],legacy[key]['metrics'][metric],'original'),(old_sources[1],matched_accounts[key]['metrics'][metric]['conservative_with_legacy_obligations'],'matching-conservative')]:
    change=next(x for x in source['changes'] if x['before']=='fixed' and x['after']=='current');observations.append(dict(source=str(path),kind=kind,charge=change['positive_charge'],denominator=source['denominator'],previous_pass=change['incremental_pass']))
   floors.append(dict(key=a['key'],metric=metric,observations=observations));e.update(reconcile(e,observations))
   for test in ['incremental','cumulative']:
    failure=metric+':'+test
    if not e[test+'_pass'] and failure not in a['failures']:a['failures'].append(failure)
 sizes=copy.deepcopy(load(new/'size-accounts.json'))
 for a in sizes:
  a['prior_account_reconciliation_pending']=False
  if 'cancel-retry' in a['features']:continue
  olda=next(v for v in old_sizes if (v['features'],v['kind'])==(a['features'],a['kind']))
  for metric,e in a['metrics'].items():
   olde=olda['metrics'][metric];change=next(x for x in olde['changes'] if x['before']=='fixed' and x['after']=='current');observations=[dict(source=str(old_sources[2]),charge=change['positive_charge'],denominator=olde['denominator'],previous_pass=change['incremental_pass'])];e.update(reconcile(e,observations))
 # Compare completed contracts, not just cost totals, against historical images.
 historical_commands=load(matched/'commands.json');history_by_domain={}
 for c in historical_commands:
  if c['label'] in ['fixed','current'] and c['features'] in ['','trace']:
   key=(c['label'],c['features'],c['kind'],tuple(c['args']),c['repeat'],c['smoke']);assert key not in history_by_domain;history_by_domain[key]=c
 new_commands={c['log']:c for c in load(new/'commands.json')};comparisons=0;compared=[]
 for o in load(new/'observations.json'):
  if o['label'] not in ['fixed','primary'] or o['features'] not in ['','trace']:continue
  key=('current' if o['label']=='primary' else 'fixed',o['features'],o['kind'],tuple(o['args']),o['repeat'],o['smoke']);oldc=history_by_domain[key];newc=new_commands[o['log']];data=[]
  for stage,c in [(matched,oldc),(new,newc)]:
   stored=(stage/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and sha(raw)==c['raw_sha256'] and c['exit_code']==0;data.append(b'\n'.join(x for x in raw.splitlines() if x.startswith((b'OUTPUT ',b'TRACE '))))
  assert data[0] and data[0]==data[1];comparisons+=1;compared.append(dict(new_log=o['log'],historical_log=oldc['log'],full_output_trace_sha256=sha(data[0])))
 assert comparisons==1644
 save('historical-source-hashes.json',source_hashes);save('floors.json',floors);save('output-comparisons.json',compared);save('accounts.json',accounts);save('size-accounts.json',sizes)
 summary=dict(commands=len(commands),historical_output_trace_comparisons=comparisons,resource_accounts=len(accounts),failed_accounts=sum(bool(a['failures']) for a in accounts),failed_metrics=dict(Counter(f for a in accounts for f in a['failures'])),size_accounts=len(sizes),failed_size_metrics=sum(e['incremental_pass'] is False or e['cumulative_pass'] is False for a in sizes for e in a['metrics'].values()),historical_metric_floors=len(floors),positive_historical_observations=sum(o['charge']>0 for row in floors for o in row['observations']),old_unadmitted_bundle_ledger_unchanged=True,all_observed_new_failures_preserved=True,caps_unchanged=True,baseline_unchanged=True,admitted=False,seconds=time.monotonic()-start);save('summary.json',summary);assert time.monotonic()<deadline;save('completion.json',dict(exit_code=0,commands=len(commands),seconds=time.monotonic()-start));print(json.dumps(summary,indent=2))
except BaseException as error:save('completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),seconds=time.monotonic()-start,automatic_retry=False));raise
