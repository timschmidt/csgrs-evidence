# Standalone history reconciliation review

Read-only review after complete consumer collection and its offline audit.
Confirm source changes on the accepted primary path from fixedc9f1f9ac through
historical currentee4932 to primarye63cbf68 in the four consumer kernel crates,
root manifests/lock and Cargo config. Confirm production trace prefix unchanged
and only test paths/body differ. Preserve complete source diffs and hashes.

Compare every new fixed/primary completed consumer output/trace to the matching
historical same-source observation, including both policies, all4cases, resource
and32cycle lifetime domains. Retain prior fixed-to-current positive charges,
denominators and failed obligations from both original and matching-launch
ledgers when mapping that accepted path to fixed-to-primary. Reconcile the new
candidate boundary separately; all unrelated unadmitted solver/wrapper branch
charges remain in their complete older ledger and are not removed or declared
passing. Preserve new observed charges too. No cap/baseline change, waiver,
geometry rerun or admission. Added retry has no fabricated correct-old baseline.

One300second offline window,40directchildren at a single counted spawn site,
60seconds perGit;1GiBfile,128MiBstage,2.5GiBtmp/20GiBdevelopment reserves. All
measurement producers terminal, source control restored, held queue unchanged.
Original command limits and all prior failures stay intact. No automatic retry.
