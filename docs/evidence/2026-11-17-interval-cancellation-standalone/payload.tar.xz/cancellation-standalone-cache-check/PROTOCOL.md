# Cargo cache warning correction

Original standalone functional producer remains immutable. Root filesystem has
zero user-available bytes; Cargo emitted its cache last-use database warning.
This does not establish a compiler warning or test failure, but precludes a
warning-free validation claim. Preserve original warnings and failed strict audit.
Use an isolated RAM Cargo home with unchanged registry and bin symlinks and a
copy of the existing disposable cache metadata database. Do not modify root
storage or compiler/source dependencies. Repeat only affected strict Clippy,
docs and examples/benches checks, plus native witness Clippy; no tests rerun.

After functional producer is terminal/successful and original verifier terminal,
check out its unchanged standalone candidate, use existing RAM build target,
run five checks and restore original control branch. One1800second window,
60directchildren at one Popen site,600seconds percheck,60Git;sixbuildjobs,
1GiBfile,128MiBstage,2.5GiBtmp/20GiBdevelopment reserves. Compiler descendants
excluded. No automatic retry. Fail on any warning or nonzero exit. Queue held,
watcher terminal. This is environmental correction, not admission or cap change.
