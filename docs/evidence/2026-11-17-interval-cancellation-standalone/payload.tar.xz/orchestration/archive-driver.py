from pathlib import Path
import gzip,hashlib,importlib.util,io,json,shutil,subprocess,tarfile,time
root=Path('/tmp/interval-refactor');out=Path('/dev/shm/cancellation-standalone-evidence');e=Path('/mnt/development/csgrs-evidence');main=Path('/mnt/development/csgrs');record='docs/evidence/2026-11-17-interval-cancellation-standalone';dest=e/record;sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());git=lambda *a:subprocess.check_output(['git','-C',str(e),*a]);start=time.monotonic();before=git('rev-parse','HEAD').decode().strip();stages=['cancellation-standalone','cancellation-standalone-cache-check','cancellation-standalone-wasm','cancellation-standalone-consumer','cancellation-standalone-consumer-separated','cancellation-standalone-history']
assert not out.exists() and not dest.exists() and not git('status','--porcelain=v1')
assert load(root/'cancellation-standalone/completion.json')['exit_code']==0 and load(root/'cancellation-standalone/independent-verification-command.json')['exit_code']==1
assert load(root/'cancellation-standalone-consumer/completion.json')['exit_code']==1
for name in ['cancellation-standalone-cache-check','cancellation-standalone-wasm','cancellation-standalone-consumer-separated','cancellation-standalone-history']:assert load(root/name/'completion.json')['exit_code']==load(root/name/'independent-verification-command.json')['exit_code']==0
for name in stages:
 pid=load(root/name/'started.json')['producer'];assert not Path(f'/proc/{pid}').exists()
f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();out.mkdir();members={};origins=[]
def include(p,name):
 raw=p.read_bytes();assert name not in members;members[name]=raw;origins.append(dict(source=str(p),path=name,bytes=len(raw),sha256=sha(raw),mode=p.stat().st_mode&0o777))
for name in stages:
 for p in sorted((root/name).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:include(p,name+'/'+p.relative_to(root/name).as_posix())
 include(root/(name+'-driver.log'),'orchestration/'+name+'-driver.log')
images=[]
for v in load(root/'cancellation-standalone/images.json'):images.append(('native-'+v['label'],v['image']['path'],v['image']['bytes'],v['image']['sha256']))
for v in load(root/'cancellation-standalone-wasm/images.json'):images.append(('wasm-'+v['label'],v['path'],v['bytes'],v['sha256']))
for stage in ['cancellation-standalone-consumer','cancellation-standalone-consumer-separated']:
 for b in load(root/stage/'builds.json'):
  for kind,v in b['artifacts'].items():images.append((stage+'-'+b['label']+'-'+(b['features'].replace(',','-') or 'default')+'-'+kind,v['path'],v['file'],v['sha256']))
for name,path,length,digest in images:
 p=Path(path);raw=p.read_bytes();assert len(raw)==length and sha(raw)==digest;include(p,'images/'+name)
include(Path(__file__),'orchestration/archive-driver.py')
include(root/'solver-cancellation-qualification-archive.json','baseline/prior-archive.json')
with tarfile.open(out/'payload.tar.xz','w:xz',preset=3,format=tarfile.PAX_FORMAT) as archive:
 for name,raw in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=next(o['mode'] for o in origins if o['path']==name);info.mtime=0;archive.addfile(info,io.BytesIO(raw))
(out/'origins.json.gz').write_bytes(gzip.compress((json.dumps(origins,indent=2)+'\n').encode(),mtime=0))
seen=set()
with tarfile.open(out/'payload.tar.xz','r:xz') as archive:
 for member in archive:
  assert member.isfile() and member.name in members and member.name not in seen;seen.add(member.name);raw=archive.extractfile(member).read();assert raw==members[member.name]
assert seen==members.keys()
for o in origins:assert sha(Path(o['source']).read_bytes())==o['sha256']
(out/'README.md').write_text('''Standalone cancellation publication qualification on primary.

Candidate8a454c86054ae4d5a4b0813d8e9edd1e6775ec47 is isolated and unadmitted.
Full functional audit:1301affected test invocations, native public witness,
three strict Clippy configurations, docs/examples/benches checks and formatting.
WASM: one old success/two expected assertion traps, three candidate successes,
two strict targetClippy configurations. Original Cargo metadata disk-full warning
and strict-audit failure are preserved alongside identical warning-free checks
using isolated RAM Cargo metadata and unchanged dependency registry sources.

Complete-consumer collection retains the initial feature-coupling build failure,
12initial images and12ordinary controls. Reviewed separation changes only the
cancel-retry dependency on added and two cfg selectors for the existing case
field. All assertions and fixture operations remain intact; the older seven-case
bundle's obligations are separate and unchanged. Corrected collection uses the
same original deadline and aggregate child ceiling. Its30final images and full
outputs, traces, complete lifetime observations, stack probes and image metrics
are retained. Observed accounts are preserved separately from historical-floor accounts;
1644historical full-output/trace comparisons and prior positive charges are
retained for the accepted primary path. The unadmitted bundle ledger remains
unchanged.12of288observed resource accounts exceed current growth allowances;
including historical floors yields17failing accounts, all with active trace.
Absolute capacities, stack, headroom and lifetime retention checks pass. Native
image growth/headroom checks pass. Runtime, distribution and admission remain open. No caps
or accepted exception counts change. No timing or arbitrary-input memory claim.

payload.tar.xz contains all stage files except Python bytecode caches, complete
command logs, source/protocol/reviewer files, failure records and46validated
images. origins.json.gz maps members to original paths, modes and SHA256 hashes.
Every original and decoded member is verified before commit; committed record
files are verified afterward. Restore original paths/modes for unchanged audit
replay, together with the earlier cancellation-qualification archive referenced
by historical-source-hashes.json. Earlier branch failures/charges remain intact.
''')
total=sum(p.stat().st_size for p in out.iterdir());free=shutil.disk_usage(e).free;assert free-3*total-20*1024**2>=20*1024**3,(total,free);shutil.copytree(out,dest);subprocess.run(['git','-C',str(e),'add','--sparse','--',record],check=True);subprocess.run(['git','-C',str(e),'diff','--cached','--check'],check=True);changed=git('diff','--cached','--name-only').decode().splitlines();assert changed and all(p.startswith(record+'/') for p in changed)
spec=importlib.util.spec_from_file_location('m',main/'scripts/evidence_archive.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.ROOTS={record:False};rows=m.manifest(str(e),git('write-tree').decode().strip());assert len(rows)==2;subprocess.run(['git','-C',str(e),'commit','-m','Preserve standalone cancellation functional and consumer qualification'],check=True,stdout=subprocess.PIPE);revision=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain=v1') and m.manifest(str(e),revision)==rows;assert git('diff','--name-only',before,revision).decode().splitlines()==changed
for p in out.iterdir():assert git('show',revision+':'+record+'/'+p.name)==p.read_bytes()
_,count,size,digest=rows[1].split('\t');v=dict(previous_revision=before,revision=revision,record=record,row=rows[1],files=int(count),bytes=int(size),sha256=digest,payload_members=len(members),payload_raw_bytes=sum(map(len,members.values())),images=len(images),all_original_and_payload_hashes_verified=True,all_committed_files_verified=True,previous_archive_paths_unchanged=True,seconds=time.monotonic()-start);(root/'cancellation-standalone-archive.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
