from pathlib import Path
import ast,gzip,hashlib,json,re,time
s=Path(__file__).parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');done=load(s/'completion.json');began=load(s/'started.json');prepared=load(s/'prepared.json')
assert done['exit_code']==0 and done['seconds']<3600 and done['source_restored'];assert sha((s/'run.py').read_bytes())==began['driver_sha256'] and sha((s/'PROTOCOL.md').read_bytes())==began['protocol_sha256'] and sha((s/'prepared.json').read_bytes())==began['prepared_sha256'];calls=[n.func.attr for n in ast.walk(ast.parse((s/'run.py').read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess'];assert calls==['Popen']
commands=load(s/'commands.json');assert len(commands)==done['commands'] and len({c['name'] for c in commands})==len(commands);assert done['aggregate_direct_children']==len(commands)+prepared['preparation_git_reads']<160;assert prepared['preparation_git_reads']==12;raws={}
for c in commands:
 stored=(s/c['log']).read_bytes();raw=gzip.decompress(stored);assert len(stored)==c['stored_bytes'] and sha(stored)==c['stored_sha256'] and len(raw)==c['raw_bytes'] and sha(raw)==c['raw_sha256'];assert c['exit_code']==c['expected_exit_code'] and not c['timeout'];raws[c['name']]=raw.decode()
 if 'clippy' in c['name'] or c['name']=='owner-consumer-docs':assert not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines())
expected_failures={'baseline-witness','baseline-owner-regressions','baseline-adapter-regression'};assert {c['name'] for c in commands if c['exit_code']}==expected_failures
assert 'result: Ok(7)' in raws['baseline-witness'] and 'cancellation must be observed before publishing an uninstrumented result' in raws['baseline-witness'];assert 'kind: Cancellation, limit: 0, used: 0, requested: 0' in raws['candidate-witness']
assert '3 passed; 5 failed; 0 ignored' in raws['baseline-owner-regressions'];assert '0 passed; 1 failed; 0 ignored' in raws['baseline-adapter-regression']
failed=['drops_unpolled_result_and_allows_fresh_retry','observes_precancelled_token_after_callback','observes_cross_thread_request','propagates_unpolled_parent_request','keeps_inner_request_local']
for name in failed:assert 'work_budget::tests::cancellation_publication_'+name+' ... FAILED' in raws['baseline-owner-regressions']
suites={}
for name in ['owner-no-default','owner-all-features','owner-resultants','adapter-tests']:
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',raws[name]);assert rows and all(all(int(v)==0 for v in row[1:]) for row in rows);suites[name]=[int(row[0]) for row in rows]
for name in ['owner-no-default','owner-all-features']:
 for test in failed+['preserves_first_failure','unwinding_restores_parent','ordinary_budget_and_uncancelled_scope_keep_values']:assert 'cancellation_publication_'+test+' ... ok' in raws[name]
assert 'cancellation_at_publication_cannot_escape_as_a_provisional_value ... ok' in raws['adapter-tests'];assert 'cancelled_stalled_stroke_releases_its_temporary_heap ... ok' in raws['adapter-tests']
for i,v in enumerate(prepared['files']):
 before=(s/f'before-{i}.rs').read_bytes();after=(s/f'candidate-{i}.rs').read_bytes();assert sha(before)==v['before_sha256'] and sha(after)==v['candidate_sha256']
 if i in [1,3]:assert after.startswith(before)
strip_docs=lambda text:'\n'.join(line for line in text.splitlines() if not line.lstrip().startswith(('///','//!')))
assert strip_docs((s/'before-2.rs').read_text())==strip_docs((s/'candidate-2.rs').read_text())
source=(s/'candidate-0.rs').read_text();source=source.replace('enter::<false, T>(', 'enter(').replace('enter::<true, T>(', 'enter(').replace('fn enter<const CHECK_CANCELLATION: bool, T>(', 'fn enter<T>(').replace('    if CHECK_CANCELLATION {\n        let _ = exhaustion();\n    }\n','');assert strip_docs(source)==strip_docs((s/'before-0.rs').read_text())
patch=(s/'candidate.patch').read_text();paths=re.findall(r'^diff --git a/(\S+) b/\S+',patch,re.M);assert sorted(paths)==sorted([v['path'] for v in prepared['files']]+['docs/MIGRATIONS.md']);assert raws['candidate-head'].strip()==done['revision']==load(s/'candidate.json')['revision'];assert raws['restored-head'].strip()=='4f41bd58415d936968e1955dbd431f0cb5e988f0' and not raws['restored-clean'].strip() and not raws['candidate-clean'].strip()
for name,v in load(s/'witness-source.json').items():
 raw=(s/'witness'/name).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256']
assert (s/'witness/main.rs').read_bytes()==(s.parent/'solver-cancellation-scope/candidate-witness/main.rs').read_bytes()
images=load(s/'images.json');assert [v['label'] for v in images]==['baseline','candidate'];assert [v['revision'] for v in images]==[done['base'],done['revision']]
for v in images:
 raw=Path(v['image']['path']).read_bytes();assert len(raw)==v['image']['bytes'] and sha(raw)==v['image']['sha256']
v=dict(base=done['base'],candidate=done['revision'],producer_commands=len(commands),preparation_git_reads=12,aggregate_direct_children=done['aggregate_direct_children'],expected_failure_commands=3,baseline_owner_failures=5,baseline_owner_passing_controls=3,baseline_adapter_failures=1,suites=suites,candidate_test_invocations=sum(sum(x) for x in suites.values()),strict_clippy_configurations=3,strict_docs_pass=True,examples_benches_check_pass=True,format_pass=True,native_witness_images=2,original_assertions_preserved=True,adapter_executable_code_unchanged=True,only_scope_local_owner_change=True,source_restored=True,prior_bundle_failures_unchanged=True,admitted=False,cost_and_remaining_admission_open=True,producer_seconds=done['seconds'],seconds=time.monotonic()-start);save('verification.json',v);print(json.dumps(v,indent=2))
