from pathlib import Path
import gzip,hashlib,json,os,resource,shutil,signal,subprocess,time
s=Path(__file__).parent;r=Path('/dev/shm/interval-trace-materialization/csgrs');h=s/'witness';target=Path('/dev/shm/interval-cancellation-standalone-target');art=Path('/dev/shm/interval-cancellation-standalone-images');start=time.monotonic();deadline=start+3600;commands=[];names=set();sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(Path(p).read_text());save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');hard=resource.getrlimit(resource.RLIMIT_FSIZE)[1];prepared=load(s/'prepared.json');base=prepared['base'];control='4f41bd58415d936968e1955dbd431f0cb5e988f0'
env=os.environ|dict(CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='6',CARGO_NET_OFFLINE='true',HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1')
def guard():
 f=Path('/proc/1621335/stat').read_text().rsplit(')',1)[1].split();assert f[0]=='T' and f[19]=='38218939' and not Path('/proc/3416600').exists();assert time.monotonic()<deadline and len(commands)+prepared['preparation_git_reads']<160;assert shutil.disk_usage('/mnt/development').free>=20*1024**3 and shutil.disk_usage('/tmp').free>=2560*1024**2;assert sum(p.stat().st_size for p in s.rglob('*') if p.is_file())<512*1024**2

def run(name,args,work=r,cap=1200,expected=0,executable=None,extra_env=None):
 guard();assert name not in names;names.add(name);t=time.monotonic();p=s/(name+'.log');timed=False;child_env=env|(extra_env or {})
 with p.open('wb') as output:
  child=subprocess.Popen(args,cwd=work,env=child_env,executable=executable,stdout=output,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=lambda:resource.setrlimit(resource.RLIMIT_FSIZE,(64*1024**2 if executable else 1024**3,hard)));save('active.json',dict(producer=os.getpid(),child=child.pid,name=name,number=len(commands)+1,aggregate_direct_children=len(commands)+1+prepared['preparation_git_reads'],remaining=deadline-t))
  try:child.wait(timeout=min(cap,deadline-t))
  except BaseException as error:
   os.killpg(child.pid,signal.SIGKILL);child.wait()
   if isinstance(error,subprocess.TimeoutExpired):timed=True
   else:raise
 raw=p.read_bytes();stored=gzip.compress(raw,compresslevel=1,mtime=0);p.with_suffix('.log.gz').write_bytes(stored);p.unlink();c=dict(name=name,command=args,cwd=str(work),executable=executable,environment_additions=extra_env or {},exit_code=child.returncode,expected_exit_code=expected,timeout=timed,seconds=time.monotonic()-t,log=name+'.log.gz',raw_bytes=len(raw),raw_sha256=sha(raw),stored_bytes=len(stored),stored_sha256=sha(stored));commands.append(c);save('commands.json',commands);save('active.json',dict(producer=os.getpid(),child=None));assert child.returncode==expected and not timed,(name,child.returncode,expected);return raw.decode()
def git(name,*args):return run(name,['git',*args],cap=60).strip()
def build_witness(label,revision,expected):
 run(label+'-witness-build',['cargo','+1.95.0','build','--release','--locked','--offline'],work=h)
 p=art/label;shutil.copy2(target/'release/cancellation-boundary-witness',p);images.append(dict(label=label,revision=revision,image=dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))));save('images.json',images)
 raw=run(label+'-witness',['cancellation-publication-control'],work=h,cap=60,expected=expected,executable=str(p));assert ('result: Ok(7)' in raw if expected else 'kind: Cancellation' in raw)
assert not (s/'started.json').exists() and not art.exists();art.mkdir();target.mkdir(exist_ok=True);images=[];guard();save('started.json',dict(time=time.time(),producer=os.getpid(),deadline_seconds=3600,direct_child_limit=160,preparation_git_reads=prepared['preparation_git_reads'],driver_sha256=sha(Path(__file__).read_bytes()),protocol_sha256=sha((s/'PROTOCOL.md').read_bytes()),prepared_sha256=sha((s/'prepared.json').read_bytes()),environment_overrides={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','HYPERSOLVE_SKIP_BENCHMARK_REPORTS']}))
try:
 assert git('initial-head','rev-parse','HEAD')==control and git('initial-branch','branch','--show-current')=='interval-trace-materialization' and not git('initial-clean','status','--porcelain=v1')
 git('base-checkout','checkout','--detach',base)
 for i,v in enumerate(prepared['files']):assert sha((r/v['path']).read_bytes())==v['before_sha256']==sha((s/f'before-{i}.rs').read_bytes());assert sha((s/f'candidate-{i}.rs').read_bytes())==v['candidate_sha256']
 assert (h/'main.rs').read_bytes()==(s.parent/'solver-cancellation-scope/candidate-witness/main.rs').read_bytes();run('witness-lock',['cargo','+1.95.0','generate-lockfile','--offline'],work=h);save('witness-source.json',{p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in h.iterdir() if p.is_file()})
 build_witness('baseline',base,101)
 git('witness-branch','checkout','-b','interval-cancellation-standalone-witness')
 for i in [1,3]:(r/prepared['files'][i]['path']).write_bytes((s/f'candidate-{i}.rs').read_bytes())
 git('witness-add','add',prepared['files'][1]['path'],prepared['files'][3]['path']);git('witness-commit','commit','-m','Reproduce cancellation publication contract on current primary');witness_revision=git('witness-head','rev-parse','HEAD')
 raw=run('baseline-owner-regressions',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--no-default-features','--lib','cancellation_publication_'],expected=101);assert '3 passed; 5 failed' in raw
 run('baseline-adapter-regression',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypercurve','--test','work_budget','cancellation_at_publication_cannot_escape_as_a_provisional_value'],expected=101)
 git('candidate-branch','checkout','-b','interval-cancellation-standalone')
 for i in [0,2]:(r/prepared['files'][i]['path']).write_bytes((s/f'candidate-{i}.rs').read_bytes())
 p=r/'docs/MIGRATIONS.md';text=p.read_text();assert text.startswith('# Migrations\n\n');p.write_text('# Migrations\n\n'+(s/'migration.md').read_text()+text[len('# Migrations\n\n'):]);git('candidate-add','add',*[v['path'] for v in prepared['files']],'docs/MIGRATIONS.md');git('candidate-commit','commit','-m','Check cancellable publication in its owning scope on primary');revision=git('candidate-head','rev-parse','HEAD');save('candidate.json',dict(base=base,witness_revision=witness_revision,revision=revision,files=prepared['files'],admitted=False))
 run('owner-no-default',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--lib','--no-default-features'])
 run('owner-all-features',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--lib','--all-features'])
 run('owner-resultants',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypersolve','--test','ordered_field_resultant','--test','ordered_field_resultants'])
 run('adapter-tests',['cargo','+1.95.0','test','--release','--locked','--offline','-p','hypercurve','--test','work_budget','--test','cancellation_release'])
 run('owner-clippy',['cargo','+1.95.0','clippy','--locked','--offline','-p','hypersolve','--all-targets','--all-features','--','-D','warnings'])
 run('adapter-clippy',['cargo','+1.95.0','clippy','--locked','--offline','-p','hypercurve','--all-features','--test','work_budget','--test','cancellation_release','--','-D','warnings'])
 run('owner-consumer-docs',['cargo','+1.95.0','doc','--locked','--offline','--no-deps','--all-features','-p','hypersolve','-p','hypercurve'],extra_env={'RUSTDOCFLAGS':'-D warnings'})
 run('owner-examples-benches',['cargo','+1.95.0','check','--locked','--offline','--all-features','--examples','--benches','-p','hypersolve'])
 build_witness('candidate',revision,0);run('witness-clippy',['cargo','+1.95.0','clippy','--locked','--offline','--all-targets','--','-D','warnings'],work=h)
 run('format',['cargo','+1.95.0','fmt','--all','--','--check']);git('whitespace','diff','--check');assert not git('candidate-clean','status','--porcelain=v1');patch=git('candidate-patch','diff',base,revision,'--',*[v['path'] for v in prepared['files']],'docs/MIGRATIONS.md');(s/'candidate.patch').write_text(patch+'\n')
 git('restore-control','checkout','interval-trace-materialization');assert git('restored-head','rev-parse','HEAD')==control and not git('restored-clean','status','--porcelain=v1')
 save('completion.json',dict(exit_code=0,base=base,witness_revision=witness_revision,revision=revision,commands=len(commands),aggregate_direct_children=len(commands)+prepared['preparation_git_reads'],seconds=time.monotonic()-start,source_restored=True,admitted=False));print('Standalone publication functional qualification complete',flush=True)
except BaseException as error:save('completion.json',dict(exit_code=1,error=repr(error),commands=len(commands),aggregate_direct_children=len(commands)+prepared['preparation_git_reads'],seconds=time.monotonic()-start,automatic_retry=False,admitted=False));raise
finally:save('commands.json',commands)
