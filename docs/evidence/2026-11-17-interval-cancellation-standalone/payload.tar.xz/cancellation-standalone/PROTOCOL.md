# Standalone cancellation publication qualification

Full goal remains the entire interval refactor plan. Owner Hypersolve work-budget
scope and Hypercurve direct adapter, P5/P6/P20/P36, plan14.4 aborted work not
published. Current primary e63cbf68aea24a5939332c738c4a6652be881627 still has the
older documented behavior: cancellation without a subsequent instrumented check
can publish a callback value. Its four affected owner/consumer source/test files
are byte-identical to the five-repair bundle's pre-publication source. Reproduce
on this current base; historical bundle checks do not prove this new revision.

Evaluate the already reviewed scope-local implementation independently of the
unadmitted kernel migrations. This is an intentional publication-contract
extension, not a behavior-preserving refactor. Check existing exhaustion once
after callback return and before scope removal, only for cancellable scopes,
using the private const flag. Preserve callbacks for pre-cancelled tokens, prior
failure precedence, nested-scope propagation/isolation, cross-thread requests,
unwind cleanup and fresh-token retry. No preemption, rollback, arbitrary work,
latency or memory bound is promised; requests after the final check can race
with success. Copy original eight owner and one adapter acceptance tests intact.
No trace representation change and no other solver repair is included.

This new isolated source does not rebase the fixed program baseline c9f1f9ac...
or clear any previous bundle failure/positive charge. Its distinct source and
new measurements must be reported separately. No numerical allowance, cumulative
account migration or source admission follows from this functional campaign.
Before retention still require complete consumer lifetimes/stack, fixed-baseline
and incremental costs, meaningful runtime/benchmarks, final images/distribution
and affected validation. Do not use old incorrect/unsupported outcomes as costs
for newly successful contracts. All original seven-case bundle obligations stay.

Build the unchanged native public witness against current-primary owner sources;
its expected assertion failure must print the old completed value. Add only the
eight owner tests on an isolated witness branch and reproduce the exact five
failures/three passing controls. Then import only the existing scope-local
owner/adapter change and unchanged regression files, with a standalone migration
note on an isolated candidate branch. Run full owner release library with no
features/all features, both ordered-field integrations, Hypercurve work-budget
and original cancellation-release suites, strict owner and affected adapter
Clippy, strict owner/adapter docs, example/bench checks and formatting. Preserve
unchanged public native witness success. No weakened assertions or fixtures.

One3600-second functional window,160directchildren at one counted Popen site;
1200seconds/build/test/check,60seconds/witness andGit. Compiler descendants
explicitly excluded. File1GiBbuild/64MiBwitness,512MiBcompleted total stage;
2.5GiBtmp/20GiBdevelopment free before each child, source/target/images RAM.
No automatic retry/deadline reset. Restore original source worktree branch/revision
on success, keep queue1621335/start38218939 held and watcher3416600 terminal.
No archiving while validation runs. Offline verification capped300seconds.

Twelve read-only Git source preparations precede the producer and are recorded
in prepared.json. Charge them against the same160-child ceiling; subsequent
producer commands all pass through its single counted spawn site. They perform
no build, test or geometry execution and do not reset a prior campaign.
