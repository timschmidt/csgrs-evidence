from pathlib import Path
import ast,gzip,hashlib,json,time
s=Path(__file__).parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();done=load(s/'completion.json');began=load(s/'started.json');assert done['exit_code']==0 and done['source_restored'] and done['seconds']<1200
for file,key in [('run.py','driver_sha256'),('PROTOCOL.md','protocol_sha256'),('provenance.json','provenance_sha256')]:assert sha((s/file).read_bytes())==began[key]
calls=[n.func.attr for n in ast.walk(ast.parse((s/'run.py').read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess'];assert calls==['Popen'];commands=load(s/'commands.json');assert len(commands)==done['commands']<100 and len({c['name'] for c in commands})==len(commands);raws={}
for c in commands:
 stored=(s/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and len(stored)==c['stored_bytes'] and sha(raw)==c['raw_sha256'] and len(raw)==c['raw_bytes'];assert c['exit_code']==0 and not c['timeout'];assert not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines());raws[c['name']]=raw.decode()
for name,v in load(s/'sources.json').items():
 raw=(s/name).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256']
for name,v in load(s/'provenance.json').items():assert sha((s/'consumer'/name).read_bytes())==v['sha256']==sha(Path(v['source']).read_bytes())
assert (s/'invoke-wasm.cjs').read_bytes()==(s.parent/'solver-cancellation-scope/invoke-wasm.cjs').read_bytes();assert raws['baseline-head'].strip()==done['base'] and raws['candidate-head'].strip()==done['candidate'];assert raws['restored-head'].strip()==raws['initial-head'].strip()=='4f41bd58415d936968e1955dbd431f0cb5e988f0' and not raws['candidate-clean'].strip() and not raws['restored-clean'].strip()
for label in ['baseline','candidate']:
 rows=[json.loads(x) for x in raws[label+'-invoke'].splitlines()];assert len(rows)==3
 for case,row in enumerate(rows):assert row['case']==case and row['expected_trap']==(label=='baseline' and case!=0) and row.get('assertions_pass',False)==(label=='candidate' or case==0)
images=load(s/'images.json');assert [x['label'] for x in images]==['baseline','candidate'];assert [x['revision'] for x in images]==[done['base'],done['candidate']]
for v in images:
 raw=Path(v['path']).read_bytes();assert len(raw)==v['bytes'] and sha(raw)==v['sha256'] and raw[:8]==b'\0asm\x01\0\0\0'
v=dict(base=done['base'],candidate=done['candidate'],commands=len(commands),images=2,baseline_success=1,baseline_expected_assertion_traps=2,candidate_success=3,unchanged_original_witness=True,strict_target_clippy_configurations=2,format_pass=True,source_restored=True,producer_seconds=done['seconds'],seconds=time.monotonic()-start,admitted=False,production_ABI_or_memory_claim=False);(s/'verification.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v,indent=2))
