# Standalone publication WASM witness

After the standalone functional producer is terminal and successful, build the
unchanged earlier no-import WASM public witness on primarye63cbf68 and standalone
candidate8a454c86054ae4d5a4b0813d8e9edd1e6775ec47. Only dependency paths differ.
The three fresh-instance cases cover uncancelled, callback-cancelled and
pre-cancelled operation, callback invocation, exact error/usage, restored scope
and fresh-token retry. Preserve baseline one success/two expected assertion traps
and candidate three successes. Baseline traps are missing-contract assertions,
not typed resource exhaustion or evidence of a complete geometric result.

This is a public boundary/platform witness, not a production WASM ABI, full
consumer memory, final shipped-size admission or full browser qualification.
The original scopes, complete fixtures, caps, failures and cumulative charges
remain unchanged. No exception or primary source merge follows from this stage.

One1200-second producer window,100directchildren at one spawn site;600perbuild/
Clippy,60per invocation/Git. Compiler descendants explicitly excluded. File1GiB,
completed stage128MiB,2.5GiBtmp/20GiBdevelopment free before each child. Source/
target/images RAM. Strict target Clippy, witness formatting and source hashes.
Restore original worktree control branch. No automatic retry/deadline reset;
queue1621335/start38218939 held, watcher3416600 terminal. Offline verification
capped300seconds. Archive only after validation is terminal.

Also wait for the isolated Cargo cache correction checks to finish successfully.
Use that RAM-backed Cargo metadata home with unchanged registry sources; the
original system-disk warning and correction evidence remain separate.
