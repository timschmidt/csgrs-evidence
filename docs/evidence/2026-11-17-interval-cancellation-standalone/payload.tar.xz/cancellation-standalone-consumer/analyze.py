from pathlib import Path
from collections import Counter,defaultdict
import ast,gzip,hashlib,itertools,json,re,time
from resource_accounting import fields,history,limits,charges
s=Path(__file__).parent;start=time.monotonic();load=lambda p:json.loads(Path(p).read_text());sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(s/n).write_text(json.dumps(v,indent=2)+'\n');done=load(s/'completion.json');began=load(s/'started.json');assert done['exit_code']==0 and done['source_restored'] and done['seconds']<5400
for file,key in [('run.py','driver_sha256'),('PROTOCOL.md','protocol_sha256'),('provenance.json','provenance_sha256'),('boundaries.json','boundaries_sha256')]:assert sha((s/file).read_bytes())==began[key]
calls=[n.func.attr for n in ast.walk(ast.parse((s/'run.py').read_text())) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess'];assert calls==['Popen'];commands=load(s/'commands.json');assert len(commands)==done['commands']<4500 and len({c['name'] for c in commands})==len(commands);cmds={c['log']:c for c in commands};raws={};builds=load(s/'builds.json');observations=load(s/'observations.json');boundaries=load(s/'boundaries.json');order=[x[0] for x in boundaries];revisions=dict(boundaries);expected_builds={(label,feature) for label in order for feature in (['','trace']+(['cancel-retry','trace,cancel-retry'] if label!='fixed' else []))};assert {(b['label'],b['features']) for b in builds}==expected_builds and len(builds)==10
sources={p.name:sha(p.read_bytes()) for p in (s/'consumer').iterdir() if p.is_file()}
for v in load(s/'provenance.json'):
 assert sources[v['name']]==v['sha256'] and sha(Path(v['source']).read_bytes())==v['original_sha256']
 if v['name']!='Cargo.toml':assert v['sha256']==v['original_sha256']
audit_provenance=load(s/'accounting-provenance.json');assert sha(Path(audit_provenance['source']).read_bytes())==audit_provenance['source_sha256'] and sha((s/'resource_accounting.py').read_bytes())==audit_provenance['extracted_sha256']
images={}
for b in builds:
 assert b['revision']==revisions[b['label']] and b['sources']==sources and b['reproduction']==(b['label']=='primary' and 'cancel-retry' in b['features']);assert set(b['artifacts'])=={'resource','lifetime','reused'}
 for kind,a in b['artifacts'].items():
  raw=Path(a['path']).read_bytes();assert len(raw)==a['file'] and sha(raw)==a['sha256'];images[a['path']]=(b,kind)
expected=[]
for b in builds:
 for kind in ['resource','lifetime','reused']:expected.append((b['label'],b['features'],kind,tuple(['0','observe','0','165','passive','strict','reuse'] if kind=='resource' else ['0','strict','passive','32']),-1,True,101 if b['reproduction'] else 0))
 if b['reproduction']:continue
 for case,policy,trace in itertools.product(range(4),['strict','approx'],['passive','active'] if 'trace' in b['features'] else ['passive']):
  for reuse,warm in itertools.product(['reuse','rebuild'],[0,1]):
   for mode in ['observe','stack','stack-drop']:
    for pattern,rep in itertools.product([165] if mode=='observe' else [165,90],range(3) if mode=='observe' else [0]):expected.append((b['label'],b['features'],'resource',(str(case),mode,str(warm),str(pattern),trace,policy,reuse),rep,False,0))
  for kind,rep in itertools.product(['lifetime','reused'],range(3)):expected.append((b['label'],b['features'],kind,(str(case),policy,trace,'32'),rep,False,0))
actual=[(o['label'],o['features'],o['kind'],tuple(o['args']),o['repeat'],o['smoke'],o['expected_exit_code']) for o in observations];assert Counter(expected)==Counter(actual) and len(set(actual))==len(actual)==done['observations'];observation_logs={o['log'] for o in observations}
for c in commands:
 stored=(s/c['log']).read_bytes();raw=gzip.decompress(stored);assert sha(stored)==c['stored_sha256'] and len(stored)==c['stored_bytes'] and sha(raw)==c['raw_sha256'] and len(raw)==c['raw_bytes'];assert c['exit_code']==c['expected_exit_code'] and not c['timeout']
 if c['log'] not in observation_logs:assert c['exit_code']==0 and not any(x.startswith((b'warning:',b'warning[')) for x in raw.splitlines());raws[c['name']]=raw.decode()
assert sum(c['name'].startswith('clippy-') for c in commands)==4;assert raws['initial-head'].strip()==raws['restored-head'].strip()=='4f41bd58415d936968e1955dbd431f0cb5e988f0';assert not raws['initial-clean'].strip() and not raws['candidate-clean'].strip() and not raws['restored-clean'].strip()
for label,revision in boundaries:assert raws[label+'-head'].strip()==revision
refs={};plain={};comparisons=Counter();counts=Counter();heap=defaultdict(lambda:defaultdict(list));stacks=defaultdict(lambda:defaultdict(list));hist=defaultdict(lambda:defaultdict(list))
for o in observations:
 c=cmds[o['log']];b,kind=images[c['executable']];assert c['command']==['cancellation-'+kind+'-control',*o['args']] and (b['label'],b['features'],kind)==(o['label'],o['features'],o['kind']);raw=gzip.decompress((s/c['log']).read_bytes()).decode();counts['observations']+=1
 if c['exit_code']:assert b['reproduction'] and 'publication cancellation must discard completed output' in raw;counts['expected_failures']+=1;continue
 full='\n'.join(x for x in raw.splitlines() if x.startswith(('OUTPUT ','TRACE ')));output='\n'.join(x for x in raw.splitlines() if x.startswith('OUTPUT '));assert full and output;key=(b['features'],kind,tuple(o['args']));plainkey=(b['features'].replace(',cancel-retry','').replace('cancel-retry',''),kind,tuple(o['args']))
 if key in refs:assert refs[key]==full;comparisons['full_output_trace']+=1
 else:refs[key]=full
 if plainkey in plain:assert plain[plainkey]==output;comparisons['full_output']+=1
 else:plain[plainkey]=output
 record=dict(log=c['log']);features=b['features'];label=b['label'];args=o['args']
 if kind=='resource':
  case,mode,warm,pattern,trace,policy,reuse=args;key=(features,int(case),policy,trace,reuse,int(warm));f=fields(raw);record['fields']=f
  if mode=='observe':heap[key][label].append(record)
  else:
   mapping,guard,caller,peak,remaining=f['HEADROOM'];assert peak==f['STACK'] and peak>0 and mapping==2*1024**2 and guard>0 and caller>0 and caller+peak+guard+remaining==mapping;record.update(mode=mode,pattern=int(pattern));stacks[key][label].append(record)
 else:
  case,policy,trace,n=args;assert n=='32';key=(features,kind,int(case),policy,trace);record.update(history(raw,kind));hist[key][label].append(record);counts['histories']+=1
assert counts['expected_failures']==6 and len(images)==30
# Recheck final-image section and symbol measurements from preserved tool output.
for b in builds:
 for kind,a in b['artifacts'].items():
  name=b['label']+'-'+(b['features'].replace(',','-') or 'default')+'-'+kind;sections={v[0]:int(v[1]) for line in raws[name+'-size'].splitlines() if len(v:=line.split())==3 and v[0].startswith('.')};assert sections==a['sections'];addresses={}
  for line in raws[name+'-nm'].splitlines():
   m=re.match(r'([0-9a-f]+) ([0-9a-f]+) [tT] ',line)
   if m:address,n=m.groups();n=int(n,16);assert address not in addresses or addresses[address]==n;addresses[address]=n
  assert sum(addresses.values())==a['named_text'];allocated=executable=0;lines=raws[name+'-objdump'].splitlines()
  for i,line in enumerate(lines[:-1]):
   f=line.split()
   if len(f)>=7 and f[0].isdigit():
    n=int(f[2],16);flags=lines[i+1]
    if 'ALLOC' in flags:allocated+=n
    if 'CODE' in flags:executable+=n
  assert allocated==a['allocated'] and executable==a['executable']
accounts=[]
def account(key,values,is_history=False):
 added='cancel-retry' in key[0];labels=['candidate'] if added else order;assert set(values)==set(labels);case=key[2] if is_history else key[1];a=dict(key=key,values=values,added_functionality=added,metrics={},failures=[],prior_account_reconciliation_pending=True)
 for metric in sorted(set.intersection(*(set(v) for v in values.values()))):
  if metric.endswith(('postdrop_min','postdrop_max')):continue
  v={label:values[label][metric] for label in labels}
  if metric in ['worker_headroom','payload_headroom']:
   minimum=1024**2 if metric=='worker_headroom' else (16 if case==3 else 4)*1024**2;a[metric]=dict(values=v,minimum=minimum,passed=min(v.values())>=minimum)
   if not a[metric]['passed']:a['failures'].append(metric+':total')
   continue
  cap,percent,total=limits(metric,case,is_history);entry=dict(values=v,total_limit=total,total_pass=total is None or max(v.values())<=total)
  if added:entry.update(incremental_pass=None,cumulative_pass=None,no_correct_old_completion_baseline=True)
  else:entry.update(charges(v,labels,cap,percent,{}));entry['account_kind']='observed-boundary charges pending historical reconciliation'
  a['metrics'][metric]=entry
  for test in ['total','incremental','cumulative']:
   if entry[test+'_pass'] is False:a['failures'].append(metric+':'+test)
 accounts.append(a);return a
for key,by_label in sorted(heap.items()):
 values={}
 for label,records in by_label.items():
  rows=[r['fields'] for r in records];sr=stacks[key][label];assert {r['mode'] for r in sr}=={'stack','stack-drop'} and {r['pattern'] for r in sr}=={165,90};v=dict(stack=max(r['fields']['STACK'] for r in sr if r['mode']=='stack'),cleanup_stack=max(r['fields']['STACK'] for r in sr if r['mode']=='stack-drop'),worker_headroom=min(r['fields']['HEADROOM'][4] for r in sr))
  for name,index in [('allocations',0),('deallocations',1),('reallocations',2),('requested_traffic',3)]:v[name]=max(sum(r[k][index] for k in ['ALLOCATION','CLEANUP','INPUT_CLEANUP']) for r in rows)
  v['usable_traffic']=max(sum(r[k][0] for k in ['USABLE','USABLE_CLEANUP','INPUT_USABLE_CLEANUP']) for r in rows)
  for prefix,op,cleanup,inp,peak,live in [('requested','ALLOCATION','CLEANUP','INPUT_CLEANUP',4,5),('usable','USABLE','USABLE_CLEANUP','INPUT_USABLE_CLEANUP',1,2)]:
   v[prefix+'_retained']=max(r[op][live] for r in rows);v[prefix+'_peak']=max(max(r[op][peak],r[op][live]+r[cleanup][peak],r[op][live]+r[cleanup][live]+r[inp][peak]) for r in rows);signed=[sum(r[k][live] for k in [op,cleanup,inp]) for r in rows];v[prefix+'_postdrop_min']=min(signed);v[prefix+'_postdrop_max']=max(signed)
  v['payload_headroom']=(32 if key[1]==3 else 8)*1024**2-2*1024**2-max(v['requested_peak'],v['usable_peak']);values[label]=v
 a=account(key,values);a['observation_counts']={label:dict(heap=len(rows),stack=len(stacks[key][label])) for label,rows in by_label.items()}
for key,by_label in sorted(hist.items()):
 values={label:{m:max(r['metrics'][m] for r in rows) for m in rows[0]['metrics']} for label,rows in by_label.items()};a=account(key,values,True);a['history_counts']={label:len(rows) for label,rows in by_label.items()}
 for label,rows in by_label.items():
  if any(r['negative'] for r in rows):a['failures'].append(label+':negative-footprint')
  if any(not r['no_retention_after_cycle_two'] for r in rows):a['failures'].append(label+':retention-after-cycle-two')
size=[]
for feature,kind in itertools.product(['','trace','cancel-retry','trace,cancel-retry'],['resource','lifetime','reused']):
 added='cancel-retry' in feature;labels=['candidate'] if added else order;by_label={b['label']:b['artifacts'][kind] for b in builds if b['features']==feature and b['label'] in labels};a=dict(features=feature,kind=kind,images=by_label,metrics={},prior_account_reconciliation_pending=True)
 for metric in ['file','text','named_text','allocated','executable']:
  v={label:by_label[label][metric] for label in labels};entry=dict(values=v)
  if added:entry.update(incremental_pass=None,cumulative_pass=None,no_correct_old_completion_baseline=True)
  else:entry.update(charges(v,labels,32768 if metric in ['file','allocated'] else 16384,1,{}))
  a['metrics'][metric]=entry
 a['headroom_pass']=all(16*1024**2-max(v['file'],v['allocated'])>=2*1024**2 for v in by_label.values());size.append(a)
prior=s.parent/'solver-cancellation-cumulative-review/matched-summary.json';prior_record=dict(path=str(prior),sha256=sha(prior.read_bytes()),unchanged=True,older_bundle_failures_and_charges_not_waived=True)
summary=dict(commands=len(commands),images=len(images),observations=len(observations),counts=dict(counts),comparisons=dict(comparisons),accounts=len(accounts),failed_observed_accounts=sum(bool(a['failures']) for a in accounts),failed_observed_metrics=dict(Counter(f for a in accounts for f in a['failures'])),size_accounts=len(size),failed_observed_size_metrics=sum(v['incremental_pass'] is False or v['cumulative_pass'] is False for a in size for v in a['metrics'].values()),all_size_headroom_pass=all(a['headroom_pass'] for a in size),prior=prior_record,prior_account_reconciliation_pending=True,admitted=False,timing_claim=False,producer_seconds=done['seconds'],seconds=time.monotonic()-start)
for name,value in [('accounts.json',accounts),('size-accounts.json',size),('summary.json',summary)]:save(name,value)
print(json.dumps(summary,indent=2))
