# Standalone publication complete consumer resource qualification

Scope owner and witness are recorded in cancellation-standalone. Evaluate the
unchanged complete consumer from solver-cancellation-cumulative on fixed program
baseline c9f1f9ac, primary e63cbf68, and standalone candidate 8a454c86. All assertions and operations remain intact. This reviewed correction changes
only the manifest feature dependency and two cfg selectors for the existing
case field; all other Rust/C bytes stay identical.
This distinct source path excludes the unadmitted five solver repairs and trace
experiments. Preserve all their seven-case, ten-boundary failures and positive
charges as separate outstanding accounts; no combined-bundle admission, baseline
reset, cap revision or waiver follows from this campaign.

Common successfully completed contract: existing ordinary cases0..3 at1/4/16/64
variables (64 separate stress), both policies, default/trace, passive/active,
reused/rebuilt input, cold/warm operation and cleanup, full materialized output
and receipts/trace, three heap observations, both stack fill patterns, three
32-cycle lifetime histories for both input reuse modes. Compare exact output
and trace across fixed/primary/candidate within every observation domain.

Added cancellation/retry: unchanged feature on primary for six expected
publication-assertion smoke failures, and candidate for complete cases0..3.
Every failed control must name the same assertion. Candidate retry output must
match ordinary output; trace is a separate two-operation domain. Costs of failed
primary attempts are not completion baselines. Cases4..6 of the older bundle
require its unadmitted repairs; leave all their source fixtures and obligations
intact and make no completed standalone claim for them. The supporting fixture
code is preserved even where those separate cases are not invoked here.

Keep existing per-metric caps, without changes: requested/usable peak and traffic
4096bytes AND2%; report/persistent retention512bytes AND2%; alloc/free/realloc16
AND1%; touched stack256bytes AND4%, incremental and cumulative positive charges.
Zero baseline requires zero growth.32cycle absolute traffic/count caps scale32;
relative, peak and retention caps do not. Retain prior accepted primary charges
and expose distinct branch accounts; do not net savings or erase rejected bundle
charges. Accounting requires review after collection, not an automatic pass.

Ordinary/added heap1MiB, traffic16MiB/operation, touched stack32KiB;64variable
stress8MiB/256MiB/64KiB. Persistent32KiB and no growth aftercycle2. Preserve2MiB
stackmapping and1MiB untouched reserve, actual measured boundaries and excluded
frames; worker8MiB/4MiBreserve, stress32MiB/16MiBreserve. Requested versus usable
payload are distinct; no RSS/allocator-metadata, firmware, arbitrary-input or
concurrent-worker guarantee. Native file/allocated32KiB AND1%; text/named/code
16KiB AND1%;16MiBcapacity/2MiBreserve. Added workloads need absolute envelope,
not a fabricated percentage. Final native images measured; distribution and
quiet runtime remain separate gates. No timing claim from instrumented runs.

Start only after standalone functional audit and WASM producers are terminal
and successful, with control worktree clean/restored. One5400second window,
4500directchildren at one counted Popen site,900build/check,60measurement/Git;
compiler descendants excluded. Sixbuildjobs, locked offline Rust1.95, isolated
RAM Cargo metadata, source/target/images RAM.1GiBbuild file/64MiBmeasurement,
512MiBstage,2.5GiBtmp/20GiBdevelopment reserves. No automatic retry or deadline
reset; restore control branch on success, preserve failure state for review.
Queue1621335/start38218939 held, watcher3416600 terminal. Archive only after
validation terminal. Separate offline review capped300seconds.

## Reviewed feature separation after preserved failed build

The first campaign stopped after101commands and12successful ordinary smoke
controls. Its cancel-retry feature also enabled added, which compiles cases4..6
and references three APIs not present on primary. Preserve that build failure
and all12images. Removing that feature dependency requires widening the existing
Fixture.case field declaration/construction selectors to added OR cancel-retry;
no assertion, operation or case4..6 code is removed. Cancellation still executes
and validates the complete original operation before cancellation, requires the
exact typed error and clean scope, then completes fresh-token retry. This is a
separate standalone4case consumer configuration, not equivalent cost evidence
for the older seven-case bundle. Its additional report fields remain in that
bundle's unchanged configuration and obligations.

Use a new stage and image directory; preserve old artifacts. Start from the
clean primary revision left by failure and restore the original control branch
on success. Charge the original101children against the same4500ceiling and use
the original absolute5400second deadline without reset. Rebuild all sources for
this explicitly changed configuration. Do not automatically retry another failure.
