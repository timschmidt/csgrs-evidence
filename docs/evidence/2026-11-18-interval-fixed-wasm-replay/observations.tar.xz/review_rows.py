import csv, subprocess, sys
from pathlib import Path
s=Path(__file__).parent
root=Path.cwd()
with (root/'interval-inventory.tsv').open(newline='') as f:
 reader=csv.DictReader(f,delimiter='\t');rows=list(reader);fields=reader.fieldnames
both='crates/hyperlattice-interval/conformance/'
lattice=both+'no_alloc_wasm.rs';foc=both+'alumina-foc/wasm/lib.rs'
abi='reviewed WASM conformance entry on csgrs ceeb7cc25'
cases=[
 ('affine_correlation_probe','FixedInterval<i32, 0>','Preserves the shared source of two affine images, then subtracts them to obtain the singleton 7.','affine_cost'),
 ('interval_affine_probe','FixedInterval<i32, 0>','Checks all four exact coordinate bounds of a translated two-dimensional affine box.','affine_cost'),
 ('affine_chain_probe','FixedInterval<i32, 0>','Checks a source-preserving affine chain at each retained depth from 0 through 32.','affine_chain_cost'),
 ('interval_norm_probe','FixedInterval<i32, 0>','Checks induced norms, logarithmic measures and composed row/column dominance margins.','norm_cost'),
 ('interval_width_probe','FixedInterval<i64, 63>','Checks unsigned widths across signed extrema, tie selection, and failed signed conversion.','width_cost'),
 ('midpoint_radius_probe','FixedInterval<i64, 63>','Checks rounded midpoint/radius bounds of vectors and matrices, preserved source and full-width failure.','midpoint_radius_cost'),
 ('contraction_probe','FixedInterval<i32, 0>','Checks the identity-minus matrix, contraction margins in both norms and the resulting vector image.','norm_cost'),
 ('range_probe','Q30Interval over signed 32-bit endpoints','Replays Park on singleton Q30 components, including intermediate range errors and full-scale inputs.','cost'),
 ('conformance_probe','Q30Interval over signed 32-bit endpoints','Compares both transform outcomes before returning the canonical digest; the JS caller checks cardinal rotations independently.','cost')]
out=[]
for name,representation,sem,bench in cases:
 isfoc=name in ('range_probe','conformance_probe');file=foc if isfoc else lattice
 lines=(root/file).read_text().splitlines()
 [line]=[i for i,l in enumerate(lines,1) if f'pub extern "C" fn {name}(' in l]
 r=dict(repository='csgrs',path=file,line=str(line),symbol=name,kind='fn',endpoint_representation=representation,
        semantics=sem,allocation='No global allocator in the linked conformance client.',
        platform='wasm32-unknown-unknown; sibling alumina-foc at 96ac01e' if isfoc else 'wasm32-unknown-unknown; fixed backend alone; Rust 1.88.0 and 1.95.0.',
        visibility='pub',serialization='Integer C ABI result; internal interval state stays in the guest.',
        consumers='alumina-foc/wasm/check.mjs' if isfoc else 'fixed-wasm/check.mjs via scripts/check_interval_wasm.py',
        owner='interval-foc-wasm-consumer' if isfoc else 'hyperlattice-interval',
        disposition='Retain as a conformance client of domain-owned transforms.' if isfoc else 'Retain as a fixed-size Cartesian conformance client.',
        baseline_tests='crates/hyperlattice-interval/conformance/alumina-foc/README.md, standalone WASM replay' if isfoc else 'python3 scripts/check_interval_wasm.py --toolchain 1.88.0 --output <fresh directory>',
        baseline_benchmarks='crates/hyperlattice-interval/conformance/alumina-foc/src/bin/cost.rs' if isfoc else f'crates/hyperlattice-interval/conformance/{bench}.rs',
        review_status=abi)
 if isfoc:r['platform']='wasm32-unknown-unknown; Rust 1.88.0; sibling alumina-foc at '+subprocess.check_output(['git','-C',str(root.parent/'alumina-firmware'),'rev-parse','--short=9','HEAD'],text=True).strip()
 assert set(r)==set(fields)
 out.append(r)
with (s/'reviewed.tsv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fields,delimiter='\t',lineterminator='\n');writer.writeheader();writer.writerows(out)
