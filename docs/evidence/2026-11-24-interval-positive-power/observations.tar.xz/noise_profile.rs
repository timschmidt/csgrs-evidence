//! Temporary profiling probe: one long-horizon correlated rotation, as in the external corpus.
use hyperdynamics::field::{
    EnclosureBudget, EnclosurePolicy, ExpressionField, FieldDefinition,
    evolution::EvolutionOptions,
    taylor_flow::noise::{
        FlowNoiseState,
        evolution::{FlowNoiseEvolutionOptions, FlowNoiseEvolutionStatus},
    },
};
use hyperinterval::DyadicInterval;
use hyperlattice_interval::BoxN;
use hypersolve::{
    Expr, SymbolId,
    expression_program::{ExpressionBudget, ExpressionProgram},
};
use std::sync::Arc;
fn d(lo: i64, hi: i64, e: i32) -> DyadicInterval {
    DyadicInterval::new(lo.into(), hi.into(), e).unwrap()
}
fn main() {
    let (t, x, y) = (SymbolId(0), SymbolId(1), SymbolId(2));
    let source = ExpressionProgram::compile(
        &[Expr::anonymous_symbol(y), -Expr::anonymous_symbol(x)],
        &[t, x, y],
        &mut ExpressionBudget::new(1_000_000, 100_000_000),
    )
    .unwrap();
    let mut budget = EnclosureBudget::new(EnclosurePolicy::default());
    let field = ExpressionField::<2>::from_definition(
        FieldDefinition { source: source.definition().clone(), time: t, state: vec![x, y] },
        &mut budget,
    )
    .unwrap();
    let program = field.flow_taylor(3, &mut budget).unwrap();
    let steps: i32 = std::env::args().nth(1).map_or(64, |a| a.parse().unwrap());
    let mut budget = EnclosureBudget::new(EnclosurePolicy::default());
    let state = Arc::new(
        FlowNoiseState::new(d(0, 0, 0), BoxN::new([d(1023, 1025, -10), d(-1, 1, -10)]).unwrap(), &mut budget).unwrap(),
    );
    let report = program.integrate_noise(
        state,
        d(steps as i64, steps as i64, -3),
        FlowNoiseEvolutionOptions {
            native: EvolutionOptions { maximum_step: Some(d(1, 1, -3)), ..Default::default() },
            ..Default::default()
        },
        &mut budget,
    );
    assert!(matches!(report.status(), FlowNoiseEvolutionStatus::Completed), "{:?}", report.status());
    println!("segments={} attempts={}", report.segments().len(), report.attempts().len());
}
