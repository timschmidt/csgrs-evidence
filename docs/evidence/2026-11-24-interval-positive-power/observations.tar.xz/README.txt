Exact positive integer interval powers (csgrs 4a4cf6c70 measured; retained as 6e47bbf4c after a rebase with unchanged Hypersolve sources).
noise_profile.rs / noise-profile.yml: temporary probe and hosted callgrind workflow (branch since deleted).
callgrind-totals.txt: instruction totals for each variant.
full.json: development artifact sizes (Rust 1.100.0, all features, default profiles, one path), base abea09f1d.
interface-run-45446472757-sizes.txt / power-size.yml: Interface trunk release WASM sizes; byte-identical at base and candidate.
ledger.py: text splice of the development charges into docs/research/interval-size-accounts.json.
