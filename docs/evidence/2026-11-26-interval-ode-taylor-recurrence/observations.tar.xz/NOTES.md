# Opt-in Taylor-mode ODE coefficients (2026-11-26)

Harness: scripts/validated-dynamics at base-commit.txt with a temporary patch
(not committed) selecting `FlowTaylorCoefficients::Recurrence` through
HD_COEFF=recurrence and skipping the long tier unless HD_LONG is set.
- corpus16-*: the sixteen short cases, 100 iterations x 3 samples, CPU 0,
  ASLR off, release; timing medians in the progress record.
- corpus20-*: all twenty cases including the long tier, 2 iterations x 3
  samples (long-tier timings are low-sample).
- oracle-*: validate.py on corpus20 for each method (analytic containment and
  width limits, all twenty true).
- width-differences.md: cases whose exact endpoint/tube differ; the largest
  relative width change is 2.27e-11 (recurrence wider in 28 lane widths).
