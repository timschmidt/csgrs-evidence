"""Development-only sign/period probe; not certified acceptance evidence."""
import json
import mpmath as mp

mp.mp.dps = 65


def epsilon_real(x, m):
    k = mp.ellipk(m)
    n = mp.floor((x + k) / (2 * k))
    r = x - 2 * n * k
    amplitude = mp.asin(mp.ellipfun("sn", r, m))
    return 2 * n * mp.ellipe(m) + mp.ellipe(amplitude, m)


def epsilon_rectangular(x, y, m):
    if not m:
        return mp.mpc(x, y)
    s, c, d = [mp.ellipfun(t, x, m).real for t in ("sn", "cn", "dn")]
    h = 1 - m
    if m > 0:
        S, C, D = [mp.ellipfun(t, y, h).real for t in ("sn", "cn", "dn")]
        q = C * C + m * s * s * S * S
        vertical = y - epsilon_real(y, h)
    else:
        r = mp.sqrt(h)
        ss, cc, dd = [mp.ellipfun(t, r * y, 1 / h).real for t in ("sn", "cn", "dn")]
        S, C, D = ss / r, dd, cc
        q = cc * cc + (-m / h) * c * c * ss * ss
        vertical = r * (r * y - epsilon_real(r * y, 1 / h))
    return mp.mpc(epsilon_real(x, m) + m * s * c * d * S * S / q,
                  vertical + d * d * S * C * D / q)


def integrated(x, y, m):
    # A rectangular path with real x != pole columns; integrate dn^2 using
    # mpmath's theta-function Jacobi values and independent quadrature.
    return (mp.quad(lambda u: mp.ellipfun("dn", u, m) ** 2, [0, x])
            + 1j * mp.quad(lambda v: mp.ellipfun("dn", x + 1j * v, m) ** 2, [0, y]))


rows = []
for m in map(mp.mpf, ("-2", "-0.5", "0.125", "0.5", "0.875")):
    k = mp.ellipk(m)
    ky = mp.ellipk(1 - m) if m > 0 else mp.ellipk(1 / (1 - m)) / mp.sqrt(1 - m)
    points = [(mp.mpf("0.25"), mp.mpf("0.125")),
              (k / 3, ky), (k, ky / 3),
              (-k / 3, -ky), (k / 3, 2 * ky)]
    for x, y in points:
        value = epsilon_rectangular(x, y, m)
        oracle = integrated(x, y, m)
        error = abs(value - oracle)
        assert error < mp.mpf("1e-50"), (m, x, y, error)
        period = abs(epsilon_rectangular(x + 2 * k, y, m) - value - 2 * mp.ellipe(m))
        assert period < mp.mpf("1e-50"), (m, x, y, period)
        rows.append(dict(m=str(m), x=mp.nstr(x, 30), y=mp.nstr(y, 30),
                         quadrature_error=str(error), real_period_error=str(period)))
print(json.dumps(dict(mpmath=mp.__version__, precision_decimal_digits=mp.mp.dps,
                     scope="non-certified development diagnostic", rows=rows), indent=2))
