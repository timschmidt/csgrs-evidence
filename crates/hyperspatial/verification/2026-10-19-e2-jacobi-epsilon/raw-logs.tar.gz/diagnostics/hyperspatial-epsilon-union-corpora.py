from pathlib import Path
import hashlib, json
out = Path("target/hyperspatial-shared-unions")
report = {}
for name,new in [("jacobi_epsilon","hyperspatial-directed-epsilon-shared"),("complex_jacobi","hyperspatial-directed-complex-after-epsilon-shared")]:
    old = Path("/mnt/development/hyperspatial/epsilon-initial-diagnostic/hyperspatial-asan-epsilon") / (name+"-corpus")
    current = Path("target") / new / "corpus"
    target = out / name
    target.mkdir(parents=True,exist_ok=True)
    sources = {}
    for source in [old,current]:
        files = sorted(p for p in source.iterdir() if p.is_file())
        sources[str(source)] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
        for p in files:
            data=p.read_bytes()
            assert len(data)==6
            (target/data.hex()).write_bytes(data)
    report[name] = {"source_files":sources,"union_count":len(list(target.iterdir()))}
(out/"report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({name:row["union_count"] for name,row in report.items()}))
