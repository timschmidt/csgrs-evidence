use hyperlattice::{Complex, Real};
#[path = "../../hyperreal/tests/support/representations.rs"]
mod representations;
fn main() {
    for case in representations::optimized_certificate_representatives() {
        assert_eq!(case.value.detailed_facts().symbolic.kind, case.public_kind, "{}",case.certificate);
        let x = (&case.value / (Real::from(8) * (&case.value + Real::one()))).unwrap();
        let y = (&x / Real::from(2)).unwrap();
        for text in ["0.5","-3","0"] {
            let m: Real=text.parse().unwrap();
            let k=Real::elliptic_k(&m).unwrap();
            for (mode,z) in [Complex::new(x.clone(),y.clone()),Complex::from(x.clone()),Complex::new(Real::zero(),y.clone()),Complex::new(&k+x.clone(),-y.clone())].into_iter().enumerate() {
                let result=z.jacobi_epsilon(&m).unwrap();
                let cold=serde_json::to_string(&[&result.re,&result.im]).unwrap();
                for v in [&result.re,&result.im] { assert!(v.certified_rational_interval(-128).is_some()); }
                assert_eq!(cold,serde_json::to_string(&[&result.re,&result.im]).unwrap());
                println!("{}\t{text}\t{mode}\t{cold}",case.certificate);
            }
        }
    }
}
