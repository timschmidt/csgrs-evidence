import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import re
import subprocess
import tarfile

root = Path('/mnt/development/hyperspatial/csgrs')
out = root / 'crates/hyperspatial/verification/2026-10-19-e2-jacobi-epsilon'
jobs_dir = Path('/tmp/hyperspatial-epsilon-shared-verification')
jobs = json.loads(Path('/tmp/hyperspatial-epsilon-shared-final-jobs.json').read_text())
freeze = json.loads(Path('/tmp/hyperspatial-epsilon-shared-source-freeze.json').read_text())
results = {}
for label, job in jobs.items():
    rows = json.loads((jobs_dir / label / 'results.json').read_text())
    assert len(rows) == len(job['commands']), (label, 'unfinished commands')
    assert all(r['status'] == 'complete' and r['returncode'] == 0 for r in rows), label
    results[label] = rows
for path, expected in freeze['sha256'].items():
    assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected, ('freeze',path)

directed = {}
for name, directory in [('epsilon','hyperspatial-directed-epsilon-shared'),
                        ('complex_jacobi','hyperspatial-directed-complex-after-epsilon-shared')]:
    report=json.loads((root/'target'/directory/'report.json').read_text())
    assert not report['failures'] and report['executions'] == 176
    directed[name]=report
asan=json.loads((root/'target/hyperspatial-asan-epsilon-shared/report.json').read_text())
assert {c['target'] for c in asan['campaigns']} == {'jacobi_epsilon','complex_jacobi'}
for campaign in asan['campaigns']:
    assert campaign['returncode'] == 0
    mutation=campaign['mutation_evidence']
    assert mutation['mutated'] and mutation['completed_runs'] > mutation['initialized_runs']
coverage=json.loads((root/'target/hyperspatial-coverage/coverage.json').read_text())
assert coverage['totals']['lines']['percent'] >= 95
assert coverage['native_inverse']['physical_executable_lines']['percent'] >= 95
for key in ['native_elliptic','native_legendre','native_inverse_legendre','native_jacobi',
            'native_complex_jacobi','native_square_quotient','native_relations']:
    assert coverage[key]['totals']['lines']['percent'] >= 95,key
for label,report in [*directed.items(),('asan',asan)]:
    for path,expected in report['source_sha256'].items():
        assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected,(label,path)
for key,value in coverage.items():
    if isinstance(value,dict) and 'source_sha256' in value:
        for path,expected in value['source_sha256'].items():
            assert hashlib.sha256((root/path).read_bytes()).hexdigest() == expected,('coverage',path)
for path,expected in coverage['source_sha256'].items():
    assert hashlib.sha256((root/'crates/hyperspatial'/path).read_bytes()).hexdigest() == expected,('spatial coverage',path)

out.mkdir(parents=True,exist_ok=True)
def write_json(name,value):
    (out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
write_json('commands.json',jobs)
write_json('process-exits.json',results)
write_json('source-freeze.json',freeze)
write_json('directed-report.json',directed)
write_json('asan.json',asan)
write_json('coverage.json',coverage)
resources=json.loads(Path('/tmp/hyperspatial-epsilon-shared-benchmark-resources.json').read_text())
assert resources['returncode'] == 0
write_json('benchmark-resources.json',resources)
comparison=json.loads(Path('/tmp/hyperspatial-epsilon-serialization-comparison.json').read_text())
before=Path('/tmp/hyperspatial-epsilon-serialization-before.tsv').read_bytes()
after=Path('/tmp/hyperspatial-epsilon-serialization-after.tsv').read_bytes()
assert before==after and len(before)==comparison['before_bytes']
assert hashlib.sha256(before).hexdigest()==comparison['before_sha256']
write_json('sharing-serialization.json',comparison)
write_json('sharing-fixed-input-diagnostics.json',json.loads(Path('/tmp/hyperspatial-epsilon-sharing-fixed.json').read_text()))
for name,path in [('bench.json',jobs_dir/'native/7.log'),('bench-msrv.json',jobs_dir/'msrv_native/7.log'),
                  ('bench-standalone.json',Path('/tmp/hyperspatial-epsilon-shared-benchmark-standalone.log'))]:
    rows=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    assert len(rows)==45 and all(row['accepted']==row['repeats'] for row in rows),(name,len(rows))
    write_json(name,rows)
counts={}
for label in jobs:
    logs={}
    for path in sorted((jobs_dir/label).glob('*.log')):
        rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',path.read_text())
        logs[path.name]=dict(suites=len(rows),passed=sum(int(r[1]) for r in rows),
                             failed=sum(int(r[2]) for r in rows),ignored=sum(int(r[3]) for r in rows))
    counts[label]=logs
write_json('test-counts.json',counts)

def command(*args):
    return subprocess.check_output(args,cwd=root,text=True).strip()
changed=set(command('git','diff','--name-only').splitlines())
changed.update(command('git','ls-files','--others','--exclude-standard').splitlines())
changed={p for p in changed if not p.startswith('crates/hyperspatial/verification/')}
source_paths=changed|set(freeze['sha256'])
metadata=dict(baseline=command('git','rev-parse','HEAD'),branch=command('git','branch','--show-current'),
              compiler=command('rustc','-vV'),msrv=command('rustc','+1.95.0','-vV'),
              nightly=command('rustc','+nightly','-vV'),platform=platform.platform(),cpu=freeze['cpu'],
              environment={'PATH_additions':['/tmp/hyperspatial-build-tools/usr/bin','/tmp/hyperspatial-fuzz-tools/bin'],
                           'GMP_MPFR_SYS_CACHE':'/tmp/hyperspatial-gmp-cache',
                           'load':'Concurrent validation; no comparative whole-domain speed ratio claimed'},
              source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(source_paths)})
write_json('source-metadata.json',metadata)

files={}
for path in sorted(Path('/tmp').glob('hyperspatial-epsilon*')):
    paths=path.rglob('*') if path.is_dir() else [path]
    for item in paths:
        if item.is_file() and item.suffix in ('.log','.json','.txt','.md','.py','.rs','.tsv','.stdout','.stderr'):
            files['diagnostics/'+str(item.relative_to('/tmp'))]=item.read_bytes()
initial=Path('/mnt/development/hyperspatial/epsilon-initial-diagnostic')
binaries={}
for path in sorted(initial.rglob('*')):
    if not path.is_file(): continue
    if path.name.endswith('-initial-asan'):
        binaries[path.name]=dict(bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    else: files['superseded-initial/'+str(path.relative_to(initial))]=path.read_bytes()
write_json('superseded-binaries.json',binaries)
for directory in ['hyperspatial-directed-epsilon-shared','hyperspatial-directed-complex-after-epsilon-shared',
                  'hyperspatial-shared-unions','hyperspatial-asan-epsilon-shared']:
    for path in sorted((root/'target'/directory).rglob('*')):
        if path.is_file(): files['campaigns/'+str(path.relative_to(root/'target'))]=path.read_bytes()
for target in ['jacobi_epsilon','complex_jacobi']:
    for path in sorted((root/'crates/hyperspatial/fuzz/artifacts'/target).glob('*')):
        if path.is_file(): files['sanitizer-artifacts/'+target+'/'+path.name]=path.read_bytes()
for path in sorted(source_paths): files['source-snapshot/'+path]=(root/path).read_bytes()
files['source-snapshot/pending.patch']=subprocess.check_output(['git','diff','--binary'],cwd=root)
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
write_json('raw-log-manifest.json',manifest)
with (out/'raw-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                archive.addfile(info,io.BytesIO(data))
print(json.dumps({'directory':str(out),'files':len(files),'raw_bytes':sum(len(d) for d in files.values()),
                  'archive_bytes':(out/'raw-logs.tar.gz').stat().st_size},indent=2))
