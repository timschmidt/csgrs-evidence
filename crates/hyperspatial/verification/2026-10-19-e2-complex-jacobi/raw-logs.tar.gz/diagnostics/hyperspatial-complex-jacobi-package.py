import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import re
import subprocess
import tarfile

root = Path('/mnt/development/hyperspatial/csgrs')
out = root / 'crates/hyperspatial/verification/2026-10-19-e2-complex-jacobi'
jobs_dir = Path('/tmp/hyperspatial-complex-jacobi-verification')
jobs = json.loads(Path('/tmp/hyperspatial-complex-jacobi-final-jobs.json').read_text())
results = {}
for label, job in jobs.items():
    rows = json.loads((jobs_dir / label / 'results.json').read_text())
    assert len(rows) == len(job['commands']), (label, 'unfinished commands')
    assert all(r['status'] == 'complete' and r['returncode'] == 0 for r in rows), label
    results[label] = rows

directed = json.loads((root / 'target/hyperspatial-directed-complex-jacobi-complete/report.json').read_text())
asan = json.loads((root / 'target/hyperspatial-asan-complex-jacobi-complete/report.json').read_text())
coverage = json.loads((root / 'target/hyperspatial-coverage/coverage.json').read_text())
assert not directed['failures']
assert all(c['returncode'] == 0 for c in asan['campaigns'])
asan_log = (root / 'target/hyperspatial-asan-complex-jacobi-complete/complex_jacobi.log').read_text()
assert 'INITED' in asan_log and re.search(r'\b(?:NEW|REDUCE)\b', asan_log), 'No mutation evidence'
assert coverage['totals']['lines']['percent'] >= 95
assert coverage['native_inverse']['physical_executable_lines']['percent'] >= 95
for key in ['native_elliptic', 'native_legendre', 'native_inverse_legendre',
            'native_jacobi', 'native_complex_jacobi', 'native_relations']:
    assert coverage[key]['totals']['lines']['percent'] >= 95, key
for label, report in [('directed', directed), ('asan', asan)]:
    for path, expected in report['source_sha256'].items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, (label, path)
for key, value in coverage.items():
    if isinstance(value, dict) and 'source_sha256' in value:
        for path, expected in value['source_sha256'].items():
            assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, ('coverage', path)

out.mkdir(parents=True, exist_ok=True)
def write_json(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

write_json('commands.json', jobs)
write_json('process-exits.json', results)
recovery_path = Path('/tmp/hyperspatial-complex-jacobi-space-recovery.json')
recovery = json.loads(recovery_path.read_text())
initial_msrv = Path('/tmp/hyperspatial-complex-jacobi-msrv-space-failure/0.log').read_text()
prefix = initial_msrv.split('Doc-tests hyperspatial')[0]
initial_rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', prefix)
assert len(initial_rows) == 21 and all(r[0] == 'ok' and r[2] == '0' for r in initial_rows)
assert sum(int(r[1]) for r in initial_rows) == 87
assert results['msrv'][0]['command'] == ['cargo', 'test', '--locked', '-p', 'hyperspatial', '--no-default-features', '--doc']
for path, expected in recovery['source_sha256'].items():
    assert hashlib.sha256((root / path).read_bytes()).hexdigest() == expected, ('recovery', path)
recovery['retained_no_default_test_results'] = dict(suites=21, passed=87, failed=0)
recovery['resumed_commands_completed'] = len(results['msrv'])
write_json('msrv-recovery.json', recovery)
write_json('directed-report.json', directed)
write_json('asan.json', asan)
write_json('coverage.json', coverage)
resources = json.loads(Path('/tmp/hyperspatial-complex-jacobi-benchmark-resources-complete.json').read_text())
assert resources['returncode'] == 0
write_json('benchmark-resources.json', resources)
for name, path in [('bench.json', jobs_dir / 'native/5.log'),
                   ('bench-msrv.json', jobs_dir / 'msrv_native/4.log')]:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 45 and all(row['accepted'] == row['repeats'] for row in rows)
    write_json(name, rows)

counts = {}
for label in jobs:
    logs = {}
    for path in sorted((jobs_dir / label).glob('*.log')):
        rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())
        logs[path.name] = dict(suites=len(rows), passed=sum(int(r[1]) for r in rows),
                               failed=sum(int(r[2]) for r in rows), ignored=sum(int(r[3]) for r in rows))
    counts[label] = logs
write_json('test-counts.json', counts)

changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
changed = {p for p in changed if not p.startswith('crates/hyperspatial/verification/')}
source_paths = changed | set(directed['source_sha256']) | set(asan['source_sha256']) | {'Cargo.toml', 'Cargo.lock'}
def command(*args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
metadata = dict(baseline=command('git', 'rev-parse', 'HEAD'), branch=command('git', 'branch', '--show-current'),
                compiler=command('rustc', '-vV'), msrv=command('rustc', '+1.95.0', '-vV'),
                nightly=command('rustc', '+nightly', '-vV'), platform=platform.platform(),
                cpu=next(l.split(':', 1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines()
                         if l.startswith('model name')),
                environment={'PATH_additions': ['/tmp/hyperspatial-build-tools/usr/bin', '/tmp/hyperspatial-fuzz-tools/bin'],
                             'GMP_MPFR_SYS_CACHE': '/tmp/hyperspatial-gmp-cache',
                             'load': 'Concurrent validation; no comparative speed ratio claimed'},
                source_sha256={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sorted(source_paths)},
                verified_campaign_source_hashes={'directed': len(directed['source_sha256']), 'asan': len(asan['source_sha256'])})
write_json('source-metadata.json', metadata)

files = {}
for pattern in ['hyperspatial-complex-jacobi*', 'hyperspatial-ln-*', 'hyperspatial-native-relation*', 'hyperspatial-allocation-counter*']:
    for path in sorted(Path('/tmp').glob(pattern)):
        paths = path.rglob('*') if path.is_dir() else [path]
        for item in paths:
            if item.is_file() and item.suffix in ('.log', '.json', '.txt', '.md', '.py', '.rs', '.stdout', '.stderr'):
                files['diagnostics/' + str(item.relative_to('/tmp'))] = item.read_bytes()
for directory in ['hyperspatial-directed-complex-jacobi-final',
                  'hyperspatial-directed-complex-jacobi-carlson-final',
                  'hyperspatial-directed-complex-jacobi-complete',
                  'hyperspatial-asan-complex-jacobi', 'hyperspatial-asan-complex-jacobi-complete']:
    for path in sorted((root / 'target' / directory).rglob('*')):
        if path.is_file():
            files['campaigns/' + str(path.relative_to(root / 'target'))] = path.read_bytes()
for path in sorted((root / 'crates/hyperspatial/fuzz/artifacts/complex_jacobi').glob('*')):
    if path.is_file():
        files['sanitizer-artifacts/' + path.name] = path.read_bytes()
for path in sorted(source_paths):
    files['source-snapshot/' + path] = (root / path).read_bytes()
files['source-snapshot/pending.patch'] = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(files.items())}
write_json('raw-log-manifest.json', manifest)
with (out / 'raw-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
print(json.dumps({'directory': str(out), 'files': len(files), 'raw_bytes': sum(len(d) for d in files.values())}, indent=2))
