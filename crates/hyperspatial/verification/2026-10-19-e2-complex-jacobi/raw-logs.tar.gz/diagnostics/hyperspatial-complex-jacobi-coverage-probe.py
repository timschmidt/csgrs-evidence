import json, os, pathlib, subprocess

root = pathlib.Path('/mnt/development/hyperspatial/csgrs')
target = root / 'target/hyperspatial-coverage'
output = pathlib.Path('/tmp/hyperspatial-complex-jacobi-coverage')
output.mkdir(exist_ok=True)
profiles = output / 'profiles'
profiles.mkdir(exist_ok=True)
env = os.environ.copy()
env.update(CARGO_TARGET_DIR=str(target), RUSTFLAGS='-C instrument-coverage',
           CARGO_PROFILE_TEST_OPT_LEVEL='1', LLVM_PROFILE_FILE=str(profiles / '%p-%m.profraw'))
commands = [
    ['cargo','test','--locked','-p','hyperreal','--no-default-features','--features','serde,dispatch-trace','--lib'],
    ['cargo','test','--locked','-p','hyperlattice','--all-features','--test','complex_jacobi'],
    ['cargo','test','--locked','-p','hyperspatial','--all-features','--test','complex_jacobi_representations'],
]
executables=set()
for command in commands:
    data=subprocess.check_output(command+['--no-run','--message-format=json'],cwd=root,env=env,text=True)
    for line in data.splitlines():
        row=json.loads(line)
        if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:
            executables.add(row['executable'])
    filters=['ring_', 'certified_planning_tests', 'logarithm_argument_recovery'] if command[4]=='hyperreal' else ['']
    for name in filters:
        subprocess.run(command+([name] if name else []),cwd=root,env=env,check=True)
rustc=subprocess.check_output(['rustc','-vV'],text=True)
host=next(line.split(': ',1)[1] for line in rustc.splitlines() if line.startswith('host:'))
sysroot=pathlib.Path(subprocess.check_output(['rustc','--print','sysroot'],text=True).strip())
llvm=sysroot/'lib/rustlib'/host/'bin'
merged=output/'coverage.profdata'
subprocess.run([str(llvm/'llvm-profdata'),'merge','-sparse',*map(str,profiles.glob('*.profraw')),'-o',str(merged)],check=True)
objects=sorted(executables)
args=[objects[0],f'--instr-profile={merged}']
for item in objects[1:]:args += ['--object',item]
(output/'arguments.json').write_text(json.dumps(args))
data=json.loads(subprocess.check_output([str(llvm/'llvm-cov'),'export','--summary-only',*args],text=True))
(output/'coverage.json').write_text(json.dumps(data,indent=2))
names=['ring_native_relations.rs','ring_native_reduction.rs','ring_native_projection.rs','ring_parameter_atoms.rs','ring_native_division.rs']
paths=[root/'crates/hyperreal/src/computable/node'/name for name in names]
paths += [root/'crates/hyperlattice/src/complex/jacobi.rs']
annotated=subprocess.check_output([str(llvm/'llvm-cov'),'show',*args,*map(str,paths),'--show-instantiations=false','--show-line-counts-or-regions'],text=True)
(output/'annotated.txt').write_text(annotated)
for dataset in data['data']:
    for row in dataset['files']:
        if pathlib.Path(row['filename']) in paths:
            print(row['filename'],row['summary']['lines'])
