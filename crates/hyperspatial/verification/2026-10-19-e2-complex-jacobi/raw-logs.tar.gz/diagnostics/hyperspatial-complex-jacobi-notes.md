# Next increment: complex Jacobi continuation (research notes, not implemented)

Owner candidate: Hyperlattice's existing `Complex { re: Real, im: Real }`.
No Hyperreal → Hyperlattice dependency. Parameter m remains real and <1;
complex parameters and m=1 are separate domains. Output tuple should retain
the six exact component expressions and share denominator/refinement work.
Inspect existing `Problem`, checked division and evidence semantics before
choosing the public signature. Domain validation must precede zero shortcuts.

Primary references read 2026-10-19:
- https://dlmf.nist.gov/22.8 (addition theorems)
- https://dlmf.nist.gov/22.6.iv (imaginary transformation)
- https://dlmf.nist.gov/22.17 (reciprocal and imaginary modulus transforms)

Derived rectangular formulas below are a working derivation, not admitted
code or an independent oracle. DLMF uses modulus k; the API uses m=k².

Let (s,c,d)=sncndn(x|m). For 0<m<1 let (S,C,D)=sncndn(y|1-m),
and Q=C²+m*s²*S². Then

sn(x+iy|m) = (s*D + i*c*d*S*C)/Q
cn(x+iy|m) = (c*C - i*s*d*S*D)/Q
dn(x+iy|m) = (d*C*D - i*m*s*c*S)/Q.

Q is a sum of nonnegative terms. Its zero set C=0,s=0 is the pole set;
unknown zero must not become a success. Do not divide separately by C,
because C=0 with s nonzero is an ordinary finite point of the final formula.

For m<0 set h=1-m>1, r=sqrt(h), and
(S,C,D)=sncndn(r*y|1/h). The complementary real functions at y|h are
(S/r,D,C), by the reciprocal modulus identities. Substitute them into
the rectangular formulas. Use the equivalent stable denominator
Q=C²+(-m/h)*c²*S², rather than D²+(m/h)*s²*S².

sn = (s*C + i*c*d*S*D/r)/Q
cn = (c*D - i*s*d*S*C/r)/Q
dn = (d*D*C - i*m*s*c*S/r)/Q.

The new Q is nonnegative and is zero precisely when C=0,c=0.
At x=0,C=0, Q remains positive: dn may be zero and the tuple is finite.
This avoids a naive global imaginary-modulus transformation, whose intermediate
sn/cn/dn can all have poles while the requested ratios have finite limits.

For m=0 use sin(x)cosh(y)+i*cos(x)sinh(y),
cos(x)cosh(y)-i*sin(x)sinh(y), and dn=1. A known real-axis input should
reuse the native real triplet, including its retained identities. Unknown
parameter sign or denominator zero requires an honest typed result.

Acceptance to design before code: independent high-precision theta or ODE
oracle, oblate/prolate regimes, exact real/imaginary axes, conjugation/parity,
quarter periods and poles, near-pole tiny offsets and large periods, relation
closure under Complex arithmetic, all scalar families/cache configurations,
serialization if the carrier supports it, strict downstream composition,
cancellation/recovery and bounded external containment. Do not claim formulas
alone satisfy retained identities: generic polynomial recognition may need
the earliest scalar owner to preserve correlations. Independent oracle code
must not merely repeat the rectangular construction.
