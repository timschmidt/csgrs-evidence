use hyperreal::Real;
use std::sync::{Arc, atomic::AtomicBool};
#[test]
fn standalone_deferred_atan_retains_active_input_abort() {
    let signal = Arc::new(AtomicBool::new(true));
    let mut input = Real::e().sin();
    input.abort(signal);
    assert!(input.certified_rational_interval(-512).is_none());
    let output = input.atan().unwrap();
    assert!(output.certified_rational_interval(-512).is_none());
}
