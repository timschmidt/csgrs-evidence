import hashlib,json,os,resource,subprocess,time
from pathlib import Path
root=Path('/mnt/development/hyperspatial/epsilon-candidate')
env=os.environ.copy()
env['CARGO_TARGET_DIR']='/mnt/development/hyperspatial/epsilon-target'
env['TMPDIR']='/mnt/development/hyperspatial/verification-tmp'
env['GMP_MPFR_SYS_CACHE']='/tmp/hyperspatial-gmp-cache'
env['PATH']='/tmp/hyperspatial-build-tools/usr/bin:'+env['PATH']
command=['cargo','bench','--locked','-p','hyperlattice','--bench','complex_atanh','--no-run','--message-format=json']
with Path('/tmp/hyperspatial-atanh-benchmark-build.stderr').open('w') as log:
 events=subprocess.check_output(command,cwd=root,env=env,text=True,stderr=log)
Path('/tmp/hyperspatial-atanh-benchmark-build.jsonl').write_text(events)
executables=[e['executable'] for line in events.splitlines() if (e:=json.loads(line)).get('reason')=='compiler-artifact' and e.get('executable') and e['target']['name']=='complex_atanh']
assert len(executables)==1,executables
executable=Path(executables[0])
start=time.monotonic()
with Path('/tmp/hyperspatial-atanh-benchmark-standalone.log').open('w') as log:
 child=subprocess.Popen([str(executable)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
record=dict(returncode=child.returncode,elapsed_seconds=time.monotonic()-start,peak_rss_kib=usage.ru_maxrss,
            executable=str(executable),executable_bytes=executable.stat().st_size,
            executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
            build_command=command,scope='Standalone native-plus-MPFR benchmark process; excludes compilation. Not an allocation count, production-only binary size, native work/heap bound or comparative speed claim.')
Path('/tmp/hyperspatial-atanh-benchmark-resources.json').write_text(json.dumps(record,indent=2)+'\n')
rows=[json.loads(line) for line in Path('/tmp/hyperspatial-atanh-benchmark-standalone.log').read_text().splitlines() if line.startswith('{')]
assert child.returncode==0 and len(rows)==45 and all(r['accepted']==r['repeats'] for r in rows)
print(json.dumps(record,indent=2));print('rows',len(rows),'accepted',sum(r['accepted'] for r in rows))
