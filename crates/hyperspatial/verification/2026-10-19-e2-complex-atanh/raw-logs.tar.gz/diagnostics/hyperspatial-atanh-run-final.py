import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/mnt/development/hyperspatial/epsilon-candidate')
jobs = json.loads(Path('/tmp/hyperspatial-atanh-final-jobs.json').read_text())
label = sys.argv[1]
job = jobs[label]
out = Path('/tmp/hyperspatial-atanh-final-verification') / label
out.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment['PATH'] = '/tmp/hyperspatial-fuzz-tools/bin:/tmp/hyperspatial-build-tools/usr/bin:' + environment['PATH']
environment['GMP_MPFR_SYS_CACHE'] = '/tmp/hyperspatial-gmp-cache'
environment.update(job.get('environment', {}))
(out / 'commands.json').write_text(json.dumps(job, indent=2) + '\n')
results = []
for index, command in enumerate(job['commands']):
    start = time.monotonic()
    with (out / f'{index}.log').open('w') as log:
        child = subprocess.Popen(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
        row = dict(command=command, environment=job.get('environment', {}), pid=child.pid,
                   runner_pid=os.getpid(), started_unix=time.time(), status='running')
        results.append(row)
        (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        row.update(returncode=child.wait(), elapsed_seconds=time.monotonic()-start, status='complete')
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(label, index, row['returncode'], flush=True)
    if row['returncode']:
        raise SystemExit(row['returncode'])
