import json, os, subprocess, time
from pathlib import Path
root=Path('/mnt/development/hyperspatial/csgrs')
logs=Path('/tmp/hyperspatial-atanh-root-verification')
logs.mkdir(exist_ok=True)
env=os.environ.copy()
env.update(CARGO_PROFILE_TEST_OPT_LEVEL='1',CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',
 CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',TMPDIR='/mnt/development/hyperspatial/verification-tmp',
 UV_TOOL_DIR='/tmp/hyperspatial-uv-tools',UV_TOOL_BIN_DIR='/tmp/hyperspatial-uv-bin')
commands=[
 ['cargo','fmt','--all','--','--check'],
 ['cargo','test','--locked','-p','hyperreal','--all-features','--test','atan2_right_half_plane'],
 ['cargo','test','--locked','-p','hyperlattice','--all-features','--test','complex_atanh'],
 ['cargo','test','--locked','-p','hyperspatial','--all-features','--test','complex_atanh_representations'],
 ['cargo','clippy','--locked','-p','hyperreal','-p','hyperlattice','-p','hyperlimit','-p','hyperspatial','--all-targets','--all-features','--','-D','warnings'],
 ['python3','crates/hyperspatial/scripts/source-consumer.py'],
 ['python3','crates/hyperspatial/scripts/test_fuzz_smoke.py'],
 ['python3','crates/hyperspatial/scripts/test_function_coverage.py'],
 ['python3','crates/hyperspatial/scripts/coverage-gates.py'],
 ['cargo','check','--locked','--manifest-path','crates/hyperspatial/fuzz/Cargo.toml','--bins'],
 ['cargo','clippy','--locked','--manifest-path','crates/hyperspatial/fuzz/Cargo.toml','--bins','--','-D','warnings'],
 ['uv','--cache-dir','/tmp/hyperspatial-uv-cache','tool','run','--offline','zizmor','--pedantic','--strict-collection','.'],
 ['git','diff','--check'],
]
record={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'environment':{k:env[k] for k in ['CARGO_PROFILE_TEST_OPT_LEVEL','CARGO_PROFILE_TEST_DEBUG_ASSERTIONS','CARGO_PROFILE_TEST_OVERFLOW_CHECKS','TMPDIR','UV_TOOL_DIR','UV_TOOL_BIN_DIR']},
 'checks':[]}
for index,command in enumerate(commands):
 start=time.monotonic()
 with (logs/f'{index}.log').open('w') as output:
  result=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 record['checks'].append(dict(command=command,returncode=result.returncode,elapsed_seconds=time.monotonic()-start,log=str(logs/f'{index}.log')))
 Path('/tmp/hyperspatial-atanh-root-validation.json').write_text(json.dumps(record,indent=2)+'\n')
 print(index,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
