import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import re
import subprocess
import tarfile

root = Path('/mnt/development/hyperspatial/csgrs')
candidate = Path('/mnt/development/hyperspatial/epsilon-candidate')
out = root / 'crates/hyperspatial/verification/2026-10-19-e2-complex-atanh'
jobs_dir = Path('/tmp/hyperspatial-atanh-final-verification')
jobs = json.loads(Path('/tmp/hyperspatial-atanh-final-jobs.json').read_text())
freeze = json.loads(Path('/tmp/hyperspatial-atanh-final-source-freeze.json').read_text())
results = {}
for label, job in jobs.items():
    rows = json.loads((jobs_dir / label / 'results.json').read_text())
    assert len(rows) == len(job['commands']), (label, 'unfinished commands')
    assert all(r['status'] == 'complete' and r['returncode'] == 0 for r in rows), label
    results[label] = rows
for path, expected in freeze['sha256'].items():
    for base in [root,candidate]:
        assert hashlib.sha256((base/path).read_bytes()).hexdigest() == expected, ('freeze',str(base),path)
integration=json.loads(Path('/tmp/hyperspatial-atanh-root-integration.json').read_text())
assert integration['all_frozen_paths_match'] and integration['frozen_path_count']==732
root_checks=json.loads(Path('/tmp/hyperspatial-atanh-root-validation.json').read_text())
assert len(root_checks['checks'])==13 and all(row['returncode']==0 for row in root_checks['checks'])

directed=json.loads(Path('/mnt/development/hyperspatial/atanh-final-directed/report.json').read_text())
assert not directed['failures'] and directed['executions'] == 176
asan=json.loads(Path('/mnt/development/hyperspatial/atanh-final-asan/report.json').read_text())
assert len(asan['campaigns'])==1 and asan['campaigns'][0]['target']=='complex_atanh'
for campaign in asan['campaigns']:
    assert campaign['returncode']==0
    mutation=campaign['mutation_evidence']
    assert mutation['mutated'] and mutation['completed_runs']>mutation['initialized_runs']
coverage_path=Path('/mnt/development/hyperspatial/atanh-final-coverage-target/coverage.json')
coverage=json.loads(coverage_path.read_text())
assert coverage['totals']['lines']['percent']>=95
for key in ['native_inverse','native_atan2','native_atan_deferred']:
    assert coverage[key]['physical_executable_lines']['percent']>=95,key
for key in ['native_elliptic','native_legendre','native_inverse_legendre','native_jacobi',
            'native_complex_jacobi','native_square_quotient','native_relations','native_complex_elementary']:
    assert coverage[key]['totals']['lines']['percent']>=95,key
for label,report in [('directed',directed),('asan',asan)]:
    for path,expected in report['source_sha256'].items():
        assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,(label,path)
for key,value in coverage.items():
    if isinstance(value,dict) and 'source_sha256' in value:
        for path,expected in value['source_sha256'].items():
            assert hashlib.sha256((root/path).read_bytes()).hexdigest()==expected,('coverage',path)
for path,expected in coverage['source_sha256'].items():
    assert hashlib.sha256((root/'crates/hyperspatial'/path).read_bytes()).hexdigest()==expected,('spatial coverage',path)

out.mkdir(parents=True,exist_ok=True)
def write_json(name,value):
    (out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
for name,value in [('commands.json',jobs),('process-exits.json',results),('source-freeze.json',freeze),
                   ('integration.json',integration),('root-validation.json',root_checks),
                   ('directed-report.json',directed),('asan.json',asan),('coverage.json',coverage)]:
    write_json(name,value)
resources=json.loads(Path('/tmp/hyperspatial-atanh-benchmark-resources.json').read_text())
assert resources['returncode']==0
write_json('benchmark-resources.json',resources)
comparison=json.loads(Path('/tmp/hyperspatial-atan2-serialization-comparison.json').read_text())
before=Path('/tmp/hyperspatial-atan2-serialization-before.tsv').read_bytes()
after=Path('/tmp/hyperspatial-atan2-serialization-after.tsv').read_bytes()
assert before==after and len(before)==comparison['before_bytes']
assert hashlib.sha256(before).hexdigest()==comparison['before_sha256']
write_json('atan2-serialization.json',comparison)
for name,path in [('bench.json',jobs_dir/'native/12.log'),('bench-msrv.json',jobs_dir/'msrv_native/12.log'),
                  ('bench-standalone.json',Path('/tmp/hyperspatial-atanh-benchmark-standalone.log'))]:
    rows=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    assert len(rows)==45 and all(row['accepted']==row['repeats'] for row in rows),(name,len(rows))
    write_json(name,rows)
counts={}
for label in jobs:
    logs={}
    for path in sorted((jobs_dir/label).glob('*.log')):
        rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',path.read_text())
        logs[path.name]=dict(suites=len(rows),passed=sum(int(r[1]) for r in rows),
                             failed=sum(int(r[2]) for r in rows),ignored=sum(int(r[3]) for r in rows))
    counts[label]=logs
write_json('test-counts.json',counts)

def command(*args):
    return subprocess.check_output(args,cwd=root,text=True).strip()
changed=set(command('git','diff','--name-only').splitlines())
changed.update(command('git','ls-files','--others','--exclude-standard').splitlines())
changed={p for p in changed if not p.startswith('crates/hyperspatial/verification/')}
source_paths=changed|set(freeze['sha256'])
cpu=json.loads(Path('/tmp/hyperspatial-epsilon-shared-source-freeze.json').read_text())['cpu']
metadata=dict(baseline=command('git','rev-parse','HEAD'),branch=command('git','branch','--show-current'),
              compiler=command('rustc','-vV'),msrv=command('rustc','+1.95.0','-vV'),
              nightly=command('rustc','+nightly','-vV'),platform=platform.platform(),cpu=cpu,
              environment={'PATH_additions':['/tmp/hyperspatial-build-tools/usr/bin','/tmp/hyperspatial-fuzz-tools/bin'],
                           'GMP_MPFR_SYS_CACHE':'/tmp/hyperspatial-gmp-cache',
                           'load':'Concurrent validation; no comparative whole-domain speed ratio claimed'},
              source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in sorted(source_paths)})
write_json('source-metadata.json',metadata)

files={}
for pattern in ['hyperspatial-atanh*','hyperspatial-atan2-serialization*']:
    for path in sorted(Path('/tmp').glob(pattern)):
        paths=path.rglob('*') if path.is_dir() else [path]
        for item in paths:
            if item.is_file() and item.suffix in ('.log','.json','.jsonl','.txt','.md','.py','.rs','.tsv','.stdout','.stderr'):
                files['diagnostics/'+str(item.relative_to('/tmp'))]=item.read_bytes()
for directory in ['atanh-final-directed','atanh-final-asan']:
    base=Path('/mnt/development/hyperspatial')/directory
    for path in sorted(base.rglob('*')):
        if path.is_file():files['campaigns/'+directory+'/'+str(path.relative_to(base))]=path.read_bytes()
for path in sorted((candidate/'crates/hyperspatial/fuzz/artifacts/complex_atanh').glob('*')):
    if path.is_file():files['sanitizer-artifacts/'+path.name]=path.read_bytes()
for directory in ['atanh-focused-coverage','atanh-final-coverage-target']:
    base=Path('/mnt/development/hyperspatial')/directory
    for path in base.glob('*'):
        if path.is_file() and path.suffix in ('.json','.txt','.log'):
            files['coverage/'+directory+'/'+path.name]=path.read_bytes()
for path in sorted(source_paths):files['source-snapshot/'+path]=(root/path).read_bytes()
files['source-snapshot/pending.patch']=subprocess.check_output(['git','diff','--binary'],cwd=root)
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
write_json('raw-log-manifest.json',manifest)
with (out/'raw-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,data in sorted(files.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
                archive.addfile(info,io.BytesIO(data))
print(json.dumps({'directory':str(out),'files':len(files),'raw_bytes':sum(len(d) for d in files.values()),
                  'archive_bytes':(out/'raw-logs.tar.gz').stat().st_size},indent=2))
