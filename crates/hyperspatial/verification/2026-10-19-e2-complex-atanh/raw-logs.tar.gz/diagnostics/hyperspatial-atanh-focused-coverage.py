import json, os, subprocess, tempfile, sys
from pathlib import Path
sys.path.insert(0,"/mnt/development/hyperspatial/epsilon-candidate/crates/hyperspatial/scripts")
from coverage_common import native_function_ranges, count_function_lines, check_native_function_coverage
crate = Path("/mnt/development/hyperspatial/epsilon-candidate/crates/hyperspatial")
root = crate.parents[1]
rustc = subprocess.check_output(["rustc", "-vV"], text=True)
host = next(line.split(": ", 1)[1] for line in rustc.splitlines() if line.startswith("host:"))
sysroot = Path(subprocess.check_output(["rustc", "--print", "sysroot"], text=True).strip())
llvm = sysroot / "lib/rustlib" / host / "bin"
if not (llvm / "llvm-cov").exists() or not (llvm / "llvm-profdata").exists():
    raise SystemExit("Install coverage tools with: rustup component add llvm-tools-preview")
target = Path(os.environ.get("CARGO_TARGET_DIR", Path("/mnt/development/hyperspatial/atanh-focused-coverage"))).resolve()
target.mkdir(parents=True, exist_ok=True)
environment = os.environ.copy()
environment["CARGO_TARGET_DIR"] = str(target)
environment["RUSTFLAGS"] = environment.get("RUSTFLAGS", "") + " -C instrument-coverage"
commands = [
    ["cargo", "test", "--locked", "-p", "hyperreal", "--all-features", "--lib", "--test", "atan2_right_half_plane"],
    ["cargo", "test", "--locked", "-p", "hyperlattice", "--all-features", "--test", "complex_atanh"],
    ["cargo", "test", "--locked", "-p", "hyperspatial", "--all-features", "--test", "complex_atanh_representations"],
]
with tempfile.TemporaryDirectory(prefix="profiles-", dir=target) as profiles:
    environment["LLVM_PROFILE_FILE"] = str(Path(profiles) / "%p-%m.profraw")
    executables = set()
    for command in commands:
        artifacts = subprocess.check_output(
            command + ["--no-run", "--message-format=json"], cwd=root, env=environment, text=True,
        )
        for line in artifacts.splitlines():
            event = json.loads(line)
            if event.get("reason") == "compiler-artifact" and event.get("executable") and event["profile"]["test"]:
                executables.add(event["executable"])
        subprocess.run(command, cwd=root, env=environment, check=True)
    if not executables:
        raise SystemExit("Cargo produced no instrumented test executables")
    raw = sorted(Path(profiles).glob("*.profraw"))
    if not raw:
        raise SystemExit("Tests produced no instrumented profiles")
    merged = target / "hyperspatial.profdata"
    subprocess.run([str(llvm / "llvm-profdata"), "merge", "-sparse", *map(str, raw), "-o", str(merged)], check=True)

objects = sorted(executables)
cov_args = [objects[0], f"--instr-profile={merged}"]
for executable in objects[1:]:
    cov_args.extend(["--object", executable])
export = json.loads(subprocess.check_output(
    [str(llvm / "llvm-cov"), "export", "--summary-only", *cov_args], text=True,
))
ranges = native_function_ranges(root)
sources=sorted({entry["path"] for entries in ranges.values() for entry in entries})
annotated=subprocess.check_output([str(llvm/"llvm-cov"),"show",*cov_args,*sources,"--show-instantiations=false","--show-line-counts-or-regions"],text=True)
report=count_function_lines(annotated,ranges,root)
for dataset in export["data"]:
    for file in dataset["files"]:
        if file["filename"].endswith("/hyperlattice/src/complex/elementary.rs"):
            report["native_complex_elementary"]=file["summary"]
report["scope"]="Focused candidate coverage only, not full stack or spatial coverage"
report["commands"]=commands
(target/"coverage.json").write_text(json.dumps(report,indent=2)+"\n")
(target/"annotated-functions.txt").write_text(annotated)
print(json.dumps({name:row.get("physical_executable_lines",row) for name,row in report.items() if name.startswith("native_")},indent=2))
check_native_function_coverage(report)
assert report["native_complex_elementary"]["lines"]["percent"]>=95
