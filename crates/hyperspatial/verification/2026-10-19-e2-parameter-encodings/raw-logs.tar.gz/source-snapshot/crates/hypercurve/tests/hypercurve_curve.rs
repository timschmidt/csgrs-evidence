mod support;
use hypercurve::{
    CircularArc2, Classification, CubicBezier2, Curve2, CurveCornerMode2, CurveCornerNoSolution2,
    CurveCornerSolutions2, CurveError, CurveFamily2, CurveGeometry2, CurveOperation2, CurvePath2,
    CurveRegion2, ExactCurveError, LineSeg2, Point2, PredicatePolicy, QuadraticBezier2,
    RationalBezier2, RationalQuadraticBezier2, Real, RegionPointLocation, UncertaintyReason,
};
use hypercurve::{ContourPointLocation, CurveCertainty};
use hyperreal::CertifiedRealEquality;
use proptest::prelude::*;

fn r(value: i32) -> Real {
    value.into()
}

fn q(numerator: i32, denominator: i32) -> Real {
    (Real::from(numerator) / Real::from(denominator)).unwrap()
}

fn p(x: i32, y: i32) -> Point2 {
    Point2::new(r(x), r(y))
}

#[test]
fn clamped_splines_preserve_discontinuous_knot_sides_and_span_images() {
    use hypercurve::{CurveParameterSide2, NurbsCurve2, PolynomialSplineCurve2};

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let controls = vec![p(0, 0), p(1, 1), p(2, 0), p(10, 0), p(11, 1), p(12, 0)];
        let knots = [-2, -1, 0, 1, 1, 1, 2, 3, 4]
            .into_iter()
            .map(r)
            .collect::<Vec<_>>();
        let polynomial = crate::support::under(&policy, || {
            PolynomialSplineCurve2::try_new(2, controls.clone(), knots.clone())
        })
        .unwrap()
        .value;
        let rational = crate::support::under(&policy, || {
            NurbsCurve2::try_new(
                2,
                controls,
                vec![r(1), r(2), r(3), r(5), r(7), r(11)],
                knots,
            )
        })
        .unwrap()
        .value;
        for curve in [Curve2::from(polynomial), Curve2::from(rational)] {
            for reversed in [false, true] {
                let source = if reversed {
                    crate::support::under(&policy, || curve.reversed())
                        .unwrap()
                        .value
                } else {
                    curve.clone()
                };
                let clamped = match source.geometry().unwrap() {
                    CurveGeometry2::PolynomialBSpline(curve) => {
                        crate::support::under(&policy, || curve.clamped_subcurve(r(0), r(2)))
                            .unwrap()
                            .map(Curve2::from)
                    }
                    CurveGeometry2::Nurbs(curve) => {
                        crate::support::under(&policy, || curve.clamped_subcurve(r(0), r(2)))
                            .unwrap()
                            .map(Curve2::from)
                    }
                    _ => unreachable!("authored spline fixture"),
                };
                assert_eq!(clamped.certainty, CurveCertainty::Certified);
                let clamped = clamped.value;
                assert_eq!(clamped.family(), source.family());
                assert_eq!(clamped.parameter_domain(), source.parameter_domain());
                assert!(matches!(
                    crate::support::under(&policy, || clamped.point_at(&r(1).into())),
                    Err(ExactCurveError::Blocked(blocker))
                        if blocker.reason() == UncertaintyReason::Boundary
                ));
                for (parameter, side) in [
                    (r(0), CurveParameterSide2::Automatic),
                    (q(1, 4), CurveParameterSide2::Automatic),
                    (q(3, 4), CurveParameterSide2::Automatic),
                    (r(1), CurveParameterSide2::Left),
                    (r(1), CurveParameterSide2::Right),
                    (q(5, 4), CurveParameterSide2::Automatic),
                    (q(7, 4), CurveParameterSide2::Automatic),
                    (r(2), CurveParameterSide2::Automatic),
                ] {
                    let parameter = parameter.into();
                    let expected =
                        crate::support::under(&policy, || source.point_at_side(&parameter, side))
                            .unwrap();
                    let actual =
                        crate::support::under(&policy, || clamped.point_at_side(&parameter, side))
                            .unwrap();
                    let equality = crate::support::under_outcome_classification(&policy, || {
                        actual.value.coincides_with(&expected.value)
                    });
                    assert_eq!(actual.certainty, CurveCertainty::Certified);
                    assert_eq!(equality.certainty, CurveCertainty::Certified);
                    assert_eq!(equality.value, Classification::Decided(true));
                }
                let closing_line = LineSeg2::try_new(
                    clamped.end().coordinates().unwrap().clone(),
                    clamped.start().coordinates().unwrap().clone(),
                )
                .unwrap();
                let path = CurvePath2::try_new(vec![clamped, Curve2::from(closing_line)]).unwrap();
                assert!(matches!(
                    crate::support::under(&policy, || CurveRegion2::try_from_boundary_paths(
                        &[path],
                        hypercurve::FillRule::EvenOdd
                    )),
                    Err(ExactCurveError::Invalid {
                        cause: CurveError::DisconnectedCurvePath,
                        ..
                    })
                ));
            }
        }
    }
}

fn assert_fillet_candidates(
    solutions: hypercurve::CurveCornerSolutions2<CurvePath2>,
    source: &CurvePath2,
    policy: &PredicatePolicy,
) -> Vec<CurvePath2> {
    let candidates = solutions.into_solutions();
    assert!(!candidates.is_empty());
    for candidate in &candidates {
        assert!(
            candidate
                .curves()
                .iter()
                .any(|curve| curve.family() == CurveFamily2::CircularArc)
        );
        for (first, second) in [
            (candidate.start(), source.start()),
            (candidate.end(), source.end()),
        ]
        .into_iter()
        .chain(
            candidate
                .curves()
                .windows(2)
                .map(|pair| (pair[0].end(), pair[1].start())),
        ) {
            let equality = crate::support::under_outcome_classification(policy, || {
                first.coincides_with(&second)
            });
            assert_eq!(equality.certainty, CurveCertainty::Certified);
            assert_eq!(equality.value, Classification::Decided(true));
        }
    }
    candidates
}

fn linear_family_curve(family: CurveFamily2, vertical: bool) -> Curve2 {
    let (start, middle, end) = if vertical {
        (p(0, 0), p(0, 1), p(0, 2))
    } else {
        (p(-2, 0), p(-1, 0), p(0, 0))
    };
    match family {
        CurveFamily2::AnalyticParallel => {
            panic!("this fixture enumerates authored native families")
        }
        CurveFamily2::Line => Curve2::from(LineSeg2::try_new(start, end).unwrap()),
        CurveFamily2::QuadraticBezier => Curve2::from(QuadraticBezier2::new(start, middle, end)),
        CurveFamily2::CubicBezier => {
            Curve2::from(CubicBezier2::new(start, middle.clone(), middle, end))
        }
        CurveFamily2::RationalQuadraticBezier => Curve2::from(
            RationalQuadraticBezier2::try_new(start, middle, end, r(1), r(1), r(1)).unwrap(),
        ),
        CurveFamily2::RationalBezier => Curve2::from(
            RationalBezier2::try_new(vec![start, middle, end], vec![r(1), r(1), r(1)]).unwrap(),
        ),
        CurveFamily2::PolynomialBSpline => {
            Curve2::try_polynomial_bspline(1, vec![start, end], vec![r(0), r(0), r(1), r(1)])
                .unwrap()
        }
        CurveFamily2::Nurbs => Curve2::try_nurbs(
            1,
            vec![start, end],
            vec![r(1), r(1)],
            vec![r(0), r(0), r(1), r(1)],
        )
        .unwrap(),
        CurveFamily2::CircularArc => panic!("linear test carrier excludes circular arcs"),
    }
}

fn closed_linear_spline(family: CurveFamily2, policy: &PredicatePolicy) -> Curve2 {
    let controls = vec![p(0, 0), p(2, 0), p(0, 2), p(0, 0)];
    let knots = vec![r(0), r(0), r(1), r(2), r(3), r(3)];
    match family {
        CurveFamily2::PolynomialBSpline => crate::support::under(policy, || {
            Curve2::try_polynomial_bspline(1, controls, knots)
        }),
        CurveFamily2::Nurbs => crate::support::under(policy, || {
            Curve2::try_nurbs(1, controls, vec![r(1), r(2), r(3), r(1)], knots)
        }),
        _ => unreachable!("the closed linear spline fixture accepts only spline families"),
    }
    .unwrap()
    .into_value()
}

fn every_family_open_chain() -> Vec<Curve2> {
    vec![
        Curve2::from(LineSeg2::try_new(p(0, 0), p(1, 0)).unwrap()),
        Curve2::from(CircularArc2::from_bulge(p(1, 0), p(3, 0), r(1)).unwrap()),
        Curve2::from(QuadraticBezier2::new(p(3, 0), p(4, 1), p(5, 0))),
        Curve2::from(CubicBezier2::new(p(5, 0), p(6, 1), p(7, 1), p(8, 0))),
        Curve2::from(
            RationalQuadraticBezier2::try_new(p(8, 0), p(9, 1), p(10, 0), r(1), r(2), r(1))
                .unwrap(),
        ),
        Curve2::from(
            RationalBezier2::try_new(vec![p(10, 0), p(11, 1), p(12, 0)], vec![r(1), r(2), r(1)])
                .unwrap(),
        ),
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_polynomial_bspline(
                2,
                vec![p(12, 0), p(13, 2), p(14, 0)],
                vec![r(0), r(0), r(0), r(1), r(1), r(1)],
            )
        })
        .unwrap()
        .into_value(),
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_nurbs(
                2,
                vec![p(14, 0), p(15, 2), p(16, 0)],
                vec![r(1), r(2), r(1)],
                vec![r(0), r(0), r(0), r(1), r(1), r(1)],
            )
        })
        .unwrap()
        .into_value(),
    ]
}

fn every_family_closed_path() -> CurvePath2 {
    let mut curves = every_family_open_chain();
    curves.extend([
        Curve2::from(LineSeg2::try_new(p(16, 0), p(16, -3)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(16, -3), p(0, -3)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, -3), p(0, 0)).unwrap()),
    ]);
    CurvePath2::try_new(curves).unwrap()
}

fn right_angle_line_path(length: i32) -> CurvePath2 {
    CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-length, 0), p(0, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 0), p(0, length)).unwrap()),
    ])
    .unwrap()
}

#[test]
fn top_level_curve_carries_every_public_family() {
    let curves = every_family_open_chain();

    assert_eq!(
        curves.iter().map(Curve2::family).collect::<Vec<_>>(),
        vec![
            CurveFamily2::Line,
            CurveFamily2::CircularArc,
            CurveFamily2::QuadraticBezier,
            CurveFamily2::CubicBezier,
            CurveFamily2::RationalQuadraticBezier,
            CurveFamily2::RationalBezier,
            CurveFamily2::PolynomialBSpline,
            CurveFamily2::Nurbs,
        ]
    );
}
#[test]
fn top_level_curve_region_classifies_points_and_shares_results() {
    let policy = PredicatePolicy::STRICT;
    let region = crate::support::under(&policy, || {
        CurveRegion2::try_from_boundary_paths(
            &[every_family_closed_path()],
            hypercurve::FillRule::EvenOdd,
        )
    })
    .unwrap()
    .into_value();
    let clone = region.clone();
    let signed_area = match crate::support::under(&policy, || region.signed_area())
        .unwrap()
        .into_value()
    {
        Some(area) => area,
        other => panic!("degree-two rational boundary contributions are exact: {other:?}"),
    };
    assert_eq!(
        crate::support::under(&policy, || clone.signed_area()).map(|outcome| outcome.into_value()),
        Ok(Some(signed_area))
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || region
            .classify_point(&p(8, -1).into()))
        .map(|outcome| outcome.into_value()),
        Ok(RegionPointLocation::Inside)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || clone
            .classify_point(&p(8, -4).into()))
        .map(|outcome| outcome.into_value()),
        Ok(RegionPointLocation::Outside)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || clone
            .classify_point(&p(0, 0).into()))
        .map(|outcome| outcome.into_value()),
        Ok(RegionPointLocation::Boundary)
    );
    let debug = format!("{region:?}");
    assert!(!debug.contains("native_boundary"));
    assert!(!debug.contains("signed_area_cache"));

    let square = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(0, 0), p(2, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(2, 0), p(2, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(2, 2), p(0, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 2), p(0, 0)).unwrap()),
    ])
    .unwrap();
    let bounded =
        CurveRegion2::try_from_boundary_paths(&[square], hypercurve::FillRule::EvenOdd).unwrap();
    let bounded_clone = bounded.clone();
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || bounded
            .classify_point(&p(1, 1).into()))
        .map(|outcome| outcome.into_value()),
        Ok(RegionPointLocation::Inside)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || bounded_clone
            .classify_point(&p(1, 1).into()))
        .map(|outcome| outcome.into_value()),
        Ok(RegionPointLocation::Inside)
    );
}

#[test]
fn curve_path_boundary_and_classification_report_terminal_closure() {
    let (start_x, end_x) = support::terminally_equal_pair(Real::pi() + Real::e());
    let start = Point2::new(start_x, Real::zero());
    let end = Point2::new(end_x, Real::zero());
    let origin = p(0, 0);
    let upper = p(0, 2);
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(start.clone(), origin.clone()).unwrap()),
        Curve2::from(LineSeg2::try_new(origin, upper.clone()).unwrap()),
        Curve2::from(LineSeg2::try_new(upper, end).unwrap()),
    ])
    .unwrap();

    let boundary =
        crate::support::under(&PredicatePolicy::APPROXIMATE_512, || path.boundary_loop())
            .expect("the terminal policy must validate the symbolic closing seam");
    assert_eq!(boundary.certainty, CurveCertainty::Approximate512Consumed);
    assert_eq!(boundary.value.len(), 3);

    let strict_boundary =
        crate::support::under(&PredicatePolicy::STRICT, || path.boundary_loop()).unwrap_err();
    assert!(matches!(
        strict_boundary,
        ExactCurveError::Blocked(blocker)
            if blocker.operation() == CurveOperation2::Arrangement
                && blocker.reason() == UncertaintyReason::RealSign
    ));

    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.classify_point(&p(1, 1).into())
    })
    .expect("the terminal policy must classify through the retained boundary");
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    assert_eq!(approximate.value, ContourPointLocation::Inside);

    let strict = path.classify_point(&p(1, 1).into()).unwrap_err();
    assert!(matches!(
        strict,
        ExactCurveError::Blocked(blocker)
            if blocker.operation() == CurveOperation2::Classification
                && blocker.reason() == UncertaintyReason::RealSign
    ));

    let repeated = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.classify_point(&p(1, 1).into())
    })
    .expect("cached terminal evidence must remain observable");
    assert_eq!(repeated.certainty, CurveCertainty::Approximate512Consumed);
    assert_eq!(repeated.value, approximate.value);
}

#[test]
fn top_level_curve_region_rejects_open_boundary_paths_with_context() {
    let path = CurvePath2::try_new(vec![Curve2::from(
        LineSeg2::try_new(p(0, 0), p(1, 0)).unwrap(),
    )])
    .unwrap();

    let error = crate::support::under(&PredicatePolicy::STRICT, || {
        CurveRegion2::try_from_boundary_paths(&[path], hypercurve::FillRule::EvenOdd)
    })
    .unwrap_err();

    assert!(matches!(
        error,
        ExactCurveError::Invalid {
            operation: CurveOperation2::Construction,
            family: Some(CurveFamily2::Line),
            cause: CurveError::OpenCurvePath,
            ..
        }
    ));
}
#[test]
fn top_level_curve_evaluates_native_and_spline_parameters() {
    let half = (r(1) / r(2)).unwrap();
    let line = Curve2::from(LineSeg2::try_new(p(0, 0), p(2, 0)).unwrap());
    let quadratic = Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, 2), p(2, 0)));
    let spline = Curve2::try_polynomial_bspline(
        2,
        vec![p(0, 0), p(1, 2), p(2, 0)],
        vec![r(0), r(0), r(0), r(2), r(2), r(2)],
    )
    .unwrap();

    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || line
            .point_at(&half.clone().into()))
        .unwrap()
        .into_value(),
        p(1, 0).into()
    );
    assert_eq!(
        (
            line.parameter_domain()
                .start()
                .scalar()
                .expect("native parameter"),
            line.parameter_domain()
                .end()
                .scalar()
                .expect("native parameter")
        ),
        (&r(0), &r(1))
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || quadratic
            .point_at(&half.clone().into()))
        .unwrap()
        .into_value(),
        p(1, 1).into()
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || spline.point_at(&r(1).into()))
            .unwrap()
            .into_value(),
        p(1, 1).into()
    );
    assert_eq!(
        (
            spline
                .parameter_domain()
                .start()
                .scalar()
                .expect("native parameter"),
            spline
                .parameter_domain()
                .end()
                .scalar()
                .expect("native parameter")
        ),
        (&r(0), &r(2))
    );
    assert!(std::ptr::eq(
        spline.parameter_domain(),
        spline.clone().parameter_domain()
    ));
}

#[test]
fn top_level_curve_reuses_retained_native_endpoints() {
    for curve in every_family_open_chain() {
        assert_eq!(
            crate::support::under(&PredicatePolicy::STRICT, || curve
                .point_at(curve.parameter_domain().start()))
            .unwrap()
            .into_value(),
            curve.start()
        );
        assert_eq!(
            crate::support::under(&PredicatePolicy::STRICT, || curve
                .point_at(curve.parameter_domain().end()))
            .unwrap()
            .into_value(),
            curve.end()
        );
    }

    let rational =
        RationalBezier2::try_new(vec![p(0, 0), p(1, 2), p(2, 0)], vec![r(1), r(2), r(3)]).unwrap();
    let top_level = Curve2::from(rational.clone());
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || top_level
            .point_at(&r(0).into()))
        .unwrap()
        .into_value(),
        p(0, 0).into()
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || top_level
            .point_at(&r(1).into()))
        .unwrap()
        .into_value(),
        p(2, 0).into()
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || top_level
            .point_at(&(r(1) / r(2)).unwrap().into()))
        .unwrap()
        .into_value(),
        (crate::support::under_value(&PredicatePolicy::STRICT, || rational
            .point_at(&(r(1) / r(2)).unwrap()))
        .unwrap())
        .into()
    );
}

#[test]
fn top_level_curve_derivatives_preserve_parameter_domains_and_share_evaluators() {
    let half = (r(1) / r(2)).unwrap();
    let line = Curve2::from(LineSeg2::try_new(p(0, 0), p(2, 0)).unwrap());
    let line_clone = line.clone();
    let line_derivative = line.derivative_at(&half.clone().into()).unwrap();
    assert_eq!(
        line_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(2)
    );
    assert_eq!(
        line_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .1,
        &r(0)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || line_clone
            .derivative_at(&half.clone().into()))
        .unwrap()
        .into_value(),
        line_derivative
    );

    let quadratic = Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, 2), p(2, 0)));
    let quadratic_derivative = quadratic.derivative_at(&half.clone().into()).unwrap();
    assert_eq!(
        quadratic_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(2)
    );
    assert_eq!(
        quadratic_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .1,
        &r(0)
    );

    let spline = Curve2::try_polynomial_bspline(
        2,
        vec![p(0, 0), p(1, 2), p(2, 0)],
        vec![r(0), r(0), r(0), r(2), r(2), r(2)],
    )
    .unwrap();
    let Some(CurveGeometry2::PolynomialBSpline(retained_spline)) = spline.geometry() else {
        panic!("top-level polynomial constructor returned another family");
    };
    let spline_derivative = spline.derivative_at(&r(1).into()).unwrap();
    assert_eq!(
        spline_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(1)
    );
    assert_eq!(
        spline_derivative
            .represented_coordinates()
            .expect("represented derivative")
            .1,
        &r(0)
    );
    assert_eq!(
        hypercurve::CurveVector2::from(
            crate::support::under(&PredicatePolicy::STRICT, || retained_spline
                .derivative_at(&r(1)))
            .unwrap()
            .into_value()
        ),
        spline_derivative
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || spline
            .derivative_at(&r(1).into()))
        .unwrap()
        .into_value(),
        spline_derivative
    );
}

#[test]
fn top_level_curve_exposes_exact_higher_derivatives() {
    let curve = Curve2::from(
        hypercurve::RationalBezier2::try_new(vec![p(0, 0), p(4, 0)], vec![r(1), r(3)]).unwrap(),
    );
    let half = (r(1) / r(2)).unwrap();

    let derivatives = curve.derivatives_at(&half.clone().into(), 3).unwrap();

    assert_eq!(derivatives.len(), 3);
    assert_eq!(
        derivatives[0]
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(3)
    );
    assert_eq!(
        derivatives[1]
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(-6)
    );
    assert_eq!(
        derivatives[2]
            .represented_coordinates()
            .expect("represented derivative")
            .0,
        &r(18)
    );
}
#[test]
fn mixed_curve_path_fillet_accepts_every_non_arc_family_pair() {
    let families = [
        CurveFamily2::Line,
        CurveFamily2::QuadraticBezier,
        CurveFamily2::CubicBezier,
        CurveFamily2::RationalQuadraticBezier,
        CurveFamily2::RationalBezier,
        CurveFamily2::PolynomialBSpline,
        CurveFamily2::Nurbs,
    ];

    for previous_family in families {
        for next_family in families {
            let path = CurvePath2::try_new(vec![
                linear_family_curve(previous_family, false),
                linear_family_curve(next_family, true),
            ])
            .unwrap();
            let filleted = {
                let solutions = crate::support::under(&PredicatePolicy::STRICT, || {
                    path.fillet_vertex(
                        1,
                        &hypercurve::CurveFillet2::new(Real::one()),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap_or_else(|error| {
                    panic!("{previous_family:?}/{next_family:?} fillet failed: {error}")
                })
                .into_value();
                let mut candidates = solutions.into_solutions();
                assert_eq!(candidates.len(), 1, "expected one isolated fillet");
                candidates.pop().unwrap()
            };

            assert_eq!(filleted.curves().len(), 3);
            assert_eq!(filleted.curves()[0].family(), previous_family);
            assert_eq!(filleted.curves()[1].family(), CurveFamily2::CircularArc);
            assert_eq!(filleted.curves()[2].family(), next_family);
            assert_eq!(
                filleted.curves()[0].end(),
                hypercurve::CurvePoint2::from(p(-1, 0).clone())
            );
            assert_eq!(
                filleted.curves()[1].start(),
                hypercurve::CurvePoint2::from(p(-1, 0).clone())
            );
            assert_eq!(
                filleted.curves()[1].end(),
                hypercurve::CurvePoint2::from(p(0, 1).clone())
            );
            assert_eq!(
                filleted.curves()[2].start(),
                hypercurve::CurvePoint2::from(p(0, 1).clone())
            );
        }
    }
}

#[test]
fn mixed_curve_path_fillet_preserves_arc_family_and_exact_tangency() {
    let source_arc = CircularArc2::try_from_center(p(5, 0), p(5, 2), p(5, 1), true).unwrap();
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(0, 0), p(5, 0)).unwrap()),
        Curve2::from(source_arc),
    ])
    .unwrap();

    let filleted = {
        let solutions = path
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(Real::one()),
                CurveCornerMode2::TrimOnly,
            )
            .unwrap();
        let mut candidates = solutions.into_solutions();
        assert_eq!(candidates.len(), 1, "expected one isolated fillet");
        candidates.pop().unwrap()
    };

    assert_eq!(
        filleted
            .curves()
            .iter()
            .map(Curve2::family)
            .collect::<Vec<_>>(),
        vec![
            CurveFamily2::Line,
            CurveFamily2::CircularArc,
            CurveFamily2::CircularArc,
        ]
    );
    assert_eq!(
        filleted.curves()[0].end(),
        hypercurve::CurvePoint2::from(p(3, 0).clone())
    );
    assert_eq!(
        filleted.curves()[1].end(),
        hypercurve::CurvePoint2::from(p(4, 1).clone())
    );
    assert_eq!(
        filleted.curves()[2].start(),
        hypercurve::CurvePoint2::from(p(4, 1).clone())
    );

    let previous_arc = CircularArc2::try_from_center(p(5, 2), p(5, 0), p(5, 1), false).unwrap();
    let reversed_pair = CurvePath2::try_new(vec![
        Curve2::from(previous_arc),
        Curve2::from(LineSeg2::try_new(p(5, 0), p(0, 0)).unwrap()),
    ])
    .unwrap();

    let reversed_fillet = {
        let solutions = reversed_pair
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(Real::one()),
                CurveCornerMode2::TrimOnly,
            )
            .unwrap();
        let mut candidates = solutions.into_solutions();
        assert_eq!(candidates.len(), 1, "expected one isolated fillet");
        candidates.pop().unwrap()
    };
    assert_eq!(
        reversed_fillet.curves()[0].family(),
        CurveFamily2::CircularArc
    );
    assert_eq!(
        reversed_fillet.curves()[0].end(),
        hypercurve::CurvePoint2::from(p(4, 1).clone())
    );
    assert_eq!(
        reversed_fillet.curves()[1].end(),
        hypercurve::CurvePoint2::from(p(3, 0).clone())
    );
    assert_eq!(reversed_fillet.curves()[2].family(), CurveFamily2::Line);
}

#[test]
fn closed_curve_path_corner_edits_support_the_start_end_seam() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(0, 0), p(2, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(2, 0), p(2, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(2, 2), p(0, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 2), p(0, 0)).unwrap()),
    ])
    .unwrap();

    let CurveCornerSolutions2::Unique(solved_chamfer) = path
        .chamfer_vertex_by_setbacks(0, r(1), r(1), CurveCornerMode2::TrimOnly)
        .unwrap()
    else {
        panic!("the closed seam must have one setback chamfer");
    };
    assert_eq!(
        solved_chamfer.start(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );
    assert_eq!(solved_chamfer.end(), solved_chamfer.start());

    let solved_fillet = {
        let solutions = path
            .fillet_vertex(
                0,
                &hypercurve::CurveFillet2::new(r(1)),
                CurveCornerMode2::TrimOnly,
            )
            .unwrap();
        let mut candidates = solutions.into_solutions();
        assert_eq!(candidates.len(), 1, "expected one isolated fillet");
        candidates.pop().unwrap()
    };
    assert_eq!(
        solved_fillet.start(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );
    assert_eq!(solved_fillet.end(), solved_fillet.start());
    let Some(CurveGeometry2::CircularArc(arc)) = solved_fillet.curves()[0].geometry() else {
        panic!("the seam fillet must lead with its circular carrier");
    };
    assert_eq!(arc.center(), &p(1, 1));
    assert_eq!(arc.end(), &p(1, 0));
    CurveRegion2::try_from_boundary_paths(&[solved_fillet], hypercurve::FillRule::EvenOdd).unwrap();
}

#[test]
fn one_curve_closed_spline_corner_edits_retain_one_middle_interval() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
            let path = CurvePath2::try_new(vec![closed_linear_spline(family, &policy)]).unwrap();
            for reversed in [false, true] {
                let path = if reversed {
                    crate::support::under(&policy, || path.clone().reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path.clone()
                };
                let (trimmed_previous_point, trimmed_next_point) = if reversed {
                    (p(1, 0), p(0, 1))
                } else {
                    (p(0, 1), p(1, 0))
                };
                for (previous, next, previous_point, next_point) in [
                    (
                        Real::one(),
                        Real::one(),
                        trimmed_previous_point.clone(),
                        trimmed_next_point.clone(),
                    ),
                    (
                        Real::one(),
                        Real::zero(),
                        trimmed_previous_point.clone(),
                        p(0, 0),
                    ),
                    (
                        Real::zero(),
                        Real::one(),
                        p(0, 0),
                        trimmed_next_point.clone(),
                    ),
                ] {
                    let expected_count = if previous == Real::zero() || next == Real::zero() {
                        2
                    } else {
                        1
                    };
                    let result = crate::support::under(&policy, || {
                        path.chamfer_vertex_by_setbacks(
                            0,
                            previous,
                            next,
                            CurveCornerMode2::TrimOnly,
                        )
                    })
                    .unwrap();
                    assert_eq!(result.certainty, CurveCertainty::Certified);
                    let candidates = match result.into_value() {
                        CurveCornerSolutions2::Unique(candidate) => vec![candidate],
                        CurveCornerSolutions2::Multiple(candidates) => candidates,
                        CurveCornerSolutions2::NoSolution(reason) => {
                            panic!("the closed spline seam lost its cuts: {reason:?}")
                        }
                    };
                    // With one zero setback either positive-distance contact
                    // leaves a valid closed path interval. The short interval
                    // retraces the inserted chord; it is still a valid path.
                    // With two positive setbacks the crossed pairing must be
                    // rejected before publication, leaving one middle interval.
                    assert_eq!(candidates.len(), expected_count);
                    let edited = candidates
                        .iter()
                        .find(|candidate| {
                            candidate.curves()[0].start()
                                == hypercurve::CurvePoint2::from(previous_point.clone())
                                && candidate.curves()[0].end()
                                    == hypercurve::CurvePoint2::from(next_point.clone())
                        })
                        .expect("the full middle interval must remain among the candidates");
                    assert_eq!(
                        edited.curves()[1].start(),
                        hypercurve::CurvePoint2::from(next_point.clone())
                    );
                    assert_eq!(
                        edited.curves()[1].end(),
                        hypercurve::CurvePoint2::from(previous_point.clone())
                    );
                    for edited in &candidates {
                        assert_eq!(edited.curves().len(), 2);
                        assert_eq!(edited.curves()[1].family(), family);
                        assert_eq!(edited.curves()[0].end(), edited.curves()[1].start());
                        assert_eq!(edited.curves()[1].end(), edited.curves()[0].start());
                    }
                }

                let fillet = crate::support::under(&policy, || {
                    path.fillet_vertex(
                        0,
                        &hypercurve::CurveFillet2::new(Real::one()),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap();
                assert_eq!(fillet.certainty, CurveCertainty::Certified);
                let fillet = {
                    let solutions = fillet.into_value();
                    let mut candidates = solutions.into_solutions();
                    assert_eq!(candidates.len(), 1, "expected one isolated fillet");
                    candidates.pop().unwrap()
                };
                assert_eq!(fillet.curves().len(), 2);
                let Some(CurveGeometry2::CircularArc(arc)) = fillet.curves()[0].geometry() else {
                    panic!("the one-curve spline seam must publish one circular fillet");
                };
                assert_eq!(arc.center(), &p(1, 1));
                assert_eq!(arc.start(), &trimmed_previous_point);
                assert_eq!(arc.end(), &trimmed_next_point);
                assert_eq!(fillet.curves()[1].family(), family);
                assert_eq!(
                    fillet.curves()[1].start(),
                    hypercurve::CurvePoint2::from(trimmed_next_point.clone())
                );
                assert_eq!(
                    fillet.curves()[1].end(),
                    hypercurve::CurvePoint2::from(trimmed_previous_point.clone())
                );
            }
        }
    }
}

#[test]
fn one_curve_closed_spline_extensions_materialize_each_cell_once() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
            let path = CurvePath2::try_new(vec![closed_linear_spline(family, &policy)]).unwrap();
            for reversed in [false, true] {
                let path = if reversed {
                    crate::support::under(&policy, || path.clone().reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path.clone()
                };
                for (previous, next, expected_curve_count) in
                    [(r(3), r(1), 3), (r(1), r(3), 3), (r(3), r(3), 4)]
                {
                    let result = crate::support::under(&policy, || {
                        path.chamfer_vertex_by_setbacks(
                            0,
                            previous,
                            next,
                            CurveCornerMode2::TrimOrExtend,
                        )
                    })
                    .unwrap();
                    assert_eq!(result.certainty, CurveCertainty::Certified);
                    let candidates = match result.into_value() {
                        CurveCornerSolutions2::Unique(edited) => vec![edited],
                        CurveCornerSolutions2::Multiple(edited) => edited,
                        CurveCornerSolutions2::NoSolution(reason) => {
                            panic!("the exterior spline seam chamfer was lost: {reason:?}")
                        }
                    };
                    assert!(
                        candidates
                            .iter()
                            .any(|edited| edited.curves().len() == expected_curve_count),
                        "the expected one-source seam reconstruction was not published"
                    );
                    assert!(candidates.iter().all(|edited| {
                        edited
                            .curves()
                            .iter()
                            .filter(|curve| curve.family() == family)
                            .count()
                            == 1
                    }));
                }

                let fillet = crate::support::under(&policy, || {
                    path.fillet_vertex(
                        0,
                        &hypercurve::CurveFillet2::new(r(3)),
                        CurveCornerMode2::TrimOrExtend,
                    )
                })
                .unwrap();
                assert_eq!(fillet.certainty, CurveCertainty::Certified);
                let candidates = {
                    let solutions = fillet.into_value();
                    let candidates = solutions.into_solutions();
                    assert!(
                        !candidates.is_empty(),
                        "expected at least one isolated fillet"
                    );
                    candidates
                };
                assert!(candidates.iter().any(|edited| edited.curves().len() == 4));
                assert!(candidates.iter().all(|edited| {
                    edited
                        .curves()
                        .iter()
                        .filter(|curve| curve.family() == family)
                        .count()
                        == 1
                }));
            }
        }
    }
}

#[test]
fn line_corner_solvers_derive_unique_trimmed_fillet_and_chamfer() {
    let path = right_angle_line_path(4);
    let chamfer = crate::support::under(&PredicatePolicy::STRICT, || {
        path.chamfer_vertex_by_setbacks(1, r(1), r(1), CurveCornerMode2::TrimOnly)
    })
    .unwrap();
    let CurveCornerSolutions2::Unique(chamfer) = chamfer.into_value() else {
        panic!("equal line setbacks must have one trimmed solution");
    };
    assert_eq!(chamfer.curves().len(), 3);
    assert_eq!(
        chamfer.curves()[0].end(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        chamfer.curves()[1].start(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        chamfer.curves()[1].end(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );
    assert_eq!(
        chamfer.curves()[2].start(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );

    let fillet = crate::support::under(&PredicatePolicy::STRICT, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(r(1)),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    let fillet = {
        let solutions = fillet.into_value();
        let mut candidates = solutions.into_solutions();
        assert_eq!(candidates.len(), 1, "expected one isolated fillet");
        candidates.pop().unwrap()
    };
    assert_eq!(fillet.curves().len(), 3);
    assert_eq!(
        fillet.curves()[0].end(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    let Some(CurveGeometry2::CircularArc(arc)) = fillet.curves()[1].geometry() else {
        panic!("the solved fillet must be an exact circular carrier");
    };
    assert_eq!(arc.start(), &p(-1, 0));
    assert_eq!(arc.end(), &p(0, 1));
    assert_eq!(arc.center(), &p(-1, 1));
    assert_eq!(arc.radius_squared(), r(1));
    assert!(!arc.is_clockwise());
}

#[test]
fn oblique_line_corner_solvers_preserve_exact_orientation() {
    for (next_y, next_cut_y, center_y, clockwise) in
        [(4, q(4, 5), r(1), false), (-4, q(-4, 5), r(-1), true)]
    {
        let path = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-5, 0), p(0, 0)).unwrap()),
            Curve2::from(LineSeg2::try_new(p(0, 0), p(3, next_y)).unwrap()),
        ])
        .unwrap();
        let CurveCornerSolutions2::Unique(chamfer) = path
            .chamfer_vertex_by_setbacks(1, Real::one(), Real::one(), CurveCornerMode2::TrimOnly)
            .unwrap()
        else {
            panic!("a 3-4-5 line corner must have one exact chamfer");
        };
        assert_eq!(
            chamfer.curves()[0].end(),
            hypercurve::CurvePoint2::from(p(-1, 0).clone())
        );
        assert_eq!(
            chamfer.curves()[2].start(),
            hypercurve::CurvePoint2::from(Point2::new(q(3, 5), next_cut_y).clone())
        );

        let fillet = {
            let solutions = path
                .fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(Real::one()),
                    CurveCornerMode2::TrimOnly,
                )
                .unwrap();
            let mut candidates = solutions.into_solutions();
            assert_eq!(candidates.len(), 1, "expected one isolated fillet");
            candidates.pop().unwrap()
        };
        let Some(CurveGeometry2::CircularArc(arc)) = fillet.curves()[1].geometry() else {
            panic!("the oblique fillet must remain circular");
        };
        assert_eq!(arc.start(), &Point2::new(q(-1, 2), Real::zero()));
        assert_eq!(arc.end(), &Point2::new(q(3, 10), q(next_y, 10)));
        assert_eq!(arc.center(), &Point2::new(q(-1, 2), center_y));
        assert_eq!(arc.radius_squared(), Real::one());
        assert_eq!(arc.is_clockwise(), clockwise);
    }
}

#[test]
fn exact_chamfer_solver_handles_native_line_arc_and_arc_arc_carriers() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let next_arc = CircularArc2::try_from_center(p(1, 0), p(2, 1), p(1, 1), false).unwrap();
        let line_arc = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-1, 0), p(1, 0)).unwrap()),
            Curve2::from(next_arc.clone()),
        ])
        .unwrap();
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            line_arc.chamfer_vertex_by_setbacks(1, q(1, 2), Real::one(), CurveCornerMode2::TrimOnly)
        })
        .unwrap()
        .into_value() else {
            panic!("the line-arc carrier pair must have one exact trim solution");
        };
        assert_eq!(
            chamfered
                .curves()
                .iter()
                .map(Curve2::family)
                .collect::<Vec<_>>(),
            vec![
                CurveFamily2::Line,
                CurveFamily2::Line,
                CurveFamily2::CircularArc,
            ]
        );
        let line_cut = Point2::new(q(1, 2), Real::zero());
        let next_cut = chamfered.curves()[2].start();
        assert_eq!(
            chamfered.curves()[0].end(),
            hypercurve::CurvePoint2::from(line_cut.clone())
        );
        assert_eq!(
            chamfered.curves()[1].start(),
            hypercurve::CurvePoint2::from(line_cut.clone())
        );
        assert_eq!(chamfered.curves()[1].end(), next_cut);
        assert!(matches!(
            next_cut
                .coordinates()
                .expect("native arc endpoint")
                .distance_squared(&p(1, 0))
                .certified_eq_until(&Real::one(), -4096),
            CertifiedRealEquality::Equal { .. }
        ));

        let CurveCornerSolutions2::Multiple(extended) = crate::support::under(&policy, || {
            line_arc.chamfer_vertex_by_setbacks(
                1,
                q(1, 2),
                Real::one(),
                CurveCornerMode2::TrimOrExtend,
            )
        })
        .unwrap()
        .into_value() else {
            panic!("line-arc extension mode must retain all four support choices");
        };
        assert_eq!(extended.len(), 4);
        assert_eq!(
            extended[0].curves()[0].end(),
            hypercurve::CurvePoint2::from(Point2::new(q(1, 2), Real::zero()).clone())
        );
        assert_eq!(extended[0].curves()[0].end(), extended[1].curves()[0].end());
        assert_eq!(
            extended[2].curves()[0].end(),
            hypercurve::CurvePoint2::from(Point2::new(q(3, 2), Real::zero()).clone())
        );
        assert_eq!(extended[2].curves()[0].end(), extended[3].curves()[0].end());
        assert_eq!(
            extended[0].curves()[2].start(),
            extended[2].curves()[2].start()
        );
        assert_eq!(
            extended[1].curves()[2].start(),
            extended[3].curves()[2].start()
        );
        assert_ne!(
            extended[0].curves()[2].start(),
            extended[1].curves()[2].start()
        );
        let mut retained_corner_membership = extended[..2]
            .iter()
            .map(|candidate| {
                let Some(CurveGeometry2::CircularArc(arc)) = candidate.curves()[2].geometry()
                else {
                    panic!("every line-arc candidate must retain a circular carrier");
                };
                assert_eq!(arc.center(), &p(1, 1));
                assert_eq!(arc.end(), &p(2, 1));
                crate::support::under_classified(&policy, || arc.contains_point(&p(1, 0)))
            })
            .collect::<Vec<_>>();
        retained_corner_membership
            .sort_by_key(|classification| matches!(classification, Classification::Decided(true)));
        assert_eq!(
            retained_corner_membership,
            vec![
                Classification::Decided(false),
                Classification::Decided(true)
            ]
        );
        assert_eq!(
            crate::support::under(&policy, || line_arc.chamfer_vertex_by_setbacks(
                1,
                q(1, 2),
                r(2).sqrt().unwrap(),
                CurveCornerMode2::TrimOnly
            ))
            .unwrap()
            .into_value(),
            CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::OutsideTrimDomain),
            "a cut at the opposite arc endpoint is not an interior trim"
        );

        let previous_arc =
            CircularArc2::try_from_center(p(0, -1), p(1, 0), p(1, -1), true).unwrap();
        let arc_arc =
            CurvePath2::try_new(vec![Curve2::from(previous_arc), Curve2::from(next_arc)]).unwrap();
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            arc_arc.chamfer_vertex_by_setbacks(
                1,
                Real::one(),
                Real::one(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .unwrap()
        .into_value() else {
            panic!("the arc-arc carrier pair must have one exact trim solution");
        };
        assert_eq!(
            chamfered
                .curves()
                .iter()
                .map(Curve2::family)
                .collect::<Vec<_>>(),
            vec![
                CurveFamily2::CircularArc,
                CurveFamily2::Line,
                CurveFamily2::CircularArc,
            ]
        );
        let previous_cut = chamfered.curves()[0].end();
        let next_cut = chamfered.curves()[2].start();
        assert_eq!(chamfered.curves()[1].start(), previous_cut);
        assert_eq!(chamfered.curves()[1].end(), next_cut);
        for cut in [previous_cut, next_cut] {
            assert!(matches!(
                cut.coordinates()
                    .expect("native arc endpoint")
                    .distance_squared(&p(1, 0))
                    .certified_eq_until(&Real::one(), -4096),
                CertifiedRealEquality::Equal { .. }
            ));
        }
    }
}

#[test]
fn exact_arc_chamfer_solver_preserves_both_major_sweep_cuts() {
    let major_arc =
        CircularArc2::try_from_center(p(1, 0), Point2::new(q(3, 5), q(4, 5)), p(0, 0), true)
            .unwrap();
    let half_root_three = (r(3).sqrt().unwrap() / r(2)).unwrap();
    for cut in [
        Point2::new(q(1, 2), -half_root_three.clone()),
        Point2::new(q(1, 2), half_root_three),
    ] {
        let contains = crate::support::under_classified(&PredicatePolicy::STRICT, || {
            major_arc.contains_point(&cut)
        });
        assert!(
            matches!(contains, Classification::Decided(true)),
            "major-arc cut incidence must be strict: {contains:?}"
        );
        let sweep = crate::support::under_classified_result(&PredicatePolicy::STRICT, || {
            major_arc.sweep_fraction(&cut)
        })
        .unwrap();
        let Classification::Decided(sweep) = sweep else {
            panic!("major-arc cut sweep fraction must be strict: {sweep:?}");
        };
        let parameter = crate::support::under_classified_result(&PredicatePolicy::STRICT, || {
            major_arc.parameter_at_sweep_fraction(&sweep)
        })
        .unwrap();
        assert!(
            matches!(parameter, Classification::Decided(_)),
            "major-arc public parameter must be strict: {parameter:?}"
        );
    }
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(1, -2), p(1, 0)).unwrap()),
        Curve2::from(major_arc),
    ])
    .unwrap();

    let CurveCornerSolutions2::Unique(tangent) = path
        .chamfer_vertex_by_setbacks(1, Real::one(), r(2), CurveCornerMode2::TrimOnly)
        .unwrap()
    else {
        panic!("the diametric major-arc setback must retain its tangent cut");
    };
    assert_eq!(
        tangent.curves()[0].end(),
        hypercurve::CurvePoint2::from(p(1, -1).clone())
    );
    assert_eq!(
        tangent.curves()[1].end(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        tangent.curves()[2].start(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(1, Real::one(), r(3), CurveCornerMode2::TrimOnly))
        .unwrap()
        .into_value(),
        CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::OutsideTrimDomain)
    );

    let CurveCornerSolutions2::Multiple(chamfers) = path
        .chamfer_vertex_by_setbacks(1, Real::one(), Real::one(), CurveCornerMode2::TrimOnly)
        .unwrap()
    else {
        panic!("a major arc crossing the setback circle twice must retain both cuts");
    };
    assert_eq!(chamfers.len(), 2);
    let next_starts = chamfers
        .iter()
        .map(|chamfer| {
            assert_eq!(
                chamfer.curves()[0].end(),
                hypercurve::CurvePoint2::from(p(1, -1).clone())
            );
            assert_eq!(
                chamfer.curves()[1].start(),
                hypercurve::CurvePoint2::from(p(1, -1).clone())
            );
            assert_eq!(chamfer.curves()[2].family(), CurveFamily2::CircularArc);
            chamfer.curves()[2].start().clone()
        })
        .collect::<Vec<_>>();
    assert_ne!(next_starts[0], next_starts[1]);
    for cut in next_starts {
        assert!(matches!(
            cut.coordinates()
                .expect("native arc endpoint")
                .distance_squared(&p(1, 0))
                .certified_eq_until(&Real::one(), -4096),
            CertifiedRealEquality::Equal { .. }
        ));
    }
}

#[test]
fn exact_native_arc_fillet_solver_handles_every_native_pair_order() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let line_arc = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
            Curve2::from(CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap()),
        ])
        .unwrap();
        let fillet = {
            let solutions = crate::support::under(&policy, || {
                line_arc.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let mut candidates = solutions.into_solutions();
            assert_eq!(candidates.len(), 1, "expected one isolated fillet");
            candidates.pop().unwrap()
        };
        assert_eq!(
            fillet
                .curves()
                .iter()
                .map(Curve2::family)
                .collect::<Vec<_>>(),
            vec![
                CurveFamily2::Line,
                CurveFamily2::CircularArc,
                CurveFamily2::CircularArc,
            ]
        );
        let Some(CurveGeometry2::CircularArc(inserted)) = fillet.curves()[1].geometry() else {
            panic!("the solved fillet must remain a certified circular arc");
        };
        let expected_center = Point2::new(Real::one() - r(2).sqrt().unwrap(), q(1, 2));
        assert!(matches!(
            inserted
                .center()
                .distance_squared(&expected_center)
                .certified_eq_until(&Real::zero(), -4096),
            CertifiedRealEquality::Equal { .. }
        ));
        assert!(matches!(
            inserted
                .radius_squared()
                .certified_eq_until(&q(1, 4), -4096),
            CertifiedRealEquality::Equal { .. }
        ));
        assert_eq!(
            fillet.curves()[0].end(),
            hypercurve::CurvePoint2::from((*(inserted.start())).clone())
        );
        assert_eq!(
            fillet.curves()[2].start(),
            hypercurve::CurvePoint2::from((*(inserted.end())).clone())
        );
        let Some(CurveGeometry2::CircularArc(retained_next)) = fillet.curves()[2].geometry() else {
            panic!("the source circular carrier must be retained");
        };
        assert_eq!(retained_next.center(), &p(1, 0));
        assert_eq!(retained_next.end(), &p(1, 1));

        let extended = crate::support::under(&policy, || {
            line_arc.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(1, 2)),
                CurveCornerMode2::TrimOrExtend,
            )
        })
        .unwrap()
        .into_value();
        assert_eq!({ extended.solutions().len() }, 3);

        let reversed = crate::support::under(&policy, || line_arc.clone().reversed())
            .unwrap()
            .into_value();
        let reversed_fillet = {
            let solutions = crate::support::under(&policy, || {
                reversed.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let mut candidates = solutions.into_solutions();
            assert_eq!(candidates.len(), 1, "expected one isolated fillet");
            candidates.pop().unwrap()
        };
        assert_eq!(
            reversed_fillet
                .curves()
                .iter()
                .map(Curve2::family)
                .collect::<Vec<_>>(),
            vec![
                CurveFamily2::CircularArc,
                CurveFamily2::CircularArc,
                CurveFamily2::Line,
            ]
        );

        let arc_arc = CurvePath2::try_new(vec![
            Curve2::from(
                CircularArc2::try_from_center(p(-1, -1), p(0, 0), p(0, -1), true).unwrap(),
            ),
            Curve2::from(CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap()),
        ])
        .unwrap();
        let fillet = {
            let solutions = crate::support::under(&policy, || {
                arc_arc.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let mut candidates = solutions.into_solutions();
            assert_eq!(candidates.len(), 1, "expected one isolated fillet");
            candidates.pop().unwrap()
        };
        assert!(
            fillet
                .curves()
                .iter()
                .all(|curve| curve.family() == CurveFamily2::CircularArc)
        );
        let Some(CurveGeometry2::CircularArc(inserted)) = fillet.curves()[1].geometry() else {
            unreachable!();
        };
        for source_center in [p(0, -1), p(1, 0)] {
            assert!(matches!(
                inserted
                    .center()
                    .distance_squared(&source_center)
                    .certified_eq_until(&q(9, 4), -4096),
                CertifiedRealEquality::Equal { .. }
            ));
        }
        assert!(matches!(
            inserted
                .radius_squared()
                .certified_eq_until(&q(1, 4), -4096),
            CertifiedRealEquality::Equal { .. }
        ));
        assert_eq!(
            fillet.curves()[0].end(),
            hypercurve::CurvePoint2::from((*(inserted.start())).clone())
        );
        assert_eq!(
            fillet.curves()[2].start(),
            hypercurve::CurvePoint2::from((*(inserted.end())).clone())
        );

        let extended = crate::support::under(&policy, || {
            arc_arc.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(1, 2)),
                CurveCornerMode2::TrimOrExtend,
            )
        })
        .unwrap()
        .into_value();
        assert_eq!({ extended.solutions().len() }, 2);

        let cross_center = crate::support::under(&policy, || {
            arc_arc.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(r(2)),
                CurveCornerMode2::TrimOrExtend,
            )
        })
        .unwrap()
        .into_value();
        let cross_center = {
            let solutions = cross_center;
            let candidates = solutions.into_solutions();
            assert!(candidates.len() > 1, "expected multiple isolated fillets");
            candidates
        };
        assert!(cross_center.iter().any(|candidate| {
            let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry() else {
                return false;
            };
            fillet.is_clockwise()
                && fillet
                    .radius_squared()
                    .certified_eq_until(&r(4), -4096)
                    .as_bool()
                    == Some(true)
        }));
    }
}

#[test]
fn retained_circular_conics_share_the_native_corner_kernel() {
    let native_arc = CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap();
    let conic = native_arc.rational_bezier_decomposition().unwrap().spans()[0]
        .curve()
        .clone();
    let elevated = RationalBezier2::from(conic.clone())
        .elevated_to_degree(5)
        .unwrap();
    let carriers = [
        (CurveFamily2::RationalQuadraticBezier, Curve2::from(conic)),
        (CurveFamily2::RationalBezier, Curve2::from(elevated)),
    ];

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let same_point = |actual: &hypercurve::CurvePoint2, expected: &hypercurve::CurvePoint2| {
            let equality = crate::support::under_outcome_classification(&policy, || {
                actual.coincides_with(expected)
            });
            assert_eq!(equality.certainty, CurveCertainty::Certified);
            assert_eq!(equality.value, Classification::Decided(true));
        };
        let chamfer_y = (r(15).sqrt().unwrap() / r(8)).unwrap();
        let upper_contact = hypercurve::CurvePoint2::from(Point2::new(q(1, 8), chamfer_y.clone()));
        let lower_contact = hypercurve::CurvePoint2::from(Point2::new(q(1, 8), -chamfer_y));
        for (family, carrier) in &carriers {
            let path = CurvePath2::try_new(vec![
                Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
                carrier.clone(),
            ])
            .unwrap();

            let CurveCornerSolutions2::Unique(chamfer) = crate::support::under(&policy, || {
                path.chamfer_vertex_by_setbacks(1, q(1, 2), q(1, 2), CurveCornerMode2::TrimOnly)
            })
            .unwrap()
            .into_value() else {
                panic!("the retained circular conic must have one exact chamfer");
            };
            same_point(&chamfer.start(), &path.start());
            same_point(&chamfer.end(), &path.end());
            same_point(
                &chamfer.curves()[1].start(),
                &Point2::new(-q(1, 2), r(0)).into(),
            );
            same_point(&chamfer.curves()[1].end(), &upper_contact);
            assert_eq!(chamfer.curves()[0].end(), chamfer.curves()[1].start());
            assert_eq!(chamfer.curves()[1].end(), chamfer.curves()[2].start());

            let fillet = {
                let solutions = crate::support::under(&policy, || {
                    path.fillet_vertex(
                        1,
                        &hypercurve::CurveFillet2::new(q(1, 2)),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap()
                .into_value();
                let mut candidates = solutions.into_solutions();
                assert_eq!(candidates.len(), 1, "expected one isolated fillet");
                candidates.pop().unwrap()
            };
            same_point(&fillet.start(), &path.start());
            same_point(&fillet.end(), &path.end());
            for pair in fillet.curves().windows(2) {
                same_point(&pair[0].end(), &pair[1].start());
            }
            let root_two = r(2).sqrt().unwrap();
            let center = Point2::new(r(1) - &root_two, q(1, 2));
            same_point(
                &fillet.curves()[0].end(),
                &Point2::new(r(1) - &root_two, r(0)).into(),
            );
            same_point(
                &fillet.curves().last().unwrap().start(),
                &Point2::new(r(1) - q(2, 3) * root_two, q(1, 3)).into(),
            );
            for inserted in &fillet.curves()[1..fillet.curves().len() - 1] {
                let domain = inserted.parameter_domain();
                let (start, end) = domain
                    .scalar_endpoints()
                    .expect("represented circle fixture");
                let midpoint = ((start + end) / r(2)).unwrap();
                let point =
                    crate::support::under(&policy, || inserted.point_at(&midpoint.into())).unwrap();
                assert_eq!(point.certainty, CurveCertainty::Certified);
                assert!(matches!(
                    point
                        .value
                        .coordinates()
                        .expect("represented circular midpoint")
                        .distance_squared(&center)
                        .certified_eq_until(&q(1, 4), -4096),
                    CertifiedRealEquality::Equal { .. }
                ));
            }

            for reversed in [false, true] {
                let extension_source = if reversed {
                    crate::support::under(&policy, || path.reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path.clone()
                };
                let extended = crate::support::under(&policy, || extension_source
                    .chamfer_vertex_by_setbacks(
                        1,
                        q(1, 2),
                        q(1, 2),
                        CurveCornerMode2::TrimOrExtend))
                    .unwrap_or_else(|error| {
                        panic!(
                            "the retained circular conic must share full-circle chamfer support: policy={policy:?}, family={family:?}, reversed={reversed}, error={error:?}"
                        )
                    });
                assert_eq!(extended.certainty, CurveCertainty::Certified);
                let CurveCornerSolutions2::Multiple(candidates) = extended.value else {
                    panic!("the circular and linear cuts must retain all four pairings");
                };
                assert_eq!(candidates.len(), 4);
                let mut extensions = 0;
                for candidate in candidates {
                    same_point(&candidate.start(), &extension_source.start());
                    same_point(&candidate.end(), &extension_source.end());
                    for pair in candidate.curves().windows(2) {
                        same_point(&pair[0].end(), &pair[1].start());
                    }
                    let chamfer_index = if reversed {
                        candidate.curves().len() - 2
                    } else {
                        1
                    };
                    let contact = if reversed {
                        candidate.curves()[chamfer_index].start()
                    } else {
                        candidate.curves()[chamfer_index].end()
                    };
                    let extension = crate::support::under_outcome_classification(&policy, || {
                        contact.coincides_with(&lower_contact)
                    });
                    assert_eq!(extension.certainty, CurveCertainty::Certified);
                    match extension.value {
                        Classification::Decided(true) => extensions += 1,
                        Classification::Decided(false) => same_point(&contact, &upper_contact),
                        Classification::Uncertain(reason) => {
                            panic!("circle contact evidence was lost: {reason:?}")
                        }
                    }
                }
                assert_eq!(extensions, 2);
            }

            let extended = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("the retained circular conic shares full-circle fillet support")
            .into_value();
            assert_eq!({ extended.solutions().len() }, 3);

            assert_eq!(
                crate::support::under(&policy, || path.chamfer_vertex_by_setbacks(
                    1,
                    Real::zero(),
                    Real::zero(),
                    CurveCornerMode2::TrimOrExtend
                ))
                .unwrap()
                .into_value(),
                CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::ZeroDesignValue)
            );
            assert_eq!(
                (crate::support::under(&policy, || path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(Real::zero()),
                    CurveCornerMode2::TrimOrExtend
                ))
                .unwrap()
                .into_value())
                .no_solution_reason(),
                Some(CurveCornerNoSolution2::ZeroDesignValue)
            );
        }
    }
}

#[test]
fn retained_circular_conic_pairs_extend_on_native_supports() {
    let previous = CircularArc2::try_from_center(p(-1, -1), p(0, 0), p(0, -1), true).unwrap();
    let next = CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap();
    let retained = |arc: &CircularArc2, elevated: bool| {
        let conic = arc.rational_bezier_decomposition().unwrap().spans()[0]
            .curve()
            .clone();
        if elevated {
            Curve2::from(RationalBezier2::from(conic).elevated_to_degree(5).unwrap())
        } else {
            Curve2::from(conic)
        }
    };

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for elevated in [false, true] {
            for reversed in [false, true] {
                let path = CurvePath2::try_new(vec![
                    retained(&previous, elevated),
                    retained(&next, elevated),
                ])
                .unwrap();
                let path = if reversed {
                    crate::support::under(&policy, || path.reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path
                };
                let trim = crate::support::under(&policy, || {
                    path.fillet_vertex(
                        1,
                        &hypercurve::CurveFillet2::new(q(1, 2)),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap()
                .into_value();
                assert_eq!({ trim.solutions().len() }, 1);
                let extended = crate::support::under(&policy, || path
                    .fillet_vertex(
                        1,
                        &hypercurve::CurveFillet2::new(q(1, 2)),
                        CurveCornerMode2::TrimOrExtend))
                    .unwrap_or_else(|error| {
                        panic!(
                            "retained circular supports must extend: policy={policy:?}, elevated={elevated}, reversed={reversed}, error={error:?}"
                        )
                    })
                    .into_value();
                assert_eq!({ extended.solutions().len() }, 2);

                let boundary_path = CurvePath2::try_new(vec![
                    retained(&previous, elevated),
                    retained(&next, elevated),
                    Curve2::from(LineSeg2::try_new(p(1, 1), p(-2, 1)).unwrap()),
                    Curve2::from(LineSeg2::try_new(p(-2, 1), p(-2, -1)).unwrap()),
                    Curve2::from(LineSeg2::try_new(p(-2, -1), p(-1, -1)).unwrap()),
                ])
                .unwrap();
                let boundary_path = if reversed {
                    crate::support::under(&policy, || boundary_path.reversed())
                        .unwrap()
                        .into_value()
                } else {
                    boundary_path
                };
                let region = crate::support::under(&policy, || {
                    CurveRegion2::try_from_boundary_paths(
                        &[boundary_path],
                        hypercurve::FillRule::EvenOdd,
                    )
                })
                .unwrap()
                .into_value();
                let fragments = region.boundary_loops()[0].curves();
                let corner = (0..fragments.len())
                    .find(|index| {
                        let is_rational_arc = |curve: &Curve2| {
                            curve.geometry().is_some()
                                && matches!(
                                    curve.family(),
                                    CurveFamily2::RationalQuadraticBezier
                                        | CurveFamily2::RationalBezier
                                )
                        };
                        is_rational_arc(&fragments[(index + fragments.len() - 1) % fragments.len()])
                            && is_rational_arc(&fragments[*index])
                    })
                    .expect("the retained circular pair stays adjacent in CurveRegion2");
                let trim = crate::support::under(&policy, || {
                    region.fillet_loop_vertex(
                        0,
                        corner,
                        &hypercurve::CurveFillet2::new(q(1, 2)),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap();
                let extended = crate::support::under(&policy, || region
                    .fillet_loop_vertex(
                        0,
                        corner,
                        &hypercurve::CurveFillet2::new(q(1, 2)),
                        CurveCornerMode2::TrimOrExtend))
                    .unwrap_or_else(|error| {
                        panic!(
                            "CurveRegion2 retained circular supports must extend: policy={policy:?}, elevated={elevated}, reversed={reversed}, error={error:?}"
                        )
                    });
                assert!({ extended.value.solutions().len() } > { trim.value.solutions().len() });
            }
        }
    }
}

#[test]
fn retained_circular_corner_recognition_uses_the_shared_approximate_terminal() {
    let native_arc = CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap();
    let conic = native_arc.rational_bezier_decomposition().unwrap().spans()[0].curve();
    let undecidable_zero = support::terminally_unresolved_zero();
    let control = Point2::new(
        conic.control().x() + undecidable_zero,
        conic.control().y().clone(),
    );
    let conic = RationalQuadraticBezier2::try_new(
        conic.start().clone(),
        control,
        conic.end().clone(),
        conic.start_weight().clone(),
        conic.control_weight().clone(),
        conic.end_weight().clone(),
    )
    .unwrap();
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
        Curve2::from(conic),
    ])
    .unwrap();

    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(q(1, 2)),
            CurveCornerMode2::TrimOnly)),
        Err(ExactCurveError::Blocked(blocker))
            if blocker.operation() == CurveOperation2::Fillet
                && blocker.family() == Some(CurveFamily2::RationalQuadraticBezier)
    ));
    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(q(1, 2)),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    {
        let solutions = approximate.value;
        assert_eq!(solutions.solutions().len(), 1);
    }
}

#[test]
fn exact_native_arc_fillet_solver_classifies_collapsed_and_coincident_offsets() {
    let line_arc = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
        Curve2::from(CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap()),
    ])
    .unwrap();
    let same_circle = CurvePath2::try_new(vec![
        Curve2::from(CircularArc2::try_from_center(p(0, -1), p(1, 0), p(0, 0), false).unwrap()),
        Curve2::from(CircularArc2::try_from_center(p(1, 0), p(0, 1), p(0, 0), false).unwrap()),
    ])
    .unwrap();
    let half_root_three = r(3).sqrt().unwrap() / r(2);
    let shared_corner = Point2::new(q(1, 2), half_root_three.unwrap());
    let disjoint_offsets = CurvePath2::try_new(vec![
        Curve2::from(
            CircularArc2::try_from_center(p(-1, 0), shared_corner.clone(), p(0, 0), true).unwrap(),
        ),
        Curve2::from(
            CircularArc2::try_from_center(shared_corner, p(2, 0), p(1, 0), false).unwrap(),
        ),
    ])
    .unwrap();
    let major_arcs = CurvePath2::try_new(vec![
        Curve2::from(CircularArc2::try_from_center(p(1, -1), p(0, 0), p(0, -1), true).unwrap()),
        Curve2::from(CircularArc2::try_from_center(p(0, 0), p(1, -1), p(1, 0), true).unwrap()),
    ])
    .unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        {
            let solutions = crate::support::under(&policy, || {
                line_arc.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(Real::one()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            assert_eq!(solutions.solutions().len(), 1);
        }
        assert_eq!(
            (crate::support::under(&policy, || same_circle.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(1, 2)),
                CurveCornerMode2::TrimOnly
            ))
            .unwrap()
            .into_value())
            .no_solution_reason(),
            Some(CurveCornerNoSolution2::DegenerateCandidate)
        );
        assert_eq!(
            (crate::support::under(&policy, || disjoint_offsets.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(3, 4)),
                CurveCornerMode2::TrimOrExtend
            ))
            .unwrap()
            .into_value())
            .no_solution_reason(),
            Some(CurveCornerNoSolution2::NoTangentCircle)
        );
        let fillets = {
            let solutions = crate::support::under(&policy, || {
                major_arcs.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let candidates = solutions.into_solutions();
            assert!(candidates.len() > 1, "expected multiple isolated fillets");
            candidates
        };
        assert_eq!(fillets.len(), 2);
        assert_ne!(
            fillets[0].curves()[1].geometry(),
            fillets[1].curves()[1].geometry()
        );
    }
}

#[test]
fn exact_native_arc_fillet_uses_only_the_shared_approximate_terminal() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
        Curve2::from(CircularArc2::try_from_center(p(0, 0), p(1, 1), p(1, 0), true).unwrap()),
    ])
    .unwrap();
    let undecidable_zero = support::terminally_unresolved_zero();
    let radius = Real::one() + undecidable_zero;
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(radius.clone()),
            CurveCornerMode2::TrimOnly)),
        Err(ExactCurveError::Blocked(blocker))
            if blocker.reason() == UncertaintyReason::RealSign
    ));
    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(radius),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    {
        let solutions = approximate.value;
        assert_eq!(solutions.solutions().len(), 1);
    }
}

#[test]
fn radical_line_image_fillets_preserve_retained_families() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::from_line_segment(
            LineSeg2::try_new(p(-1, -1), p(0, 0)).unwrap(),
        )),
        Curve2::from(QuadraticBezier2::from_line_segment(
            LineSeg2::try_new(p(0, 0), p(-1, 1)).unwrap(),
        )),
    ])
    .unwrap();
    let fillet = {
        let solutions = path
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(1, 2)),
                CurveCornerMode2::TrimOnly,
            )
            .unwrap();
        let mut candidates = solutions.into_solutions();
        assert_eq!(candidates.len(), 1, "expected one isolated fillet");
        candidates.pop().unwrap()
    };
    assert_eq!(fillet.curves()[0].family(), CurveFamily2::QuadraticBezier);
    assert_eq!(fillet.curves()[2].family(), CurveFamily2::QuadraticBezier);
    for distance_squared in [
        fillet.curves()[0]
            .end()
            .coordinates()
            .expect("native endpoint")
            .distance_squared(&p(0, 0)),
        fillet.curves()[2]
            .start()
            .coordinates()
            .expect("native endpoint")
            .distance_squared(&p(0, 0)),
    ] {
        assert!(matches!(
            distance_squared.certified_eq_until(&q(1, 4), -4096),
            CertifiedRealEquality::Equal { .. }
        ));
    }
    let Some(CurveGeometry2::CircularArc(arc)) = fillet.curves()[1].geometry() else {
        panic!("the radical line-image fillet must remain circular");
    };
    assert!(matches!(
        arc.radius_squared().certified_eq_until(&q(1, 4), -4096),
        CertifiedRealEquality::Equal { .. }
    ));
}

#[test]
fn line_corner_solvers_enumerate_extensions_deterministically() {
    let path = right_angle_line_path(4);
    let CurveCornerSolutions2::Multiple(chamfers) = path
        .chamfer_vertex_by_setbacks(1, r(1), r(1), CurveCornerMode2::TrimOrExtend)
        .unwrap()
    else {
        panic!("trim-or-extend setbacks must expose all four line-support choices");
    };
    assert_eq!(chamfers.len(), 4);
    assert_eq!(
        chamfers[0].curves()[0].end(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        chamfers[0].curves()[2].start(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );
    assert_eq!(
        chamfers[1].curves()[0].end(),
        hypercurve::CurvePoint2::from(p(-1, 0).clone())
    );
    assert_eq!(
        chamfers[1].curves()[2].start(),
        hypercurve::CurvePoint2::from(p(0, -1).clone())
    );
    assert_eq!(
        chamfers[2].curves()[0].end(),
        hypercurve::CurvePoint2::from(p(1, 0).clone())
    );
    assert_eq!(
        chamfers[2].curves()[2].start(),
        hypercurve::CurvePoint2::from(p(0, 1).clone())
    );
    assert_eq!(
        chamfers[3].curves()[0].end(),
        hypercurve::CurvePoint2::from(p(1, 0).clone())
    );
    assert_eq!(
        chamfers[3].curves()[2].start(),
        hypercurve::CurvePoint2::from(p(0, -1).clone())
    );

    let fillets = {
        let solutions = path
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(r(1)),
                CurveCornerMode2::TrimOrExtend,
            )
            .unwrap();
        let candidates = solutions.into_solutions();
        assert!(candidates.len() > 1, "expected multiple isolated fillets");
        candidates
    };
    assert_eq!(fillets.len(), 2);
    let centers_and_orientations = fillets
        .iter()
        .map(|fillet| {
            let Some(CurveGeometry2::CircularArc(arc)) = fillet.curves()[1].geometry() else {
                panic!("every line fillet candidate must contain one circular arc");
            };
            (arc.center().clone(), arc.is_clockwise())
        })
        .collect::<Vec<_>>();
    assert_eq!(
        centers_and_orientations,
        vec![(p(-1, 1), false), (p(1, -1), true)]
    );
}

#[test]
fn polynomial_chamfer_materializes_represented_incident_extension() {
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let path = CurvePath2::try_new(vec![
            Curve2::from(QuadraticBezier2::new(
                p(-1, 1),
                Point2::new(-q(1, 2), Real::zero()),
                p(0, 0),
            )),
            Curve2::from(LineSeg2::try_new(p(0, 0), p(0, 3)).unwrap()),
        ])
        .unwrap();
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let setback = Real::from(2_i8).sqrt().unwrap();
            let (previous_setback, next_setback) = if reversed {
                (Real::zero(), setback)
            } else {
                (setback, Real::zero())
            };
            let result = crate::support::under(&policy, || {
                path.chamfer_vertex_by_setbacks(
                    1,
                    previous_setback,
                    next_setback,
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("the represented polynomial extension must materialize");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let CurveCornerSolutions2::Unique(edited) = result.into_value() else {
                panic!("the represented polynomial extension must be unique");
            };
            let quadratic = edited
                .curves()
                .iter()
                .find(|curve| curve.family() == CurveFamily2::QuadraticBezier)
                .expect("the extended source family must be retained");
            assert!(
                quadratic.start() == hypercurve::CurvePoint2::from(p(1, 1).clone())
                    || quadratic.end() == hypercurve::CurvePoint2::from(p(1, 1).clone())
            );
        }
    }
}

#[test]
fn rational_chamfer_materializes_the_incident_projective_cell() {
    let half = q(1, 2);
    let quarter = q(1, 4);
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let path = CurvePath2::try_new(vec![
            Curve2::from(
                RationalBezier2::try_new(
                    vec![p(0, 0), Point2::new(half.clone(), Real::zero()), p(1, 1)],
                    vec![Real::one(), half.clone(), quarter.clone()],
                )
                .unwrap(),
            ),
            Curve2::from(LineSeg2::try_new(p(1, 1), p(1, 12)).unwrap()),
        ])
        .unwrap();
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let setback = Real::from(68_i8).sqrt().unwrap();
            let (previous_setback, next_setback) = if reversed {
                (Real::zero(), setback)
            } else {
                (setback, Real::zero())
            };
            let result = crate::support::under(&policy, || {
                path.chamfer_vertex_by_setbacks(
                    1,
                    previous_setback,
                    next_setback,
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("the incident rational cell must extend before its pole");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let CurveCornerSolutions2::Unique(edited) = result.into_value() else {
                panic!("the pole-partitioned rational extension must be unique");
            };
            let rational = edited
                .curves()
                .iter()
                .find(|curve| curve.family() == CurveFamily2::RationalBezier)
                .expect("the exact rational carrier must be retained");
            assert!(
                rational.start() == hypercurve::CurvePoint2::from(p(3, 9).clone())
                    || rational.end() == hypercurve::CurvePoint2::from(p(3, 9).clone())
            );
        }
    }
}

#[test]
fn spline_chamfer_materializes_only_the_incident_extension_cell() {
    let knots = || vec![r(0), r(0), r(0), r(1), r(1), r(1)];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let polynomial = crate::support::under(&policy, || {
            Curve2::try_polynomial_bspline(
                2,
                vec![p(-1, 1), Point2::new(-q(1, 2), Real::zero()), p(0, 0)],
                knots(),
            )
        })
        .unwrap()
        .into_value();
        let rational = crate::support::under(&policy, || {
            Curve2::try_nurbs(
                2,
                vec![p(0, 0), Point2::new(q(1, 2), Real::zero()), p(1, 1)],
                vec![Real::one(), q(1, 2), q(1, 4)],
                knots(),
            )
        })
        .unwrap()
        .into_value();
        for (source, line_end, setback, expected) in [
            (
                polynomial,
                p(0, 3),
                Real::from(2_i8).sqrt().unwrap(),
                p(1, 1),
            ),
            (
                rational,
                p(1, 12),
                Real::from(68_i8).sqrt().unwrap(),
                p(3, 9),
            ),
        ] {
            let family = source.family();
            let corner = source.end().clone();
            let path = CurvePath2::try_new(vec![
                source,
                Curve2::from(
                    LineSeg2::try_new(
                        (corner).coordinates().expect("native endpoint").clone(),
                        line_end,
                    )
                    .unwrap(),
                ),
            ])
            .unwrap();
            for reversed in [false, true] {
                let path = if reversed {
                    crate::support::under(&policy, || path.clone().reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path.clone()
                };
                let (previous_setback, next_setback) = if reversed {
                    (Real::zero(), setback.clone())
                } else {
                    (setback.clone(), Real::zero())
                };
                let result = crate::support::under(&policy, || path
                    .chamfer_vertex_by_setbacks(
                        1,
                        previous_setback,
                        next_setback,
                        CurveCornerMode2::TrimOrExtend))
                    .unwrap_or_else(|error| {
                        panic!(
                            "the spline incident cell must extend: policy={policy:?}, family={family:?}, reversed={reversed}, error={error:?}"
                        )
                    });
                assert_eq!(result.certainty, CurveCertainty::Certified);
                let CurveCornerSolutions2::Unique(edited) = result.into_value() else {
                    panic!("the spline extension chamfer must be unique");
                };
                assert_eq!(edited.curves().len(), 4);
                assert_eq!(
                    edited
                        .curves()
                        .iter()
                        .filter(|curve| curve.family() == family)
                        .count(),
                    1,
                );
                assert!(edited.curves().iter().any(|curve| {
                    curve.start() == hypercurve::CurvePoint2::from(expected.clone())
                        || curve.end() == hypercurve::CurvePoint2::from(expected.clone())
                }));
            }
        }
    }
}

#[test]
fn line_parabola_mixed_exact_algebraic_fillet_is_an_exact_open_path() {
    let half = q(1, 2);
    let radius = q(299, 125);
    let line_direction = Point2::new(q(38280, 91901), q(83549, 91901));
    let corner = p(1, 1);
    let line_end = Point2::new(
        corner.x() + line_direction.x(),
        corner.y() + line_direction.y(),
    );
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let path = CurvePath2::try_new(vec![
            Curve2::from(QuadraticBezier2::new(
                p(0, 0),
                Point2::new(half.clone(), Real::zero()),
                corner.clone(),
            )),
            Curve2::from(LineSeg2::try_new(corner.clone(), line_end.clone()).unwrap()),
        ])
        .unwrap();
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let result = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("selected fillets remain representable as open paths");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let candidates = assert_fillet_candidates(result.value, &path, &policy);
            assert!(candidates.iter().any(|candidate| {
                candidate
                    .curves()
                    .iter()
                    .any(|curve| curve.geometry().is_none())
            }));
        }
    }
}

#[test]
fn line_corner_solvers_report_exact_no_solution_and_invalid_options() {
    let path = right_angle_line_path(4);
    assert_eq!(
        (crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(r(5)),
            CurveCornerMode2::TrimOnly
        ))
        .unwrap()
        .into_value())
        .no_solution_reason(),
        Some(CurveCornerNoSolution2::OutsideTrimDomain)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(
                1,
                Real::zero(),
                Real::zero(),
                CurveCornerMode2::TrimOnly
            ))
        .unwrap()
        .into_value(),
        CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::ZeroDesignValue)
    );
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(-Real::one()),
            CurveCornerMode2::TrimOnly
        )),
        Err(ExactCurveError::Invalid {
            operation: CurveOperation2::Fillet,
            cause: CurveError::InvalidCornerOptions,
            ..
        })
    ));
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(
                1,
                -Real::one(),
                Real::one(),
                CurveCornerMode2::TrimOnly
            )),
        Err(ExactCurveError::Invalid {
            operation: CurveOperation2::Chamfer,
            cause: CurveError::InvalidCornerOptions,
            ..
        })
    ));
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(1, r(4), Real::one(), CurveCornerMode2::TrimOnly))
        .unwrap()
        .into_value(),
        CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::OutsideTrimDomain)
    );
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(
                0,
                Real::one(),
                Real::one(),
                CurveCornerMode2::TrimOnly
            )),
        Err(ExactCurveError::Invalid {
            operation: CurveOperation2::Chamfer,
            cause: CurveError::OpenCurvePath,
            ..
        })
    ));

    let tangent_path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 0), p(4, 0)).unwrap()),
    ])
    .unwrap();
    assert_eq!(
        (crate::support::under(&PredicatePolicy::STRICT, || tangent_path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::one()),
            CurveCornerMode2::TrimOrExtend
        ))
        .unwrap()
        .into_value())
        .no_solution_reason(),
        Some(CurveCornerNoSolution2::ParallelTangents)
    );

    let backtracking = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-2, 0), p(0, 0)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 0), p(-2, 0)).unwrap()),
    ])
    .unwrap();
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || backtracking
            .chamfer_vertex_by_setbacks(
                1,
                Real::one(),
                Real::one(),
                CurveCornerMode2::TrimOnly
            ))
        .unwrap()
        .into_value(),
        CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::DegenerateCandidate)
    );
}

#[test]
fn automatic_corner_solver_reconstructs_selected_pairs() {
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(
            Point2::new(-q(4, 5), q(3, 5)),
            Point2::new(-q(4, 5), q(1, 10)),
            p(0, 0),
        )),
        Curve2::from(QuadraticBezier2::new(p(0, 0), p(2, 1), p(0, 2))),
    ])
    .unwrap();
    let result = crate::support::under(&PredicatePolicy::STRICT, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::one()),
            CurveCornerMode2::TrimOnly,
        )
    })
    .expect("the selected Bezier pair fillet remains an exact path");
    assert_eq!(result.certainty, CurveCertainty::Certified);
    assert_fillet_candidates(result.value, &path, &PredicatePolicy::STRICT);

    let spline = CurvePath2::try_new(vec![
        crate::support::under(&PredicatePolicy::STRICT, || {
            Curve2::try_polynomial_bspline(
                2,
                vec![p(-4, 0), p(-2, 1), p(0, 0)],
                vec![r(0), r(0), r(0), r(1), r(1), r(1)],
            )
        })
        .unwrap()
        .into_value(),
        Curve2::from(LineSeg2::try_new(p(0, 0), p(0, 4)).unwrap()),
    ])
    .unwrap();
    let result = crate::support::under(&PredicatePolicy::STRICT, || {
        spline.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::one()),
            CurveCornerMode2::TrimOnly,
        )
    })
    .expect("the selected spline fillet remains an exact path");
    assert_eq!(result.certainty, CurveCertainty::Certified);
    assert_fillet_candidates(result.value, &spline, &PredicatePolicy::STRICT);
    assert_eq!(
        (crate::support::under(&PredicatePolicy::STRICT, || spline.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::zero()),
            CurveCornerMode2::TrimOrExtend
        ))
        .unwrap()
        .into_value())
        .no_solution_reason(),
        Some(CurveCornerNoSolution2::ZeroDesignValue)
    );
    assert_eq!(
        crate::support::under(&PredicatePolicy::STRICT, || spline
            .chamfer_vertex_by_setbacks(
                1,
                Real::zero(),
                Real::zero(),
                CurveCornerMode2::TrimOrExtend
            ))
        .unwrap()
        .into_value(),
        CurveCornerSolutions2::NoSolution(CurveCornerNoSolution2::ZeroDesignValue)
    );

    let algebraic_cut = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
        Curve2::from(QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2))),
    ])
    .unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let result = crate::support::under(&policy, || {
            algebraic_cut.chamfer_vertex_by_setbacks(
                1,
                Real::one(),
                Real::one(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .unwrap();
        assert_eq!(result.certainty, CurveCertainty::Certified);
        let CurveCornerSolutions2::Unique(result) = result.value else {
            panic!("the selected chamfer must remain a public exact path");
        };
        assert!(
            result
                .curves()
                .iter()
                .any(|curve| curve.geometry().is_none())
        );
        for pair in result.curves().windows(2) {
            let equality = crate::support::under_outcome_classification(&policy, || {
                pair[0].end().coincides_with(&pair[1].start())
            });
            assert_eq!(equality.certainty, CurveCertainty::Certified);
            assert_eq!(equality.value, Classification::Decided(true));
        }
    }
}

#[test]
fn represented_line_bezier_corners_use_the_general_incidence_kernel() {
    let conic = RationalQuadraticBezier2::try_new(
        p(0, 0),
        p(0, 1),
        p(1, 2),
        Real::one(),
        Real::one(),
        Real::one(),
    )
    .unwrap();
    let carriers = [
        (
            CurveFamily2::QuadraticBezier,
            Curve2::from(QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2))),
        ),
        (
            CurveFamily2::CubicBezier,
            Curve2::from(CubicBezier2::new(
                p(0, 0),
                Point2::new(Real::zero(), q(2, 3)),
                Point2::new(q(1, 3), q(4, 3)),
                p(1, 2),
            )),
        ),
        (
            CurveFamily2::RationalQuadraticBezier,
            Curve2::from(conic.clone()),
        ),
        (
            CurveFamily2::RationalBezier,
            Curve2::from(RationalBezier2::from(conic).elevated_to_degree(5).unwrap()),
        ),
    ];
    let expected_center = Point2::new(-q(39, 16), q(15, 4));
    let next_setback = (r(657).sqrt().unwrap() / r(16)).unwrap();
    for (family, carrier) in carriers {
        let path = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
            carrier,
        ])
        .unwrap();
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            let solutions = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(15, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                candidate.curves()[2].family() == family
                    && fillet
                        .center()
                        .distance_squared(&expected_center)
                        .certified_eq_until(&Real::zero(), -4096)
                        .as_bool()
                        == Some(true)
            };
            let solutions = solutions;
            assert!(solutions.solutions().iter().any(has_expected));

            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                path.chamfer_vertex_by_setbacks(
                    1,
                    Real::one(),
                    next_setback.clone(),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value() else {
                panic!("the represented quadratic circle contact must define one chamfer");
            };
            assert_eq!(
                chamfered.curves()[0].end(),
                hypercurve::CurvePoint2::from(p(-1, 0).clone())
            );
            assert_eq!(
                chamfered.curves()[2].start(),
                hypercurve::CurvePoint2::from(Point2::new(q(9, 16), q(3, 2)).clone())
            );
            assert_eq!(chamfered.curves()[2].family(), family);

            let reversed = crate::support::under(&policy, || path.clone().reversed())
                .unwrap()
                .into_value();
            let reversed_solutions = crate::support::under(&policy, || {
                reversed.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(15, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let reversed_has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                candidate.curves()[0].family() == family
                    && candidate.curves()[2].family() == CurveFamily2::Line
                    && fillet
                        .center()
                        .distance_squared(&expected_center)
                        .certified_eq_until(&Real::zero(), -4096)
                        .as_bool()
                        == Some(true)
            };
            let solutions = reversed_solutions;
            assert!(solutions.solutions().iter().any(reversed_has_expected));

            let CurveCornerSolutions2::Unique(reversed_chamfered) =
                crate::support::under(&policy, || {
                    reversed.chamfer_vertex_by_setbacks(
                        1,
                        next_setback.clone(),
                        Real::one(),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap()
                .into_value()
            else {
                panic!("the reversed represented curve/line chamfer must be unique");
            };
            assert_eq!(reversed_chamfered.curves()[0].family(), family);
            assert_eq!(
                reversed_chamfered.curves()[0].end(),
                hypercurve::CurvePoint2::from(Point2::new(q(9, 16), q(3, 2)).clone())
            );
            assert_eq!(
                reversed_chamfered.curves()[2].start(),
                hypercurve::CurvePoint2::from(p(-1, 0).clone())
            );
        }
    }
}

#[test]
fn spline_incident_spans_reuse_represented_bezier_corner_incidence() {
    let controls = vec![p(0, 0), p(0, 1), p(1, 2), p(2, 1), p(4, 2)];
    let knots = vec![r(2), r(2), r(2), r(5), r(5), r(9), r(9), r(9)];
    let carriers = [
        (
            CurveFamily2::PolynomialBSpline,
            Curve2::try_polynomial_bspline(2, controls.clone(), knots.clone()).unwrap(),
        ),
        (
            CurveFamily2::Nurbs,
            Curve2::try_nurbs(2, controls, vec![Real::one(); 5], knots).unwrap(),
        ),
    ];
    let expected_cut = Point2::new(q(9, 16), q(3, 2));
    let expected_public_parameter = q(17, 4);
    let expected_reversed_parameter = q(27, 4);
    let next_setback = (r(657).sqrt().unwrap() / r(16)).unwrap();
    let expected_center = Point2::new(-q(39, 16), q(15, 4));

    for (family, carrier) in carriers {
        let path = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
            carrier,
        ])
        .unwrap();
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
                path.chamfer_vertex_by_setbacks(
                    1,
                    Real::one(),
                    next_setback.clone(),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value() else {
                panic!("the incident {family:?} span must define one exact chamfer");
            };
            let trimmed = &chamfered.curves()[2];
            assert_eq!(trimmed.family(), family);
            assert_eq!(
                trimmed.start(),
                hypercurve::CurvePoint2::from(expected_cut.clone())
            );
            assert_eq!(
                trimmed
                    .parameter_domain()
                    .start()
                    .scalar()
                    .expect("native parameter"),
                &expected_public_parameter
            );
            assert_eq!(
                trimmed
                    .parameter_domain()
                    .end()
                    .scalar()
                    .expect("native parameter"),
                &r(9)
            );

            let fillets = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(15, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                candidate.curves()[2].family() == family
                    && candidate.curves()[2].start()
                        == hypercurve::CurvePoint2::from(expected_cut.clone())
                    && fillet
                        .center()
                        .distance_squared(&expected_center)
                        .certified_eq_until(&Real::zero(), -4096)
                        .as_bool()
                        == Some(true)
            };
            let solutions = fillets;
            assert!(solutions.solutions().iter().any(has_expected));

            let reversed = crate::support::under(&policy, || path.clone().reversed())
                .unwrap()
                .into_value();
            let CurveCornerSolutions2::Unique(reversed_chamfered) =
                crate::support::under(&policy, || {
                    reversed.chamfer_vertex_by_setbacks(
                        1,
                        next_setback.clone(),
                        Real::one(),
                        CurveCornerMode2::TrimOnly,
                    )
                })
                .unwrap()
                .into_value()
            else {
                panic!("the reversed incident {family:?} span must remain exact");
            };
            let reversed_trimmed = &reversed_chamfered.curves()[0];
            assert_eq!(reversed_trimmed.family(), family);
            assert_eq!(
                reversed_trimmed.end(),
                hypercurve::CurvePoint2::from(expected_cut.clone())
            );
            assert_eq!(
                reversed_trimmed
                    .parameter_domain()
                    .start()
                    .scalar()
                    .expect("native parameter"),
                &r(2)
            );
            assert_eq!(
                reversed_trimmed
                    .parameter_domain()
                    .end()
                    .scalar()
                    .expect("native parameter"),
                &expected_reversed_parameter
            );
        }
    }
}

#[test]
fn spline_incident_span_pairs_reuse_exact_ph_fillet_fast_path() {
    let make_spline =
        |family: CurveFamily2, controls: Vec<Point2>, start: i32, end: i32| match family {
            CurveFamily2::PolynomialBSpline => Curve2::try_polynomial_bspline(
                3,
                controls,
                vec![r(start); 4]
                    .into_iter()
                    .chain(vec![r(end); 4])
                    .collect(),
            )
            .unwrap(),
            CurveFamily2::Nurbs => Curve2::try_nurbs(
                3,
                controls,
                vec![Real::one(); 4],
                vec![r(start); 4]
                    .into_iter()
                    .chain(vec![r(end); 4])
                    .collect(),
            )
            .unwrap(),
            _ => unreachable!(),
        };
    let previous_controls = vec![
        p(-4, 0),
        Point2::new(-q(8, 3), Real::zero()),
        Point2::new(-q(4, 3), Real::zero()),
        p(0, 0),
    ];
    let next_controls = vec![
        p(0, 0),
        Point2::new(Real::zero(), q(4, 3)),
        Point2::new(Real::zero(), q(8, 3)),
        p(0, 4),
    ];

    for previous_family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
        for next_family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
            let path = CurvePath2::try_new(vec![
                make_spline(previous_family, previous_controls.clone(), 2, 5),
                make_spline(next_family, next_controls.clone(), 7, 11),
            ])
            .unwrap();
            for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
                let filleted = {
                    let solutions = crate::support::under(&policy, || {
                        path.fillet_vertex(
                            1,
                            &hypercurve::CurveFillet2::new(Real::one()),
                            CurveCornerMode2::TrimOnly,
                        )
                    })
                    .unwrap()
                    .into_value();
                    let mut candidates = solutions.into_solutions();
                    assert_eq!(candidates.len(), 1, "expected one isolated fillet");
                    candidates.pop().unwrap()
                };
                assert_eq!(filleted.curves()[0].family(), previous_family);
                assert_eq!(
                    filleted.curves()[0].end(),
                    hypercurve::CurvePoint2::from(p(-1, 0).clone())
                );
                assert_eq!(
                    filleted.curves()[0]
                        .parameter_domain()
                        .end()
                        .scalar()
                        .expect("native parameter"),
                    &q(17, 4)
                );
                assert_eq!(filleted.curves()[2].family(), next_family);
                assert_eq!(
                    filleted.curves()[2].start(),
                    hypercurve::CurvePoint2::from(p(0, 1).clone())
                );
                assert_eq!(
                    filleted.curves()[2]
                        .parameter_domain()
                        .start()
                        .scalar()
                        .expect("native parameter"),
                    &r(8)
                );
                let Some(CurveGeometry2::CircularArc(fillet)) = filleted.curves()[1].geometry()
                else {
                    panic!("the exact PH-span fillet must remain circular");
                };
                assert_eq!(fillet.center(), &p(-1, 1));
            }
        }
    }
}

#[test]
fn represented_bezier_pairs_use_independent_chamfer_and_exact_ph_fillet_routes() {
    let next = QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2));
    let previous = QuadraticBezier2::new(p(-1, 2), p(0, 1), p(0, 0));
    let chamfer_path =
        CurvePath2::try_new(vec![Curve2::from(previous), Curve2::from(next)]).unwrap();
    let setback = (r(657).sqrt().unwrap() / r(16)).unwrap();

    let cubic_line_path = CurvePath2::try_new(vec![
        Curve2::from(CubicBezier2::new(
            p(-4, 0),
            Point2::new(-q(8, 3), Real::zero()),
            Point2::new(-q(4, 3), Real::zero()),
            p(0, 0),
        )),
        Curve2::from(CubicBezier2::new(
            p(0, 0),
            Point2::new(Real::zero(), q(4, 3)),
            Point2::new(Real::zero(), q(8, 3)),
            p(0, 4),
        )),
    ])
    .unwrap();

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&policy, || {
            chamfer_path.chamfer_vertex_by_setbacks(
                1,
                setback.clone(),
                setback.clone(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .unwrap()
        .into_value() else {
            panic!("the represented quadratic pair must define one chamfer");
        };
        assert_eq!(
            chamfered.curves()[0].end(),
            hypercurve::CurvePoint2::from(Point2::new(-q(9, 16), q(3, 2)).clone())
        );
        assert_eq!(
            chamfered.curves()[2].start(),
            hypercurve::CurvePoint2::from(Point2::new(q(9, 16), q(3, 2)).clone())
        );
        assert_eq!(
            chamfered.curves()[0].family(),
            CurveFamily2::QuadraticBezier
        );
        assert_eq!(
            chamfered.curves()[2].family(),
            CurveFamily2::QuadraticBezier
        );

        let filleted = {
            let solutions = crate::support::under(&policy, || {
                cubic_line_path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(Real::one()),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let mut candidates = solutions.into_solutions();
            assert_eq!(candidates.len(), 1, "expected one isolated fillet");
            candidates.pop().unwrap()
        };
        assert_eq!(
            filleted.curves()[0].end(),
            hypercurve::CurvePoint2::from(p(-1, 0).clone())
        );
        assert_eq!(
            filleted.curves()[2].start(),
            hypercurve::CurvePoint2::from(p(0, 1).clone())
        );
        assert_eq!(filleted.curves()[0].family(), CurveFamily2::CubicBezier);
        assert_eq!(filleted.curves()[2].family(), CurveFamily2::CubicBezier);
        let Some(CurveGeometry2::CircularArc(fillet)) = filleted.curves()[1].geometry() else {
            panic!("the exact PH pair must insert a circular fillet");
        };
        assert_eq!(fillet.center(), &p(-1, 1));
    }
}

#[test]
fn direct_bezier_pair_fillet_retains_both_incident_extensions() {
    // P(t) = (t, t^2) and
    // Q(s) = (1, 1) + (-31/65, -86/325)s + (-48/65, -43/325)s^2.
    // Their left parallels at distance 1/2 meet at the exact parameters
    // t = 6/5 and s = -1, outside both authored spans but inside their
    // endpoint-adjacent regular cells.
    let previous_cut = Point2::new(q(6, 5), q(36, 25));
    let next_cut = Point2::new(q(48, 65), q(368, 325));
    let expected_center = Point2::new(q(48, 65), q(1061, 650));
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(
            p(0, 0),
            Point2::new(q(1, 2), Real::zero()),
            p(1, 1),
        )),
        Curve2::from(QuadraticBezier2::new(
            p(1, 1),
            Point2::new(q(99, 130), q(282, 325)),
            Point2::new(-q(14, 65), q(196, 325)),
        )),
    ])
    .unwrap();

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let result = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(1, 2)),
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("both regular Bezier incident extensions must be solved exactly");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let has_expected = |candidate: &CurvePath2| {
                let curves = candidate.curves();
                if curves.len() < 3 {
                    return false;
                }
                let (expected_previous, expected_next) = if reversed {
                    (&next_cut, &previous_cut)
                } else {
                    (&previous_cut, &next_cut)
                };
                for (actual, expected) in [
                    (curves[0].end(), expected_previous),
                    (curves.last().unwrap().start(), expected_next),
                ] {
                    let same = crate::support::under_outcome_classification(&policy, || {
                        actual.coincides_with(&expected.clone().into())
                    });
                    assert_eq!(same.certainty, CurveCertainty::Certified);
                    if same.value != Classification::Decided(true) {
                        return false;
                    }
                }
                let expected = Curve2::from(
                    CircularArc2::try_from_center(
                        expected_previous.clone(),
                        expected_next.clone(),
                        expected_center.clone(),
                        reversed,
                    )
                    .unwrap(),
                );
                let compare = |left: &hypercurve::CurveParameter2,
                               right: &hypercurve::CurveParameter2| {
                    let order =
                        crate::support::under_outcome_classified(&policy, || left.compare(right))
                            .unwrap();
                    assert_eq!(order.certainty, CurveCertainty::Certified);
                    match order.value {
                        Classification::Decided(order) => order,
                        Classification::Uncertain(reason) => {
                            panic!("circle coverage order: {reason:?}")
                        }
                    }
                };
                let ascending = |range: &hypercurve::CurveParameterRange2| {
                    let (start, end) = (range.start().clone(), range.end().clone());
                    if compare(&start, &end).is_gt() {
                        (end, start)
                    } else {
                        (start, end)
                    }
                };
                // A major arc may use retained circles or rational quadratic charts.
                // Certify the complete trace against an independent exact arc,
                // including its center, finite sweep, and traversal direction.
                for piece in &curves[1..curves.len() - 1] {
                    let overlap =
                        crate::support::under(&policy, || piece.intersect_curve(&expected))
                            .unwrap();
                    assert_eq!(overlap.certainty, CurveCertainty::Certified);
                    assert!(overlap.value.is_complete());
                    let mut ranges = overlap
                        .value
                        .overlaps()
                        .iter()
                        .map(|overlap| {
                            assert_eq!(overlap.first_span_index(), 0);
                            assert!(overlap.includes_start() && overlap.includes_end());
                            assert_eq!(
                                overlap.orientation(),
                                hypercurve::CurveOverlapOrientation2::Same
                            );
                            ascending(overlap.first_range())
                        })
                        .collect::<Vec<_>>();
                    ranges.sort_by(|left, right| compare(&left.0, &right.0));
                    let (mut cursor, end) = ascending(piece.parameter_domain());
                    for (lower, upper) in ranges {
                        if compare(&lower, &cursor).is_gt() {
                            return false;
                        }
                        if compare(&upper, &cursor).is_gt() {
                            cursor = upper;
                        }
                    }
                    if !compare(&cursor, &end).is_eq() {
                        return false;
                    }
                }
                true
            };
            let solutions = result.into_value();
            assert!(solutions.solutions().iter().any(has_expected));
        }
    }
}

#[test]
fn spline_line_fillet_preserves_the_authored_spline_and_adds_its_incident_cell() {
    let knots = || vec![r(0), r(0), r(0), r(1), r(1), r(1)];
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
            let spline = match family {
                CurveFamily2::PolynomialBSpline => crate::support::under(&policy, || {
                    Curve2::try_polynomial_bspline(2, vec![p(-2, 0), p(-1, 0), p(0, 0)], knots())
                }),
                CurveFamily2::Nurbs => crate::support::under(&policy, || {
                    Curve2::try_nurbs(
                        2,
                        vec![p(-2, 0), p(-1, 0), p(0, 0)],
                        vec![Real::one(); 3],
                        knots(),
                    )
                }),
                _ => unreachable!(),
            }
            .unwrap()
            .into_value();
            let path = CurvePath2::try_new(vec![
                spline,
                Curve2::from(LineSeg2::try_new(p(0, 0), p(0, 2)).unwrap()),
            ])
            .unwrap();
            for reversed in [false, true] {
                let path = if reversed {
                    crate::support::under(&policy, || path.clone().reversed())
                        .unwrap()
                        .into_value()
                } else {
                    path.clone()
                };
                let result = crate::support::under(&policy, || path
                    .fillet_vertex(
                        1,
                        &hypercurve::CurveFillet2::new(Real::one()),
                        CurveCornerMode2::TrimOrExtend))
                    .unwrap_or_else(|error| {
                        panic!(
                            "the spline incident cell must fillet: policy={policy:?}, family={family:?}, reversed={reversed}, error={error:?}"
                        )
                    });
                assert_eq!(result.certainty, CurveCertainty::Certified);
                let has_expected = |candidate: &CurvePath2| {
                    candidate.curves().len() == 4
                        && candidate
                            .curves()
                            .iter()
                            .filter(|curve| curve.family() == family)
                            .count()
                            == 1
                        && candidate.curves().iter().any(|curve| {
                            matches!(
                                curve.geometry(),
                                Some(CurveGeometry2::CircularArc(arc)) if arc.center() == &p(1, -1)
                            )
                        })
                        && candidate.curves().iter().any(|curve| {
                            curve.start() == hypercurve::CurvePoint2::from(p(1, 0).clone())
                                || curve.end() == hypercurve::CurvePoint2::from(p(1, 0).clone())
                        })
                        && candidate.curves().iter().any(|curve| {
                            curve.start() == hypercurve::CurvePoint2::from(p(0, -1).clone())
                                || curve.end() == hypercurve::CurvePoint2::from(p(0, -1).clone())
                        })
                };
                let solutions = result.into_value();
                assert!(solutions.solutions().iter().any(has_expected));
            }
        }
    }
}

#[test]
fn independently_parameterized_bezier_continuation_is_an_incident_fillet_component() {
    // These are adjacent parameter spans of the same non-PH parabola:
    // P(t)=(t,t^2), Q(s)=(1+s,(1+s)^2). Their authored domains share only
    // the seam P(1)=Q(0), while their analytic continuations satisfy
    // s=t-1. Equal selected offsets therefore provide infinitely many
    // projective fillet centers. Retain that contact family, but reject its
    // coincident cuts during selection; the component must not disappear
    // when the squared pair equations are saturated.
    let path = CurvePath2::try_new(vec![
        Curve2::from(QuadraticBezier2::new(
            p(0, 0),
            Point2::new(q(1, 2), Real::zero()),
            p(1, 1),
        )),
        Curve2::from(QuadraticBezier2::new(
            p(1, 1),
            Point2::new(q(3, 2), r(2)),
            p(2, 4),
        )),
    ])
    .unwrap();

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let mut request = hypercurve::CurveFillet2::new(q(1, 2));
            assert!(matches!(
                crate::support::under(&policy, || path.fillet_vertex(
                    1,
                    &request,
                    CurveCornerMode2::TrimOrExtend
                )),
                Err(ExactCurveError::Invalid {
                    cause: CurveError::FilletConstraintRequired,
                    ..
                })
            ));
            // Exact contact constraints select each continuation without ever
            // publishing the coincident cuts as a zero-length inserted arc.
            for (previous, next) in [(q(1, 2), -q(1, 2)), (q(3, 2), q(1, 2)), (q(1, 2), q(1, 2))] {
                request.contacts = [
                    Some(hypercurve::CurveFilletContact2::Parameter(previous.into())),
                    Some(hypercurve::CurveFilletContact2::Parameter(next.into())),
                ];
                let selected = crate::support::under(&policy, || {
                    path.fillet_vertex(1, &request, CurveCornerMode2::TrimOrExtend)
                })
                .unwrap();
                assert_eq!(selected.certainty, CurveCertainty::Certified);
                assert!(selected.value.solutions().is_empty());
            }
        }
    }
}

#[test]
fn same_bezier_support_fillet_removes_the_projective_parameter_diagonal() {
    // This regular closed cubic has P(2) = (22/3, -4/3) with tangent
    // (13, 0), and P(-1) = (4/3, -22/3) with tangent (0, 13). Its right
    // parallel at distance 6 therefore has the off-diagonal self-contact
    // (2, -1) at (22/3, -22/3). The coincident t=s component must be divided
    // out before the two incident domains are projected.
    let previous_cut = Point2::new(q(22, 3), -q(4, 3));
    let next_cut = Point2::new(q(4, 3), -q(22, 3));
    let expected_center = Point2::new(q(22, 3), -q(22, 3));
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(-q(5, 9), q(8, 9)),
        Point2::new(-q(8, 9), q(5, 9)),
        p(0, 0),
    );
    let path =
        CurvePath2::try_new(vec![Curve2::from(source.clone()), Curve2::from(source)]).unwrap();

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let result = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(r(6)),
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("the structural diagonal must leave complete off-diagonal contacts");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                let (expected_previous, expected_next) = if reversed {
                    (&next_cut, &previous_cut)
                } else {
                    (&previous_cut, &next_cut)
                };
                candidate.curves()[0].end()
                    == hypercurve::CurvePoint2::from((*(expected_previous)).clone())
                    && candidate.curves()[2].start()
                        == hypercurve::CurvePoint2::from((*(expected_next)).clone())
                    && fillet.center() == &expected_center
            };
            let solutions = result.into_value();
            assert!(solutions.solutions().iter().any(has_expected));
        }
    }
}

#[test]
fn same_ph_bezier_support_fillet_reuses_rational_projective_self_contact() {
    // With x=t-1/2 and b=sqrt(3)/6, this closed PH cubic is
    // P(x)=(x^3/3-x/12, b(x^2-1/4)); its hodograph is
    // (x^2-b^2, 2bx) and its everywhere-positive speed is x^2+b^2.
    // At signed left distance 13*sqrt(3)/48, the exact rational parallel has
    // the off-diagonal contact x=(1,-1), hence t=(3/2,-1/2), at
    // (0,17*sqrt(3)/48). The finite PH injectivity fast path must not discard
    // this exterior pair.
    let sqrt_three = r(3).sqrt().unwrap();
    let source = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(1, 18), -(&sqrt_three / r(18)).unwrap()),
        Point2::new(-q(1, 18), -(&sqrt_three / r(18)).unwrap()),
        p(0, 0),
    );
    let radius = (&r(13) * &sqrt_three / r(48)).unwrap();
    let previous_cut = Point2::new(q(1, 4), (&sqrt_three / r(8)).unwrap());
    let next_cut = Point2::new(-q(1, 4), (&sqrt_three / r(8)).unwrap());
    let expected_center = Point2::new(Real::zero(), (&r(17) * &sqrt_three / r(48)).unwrap());
    assert!(matches!(
        crate::support::under_classified_result(&PredicatePolicy::STRICT, || source
            .parallel_left(radius.clone())
            .unwrap()
            .exact_pythagorean_hodograph_offset())
        .unwrap(),
        Classification::Decided(Some(_))
    ));
    let path =
        CurvePath2::try_new(vec![Curve2::from(source.clone()), Curve2::from(source)]).unwrap();

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        for reversed in [false, true] {
            let path = if reversed {
                crate::support::under(&policy, || path.clone().reversed())
                    .unwrap()
                    .into_value()
            } else {
                path.clone()
            };
            let result = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(radius.clone()),
                    CurveCornerMode2::TrimOrExtend,
                )
            })
            .expect("the exact PH parallel must retain its exterior self-contact");
            assert_eq!(result.certainty, CurveCertainty::Certified);
            let has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                let (expected_previous, expected_next) = if reversed {
                    (&next_cut, &previous_cut)
                } else {
                    (&previous_cut, &next_cut)
                };
                candidate.curves()[0].end()
                    == hypercurve::CurvePoint2::from((*(expected_previous)).clone())
                    && candidate.curves()[2].start()
                        == hypercurve::CurvePoint2::from((*(expected_next)).clone())
                    && fillet.center() == &expected_center
            };
            let solutions = result.into_value();
            assert!(solutions.solutions().iter().any(has_expected));
        }
    }
}

#[test]
fn represented_arc_bezier_fillets_use_circle_incidence() {
    let source_center = Point2::new(-q(7, 16), q(207, 512));
    let source_start = Point2::new(-q(7, 16), -q(49, 256));
    let previous =
        CircularArc2::try_from_center(source_start, p(0, 0), source_center, true).unwrap();
    let conic = RationalQuadraticBezier2::try_new(
        p(0, 0),
        p(0, 1),
        p(1, 2),
        Real::one(),
        Real::one(),
        Real::one(),
    )
    .unwrap();
    let carriers = [
        (
            CurveFamily2::QuadraticBezier,
            Curve2::from(QuadraticBezier2::new(p(0, 0), p(0, 1), p(1, 2))),
        ),
        (
            CurveFamily2::CubicBezier,
            Curve2::from(CubicBezier2::new(
                p(0, 0),
                Point2::new(Real::zero(), q(2, 3)),
                Point2::new(q(1, 3), q(4, 3)),
                p(1, 2),
            )),
        ),
        (
            CurveFamily2::RationalQuadraticBezier,
            Curve2::from(conic.clone()),
        ),
        (
            CurveFamily2::RationalBezier,
            Curve2::from(RationalBezier2::from(conic).elevated_to_degree(5).unwrap()),
        ),
    ];
    let expected_center = Point2::new(-q(7, 16), q(9, 4));

    for (family, carrier) in carriers {
        let path = CurvePath2::try_new(vec![Curve2::from(previous.clone()), carrier]).unwrap();
        for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
            let solutions = crate::support::under(&policy, || {
                path.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(5, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                fillet
                    .center()
                    .distance_squared(&expected_center)
                    .certified_eq_until(&Real::zero(), -4096)
                    .as_bool()
                    == Some(true)
                    && candidate.curves()[0].family() == CurveFamily2::CircularArc
                    && candidate.curves()[2].family() == family
            };
            let solutions = solutions;
            assert!(solutions.solutions().iter().any(has_expected));

            let reversed = crate::support::under(&policy, || path.clone().reversed())
                .unwrap()
                .into_value();
            let reversed_solutions = crate::support::under(&policy, || {
                reversed.fillet_vertex(
                    1,
                    &hypercurve::CurveFillet2::new(q(5, 4)),
                    CurveCornerMode2::TrimOnly,
                )
            })
            .unwrap()
            .into_value();
            let reversed_has_expected = |candidate: &CurvePath2| {
                let Some(CurveGeometry2::CircularArc(fillet)) = candidate.curves()[1].geometry()
                else {
                    return false;
                };
                candidate.curves()[0].family() == family
                    && candidate.curves()[2].family() == CurveFamily2::CircularArc
                    && fillet
                        .center()
                        .distance_squared(&expected_center)
                        .certified_eq_until(&Real::zero(), -4096)
                        .as_bool()
                        == Some(true)
            };
            let solutions = reversed_solutions;
            assert!(solutions.solutions().iter().any(reversed_has_expected));
        }
    }
}

#[test]
fn represented_bezier_chamfer_retains_more_than_two_exact_cuts() {
    // This regular cubic meets the unit circle about its start at t = 1/4,
    // 1/2, and 3/4. The remaining cubic factor of the circle equation has no
    // root in [0, 1], so these are the complete cuts rather than samples.
    let cubic = CubicBezier2::new(
        p(0, 0),
        Point2::new(q(266, 195), q(200, 117)),
        Point2::new(q(28, 65), q(272, 585)),
        Point2::new(-q(30, 13), q(56, 65)),
    );
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-1, 0), p(0, 0)).unwrap()),
        Curve2::from(cubic),
    ])
    .unwrap();
    let expected = [
        Point2::new(q(3, 5), q(4, 5)),
        Point2::new(q(5, 13), q(12, 13)),
        Point2::new(-q(3, 5), q(4, 5)),
    ];

    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        let CurveCornerSolutions2::Multiple(candidates) = crate::support::under(&policy, || {
            path.chamfer_vertex_by_setbacks(
                1,
                Real::zero(),
                Real::one(),
                CurveCornerMode2::TrimOnly,
            )
        })
        .unwrap()
        .into_value() else {
            panic!("all three represented cubic circle contacts must be retained");
        };
        assert_eq!(candidates.len(), expected.len());
        for (candidate, expected) in candidates.iter().zip(&expected) {
            assert_eq!(candidate.curves()[2].family(), CurveFamily2::CubicBezier);
            assert_eq!(
                candidate.curves()[2].start(),
                hypercurve::CurvePoint2::from((*(expected)).clone())
            );
        }
    }
}

#[test]
fn represented_bezier_corner_incidence_uses_the_shared_approximate_terminal() {
    let undecidable_zero = support::terminally_unresolved_zero();
    let path = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
        Curve2::from(QuadraticBezier2::new(
            p(0, 0),
            Point2::new(undecidable_zero, Real::one()),
            p(1, 2),
        )),
    ])
    .unwrap();

    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(q(15, 4)),
            CurveCornerMode2::TrimOnly)),
        Err(ExactCurveError::Blocked(blocker))
            if blocker.operation() == CurveOperation2::Fillet
                && blocker.family() == Some(CurveFamily2::QuadraticBezier)
    ));
    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(q(15, 4)),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    assert_ne!({ approximate.value.solutions().len() }, 0);
}

#[test]
fn spline_corner_incidence_uses_the_shared_approximate_terminal() {
    let undecidable_zero = support::terminally_unresolved_zero();
    for family in [CurveFamily2::PolynomialBSpline, CurveFamily2::Nurbs] {
        let controls = vec![
            p(0, 0),
            Point2::new(undecidable_zero.clone(), Real::one()),
            p(1, 2),
        ];
        let knots = vec![r(2), r(2), r(2), r(5), r(5), r(5)];
        let carrier = match family {
            CurveFamily2::PolynomialBSpline => {
                crate::support::under(&PredicatePolicy::STRICT, || {
                    Curve2::try_polynomial_bspline(2, controls, knots)
                })
            }
            CurveFamily2::Nurbs => crate::support::under(&PredicatePolicy::STRICT, || {
                Curve2::try_nurbs(2, controls, vec![Real::one(); 3], knots)
            }),
            _ => unreachable!(),
        }
        .unwrap()
        .into_value();
        let path = CurvePath2::try_new(vec![
            Curve2::from(LineSeg2::try_new(p(-4, 0), p(0, 0)).unwrap()),
            carrier,
        ])
        .unwrap();

        assert!(matches!(
            crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(15, 4)),
                CurveCornerMode2::TrimOnly)),
            Err(ExactCurveError::Blocked(blocker))
                if blocker.operation() == CurveOperation2::Fillet
                    && blocker.family() == Some(family)
        ));
        let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
            path.fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(q(15, 4)),
                CurveCornerMode2::TrimOnly,
            )
        })
        .unwrap();
        assert_eq!(
            approximate.certainty,
            CurveCertainty::Approximate512Consumed
        );
        assert_ne!({ approximate.value.solutions().len() }, 0);
    }
}

#[test]
fn automatic_corner_solver_obeys_strict_and_approximate_512_once() {
    let path = right_angle_line_path(4);
    let undecidable_zero = support::terminally_unresolved_zero();
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(undecidable_zero.clone()),
            CurveCornerMode2::TrimOnly)),
        Err(ExactCurveError::Blocked(blocker))
            if blocker.operation() == CurveOperation2::Fillet
                && blocker.reason() == UncertaintyReason::RealSign
    ));
    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        path.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(undecidable_zero),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    assert_eq!(
        (approximate.value).no_solution_reason(),
        Some(CurveCornerNoSolution2::ZeroDesignValue)
    );

    let undecidable_parallel = support::terminally_unresolved_zero();
    let near_tangent = CurvePath2::try_new(vec![
        Curve2::from(LineSeg2::try_new(p(-1, 0), p(0, 0)).unwrap()),
        Curve2::from(
            LineSeg2::try_new(p(0, 0), Point2::new(Real::one(), undecidable_parallel)).unwrap(),
        ),
    ])
    .unwrap();
    assert!(matches!(
        crate::support::under(&PredicatePolicy::STRICT, || near_tangent.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::one()),
            CurveCornerMode2::TrimOnly)),
        Err(ExactCurveError::Blocked(blocker))
            if blocker.reason() == UncertaintyReason::RealSign
    ));
    let approximate = crate::support::under(&PredicatePolicy::APPROXIMATE_512, || {
        near_tangent.fillet_vertex(
            1,
            &hypercurve::CurveFillet2::new(Real::one()),
            CurveCornerMode2::TrimOnly,
        )
    })
    .unwrap();
    assert_eq!(
        approximate.certainty,
        CurveCertainty::Approximate512Consumed
    );
    assert_eq!(
        (approximate.value).no_solution_reason(),
        Some(CurveCornerNoSolution2::ParallelTangents)
    );
}

proptest! {
    #[test]
    fn exact_line_corner_design_edits_hold_across_source_lengths(
        radius in 1_i32..32,
        previous_remainder in 1_i32..32,
        next_remainder in 1_i32..32,
    ) {
        let previous_length = radius + previous_remainder;
        let next_length = radius + next_remainder;
        let path = CurvePath2::try_new(vec![
            Curve2::from(
                LineSeg2::try_new(p(-previous_length, 0), p(0, 0)).unwrap()
            ),
            Curve2::from(
                LineSeg2::try_new(p(0, 0), p(0, next_length)).unwrap()
            ),
        ])
        .unwrap();
        let CurveCornerSolutions2::Unique(chamfered) = crate::support::under(&PredicatePolicy::STRICT, || path
            .chamfer_vertex_by_setbacks(
                1,
                r(radius),
                r(radius),
                CurveCornerMode2::TrimOnly))
            .unwrap()
            .into_value()
        else {
            return Err(TestCaseError::fail("line setbacks must solve uniquely"));
        };
        prop_assert_eq!(chamfered.curves()[0].end().coordinates().expect("native endpoint").clone(), p(-radius, 0));
        prop_assert_eq!(chamfered.curves()[1].end().coordinates().expect("native endpoint").clone(), p(0, radius));

        let filleted = {
let solutions = crate::support::under(&PredicatePolicy::STRICT, || path
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(r(radius)),
                CurveCornerMode2::TrimOnly))
            .unwrap()
            .into_value();
let mut candidates = solutions.into_solutions();
assert_eq!(candidates.len(), 1, "expected one isolated fillet");
candidates.pop().unwrap()
};
        prop_assert_eq!(filleted.curves()[0].end().coordinates().expect("native endpoint").clone(), p(-radius, 0));
        prop_assert_eq!(filleted.curves()[1].family(), CurveFamily2::CircularArc);
        prop_assert_eq!(filleted.curves()[1].end().coordinates().expect("native endpoint").clone(), p(0, radius));
        prop_assert_eq!(filleted.curves()[2].start().coordinates().expect("native endpoint").clone(), p(0, radius));
    }

    #[test]
    fn exact_line_arc_fillets_retain_rational_radius_across_source_scales(
        source_radius in 1_i32..16,
        fillet_numerator in 1_i32..24,
        fillet_denominator in 1_i32..8,
    ) {
        let line_length = 4 * (source_radius + fillet_numerator + fillet_denominator);
        let path = CurvePath2::try_new(vec![
            Curve2::from(
                LineSeg2::try_new(p(-line_length, 0), p(0, 0)).unwrap()
            ),
            Curve2::from(
                CircularArc2::try_from_center(
                    p(0, 0),
                    p(source_radius, source_radius),
                    p(source_radius, 0),
                    true,
                )
                .unwrap()
            ),
        ])
        .unwrap();
        let radius = q(fillet_numerator, fillet_denominator);
        let filleted = {
let solutions = crate::support::under(&PredicatePolicy::STRICT, || path
            .fillet_vertex(
                1,
                &hypercurve::CurveFillet2::new(radius.clone()),
                CurveCornerMode2::TrimOnly))
            .unwrap()
            .into_value();
let mut candidates = solutions.into_solutions();
assert_eq!(candidates.len(), 1, "expected one isolated fillet");
candidates.pop().unwrap()
};
        let Some(CurveGeometry2::CircularArc(inserted)) = filleted.curves()[1].geometry() else {
            return Err(TestCaseError::fail("the solved fillet must remain circular"));
        };
        prop_assert_eq!(filleted.curves()[0].end().coordinates().expect("native endpoint").clone(), inserted.start().clone());
        prop_assert_eq!(filleted.curves()[2].start().coordinates().expect("native endpoint").clone(), inserted.end().clone());
        prop_assert_eq!(
            inserted
                .radius_squared()
                .certified_eq_until(&(&radius * &radius), -4096)
                .as_bool(),
            Some(true)
        );
        let Some(CurveGeometry2::CircularArc(retained)) = filleted.curves()[2].geometry() else {
            return Err(TestCaseError::fail("the source arc must be retained"));
        };
        prop_assert_eq!(retained.center(), &p(source_radius, 0));
        prop_assert_eq!(retained.end(), &p(source_radius, source_radius));
    }
}

#[test]
fn derivatives_at_selected_parameters_stay_exact() {
    use hypercurve::{
        Axis2, BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval,
        BezierParameterPolynomial, Classification, CurveParameter2, RealSign,
    };
    fn decided<T>(value: Classification<T>) -> T {
        match value {
            Classification::Decided(value) => value,
            Classification::Uncertain(reason) => panic!("{reason:?}"),
        }
    }
    let q = |n: i64, d: i64| (Real::from(n) / Real::from(d)).unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512] {
        // The positive root of scale*t^2 - constant in [lower, upper].
        let root = |scale: i64, constant: i64, lower: Real, upper: Real| {
            let polynomial = decided(
                crate::support::under_classified_result(&policy, || {
                    BezierParameterPolynomial::try_new_power_basis(vec![
                        Real::from(-constant),
                        Real::zero(),
                        Real::from(scale),
                    ])
                })
                .unwrap(),
            );
            let interval = decided(
                crate::support::under_classified_result(&policy, || {
                    BezierParameterInterval::try_new(lower, upper)
                })
                .unwrap(),
            );
            CurveParameter2::from(BezierParameter2::Algebraic(decided(
                crate::support::under_classified_result(&policy, || {
                    BezierAlgebraicParameter2::try_isolate(polynomial, interval)
                })
                .unwrap(),
            )))
        };
        let signs = |curve: &Curve2, parameter: &CurveParameter2| {
            let derivative = crate::support::under(&policy, || curve.derivative_at(parameter))
                .unwrap()
                .into_value();
            assert!(derivative.represented_coordinates().is_none());
            [Axis2::X, Axis2::Y].map(|axis| {
                decided(
                    crate::support::under_classified_result(&policy, || {
                        derivative.coordinate_sign(axis)
                    })
                    .unwrap(),
                )
            })
        };
        let sqrt_half = root(2, 1, q(2, 3), q(3, 4));

        // P(t) = (2t, 4t^2), so P'(t) = (2, 8t).
        let parabola = Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, 0), p(2, 4)));
        assert_eq!(
            signs(&parabola, &sqrt_half),
            [RealSign::Positive, RealSign::Positive]
        );
        // P(t) = (2t, 2t - 2t^2), so P'(t) = (2, 2 - 4t) and 2 - 2*sqrt(2) < 0.
        let arch = Curve2::from(QuadraticBezier2::new(p(0, 0), p(1, 1), p(2, 0)));
        assert_eq!(
            signs(&arch, &sqrt_half),
            [RealSign::Positive, RealSign::Negative]
        );

        // The same arch on knot domain [0, 2]: the chart factor 1/2 is exact,
        // and s = sqrt(2) maps to the local root sqrt(1/2).
        let spline = crate::support::under(&policy, || {
            Curve2::try_polynomial_bspline(
                2,
                vec![p(0, 0), p(1, 1), p(2, 0)],
                [0, 0, 0, 2, 2, 2].map(Real::from).to_vec(),
            )
        })
        .unwrap()
        .into_value();
        let sqrt_two = root(1, 2, q(4, 3), q(3, 2));
        assert_eq!(
            signs(&spline, &sqrt_two),
            [RealSign::Positive, RealSign::Negative]
        );
    }
}
