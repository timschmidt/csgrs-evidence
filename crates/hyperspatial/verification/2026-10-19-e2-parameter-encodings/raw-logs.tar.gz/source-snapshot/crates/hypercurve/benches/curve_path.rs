#[path = "../tests/support/mod.rs"]
mod support;
use std::hint::black_box;
use std::time::Instant;

use hypercurve::{
    BooleanOp, CircularArc2, CubicBezier2, Curve2, CurvePath2, CurveRegion2, CurveRegionLoopRole,
    FillRule, LineSeg2, Point2, PredicatePolicy, QuadraticBezier2, Real,
};

fn r(value: i32) -> Real {
    value.into()
}

fn p(x: i32, y: i32) -> Point2 {
    Point2::new(r(x), r(y))
}

fn q(numerator: i32, denominator: i32) -> Real {
    (r(numerator) / r(denominator)).expect("benchmark denominator is nonzero")
}

fn rectangle(x0: i32, y0: i32, x1: i32, y1: i32) -> CurvePath2 {
    let points = [p(x0, y0), p(x1, y0), p(x1, y1), p(x0, y1)];
    CurvePath2::try_new(
        (0..4)
            .map(|index| {
                Curve2::from(
                    LineSeg2::try_new(points[index].clone(), points[(index + 1) % 4].clone())
                        .expect("benchmark rectangle edges are nonzero"),
                )
            })
            .collect(),
    )
    .expect("benchmark rectangle is connected")
}

fn path_region(path: &CurvePath2, policy: &PredicatePolicy) -> CurveRegion2 {
    crate::support::under(policy, || {
        CurveRegion2::try_from_boundary_paths_with_loop_semantics(
            std::slice::from_ref(path),
            &[CurveRegionLoopRole::Material],
            &[FillRule::EvenOdd],
        )
    })
    .expect("benchmark path is a valid exact region boundary")
    .into_value()
}

fn full_circle(center_x: i32) -> Curve2 {
    Curve2::from(
        CircularArc2::try_from_center(
            p(center_x + 1, 0),
            p(center_x + 1, 0),
            p(center_x, 0),
            false,
        )
        .expect("benchmark circle is valid"),
    )
}

fn closed_under_cubic(curve: CubicBezier2, lower_y: i32) -> CurvePath2 {
    let start = curve.start().clone();
    let end = curve.end().clone();
    let lower_end = Point2::new(end.x().clone(), r(lower_y));
    let lower_start = Point2::new(start.x().clone(), r(lower_y));
    CurvePath2::try_new(vec![
        Curve2::from(curve),
        Curve2::from(LineSeg2::try_new(end, lower_end.clone()).expect("benchmark side is nonzero")),
        Curve2::from(
            LineSeg2::try_new(lower_end, lower_start.clone()).expect("benchmark base is nonzero"),
        ),
        Curve2::from(LineSeg2::try_new(lower_start, start).expect("benchmark side is nonzero")),
    ])
    .expect("benchmark curved path is connected")
}

fn main() {
    let policy = PredicatePolicy::STRICT;
    let first = rectangle(0, 0, 2, 2);
    let second = rectangle(1, -1, 3, 1);

    let promotion_iterations = 20_000_u32;
    let promotion_cache_iterations = 2_000_000_u32;
    crate::support::under(&policy, || first.native_bezier_fragments())
        .expect("path promotion is exact");
    let started = Instant::now();
    let mut promotion_checksum = 0_usize;
    for _ in 0..promotion_cache_iterations {
        promotion_checksum = promotion_checksum.wrapping_add(black_box(
            crate::support::under(&policy, || black_box(&first).native_bezier_fragments())
                .expect("cached path promotion remains exact")
                .into_value()
                .len(),
        ));
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_cached_native_promotion: {promotion_cache_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={promotion_checksum}",
        elapsed / promotion_cache_iterations
    );

    crate::support::under(&policy, || first.boundary_loop())
        .expect("benchmark boundary materialization is exact");
    let boundary_cache_iterations = 2_000_000_u32;
    let started = Instant::now();
    let mut boundary_checksum = 0_usize;
    for _ in 0..boundary_cache_iterations {
        boundary_checksum ^= black_box(
            crate::support::under(&policy, || first.boundary_loop())
                .expect("cached path boundary remains exact")
                .into_value()
                .len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_cached_boundary_loop: {boundary_cache_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={boundary_checksum}",
        elapsed / boundary_cache_iterations
    );

    let boundary_build_iterations = 20_000_u32;
    let rectangle_curves = first.curves().to_vec();
    let started = Instant::now();
    let mut boundary_build_checksum = 0_usize;
    for _ in 0..boundary_build_iterations {
        let path = CurvePath2::try_new(rectangle_curves.clone())
            .expect("fresh benchmark path is connected");
        boundary_build_checksum ^= black_box(
            crate::support::under(&policy, || path.boundary_loop())
                .expect("fresh benchmark boundary is exact")
                .into_value()
                .len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_immediate_boundary_loop: {boundary_build_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={boundary_build_checksum}",
        elapsed / boundary_build_iterations
    );

    let query = hypercurve::CurvePoint2::from(p(1, 1));
    let classification_iterations = 50_000_u32;
    let started = Instant::now();
    let mut classification_checksum = 0_usize;
    for _ in 0..classification_iterations {
        let location = crate::support::under(&policy, || first.classify_point(black_box(&query)))
            .expect("benchmark path classification is exact")
            .into_value();
        classification_checksum ^= black_box(location as usize);
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_cached_point_classification: {classification_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={classification_checksum}",
        elapsed / classification_iterations
    );

    let native = Curve2::from(QuadraticBezier2::new(p(0, 0), p(2, 4), p(4, 0)));
    crate::support::under(&policy, || native.native_bezier_fragments())
        .expect("benchmark native curve promotes exactly");
    let started = Instant::now();
    let mut full_trim_checksum = 0_usize;
    for _ in 0..promotion_iterations {
        let trimmed = crate::support::under(&policy, || native.subcurve(r(0).into(), r(1).into()))
            .expect("full-domain trim is exact")
            .into_value();
        full_trim_checksum ^= black_box(
            crate::support::under(&policy, || trimmed.native_bezier_fragments())
                .unwrap()
                .into_value()
                .len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_cached_full_domain_subcurve: {promotion_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={full_trim_checksum}",
        elapsed / promotion_iterations
    );

    let native_split_iterations = 5_000_u32;
    let started = Instant::now();
    let mut native_split_checksum = 0_usize;
    for _ in 0..native_split_iterations {
        let (left, right) = crate::support::under(&policy, || native.split_at(q(1, 2).into()))
            .expect("native benchmark split is exact")
            .into_value();
        native_split_checksum ^= black_box(left.family() as usize ^ right.family() as usize);
    }
    let elapsed = started.elapsed();
    println!(
        "curve_native_exact_split: {native_split_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={native_split_checksum}",
        elapsed / native_split_iterations
    );

    let spline = crate::support::under(&policy, || {
        Curve2::try_nurbs(
            2,
            vec![p(0, 0), p(2, 4), p(4, 4), p(6, 0)],
            vec![r(1), r(2), r(3), r(4)],
            vec![r(0), r(1), r(2), r(3), r(4), r(5), r(6)],
        )
    })
    .expect("benchmark NURBS is valid")
    .into_value();
    let spline_split_iterations = 1_000_u32;
    let started = Instant::now();
    let mut spline_split_checksum = 0_usize;
    for _ in 0..spline_split_iterations {
        let (left, right) = crate::support::under(&policy, || spline.split_at(r(3).into()))
            .expect("spline benchmark split is exact")
            .into_value();
        spline_split_checksum ^= black_box(
            crate::support::under(&policy, || left.native_bezier_fragments())
                .unwrap()
                .into_value()
                .len()
                + crate::support::under(&policy, || right.native_bezier_fragments())
                    .unwrap()
                    .into_value()
                    .len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_nurbs_exact_split: {spline_split_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={spline_split_checksum}",
        elapsed / spline_split_iterations
    );

    let immediate_iterations = 2_000_u32;
    let started = Instant::now();
    let mut evidence_checksum = 0_usize;
    for _ in 0..immediate_iterations {
        let evidence = crate::support::under(&policy, || first.intersect_path(&second))
            .expect("benchmark path evidence is complete")
            .into_value();
        evidence_checksum ^= black_box(
            evidence.candidate_curve_pair_count()
                + evidence.contacts().len()
                + evidence.overlaps().len()
                + evidence.blockers().len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_immediate_intersection_evidence: {immediate_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={evidence_checksum}",
        elapsed / immediate_iterations
    );

    let started = Instant::now();
    let mut topology_checksum = 0_usize;
    for _ in 0..immediate_iterations {
        let topology = crate::support::under(&policy, || first.intersection_topology(&second))
            .expect("benchmark path topology is complete")
            .into_value();
        topology_checksum ^= black_box(topology.first().len() + topology.second().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_path_immediate_intersection_topology: {immediate_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={topology_checksum}",
        elapsed / immediate_iterations
    );

    let partial_first = rectangle(0, 0, 2, 4);
    let partial_second = rectangle(2, 1, 4, 3);
    let partial_first_region = path_region(&partial_first, &policy);
    let partial_second_region = path_region(&partial_second, &policy);
    let boolean_iterations = 500_u32;
    let started = Instant::now();
    let mut boolean_checksum = 0_usize;
    for _ in 0..boolean_iterations {
        let regions = crate::support::under(&policy, || {
            partial_first_region.boolean_regions(&partial_second_region)
        })
        .expect("all canonical partial-overlap Booleans are exact")
        .into_value();
        boolean_checksum ^= black_box(
            regions.union().boundary_loops().len()
                + regions.intersection().boundary_loops().len()
                + regions.difference().boundary_loops().len()
                + regions.xor().boundary_loops().len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_authoritative_boolean_batch: {boolean_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={boolean_checksum}",
        elapsed / boolean_iterations
    );

    let started = Instant::now();
    let mut partial_checksum = 0_usize;
    for _ in 0..boolean_iterations {
        let region = crate::support::under(&policy, || {
            partial_first_region.boolean_region(&partial_second_region, BooleanOp::Union)
        })
        .expect("partial-overlap union is exact")
        .into_value();
        partial_checksum ^= black_box(region.boundary_loops().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_authoritative_partial_line_overlap_union: {boolean_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={partial_checksum}",
        elapsed / boolean_iterations
    );

    let partial_arc_first = CurvePath2::try_new(vec![
        Curve2::from(
            CircularArc2::try_from_center(p(5, 0), p(-5, 0), p(0, 0), false)
                .expect("benchmark semicircle is valid"),
        ),
        Curve2::from(LineSeg2::try_new(p(-5, 0), p(5, 0)).expect("benchmark diameter is nonzero")),
    ])
    .expect("benchmark semicircle path is connected");
    let partial_arc_second = CurvePath2::try_new(vec![
        Curve2::from(
            CircularArc2::try_from_center(p(4, 3), p(0, 5), p(0, 0), false)
                .expect("benchmark subarc is valid"),
        ),
        Curve2::from(
            LineSeg2::try_new(p(0, 5), p(4, 3)).expect("benchmark subarc chord is nonzero"),
        ),
    ])
    .expect("benchmark circular-segment path is connected");
    let partial_arc_first_region = path_region(&partial_arc_first, &policy);
    let partial_arc_second_region = path_region(&partial_arc_second, &policy);
    let started = Instant::now();
    let mut partial_arc_checksum = 0_usize;
    for _ in 0..boolean_iterations {
        let region = crate::support::under(&policy, || {
            partial_arc_first_region.boolean_region(&partial_arc_second_region, BooleanOp::Union)
        })
        .expect("partial-arc union is exact")
        .into_value();
        partial_arc_checksum ^= black_box(region.boundary_loops().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_authoritative_partial_arc_overlap_union: {boolean_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={partial_arc_checksum}",
        elapsed / boolean_iterations
    );

    let nonlinear_source = CubicBezier2::new(p(0, 0), p(1, 3), p(3, 3), p(4, 0));
    let nonlinear_first = closed_under_cubic(
        crate::support::under_value(&policy, || {
            nonlinear_source.subcurve_between_exact(&r(0), &q(3, 4))
        })
        .expect("benchmark cubic subcurve is exact"),
        -5,
    );
    let nonlinear_second = closed_under_cubic(
        crate::support::under_value(&policy, || {
            nonlinear_source.subcurve_between_exact(&q(3, 8), &q(7, 8))
        })
        .expect("benchmark cubic subcurve is exact"),
        -6,
    );
    let nonlinear_first_region = path_region(&nonlinear_first, &policy);
    let nonlinear_second_region = path_region(&nonlinear_second, &policy);
    let started = Instant::now();
    let mut nonlinear_checksum = 0_usize;
    for _ in 0..boolean_iterations {
        let region = crate::support::under(&policy, || {
            nonlinear_first_region.boolean_region(&nonlinear_second_region, BooleanOp::Union)
        })
        .expect("partial nonlinear-overlap union is exact")
        .into_value();
        nonlinear_checksum ^= black_box(region.boundary_loops().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_authoritative_partial_nonlinear_overlap_union: {boolean_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={nonlinear_checksum}",
        elapsed / boolean_iterations
    );

    let lineage_source = Curve2::from(CubicBezier2::new(p(0, 0), p(1, 3), p(3, 3), p(4, 0)));
    let lineage_first = crate::support::under(&policy, || {
        lineage_source.subcurve(r(0).into(), q(3, 4).into())
    })
    .expect("benchmark source trim is exact")
    .into_value();
    let lineage_second = crate::support::under(&policy, || {
        lineage_source.subcurve(q(1, 4).into(), r(1).into())
    })
    .expect("benchmark source trim is exact")
    .into_value();
    let lineage_iterations = 5_000_u32;
    let started = Instant::now();
    let mut lineage_checksum = 0_usize;
    for _ in 0..lineage_iterations {
        lineage_checksum ^= black_box(
            crate::support::under(&policy, || lineage_first.intersect_curve(&lineage_second))
                .expect("lineage evidence is exact")
                .into_value()
                .overlaps()
                .len(),
        );
    }
    let elapsed = started.elapsed();
    println!(
        "curve_pair_immediate_lineage_partial_nonlinear_overlap: {lineage_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={lineage_checksum}",
        elapsed / lineage_iterations
    );

    let first_circle = full_circle(0);
    let second_circle = full_circle(1);
    let native_iterations = 500_u32;
    let started = Instant::now();
    let mut native_checksum = 0_usize;
    for _ in 0..native_iterations {
        let evidence =
            crate::support::under(&policy, || first_circle.intersect_curve(&second_circle))
                .expect("native circle evidence is complete")
                .into_value();
        native_checksum ^= black_box(evidence.contacts().len() + evidence.span_pair_count());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_pair_native_circle_dispatch: {native_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={native_checksum}",
        elapsed / native_iterations
    );

    let first_circle_path =
        CurvePath2::try_new(vec![first_circle]).expect("benchmark circle path is connected");
    let second_circle_path =
        CurvePath2::try_new(vec![second_circle]).expect("benchmark circle path is connected");
    let first_circle_region = path_region(&first_circle_path, &policy);
    let second_circle_region = path_region(&second_circle_path, &policy);
    let started = Instant::now();
    let mut circle_checksum = 0_usize;
    for _ in 0..boolean_iterations {
        let region = crate::support::under(&policy, || {
            first_circle_region.boolean_region(&second_circle_region, BooleanOp::Union)
        })
        .expect("benchmark circle union is exact")
        .into_value();
        circle_checksum ^= black_box(region.boundary_loops().len());
    }
    let elapsed = started.elapsed();
    println!(
        "curve_region_authoritative_circle_union: {boolean_iterations} iterations in {elapsed:?} ({:?}/iter), checksum={circle_checksum}",
        elapsed / boolean_iterations
    );
}
