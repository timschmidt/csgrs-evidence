//! Exactness-aware axis-aligned bounding boxes for planar curve primitives.
//!
//! These boxes are deliberately a broad-phase filter, not a replacement for
//! exact segment topology. A decided non-overlap lets callers skip an exact
//! segment relation; uncertain ordering falls back to the exact relation. This
//! mirrors the candidate-pruning role of bounding intervals in sweep-line
//! intersection algorithms such as sweep-line scheduling.

use std::cmp::Ordering;

use hyperreal::Real;

use crate::classify::compare_reals;
use crate::region::{LineArcRegion2, RegionView2};
use crate::{
    CircularArc2, Classification, Contour2, CurveContext, CurveResult, CurveString2, LineSeg2,
    Point2, Segment2, UncertaintyReason,
};

/// An axis-aligned bounding box for two-dimensional curve geometry.
///
/// The box is closed: points on `min`/`max` edges are considered contained and
/// two boxes whose edges touch are considered overlapping. Construction and
/// enclosure evidence use only certified decisions, independently of topology
/// or preview policy. Unresolved ordering returns uncertainty unless the source
/// primitive provides a certified conservative envelope.
#[derive(Clone, Debug, PartialEq)]
pub struct Aabb2 {
    min: Point2,
    max: Point2,
}

impl Aabb2 {
    /// Constructs a box without checking `min <= max`.
    ///
    /// Prefer the geometry constructors unless the caller already proved the
    /// coordinate ordering.
    pub const fn new_unchecked(min: Point2, max: Point2) -> Self {
        Self { min, max }
    }

    /// Constructs a zero-area box containing exactly one point.
    pub fn from_point(point: Point2) -> Self {
        Self {
            min: point.clone(),
            max: point,
        }
    }

    /// Constructs the smallest box containing all supplied points.
    ///
    /// Empty input is reported as unsupported because there is no neutral finite
    /// bounding box for an empty point set in this crate's Real model.
    pub fn from_points<'a, I>(points: I) -> Classification<Self>
    where
        I: IntoIterator<Item = &'a Point2>,
    {
        let mut points = points.into_iter();
        let Some(first) = points.next() else {
            return Classification::Uncertain(UncertaintyReason::Unsupported);
        };

        let Some(second) = points.next() else {
            return Classification::Decided(Self::from_point(first.clone()));
        };
        // The initial bounds coincide. One certified comparison per axis
        // establishes both extrema; comparing the same pair twice adds no proof.
        let Some((mut min_x, mut max_x)) = ordered_coordinate_pair(first.x(), second.x()) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };
        let Some((mut min_y, mut max_y)) = ordered_coordinate_pair(first.y(), second.y()) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };

        for point in points {
            if include_coordinate(&mut min_x, &mut max_x, point.x()).is_none()
                || include_coordinate(&mut min_y, &mut max_y, point.y()).is_none()
            {
                return Classification::Uncertain(UncertaintyReason::Ordering);
            }
        }

        Classification::Decided(Self {
            min: Point2::new(min_x, min_y),
            max: Point2::new(max_x, max_y),
        })
    }

    /// Constructs the bounding box of a finite line segment.
    pub fn from_line(line: &LineSeg2) -> Classification<Self> {
        Self::from_points([line.start(), line.end()])
    }

    /// Constructs the bounding box of a finite circular arc.
    ///
    /// The endpoints always contribute. Cardinal circle extrema contribute only
    /// when the arc sweep contains the corresponding point, preserving native
    /// circular-arc geometry without tessellation. If sweep membership at a
    /// cardinal point is uncertain, that point is included conservatively. A
    /// looser box is safe for broad-phase filtering while omitting an uncertain
    /// extremum could hide a true intersection.
    pub fn from_arc(arc: &CircularArc2) -> CurveResult<Classification<Self>> {
        let mut bbox = match Self::from_points([arc.start(), arc.end()]) {
            Classification::Decided(bbox) => bbox,
            Classification::Uncertain(reason) => {
                if reason != UncertaintyReason::Ordering {
                    return Ok(Classification::Uncertain(reason));
                }
                let radius = arc.radius_squared().sqrt()?;
                return Ok(Classification::Decided(Self::arc_circle_envelope(
                    arc, &radius,
                )));
            }
        };

        let radius = arc.radius_squared().sqrt()?;
        let candidates = [
            Point2::new(arc.center().x() + &radius, arc.center().y().clone()),
            Point2::new(arc.center().x() - &radius, arc.center().y().clone()),
            Point2::new(arc.center().x().clone(), arc.center().y() + &radius),
            Point2::new(arc.center().x().clone(), arc.center().y() - &radius),
        ];

        for candidate in &candidates {
            match arc.contains_sweep_point_with_policy(candidate, &CurveContext::STRICT) {
                Classification::Decided(true) => match bbox.include_point(candidate) {
                    Classification::Decided(()) => {}
                    Classification::Uncertain(_) => {
                        return Ok(Classification::Decided(Self::arc_circle_envelope(
                            arc, &radius,
                        )));
                    }
                },
                Classification::Decided(false) => {}
                Classification::Uncertain(_) => {
                    return Ok(Classification::Decided(Self::arc_circle_envelope(
                        arc, &radius,
                    )));
                }
            }
        }

        Ok(Classification::Decided(bbox))
    }

    fn arc_circle_envelope(arc: &CircularArc2, radius: &Real) -> Self {
        Self {
            min: Point2::new(arc.center().x() - radius, arc.center().y() - radius),
            max: Point2::new(arc.center().x() + radius, arc.center().y() + radius),
        }
    }

    /// Constructs the bounding box of a native line or circular-arc segment.
    pub fn from_segment(segment: &Segment2) -> CurveResult<Classification<Self>> {
        match segment {
            Segment2::Line(line) => Ok(Self::from_line(line)),
            Segment2::Arc(arc) => Self::from_arc(arc),
        }
    }

    /// Constructs the bounding box of an open curve string.
    pub fn from_curve_string(curve: &CurveString2) -> CurveResult<Classification<Self>> {
        if curve
            .segments()
            .iter()
            .all(|segment| matches!(segment, Segment2::Line(_)))
        {
            // Curve strings retain exact endpoint connectivity. Every line
            // endpoint except the final one is therefore the next segment's
            // start, so visit each authored vertex once instead of boxing every
            // edge and repeatedly unioning the same shared vertices.
            return Ok(Self::from_points(
                curve
                    .segments()
                    .iter()
                    .map(Segment2::start)
                    .chain(curve.segments().last().map(Segment2::end)),
            ));
        }

        let mut segments = curve.segments().iter();
        let Some(first) = segments.next() else {
            return Ok(Classification::Uncertain(UncertaintyReason::Unsupported));
        };

        let mut bbox = match Self::from_segment(first)? {
            Classification::Decided(bbox) => bbox,
            Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
        };

        for segment in segments {
            let segment_bbox = match Self::from_segment(segment)? {
                Classification::Decided(bbox) => bbox,
                Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
            };
            bbox = match bbox.union(&segment_bbox) {
                Classification::Decided(bbox) => bbox,
                Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
            };
        }

        Ok(Classification::Decided(bbox))
    }

    /// Constructs the bounding box of a closed contour.
    pub fn from_contour(contour: &Contour2) -> CurveResult<Classification<Self>> {
        if contour
            .segments()
            .iter()
            .all(|segment| matches!(segment, Segment2::Line(_)))
        {
            // A contour is closed and endpoint-connected, so its segment starts
            // are exactly its distinct authored vertex visits. The final end is
            // the first start and need not be compared again.
            return Ok(Self::from_points(
                contour.segments().iter().map(Segment2::start),
            ));
        }
        Self::from_curve_string(contour.curve_string())
    }

    /// Constructs the bounding box of an owned region.
    ///
    /// Material and hole contours both contribute because a region-level box is
    /// a broad-phase envelope for boundary topology, not a filled-area
    /// containment proof.
    pub(crate) fn from_region(region: &LineArcRegion2) -> CurveResult<Classification<Self>> {
        Self::from_region_view(&region.as_view())
    }

    /// Constructs the bounding box of a borrowed region view.
    ///
    /// Empty regions evidence unsupported because there is no finite closed box
    /// that represents the absence of geometry. Callers that need empty-region
    /// fast paths should handle emptiness before asking for a box.
    pub(crate) fn from_region_view(region: &RegionView2<'_>) -> CurveResult<Classification<Self>> {
        let mut contours = region
            .material_contours()
            .iter()
            .chain(region.hole_contours().iter())
            .copied();
        let Some(first) = contours.next() else {
            return Ok(Classification::Uncertain(UncertaintyReason::Unsupported));
        };

        let mut bbox = match Self::from_contour(first)? {
            Classification::Decided(bbox) => bbox,
            Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
        };

        for contour in contours {
            let contour_bbox = match Self::from_contour(contour)? {
                Classification::Decided(bbox) => bbox,
                Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
            };
            bbox = match bbox.union(&contour_bbox) {
                Classification::Decided(bbox) => bbox,
                Classification::Uncertain(reason) => return Ok(Classification::Uncertain(reason)),
            };
        }

        Ok(Classification::Decided(bbox))
    }

    /// Returns the minimum corner.
    pub const fn min(&self) -> &Point2 {
        &self.min
    }

    /// Returns the maximum corner.
    pub const fn max(&self) -> &Point2 {
        &self.max
    }

    /// Returns the minimum x coordinate.
    pub fn min_x(&self) -> &Real {
        self.min.x()
    }

    /// Returns the minimum y coordinate.
    pub fn min_y(&self) -> &Real {
        self.min.y()
    }

    /// Returns the maximum x coordinate.
    pub fn max_x(&self) -> &Real {
        self.max.x()
    }

    /// Returns the maximum y coordinate.
    pub fn max_y(&self) -> &Real {
        self.max.y()
    }

    /// Classifies whether the stored corners satisfy `min <= max` on both axes.
    ///
    /// This certifies boxes that entered through [`Self::new_unchecked`] before
    /// they are retained as provenance-bearing evidence.
    pub fn has_valid_ordering(&self) -> Classification<bool> {
        let Some(x_order) = compare_reals(self.min_x(), self.max_x(), &CurveContext::STRICT) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };
        let Some(y_order) = compare_reals(self.min_y(), self.max_y(), &CurveContext::STRICT) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };
        Classification::Decided(
            !matches!(x_order, Ordering::Greater) && !matches!(y_order, Ordering::Greater),
        )
    }

    /// Expands this box so it contains `point`.
    pub fn include_point(&mut self, point: &Point2) -> Classification<()> {
        let mut min_x = self.min.x().clone();
        let mut min_y = self.min.y().clone();
        let mut max_x = self.max.x().clone();
        let mut max_y = self.max.y().clone();

        if include_coordinate(&mut min_x, &mut max_x, point.x()).is_none()
            || include_coordinate(&mut min_y, &mut max_y, point.y()).is_none()
        {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        }

        self.min = Point2::new(min_x, min_y);
        self.max = Point2::new(max_x, max_y);
        Classification::Decided(())
    }

    /// Returns the smallest box containing both inputs.
    pub fn union(&self, other: &Self) -> Classification<Self> {
        let mut merged = self.clone();
        match merged.include_point(other.min()) {
            Classification::Decided(()) => {}
            Classification::Uncertain(reason) => return Classification::Uncertain(reason),
        }
        match merged.include_point(other.max()) {
            Classification::Decided(()) => Classification::Decided(merged),
            Classification::Uncertain(reason) => Classification::Uncertain(reason),
        }
    }

    /// Returns an exact-rational outer envelope without ordering either stored
    /// endpoint against an unrelated algebraic value.
    ///
    /// Every coordinate interval is a certified enclosure supplied by
    /// `hyperreal`; choosing the lower enclosure for `min` and the upper
    /// enclosure for `max` can only widen this box.  This is therefore safe in
    /// STRICT as well as APPROXIMATE_512 and does not consume an approximate
    /// equality decision. Initial queries use 32-bit computable precision;
    /// further refinement increases it without imposing a fixed ceiling on
    /// separation. Exact rational coordinates retain their original values.
    /// Unrepresentable precision requests decline this optional conversion.
    pub(crate) fn certified_rational_outer_envelope(
        &self,
        refinement_steps: usize,
    ) -> Option<Self> {
        let precision = -i32::try_from(refinement_steps.max(32)).ok()?;

        let [min_x, _] = self.min_x().certified_rational_interval(precision)?;
        let [min_y, _] = self.min_y().certified_rational_interval(precision)?;
        let [_, max_x] = self.max_x().certified_rational_interval(precision)?;
        let [_, max_y] = self.max_y().certified_rational_interval(precision)?;
        Some(Self::new_unchecked(
            Point2::new(Real::new(min_x), Real::new(min_y)),
            Point2::new(Real::new(max_x), Real::new(max_y)),
        ))
    }

    /// Classifies whether this closed box contains `point`.
    pub fn contains_point(&self, point: &Point2) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided(
            crate::CurveOperation2::Classification,
            self.contains_point_with_policy(point, &crate::policy::principal_context()),
        )
    }

    /// [`Self::contains_point`] under an explicit predicate policy.
    pub(crate) fn contains_point_with_policy(
        &self,
        point: &Point2,
        policy: &CurveContext,
    ) -> Classification<bool> {
        if !policy.is_edge_preview() {
            return match policy.consume_predicate(hyperlimit::point_in_ordered_aabb2_coordinates(
                [self.min_x(), self.min_y()],
                [self.max_x(), self.max_y()],
                [point.x(), point.y()],
                policy.predicate_policy(),
            )) {
                Some(value) => Classification::Decided(value),
                None => Classification::Uncertain(UncertaintyReason::Ordering),
            };
        }

        let Some(x_inside) = real_between(point.x(), self.min_x(), self.max_x(), policy) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };
        if !x_inside {
            return Classification::Decided(false);
        }

        let Some(y_inside) = real_between(point.y(), self.min_y(), self.max_y(), policy) else {
            return Classification::Uncertain(UncertaintyReason::Ordering);
        };
        Classification::Decided(y_inside)
    }

    /// Classifies whether two closed boxes overlap.
    ///
    /// Edge and corner contacts count as overlap. This inclusive convention is
    /// necessary for tangent, endpoint, and shared-boundary curve topology.
    pub fn overlaps(&self, other: &Self) -> crate::ExactCurveResult<bool> {
        crate::ExactCurveError::decided(
            crate::CurveOperation2::Classification,
            self.overlaps_with_policy(other, &crate::policy::principal_context()),
        )
    }

    /// [`Self::overlaps`] under an explicit predicate policy.
    pub(crate) fn overlaps_with_policy(
        &self,
        other: &Self,
        policy: &CurveContext,
    ) -> Classification<bool> {
        if !policy.is_edge_preview() {
            return match policy.consume_predicate(hyperlimit::ordered_aabb2s_intersect_coordinates(
                [self.min_x(), self.min_y()],
                [self.max_x(), self.max_y()],
                [other.min_x(), other.min_y()],
                [other.max_x(), other.max_y()],
                policy.predicate_policy(),
            )) {
                Some(value) => Classification::Decided(value),
                None => Classification::Uncertain(UncertaintyReason::Ordering),
            };
        }

        for (direction, (left, right)) in [
            (self.max_x(), other.min_x()),
            (other.max_x(), self.min_x()),
            (self.max_y(), other.min_y()),
            (other.max_y(), self.min_y()),
        ]
        .into_iter()
        .enumerate()
        {
            #[cfg(not(feature = "dispatch-trace"))]
            let _ = direction;
            match real_less(left, right, policy) {
                Some(true) => {
                    #[cfg(feature = "dispatch-trace")]
                    hyperreal::dispatch_trace::record(
                        "hypercurve",
                        "aabb-overlap",
                        match direction {
                            0 => "separated-first-x",
                            1 => "separated-second-x",
                            2 => "separated-first-y",
                            3 => "separated-second-y",
                            _ => unreachable!("AABB has four directed separation tests"),
                        },
                    );
                    return Classification::Decided(false);
                }
                Some(false) => {}
                None => {
                    #[cfg(feature = "dispatch-trace")]
                    hyperreal::dispatch_trace::record("hypercurve", "aabb-overlap", "uncertain");
                    return Classification::Uncertain(UncertaintyReason::Ordering);
                }
            }
        }

        #[cfg(feature = "dispatch-trace")]
        hyperreal::dispatch_trace::record("hypercurve", "aabb-overlap", "overlap");
        Classification::Decided(true)
    }

    /// Returns the sole point in the intersection of two closed boxes.
    ///
    /// `None` means the boxes are disjoint or their intersection has positive
    /// extent in at least one axis. Uncertain coordinate order remains explicit.
    pub fn singleton_intersection(&self, other: &Self) -> Classification<Option<Point2>> {
        let x = match singleton_interval_intersection(
            self.min_x(),
            self.max_x(),
            other.min_x(),
            other.max_x(),
        ) {
            Classification::Decided(value) => value,
            Classification::Uncertain(reason) => return Classification::Uncertain(reason),
        };
        let y = match singleton_interval_intersection(
            self.min_y(),
            self.max_y(),
            other.min_y(),
            other.max_y(),
        ) {
            Classification::Decided(value) => value,
            Classification::Uncertain(reason) => return Classification::Uncertain(reason),
        };
        Classification::Decided(x.zip(y).map(|(x, y)| Point2::new(x, y)))
    }
}

fn singleton_interval_intersection(
    first_min: &Real,
    first_max: &Real,
    second_min: &Real,
    second_max: &Real,
) -> Classification<Option<Real>> {
    let lower = match compare_reals(first_min, second_min, &CurveContext::STRICT) {
        Some(Ordering::Less) => second_min,
        Some(Ordering::Equal | Ordering::Greater) => first_min,
        None => return Classification::Uncertain(UncertaintyReason::Ordering),
    };
    let upper = match compare_reals(first_max, second_max, &CurveContext::STRICT) {
        Some(Ordering::Less | Ordering::Equal) => first_max,
        Some(Ordering::Greater) => second_max,
        None => return Classification::Uncertain(UncertaintyReason::Ordering),
    };
    match compare_reals(lower, upper, &CurveContext::STRICT) {
        Some(Ordering::Equal) => Classification::Decided(Some(lower.clone())),
        Some(Ordering::Less | Ordering::Greater) => Classification::Decided(None),
        None => Classification::Uncertain(UncertaintyReason::Ordering),
    }
}

pub(crate) fn decided_segment_aabb(segment: &Segment2) -> Option<Aabb2> {
    match Aabb2::from_segment(segment) {
        Ok(Classification::Decided(bbox)) => Some(bbox),
        Ok(Classification::Uncertain(_)) | Err(_) => None,
    }
}

pub(crate) fn decided_contour_aabb(contour: &Contour2) -> Option<Aabb2> {
    match Aabb2::from_contour(contour) {
        Ok(Classification::Decided(bbox)) => Some(bbox),
        Ok(Classification::Uncertain(_)) | Err(_) => None,
    }
}

pub(crate) fn aabbs_decided_disjoint(first: &Aabb2, second: &Aabb2, policy: &CurveContext) -> bool {
    matches!(
        first.overlaps_with_policy(second, policy),
        Classification::Decided(false)
    )
}

pub(crate) fn aabb_decided_misses_point(
    bbox: &Aabb2,
    point: &Point2,
    policy: &CurveContext,
) -> bool {
    matches!(
        bbox.contains_point_with_policy(point, policy),
        Classification::Decided(false)
    )
}

pub(crate) fn aabb_decided_strictly_right_of_point(
    bbox: &Aabb2,
    point: &Point2,
    policy: &CurveContext,
) -> bool {
    matches!(
        compare_reals(bbox.min_x(), point.x(), policy),
        Some(Ordering::Greater)
    )
}

fn ordered_coordinate_pair(first: &Real, second: &Real) -> Option<(Real, Real)> {
    Some(match compare_reals(second, first, &CurveContext::STRICT)? {
        Ordering::Less => (second.clone(), first.clone()),
        Ordering::Equal => (first.clone(), first.clone()),
        Ordering::Greater => (first.clone(), second.clone()),
    })
}

fn include_coordinate(min: &mut Real, max: &mut Real, value: &Real) -> Option<()> {
    if matches!(
        compare_reals(value, min, &CurveContext::STRICT)?,
        Ordering::Less
    ) {
        *min = value.clone();
    }
    if matches!(
        compare_reals(value, max, &CurveContext::STRICT)?,
        Ordering::Greater
    ) {
        *max = value.clone();
    }
    Some(())
}

fn real_less(left: &Real, right: &Real, policy: &CurveContext) -> Option<bool> {
    if policy.is_edge_preview()
        && let (Some(left), Some(right)) = (left.to_f64_lossy(), right.to_f64_lossy())
        && left.is_finite()
        && right.is_finite()
    {
        return Some(left < right - edge_preview_tolerance());
    }

    Some(matches!(
        compare_reals(left, right, policy)?,
        Ordering::Less
    ))
}

fn real_between(value: &Real, min: &Real, max: &Real, policy: &CurveContext) -> Option<bool> {
    if policy.is_edge_preview()
        && let (Some(value), Some(min), Some(max)) =
            (value.to_f64_lossy(), min.to_f64_lossy(), max.to_f64_lossy())
        && value.is_finite()
        && min.is_finite()
        && max.is_finite()
    {
        let tolerance = edge_preview_tolerance();
        return Some(value >= min - tolerance && value <= max + tolerance);
    }

    // Approximation only chooses which exact bound to test first. Values above
    // a box are common in broad-phase scans; checking the upper bound first in
    // that case avoids an otherwise guaranteed lower-bound comparison without
    // allowing the lossy view to decide topology.
    let check_upper_first = matches!(
        (
            value.to_f64_lossy(),
            min.to_f64_lossy(),
            max.to_f64_lossy(),
        ),
        (Some(value), Some(_), Some(max)) if value.is_finite() && max.is_finite() && value > max
    );
    if check_upper_first {
        let upper = compare_reals(value, max, policy)?;
        if matches!(upper, Ordering::Greater) {
            return Some(false);
        }
        let lower = compare_reals(value, min, policy)?;
        return Some(!matches!(lower, Ordering::Less));
    }

    let lower = compare_reals(value, min, policy)?;
    if matches!(lower, Ordering::Less) {
        return Some(false);
    }
    let upper = compare_reals(value, max, policy)?;
    Some(!matches!(upper, Ordering::Greater))
}

fn edge_preview_tolerance() -> f64 {
    crate::policy::preview_tolerance()
        .map(|tolerance| tolerance.absolute.max(tolerance.relative))
        .unwrap_or(1e-12)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::policy::resolve_certified_value;
    use crate::{CurveCertainty, CurvePreviewOptions};

    #[test]
    fn aabb_construction_keeps_exact_input_points() {
        for policy in [CurveContext::APPROXIMATE_512, CurveContext::STRICT] {
            for operation in 0..4 {
                for axis in 0..2 {
                    for reverse in [false, true] {
                        // Fresh positive values whose signs need more than 512
                        // bits prevent earlier proofs from warming this query.
                        let exponent = 607
                            + operation * 4
                            + axis * 2
                            + i64::from(reverse)
                            + i64::from(policy == CurveContext::STRICT) * 16;
                        let epsilon =
                            Real::one() - Real::from(2_i8).powi_i64(-exponent).unwrap().cos();
                        let mut points = [
                            Point2::from_values(0, 0),
                            if axis == 0 {
                                Point2::new(epsilon, Real::one())
                            } else {
                                Point2::new(Real::one(), epsilon)
                            },
                        ];
                        if reverse {
                            points.reverse();
                        }
                        let outcome = resolve_certified_value(&policy, |_| match operation {
                            0 => Aabb2::from_points(&points),
                            1 => Aabb2::from_line(
                                &LineSeg2::try_new(points[0].clone(), points[1].clone()).unwrap(),
                            ),
                            2 => {
                                let mut bounds = Aabb2::from_point(points[0].clone());
                                bounds.include_point(&points[1]).map(|()| bounds)
                            }
                            3 => Aabb2::from_point(points[0].clone())
                                .union(&Aabb2::from_point(points[1].clone())),
                            _ => unreachable!(),
                        });
                        assert_eq!(
                            outcome.certainty,
                            CurveCertainty::Certified,
                            "operation={operation}, axis={axis}, reverse={reverse}, policy={policy:?}",
                        );
                        // An optional bound may decline unresolved order. A
                        // returned bound must contain every source coordinate.
                        let Classification::Decided(bounds) = outcome.value else {
                            continue;
                        };
                        for point in &points {
                            for (lower, upper, value) in [
                                (bounds.min_x(), bounds.max_x(), point.x()),
                                (bounds.min_y(), bounds.max_y(), point.y()),
                            ] {
                                assert!(matches!(
                                    lower.certified_cmp_until(value, -3200).ordering(),
                                    Some(Ordering::Less | Ordering::Equal),
                                ));
                                assert!(matches!(
                                    upper.certified_cmp_until(value, -3200).ordering(),
                                    Some(Ordering::Greater | Ordering::Equal),
                                ));
                            }
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn aabb_ordering_evidence_rejects_near_zero_reversed_corners() {
        for policy in [CurveContext::APPROXIMATE_512, CurveContext::STRICT] {
            for axis in 0..2 {
                let exponent = 653 + axis + i64::from(policy == CurveContext::STRICT) * 2;
                let epsilon = Real::one() - Real::from(2_i8).powi_i64(-exponent).unwrap().cos();
                let bounds = if axis == 0 {
                    Aabb2::new_unchecked(
                        Point2::new(epsilon, Real::zero()),
                        Point2::from_values(0, 1),
                    )
                } else {
                    Aabb2::new_unchecked(
                        Point2::new(Real::zero(), epsilon),
                        Point2::from_values(1, 0),
                    )
                };
                let outcome = resolve_certified_value(&policy, |_| bounds.has_valid_ordering());
                assert_ne!(outcome.value, Classification::Decided(true));
                assert_eq!(outcome.certainty, CurveCertainty::Certified);
            }
        }
    }

    #[test]
    fn aabb_singleton_evidence_keeps_distinct_point_boxes_disjoint() {
        for policy in [CurveContext::APPROXIMATE_512, CurveContext::STRICT] {
            let exponent = 677 + i64::from(policy == CurveContext::STRICT);
            let epsilon = Real::one() - Real::from(2_i8).powi_i64(-exponent).unwrap().cos();
            let first = Aabb2::from_point(Point2::from_values(0, 0));
            let second = Aabb2::from_point(Point2::new(epsilon, Real::zero()));
            let outcome =
                resolve_certified_value(&policy, |_| first.singleton_intersection(&second));
            assert!(!matches!(outcome.value, Classification::Decided(Some(_))));
            assert_eq!(outcome.certainty, CurveCertainty::Certified);
        }
    }

    #[test]
    fn preview_arc_bounds_keep_exact_cardinal_extrema() {
        for policy in [CurveContext::APPROXIMATE_512, CurveContext::STRICT] {
            let x = Real::from(2_i8).sqrt().unwrap();
            let arc = CircularArc2::try_from_center(
                Point2::new(x.clone(), Real::one()),
                Point2::new(-x, Real::one()),
                Point2::from_values(0, 0),
                false,
            )
            .unwrap();
            let preview = CurvePreviewOptions::try_new(policy, 1e-12, 1e-12).unwrap();
            let Classification::Decided(bounds) =
                preview.evaluate(|| Aabb2::from_arc(&arc).unwrap())
            else {
                panic!("the radius-squared-3 arc has certified bounds");
            };
            // The native circle and its CCW sweep contain this exact point.
            // Rounding sqrt(3) to f64 moves the previous upper bound inward.
            let radius = Real::from(3_i8).sqrt().unwrap();
            assert_eq!(
                bounds.contains_point_with_policy(
                    &Point2::new(Real::zero(), radius),
                    &CurveContext::STRICT,
                ),
                Classification::Decided(true),
            );
        }
    }
}
