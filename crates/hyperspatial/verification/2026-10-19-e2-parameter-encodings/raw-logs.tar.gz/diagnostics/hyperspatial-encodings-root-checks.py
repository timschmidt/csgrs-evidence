import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/mnt/development/hyperspatial/csgrs')
logs = Path('/tmp/hyperspatial-encodings-root-verification')
logs.mkdir(exist_ok=True)
freeze = json.loads(Path('/tmp/hyperspatial-encodings-final-source-freeze.json').read_text())
def check_source():
    for name, expected in freeze['sha256'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
environment = os.environ.copy()
environment.update(CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',
                   CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true', CARGO_BUILD_JOBS='4',
                   TMPDIR='/mnt/development/hyperspatial/verification-tmp',
                   UV_TOOL_DIR='/tmp/hyperspatial-uv-tools', UV_TOOL_BIN_DIR='/tmp/hyperspatial-uv-bin',
                   GMP_MPFR_SYS_CACHE='/tmp/hyperspatial-gmp-cache')
environment['PATH'] = '/tmp/hyperspatial-build-tools/usr/bin:' + environment['PATH']
commands = [
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['cargo', 'fmt', '--manifest-path', 'crates/hyperspatial/fuzz/Cargo.toml', '--', '--check'],
    ['cargo', 'test', '--locked', '-p', 'hyperreal', '--all-features', '--lib', 'ring_native_sign_tests'],
    ['cargo', 'test', '--locked', '-p', 'hyperreal', '--all-features', '--test', 'bounded_parameter_encodings'],
    ['cargo', 'test', '--locked', '-p', 'hyperspatial', '--all-features', '--test', 'parameter_encodings_representations'],
    ['cargo', 'test', '--locked', '-p', 'hyperspatial', '--all-features', '--test', 'complex_jacobi_representations', '--test', 'jacobi_epsilon_representations'],
    ['cargo', 'clippy', '--locked', '-p', 'hyperreal', '-p', 'hyperlattice', '-p', 'hyperlimit', '-p', 'hyperspatial', '--all-targets', '--all-features', '--', '-D', 'warnings'],
    ['python3', 'crates/hyperspatial/scripts/source-consumer.py'],
    ['python3', 'crates/hyperspatial/scripts/test_fuzz_smoke.py'],
    ['python3', 'crates/hyperspatial/scripts/test_function_coverage.py'],
    ['python3', 'crates/hyperspatial/scripts/coverage-gates.py'],
    ['cargo', 'check', '--locked', '--manifest-path', 'crates/hyperspatial/fuzz/Cargo.toml', '--bins'],
    ['cargo', 'clippy', '--locked', '--manifest-path', 'crates/hyperspatial/fuzz/Cargo.toml', '--bins', '--', '-D', 'warnings'],
    ['uv', '--cache-dir', '/tmp/hyperspatial-uv-cache', 'tool', 'run', '--offline', 'zizmor', '--pedantic', '--strict-collection', '.'],
    ['git', 'diff', '--check'],
]
record = dict(baseline=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
              environment={key: value for key, value in environment.items()
                           if key.startswith(('CARGO_', 'GMP_', 'UV_TOOL')) or key == 'TMPDIR'}, checks=[])
for index, command in enumerate(commands):
    check_source()
    start = time.monotonic()
    with (logs / f'{index}.log').open('w') as output:
        child = subprocess.Popen(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT)
        row = dict(command=command, log=str(logs / f'{index}.log'), pid=child.pid,
                   started_unix=time.time(), status='running')
        record['checks'].append(row)
        Path('/tmp/hyperspatial-encodings-root-validation.json').write_text(json.dumps(record, indent=2) + '\n')
        row.update(returncode=child.wait(), elapsed_seconds=time.monotonic() - start, status='complete')
    check_source()
    Path('/tmp/hyperspatial-encodings-root-validation.json').write_text(json.dumps(record, indent=2) + '\n')
    print(index, row['returncode'], flush=True)
    if row['returncode']:
        raise SystemExit(row['returncode'])
