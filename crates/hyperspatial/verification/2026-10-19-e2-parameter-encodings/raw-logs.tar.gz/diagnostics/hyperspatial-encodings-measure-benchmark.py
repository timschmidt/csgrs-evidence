import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
log=Path('/tmp/hyperspatial-encodings-benchmark-v1.log').read_text()
paths=re.findall(r'Running benches/bounded_parameter_encodings.rs \(([^)]+)\)',log)
assert len(paths)==1,paths
executable=Path(paths[0]);digest=hashlib.sha256(executable.read_bytes()).hexdigest()
start=time.monotonic()
with Path('/tmp/hyperspatial-encodings-benchmark-standalone.log').open('w') as out:
 child=subprocess.Popen([str(executable)],cwd=root,stdout=out,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
record=dict(returncode=child.returncode,elapsed_seconds=time.monotonic()-start,peak_rss_kib=usage.ru_maxrss,
 executable=str(executable),executable_bytes=executable.stat().st_size,executable_sha256=digest,
 build_command=['cargo','bench','--locked','-p','hyperreal','--bench','bounded_parameter_encodings','--features','serde'],
 build_record='/tmp/hyperspatial-encodings-benchmark-v1.log',
 scope='Standalone native proof/replay benchmark with development serialization and the 22-family fixture; excludes compilation. Not an allocation count, production-only binary size, native work/heap bound or comparative speed claim.')
assert hashlib.sha256(executable.read_bytes()).hexdigest()==digest
rows=[json.loads(line) for line in Path('/tmp/hyperspatial-encodings-benchmark-standalone.log').read_text().splitlines() if line.startswith('{')]
assert child.returncode==0 and len(rows)==220 and all(r['accepted']==r['repeats'] for r in rows)
record.update(rows=len(rows),accepted=sum(r['accepted'] for r in rows))
Path('/tmp/hyperspatial-encodings-benchmark-resources.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
