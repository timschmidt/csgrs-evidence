"""Additional development-only tail/precision probes, not production evidence."""
from pathlib import Path
exec(Path('/tmp/hyperspatial-thompson-interval-probe.py').read_text().split('mp.mp.dps=140')[0])
rows=[]
for s,m,sign in itertools.product([-1,1],[F(0),F(1,2),1-F(1,10**100)],[-1,1]):
    result,record=advance(F(s),F(0),m,F(sign,9),128,False)
    for index,expected in [(0,F(s)),(1,F(0)),(3,F(0)),(4,F(0))]:
        lo,hi=result[index][0].exact();assert lo<=expected<=hi
        lo,hi=result[index][1].exact();assert lo<=0<=hi
    lo,hi=result[2][0].exact();assert lo*lo<=1-m<=hi*hi
    record.update(case='exact_forward_pole',s=s,m=str(m),sign=sign);rows.append(record)
small=F(1,10**60);s=(1-small*small)/(1+small*small);c=2*small/(1+small*small)
m=1-F(1,10**200)
for reverse,sign in itertools.product([False,True],[-1,1]):
    result,record=advance(s,c,m,F(sign,6 if reverse else 9),128,reverse)
    if not reverse: assert record['working_bits']>176
    record.update(case='tiny_initial_denominator',m=str(m),c=str(c),reverse=reverse,sign=sign)
    rows.append(record)
print(json.dumps(rows,indent=2))
Path('/tmp/hyperspatial-thompson-interval-boundary-probe.json').write_text(json.dumps(rows,indent=2)+'\n')
