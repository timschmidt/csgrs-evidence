import gzip, hashlib, io, json, tarfile
from pathlib import Path
files={}
for path in Path('/tmp').glob('hyperspatial-thompson-*'):
    if path.is_file() and path.suffix in {'.rs','.py','.log','.json','.md','.gz'} and path.name!='hyperspatial-thompson-research-manifest.json':
        files['diagnostics/'+path.name]=path.read_bytes()
probe=Path('/mnt/development/hyperspatial/thompson-interval-probe')
for path in probe.rglob('*'):
    if path.is_file(): files['native-prototype/'+str(path.relative_to(probe))]=path.read_bytes()
freeze=Path('/tmp/hyperspatial-atanh-final-source-freeze.json')
files['dependency-source-freeze.json']=freeze.read_bytes()
for name,want in json.loads(freeze.read_text())['sha256'].items():
    data=(Path('/mnt/development/hyperspatial/epsilon-candidate')/name).read_bytes()
    assert hashlib.sha256(data).hexdigest()==want,name
    files['dependency-source/'+name]=data
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(files.items())}
Path('/tmp/hyperspatial-thompson-research-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files['manifest.json']=Path('/tmp/hyperspatial-thompson-research-manifest.json').read_bytes()
archive=Path('/mnt/development/hyperspatial/thompson-research-20261019-boundaries.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
print(json.dumps({'files':len(files),'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
