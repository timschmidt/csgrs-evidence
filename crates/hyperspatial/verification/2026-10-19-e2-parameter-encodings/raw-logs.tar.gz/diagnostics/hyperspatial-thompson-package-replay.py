import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
freeze=json.loads(Path('/tmp/hyperspatial-thompson-scalar-regression-freeze-v3.json').read_text())
results=json.loads(Path('/tmp/hyperspatial-thompson-scalar-regressions-v3/results.json').read_text())
assert len(results)==8 and all(r['status']=='complete' and r['returncode']==0 for r in results)
files={}
for name,expected in freeze['sha256'].items():
 data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==expected,name
 files['candidate-source/'+name]=data
for pattern in ['hyperspatial-thompson-*','hsp-thompson-*']:
 for path in sorted(Path('/tmp').glob(pattern)):
  paths=path.rglob('*') if path.is_dir() else [path]
  for p in paths:
   if p.is_file() and p.suffix in ['.rs','.md','.json','.jsonl','.log','.py','.txt','.tsv']:
    files['diagnostics/'+str(p.relative_to('/tmp'))]=p.read_bytes()
for name in ['thompson-scalar-probe','thompson-interval-probe','thompson-encoding-consumer-probe']:
 base=root.parent/name
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.suffix in ['.rs','.toml','.lock','.md']:
   files['probes/'+name+'/'+str(p.relative_to(base))]=p.read_bytes()
for p in sorted(Path('/tmp/hyperspatial-encoding-posture').glob('*')):
 if p.is_file():files['unapplied-testing-draft/'+p.name]=p.read_bytes()
manifest={n:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for n,data in sorted(files.items())}
files['manifest.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
archive=root.parent/'thompson-research-20261019-cold-replay.tar.gz'
assert not archive.exists()
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for name,data in sorted(files.items()):
    entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(files)
 for name,data in files.items():assert tar.extractfile(name).read()==data,name
report=dict(archive=str(archive),entries=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),all_payloads_audited=True,frozen_source_paths=len(freeze['sha256']))
Path('/tmp/hyperspatial-thompson-replay-package-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(report)
