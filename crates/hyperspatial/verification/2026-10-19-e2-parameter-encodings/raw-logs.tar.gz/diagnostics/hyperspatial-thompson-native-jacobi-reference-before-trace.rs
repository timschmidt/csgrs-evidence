use hyperlattice::Complex;
use hyperreal::{Rational, Real};
use thompson_interval_probe::{FlowResult, forward, reverse};

fn overlaps(actual: &[[Rational; 2]; 2], expected: &Complex, bits: u32) {
    let limit = Rational::fraction(1, 2).unwrap().powi((bits + 16).into()).unwrap();
    for (bounds, component) in actual.iter().zip([&expected.re, &expected.im]) {
        let reference = component.certified_rational_interval(-(bits as i32)-32).unwrap();
        assert!(&reference[1] - &reference[0] < limit);
        assert!(bounds[0] <= reference[1] && reference[0] <= bounds[1]);
    }
}

fn check(result: &FlowResult, expected: &[Complex], bits: u32) {
    assert_eq!(result.bounds.len(), expected.len());
    for (actual, expected) in result.bounds.iter().zip(expected) { overlaps(actual, expected, bits); }
}

#[test]
fn forward_and_reverse_flows_match_independent_jacobi_epsilon_definitions() {
    let bits = 80;
    for parameter in [Real::zero(), "0.5".parse().unwrap()] {
        let h = Real::one() - &parameter;
        let axis_ratio = h.clone().sqrt().unwrap();
        let eccentricity = parameter.clone().sqrt().unwrap();
        let k = Real::elliptic_k(&parameter).unwrap();
        let e = Real::elliptic_e_complete(&parameter).unwrap();
        for sign in [-1, 1] {
            let w = Complex::new("0.25".parse().unwrap(), (Real::from(sign)*&h/Real::from(128)).unwrap());
            let (s,c,d) = w.clone().jacobi_sncndn(&parameter).unwrap();
            let chi = s.clone().atanh().unwrap()
                - (s.clone()*Complex::from(eccentricity.clone())).atanh().unwrap()*Complex::from(eccentricity.clone());
            let sigma = Complex::from(e.clone())
                - (Complex::from(k.clone())-w).jacobi_epsilon(&parameter).unwrap();
            let phi = chi.re.clone().inverse_isometric_latitude(&axis_ratio).unwrap();
            let sine = phi.clone().sin();
            let cosine = phi.clone().cos();
            let dn = (&h+&parameter*&cosine*&cosine).sqrt().unwrap();
            let meridian = phi.clone().elliptic_e(&parameter).unwrap()
                - (&parameter*sine*cosine/dn).unwrap();
            let forward_result = forward(&phi,&chi.im,&parameter,bits).unwrap();
            check(&forward_result,&[s.clone(),c.clone(),d.clone(),(&c/&d).unwrap(),
                sigma.clone()-Complex::from(meridian)],bits);
            // The inverse meridian uses the independent real inverse E and F.
            let a = (e.clone()-&sigma.re).inverse_elliptic_e(&parameter).unwrap();
            let meridian_w = k.clone()-a.elliptic_f(&parameter).unwrap();
            let (s0,c0,_) = meridian_w.jacobi_sncndn(&parameter).unwrap();
            let initial_phi = s0.try_atan2(c0).unwrap();
            let reverse_result = reverse(&initial_phi,&sigma.im,&parameter,bits).unwrap();
            check(&reverse_result,&[s,c,d],bits);
        }
    }
}
