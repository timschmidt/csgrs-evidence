//! Research only: bound the final atanh consumer, not merely the flow state.
use hyperlattice::Complex;
use hyperreal::{Rational, Real};
use thompson_interval_probe::reverse_from_northing;

type Interval = [Rational; 2];
type Box2 = [Interval; 2];

fn dyadic(bits: u32) -> Rational {
    Rational::fraction(1, 2).unwrap().powi(bits.into()).unwrap()
}

fn add(a: &Interval, b: &Interval) -> Interval {
    [&a[0] + &b[0], &a[1] + &b[1]]
}

fn subtract(a: &Interval, b: &Interval) -> Interval {
    [&a[0] - &b[1], &a[1] - &b[0]]
}

fn multiply(a: &Interval, b: &Interval) -> Interval {
    let values = [&a[0] * &b[0], &a[0] * &b[1], &a[1] * &b[0], &a[1] * &b[1]];
    [values.iter().min().unwrap().clone(), values.iter().max().unwrap().clone()]
}

fn enclose(value: &Real, bits: u32) -> Interval {
    let limit = dyadic(bits);
    let mut precision = -(bits as i32) - 16;
    loop {
        let interval = value.certified_rational_interval(precision).unwrap();
        if &interval[1] - &interval[0] <= limit { return interval; }
        precision *= 2;
        assert!(precision >= -16384, "external research precision schedule exhausted");
    }
}

fn distance_from(interval: &Interval, point: &Rational) -> Rational {
    if interval[1] < *point { point - &interval[1] }
    else if interval[0] > *point { &interval[0] - point }
    else { Rational::zero() }
}

fn atanh_box(z: &Box2, bits: u32) -> Option<Box2> {
    let zero = Rational::zero();
    let one = Rational::one();
    // The entire convex rectangle lies in the same analytic cut-free domain.
    if !(z[0][0] > -&one && z[0][1] < one || z[1][0] > zero || z[1][1] < zero) {
        return None;
    }
    let imaginary_distance = distance_from(&z[1], &zero);
    let minus_distance = distance_from(&z[0], &one).max(imaginary_distance.clone());
    let plus_distance = distance_from(&z[0], &-&one).max(imaginary_distance);
    if minus_distance.is_zero() || plus_distance.is_zero() { return None; }
    let half = Rational::fraction(1, 2).unwrap();
    let midpoint = Complex::new(
        Real::from((&z[0][0] + &z[0][1]) * &half),
        Real::from((&z[1][0] + &z[1][1]) * &half),
    ).atanh().unwrap();
    let radius = ((&z[0][1] - &z[0][0]) + (&z[1][1] - &z[1][0])) * half;
    // |f'|=1/(|1-z| |1+z|). L-infinity distances are lower bounds
    // on the factors; the L1 segment length is an upper bound on length.
    let error = radius * (minus_distance * plus_distance).inverse().unwrap();
    let offset = [-&error, error];
    Some([add(&enclose(&midpoint.re, bits + 8), &offset),
          add(&enclose(&midpoint.im, bits + 8), &offset)])
}

fn final_chi(northing: &Real, easting: &Real, m: &Real, bits: u32) -> (Box2, u32, u32) {
    let width = dyadic(bits);
    let eccentricity = m.clone().sqrt().unwrap();
    let mut state_bits = bits + 16;
    loop {
        assert!(state_bits <= 4096, "external flow precision schedule exhausted");
        let result = reverse_from_northing(northing, easting, m, state_bits).unwrap();
        let s = &result.bounds[0];
        if let Some(base) = atanh_box(s, state_bits) {
            let e = enclose(&eccentricity, state_bits + 16);
            let scaled = [multiply(&e, &s[0]), multiply(&e, &s[1])];
            if let Some(correction) = atanh_box(&scaled, state_bits) {
                let chi = [subtract(&base[0], &multiply(&e, &correction[0])),
                           subtract(&base[1], &multiply(&e, &correction[1]))];
                if chi.iter().all(|part| &part[1] - &part[0] <= width) {
                    return (chi, result.degree, result.working_bits);
                }
            }
        }
        state_bits *= 2;
    }
}

fn compare(label: &str, actual: &Box2, expected: &Complex, bits: u32) {
    for (part, (actual, expected)) in actual.iter().zip([&expected.re, &expected.im]).enumerate() {
        let reference = enclose(expected, bits + 24);
        assert!(&actual[1] - &actual[0] <= dyadic(bits), "{label} part {part} width");
        assert!(actual[0] <= reference[1] && reference[0] <= actual[1], "{label} part {part} disjoint");
    }
}

#[test]
fn final_inverse_chi_encloses_closed_spherical_form_near_poles_and_tiny_eastings() {
    let near_pole = (Real::pi() / Real::from(2)).unwrap() - "1e-60".parse::<Real>().unwrap();
    let cases = [
        ("equator edge", Real::zero(), (Real::one() / Real::from(6)).unwrap()),
        ("ordinary", "0.5".parse().unwrap(), "0.1".parse().unwrap()),
        ("negative", "-0.5".parse().unwrap(), "-0.1".parse().unwrap()),
        ("pole meridian", near_pole.clone(), Real::zero()),
        ("pole tiny positive", near_pole.clone(), "1e-120".parse().unwrap()),
        ("pole tiny negative", -near_pole, "-1e-120".parse().unwrap()),
    ];
    for (label, xi, eta) in cases {
        let sine = xi.clone().sin();
        let cosine = xi.clone().cos();
        let hyperbolic_sine = eta.clone().sinh().unwrap();
        let denominator = (&cosine * &cosine + &hyperbolic_sine * &hyperbolic_sine).sqrt().unwrap();
        let expected = Complex::new((sine / denominator).unwrap().asinh().unwrap(),
                                    hyperbolic_sine.try_atan2(cosine).unwrap());
        let (actual, degree, working_bits) = final_chi(&xi, &eta, &Real::zero(), 64);
        compare(label, &actual, &expected, 64);
        eprintln!("{label}: final 64 bits, degree {degree}, grid {working_bits}");
    }
}

#[test]
fn final_inverse_chi_matches_independently_prescribed_ellipsoidal_arguments() {
    for parameter in ["0.5", "0.99"] {
        let m: Real = parameter.parse().unwrap();
        let e = m.clone().sqrt().unwrap();
        let h = Real::one() - &m;
        let k = Real::elliptic_k(&m).unwrap();
        let complete_e = Real::elliptic_e_complete(&m).unwrap();
        for sign in [-1, 1] {
            let w = Complex::new(Real::from(sign) * "0.25".parse::<Real>().unwrap(),
                                 (Real::from(sign) * &h / Real::from(128)).unwrap());
            let (s, _, _) = w.clone().jacobi_sncndn(&m).unwrap();
            let expected = s.clone().atanh().unwrap()
                - Complex::from(e.clone()) * (Complex::from(e.clone()) * s).atanh().unwrap();
            let sigma = Complex::from(complete_e.clone())
                - (Complex::from(k.clone()) - w).jacobi_epsilon(&m).unwrap();
            let (actual, degree, working_bits) = final_chi(&sigma.re, &sigma.im, &m, 64);
            compare(parameter, &actual, &expected, 64);
            eprintln!("m={parameter}, sign={sign}: final 64 bits, degree {degree}, grid {working_bits}");
        }
    }
}
