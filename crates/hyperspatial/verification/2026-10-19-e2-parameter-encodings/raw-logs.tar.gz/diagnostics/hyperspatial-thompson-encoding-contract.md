# Thompson payload encoding acceptance probe

2026-10-19. Research only, before any new production node. Hyperreal owns exact
algebraic and inverse-trigonometric composition; P1/P2/P3/P6/P18/P19 apply.
A candidate parameter carrier must be mathematically finite for every decoded
field without trusting a serialized chart assertion. At the public encoder,
exact source values should survive the bounded-parameter reconstruction.

For the inverse meridian use an algebraic open-interval parameter rather than
tanh(atanh(v)): for -1<v<1, a=v/sqrt(1-v²), and decode v=a/sqrt(1+a²).
Every finite decoded a gives a strict -1<v<1. Positive root branches determine
the same sign and exact value. This avoids requiring an unrelated missing
hyperbolic inverse certificate. The meridian coordinate is xi=E(m)*v.

For 0<=m<1, r=sqrt(m/(1-m)); decode h=1/(1+r²),m=1-h. For closed normalized
time u∈[-1,1], tau=asin(u); decode u=sin(tau), so exact chart endpoints remain
available. The actual flow times are u/9 forward and u/6 reverse.

Missing acceptance: across all 22 scalar representation families and both
signs for v/u, prove zero exact residuals after these encodings. Include zero
and closed-time endpoints. Test the existing implementation before choosing
this payload. A mathematical identity is not a claim that the current scalar
certificate normalizer can already replay it. If a certificate is missing,
record the failure at its scalar owner; do not replace exact assertions with
numerical closeness or assume that an unverified metadata flag proves it.
