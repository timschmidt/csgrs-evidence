"""Exploratory dyadic interval ODE probe; not production or admission evidence.

Integer endpoints enclose rational Taylor arithmetic; the proposed analytic
majorant bounds the omitted tail. mpmath Newton/Jacobi values are independent
point comparisons, not certified reference intervals or physical accuracy.
"""
from dataclasses import dataclass
from fractions import Fraction as F
import itertools, json, math, time
import mpmath as mp

BITS=192
SCALE=1<<BITS
@dataclass(frozen=True)
class I:
    lo: int
    hi: int
    def __add__(a,b): return I(a.lo+b.lo,a.hi+b.hi)
    def __neg__(a): return I(-a.hi,-a.lo)
    def __sub__(a,b): return a+-b
    def __mul__(a,b):
        products=[a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi]
        return I(min(products)//SCALE,-((-max(products))//SCALE))
    def div_int(a,n):
        assert n>0
        return I(a.lo//n,-((-a.hi)//n))
    def div_positive(a,b):
        if b.lo<=0: raise ArithmeticError('refine positive denominator')
        candidates=[F(x*SCALE,y) for x in [a.lo,a.hi] for y in [b.lo,b.hi]]
        return I(math.floor(min(candidates)),math.ceil(max(candidates)))
    def exact(a): return [F(a.lo,SCALE),F(a.hi,SCALE)]

def interval(f):
    f=F(f)*SCALE
    return I(math.floor(f),math.ceil(f))
def root_interval(f):
    f=F(f); square=f.numerator*SCALE*SCALE; root=math.isqrt(square//f.denominator)
    return I(root,root+(root*root*f.denominator!=square))
def cadd(a,b): return (a[0]+b[0],a[1]+b[1])
def cneg(a): return (-a[0],-a[1])
def cmul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def cscale(a,b): return (a[0]*b,a[1]*b)
def ci(a): return (-a[1],a[0])
def div_int(a,n): return (a[0].div_int(n),a[1].div_int(n))
def conv(a,b,n):
    value=(interval(0),interval(0))
    for j in range(n+1): value=cadd(value,cmul(a[j],b[n-j]))
    return value

def advance(s,c,m,t,bits,reverse):
    global BITS,SCALE
    degree=bits+8
    for work in [bits+48,2*(bits+48),4*(bits+48),8*(bits+48)]:
        BITS=work;SCALE=1<<work
        zero=interval(0); mi=interval(m);h=interval(1-m);ti=interval(t)
        d=root_interval(1-m*s*s)
        initial=[interval(s),interval(c),d]
        try:
            if not reverse: initial += [zero if c==0 else interval(c).div_positive(d),zero]
        except ArithmeticError: continue
        # Actual initial states are proved <=1; intersect, never inflate the
        # majorant using rounded interval overestimates.
        initial=[I(max(-SCALE,v.lo),min(SCALE,v.hi)) for v in initial]
        series=[[(v,zero)] for v in initial]
        c2=[];d2=[];sc=[];sc2=[];d3=[]
        for n in range(degree):
            ss,cc,dd=series[:3]
            c2.append(conv(cc,cc,n));d2.append(conv(dd,dd,n));sc.append(conv(ss,cc,n))
            if reverse:
                d3.append(conv(dd,d2,n))
                deriv=[conv(cc,d3,n),cneg(conv(ss,d3,n)),cneg(cscale(conv(sc,d2,n),mi))]
            else:
                tt=series[3];sc2.append(conv(ss,c2,n))
                deriv=[conv(c2,d2,n),cneg(conv(sc,d2,n)),cneg(cscale(conv(sc2,dd,n),mi)),
                       cneg(cscale(conv(ss,tt,n),h)),cscale(tt[n],h)]
            for coefficients,value in zip(series,deriv): coefficients.append(div_int(ci(value),n+1))
        q=F(1,2) if reverse else F(1,3)
        assert abs(t)*3<=q
        tail=q**(degree+1)/(1-q)
        tail_units=math.ceil(tail*SCALE)
        result=[]
        for coefficients in series:
            value=coefficients[-1]
            for coefficient in reversed(coefficients[:-1]): value=cadd(cscale(value,ti),coefficient)
            result.append(tuple(I(v.lo-tail_units,v.hi+tail_units) for v in value))
        width=max(F(v.hi-v.lo,SCALE) for row in result for v in row)
        if width<=F(1,1<<bits): return result,dict(degree=degree,working_bits=work,width=str(width),tail=str(tail))
    raise AssertionError('prototype exhausted precision schedule')

# Exact corner arithmetic checks, independent Fraction expectations.
for ends in itertools.product(range(-3,4),repeat=4):
    a,b,c,d=ends
    if a>b or c>d:continue
    aa,bb=I(a,b),I(c,d);actual=aa*bb
    refs=[F(x*y,SCALE*SCALE) for x in [a,b] for y in [c,d]]
    assert F(actual.lo,SCALE)<=min(refs)<=max(refs)<=F(actual.hi,SCALE)
for f in [F(0),F(1,10**200),F(1,3),F(2),F(10**200)]:
    lo,hi=root_interval(f).exact();assert lo*lo<=f<=hi*hi

mp.mp.dps=140
def mpf(value):return mp.mpf(value.numerator)/value.denominator
def chi(w,m):
    s=mp.ellipfun('sn',w,m);e=mp.sqrt(m)
    return mp.atanh(s)-e*mp.atanh(e*s)
def sigma(w,m):
    s,c,d=[mp.ellipfun(k,w,m) for k in ['sn','cn','dn']]
    return mp.ellipe(mp.asin(s),m)-m*s*c/d
rows=[]
for m,s,c,reverse,sign in itertools.product([F(0),F(1,150),F(1,2),1-F(1,10**40)],
                                          [None],[None],[False,True],[-1,1]):
    for s,c in [(F(0),F(1)),(F(3,5),F(4,5)),(F(9999,10001),F(200,10001))]:
        assert s*s+c*c==1
        t=F(sign,6 if reverse else 9)
        start=time.monotonic();bounds,record=advance(s,c,m,t,96,reverse)
        mm,ss,cc,tt=map(mpf,[m,s,c,t]);h=1-mm;phi=mp.asin(ss);w0=mp.ellipf(phi,mm);d=mp.sqrt(1-mm*ss*ss)
        if reverse:
            target=sigma(w0,mm)+1j*h*tt
            w=mp.findroot(lambda w:sigma(w,mm)-target,w0+1j*tt*d*d,tol=mp.mpf('1e-125'))
        else:
            target=chi(w0,mm)+1j*h*tt
            w=mp.findroot(lambda w:chi(w,mm)-target,w0+1j*tt*cc*d,tol=mp.mpf('1e-125'))
        values=[mp.ellipfun(k,w,mm) for k in ['sn','cn','dn']]
        if not reverse:values += [values[1]/values[2],sigma(w,mm)-sigma(w0,mm)]
        for bound,value in zip(bounds,values):
            for enclosure,point in zip(bound,[mp.re(value),mp.im(value)]):
                lo,hi=map(mpf,enclosure.exact());assert lo<=point<=hi,(m,s,c,reverse,sign,lo,point,hi)
        record.update(m=str(m),s=str(s),c=str(c),t=str(t),reverse=reverse,seconds=time.monotonic()-start)
        rows.append(record);print(json.dumps(record),flush=True)
Path=None
with open('/tmp/hyperspatial-thompson-interval-probe.json','w') as output:
    json.dump(dict(rows=rows,source='Derived polynomial equations; mpmath Thompson/Jacobi point comparisons',
                   limitations=__doc__,reference_decimal_digits=mp.mp.dps),output,indent=2)
