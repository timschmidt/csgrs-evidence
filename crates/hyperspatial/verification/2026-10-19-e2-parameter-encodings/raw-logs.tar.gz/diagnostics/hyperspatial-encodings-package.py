import gzip
import hashlib
import io
import json
from pathlib import Path
import platform
import re
import subprocess
import tarfile

root = Path('/mnt/development/hyperspatial/csgrs')
candidate = Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
out = root / 'crates/hyperspatial/verification/2026-10-19-e2-parameter-encodings'
jobs_dir = Path('/tmp/hyperspatial-encodings-final-verification')
jobs = json.loads(Path('/tmp/hyperspatial-encodings-final-jobs.json').read_text())
freeze = json.loads(Path('/tmp/hyperspatial-encodings-final-source-freeze.json').read_text())
results = {}
for label, job in jobs.items():
    rows = json.loads((jobs_dir / label / 'results.json').read_text())
    assert len(rows) == len(job['commands']), (label, 'unfinished commands')
    assert all(row['status'] == 'complete' and row['returncode'] == 0 for row in rows), label
    results[label] = rows
for name, expected in freeze['sha256'].items():
    for base in [root, candidate]:
        assert hashlib.sha256((base / name).read_bytes()).hexdigest() == expected, (str(base), name)
integration = json.loads(Path('/tmp/hyperspatial-encodings-root-integration.json').read_text())
assert integration['all_frozen_paths_match'] and integration['frozen_path_count'] == 741
root_checks = json.loads(Path('/tmp/hyperspatial-encodings-root-validation.json').read_text())
assert len(root_checks['checks']) == 15 and all(row['returncode'] == 0 for row in root_checks['checks'])
directed = json.loads(Path('/mnt/development/hyperspatial/encodings-directed-initial/report.json').read_text())
assert not directed['failures'] and directed['executions'] == 176
asan = json.loads(Path('/mnt/development/hyperspatial/encodings-asan-initial/report.json').read_text())
assert len(asan['campaigns']) == 1 and asan['campaigns'][0]['target'] == 'parameter_encodings'
for campaign in asan['campaigns']:
    assert campaign['returncode'] == 0
    mutation = campaign['mutation_evidence']
    assert mutation['mutated'] and mutation['completed_runs'] > mutation['initialized_runs']
coverage = json.loads(Path('/mnt/development/hyperspatial/thompson-domain-coverage-target/coverage.json').read_text())
assert coverage['totals']['lines']['percent'] >= 95
for key in ['native_inverse', 'native_atan2', 'native_atan_deferred', 'native_parameter_ring']:
    assert coverage[key]['physical_executable_lines']['percent'] >= 95, key
for key in ['native_elliptic', 'native_legendre', 'native_inverse_legendre', 'native_jacobi',
            'native_complex_jacobi', 'native_square_quotient', 'native_relations',
            'native_complex_elementary', 'native_parameter_domain']:
    assert coverage[key]['totals']['lines']['percent'] >= 95, key
for label, report in [('directed', directed), ('asan', asan)]:
    for name, expected in report['source_sha256'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, (label, name)
for value in coverage.values():
    if isinstance(value, dict) and 'source_sha256' in value:
        for name, expected in value['source_sha256'].items():
            assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for name, expected in coverage['source_sha256'].items():
    assert hashlib.sha256((root / 'crates/hyperspatial' / name).read_bytes()).hexdigest() == expected, name

out.mkdir(parents=True, exist_ok=True)
def write_json(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
for name, value in [('commands.json', jobs), ('process-exits.json', results), ('source-freeze.json', freeze),
                    ('integration.json', integration), ('root-validation.json', root_checks),
                    ('directed-report.json', directed), ('asan.json', asan), ('coverage.json', coverage)]:
    write_json(name, value)
resources = json.loads(Path('/tmp/hyperspatial-encodings-benchmark-resources.json').read_text())
assert resources['returncode'] == 0 and resources['rows'] == 220 and resources['accepted'] == 2200
write_json('benchmark-resources.json', resources)
for name, path in [('bench.json', jobs_dir / 'native/12.log'),
                   ('bench-msrv.json', jobs_dir / 'msrv_native/11.log'),
                   ('bench-standalone.json', Path('/tmp/hyperspatial-encodings-benchmark-standalone.log'))]:
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    assert len(rows) == 220 and all(row['accepted'] == row['repeats'] for row in rows), (name, len(rows))
    write_json(name, rows)
def count_tests(path):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())
    return dict(suites=len(rows), passed=sum(int(row[1]) for row in rows),
                failed=sum(int(row[2]) for row in rows), ignored=sum(int(row[3]) for row in rows))
counts = {label: {path.name: count_tests(path) for path in sorted((jobs_dir / label).glob('*.log'))}
          for label in jobs}
counts['reused_msrv_native_preflight'] = count_tests(Path('/tmp/hyperspatial-encodings-msrv-native-v1.log'))
write_json('test-counts.json', counts)
preflight = dict(
    scope='Previously completed checks on the unchanged final-source candidate are reused; no per-process timestamps are inferred.',
    candidate_git_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=candidate, text=True).strip(),
    overlay_baseline=freeze['baseline'],
    directed_source_hashes=len(directed['source_sha256']), asan_source_hashes=len(asan['source_sha256']),
    retained_logs=['hyperspatial-encodings-msrv-native-v1.log', 'hyperspatial-encodings-directed-v1.log',
                   'hyperspatial-encodings-asan-v1.log', 'hyperspatial-encodings-zizmor-v1.log',
                   'hyperspatial-encodings-fuzz-check-v1.log', 'hyperspatial-encodings-clippy-v1.log'],
    source_freeze='diagnostics/hyperspatial-encodings-posture-freeze-v1.json',
    caution='Report git revisions identify the detached checkout base, not the full overlay; source hashes identify executed code.')
write_json('reused-preflight.json', preflight)

def command(*args):
    return subprocess.check_output(args, cwd=root, text=True).strip()
changed = set(command('git', 'diff', '--name-only').splitlines())
changed.update(command('git', 'ls-files', '--others', '--exclude-standard').splitlines())
changed = {name for name in changed if not name.startswith('crates/hyperspatial/verification/')}
source_paths = changed | set(freeze['sha256'])
cpu = json.loads(Path('/tmp/hyperspatial-epsilon-shared-source-freeze.json').read_text())['cpu']
metadata = dict(baseline=command('git', 'rev-parse', 'HEAD'), branch=command('git', 'branch', '--show-current'),
                compiler=command('rustc', '-vV'), msrv=command('rustc', '+1.95.0', '-vV'),
                nightly=command('rustc', '+nightly', '-vV'), platform=platform.platform(), cpu=cpu,
                environment={'PATH_additions': ['/tmp/hyperspatial-build-tools/usr/bin', '/tmp/hyperspatial-fuzz-tools/bin'],
                             'GMP_MPFR_SYS_CACHE': '/tmp/hyperspatial-gmp-cache',
                             'load': 'Concurrent validation; no comparative speed ratio claimed'},
                source_sha256={name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(source_paths)})
write_json('source-metadata.json', metadata)
files = {}
for pattern in ['hyperspatial-encodings*', 'hyperspatial-thompson*']:
    for path in sorted(Path('/tmp').glob(pattern)):
        if path.name.startswith(('hyperspatial-thompson-forward', 'hyperspatial-thompson-old-wire')):
            continue  # A separate, later native candidate is not this increment.
        paths = path.rglob('*') if path.is_dir() else [path]
        for item in paths:
            if item.is_file() and item.suffix in ('.log', '.json', '.jsonl', '.txt', '.md', '.py', '.rs', '.tsv', '.stdout', '.stderr', '.lock', '.toml'):
                files['diagnostics/' + str(item.relative_to('/tmp'))] = item.read_bytes()
for directory in ['encodings-directed-initial', 'encodings-asan-initial']:
    base = Path('/mnt/development/hyperspatial') / directory
    for path in sorted(base.rglob('*')):
        if path.is_file():
            files['campaigns/' + directory + '/' + str(path.relative_to(base))] = path.read_bytes()
for path in sorted((candidate / 'crates/hyperspatial/fuzz/artifacts/parameter_encodings').glob('*')):
    if path.is_file():
        files['sanitizer-artifacts/' + path.name] = path.read_bytes()
for path in Path('/mnt/development/hyperspatial/thompson-domain-coverage-target').glob('*'):
    if path.is_file() and path.suffix in ('.json', '.txt', '.log'):
        files['coverage/' + path.name] = path.read_bytes()
for directory in ['thompson-scalar-probe', 'encodings-baseline-probe', 'thompson-inverse-chi-probe']:
    base = Path('/mnt/development/hyperspatial') / directory
    for pattern in ['Cargo.toml', 'Cargo.lock', 'src/**/*.rs', 'tests/**/*.rs']:
        for path in base.glob(pattern):
            files['external-probes/' + directory + '/' + str(path.relative_to(base))] = path.read_bytes()
# The exact earlier frozen failures are retained separately; do not reconstruct
# lost bytes or label later fixture reconstructions as those earlier snapshots.
for filename in ['thompson-research-20261019-cold-replay.tar.gz',
                 'thompson-research-20261019-encodings-regressions-v1.tar.gz']:
    files['earlier-archives/' + filename] = (Path('/mnt/development/hyperspatial') / filename).read_bytes()
for name in sorted(source_paths):
    files['source-snapshot/' + name] = (root / name).read_bytes()
files['source-snapshot/pending.patch'] = subprocess.check_output(['git', 'diff', '--binary'], cwd=root)
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(files.items())}
write_json('raw-log-manifest.json', manifest)
with (out / 'raw-logs.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(out / 'raw-logs.tar.gz', 'r:gz') as archive:
    assert len(archive.getmembers()) == len(manifest)
    for name, expected in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'], name
print(json.dumps(dict(directory=str(out), files=len(files), raw_bytes=sum(map(len, files.values())),
                      archive_bytes=(out / 'raw-logs.tar.gz').stat().st_size,
                      archive_sha256=hashlib.sha256((out / 'raw-logs.tar.gz').read_bytes()).hexdigest()), indent=2))
