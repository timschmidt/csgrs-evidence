import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
out = Path('/tmp/hyperspatial-thompson-scalar-regressions-v2')
out.mkdir(exist_ok=True)
freeze = json.loads(Path('/tmp/hyperspatial-thompson-scalar-regression-freeze-v2.json').read_text())
env = dict(os.environ, CARGO_TARGET_DIR='/mnt/development/hyperspatial/thompson-scalar-target',
           CARGO_PROFILE_TEST_OPT_LEVEL='1', CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',
           CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',
           GMP_MPFR_SYS_CACHE='/tmp/hyperspatial-gmp-cache',
           TMPDIR='/mnt/development/hyperspatial/verification-tmp')
env['PATH'] = '/tmp/hyperspatial-build-tools/usr/bin:' + env['PATH']
commands = [
    ['cargo', 'test', '--locked', '-p', 'hyperreal', '--all-features'],
    ['cargo', 'test', '--locked', '-p', 'hyperlattice', '--all-features'],
    ['cargo', 'test', '--locked', '-p', 'hyperlimit', '--all-features'],
    ['cargo', 'test', '--locked', '-p', 'hyperspatial', '--all-features'],
    ['cargo', 'test', '--locked', '-p', 'hypercurve', '--test', 'hypercurve_circle_predicates',
     '--test', 'hypercurve_curve', '--test', 'hypercurve_contour'],
    ['cargo', 'clippy', '--locked', '-p', 'hyperreal', '-p', 'hyperlattice', '-p', 'hyperlimit',
     '-p', 'hyperspatial', '--all-targets', '--all-features', '--', '-D', 'warnings'],
    ['cargo', 'fmt', '--all', '--', '--check'],
    ['git', 'diff', '--check'],
]
results = []
def check_source():
    for name, digest in freeze['sha256'].items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest, name
for index, command in enumerate(commands):
    check_source()
    row = dict(command=command, status='running', started_unix=time.time())
    results.append(row)
    (out/'results.json').write_text(json.dumps(results, indent=2)+'\n')
    started = time.monotonic()
    with (out/f'{index}.log').open('w') as log:
        run = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row.update(status='complete', returncode=run.returncode, elapsed_seconds=time.monotonic()-started)
    (out/'results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(index, run.returncode, flush=True)
    if run.returncode:
        raise SystemExit(run.returncode)
    check_source()
