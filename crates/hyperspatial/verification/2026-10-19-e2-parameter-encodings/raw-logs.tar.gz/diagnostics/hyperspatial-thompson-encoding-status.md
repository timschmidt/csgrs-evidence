# Bounded parameter encoding investigation, 2026-10-19

This is an isolated Hyperreal experiment, not an accepted production payload.
The root hyperspatial branch has committed epsilon (`7042b1ef2`) and complex
atanh (`2aaf10dea`); the root worktree is clean. Its runtime source is unchanged
by this experiment.

The original interval prototype and its ten previously passing tests remain
unchanged. A new encoding acceptance on that prototype's original dependency
fails: direct rational parameter reconstruction works in all 22 families,
but inserting a generic square root loses the available exact certificate in
21. The initial meridian encoding has the same gap. All sin(asin) time
encodings already work.

The scalar candidate overlays the 732-file atanh source on a detached
`7042b1ef2` worktree. It now changes five production files and adds eight
private guard tests. Roots remain separate relation atoms; a sufficient
zero proof splits P-Q into nonnegative sides and proves P²=Q². Exact
polynomial division can remove a common factor for this zero-only claim,
without asserting the factor nonzero. Rational root squares collapse while
merging sorted monomials, before exceeding the unchanged retained degree cap.
The existing domain, inverse, cancellation, work, coefficient, atom and term
limits remain. No expression node, wire tag, physical model or numerical
tolerance is added.

The unchanged public encoding acceptance passes all 22 families, both signed
meridian/time cases, and the time endpoints. All 955 scalar library tests
pass after correcting a new fixture's domain precondition. Its raw noninteger
Ratio had no immediate sign witness: the fixture must establish that witness
before assuming an admitted root relation. Unknown-root fixtures are retained.
A speculative constant-denominator normalization did not fix that fixture
and was removed. Both failed full-library runs and that variant remain.

Cold JSON replay is still an unmet research acceptance test. Of 44 signed
cases, parameter/meridian certificates pass for 2 cold, 42 after structural
fact inspection (ConstOffset = pi-3 remains), and 44 after display or
certified -128-bit refinement. Time certificates pass for all 44 cold.
Nine zero/near-endpoint replay cases pass. Refinement supplies certified sign
facts; numerical closeness never replaces the final exact zero residual.
The failing cold test is unchanged. A future checked payload must explicitly
specify how its domain evidence is replayed; no cache or serialized assertion
may be treated as proof. The normalizer is currently a non-numerical bounded
proof attempt. Do not silently insert numeric refinement into that contract.

All-feature Hyperreal/Hyperlattice/Hyperlimit/Hyperspatial and selected
Hypercurve regressions, strict Clippy and formatting are running against
`hyperspatial-thompson-scalar-regression-freeze.json` (734 candidate files).
Their success, if obtained, will establish regression evidence only; it will
not close the cold replay gap. The independent probe's seven source/manifest
files are also hashed in that freeze. Do not edit frozen sources during the
run. Review the new proof attempt's ordering and work consumption as well as
the larger downstream matrices before integration.

The powi(2) diagnostic remains 1/22: generic powi deliberately uses an exp/ln
carrier and is separate from the literal-product root identities fixed here.
Do not claim that this experiment restores that different certificate.
