# Next increment research: Thompson/Lee rectification

Read 2026-10-19 while the complex Jacobi increment runs validation. These are
design notes, not implemented or admitted behavior. Production stays native
and Real-backed; external code remains algorithmic reference/development oracle.

Karney's paper, equations (30)-(31), uses w=u+iv as an intermediate coordinate:

    chi = atanh(sn(w|m)) - e*atanh(e*sn(w|m)), e=sqrt(m)
    zeta = pi/(2*E(m)) * (E(m) - epsilon(K(m)-w|m)).

Here chi=psi+i*lambda and zeta is normalized northing+i*easting. E(m) without
an argument is the complete Legendre integral; epsilon is Jacobi's epsilon,
not the amplitude-parameter incomplete Legendre E. Forward and inverse need
different inversions of these intermediate maps. Bare Newton iteration does
not establish an enclosure or unique root. Source:
https://arxiv.org/abs/1002.1417 (sections 3 and 5).

Current GeographicLib source uses an unnormalized sigma=xi+i*eta, then multiplies
by a*k0. Its real formulas use u|m and v|1-m with s,c,d and S,C,D:

    denominator = m*c² + (1-m)*C²
    xi  = epsilon(u|m) - m*s*c*d/denominator
    eta = v-epsilon(v|1-m) + (1-m)*S*C*D/denominator.

This source is MIT/X11 licensed, unlike old 2009 documentation encountered
in search. It currently requires positive flattening. Sources:
https://raw.githubusercontent.com/geographiclib/geographiclib/main/src/TransverseMercatorExact.cpp
https://raw.githubusercontent.com/geographiclib/geographiclib/main/LICENSE.txt

Its standard cut is associated with the equatorial branch at
lambda=(1-e)*pi/2; extension changes the selected sheet, and a global reverse
operation can have multiple projected preimages for one geographical point.
Hyperspatial must name its admitted chart and inverse image. Sphere behavior
should use the existing exact spherical chart; a generic oblate formula has
divergent intermediate constants in that limit. Source:
https://raw.githubusercontent.com/geographiclib/geographiclib/main/include/GeographicLib/TransverseMercatorExact.hpp

## Candidate epsilon prerequisite: working derivation

The DLMF gives epsilon'=dn², epsilon(u)=E(am(u)|m), and the quasi-addition
formula epsilon(x+y)=epsilon(x)+epsilon(y)-m*sn(x)*sn(y)*sn(x+y).
Its modulus k is converted here to parameter m=k². Source:
https://dlmf.nist.gov/22.16 (especially 22.16.17, 22.16.27).

The following is a local algebraic derivation to validate independently before
implementation, not a claim that an existing public API already supplies it.
For 0<m<1, use the current rectangular triplets at x|m and y|h, h=1-m,
and Q=C²+m*s²*S². Differentiate S*D/C to obtain

    epsilon(i*y|m) = i*(y-epsilon(y|h)+S*D/C).

Substitute this and the rectangular sn in quasi-addition. The apparent 1/C
singularity cancels because Q-m*s²=d²*C², giving

    Re epsilon(x+i*y|m) = epsilon(x|m) + m*s*c*d*S²/Q
    Im epsilon(x+i*y|m) = y-epsilon(y|h) + d²*S*C*D/Q.

This finite form matters at C=0, s!=0. At actual poles, the final denominator
still requires its domain witness. For m<0, set r=sqrt(h) and take the
reciprocal triplet at r*y|1/h. The complementary functions are (S/r,D,C).
Differentiation with zero initial value gives

    epsilon(y|h) = r*epsilon(r*y|1/h)+(1-h)*y.

Thus y-epsilon(y|h)=r*(r*y-epsilon(r*y|1/h)); use the existing stable
negative-parameter Q. For m=0, epsilon(z|0)=z. Check signs and all finite
quarter-period cases against an independent oracle before admitting this.

Extend the existing ODE oracle with epsilon'=dn², epsilon(0)=0. Its coefficient
recurrence is independent of the rectangular expression. Reuse neither this
epsilon formula nor the Thompson mapping in the reference. Retain real-axis
Legendre composition, quasi-periods, parity/conjugation, very large periods,
tiny offsets, poles, serialization if applicable, and native exact consumers.

## Inverse design questions to resolve before code

Hyperreal owns certified scalar refinement; Hyperlattice owns complex assembly;
Hyperspatial owns projection/frame identity, chart membership and receipts.
There must be no Hyperreal dependency on Hyperlattice. A two-coordinate retained
root needs a mathematical uniqueness/domain proof, shared certified enclosures,
cancellation and a specified resource contract. Repeated Newton points without
such evidence cannot become exact Real outputs. Preserve correlation and the
defined inverse relation through forward/reverse composition. Qualify model
accuracy independently of numerical enclosure width. An oblate first domain
must disclose the still-open prolate/extended-sheet cases explicitly.
