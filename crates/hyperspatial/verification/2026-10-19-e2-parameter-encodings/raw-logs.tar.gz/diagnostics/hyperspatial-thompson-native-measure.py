import hashlib, json, os, subprocess, time
from pathlib import Path
root=Path('/mnt/development/hyperspatial/thompson-interval-probe')
executable=Path('/mnt/development/hyperspatial/thompson-interval-target/release/cost')
log=Path('/tmp/hyperspatial-thompson-native-cost-standalone.log')
start=time.monotonic()
with log.open('w') as output:
 child=subprocess.Popen([str(executable)],cwd=root,stdout=output,stderr=subprocess.STDOUT)
 _,status,usage=os.wait4(child.pid,0)
 child.returncode=os.waitstatus_to_exitcode(status)
record=dict(returncode=child.returncode,elapsed_seconds=time.monotonic()-start,
 peak_rss_kib=usage.ru_maxrss,executable=str(executable),executable_bytes=executable.stat().st_size,
 executable_sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),
 source_sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
  for p in sorted(root.rglob('*')) if p.is_file()},
 dependency_source_freeze='/tmp/hyperspatial-atanh-final-source-freeze.json',
 scope='Standalone research interval-cost executable; excludes compilation. Native only; not an exact-function API, allocation count, native total-work/heap bound, physical-accuracy claim, or comparative benchmark.')
Path('/tmp/hyperspatial-thompson-native-cost-resources.json').write_text(json.dumps(record,indent=2)+'\n')
rows=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
assert child.returncode==0 and len(rows)==60 and all(row['accepted'] for row in rows)
print(json.dumps({k:v for k,v in record.items() if k!='source_sha256'},indent=2))
print('rows',len(rows),'materialized scalar intervals',sum(row['components'] for row in rows))
