import json,subprocess,os,hashlib,time
from pathlib import Path
root=Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
target=Path('/mnt/development/hyperspatial/thompson-domain-coverage-target')
out=Path('/tmp/hyperspatial-thompson-domain-coverage-v2');out.mkdir(exist_ok=True)
target.mkdir(exist_ok=True)
profiles=out/'profiles';profiles.mkdir(exist_ok=True)
freeze=json.loads(Path('/tmp/hyperspatial-encodings-posture-freeze-v1.json').read_text())
def check():
    for p,expected in freeze['sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==expected,p
check()
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_PROFILE_TEST_OPT_LEVEL='1',CARGO_PROFILE_TEST_DEBUG_ASSERTIONS='true',CARGO_PROFILE_TEST_OVERFLOW_CHECKS='true',TMPDIR='/mnt/development/hyperspatial/verification-tmp',GMP_MPFR_SYS_CACHE='/tmp/hyperspatial-gmp-cache',RUSTFLAGS='-C instrument-coverage',LLVM_PROFILE_FILE=str(profiles/'%p-%m.profraw'))
env['PATH']='/tmp/hyperspatial-build-tools/usr/bin:'+env['PATH']
command=['cargo','test','--locked','-p','hyperreal','--all-features','--lib','--test','bounded_parameter_encodings']
with (out/'build.log').open('w') as log:
    build=subprocess.check_output(command+['--no-run','--message-format=json'],cwd=root,env=env,text=True,stderr=log)
(out/'build.jsonl').write_text(build)
objects=[]
for line in build.splitlines():
    event=json.loads(line)
    if event.get('reason')=='compiler-artifact' and event.get('executable') and event['profile']['test']:objects.append(event['executable'])
with (out/'tests.log').open('w') as log:subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
sysroot=Path(subprocess.check_output(['rustc','--print','sysroot'],text=True).strip())
host=next(x.split(': ',1)[1] for x in subprocess.check_output(['rustc','-vV'],text=True).splitlines() if x.startswith('host:'))
llvm=sysroot/'lib/rustlib'/host/'bin'
merged=out/'merged.profdata'
subprocess.run([str(llvm/'llvm-profdata'),'merge','-sparse',*map(str,profiles.glob('*.profraw')),'-o',str(merged)],check=True)
args=[objects[0],f'--instr-profile={merged}']
for obj in objects[1:]:args+=['--object',obj]
export=json.loads(subprocess.check_output([str(llvm/'llvm-cov'),'export','--summary-only',*args],text=True))
(out/'export.json').write_text(json.dumps(export))
sources=[root/'crates/hyperreal/src/computable/node'/name for name in ['ring_native_domain.rs','ring_native_relations.rs','ring_native_projection.rs','ring_polynomial.rs','ring_quotient.rs']]
shown=subprocess.check_output([str(llvm/'llvm-cov'),'show',*args,*map(str,sources),'--show-instantiations=false','--show-line-counts-or-regions'],text=True)
(out/'annotated.txt').write_text(shown)
files={f['filename']:f['summary'] for d in export['data'] for f in d['files'] if Path(f['filename']) in sources}
report=dict(command=command,files=files,sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
check()
print(json.dumps({k:v['lines'] for k,v in files.items()},indent=2),flush=True)
