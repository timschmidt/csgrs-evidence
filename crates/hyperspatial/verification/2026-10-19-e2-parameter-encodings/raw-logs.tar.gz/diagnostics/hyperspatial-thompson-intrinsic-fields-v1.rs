//! Separate next-node research: finite decoded fields, not a production chart API.
use hyperreal::{Rational, Real, RealSign};

fn opaque_zero() -> Real {
    Real::e().sin().powi(2.into()).unwrap() + Real::e().cos().powi(2.into()).unwrap() - Real::one()
}

#[test]
fn intrinsic_parameter_formulas_accept_unresolved_and_extreme_finite_fields() {
    let zero = opaque_zero();
    assert_eq!(zero.certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION).sign(), None);
    let tiny: Real = "1e-1000".parse().unwrap();
    let cases = [
        ("zero", Real::zero()), ("one", Real::one()), ("minus one", -Real::one()),
        ("pi", Real::pi()), ("minus pi", -Real::pi()),
        ("huge", "1e1000".parse().unwrap()), ("minus huge", "-1e1000".parse().unwrap()),
        ("opaque zero", zero.clone()), ("opaque tiny positive", &zero + &tiny),
        ("opaque tiny negative", zero - tiny),
    ];
    let width = Rational::fraction(1, 1_u64 << 48).unwrap();
    for (label, field) in cases {
        let denominator = Real::one() + &field * &field;
        let h = (Real::one() / &denominator).expect(label);
        let v = (&field / denominator.sqrt().expect(label)).expect(label);
        assert_eq!(h.certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION).sign(), Some(RealSign::Positive), "{label}");
        for (kind, value) in [("h", h), ("v", v.clone())] {
            let [lo, hi] = value.certified_rational_interval(-64).expect(label);
            assert!(hi.clone() - &lo < width, "{label}: {kind}");
            let lower = if kind == "h" { Rational::zero() } else { -Rational::one() };
            assert!(lo >= lower - &width && hi <= Rational::one() + &width, "{label}: {kind}");
        }
        // Diagnostic only: construction of a later inverse trig consumer can
        // have a separate domain-evidence obligation; do not assume success.
        eprintln!("{label}: asin construction {}", if v.asin().is_ok() { "accepted" } else { "declined" });
    }
}
