import json,re,subprocess,hashlib
from pathlib import Path
root=Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
log=Path('/tmp/hyperspatial-encodings-final-verification/coverage/1.log').read_text()
objects=sorted(set(re.findall(r'Running [^\n]*\((/[^\n()]+)\)',log)))
assert len(objects)>=30,len(objects)
llvm='/home/tim/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-cov'
args=[llvm,'export','--summary-only','--dump',objects[0],'--instr-profile=/mnt/development/hyperspatial/thompson-domain-coverage-target/hyperspatial.profdata']
for x in objects[1:]:args+=['--object',x]
out=Path('/tmp/hyperspatial-encodings-coverage-mismatch-audit')
out.mkdir(exist_ok=True)
with (out/'export.json').open('w') as o,(out/'dump.log').open('w') as e:
 p=subprocess.run(args,cwd=root,stdout=o,stderr=e)
(out/'command.json').write_text(json.dumps(dict(command=args,returncode=p.returncode,object_count=len(objects),object_sha256={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in objects}),indent=2)+'\n')
print('returncode',p.returncode,'objects',len(objects));print((out/'dump.log').read_text()[:5000])
