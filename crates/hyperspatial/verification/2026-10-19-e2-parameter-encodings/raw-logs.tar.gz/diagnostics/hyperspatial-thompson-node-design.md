# Candidate intrinsically valid Thompson flow nodes

Development notes, 2026-10-19. Not an admitted implementation. Builds on
`hyperspatial-thompson-flow-design.md`; the polynomial equations, analytic
majorant and proposed chart still need implementation-connected review.
Karney's defining equations are the source of the map identities:
https://arxiv.org/html/1002.1417v3 . The following node parameterization is an
original design proposal, not a claim made in that paper.

A serialized scalar node must remain defined for every representable field.
Do not serialize an unchecked user-domain assertion or forge positive signs
from a coordinate wrapper. Native normalized parameters can enforce the local
chart intrinsically, without floating-point or external numerical backends.

## Forward proposal

Fields are three arbitrary finite real arguments phi, r and tau, and a finite
component enum. Set h=1/(1+r²), m=r²/(1+r²), t=sin(tau)/9. Thus 0<=m<1,
h>0 and |t|<=1/9 hold for every decoded node. The corresponding longitude is
lambda=h*t. Phi may be any unwrapped real amplitude; coordinate latitude
validation remains in Hyperspatial.

At the real meridian use S=sin(phi), C=cos(phi), D=sqrt(h+m*C²), T=C/D,
and sigma0=E(phi|m)-m*S*C/D. Every state magnitude is at most one. E can use
log(h)=-ln(1+r²), which is a valid existing Legendre parameter for every r.
The polynomial flow is

    S'=i*C²*D², C'=-i*S*C*D², D'=-i*m*S*C²*D,
    T'=-i*h*S*T, sigma'=i*h*T.

With the earlier Y'=Y^4 majorant, q<=1/3. A normalized northing/easting pair
is Re/Im sigma(t), as an exact function node, not a stored finite estimate.
A conventional scalar constructor can validate 0<=m<1 and |lambda|<=h/9,
then encode r=sqrt(m/h), tau=asin(9*lambda/h). Those transformations must retain
exact defining relations and their cancellation/resource behavior. A sphere
and poles deserve their existing direct paths. No public function name has
been chosen; it should identify the normalized mathematical operation without
introducing frame/units semantics into Hyperreal.

## Reverse proposal

Use fields r, alpha and beta with h,m as above, xi=E(m)*tanh(alpha),
eta=h*sin(beta)/6 and t=sin(beta)/6. This guarantees -E<xi<E and |eta|<=h/6
for every finite decoded input. The *open* xi interval matters: sin(alpha)
would include xi=+-E, whose nonzero eta continuations lie on atanh cuts.
The coordinate layer can encode alpha=atanh(xi/E) after proving strict
membership; exact pole images are handled separately.

Let a=inverse_E(E-xi|m), w=K-F(a|m), and initialize the real S,C,D triplet at w.
Then C,D>0 and each state magnitude is <=1. Continue

    S'=i*C*D³, C'=-i*S*D³, D'=-i*m*S*C*D².

Here q<=1/2. The previously proposed proof gives Re C>0, Re D>0, and Im S
with the sign of eta, so S and sqrt(m)*S avoid their principal atanh cuts.
Recover chi=atanh(S)-sqrt(m)*atanh(sqrt(m)*S), using the native complex owner,
then inverse-isometric latitude and the longitude-chart check in Hyperspatial.
The enclosing inverse rectangle is not the exact forward image.

The sign proof can be retained by these intrinsically valid nodes; it must not
be attached to a more general Jacobi expression merely because a wrapper says
its input is in range. Zero time can use a direct real path, but that path must
retain the open latitude/amplitude facts needed by the next scalar operation.
Special-case reconstruction cannot discard these proofs. Exact polynomial
relations S²+C²=1 and D²+m*S²=1 are possible native certificates keyed by the
same owned flow specification; they require independent relation/serialization
and cancellation tests, like the earlier Jacobi extension.

## Refinement and resources to investigate

Use outward dyadic interval coefficients for the polynomial Taylor recurrence.
Intersect initial real-state enclosures with the independently proven [-1,1]
bounds; do not inflate the common majorant to 2 and silently keep its old
radius. Parameter intervals intersect [0,1] by the intrinsic formula. D and
other positive denominators must be evaluated by their stable positive forms.

Choose N from the analytic geometric tail (q<=1/3 or 1/2), enclose every
coefficient operation and Horner step, and refine working precision until the
combined interval plus tail meets the requested output width. Rounding error
must be measured by the interval arithmetic, not guessed from a fixed number
of guard bits. A finite N computation converges as initial/working precision
increases; cancellation must suppress partial cache publication and permit
recovery. State sharing needs an owned identity and cache lifecycle contract,
not a pointer key that outlives its inputs. Do not claim a total-work or
heap-byte bound merely from an N or precision limit.

A new node requires every serializer/decoder/normalizer/approximation/metadata
match and the scalar representation inventory to be updated. Tests need
independent map values, near-domain boundaries, near poles, parameters near
0/1, tiny offsets, precision order, shared-state concurrency and all downstream
receipts. Native ordinary performance, allocation/peak memory and binary-size
evidence precede retention. Prototype point agreement alone is insufficient.

## Outward-arithmetic prototype observations

`hyperspatial-thompson-interval-probe.py` now evaluates the polynomial flows
using common-grid dyadic interval endpoints, exact floor/ceiling multiplication
and division, interval Horner evaluation, and the proposed whole Taylor tail.
The prototype is development-only Python; none of it is a production scalar
or an admitted implementation. The first invocation lacked mpmath; the passing
run used `uv run --with mpmath==1.3.0 python ...` and retained both logs.

The 48-case point comparison crosses m=0, 1/150, 1/2 and 1-10^-40; real initial
(s,c)=(0,1), (3/5,4/5) and (9999/10001,200/10001); both time signs; and both
forward/reverse chart boundaries. Each requested a 96-bit interval width.
Degree 104 and a 144-bit working grid passed every case, with 140-decimal-digit
mpmath Newton/Jacobi/Legendre values inside all output boxes. The full run took
57.83 seconds in Python under concurrent validation. This is not a Rust cost
estimate, a certified reference comparison, or a physical accuracy claim.
The reference uses sigma=E(asin(sn(w))|m)-m*sn(w)*cn(w)/dn(w) on the selected
principal chart, rather than the production-candidate ODE recurrence.

`hyperspatial-thompson-interval-boundary-probe.py` supplements those cases:
12 exact forward pole cases check S=+-1, C=T=delta-sigma=0 and D²=h against
exact rational expectations. Four tiny-initial-denominator cases request
128-bit widths with c=2*10^-60/(1+10^-120) and m=1-10^-200. Forward evaluation
needs a 352-bit working grid after the initial 176-bit schedule is inadequate;
reverse evaluation completes at 176 bits. Those four cases measure interval
width and completion, not independent output values. They demonstrate why a
fixed guard-bit count cannot be the acceptance rule.

The exact small-integer endpoint product checks and rational square-root
checks exercise prototype outward rounding, not the native BigInt kernel.
All output widths are checked after adding the analytical tail. Failed
positive-denominator resolution restarts on a finer grid; intersection with
[-1,1] relies on the separately derived initial-state bounds. Native work,
allocation, cancellation, serialization and shared-output identity remain
unimplemented. Preserve these distinctions in the eventual admission.

## Important distinction for future retained facts

The proposed forward node with arbitrary unwrapped phi is intrinsically finite
and has the stated Taylor majorant, but it does **not** intrinsically have
positive C or T, nor northing in (-E,E). Those stronger chart facts require
phi in (-pi/2,pi/2). Do not attach them to all decoded forward nodes merely
because the public coordinate constructor validated its original latitude.

If the scalar owner needs those facts without a separately replayed latitude
proof, use a finite field a with phi=atan(a) for the interior forward node.
Then every decoded node has the open latitude condition. Initial values can
be expressed stably as

    S=a/sqrt(1+a²), C=1/sqrt(1+a²),
    D=sqrt((1+h*a²)/(1+a²)), T=1/sqrt(1+h*a²),
    sigma0=E(atan(a)|m)-m*S*T.

The public encoder would use a=tan(phi) after proving the open latitude;
poles remain explicit direct paths. This is an alternative design, not an
implemented decision. It introduces an exact-composition obligation for
atan(tan(phi)) on the admitted chart: preserving a value numerically is not
the same as retaining that identity for a later exact consumer. Investigate
existing native inverse-trig certificates before choosing the payload.
No serialized assertion may stand in for that proof.

The current scalar source confirms only special TanPi/quarter-turn inverse
certificates in Real::atan; generic atan(tan(phi)) is not retained as phi.
Computable::atan normally creates AtanDeferred, while ordinary tangent may
use reduced argument kernels. Do not assume the a=tan(phi) encoding preserves
a public exact round-trip certificate automatically.

The original unwrapped-phi payload remains viable if it publishes only the
finite numerical function and its universal majorant, with **no** unconditional
positive-T or bounded-northing metadata. A public coordinate constructor can
prove its chart; a future inverse/forward pair-recognition rule must replay
that chart proof from decoded source fields before returning the original phi.
Thus the proof may be conditional and validated without changing the node's
universal numerical definition. Compare this approach with the intrinsically
interior payload before implementation. Neither choice is yet admitted.

## Native outward-interval prototype, 2026-10-19

The separate `thompson-interval-probe` Rust workspace now implements common-grid
BigInt endpoint arithmetic using native `Real` inputs and initial expressions.
It is not part of a production crate. Seven release tests pass: three signed
outward-arithmetic/ingress tests, two spherical/invalid-domain tests, four
independent complex-Jacobi forward/reverse cases, and twelve inverse-meridian
cases with nine invalid-northing checks. The four-case test retains its original
composed-angle reverse construction and all assertions; the final suite takes
143.83 seconds in that test under concurrent validation. Strict all-target
Clippy also passes. Failures and one accidentally duplicated run terminated by
SIGTERM remain separate diagnostics; the original and final complete tests pass.

The inverse-meridian construction has a more direct exact form. With
`a=inverse_E(E-xi|m)` and `da=sqrt(h+m*cos(a)^2)`, quarter-period identities give

    S=cos(a)/da, C=sqrt(h)*sin(a)/da, D=sqrt(h)/da.

These expressions avoid constructing K-F(a), its Jacobi triplet, a recovered
angle, and trigonometric functions of that angle. The expanded independent test
crosses m=0, 1/2, 0.99, both real signs and both imaginary signs. Comparisons use
independently constructed complex Jacobi/epsilon enclosures, each with an
explicit width requirement, rather than another wrapper around the recurrence.
This is algorithmic evidence, not an admitted serialized exact-function node.

The cost corpus materializes 60 accepted cases across 64, 128 and 256 bits,
four parameters, four forward latitudes and one inverse northing. Every returned
interval meets its requested width after adding the Taylor tail. A standalone
process takes 9.678885317 seconds and peaks at 16,408 KiB RSS; its executable is
2,392,368 bytes, SHA-256
`0cbcac9564d7d3f1e1ea1e6e8d17e9629c42df75c7e89250cf7cead501650238`.
It materializes 552 scalar intervals, excludes compilation, and runs concurrently
with other validation. It is neither an allocation count nor a comparative speed
claim or native work/heap bound. The prototype still lacks production node
identity, cache/cancellation integration and serialization replay.

The reverse univalence argument additionally uses `T=C/D` and `T'=-i*h*S`
along the normalized vertical flow. Since Im S has the sign of the vertical
coordinate, Re T does not decrease from its positive real-meridian value.
Thus the derivative of chi with respect to sigma, 1/T, has positive real part
throughout the proposed convex inverse rectangle. The line-integral criterion
then gives injectivity on that rectangle. Production admission must connect
this analytic proof, the forward image bound and decoded chart checks before
claiming exact forward/reverse cancellation.

## Supplementary native boundary acceptance

Three additional release tests pass, with no production/prototype algorithm
change. They cover fourteen spherical forward cases at both longitude edges,
ten spherical inverse cases at both easting edges, and sixteen exact
ellipsoidal pole cases. Near-pole spherical coordinates differ from pi/2 by
10^-60 and are compared at 320 bits against independent closed trigonometric
and hyperbolic formulas. Pole values are compared at 384 bits for m=0, 1/2,
0.99 and 1-10^-200; the smallest D=10^-100 is resolved at that precision.
Sixteen immediately-outside-chart inputs use relative offsets of 10^-60 and
must fail with InvalidDomain, without epsilon snapping.

The new boundary suite completes in 2.77 seconds with an external 300-second
process timeout; strict all-target Clippy passes. The previous seven-test suite
and original independent comparisons remain intact. A hash check against the
standalone cost record confirms every previously measured source file is
unchanged; only tests/boundaries.rs is new. No benchmark is rerun or speed claim
extended for this test-only addition. Both production validation checkouts still
match all 732 frozen atanh-source hashes.

A remaining payload design issue is exact input encoding, not interval
accuracy. Intrinsically bounded time fields using sin(asin(...)), interior
latitude using atan(tan(...)), or inverse northing using tanh(atanh(...)) need
their public composition/evidence contract stated explicitly. Existing generic
atan/tan and stable hyperbolic spellings do not automatically provide every
structural cancellation certificate. Keep the original unwrapped-phi forward
payload option, which is universally finite without claiming an unconditional
positive T; chart facts may instead be replayed by the owning scalar/coordinate
operation. Do not silently assume a missing certificate or serialize an
unchecked positive/chart assertion to avoid this decision.
