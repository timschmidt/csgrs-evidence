# Bounded-parameter proof review

The new square-sign attempt consumes only an already admitted finite quotient.
Its partition terms have exact signs; P,Q are nonnegative at the current input.
The recursive ZeroResidual reducer returns Some only for an empty numerator,
so P²-Q²=0 plus nonnegativity proves P=Q. Formal common-factor division is used
only to obtain a sufficient zero condition; it never proves that the factor
is nonzero or inverts it. Unknown terms can decline but cannot select a branch.

Completed root relations admit only a nonnegative radicand quotient whose
original inverse obligations have already passed. A positive/zero radicand
witness gives the same sign for its principal square root. Mixed-sign constant
bounds use existing positive rational intervals with coefficient sign reversal;
bounds touching zero remain unresolved. No failed attempt publishes a global
rational certificate. The final publication still checks the root controller.

The original strategy retains its exact choices and success paths. The second
strategy clears only atom-ID-dependent state; its work/node counters and
controller are unchanged. The direct handoff tests check the single transition
debit, zero remaining resources, active cancellation and recovery. Early root
products check coefficients before any zero factor could erase an oversized
value, and never retain a monomial above the old degree limit.

The numerical resource claim is narrow: existing normalizer visit/operation,
coefficient, atom, term and degree caps remain. The cost of shared structural
matching and arbitrary dependent scalar evaluation is not established as a
new total-work or heap-byte bound. The runtime fields remain native Real/
Computable/Rational values; integer counters and BigInt limbs are the existing
scalar substrate, and display floats appear only in explicit development
warming. Domain replay assumes valid finite scalar atoms, not a general
validator for forged undefined nonleaf serialized graphs.
