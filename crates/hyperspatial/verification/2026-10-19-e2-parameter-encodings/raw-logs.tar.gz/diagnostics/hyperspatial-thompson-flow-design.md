# Candidate native polynomial continuation for transverse rectification

Research 2026-10-19; not implemented or certified acceptance. The epsilon
increment remains under final validation. These equations are local algebraic
derivations to investigate, not a claim of a completed inverse API.

Karney gives the Thompson intermediates in equations 30 and 31:
https://arxiv.org/html/1002.1417v3 . Use parameter m=e², h=1−m and unnormalized
sigma=E(m)−epsilon(K(m)−w|m). chi=atanh(sn w)−e*atanh(e*sn w).
The source also locates the branch at w=i*K(1−m), chi=i*(1−e)*pi/2,
sigma=i*(K(1−m)−E(1−m)); the standard chart needs its named cuts.

## Derivation of a forward polynomial flow

Set S=sn(w), C=cn(w), D=dn(w), Q=sqrt(h)/D. Differentiating and using
S²+C²=1 and D²−m*C²=h gives dchi/dw=h/(C*D) and dsigma/dw=h/D².
Continue chi from its real central-meridian value by i*lambda, with
real path coordinate t=lambda/h. The resulting autonomous equations are

    S' =  i*C²*D²
    C' = -i*S*C*D²
    D' = -i*m*S*C²*D
    Q' =  i*m*S*C²*Q
    sigma' = i*sqrt(h)*C*Q.

At t=0, geographic latitude phi gives S=sin(phi), C=cos(phi),
D=sqrt(1−m*S²), Q=sqrt(h)/D, and
sigma=E(phi|m)−m*S*C/D. The initial sigma is the meridian distance divided
by the equatorial radius. For 0<=m<1 and |phi|<=pi/2, all four state
magnitudes are at most one. At either pole C=0 and the entire flow is
constant, agreeing with the pole image without infinite isometric latitude.

Rescaling Q and the path avoids a pessimistic majorant growing as D^-5 near
polar latitudes. The four state polynomials have degree four and coefficients
of magnitude at most one. No complex inverse amplitude or atanh evaluation
is needed inside this forward continuation.

## Reverse polynomial flow and remaining scalar boundary

Continue sigma from xi on the real meridian by i*eta, with t=eta/h:

    S' =  i*C*D³
    C' = -i*S*D³
    D' = -i*m*S*C*D².

The real initial state can be constructed with the existing real inverse E
and Jacobi functions: a=inverse_E(E(m)−xi|m), w=K(m)−F(a|m), then the
real triplet at w. Recover chi from S using its stated atanh formula on the
chosen sheet, then use the existing real inverse-isometric latitude scalar.
A production complex atanh boundary would need stable formulas, explicit
cuts/poles, exact axes and independent tests at its owning layer. Tracking
1/C as an extra ODE state is rejected provisionally: a coarse common majorant
would force very small steps at high latitudes.

## Candidate certified Taylor majorant

For either core system, at a step start let M>=1 bound every state magnitude.
The positive scalar majorant Y'=Y^4, Y(0)=M gives
Y(z)=M*(1−3*M³*z)^(-1/3). Its convergence radius is R=1/(3*M³), and each
coefficient has magnitude <=M/R^n. For |step|/R=q<1, the omitted state tail
after degree N is <=M*q^(N+1)/(1−q). The forward sigma derivative has
magnitude majorized by Y², since sqrt(h)<=1; its incremental coefficient n
is <=M²*R/R^n, which is <=M/R^n. Thus the same tail bound suffices for sigma.

This is a candidate local bound only. A native implementation still needs:
- Outward interval coefficients enclosing initial-state and parameter uncertainty.
- Complex interval products, dyadic rounding, and a tested bound for every
  rounding and truncation contribution.
- Validated step chaining, precision restart/recovery and cancellation. Coarse
  initial boxes must not accumulate an unreported uncertainty.
- A mathematical existence/continuation argument for the declared whole chart,
  with singular boundaries distinguished from numerical exhaustion.
- Shared exact output identity and retained forward/reverse composition; an
  interval endpoint must never be substituted for the exact function value.
- New scalar-node inventory/replay/serialization evidence if intrinsic nodes
  are chosen. Shared bounds belong below coordinate/frame semantics.

The reverse path domain and relation to the forward chart require proof. Do
not assume a rectangular projected bound is the exact image of a longitude
strip. The branch constants suggest useful initial bounds, not an admitted
image characterization. Sphere behavior should retain the existing spherical
chart and avoid complementary complete-integral singularities.

## Existing workspace ownership

Hypersolve already has exact RealInterval arithmetic and affine/quadratic
Krawczyk certification; its documented dense nonlinear loop is a lossy proposal
adapter. Those polynomial certificate APIs do not directly supply a refinable
transcendental complex root, and Hyperreal cannot depend on a consumer that
already depends on it. Assess reuse at the scalar/interval boundary rather
than adding a second coordinate kernel or accepting an unverified Newton point.

## Refined state and a candidate explicit chart

A simpler fourth state is T=C/D. Differentiation cancels h exactly and gives

    T' = -i*h*S*T,   sigma' = i*h*T

with the same first three forward equations. Initially |T|<=1 because
C²<=h+m*C²=D². Every state still has the common Y'=Y^4 majorant. This reduces
the fourth derivative to degree two and strengthens the sigma increment bound:

    |sigma(t)−sigma(0)| <= h*|t|/(1−3*|t|),   |t|<1/3.

A first useful closed longitude chart is |lambda|<=h/9. Then |t|<=1/9,
q<=1/3 and |Im sigma|<=h/6. This width covers ordinary and exceptional UTM
longitude offsets on WGS84; parameter-dependent chart admission must still
be checked explicitly, rather than promised for every ellipsoid. Broader
charts and prolate parameters remain a subsequent extension.

For interior latitudes, T(0)>0. The differential equation gives
T(t)=T(0)*exp(−i*h*integral_0^t S(v)dv). Its phase obeys
|arg T|<=h*|t|*(1−3|t|)^(-1/3)<=((3/2)^(1/3))/9<pi/2.
Hence Re T>0 throughout this strip. Since d sigma/d chi=T, northing is strictly
increasing with real isometric latitude. Uniform local flow bounds allow the
pole limits sigma→±E(m); thus -E<Re sigma<E for interior latitudes. At a pole,
C=T=0 and S,D are constant, so the image is exactly ±E. This also supplies
positive real derivative on a convex chi strip, an injectivity route to justify
carefully in the eventual admission, not a Newton-convergence assumption.

## Reverse-domain argument to validate rigorously

The reverse polynomial flow starts from the real meridian at any
-E<xi<E, so C(0)>0 and D(0)>0. For |eta|<=h/6, |t|<=1/6 and q<=1/2; the
same majorant supplies finite analytic continuation of S,C,D. Algebraic
invariants S²+C²=1 and D²+m*S²=1 follow by differentiating them.

D cannot vanish: D=0 makes the whole reverse vector field zero, and uniqueness
would force D(0)=0. Also |D'/D|<=|S*C*D|<=Y³. Its continuous argument therefore
stays within (ln 2)/3<pi/2 of zero, giving Re D>0.

C cannot vanish either. At C=0, the invariants imply S=±1 and D²=h. The real
path subspace S,D real and C purely imaginary is invariant under the reverse
vector field. Uniqueness propagated back along the already finite solution
would make C(0) purely imaginary, contradicting C(0)>0.

More generally, C cannot be purely imaginary: then S is real with |S|>=1.
If 1<=|S|<1/sqrt(m), D is real by its invariant, and the same invariant-subspace
argument contradicts C(0)>0. If |S|>=1/sqrt(m), D is zero or purely imaginary,
contradicting Re D>0. The m=0 endpoint omits the second threshold and uses the
first argument directly. Thus Re C>0 and S avoids the real atanh cuts.

At Im S=0 within (-1,1), C,D must be positive real and
(d/dt) Im S=C*D³>0. Starting at zero, Im S therefore has the sign of t. It
cannot cross back to the real axis because the vector field points in the
same direction at any such crossing. This sign is potentially retainable at
the scalar owner: it also proves the nonzero denominators of complex atanh
when eta is nonzero. The real axis uses its existing exact scalar path.
For 0<m<1, sqrt(m)*S avoids its own real cuts as well. These observations
permit the principal atanh expression for chi along this particular sheet.

The rectangle -E<xi<E, |eta|<=h/6 is an enclosing inverse evaluation domain,
not a claim that every point belongs to the narrower forward longitude chart.
After evaluation, a public coordinate inverse must prove its resulting
longitude belongs to |lambda|<=h/9 (or report the distinct chart failure).
Retained forward results already carry that chart witness. The precise
forward/inverse identity, sheet, pole convention and raw-ingress behavior
must be admitted before a production API claims them.

Both the Q-state and T-state point prototypes compare 16 cases at 80 decimal
digits against independently evaluated Thompson equations and reverse
compositions. Their logs are development evidence only. They do not test
outward interval coefficients, rounded dyadic arithmetic, actual production
nodes or cancellation; the mathematical proof still needs implementation-
connected tests and careful review.

## Stronger inverse uniqueness argument

A useful additional identity is available on the proposed reverse rectangle.
Set T=C/D there. Its reverse derivative simplifies to

    T' = -i*h*S.

The earlier argument gives Im S with the sign of t. Therefore
Re T(t)=T(0)+h*integral_0^t Im S(v)dv >= T(0)>0, for either sign of t.
Consequently Re(1/T)>0. The inverse mapping G(sigma)=chi has derivative
G'=D/C=1/T with positive real part throughout the convex open rectangle
-E<Re sigma<E, |Im sigma|<h/6. Integrating this derivative along a line segment
shows G is injective: its average derivative has positive real part and cannot
vanish. This avoids relying on a numerical inverse branch selection.

The forward mapping F has Re F'=Re T>0 on its convex chi strip, as established
above. Its image is inside the reverse rectangle (strictly in the interior
for interior longitude and latitude). F and G agree as inverses on the real
meridian; analytic continuation/identity on the connected strip then gives
G(F(chi))=chi. If a raw rectangle input sigma passes the recovered-longitude
chart check, F(G(sigma)) exists and has the same G image as sigma. Injectivity
of G then gives F(G(sigma))=sigma. Boundary identities follow by continuity
where the previously proved nonvanishing and bounds persist.

This is an original proof outline to connect carefully to a native node and
its exact parameterization. It is not supplied by the point prototype. A
full admission must justify the holomorphic gluing of local ODE solutions,
initial inverse-E branch, strict interior inequalities and boundary continuity.
Pole images are separate: all allowed longitudes collapse there, so an inverse
longitude convention and its evidence must remain explicit.
