import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

root = Path('/mnt/development/hyperspatial/csgrs')
candidate = Path('/mnt/development/hyperspatial/thompson-scalar-candidate')
freeze = json.loads(Path('/tmp/hyperspatial-encodings-final-source-freeze.json').read_text())
jobs = json.loads(Path('/tmp/hyperspatial-encodings-final-jobs.json').read_text())
for label, job in jobs.items():
    rows = json.loads((Path('/tmp/hyperspatial-encodings-final-verification') / label / 'results.json').read_text())
    assert len(rows) == len(job['commands']), (label, 'unfinished commands')
    assert all(row['status'] == 'complete' and row['returncode'] == 0 for row in rows), label
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
assert git('branch', '--show-current') == 'hyperspatial'
assert git('rev-parse', 'HEAD') == freeze['baseline']
assert not git('status', '--porcelain'), 'Root has changes; inspect before integration'
for name, expected in freeze['sha256'].items():
    assert hashlib.sha256((candidate / name).read_bytes()).hexdigest() == expected, name
changes = json.loads(Path('/tmp/hyperspatial-encodings-integration-paths.json').read_text())
changes += ['crates/hyperreal/docs/admission-bounded-parameter-encodings.md',
            'crates/hyperspatial/docs/admission/e2-parameter-encodings.md']
for name in changes:
    destination = root / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(candidate / name, destination)
for name, expected in freeze['sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
record = dict(baseline=freeze['baseline'], branch=git('branch', '--show-current'),
              copied_paths=changes, frozen_path_count=len(freeze['sha256']),
              all_frozen_paths_match=True, completed_unix=time.time())
Path('/tmp/hyperspatial-encodings-root-integration.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
