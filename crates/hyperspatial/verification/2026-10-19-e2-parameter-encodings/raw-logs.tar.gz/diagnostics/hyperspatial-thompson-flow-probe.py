"""Development-only point probe; no interval or certified acceptance claim."""
import json
import mpmath as mp
mp.mp.dps = 80
DEGREE = 96

def convolution(a, b, n):
    return sum(a[j] * b[n-j] for j in range(n+1))

def advance(state, m, duration, reverse=False):
    time = mp.mpf(0)
    steps = 0
    h = 1-m
    tail = mp.mpf(0)
    while abs(duration-time) > mp.mpf('1e-78'):
        magnitude = max([mp.mpf(1)] + [abs(v) for v in state[:3 if reverse else 4]])
        radius = 1/(3*magnitude**3)
        step = mp.sign(duration-time) * min(abs(duration-time), radius/5)
        q = abs(step)/radius
        coefficients = [[v] for v in state]
        square_c, square_d, sc, sc2, cube_d = [], [], [], [], []
        for n in range(DEGREE):
            s,c,d = coefficients[:3]
            square_c.append(convolution(c,c,n))
            square_d.append(convolution(d,d,n))
            sc.append(convolution(s,c,n))
            if reverse:
                cube_d.append(convolution(d,square_d,n))
                derivatives = [convolution(c,cube_d,n), -convolution(s,cube_d,n),
                               -m*convolution(sc,square_d,n)]
            else:
                qstate=coefficients[3]
                sc2.append(convolution(s,square_c,n))
                derivatives=[convolution(square_c,square_d,n),-convolution(sc,square_d,n),
                             -m*convolution(sc2,d,n),m*convolution(sc2,qstate,n),
                             mp.sqrt(h)*convolution(c,qstate,n)]
            for series,derivative in zip(coefficients,derivatives):
                series.append(1j*derivative/(n+1))
        state=[mp.polyval(list(reversed(series)),step) for series in coefficients]
        tail=max(tail,magnitude*q**(DEGREE+1)/(1-q))
        time+=step
        steps+=1
        assert steps<2000
    return state,steps,tail

def meridian(phi,m):
    s,c=mp.sin(phi),mp.cos(phi)
    return mp.ellipe(phi,m)-m*s*c/mp.sqrt(1-m*s*s)

def chi(s,m):
    e=mp.sqrt(m)
    return mp.atanh(s)-e*mp.atanh(e*s)

rows=[]
for m in [mp.mpf('0'),mp.mpf('0.006694379990141316996137233540044785'),mp.mpf('0.5'),mp.mpf('0.99')]:
    h=1-m
    longitude=min(mp.mpf('0.06'),(1-mp.sqrt(m))*mp.pi/10)
    for phi,lam in [(mp.mpf('0'),longitude),(mp.mpf('0.5'),longitude),(mp.mpf('1.4'),longitude),(mp.mpf('-0.5'),-longitude)]:
        s,c=mp.sin(phi),mp.cos(phi)
        d=mp.sqrt(1-m*s*s)
        state=[mp.mpc(s),mp.mpc(c),mp.mpc(d),mp.mpc(mp.sqrt(h)/d),mp.mpc(meridian(phi,m))]
        final,forward_steps,tail=advance(state,m,lam/h)
        sigma=final[-1]
        target=chi(s,m)+1j*lam
        w0=mp.ellipf(phi,m)
        root=mp.findroot(lambda w: chi(mp.ellipfun('sn',w,m),m)-target,w0+1j*lam*c*d/h,tol=mp.mpf('1e-70'))
        argument=mp.ellipk(m)-root
        reference=mp.ellipe(m)-argument*mp.quad(lambda t: mp.ellipfun('dn',argument*t,m)**2,[0,1])
        middle=mp.findroot(lambda v: meridian(v,m)-sigma.real,(phi-mp.mpf('.01'),phi+mp.mpf('.01')),tol=mp.mpf('1e-70'))
        s0,c0=mp.sin(middle),mp.cos(middle)
        reverse,reverse_steps,reverse_tail=advance([mp.mpc(s0),mp.mpc(c0),mp.mpc(mp.sqrt(1-m*s0*s0))],m,sigma.imag/h,True)
        recovered=chi(reverse[0],m)
        error=abs(sigma-reference)
        inverse_error=abs(recovered-target)
        invariant_error=max(abs(final[0]**2+final[1]**2-1),abs(final[2]**2+m*final[0]**2-1),abs(final[2]*final[3]-mp.sqrt(h)))
        row=dict(m=str(m),latitude=str(phi),longitude=str(lam),forward_steps=forward_steps,reverse_steps=reverse_steps,
                 forward_error=str(error),inverse_error=str(inverse_error),invariant_error=str(invariant_error),local_point_tail_estimate=str(max(tail,reverse_tail)))
        rows.append(row)
        print(json.dumps(row),flush=True)
        assert max(error,inverse_error,invariant_error)<mp.mpf('1e-55')
report=dict(cases=rows,precision_decimal_digits=mp.mp.dps,degree=DEGREE,limitations='Uncertified point Taylor probe and numerical Newton/quadrature references. Local tail estimates use point states; not global certified bounds.')
with open('/tmp/hyperspatial-thompson-flow-probe.json','w') as output: json.dump(report,output,indent=2)
