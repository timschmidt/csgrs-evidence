# Next Thompson node review (research only)

2026-10-19. The bounded-parameter scalar candidate is under final validation;
root remains at 2aaf10dea. This note is not a new production API or admission.
It supplements the earlier flow/node designs and replaces their provisional
reverse tanh/atanh parameter spelling.

## Current payload direction

Use finite r with h=1/(1+r*r), m=1-h and log(h)=-ln(1+r*r). This enforces
0<=m<1 without a serialized domain flag. Forward fields can remain arbitrary
unwrapped phi and finite tau with t=sin(tau)/9; lambda=h*t. All forward flow
states S,C,D,T have magnitude <=1 initially for arbitrary real phi, but the
unbounded anchor sigma0 is excluded from that bound. Its increment has the
proved tail. Do not tag general decoded forward nodes with positive C/T or
northing in (-E,E): those stronger chart facts need the interior latitude.
Keeping phi directly avoids assuming an unavailable atan(tan(phi)) certificate.

Reverse fields can use finite a with v=a/sqrt(1+a*a), xi=E(m)*v, and beta with
t=sin(beta)/6, eta=h*t. This enforces strict -E<xi<E. It avoids the earlier
unproved generic tanh(atanh(v)) cancellation. The public encoding obligation
for a=v/sqrt(1-v*v) is now exercised across 22 scalar families, JSON/CBOR,
concurrency and near endpoints in the candidate. Those finite tests and the
bounded normalizer are not a proof that every arbitrary expression will
normalize successfully within its fixed work/degree/coefficient budgets.
Generic powi(2) still has a different exp/log carrier from literal r*r.

All these statements assume valid finite input Real values, as does the
existing scalar graph contract. They are not a general validator for a forged
serialized graph containing undefined nonleaf operations.

## Domain proofs must reach the next consumer

The existing public Complex::atanh first certifies a nonzero imaginary part
or positive 1-re*re. An intrinsically cut-free inverse-flow output could still
be rejected when those ordinary scalar queries exhaust their absolute
precision floor near a pole/cut. Merely knowing the analytic theorem in a
coordinate wrapper is insufficient. Before choosing an implementation, add
acceptance for near-pole inverse states, tiny eta, exact eta=0, and cold replay.
Either replay the intrinsic node's branch certificate at the scalar owner,
or make the exact inverse-chi component itself an intrinsic node whose
numerical kernel uses that proved domain. Do not bypass a public domain guard
by an unchecked flag or a numerical Newton guess. The latter design would
still use native logarithm/atan2 kernels and must document its universal
payload-domain proof; it is not yet a selected architecture.

Similarly, test denominator 1+r*r and root 1+a*a with arbitrary signed,
zero, huge, and unresolved-zero fields. The existing opaque zero fixture
sin(e).powi(2)+cos(e).powi(2)-1 provides a valid zero with no cheap sign proof.
An intrinsic payload must not depend on proving that r or a is nonzero.
Exact forward/reverse pair recognition must replay the actual latitude/chart
obligations from decoded source fields before returning an original input.

## Sharing and evaluation obligations

The outward-dyadic polynomial recurrence prototype already gives interval
coefficients, Horner evaluation and a whole-tail bound. Reuse its mathematics,
not its finite result as the authoritative value. With q<=1/3 forward or
q<=1/2 reverse, the common tail is at most 2^-N after degree N; integer
precision bookkeeping can select a conservative N without floating logs.
Working-grid rounding must still be measured and refined until the complete
output interval meets the requested width. Near-pole initial denominators
already required more than the first guard-bit schedule in the prototype.

A shared owned flow specification can avoid repeating the entire recurrence
for each component, but needs its own cache lifecycle acceptance: cold/warm,
low-high-low precision, independently decoded equal inputs, concurrent readers,
cancellation before and during a recurrence, and recovery without publishing
partial values. Pointer identity must not outlive owned inputs. Cancellation
controllers must not become semantic field identity or serialized facts.
The existing scalar caches do not establish a new total-work or heap-byte
bound for an O(N^2) recurrence; precision/degree, cancellation and retention
are separate obligations. Extreme probes need explicit external containment
until any stronger native resource contract is implemented and measured.

The useful first coordinate chart remains sphere/oblate, |lambda|<=h/9, with
the enclosing inverse rectangle -E<xi<E, |eta|<=h/6. The rectangle is not
claimed to equal the forward image; raw inverse input must pass the recovered
longitude check. Poles have a separate longitude convention. Prolate and
broader longitude charts remain subsequent extensions. Holomorphic gluing,
nonvanishing branch proofs and identity-theorem/injectivity arguments in the
earlier flow note still require implementation-connected review and tests.

## Possible lazy inverse-chi construction (unselected)

There is a universal positive-denominator spelling on a cut-free state
z=x+i*y. Let X=1-x*x-y*y and Y=2*y. Since the principal atanh cuts and poles
are excluded, (X,Y) is never the origin or the negative real axis. Thus
X+sqrt(X*X+Y*Y)>0 and

    Im atanh(z) = atan(Y/(X+sqrt(X*X+Y*Y))),
    Re atanh(z) = (ln((1+x)^2+y^2)-ln((1-x)^2+y^2))/4.

For the intrinsic reverse flow, the branch theorem supplies those obligations
for both S and sqrt(m)*S, including the real-meridian case. This suggests a
lazy exact chi component constructed from native Computable elementary
expressions, with its proof owned by the intrinsic payload constructor. It
would avoid requiring a numerical sign decision merely to construct a value
already proved finite. This is a proposal to evaluate, not authorization to
add an unchecked public atanh API or duplicate complex semantics silently.
Review ownership and stable/rationalized spellings against the existing native
half-angle/logarithm implementation before selecting it.

A fixed 128-bit S/C/D enclosure is not sufficient to obtain a 128-bit chi
near a pole: atanh can amplify its input error by arbitrarily much. Any direct
chi interval kernel must adapt the degree as well as the working grid until
its final propagated width is met. Alternatively an exact elementary DAG over
lazy flow components can use the existing demand/refinement machinery. Near
zero time and tiny C, absolute Taylor tails may require many more coefficients;
the current state-only prototype has not measured that final consumer cost.

## Finite-field stress probe

A separate native probe tests h=1/(1+r*r) and v=r/sqrt(1+r*r) for
zero, +/-1, +/-pi, +/-10^1000, an opaque exact zero, and that zero
plus/minus 10^-1000. All ten fields construct finite decoded values; h
has a positive certificate and measured h/v enclosures meet the same
2^-48 width requirement. This is finite acceptance, not a universal
proof of computational completion.

The first run fails its fixed-precision width assertion for the huge v.
That assertion misunderstood Real::certified_rational_interval: requested
precision applies to the Computable factor before exact rational scaling.
The second run measures the final width and refines from -64 to -4096
for both huge v cases. Every other h/v enclosure meets the target at -64.
The original 2^-48 acceptance width is unchanged; both source snapshots and
logs are retained. The separate process is externally limited to 300 seconds.

All ten decoded values pass the test, but a diagnostic of v.asin() returns
Exhausted for both huge cases while accepting the other eight. This is an
explicit downstream domain-evidence limit, not a failed decoding or a
claim that arbitrary close-to-endpoint inverse-trig consumers now complete.
An intrinsic reverse node must own/replay that open-interval proof or use a
mathematically equivalent construction whose domain is intrinsic. The
current bounded-encoding increment does not change this consumer.

## Final inverse-chi enclosure probe

The separate native `thompson-inverse-chi-probe` copies the earlier interval
prototype and links the frozen bounded-encoding candidate. It adds a research
consumer of the continued S box, using chi=atanh(S)-sqrt(m)*atanh(sqrt(m)*S).
For each atanh input rectangle, require that the whole rectangle avoid the
principal cuts. The midpoint is evaluated by the existing exact native atanh;
its certified enclosure is enlarged by

    (real half-width + imaginary half-width) / (d_minus * d_plus),

where each d is the L-infinity distance from the rectangle to the pole +/-1.
These are conservative lower bounds for Euclidean distances along every
midpoint-to-input segment. The analytic derivative 1/(1-z*z) then bounds the
whole segment error. Rational endpoint arithmetic also includes uncertainty
in sqrt(m), the correction and the final subtraction. The requested final
width, not the intermediate state width, controls degree refinement.

Two release tests pass ten cases in 3.77 seconds under concurrent validation:
six spherical cases compare independent closed asinh/atan2 formulas, including
both signs, the equator, a chart edge, meridian points 10^-60 from a pole,
and nonzero eastings +/-10^-120. Four oblate cases m=1/2,0.99 compare
independently prescribed complex Jacobi/epsilon arguments and both signs.
All returned final component intervals have width <=2^-64. The ordinary
cases use degree88/grid128; the three near-pole cases use degree648/grid688.
The ellipsoidal comparison shares the native elementary atanh implementation
with midpoint evaluation; it is independent of the flow recurrence, not an
independent atanh oracle. Interval overlap with a narrower reference is a
regression check, not a machine-checked proof of this analytic bound.

The first build fails because Rational provides PartialOrd, not Ord; the
corrected probe uses its exact comparison explicitly. Both source and log
are retained. Strict release/all-target Clippy passes. No production files
changed, no timing ratio is claimed, and this still lacks intrinsic node
identity, serialization, cancellation and cache lifecycle acceptance.
External 600-second process containment is not a native resource bound.
