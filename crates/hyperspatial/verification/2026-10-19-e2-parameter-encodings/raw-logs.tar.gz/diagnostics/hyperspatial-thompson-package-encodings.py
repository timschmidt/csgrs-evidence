import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

files = {}
for path in Path('/tmp').glob('hyperspatial-thompson-*'):
    paths = path.rglob('*') if path.is_dir() else [path]
    for item in paths:
        if item.is_file() and item.suffix in {'.rs', '.py', '.log', '.json', '.md', '.tsv'}:
            if item.name.endswith('research-manifest.json'):
                continue
            files['diagnostics/'+str(item.relative_to('/tmp'))] = item.read_bytes()
base = Path('/mnt/development/hyperspatial')
for name, folder in [('native-prototype', 'thompson-interval-probe'),
                     ('scalar-prototype', 'thompson-scalar-probe')]:
    for path in (base/folder).rglob('*'):
        if path.is_file():
            files[name+'/'+str(path.relative_to(base/folder))] = path.read_bytes()
baseline = json.loads(Path('/tmp/hyperspatial-atanh-final-source-freeze.json').read_text())
for name, digest in baseline['sha256'].items():
    data = (base/'epsilon-candidate'/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, name
    files['dependency-source/'+name] = data
experiment = json.loads(Path('/tmp/hyperspatial-thompson-scalar-regression-freeze.json').read_text())
for name, digest in experiment['sha256'].items():
    data = (base/'thompson-scalar-candidate'/name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest, name
    if baseline['sha256'].get(name) != digest:
        files['scalar-experiment/'+name] = data
for name, digest in experiment['probe_sha256'].items():
    assert hashlib.sha256((base/'thompson-scalar-probe'/name).read_bytes()).hexdigest() == digest, name
manifest = {name: {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
            for name,data in sorted(files.items())}
manifest_path = Path('/tmp/hyperspatial-thompson-encodings-research-manifest.json')
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
files['manifest.json'] = manifest_path.read_bytes()
archive = base/'thompson-research-20261019-encodings.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|') as tar:
        for name,data in sorted(files.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
print(json.dumps({'files':len(files), 'archive':str(archive), 'bytes':archive.stat().st_size,
                  'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}, indent=2))
