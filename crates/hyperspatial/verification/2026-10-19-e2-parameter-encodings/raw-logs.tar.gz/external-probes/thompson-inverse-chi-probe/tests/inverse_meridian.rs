use hyperlattice::Complex;
use hyperreal::{Rational, Real};
use thompson_interval_probe::{ProbeError, reverse_from_northing};

#[test]
fn inverse_meridian_continuation_matches_jacobi_at_independently_prescribed_arguments() {
    for parameter in [
        Real::zero(),
        "0.5".parse().unwrap(),
        "0.99".parse().unwrap(),
    ] {
        let h = Real::one() - &parameter;
        let k = Real::elliptic_k(&parameter).unwrap();
        let e = Real::elliptic_e_complete(&parameter).unwrap();
        for (real_sign, sign) in [(-1, -1), (-1, 1), (1, -1), (1, 1)] {
            let w = Complex::new(
                Real::from(real_sign) * "0.25".parse::<Real>().unwrap(),
                (Real::from(sign) * &h / Real::from(128)).unwrap(),
            );
            let (s, c, d) = w.clone().jacobi_sncndn(&parameter).unwrap();
            let sigma = Complex::from(e.clone())
                - (Complex::from(k.clone()) - w)
                    .jacobi_epsilon(&parameter)
                    .unwrap();
            let result = reverse_from_northing(&sigma.re, &sigma.im, &parameter, 80).unwrap();
            let width = Rational::fraction(1, 2).unwrap().powi(96.into()).unwrap();
            for (actual, expected) in result.bounds.iter().zip([s, c, d]) {
                for (actual, expected) in actual.iter().zip([expected.re, expected.im]) {
                    let reference = expected.certified_rational_interval(-112).unwrap();
                    assert!(&reference[1] - &reference[0] < width);
                    assert!(actual[0] <= reference[1] && reference[0] <= actual[1]);
                }
            }
        }
        for endpoint in [e.clone(), -e.clone(), Real::from(2) * &e] {
            assert!(matches!(
                reverse_from_northing(&endpoint, &Real::zero(), &parameter, 80),
                Err(ProbeError::InvalidDomain)
            ));
        }
    }
}
