use hyperreal::{Rational, Real};
use thompson_interval_probe::{forward, reverse};

fn contains(bounds: &[Rational; 2], value: Rational) {
    assert!(bounds[0] <= value && value <= bounds[1]);
}

#[test]
fn spherical_equator_and_poles_retain_independent_values() {
    for bits in [32, 128] {
        for sign in [-1, 1] {
            let phi = Real::from(sign) * (Real::pi() / Real::from(2)).unwrap();
            let output = forward(&phi, &"0.1".parse().unwrap(), &Real::zero(), bits).unwrap();
            contains(&output.bounds[0][0], Rational::new(sign));
            contains(&output.bounds[1][0], Rational::zero());
            contains(&output.bounds[3][0], Rational::zero());
            contains(&output.bounds[4][0], Rational::zero());
            contains(&output.bounds[4][1], Rational::zero());
        }
        // For m=0 on the reverse equator S=sin(i*eta)=i*sinh(eta).
        let eta: Real = "0.1".parse().unwrap();
        let output = reverse(&Real::zero(), &eta, &Real::zero(), bits).unwrap();
        contains(&output.bounds[0][0], Rational::zero());
        let expected = eta
            .sinh()
            .unwrap()
            .certified_rational_interval(-(bits as i32) - 32)
            .unwrap();
        assert!(output.bounds[0][1][0] <= expected[1] && expected[0] <= output.bounds[0][1][1]);
    }
}

#[test]
fn chart_failures_and_precision_overflow_are_distinct_from_success() {
    use thompson_interval_probe::ProbeError;
    for parameter in [Real::from(-1), Real::one(), Real::from(2)] {
        assert!(matches!(
            forward(&Real::zero(), &Real::zero(), &parameter, 80),
            Err(ProbeError::InvalidDomain)
        ));
    }
    assert!(matches!(
        forward(&Real::zero(), &"0.12".parse().unwrap(), &Real::zero(), 80),
        Err(ProbeError::InvalidDomain)
    ));
    assert!(matches!(
        forward(&Real::zero(), &Real::zero(), &Real::zero(), u32::MAX),
        Err(ProbeError::PrecisionScheduleExhausted)
    ));
}
