//! Independent closed spherical functions and exact pole values at chart edges.
//! This supplements the earlier prescribed-Jacobi comparisons without replacing them.
use hyperlattice::Complex;
use hyperreal::{Rational, Real};
use thompson_interval_probe::{FlowResult, ProbeError, forward, reverse, reverse_from_northing};

fn check(actual: &FlowResult, expected: &[Complex], bits: u32) {
    assert_eq!(actual.bounds.len(), expected.len());
    let width = Rational::fraction(1, 2).unwrap().powi(bits.into()).unwrap();
    let reference_width = Rational::fraction(1, 2)
        .unwrap()
        .powi((bits + 16).into())
        .unwrap();
    for (index, (actual, expected)) in actual.bounds.iter().zip(expected).enumerate() {
        for (part, (actual, expected)) in
            actual.iter().zip([&expected.re, &expected.im]).enumerate()
        {
            let reference = expected
                .certified_rational_interval(-(bits as i32) - 32)
                .unwrap();
            assert!(&actual[1] - &actual[0] <= width, "output {index}/{part}");
            assert!(
                &reference[1] - &reference[0] <= reference_width,
                "reference {index}/{part}"
            );
            assert!(
                actual[0] <= reference[1] && reference[0] <= actual[1],
                "disjoint {index}/{part}"
            );
        }
    }
}

fn spherical_state(xi: &Real, eta: &Real) -> [Complex; 3] {
    let sin = xi.clone().sin();
    let cos = xi.clone().cos();
    let sinh = eta.clone().sinh().unwrap();
    let cosh = eta.clone().cosh().unwrap();
    [
        Complex::new(&sin * &cosh, &cos * &sinh),
        Complex::new(&cos * &cosh, -(&sin * &sinh)),
        Complex::one(),
    ]
}

#[test]
fn closed_spherical_forward_matches_at_both_longitude_edges_and_near_poles() {
    let near_pole = (Real::pi() / Real::from(2)).unwrap() - "1e-60".parse::<Real>().unwrap();
    for (phi, bits) in [
        (Real::zero(), 144),
        ("0.5".parse().unwrap(), 144),
        ("-0.5".parse().unwrap(), 144),
        ("1.4".parse().unwrap(), 144),
        ("-1.4".parse().unwrap(), 144),
        (near_pole.clone(), 320),
        (-near_pole, 320),
    ] {
        for sign in [-1, 1] {
            let lambda = (Real::from(sign) / Real::from(9)).unwrap();
            let sin_phi = phi.clone().sin();
            let cos_phi = phi.clone().cos();
            let xi = sin_phi.try_atan2(&cos_phi * lambda.clone().cos()).unwrap();
            let eta = (cos_phi * lambda.clone().sin()).atanh().unwrap();
            let [s, c, d] = spherical_state(&xi, &eta);
            let expected = [s, c.clone(), d, c, Complex::new(xi - &phi, eta)];
            check(
                &forward(&phi, &lambda, &Real::zero(), bits).unwrap(),
                &expected,
                bits,
            );
        }
    }
}

#[test]
fn closed_spherical_reverse_matches_at_both_easting_edges_and_near_northing_edges() {
    let near_pole = (Real::pi() / Real::from(2)).unwrap() - "1e-60".parse::<Real>().unwrap();
    for (xi, bits) in [
        (Real::zero(), 144),
        ("0.5".parse().unwrap(), 144),
        ("-0.5".parse().unwrap(), 144),
        (near_pole.clone(), 320),
        (-near_pole, 320),
    ] {
        for sign in [-1, 1] {
            let eta = (Real::from(sign) / Real::from(6)).unwrap();
            check(
                &reverse_from_northing(&xi, &eta, &Real::zero(), bits).unwrap(),
                &spherical_state(&xi, &eta),
                bits,
            );
        }
    }
}

#[test]
fn ellipsoidal_poles_and_exact_near_edge_rejections_include_extreme_parameters() {
    for m in [
        Real::zero(),
        "0.5".parse().unwrap(),
        "0.99".parse().unwrap(),
        Real::one() - "1e-200".parse::<Real>().unwrap(),
    ] {
        let h = Real::one() - &m;
        let forward_edge = (&h / Real::from(9)).unwrap();
        let reverse_edge = (&h / Real::from(6)).unwrap();
        let offset = &h * "1e-60".parse::<Real>().unwrap();
        for longitude_sign in [-1, 1] {
            let longitude = Real::from(longitude_sign) * &forward_edge;
            for latitude_sign in [-1, 1] {
                let phi = (Real::from(latitude_sign) * Real::pi() / Real::from(2)).unwrap();
                let expected = [
                    Complex::from(Real::from(latitude_sign)),
                    Complex::zero(),
                    Complex::from(h.clone().sqrt().unwrap()),
                    Complex::zero(),
                    Complex::zero(),
                ];
                check(&forward(&phi, &longitude, &m, 384).unwrap(), &expected, 384);
            }
            let outside = Real::from(longitude_sign) * (&forward_edge + &offset);
            assert!(matches!(
                forward(&Real::zero(), &outside, &m, 80),
                Err(ProbeError::InvalidDomain)
            ));
            let outside = Real::from(longitude_sign) * (&reverse_edge + &offset);
            assert!(matches!(
                reverse(&Real::zero(), &outside, &m, 80),
                Err(ProbeError::InvalidDomain)
            ));
        }
    }
}
