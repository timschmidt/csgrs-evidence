use hyperreal::Rational;
use num::BigInt;
use thompson_interval_probe::{Grid, Interval};

#[test]
fn signed_products_and_divisions_enclose_every_small_rational_corner() {
    for bits in [0, 3, 17] {
        let grid = Grid::new(bits);
        let scale = BigInt::from(1_u8) << bits;
        for lo in -3..=3 {
            for hi in lo..=3 {
                for other_lo in -3..=3 {
                    for other_hi in other_lo..=3 {
                        let a = Interval::from_units(lo, hi);
                        let b = Interval::from_units(other_lo, other_hi);
                        let product = grid.multiply(&a, &b);
                        for x in [lo, hi] {
                            for y in [other_lo, other_hi] {
                                let expected = Rational::from_bigint_fraction(
                                    BigInt::from(x * y),
                                    (&scale * &scale).to_biguint().unwrap(),
                                )
                                .unwrap();
                                assert!(grid.contains(&product, &expected));
                            }
                        }
                        if other_lo > 0 {
                            let quotient = grid.divide_positive(&a, &b).unwrap();
                            for x in [lo, hi] {
                                for y in [other_lo, other_hi] {
                                    assert!(grid.contains(
                                        &quotient,
                                        &Rational::fraction(x, y as u64).unwrap()
                                    ));
                                }
                            }
                        } else {
                            assert!(grid.divide_positive(&a, &b).is_none());
                        }
                    }
                }
                for divisor in 1..=7_u32 {
                    let a = Interval::from_units(lo, hi);
                    let result = a.divide_integer(divisor);
                    for x in [lo, hi] {
                        let expected = Rational::from_bigint_fraction(
                            BigInt::from(x),
                            (&scale * divisor).to_biguint().unwrap(),
                        )
                        .unwrap();
                        assert!(grid.contains(&result, &expected));
                    }
                }
            }
        }
    }
}

#[test]
fn rational_ingress_preserves_exact_grid_points_and_encloses_others() {
    for bits in [0, 1, 64, 256] {
        let grid = Grid::new(bits);
        for numerator in -17..=17 {
            for denominator in 1..=19 {
                let rational = Rational::fraction(numerator, denominator).unwrap();
                let bounds = grid.rational(&rational);
                assert!(grid.contains(&bounds, &rational));
                assert!(bounds.width_units() <= BigInt::from(1));
            }
        }
    }
}

#[test]
fn real_ingress_refines_on_the_requested_grid() {
    use hyperreal::Real;
    for bits in [32, 128, 256] {
        let grid = Grid::new(bits);
        for value in [
            Real::zero(),
            Real::one(),
            Real::pi(),
            -Real::e(),
            Real::from(2).sqrt().unwrap(),
        ] {
            let bounds = grid.real(&value).unwrap();
            let expected = value
                .certified_rational_interval(-(bits as i32) - 16)
                .unwrap();
            let actual = grid.endpoints(&bounds);
            assert!(actual[0] <= expected[1] && expected[0] <= actual[1]);
            assert!(bounds.width_units() <= BigInt::from(2));
        }
    }
}
