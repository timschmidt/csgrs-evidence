use crate::{Grid, Interval};
use hyperreal::{Problem, Rational, Real, RealSign};
use num::{BigInt, One, Zero};

#[derive(Debug)]
pub enum ProbeError {
    Numeric(Problem),
    InvalidDomain,
    EvaluationUnavailable,
    PrecisionScheduleExhausted,
}

impl From<Problem> for ProbeError {
    fn from(value: Problem) -> Self {
        Self::Numeric(value)
    }
}

#[derive(Debug)]
pub struct FlowResult {
    /// S, C, D, and (forward only) T and the sigma increment; real/imaginary boxes.
    pub bounds: Vec<[[Rational; 2]; 2]>,
    pub degree: u32,
    pub working_bits: u32,
}

#[derive(Clone)]
struct ComplexInterval {
    re: Interval,
    im: Interval,
}

impl ComplexInterval {
    fn zero() -> Self {
        Self {
            re: Interval::from_units(0, 0),
            im: Interval::from_units(0, 0),
        }
    }

    fn add(&self, other: &Self) -> Self {
        Self {
            re: self.re.add(&other.re),
            im: self.im.add(&other.im),
        }
    }

    fn negate(&self) -> Self {
        Self {
            re: self.re.negate(),
            im: self.im.negate(),
        }
    }

    fn times_i(&self) -> Self {
        Self {
            re: self.im.negate(),
            im: self.re.clone(),
        }
    }

    fn divide_integer(&self, n: u32) -> Self {
        Self {
            re: self.re.divide_integer(n),
            im: self.im.divide_integer(n),
        }
    }

    fn multiply(&self, other: &Self, grid: &Grid) -> Self {
        Self {
            re: grid
                .multiply(&self.re, &other.re)
                .subtract(&grid.multiply(&self.im, &other.im)),
            im: grid
                .multiply(&self.re, &other.im)
                .add(&grid.multiply(&self.im, &other.re)),
        }
    }

    fn scale(&self, factor: &Interval, grid: &Grid) -> Self {
        Self {
            re: grid.multiply(&self.re, factor),
            im: grid.multiply(&self.im, factor),
        }
    }
}

fn convolution(
    a: &[ComplexInterval],
    b: &[ComplexInterval],
    n: usize,
    grid: &Grid,
) -> ComplexInterval {
    let mut result = ComplexInterval::zero();
    for j in 0..=n {
        result = result.add(&a[j].multiply(&b[n - j], grid));
    }
    result
}

fn domain(parameter: &Real, offset: &Real, divisor: i32) -> Result<(Real, Real), ProbeError> {
    match parameter
        .certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION)
        .sign()
    {
        Some(RealSign::Zero | RealSign::Positive) => {}
        Some(RealSign::Negative) => return Err(ProbeError::InvalidDomain),
        None => return Err(ProbeError::EvaluationUnavailable),
    }
    let h = Real::one() - parameter;
    match h
        .certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION)
        .sign()
    {
        Some(RealSign::Positive) => {}
        Some(_) => return Err(ProbeError::InvalidDomain),
        None => return Err(ProbeError::EvaluationUnavailable),
    }
    let bound = (h.clone() / Real::from(divisor))?;
    let margin = Real::diff_of_products(&bound, &bound, offset, offset);
    match margin
        .certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION)
        .sign()
    {
        Some(RealSign::Zero | RealSign::Positive) => {}
        Some(RealSign::Negative) => return Err(ProbeError::InvalidDomain),
        None => return Err(ProbeError::EvaluationUnavailable),
    }
    let time = (offset.clone() / &h)?;
    Ok((h, time))
}

/// Probe the forward polynomial flow, returning sigma's increment separately.
pub fn forward(
    phi: &Real,
    longitude: &Real,
    parameter: &Real,
    bits: u32,
) -> Result<FlowResult, ProbeError> {
    let (h, time) = domain(parameter, longitude, 9)?;
    let s = phi.clone().sin();
    let c = phi.clone().cos();
    let d = (&h + parameter * &c * &c).sqrt()?;
    let t = (c.clone() / &d)?;
    evaluate(
        &[s, c, d, t, Real::zero()],
        parameter,
        &h,
        &time,
        bits,
        false,
    )
}

/// Probe reverse continuation from a given real meridian latitude.
/// This does not implement the inverse-meridian construction from northing.
pub fn reverse(
    phi: &Real,
    easting: &Real,
    parameter: &Real,
    bits: u32,
) -> Result<FlowResult, ProbeError> {
    let (h, time) = domain(parameter, easting, 6)?;
    let s = phi.clone().sin();
    let c = phi.clone().cos();
    let d = (&h + parameter * &c * &c).sqrt()?;
    evaluate(&[s, c, d], parameter, &h, &time, bits, true)
}

/// Continue from normalized northing using the exact quarter-period identities.
pub fn reverse_from_northing(
    northing: &Real,
    easting: &Real,
    parameter: &Real,
    bits: u32,
) -> Result<FlowResult, ProbeError> {
    let (h, time) = domain(parameter, easting, 6)?;
    let complete = Real::elliptic_e_complete(parameter)?;
    let margin = Real::diff_of_products(&complete, &complete, northing, northing);
    match margin
        .certified_sign_until(Real::PARTIAL_CMP_MIN_PRECISION)
        .sign()
    {
        Some(RealSign::Positive) => {}
        Some(_) => return Err(ProbeError::InvalidDomain),
        None => return Err(ProbeError::EvaluationUnavailable),
    }
    let amplitude = (complete - northing).inverse_elliptic_e(parameter)?;
    let sine = amplitude.clone().sin();
    let cosine = amplitude.cos();
    let denominator = (&h + parameter * &cosine * &cosine).sqrt()?;
    let root_h = h.clone().sqrt()?;
    let s = (cosine / &denominator)?;
    let c = (&root_h * sine / &denominator)?;
    let d = (root_h / denominator)?;
    evaluate(&[s, c, d], parameter, &h, &time, bits, true)
}

fn evaluate(
    initial: &[Real],
    parameter: &Real,
    complement: &Real,
    time: &Real,
    bits: u32,
    reverse: bool,
) -> Result<FlowResult, ProbeError> {
    let degree = bits
        .checked_add(8)
        .ok_or(ProbeError::PrecisionScheduleExhausted)?;
    let start = bits
        .checked_add(48)
        .ok_or(ProbeError::PrecisionScheduleExhausted)?;
    let q = Rational::fraction(1, if reverse { 2 } else { 3 })?;
    let omitted = degree
        .checked_add(1)
        .ok_or(ProbeError::PrecisionScheduleExhausted)?;
    let tail = q.clone().powi(omitted.into())? / (Rational::one() - q);
    // A prototype scheduling cap, not a proof that this precision always suffices.
    for multiplier in [1, 2, 4, 8] {
        let work = start
            .checked_mul(multiplier)
            .ok_or(ProbeError::PrecisionScheduleExhausted)?;
        let grid = Grid::new(work);
        let mi = grid
            .real(parameter)
            .ok_or(ProbeError::EvaluationUnavailable)?;
        let hi = grid
            .real(complement)
            .ok_or(ProbeError::EvaluationUnavailable)?;
        let mi = Interval {
            lo: mi.lo.max(BigInt::zero()),
            hi: mi.hi.min(grid.scale.clone()),
        };
        let hi = Interval {
            lo: hi.lo.max(BigInt::zero()),
            hi: hi.hi.min(grid.scale.clone()),
        };
        let ti = grid.real(time).ok_or(ProbeError::EvaluationUnavailable)?;
        let mut series = Vec::with_capacity(initial.len());
        for value in initial {
            let interval = grid.real(value).ok_or(ProbeError::EvaluationUnavailable)?;
            let interval = Interval {
                lo: interval.lo.max(-&grid.scale),
                hi: interval.hi.min(grid.scale.clone()),
            };
            assert!(
                interval.lo <= interval.hi,
                "proved initial unit bound intersects its enclosure"
            );
            series.push(vec![ComplexInterval {
                re: interval,
                im: Interval::from_units(0, 0),
            }]);
        }
        let mut c2 = Vec::new();
        let mut d2 = Vec::new();
        let mut sc = Vec::new();
        let mut sc2 = Vec::new();
        let mut d3 = Vec::new();
        for n in 0..degree as usize {
            let (s, c, d) = (&series[0], &series[1], &series[2]);
            c2.push(convolution(c, c, n, &grid));
            d2.push(convolution(d, d, n, &grid));
            sc.push(convolution(s, c, n, &grid));
            let derivatives = if reverse {
                d3.push(convolution(d, &d2, n, &grid));
                vec![
                    convolution(c, &d3, n, &grid),
                    convolution(s, &d3, n, &grid).negate(),
                    convolution(&sc, &d2, n, &grid).scale(&mi, &grid).negate(),
                ]
            } else {
                let t = &series[3];
                sc2.push(convolution(s, &c2, n, &grid));
                vec![
                    convolution(&c2, &d2, n, &grid),
                    convolution(&sc, &d2, n, &grid).negate(),
                    convolution(&sc2, d, n, &grid).scale(&mi, &grid).negate(),
                    convolution(s, t, n, &grid).scale(&hi, &grid).negate(),
                    t[n].scale(&hi, &grid),
                ]
            };
            for (coefficients, value) in series.iter_mut().zip(derivatives) {
                coefficients.push(value.times_i().divide_integer(n as u32 + 1));
            }
        }
        let tail_units = grid.rational(&tail).hi;
        let mut result = Vec::with_capacity(initial.len());
        for coefficients in series {
            let mut value = coefficients.last().unwrap().clone();
            for coefficient in coefficients[..coefficients.len() - 1].iter().rev() {
                value = value.scale(&ti, &grid).add(coefficient);
            }
            for interval in [&mut value.re, &mut value.im] {
                interval.lo -= &tail_units;
                interval.hi += &tail_units;
            }
            result.push(value);
        }
        let allowed_width = BigInt::one() << (work - bits);
        if result
            .iter()
            .all(|v| v.re.width_units() <= allowed_width && v.im.width_units() <= allowed_width)
        {
            return Ok(FlowResult {
                bounds: result
                    .iter()
                    .map(|v| [grid.endpoints(&v.re), grid.endpoints(&v.im)])
                    .collect(),
                degree,
                working_bits: work,
            });
        }
    }
    Err(ProbeError::PrecisionScheduleExhausted)
}
