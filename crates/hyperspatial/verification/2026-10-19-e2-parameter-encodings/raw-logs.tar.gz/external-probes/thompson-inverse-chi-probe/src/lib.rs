//! Research harness for outward arithmetic; no production exact-function API.

use hyperreal::{Rational, Real};
use num::{BigInt, BigUint, Integer, One, Zero};

mod flow;
pub use flow::{FlowResult, ProbeError, forward, reverse, reverse_from_northing};

#[derive(Clone, Debug)]
pub struct Interval {
    pub lo: BigInt,
    pub hi: BigInt,
}

impl Interval {
    pub fn from_units(lo: i64, hi: i64) -> Self {
        assert!(lo <= hi);
        Self {
            lo: lo.into(),
            hi: hi.into(),
        }
    }

    pub fn width_units(&self) -> BigInt {
        &self.hi - &self.lo
    }

    pub fn add(&self, other: &Self) -> Self {
        Self {
            lo: &self.lo + &other.lo,
            hi: &self.hi + &other.hi,
        }
    }

    pub fn negate(&self) -> Self {
        Self {
            lo: -&self.hi,
            hi: -&self.lo,
        }
    }

    pub fn subtract(&self, other: &Self) -> Self {
        Self {
            lo: &self.lo - &other.hi,
            hi: &self.hi - &other.lo,
        }
    }

    /// Positive integer coefficient divisor; zero is outside this helper's domain.
    pub fn divide_integer(&self, divisor: u32) -> Self {
        assert!(divisor > 0);
        let divisor = BigInt::from(divisor);
        Self {
            lo: self.lo.div_floor(&divisor),
            hi: self.hi.div_ceil(&divisor),
        }
    }
}

#[derive(Clone, Debug)]
pub struct Grid {
    bits: u32,
    scale: BigInt,
}

impl Grid {
    pub fn new(bits: u32) -> Self {
        Self {
            bits,
            scale: BigInt::one() << bits,
        }
    }

    pub fn rational(&self, value: &Rational) -> Interval {
        let numerator = BigInt::from_biguint(value.sign(), value.numerator().clone()) << self.bits;
        let denominator = BigInt::from(value.denominator().clone());
        Interval {
            lo: numerator.div_floor(&denominator),
            hi: numerator.div_ceil(&denominator),
        }
    }

    pub fn real(&self, value: &Real) -> Option<Interval> {
        let precision = i32::try_from(self.bits)
            .ok()?
            .checked_add(4)?
            .checked_neg()?;
        let [lo, hi] = value.certified_rational_interval(precision)?;
        Some(Interval {
            lo: self.rational(&lo).lo,
            hi: self.rational(&hi).hi,
        })
    }

    pub fn endpoints(&self, value: &Interval) -> [Rational; 2] {
        [&value.lo, &value.hi].map(|n| {
            Rational::from_bigint_fraction(n.clone(), BigUint::one() << self.bits).unwrap()
        })
    }

    pub fn contains(&self, value: &Interval, point: &Rational) -> bool {
        let [lo, hi] = self.endpoints(value);
        lo <= *point && *point <= hi
    }

    pub fn multiply(&self, a: &Interval, b: &Interval) -> Interval {
        let products = [&a.lo * &b.lo, &a.lo * &b.hi, &a.hi * &b.lo, &a.hi * &b.hi];
        Interval {
            lo: products.iter().min().unwrap().div_floor(&self.scale),
            hi: products.iter().max().unwrap().div_ceil(&self.scale),
        }
    }

    pub fn divide_positive(&self, a: &Interval, b: &Interval) -> Option<Interval> {
        if b.lo <= BigInt::zero() {
            return None;
        }
        let pairs = [
            (&a.lo, &b.lo),
            (&a.lo, &b.hi),
            (&a.hi, &b.lo),
            (&a.hi, &b.hi),
        ];
        let lo = pairs
            .iter()
            .map(|(n, d)| (*n << self.bits).div_floor(d))
            .min()
            .unwrap();
        let hi = pairs
            .iter()
            .map(|(n, d)| (*n << self.bits).div_ceil(d))
            .max()
            .unwrap();
        Some(Interval { lo, hi })
    }
}
