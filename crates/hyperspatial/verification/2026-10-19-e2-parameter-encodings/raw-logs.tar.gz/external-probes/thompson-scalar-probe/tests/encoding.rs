use hyperreal::{Rational, Real};
#[path = "../../thompson-scalar-candidate/crates/hyperreal/tests/support/representations.rs"]
mod representations;

#[test]
fn bounded_parameter_encodings_retain_all_scalar_family_values() {
    for case in representations::optimized_certificate_representatives() {
        assert_eq!(case.value.detailed_facts().symbolic.kind, case.public_kind);
        let value = &case.value;
        let unit = (value / (value + Real::one())).unwrap();
        let m = (&unit / Real::from(2)).unwrap();
        let h = Real::one() - &m;
        let r = (m.clone() / &h).unwrap().sqrt().unwrap();
        let decoded_h = (Real::one() / (Real::one() + &r * &r)).unwrap();
        assert_eq!((decoded_h - h).exact_rational_normal_form(), Some(Rational::zero()), "parameter {}",case.certificate);
        for sign in [-1,1] {
            let v = Real::from(sign)*&unit;
            let a = (v.clone() / (Real::one()-&v*&v).sqrt().unwrap()).unwrap();
            let decoded_v = (a.clone() / (Real::one()+&a*&a).sqrt().unwrap()).unwrap();
            assert_eq!((decoded_v - &v).exact_rational_normal_form(), Some(Rational::zero()), "meridian {} / {sign}",case.certificate);
            let decoded_time = v.clone().asin().unwrap().sin();
            assert_eq!((decoded_time - v).exact_rational_normal_form(), Some(Rational::zero()), "time {} / {sign}",case.certificate);
        }
    }
    for v in [Real::zero(),Real::one(),-Real::one()] {
        assert_eq!((v.clone().asin().unwrap().sin()-v).exact_rational_normal_form(),Some(Rational::zero()));
    }
}
