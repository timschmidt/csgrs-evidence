use hyperreal::{Rational, Real};
#[path = "../../thompson-scalar-candidate/crates/hyperreal/tests/support/representations.rs"]
mod representations;

fn replay(value: &[Real; 5]) -> [Real; 5] {
    serde_json::from_str(&serde_json::to_string(value).unwrap()).unwrap()
}

fn encoded(v: Real, m: Real) -> [Real; 5] {
    let r = (&m / (Real::one() - &m)).unwrap().sqrt().unwrap();
    let a = (&v / (Real::one() - &v * &v).sqrt().unwrap()).unwrap();
    let tau = v.clone().asin().unwrap();
    [v, m, r, a, tau]
}

fn accept([v, m, r, a, tau]: [Real; 5], context: &str) {
    let decoded_h = (Real::one() / (Real::one() + &r * &r)).unwrap();
    let decoded_v = (&a / (Real::one() + &a * &a).sqrt().unwrap()).unwrap();
    for (label, residual) in [
        ("parameter", decoded_h - (Real::one() - m)),
        ("meridian", decoded_v - &v),
        ("time", tau.sin() - v),
    ] {
        assert_eq!(
            residual.exact_rational_normal_form(),
            Some(Rational::zero()),
            "{context}: {label}"
        );
        assert_eq!(
            residual.sin().exact_rational_normal_form(),
            Some(Rational::zero())
        );
    }
}

#[test]
fn serialized_parameter_encodings_replay_cold_and_after_display_warming() {
    for case in representations::optimized_certificate_representatives() {
        assert_eq!(case.value.detailed_facts().symbolic.kind, case.public_kind);
        let unit = (&case.value / (&case.value + Real::one())).unwrap();
        let m = (&unit / Real::from(2)).unwrap();
        for sign in [-1, 1] {
            let source = encoded(Real::from(sign) * &unit, m.clone());
            for warm in [false, true] {
                let decoded = replay(&source);
                if warm {
                    for value in &decoded {
                        let _ = value.to_f64_lossy();
                    }
                }
                accept(
                    decoded,
                    &format!("{} sign={sign} warm={warm}", case.certificate),
                );
            }
        }
    }
}

#[test]
fn parameter_zero_and_exact_near_endpoint_offsets_survive_replay() {
    let delta: Real = "1e-100".parse().unwrap();
    for m in [Real::zero(), delta.clone(), Real::one() - &delta] {
        for v in [Real::zero(), -Real::one() + &delta, Real::one() - &delta] {
            accept(replay(&encoded(v, m.clone())), "boundary");
        }
    }
}
