// Baseline acceptance reproduction.
