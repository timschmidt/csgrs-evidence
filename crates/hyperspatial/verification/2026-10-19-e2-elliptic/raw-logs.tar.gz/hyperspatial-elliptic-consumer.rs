use hyperreal::Real;
fn main() {
    for (index, xyz) in [["0","0.25","1"],["2","3","5"],["0","2","2"],["0.125","0.5","0.75"]].into_iter().enumerate() {
        let [x,y,z] = xyz.map(|s| s.parse::<Real>().unwrap());
        for (kind,value) in [("RF",Real::elliptic_rf(&x,&y,&z).unwrap()),("RD",Real::elliptic_rd(&x,&y,&z).unwrap())] {
            let json = value.to_json();
            println!("model\t{index}\t{kind}\t{json}");
            for bits in [32,128,512,64] {
                let [lo,hi] = value.certified_rational_interval(-bits).unwrap();
                assert!(lo > hyperreal::Rational::zero());
                println!("interval\t{index}\t{kind}\t{bits}\t{}/{}\t{}/{}",lo.numerator(),lo.denominator(),hi.numerator(),hi.denominator());
                assert_eq!(json,value.to_json());
            }
            let composed = value.ln().unwrap().exp().unwrap();
            assert!(composed.certified_rational_interval(-128).is_some());
        }
    }
}
