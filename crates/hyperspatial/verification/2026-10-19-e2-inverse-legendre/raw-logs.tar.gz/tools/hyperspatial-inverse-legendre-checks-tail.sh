#!/usr/bin/env bash
set -euo pipefail
# Repeat the corrected default-feature doctest, then complete the commands
# after the original checks.sh invocation stopped at that README type error.
cargo test --locked -p hyperspatial --no-default-features --doc
cargo test --locked -p hyperspatial --all-targets --all-features
cargo test --locked -p hyperspatial --doc --all-features
cargo clippy --locked -p hyperspatial --all-targets --all-features -- -D warnings
RUSTDOCFLAGS="${RUSTDOCFLAGS:-} -D warnings" cargo doc --locked -p hyperspatial --no-deps --all-features
python3 crates/hyperspatial/scripts/source-consumer.py
cargo check --locked --manifest-path crates/hyperspatial/fuzz/Cargo.toml --bins
cargo clippy --locked --manifest-path crates/hyperspatial/fuzz/Cargo.toml --bins -- -D warnings
