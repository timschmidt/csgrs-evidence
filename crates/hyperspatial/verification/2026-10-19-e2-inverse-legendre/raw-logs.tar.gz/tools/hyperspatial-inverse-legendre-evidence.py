import hashlib, io, json, os, platform, re, shutil, subprocess, tarfile
from pathlib import Path
root=Path.cwd()
out=root/'crates/hyperspatial/verification/2026-10-19-e2-inverse-legendre'
out.mkdir(parents=True,exist_ok=True)
def write(name,value): (out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def copy(source,name): shutil.copyfile(source,out/name)
equivalence=json.loads((out/'source-equivalence.json').read_text())
before=Path('/tmp/hyperspatial-inverse-legendre-certified-interval-measured.rs').read_bytes()
after=Path(equivalence['path']).read_bytes()
assert before==after+b'\n'
assert hashlib.sha256(before).hexdigest()==equivalence['measured_sha256']
assert hashlib.sha256(after).hexdigest()==equivalence['final_sha256']
def validate_hashes(hashes,base=root):
 for name,digest in hashes.items():
  path=base/name
  if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
   assert path==root/equivalence['path'] and digest==equivalence['measured_sha256'], name
def run(*args): return subprocess.check_output(args,text=True).strip()
def suites(path):
 s=Path(path).read_text()
 return [{'status':m[0],'passed':int(m[1]),'failed':int(m[2])} for m in re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed',s)]
logs=sorted(Path('/tmp').glob('hyperspatial-inverse-legendre-*.log'))
counts={p.name:suites(p) for p in logs if 'test result:' in p.read_text()}
write('test-counts.json',counts)
for source,name in [
 ('target/hyperspatial-directed-inverse-legendre/report.json','directed-report.json'),
 ('target/hyperspatial-directed-inverse-legendre/observations.jsonl.gz','directed-observations.jsonl.gz'),
 ('target/hyperspatial-asan-inverse-legendre/report.json','asan.json'),
 ('target/hyperspatial-coverage/coverage.json','coverage.json'),
 ('/tmp/hyperspatial-inverse-legendre-bench-resources.json','benchmark-resources.json'),
]: copy(source,name)
for source,name in [('/tmp/hyperspatial-inverse-legendre-bench-final.jsonl','bench.json'),
                    ('/tmp/hyperspatial-inverse-legendre-msrv-bench.log','bench-msrv.json')]:
 rows=[json.loads(line) for line in Path(source).read_text().splitlines() if line.startswith('{')]
 assert len(rows)==120 and all(row['accepted']==row['repeats'] for row in rows)
 write(name,rows)
coverage=json.loads((out/'coverage.json').read_text())
validate_hashes(coverage['source_sha256'],root/'crates/hyperspatial')
for label in ['native_inverse','native_exponential','native_elliptic','native_legendre','native_inverse_legendre']:
 validate_hashes(coverage[label]['source_sha256'])
assert coverage['native_inverse_legendre']['totals']['lines']['percent']>=95
for name in ['directed-report.json','asan.json']:
 validate_hashes(json.loads((out/name).read_text())['source_sha256'])
commands={
 'final_helper':'cargo test --offline -p hyperreal --all-features --lib inverse_legendre_tests; cargo test --offline -p hyperreal --all-features --lib isometric_precision_tests',
 'final_spatial':'cargo test --offline --release -p hyperspatial --test inverse_legendre_representations',
 'native_all':'cargo test --offline -p hyperreal --all-features',
 'native_msrv':'RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv cargo test --offline -p hyperreal --test inverse_legendre --features serde',
 'native_msrv_final_oracle':'RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv cargo test --offline -p hyperreal --test inverse_legendre --features serde independent_inverse_oracle_accepts_fresh_rational_inputs -- --exact',
 'spatial_stable':'bash crates/hyperspatial/scripts/checks.sh, then bash /tmp/hyperspatial-inverse-legendre-checks-tail.sh after the README error-type annotation fix; the exact tail script is retained in the raw archive',
 'spatial_msrv':'Same spatial commands with RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv',
 'cache_matrix':'for features in serde serde,cached-f32-approx serde,cached-f64-approx serde,cached-f32-approx,cached-f64-approx; do cargo test --offline --release -p hyperreal --no-default-features --features "$features" --test inverse_legendre; dependency_features="hyperreal/${features//,/,hyperreal/}"; cargo test --offline --release -p hyperspatial --test inverse_legendre_representations --no-default-features --features "$dependency_features"; done',
 'clippy':'cargo clippy --offline -p hyperreal --all-targets --all-features -- -D warnings; stable and MSRV, final helper source',
 'rustdoc':'RUSTDOCFLAGS="-D warnings" cargo doc --offline -p hyperreal --no-deps --all-features',
 'downstream':'cargo test --offline -p hyperlattice -p hyperlimit --lib; then the same command with --all-features',
 'wasm':'cargo check --offline -p hyperspatial --lib --target wasm32-unknown-unknown --all-features; cargo clippy --offline -p hyperspatial --lib --target wasm32-unknown-unknown --all-features -- -D warnings',
 'benchmark_stable':'cargo bench --offline -p hyperreal --bench inverse_legendre --no-run --message-format=json; run the compiler-artifact executable as the sole child of a fresh Python process; resource.getrusage(RUSAGE_CHILDREN) measures that child only',
 'benchmark_msrv':'RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv cargo bench --offline -p hyperreal --bench inverse_legendre',
 'gmp_api':"cargo bench --offline -p hyperreal --bench gmp_api -- 'jacobi_amplitude|inverse_elliptic_e' --sample-size 10 --warm-up-time 0.1 --measurement-time 1",
 'directed':'python3 crates/hyperspatial/scripts/directed.py --workload inverse_legendre --output target/hyperspatial-directed-inverse-legendre',
 'asan':'python3 crates/hyperspatial/scripts/fuzz-smoke.py --targets inverse_legendre --inverse-legendre-corpus target/hyperspatial-directed-inverse-legendre/corpus --output target/hyperspatial-asan-inverse-legendre',
 'coverage':'python3 crates/hyperspatial/scripts/coverage.py',
 'coverage_gate_regressions':'python3 crates/hyperspatial/scripts/coverage-gates.py',
 'source_consumer':'python3 crates/hyperspatial/scripts/source-consumer.py',
 'zizmor':'UV_TOOL_DIR=/tmp/hyperspatial-uv-tools UV_TOOL_BIN_DIR=/tmp/hyperspatial-uv-bin uv --cache-dir /tmp/hyperspatial-uv-cache tool run --offline zizmor --pedantic --strict-collection .',
 'format':'cargo fmt --all -- --check; cargo fmt --manifest-path crates/hyperspatial/fuzz/Cargo.toml -- --check',
 'syntax':'python3 -m py_compile crates/hyperspatial/scripts/{coverage,coverage_common,coverage-gates,directed,fuzz-smoke}.py; bash -n crates/hyperspatial/scripts/{checks,representation-checks}.sh; git diff --check',
}
write('commands.json',commands)
changed=set(run('git','diff','--name-only','HEAD').splitlines()) | set(run('git','ls-files','--others','--exclude-standard').splitlines())
changed={p for p in changed if not p.startswith(str(out.relative_to(root))+'/')}
source=sorted(changed | {'Cargo.lock','Cargo.toml','crates/hyperspatial/Cargo.toml','crates/hyperspatial/fuzz/Cargo.lock'})
metadata={'baseline':run('git','rev-parse','HEAD'),'branch':run('git','branch','--show-current'),
 'compiler':run('rustc','-vV'),'msrv':run('rustc','+1.95.0','-vV'),'nightly':run('rustc','+nightly','-vV'),
 'platform':platform.platform(),'cpu':next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'unknown'),
 'environment':{'PATH_additions':['/tmp/hyperspatial-build-tools/usr/bin','/tmp/hyperspatial-fuzz-tools/bin'], 'GMP_MPFR_SYS_CACHE':'/tmp/hyperspatial-gmp-cache','network':'Cargo offline; online primary reference research only'},
 'measurement_source_equivalence':equivalence,
 'source_sha256':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in source}}
assert metadata['baseline'].startswith('0171a2a48') and metadata['branch']=='hyperspatial'
write('source-metadata.json',metadata)
entries={}
for p in logs: entries['logs/'+p.name]=p.read_bytes()
for name in ['hyperspatial-inverse-legendre-checks-tail.sh','hyperspatial-inverse-legendre-bench-artifacts.jsonl','hyperspatial-inverse-legendre-bench-final.jsonl','hyperspatial-inverse-legendre-bench-resources.json','hyperspatial-inverse-legendre-benchmarks-generated.md','hyperspatial-inverse-legendre-evidence.py','hyperspatial-inverse-legendre-certified-interval-measured.rs']:
 p=Path('/tmp')/name; entries['tools/'+name]=p.read_bytes()
for folder,prefix in [('target/hyperspatial-directed-inverse-legendre/corpus','directed/corpus'),('target/hyperspatial-asan-inverse-legendre/inverse_legendre-corpus','asan/corpus')]:
 for p in sorted(Path(folder).iterdir()):
  if p.is_file(): entries[prefix+'/'+p.name]=p.read_bytes()
entries['asan/inverse_legendre.log']=Path('target/hyperspatial-asan-inverse-legendre/inverse_legendre.log').read_bytes()
for p in source: entries['source/'+p]=Path(p).read_bytes()
with tarfile.open(out/'raw-logs.tar.gz','w:gz') as archive:
 for name,content in sorted(entries.items()):
  item=tarfile.TarInfo(name); item.size=len(content); item.mtime=0; item.mode=0o644
  archive.addfile(item,io.BytesIO(content))
write('raw-log-manifest.json',{name:{'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()} for name,content in sorted(entries.items())})
print('Archived',len(entries),'entries; final changed-source hashes',len(metadata['source_sha256']))
