import datetime
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/mnt/development/hyperspatial/csgrs')
prefix = Path('/tmp/hyperspatial-jacobi')
base = os.environ.copy()
base['PATH'] = '/tmp/hyperspatial-build-tools/usr/bin:' + base['PATH']
base['GMP_MPFR_SYS_CACHE'] = '/tmp/hyperspatial-gmp-cache'
commands = [
    ('bench-stable-final', ['cargo','bench','--locked','-p','hyperreal','--bench','jacobi'], {}),
    ('gmp-api', ['cargo','bench','--locked','-p','hyperreal','--bench','gmp_api','--','jacobi_sncndn','--sample-size','10','--warm-up-time','0.1','--measurement-time','0.2'], {}),
    ('native-docs', ['cargo','doc','--locked','-p','hyperreal','--all-features','--no-deps'], {'RUSTDOCFLAGS':'-D warnings'}),
    ('wasm-check-final', ['cargo','check','--locked','-p','hyperspatial','--lib','--all-features','--target','wasm32-unknown-unknown'], {}),
    ('wasm-clippy-final', ['cargo','clippy','--locked','-p','hyperspatial','--lib','--all-features','--target','wasm32-unknown-unknown','--','-D','warnings'], {}),
    ('native-msrv', ['cargo','test','--locked','-p','hyperreal','--test','jacobi','--features','serde'], {'RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TARGET_DIR':'target/hyperspatial-msrv'}),
    ('native-msrv-private', ['cargo','test','--locked','-p','hyperreal','--lib','jacobi','--features','serde'], {'RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TARGET_DIR':'target/hyperspatial-msrv'}),
    ('native-msrv-range', ['cargo','test','--locked','-p','hyperreal','--lib','range_reduction_tests','--features','serde'], {'RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TARGET_DIR':'target/hyperspatial-msrv'}),
    ('native-msrv-clippy', ['cargo','clippy','--locked','-p','hyperreal','--all-targets','--all-features','--','-D','warnings'], {'RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TARGET_DIR':'target/hyperspatial-msrv'}),
    ('bench-msrv', ['cargo','bench','--locked','-p','hyperreal','--bench','jacobi'], {'RUSTUP_TOOLCHAIN':'1.95.0','CARGO_TARGET_DIR':'target/hyperspatial-msrv'}),
    ('curves-final', ['cargo','test','--locked','-p','hypercurve','--test','hypercurve_circle_predicates','--test','hypercurve_curve','--test','hypercurve_contour'], {}),
]
records=[]
for name, command, overrides in commands:
    environment=base | overrides
    entry={'name':name,'command':command,'environment':overrides,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    started=time.monotonic()
    report=root/'crates/hyperreal/benchmarks.md'
    previous=report.read_bytes() if name=='gmp-api' else None
    try:
        with Path(str(prefix)+'-'+name+'.log').open('w') as log:
            entry['returncode']=subprocess.run(command,cwd=root,env=environment,stdout=log,stderr=subprocess.STDOUT).returncode
    finally:
        if previous is not None:
            Path(str(prefix)+'-gmp-generated.md').write_bytes(report.read_bytes())
            report.write_bytes(previous)
    entry['elapsed_seconds']=time.monotonic()-started
    records.append(entry)
    Path(str(prefix)+'-remaining.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(entry),flush=True)
    if entry['returncode']:
        raise SystemExit(entry['returncode'])
