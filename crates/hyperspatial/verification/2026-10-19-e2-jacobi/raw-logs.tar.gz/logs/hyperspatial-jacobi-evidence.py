"""Assemble final Jacobi evidence after the listed validation processes finish."""
import datetime
import hashlib
import io
import json
import platform
import re
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/mnt/development/hyperspatial/csgrs')
OUT = ROOT / 'crates/hyperspatial/verification/2026-10-19-e2-jacobi'
OUT.mkdir(parents=True, exist_ok=True)

def read_json(path):
    return json.loads(Path(path).read_text())

def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()

def verify_hashes(report, prefix=ROOT):
    for name, expected in report['source_sha256'].items():
        assert sha((prefix / name).read_bytes()) == expected, name
    return len(report['source_sha256'])

coverage = read_json(ROOT / 'target/hyperspatial-coverage/coverage.json')
assert 'native_jacobi' in coverage
verify_hashes(coverage, ROOT / 'crates/hyperspatial')
for key in ['native_inverse', 'native_exponential', 'native_elliptic',
            'native_legendre', 'native_inverse_legendre', 'native_jacobi']:
    verify_hashes(coverage[key])
write_json('coverage.json', coverage)

directed = read_json(ROOT / 'target/hyperspatial-directed-jacobi-final/report.json')
directed_hash_count = verify_hashes(directed)
write_json('directed-report.json', directed)
asan = read_json(ROOT / 'target/hyperspatial-asan-jacobi-mutation/report.json')
asan_hash_count = verify_hashes(asan)
assert len(asan['campaigns']) == 1
assert asan['campaigns'][0]['returncode'] == 0
assert not asan['campaigns'][0]['artifacts']
asan_log = (ROOT / 'target/hyperspatial-asan-jacobi-mutation/jacobi.log').read_text()
assert 'INITED' in asan_log and 'NEW' in asan_log and 'DONE' in asan_log
write_json('asan.json', asan)
write_json('asan-seed-replay.json', read_json(ROOT / 'target/hyperspatial-asan-jacobi-final/report.json'))

remaining = read_json('/tmp/hyperspatial-jacobi-remaining.json')
assert len(remaining) == 11 and all(row['returncode'] == 0 for row in remaining)
write_json('timed-commands.json', remaining)
write_json('benchmark-resources.json', read_json('/tmp/hyperspatial-jacobi-resource.json'))
for source, destination in [('bench-stable-final', 'bench.json'), ('bench-msrv', 'bench-msrv.json'),
                            ('resource-run', 'bench-resource-run.json')]:
    rows = [json.loads(line) for line in Path('/tmp/hyperspatial-jacobi-' + source + '.log').read_text().splitlines()
            if line.startswith('{')]
    assert len(rows) == 60 and all(row['accepted'] == row['repeats'] for row in rows)
    assert sum(row['accepted'] for row in rows) == 1060
    write_json(destination, rows)

counts = {}
for name in ['native-all-final', 'downstream-final', 'curves-final', 'native-msrv',
             'native-msrv-private', 'native-msrv-range', 'stable-checks-final',
             'msrv-checks-final', 'cache-matrix-final', 'coverage-final']:
    log = Path('/tmp/hyperspatial-jacobi-' + name + '.log').read_text()
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', log)
    assert rows and 'test result: FAILED.' not in log
    counts[name] = {'passing_test_executions': sum(int(row[0]) for row in rows),
                    'successful_suites': len(rows), 'failed_tests': sum(int(row[1]) for row in rows)}
assert counts['native-all-final']['passing_test_executions'] == 1165
for name in ['stable-checks-final', 'msrv-checks-final']:
    assert counts[name]['passing_test_executions'] == 170
assert counts['cache-matrix-final']['passing_test_executions'] == 360
assert counts['cache-matrix-final']['successful_suites'] == 84
write_json('test-counts.json', counts)

exits = read_json('/tmp/hyperspatial-jacobi-process-exits.json')
for name in ['stable-checks-final', 'msrv-checks-final', 'cache-matrix-final',
             'coverage-final', 'asan-mutation', 'format-final', 'zizmor-final']:
    assert exits[name]['returncode'] == 0, name
write_json('process-exits.json', exits)

records = {
    'native_all': 'cargo test --locked -p hyperreal --all-features',
    'native_clippy': 'cargo clippy --locked -p hyperreal --all-targets --all-features -- -D warnings',
    'downstream': 'cargo test --locked -p hyperlattice -p hyperlimit --lib --all-features',
    'spatial_stable': 'bash crates/hyperspatial/scripts/checks.sh',
    'spatial_msrv': 'RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv bash crates/hyperspatial/scripts/checks.sh',
    'cache_matrix': 'CARGO_TARGET_DIR=target/hyperspatial-cache-matrix bash crates/hyperspatial/scripts/representation-checks.sh',
    'cache_profile': 'test profile, opt-level=1, debug-assertions=true, overflow-checks=true; full spatial tests and native Jacobi suite in all four configurations',
    'spatial_benchmarks': 'cargo bench --locked -p hyperspatial --benches; repeated with RUSTUP_TOOLCHAIN=1.95.0 CARGO_TARGET_DIR=target/hyperspatial-msrv',
    'coverage': 'python3 crates/hyperspatial/scripts/coverage.py',
    'coverage_gates': 'python3 crates/hyperspatial/scripts/coverage-gates.py',
    'directed': 'python3 crates/hyperspatial/scripts/directed.py --workload jacobi --output target/hyperspatial-directed-jacobi-final',
    'asan': 'python3 crates/hyperspatial/scripts/fuzz-smoke.py --targets jacobi --jacobi-corpus target/hyperspatial-directed-jacobi-final/corpus --output target/hyperspatial-asan-jacobi-mutation',
    'asan_seed_replay': 'Same command with --jacobi-seconds 900 and output target/hyperspatial-asan-jacobi-final; replay completed without mutations; original driver retained byte-for-byte',
    'format': 'cargo fmt --all -- --check; cargo fmt --manifest-path crates/hyperspatial/fuzz/Cargo.toml -- --check',
    'syntax': 'python3 -m py_compile for changed Python scripts; bash -n for checks.sh and representation-checks.sh; git diff --check',
    'zizmor': 'UV_TOOL_DIR=/tmp/hyperspatial-uv-tools UV_TOOL_BIN_DIR=/tmp/hyperspatial-uv-bin uv --cache-dir /tmp/hyperspatial-uv-cache tool run --offline zizmor --pedantic --strict-collection .',
    'timed_commands': 'See timed-commands.json for stable/MSRV benchmarks, GMP API benchmark, native docs, WASM checks, MSRV tests/Clippy, and curve downstream tests.',
    'excluded': 'No push. Full repository pre-push matrix and hosted workflows not claimed.'
}
write_json('commands.json', records)

paths = set(command('git', 'diff', 'HEAD', '--name-only').splitlines())
paths.update(command('git', 'ls-files', '--others', '--exclude-standard').splitlines())
paths.update(['Cargo.toml', 'Cargo.lock', 'crates/hyperspatial/Cargo.toml', 'crates/hyperspatial/fuzz/Cargo.lock'])
paths = sorted(name for name in paths if not name.startswith('crates/hyperspatial/verification/') and (ROOT / name).is_file())
source_hashes = {name: sha((ROOT / name).read_bytes()) for name in paths}
cpu = next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
metadata = {
    'baseline': command('git', 'rev-parse', 'HEAD'),
    'branch': command('git', 'branch', '--show-current'),
    'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'compiler': command('rustc', '-vV'),
    'msrv': command('rustc', '+1.95.0', '-vV'),
    'nightly': command('rustc', '+nightly', '-vV'),
    'platform': platform.platform(), 'cpu': cpu,
    'source_sha256': source_hashes,
    'verified_campaign_source_hashes': {'directed': directed_hash_count, 'asan_mutation': asan_hash_count},
    'environment': {'GMP_MPFR_SYS_CACHE': '/tmp/hyperspatial-gmp-cache',
                    'PATH_additions': ['/tmp/hyperspatial-build-tools/usr/bin', '/tmp/hyperspatial-fuzz-tools/bin'],
                    'load': 'Concurrent validations on the same host; timings are not comparative speed claims'},
}
write_json('source-metadata.json', metadata)

payloads = {}
for path in sorted(Path('/tmp').glob('hyperspatial-jacobi-*')):
    if path.is_file() and path.suffix in ('.log', '.json', '.py', '.md'):
        payloads['logs/' + path.name] = path.read_bytes()
for name in paths:
    payloads['source/' + name] = (ROOT / name).read_bytes()
for folder, label in [
    ('target/hyperspatial-directed-jacobi-final', 'directed'),
    ('target/hyperspatial-asan-jacobi-final', 'asan-seed-replay'),
    ('target/hyperspatial-asan-jacobi-mutation', 'asan-mutation'),
]:
    base = ROOT / folder
    for path in sorted(base.rglob('*')):
        if path.is_file():
            payloads[label + '/' + str(path.relative_to(base))] = path.read_bytes()
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(payloads.items())}
write_json('raw-log-manifest.json', manifest)
with tarfile.open(OUT / 'raw-logs.tar.gz', 'w:gz') as archive:
    for name, data in sorted(payloads.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(OUT / 'raw-logs.tar.gz') as archive:
    assert set(archive.getnames()) == set(manifest)
    for name, entry in manifest.items():
        data = archive.extractfile(name).read()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
print(json.dumps({'test_counts': counts, 'archive_entries': len(manifest), 'source_hashes': len(source_hashes)}, indent=2))
