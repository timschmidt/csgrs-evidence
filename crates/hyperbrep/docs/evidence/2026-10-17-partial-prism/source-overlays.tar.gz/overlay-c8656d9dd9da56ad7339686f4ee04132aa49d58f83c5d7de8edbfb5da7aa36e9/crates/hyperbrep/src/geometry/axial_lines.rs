//! Complete affine correspondence for axial plane/cylinder intersection lines.

use super::*;

impl SurfaceIntersectionCurve {
    /// Retains a native line segment on a plane and a circular cylinder.
    ///
    /// The plane incidence, axial direction and constant radial distance prove
    /// the whole segment image. The cylinder's angle is constant and its axial
    /// coordinate is affine in the original spatial parameter. Periodic face
    /// lifts are applied later, against the actual authored trim chart.
    pub(crate) fn on_plane_cylinder_line(
        curve: Curve3,
        first: &Surface,
        second: &Surface,
    ) -> GeometryResult<Option<Self>> {
        if curve.kind() != Curve3Kind::Line {
            return Ok(None);
        }
        let (plane, cylinder, cylinder_first) = match (&first.data.geometry, &second.data.geometry) {
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Cylinder(cylinder)) => {
                (plane, cylinder, false)
            }
            (SurfaceGeometry::Cylinder(cylinder), SurfaceGeometry::Plane(plane)) => {
                (plane, cylinder, true)
            }
            _ => return Ok(None),
        };
        let start = curve.start()?;
        let end = curve.end()?;
        let direction = &end - &start;
        let normal = plane.u.cross(&plane.v);
        let zero = |value: Real| -> GeometryResult<bool> {
            Ok(decided_order(compare_reals(&value, &Real::zero(), crate::STRICT_PREDICATES))?
                == Ordering::Equal)
        };
        if !zero(normal.dot(&(&start - &plane.origin)))?
            || !zero(normal.dot(&direction))?
            || !zero(direction.cross(&cylinder.frame.z).norm_squared())?
        {
            return Ok(None);
        }
        let offset = &start - &cylinder.origin;
        let axial_start = offset.dot(&cylinder.frame.z);
        let radial = offset - cylinder.frame.z.clone() * &axial_start;
        if !zero(radial.norm_squared() - &cylinder.radius * &cylinder.radius)? {
            return Ok(None);
        }
        let angle = certified_atan2(radial.dot(&cylinder.frame.y), radial.dot(&cylinder.frame.x))?;
        let axial_delta = direction.dot(&cylinder.frame.z);
        let parameter_span = curve.domain().end() - curve.domain().start();
        let scale = (axial_delta / parameter_span).map_err(GeometryError::Numeric)?;
        let offset = axial_start - &scale * curve.domain().start();
        let cylinder_pcurve = SurfaceIntersectionPcurve::tensor_iso(
            curve.domain().clone(),
            angle,
            TensorAxis::U,
            scale,
            offset,
        );
        let plane_pcurve = SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane);
        Ok(Some(if cylinder_first {
            Self::new(curve, cylinder_pcurve, plane_pcurve)
        } else {
            Self::new(curve, plane_pcurve, cylinder_pcurve)
        }))
    }
}
