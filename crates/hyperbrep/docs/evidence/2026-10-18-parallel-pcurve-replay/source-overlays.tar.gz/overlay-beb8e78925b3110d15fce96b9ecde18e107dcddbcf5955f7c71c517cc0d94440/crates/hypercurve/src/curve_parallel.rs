//! Borrowed structural definitions of exact procedural parallel curves.

use crate::{BezierParallel2, BezierParameterRange2, BezierSplitFragment2, Curve2};

/// A lossless structural view of a finite analytic parallel.
///
/// The parallel retains its polynomial or homogeneous rational source and
/// signed left-normal distance. The ascending range retains selected roots;
/// traversal is independent of its order. This view neither materializes
/// coordinates nor changes proof caches. It describes the current geometry,
/// not the certainty of an earlier construction's intent or its full history.
#[derive(Clone, Copy, Debug)]
pub struct CurveAnalyticParallel2<'a> {
    fragment: &'a crate::BezierParallelFragment2,
}

impl<'a> CurveAnalyticParallel2<'a> {
    /// Borrows the complete procedural support, including source and distance.
    pub const fn parallel(&self) -> &'a BezierParallel2 {
        self.fragment.parallel()
    }

    /// Borrows the ascending finite range in the original source chart.
    pub const fn range(&self) -> &'a BezierParameterRange2 {
        self.fragment.range()
    }

    /// Whether traversal runs from the range's end to its start.
    pub const fn is_reversed(&self) -> bool {
        self.fragment.is_reversed()
    }
}

impl Curve2 {
    /// Borrows a procedural parallel's source, range and traversal definition.
    ///
    /// Other retained carriers and native geometry return `None`; this is not
    /// a geometric equivalence test. For untrusted replay, pass the retained
    /// parallel and oriented range to [`Self::try_analytic_parallel`], which
    /// rechecks poles, undefined normals and unsplit interior cusps. The view
    /// is not a serialized validation certificate.
    pub fn analytic_parallel(&self) -> Option<CurveAnalyticParallel2<'_>> {
        match self.retained_fragment()? {
            BezierSplitFragment2::AnalyticParallel(fragment) => {
                Some(CurveAnalyticParallel2 { fragment })
            }
            _ => None,
        }
    }
}
