#[path = "support/parallel_pcurve_archive.rs"]
mod acceptance;

#[test]
fn nonlinear_parallel_pcurve_replays_exactly() {
    acceptance::nonlinear_parallel_pcurve_replays_exactly();
}
