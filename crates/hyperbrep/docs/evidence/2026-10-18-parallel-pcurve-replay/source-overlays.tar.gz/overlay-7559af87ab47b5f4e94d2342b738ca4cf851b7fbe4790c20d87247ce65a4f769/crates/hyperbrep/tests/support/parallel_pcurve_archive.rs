use hyperbrep::{ArchiveLimits, ModelBuilder, Pcurve, RawModel, Real};
use hypercurve::{BezierParameter2, BezierParameterRange2, Curve2, Point2, QuadraticBezier2};

pub fn nonlinear_parallel_pcurve_replays_exactly() {
    let parallel = QuadraticBezier2::new(
        Point2::from_values(0, 0),
        Point2::from_values(2, 2),
        Point2::from_values(4, 0),
    )
    .parallel_left(Real::one())
    .unwrap();
    let range = BezierParameterRange2::try_new(
        BezierParameter2::Exact(Real::one()),
        BezierParameter2::Exact(Real::zero()),
    )
    .unwrap();
    let curve = Curve2::try_analytic_parallel(parallel, range).unwrap();
    let mut builder = ModelBuilder::new();
    builder.pcurve(Pcurve::new(curve)).unwrap();
    let model = builder.finish().unwrap();
    let json = model.to_json().unwrap();
    let restored = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(restored.counts(), model.counts());
    assert_eq!(restored.to_json().unwrap(), json);
}
