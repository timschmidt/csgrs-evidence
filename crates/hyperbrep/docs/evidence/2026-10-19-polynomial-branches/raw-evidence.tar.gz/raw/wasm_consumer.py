"""Execute every declared no-import WebAssembly acceptance export in order."""
from pathlib import Path
import hashlib,json,sys,time
sys.path.insert(0,'/tmp/hyperbrep-wasmtime')
import wasmtime
p=Path(sys.argv[1]);expected=int(sys.argv[2])
exports=json.loads(Path(sys.argv[3]).read_text()) if len(sys.argv)>3 else [['run_probe',expected]]
assert sum(count for name,count in exports)==expected
assert len({name for name,count in exports})==len(exports)
engine=wasmtime.Engine();module=wasmtime.Module.from_file(engine,str(p))
assert len(module.imports)==0
store=wasmtime.Store(engine);instance=wasmtime.Instance(store,module,[])
start=time.perf_counter();rows=[]
for name,count in exports:
    began=time.perf_counter();groups=instance.exports(store)[name](store)
    assert groups==count,(name,groups,count)
    row=dict(export=name,groups=groups,elapsed_seconds=time.perf_counter()-began)
    rows.append(row);print(json.dumps(row),flush=True)
print(json.dumps(dict(groups=sum(r['groups'] for r in rows),exports=rows,imports=0,elapsed_seconds=time.perf_counter()-start,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Source-path standalone WASM execution; not installed packages or published JavaScript bindings.')),flush=True)
