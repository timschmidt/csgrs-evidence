"""Summarize completed recorded jobs without converting failures into passes."""
from pathlib import Path
import hashlib,json,re,statistics
OUT=Path(__file__).resolve().parent
results=json.loads((OUT/'results.json').read_text())
by_label={r['label']:r for r in results}
assert len(by_label)==len(results)
summary={}
for label,row in by_label.items():
    log=Path(row['log']).read_text(errors='replace')
    tests=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    if tests:
        summary[label]={'exit_code':row['exit_code'],'batches':len(tests),'passed':sum(int(x[1]) for x in tests),'failed':sum(int(x[2]) for x in tests),'ignored':sum(int(x[3]) for x in tests)}
(OUT/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
required=['brep-release-tests-final','v2-curve-strict-clippy','brep-strict-clippy-final','post-admission-warning-denied-doc','post-admission-format-check','post-admission-diff-check','v2-branch-tests','archive-admission-public-after','archive-unit-after','archive-fuzz-target-check','v2-wasm-runtime','v2-native-run','archive-native-run','archive-wasm-runtime','preserved-baseline-run','post-admission-preserved-run','preserved-baseline-artifacts','preserved-candidate-artifacts']
missing=[label for label in required if label not in by_label or by_label[label]['exit_code']!=0]
print('Missing or failing required jobs:',missing)
if missing: raise SystemExit(2)
known={
 'bezier_offset::conversion_tests::independent_oblique_chords_support_constrained_fillet_families': ('baseline-oblique-fillet','Approximate512Consumed'),
 'bezier_offset::conversion_tests::retained_incident_domains_admit_exterior_affine_endpoints': ('baseline-exterior-endpoints','recursive.as_recursive_projective().is_some()'),
}
curve=by_label['v2-curve-release-tests'];assert curve['exit_code']==101
log=Path(curve['log']).read_text()
failed=set(re.findall(r'^test (.+) \.\.\. FAILED$',log,re.M))
assert failed==set(known),(failed,known)
assert summary['v2-curve-release-tests']['failed']==2
inherited=[]
for name,(label,message) in known.items():
    original=by_label[label];assert original['exit_code']==101
    original_log=Path(original['log']).read_text()
    assert name+' ... FAILED' in original_log and message in original_log and message in log
    inherited.append(dict(test=name,baseline_label=label,baseline_revision=original['revision'],candidate_label=curve['label'],failure=message,disposition='Reproduced unchanged on ea05bc2aa; preserved without relaxing assertions. Owner repair remains outside this BRep increment.'))
(OUT/'inherited-failures.json').write_text(json.dumps(inherited,indent=2)+'\n')
for flavor,root in [('candidate','/mnt/development/csgrs/target/hyperbrep-development'),('baseline','/mnt/development/csgrs')]:
    source=json.loads((OUT/(flavor+'-source.json')).read_text())
    assert all(hashlib.sha256((Path(root)/name).read_bytes()).hexdigest()==digest for name,digest in source['files'].items()),flavor
probe=by_label['original-brep-interior-loop-final']
assert probe['exit_code']==101
assert 'UnsupportedIntersection' in Path(probe['log']).read_text()
measurements=[]
for job in json.loads((OUT/'cost-jobs.json').read_text()):
    label=job['label'];assert by_label[label]['exit_code']==0,label
    rows=[json.loads(line) for line in Path(by_label[label]['log']).read_text().splitlines() if line.startswith('{')]
    resource=json.loads((OUT/'costs'/(label+'-resources.json')).read_text())
    assert resource['exit_code']==0
    measurements.append({'label':label,'samples':[r for r in rows if 'case' in r],'layout':[r for r in rows if r.get('kind')=='layout'],'resources':resource})
pairs=[]
for i in range(3):
    before=next(x for x in measurements if x['label']==f'preserved-baseline-{i}')
    after=next(x for x in measurements if x['label']==f'preserved-candidate-{i}')
    assert before['layout']==after['layout'],(before['layout'],after['layout'])
    b={(r['case'],r['phase']):r for r in before['samples']};a={(r['case'],r['phase']):r for r in after['samples']}
    assert a.keys()==b.keys()
    for key in b:
        first,last=b[key],a[key];assert first['iterations']==last['iterations'] and first['outcome']==last['outcome']
        pairs.append({'process_pair':i,'case':key[0],'phase':key[1],'baseline':first,'candidate':last,'time_ratio':last['elapsed_ns']/first['elapsed_ns'],'allocation_call_delta':last['allocation_calls']-first['allocation_calls'],'allocation_byte_delta':last['requested_bytes']-first['requested_bytes']})
phase=[]
for key in sorted({(r['case'],r['phase']) for r in pairs}):
    rows=[r for r in pairs if (r['case'],r['phase'])==key]
    phase.append({'case':key[0],'phase':key[1],'paired_time_ratios':[r['time_ratio'] for r in rows],'median_paired_time_ratio':statistics.median(r['time_ratio'] for r in rows),'allocation_call_deltas':[r['allocation_call_delta'] for r in rows],'allocation_byte_deltas':[r['allocation_byte_delta'] for r in rows]})
(OUT/'consumer-costs.json').write_text(json.dumps({'measurements':measurements,'paired_samples':pairs,'phase_summary':phase,'scope':'Matched complete preserved workflows plus absolute new capability recipes; shared host, no general speedup or whole-resource bound claim.'},indent=2)+'\n')
(OUT/'adverse-cost-samples.json').write_text(json.dumps([r for r in pairs if r['time_ratio']>1 or r['allocation_call_delta']>0 or r['allocation_byte_delta']>0],indent=2)+'\n')
representation=[]
for i in range(3):
    inline=next(x for x in measurements if x['label']==f'inline-branches-{i}')
    shared=next(x for x in measurements if x['label']==f'polynomial-branches-{i}')
    b={(r['case'],r['phase']):r for r in inline['samples']};a={(r['case'],r['phase']):r for r in shared['samples']}
    assert a.keys()==b.keys()
    for key in b:
        first,last=b[key],a[key];assert first['iterations']==last['iterations'] and first['outcome']==last['outcome']
        representation.append(dict(process_pair=i,case=key[0],phase=key[1],inline=first,shared=last,time_ratio=last['elapsed_ns']/first['elapsed_ns'],allocation_call_delta=last['allocation_calls']-first['allocation_calls'],allocation_byte_delta=last['requested_bytes']-first['requested_bytes']))
(OUT/'representation-costs.json').write_text(json.dumps(representation,indent=2)+'\n')
files={}
for flavor in ['baseline','candidate']:
    files[flavor]={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((OUT/'artifacts'/flavor).glob('*.json'))}
assert files['baseline'] and files['baseline']==files['candidate']
(OUT/'artifact-comparison.json').write_text(json.dumps({'equal':True,'count':len(files['baseline']),'files':files},indent=2)+'\n')
wasm={}
for label,expected in [('v2-wasm-runtime',6),('archive-wasm-runtime',1)]:
    rows=[json.loads(line) for line in Path(by_label[label]['log']).read_text().splitlines() if line.startswith('{')]
    value=rows[-1];assert value['groups']==expected and value['imports']==0
    wasm[label]=value
(OUT/'wasm-artifacts.json').write_text(json.dumps(wasm,indent=2)+'\n')
binaries={}
for name in ['hyperbrep-polynomial-branch-consumer','hyperbrep-branch-preserved-baseline','hyperbrep-branch-preserved-candidate','hyperbrep-polynomial-archive-consumer']:
    p=Path('/tmp/hyperbrep-review-target/release')/name;binaries[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(OUT/'native-artifacts.json').write_text(json.dumps(binaries,indent=2)+'\n')
print('Affected checks and consumers pass except two reproduced baseline curve failures; original full BRep section blocker retained.')
print('Archive records:',len(files['baseline']),'matched phase rows:',len(phase),'measurement processes:',len(measurements))
print('Time ratios:',[r['median_paired_time_ratio'] for r in phase])
