"""Publish a bounded evidence record only after its checks and comparisons finish."""
from pathlib import Path
import copy, datetime, gzip, hashlib, json, re, shutil, subprocess, tarfile
import run
OUT=Path(__file__).resolve().parent
ROOT=run.ROOT
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-polynomial-branches'
assert not DEST.exists()
subprocess.run(['python3','-B',str(OUT/'analyze.py')],check=True)
results=json.loads((OUT/'results.json').read_text())
summary=json.loads((OUT/'test-summary.json').read_text())
costs=json.loads((OUT/'consumer-costs.json').read_text())
representation=json.loads((OUT/'representation-costs.json').read_text())
first=[r for r in representation if r['phase']=='first_fresh_input']
extra_calls=[r['allocation_call_delta'] for r in first]
saved_bytes=[-r['allocation_byte_delta'] for r in first]
artifacts=json.loads((OUT/'artifact-comparison.json').read_text())
ratios=[r['median_paired_time_ratio'] for r in costs['phase_summary']]
allocation_increases=sum(r['allocation_byte_delta']>0 or r['allocation_call_delta']>0 for r in costs['paired_samples'])
rss=max(r['resources']['maximum_rss_kib'] for r in costs['measurements'])
curve=summary['v2-curve-release-tests'];brep=summary['brep-release-tests-final']
qualification=(f"Six shared Hypercurve groups and one public BRep point-archive group pass natively and in actual zero-import WebAssembly. The public model recipe retains a polynomial-fiber chord endpoint through cold replay and reversal, verifies deterministic archive bytes, rejects forged singleton claims, and checks record/degree/element refusal and recovery before scalar decoding. The internal selected-point archive regression also passes. Final BRep/IO all-feature release suites pass {brep['passed']} tests. The final Hypercurve all-feature no-fail-fast run records {curve['passed']} passed, {curve['failed']} failed and {curve['ignored']} ignored tests across {curve['batches']} batches. Both failures reproduce on unchanged ea05bc2aa: oblique fillet certainty and the exterior parameter's recursive-projective view. Their original assertions remain unchanged. Affected native all-feature/all-target Clippy and rustdoc deny warnings; BRep fuzz-target compilation and formatting pass. Three complete preserved BRep workflows pass on fresh baseline/candidate binaries, with {artifacts['count']} byte-identical archive records. These checks do not establish the original public interior-loop surface section: that complete probe still returns UnsupportedIntersection with its success assertion intact.")
cost_evidence=(f"Fifteen CPU-pinned processes retain three alternating baseline/candidate pairs for three complete preserved modeling workflows, three absolute processes for six new curve recipes, three for the complete public point-archive recipe, and three for the rejected inline curve representation using unchanged recipes. Its paired tradeoff samples are retained separately. First and three repeated fresh-input calls retain all assertions and validation. The six matched median phase ratios range {min(ratios):.6f} to {max(ratios):.6f}; {allocation_increases} of {len(costs['paired_samples'])} paired rows increase counted Rust allocation traffic. Maximum process RSS is {rss} KiB. All adverse samples remain. An inline point payload was rejected after increasing CurvePoint2 from 16 to 56 bytes and its definition from 360 to 400 bytes; shared indirection restores the baseline 16/360-byte layouts, with the Curve2 handle still 8 bytes on this target. On the unchanged six curve recipes, shared storage adds {min(extra_calls)}–{max(extra_calls)} counted allocations per first call while reducing requested bytes by {min(saved_bytes)}–{max(saved_bytes)}; all tradeoff samples remain. Requested allocation traffic excludes foreign allocator internals and is not live heap. Shared-host timings and finite layouts establish neither a general speedup nor a total resource bound. New successful operations have no prior successful-work timing baseline.")
limits=("This is a native planar branch and point foundation, not a completed general BRep section. The source equation must satisfy the solver's finite-fiber rational-domain restrictions; vertical/nullified components, generic repeated factors and whole boundary components remain typed blockers. Interior queries need a native BezierParameter2 view; mixed affine scalar images over an algebraic base and general selected scalar persistence remain restricted. General derivatives, rational planar/spatial maps, dual surface charts, filled arrangements, trim/material topology, whole-branch replay and general surface intersections remain open. Conservative branch boxes use the complete source rectangle. Existing refinement/work counters and archive input limits do not bound total arithmetic, coefficient growth, live heap, stack or cancellation latency. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, production bindings and the full pre-push matrix remain unqualified. All 28 work packages remain open/in-progress. The consumed eaa0cae54 push exception does not authorize publishing this increment.")
report=dict(date='2026-10-19',base_revision=run.git('rev-parse','HEAD'),increment='polynomial-branches-2026-10-19',qualification=qualification,cost_evidence=cost_evidence,limits=limits,source='candidate-source.json',baseline_source='baseline-source.json',checks='results.json',tests='test-summary.json',known_failures='inherited-failures.json',costs='consumer-costs.json',artifacts='artifact-comparison.json',upstream_check='upstream-check.json')
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
# Refresh the complete code/documentation patch before adding evidence and ledgers.
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines():
    if name.endswith(('.rs','.toml','.json','.md','.py')):
        added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=ROOT,capture_output=True)
        assert added.returncode in (0,1);patch+=added.stdout
(OUT/'qualified-source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
(OUT/'source-patch.json').write_text(json.dumps(dict(base=report['base_revision'],uncompressed_bytes=len(patch),sha256=hashlib.sha256(patch).hexdigest(),scope='Final implementation, acceptance inputs and API/archive documentation before evidence and ledger edits.'),indent=2)+'\n')
DEST.mkdir()
for name in ['report.json','candidate-source.json','baseline-source.json','source-patch.json','qualified-source.patch.gz','results.json','test-summary.json','inherited-failures.json','consumer-costs.json','representation-costs.json','representation-comparison-contract.json','adverse-cost-samples.json','native-artifacts.json','wasm-artifacts.json','artifact-comparison.json','environment.json','upstream-check.json','contract-before-edit.json','archive-admission-finding.json','construction-argument.md','attempt-review.md','next-domains.md']:
    shutil.copy2(OUT/name,DEST/name)
readme=f'''# Native polynomial branches and selected point replay

This increment extends WP05a/WP05b prerequisites in Hypercurve and the existing
BRep point archive. Hypersolve retains equation, projection and incidence proof
ownership. Hypercurve owns native graph branches and correlated selected points;
BRep owns public model admission and replay. The complete original surface
section recipe remains a failing frontier test.

## Implemented contract

`PolynomialCurveSet2::from_topology` consumes the solver's immutable complete
zero-set graph, producing native `Curve2` branches and separate isolated points.
`Curve2::polynomial_branch` exposes the source graph, slab/root identity and
composed similarity. Rational/algebraic fiber evaluation, repeated subdivision,
reversal, conservative bounds, similarity images, coordinate and affine-sign
queries retain the selected source chart. `CurvePointDefinition2::PolynomialFiber`
replays both selected coordinates together through the existing fiber authority.
No independent approximate coordinate replaces either selection.

The additive archive point tag is exercised through `RawModel::from_json` and
validation using retained-chord endpoints. Both stored equation axes, all
coefficients and row headers are charged before scalar decoding. Point replay
checks singleton evidence; archives contain no trusted root-count or certainty
flag. This does not encode a whole implicit branch.

## Qualification

{qualification}

## Cost and rejected attempt

{cost_evidence}

## Boundaries

{limits}

## Evidence and reproduction

[manifest.json](manifest.json) identifies the bounded record. The
[construction argument](construction-argument.md), [attempt review](attempt-review.md),
[inherited failure comparison](inherited-failures.json) and
[next domains](next-domains.md) distinguish the implemented contract from open work.
[Raw evidence](raw-evidence.tar.gz) contains commands, logs, per-command source
patches, locked standalone consumer projects, exact paired archives, scripts and
all cost samples. The source hashes and final patch identify the measured source
on `{report['base_revision']}`. The rejected inline binary is represented by its
hash, size and observed layout; compiled binaries are not committed.

The original environment used Rust 1.99.0, offline locked dependencies and source
paths recorded in the projects. Extract the raw record and adjust its explicit
workspace/tool-cache paths when reproducing elsewhere. `run.py` records each
command without converting nonzero exits into successes; `analyze.py` requires
the exact reproduced failure set, source hashes, matching layouts and unchanged
archive bytes. Source-path native and Wasmtime consumers are not installed-package
or production-binding qualification. No additional push occurred.
'''
(DEST/'README.md').write_text(readme)
status_path=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status=json.loads(status_path.read_text());assert len(status['increments'])==69
status['updated_on']='2026-10-19'
status['increments'].append(dict(id=report['increment'],work_packages=['WP05a','WP05b','WP06','WP13','WP21'],properties=json.loads((OUT/'contract-before-edit.json').read_text())['properties'],change='Retain complete solver-certified polynomial zero sets as native Hypercurve branches and correlated selected points; admit and replay their endpoint definitions through the public BRep archive.',sources=['../../hypercurve/src/polynomial_curve.rs','../../hypercurve/src/polynomial_point.rs','../src/persistence/planar_points.rs','../src/persistence/admission/shapes.rs'],evidence='evidence/2026-10-19-polynomial-branches/manifest.json',validation=qualification,cost_evidence=cost_evidence,limits=limits))
status['next_actions'].insert(0,'Continue WP05a/WP05b from evidence/2026-10-19-polynomial-branches/manifest.json and next-domains.md. Preserve the original complete BRep interior-loop probe, native branch/point and public archive recipes, exact shared source charts, resource refusal/recovery, baseline curve failures and every adverse cost. Extend selected rational functions, regular derivative and image evidence, spatial/dual-chart correspondence, whole-branch replay, component processing and trim arrangements in their owning layers before claiming section completion. This prerequisite closes no work package or publication gate.')
status_path.write_text(json.dumps(status,indent=2)+'\n')
plan_path=ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md';plan=plan_path.read_text()
plan=plan.replace('Status: implementation blueprint. Updated 2026-10-18 for upstream\n`dbe99e3cc` and concurrent development ownership.', 'Status: implementation blueprint. Updated 2026-10-19 for native polynomial\nbranches, upstream `dbe99e3cc` and concurrent development ownership.')
old='''factors and whole boundary components still fail typed. This finite graph
is not yet a Hypercurve branch carrier or a BRep section: the original public
biquadratic interior-loop probe remains unsupported. Follow its
[next domains](evidence/2026-10-19-bivariate-cell-prototype/next-domains.md) for
retained planar branches, spatial/dual-chart maps, surface guards, trimming,
component processing, persistence and full resource qualification. WP05a is
in progress; its complete gate and G3/G4 remain open.'''
new='''factors and whole boundary components still fail typed. This finite graph now
feeds the native branch carrier described below. The original public
biquadratic interior-loop section remains unsupported. WP05a is in progress;
its complete gate and G3/G4 remain open.'''
assert plan.count(old)==1;plan=plan.replace(old,new)
marker='Apply [research gates G2–G5]'
assert plan.count(marker)==1
paragraph='''The [native polynomial-branch increment](evidence/2026-10-19-polynomial-branches/README.md)
now consumes that graph as `PolynomialCurveSet2`, native `Curve2` branches and
isolated `CurvePoint2` values. Selected fiber evaluation, subdivision, reversal,
similarity, conservative bounds and point-definition replay retain the original
chart and shared equation. BRep's public archive admits these point definitions
as retained-chord endpoints with degree/element accounting and checked singleton
replay. The public surface section remains unsupported. Follow the new
[next domains](evidence/2026-10-19-polynomial-branches/next-domains.md) for selected
rational functions, regular derivatives/maps, spatial/dual-chart images,
whole-branch replay, components and arrangements. General filled topology and
all complete work-package/release gates remain open.

'''
plan=plan.replace(marker,paragraph+marker)
plan_path.write_text(plan)
matrix_path=ROOT/'crates/hyperbrep/docs/SUPPORT_MATRIX.md';matrix=matrix_path.read_text();marker='## Spatial curve carriers\n'
assert matrix.count(marker)==1
paragraph='''## Planar polynomial branch prerequisite

Hypercurve consumes complete admitted rational bivariate zero-set graphs as
native branches and separate isolated points. Branches retain selected source
endpoints and ordered fiber identity through evaluation, subdivision, reversal
and similarity; bounds conservatively enclose the full source rectangle.
Correlated point definitions replay through the existing selected-fiber owner.
The BRep archive accepts these definitions in retained-chord endpoints, charges
both equation degrees and coefficient/row entries, and rejects forged singletons.
See the [finite evidence](evidence/2026-10-19-polynomial-branches/README.md).
This does not supply general derivatives, filled arrangements, tensor-surface
images, both section charts or whole implicit-branch archives. The original
public biquadratic interior-loop section still reports `UnsupportedIntersection`.

'''
matrix_path.write_text(matrix.replace(marker,paragraph+marker))
ledger_path=ROOT/'docs/properties-status.json';ledger_text=ledger_path.read_text();ledger=json.loads(ledger_text);before=copy.deepcopy(ledger)
entry=ledger['current_work']['hyperbrep'];entry.update(latest_evidence='crates/hyperbrep/docs/evidence/2026-10-19-polynomial-branches/manifest.json',latest_feature_evidence='crates/hyperbrep/docs/evidence/2026-10-19-polynomial-branches/manifest.json',latest_implementation=report['increment'],qualification=qualification,performance_evidence=cost_evidence,limits=limits,latest_update_check='crates/hyperbrep/docs/evidence/2026-10-19-polynomial-branches/upstream-check.json')
comparison=copy.deepcopy(ledger);comparison['current_work']['hyperbrep']=before['current_work']['hyperbrep'];assert comparison==before
# Preserve shared-ledger bytes outside this owner's object for future merges.
decoder=json.JSONDecoder()
def whitespace(text,pos):
    while text[pos].isspace():pos+=1
    return pos
def member(text,start,key):
    pos=whitespace(text,start);assert text[pos]=='{';pos=whitespace(text,pos+1)
    while text[pos]!='}':
        name,pos=decoder.raw_decode(text,pos);pos=whitespace(text,pos);assert text[pos]==':'
        begin=whitespace(text,pos+1);_,end=decoder.raw_decode(text,begin)
        if name==key:return begin,end
        pos=whitespace(text,end)
        if text[pos]==',':pos=whitespace(text,pos+1)
    raise KeyError(key)
start,_=member(ledger_text,0,'current_work');start,end=member(ledger_text,start,'hyperbrep')
line=ledger_text[ledger_text.rfind('\n',0,start)+1:start];base=len(line)-len(line.lstrip())
second=ledger_text[start:end].splitlines()[1];width=len(second)-len(second.lstrip())-base
block=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*base)
ledger_output=ledger_text[:start]+block+ledger_text[end:];assert json.loads(ledger_output)==ledger
ledger_path.write_text(ledger_output)
# No further run.py snapshots after evidence exists. Record final local checks directly.
final=[]
for name,command in [('format',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]:
    log=OUT/('commit-review-'+name+'.log')
    with log.open('w') as stream:
        result=subprocess.run(command,cwd=ROOT,env=run.ENV,stdout=stream,stderr=subprocess.STDOUT)
    final.append(dict(command=command,exit_code=result.returncode,log=log.name))
    assert result.returncode==0,(name,log)
(OUT/'commit-review.json').write_text(json.dumps(final,indent=2)+'\n');shutil.copy2(OUT/'commit-review.json',DEST/'commit-review.json')
# Verify every final implementation/acceptance source remained frozen.
source=json.loads((OUT/'candidate-source.json').read_text())
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in source['files'].items())
archive=DEST/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(OUT.rglob('*')):
        if not path.is_file() or path.name in ['native-consumer','results.lock'] or '__pycache__' in path.parts: continue
        tar.add(path,arcname=str(Path('raw')/path.relative_to(OUT)),recursive=False)
files={str(p.relative_to(DEST)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(DEST.rglob('*')) if p.is_file()}
manifest=dict(**report,complete=False,work_packages_closed=0,files=files)
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Evidence prepared:',DEST,'files',len(files)+1,'raw bytes',archive.stat().st_size)
print('Final qualification:',qualification)
print('Final cost:',cost_evidence)
