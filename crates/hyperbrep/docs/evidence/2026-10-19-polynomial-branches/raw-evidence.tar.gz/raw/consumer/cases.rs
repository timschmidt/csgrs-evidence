#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hypercurve/tests/support/polynomial_curves.rs"]
mod acceptance;
fn cases() -> [(&'static str, fn()); 6] { [
("closed_loop_evaluation_split_reverse_and_source_identity", acceptance::closed_loop_evaluation_split_reverse_and_source_identity),
("algebraic_slice_keeps_correlated_noncircular_fiber", acceptance::algebraic_slice_keeps_correlated_noncircular_fiber),
("similarity_and_point_replay_keep_source_chart", acceptance::similarity_and_point_replay_keep_source_chart),
("isolated_empty_and_singular_contacts_remain_distinct", acceptance::isolated_empty_and_singular_contacts_remain_distinct),
("forged_selector_rejection_and_budget_recovery", acceptance::forged_selector_rejection_and_budget_recovery),
("algebraic_events_and_tiny_loops_preserve_selected_endpoints", acceptance::algebraic_events_and_tiny_loops_preserve_selected_endpoints),
] }
