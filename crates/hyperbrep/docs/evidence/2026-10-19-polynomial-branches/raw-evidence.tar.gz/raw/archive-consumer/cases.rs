#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/polynomial_points.rs"]
mod archive;
fn cases() -> [(&'static str, fn()); 1] { [(
    "polynomial_point_archive_admission_and_replay",
    archive::polynomial_point_archive_admission_and_replay,
)] }
