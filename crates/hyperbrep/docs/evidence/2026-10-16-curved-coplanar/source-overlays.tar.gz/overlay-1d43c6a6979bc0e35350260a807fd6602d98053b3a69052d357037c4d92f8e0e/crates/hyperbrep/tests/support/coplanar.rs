//! Repeated curved-cap Booleans with independent exact expectations.
use hyperbrep::{BodySet, Matrix4, Model, Real, SolidPointLocation, boolean};

#[allow(dead_code)]
#[path = "seam_cuts.rs"]
mod seam;

fn measures(model: &Model, volume: &Real, area: &Real) {
    assert_eq!(model.solids().count(), 1);
    seam::equal(&model.solids().next().unwrap().volume().unwrap(), volume);
    seam::equal(
        &model
            .faces()
            .map(|face| face.area().unwrap())
            .fold(Real::zero(), |a, b| a + b),
        area,
    );
    for edge in model.edges() {
        let uses: Vec<_> = edge.uses().collect();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
}

fn samples(kind: usize, restored: bool) -> Vec<(hyperbrep::Point3, SolidPointLocation)> {
    use SolidPointLocation::{Boundary, Inside, Outside};
    let p = seam::point;
    let delta = seam::ratio(1, 1_000_000) * seam::ratio(1, 1_000_000);
    let other = if restored { Inside } else { Outside };
    let seam_location = if restored { Inside } else { Boundary };
    match kind {
        0 => vec![
            (p(5, 0, 1), Inside),
            (p(5, 0, -1), other),
            (p(5, 0, 0), seam_location),
            (p(0, 0, 0), Outside),
            (p(5, 0, 2), Boundary),
            (
                hyperbrep::Point3::new(5.into(), 0.into(), delta.clone()),
                Inside,
            ),
            (hyperbrep::Point3::new(5.into(), 0.into(), -&delta), other),
            (
                hyperbrep::Point3::new(5.into(), 0.into(), Real::from(2) - &delta),
                Inside,
            ),
            (
                hyperbrep::Point3::new(5.into(), 0.into(), Real::from(2) + &delta),
                Outside,
            ),
        ],
        1 => vec![
            (p(5, 0, 0), Inside),
            (p(-5, 0, 0), other),
            (p(0, 5, 0), seam_location),
            (p(0, 0, 0), Outside),
            (p(7, 0, 0), Boundary),
            (
                hyperbrep::Point3::new(delta.clone(), 5.into(), 0.into()),
                Inside,
            ),
            (hyperbrep::Point3::new(-&delta, 5.into(), 0.into()), other),
            (
                hyperbrep::Point3::new(Real::from(7) - &delta, 0.into(), 0.into()),
                Inside,
            ),
            (
                hyperbrep::Point3::new(Real::from(7) + &delta, 0.into(), 0.into()),
                Outside,
            ),
        ],
        2 => vec![
            (p(1, 0, 3), Inside),
            (p(-1, 0, 3), other),
            (p(0, 0, 3), seam_location),
            (p(0, 0, 7), Outside),
            (
                hyperbrep::Point3::new(seam::ratio(7, 2), 0.into(), 3.into()),
                Boundary,
            ),
            (
                hyperbrep::Point3::new(delta.clone(), 0.into(), 3.into()),
                Inside,
            ),
            (hyperbrep::Point3::new(-&delta, 0.into(), 3.into()), other),
            (
                hyperbrep::Point3::new(seam::ratio(7, 2) - &delta, 0.into(), 3.into()),
                Inside,
            ),
            (
                hyperbrep::Point3::new(seam::ratio(7, 2) + &delta, 0.into(), 3.into()),
                Outside,
            ),
        ],
        _ => unreachable!(),
    }
}

fn check_output(result: &BodySet, kind: usize, restored: bool, map: &Matrix4, scale: &Real) {
    let (_, _, half_volume, half_area) = seam::fixture(kind);
    let volume = if restored {
        Real::from(2) * half_volume
    } else {
        half_volume
    };
    let area = if restored {
        if kind == 2 {
            (Real::from(29) + Real::from(21) * Real::from(5).sqrt().unwrap()) * Real::pi()
        } else {
            Real::from(40) * Real::pi() * Real::pi()
        }
    } else {
        half_area
    };
    let volume = volume * scale * scale * scale;
    let area = area * scale * scale;
    assert_eq!(result.len(), 1);
    let replay = seam::reload(result.model());
    for model in [result.model(), &replay] {
        measures(model, &volume, &area);
        for (point, expected) in samples(kind, restored) {
            assert_eq!(
                model
                    .solids()
                    .next()
                    .unwrap()
                    .classify_point(&map.transform_point3(&point).unwrap())
                    .unwrap(),
                expected
            );
        }
    }
    let edge = replay.edges().next().unwrap();
    let parameter = ((edge.domain().start().try_real().unwrap()
        + edge.domain().end().try_real().unwrap())
        / Real::from(2))
    .unwrap();
    let split = edge.split(parameter.into()).unwrap();
    let replay = seam::reload(split.model());
    measures(&replay, &volume, &area);
    let moved = replay
        .transformed(&seam::similarity(&seam::ratio(1, 1000), true))
        .unwrap();
    measures(
        &seam::reload(&moved),
        &(volume * seam::ratio(1, 1_000_000_000)),
        &(area * seam::ratio(1, 1_000_000)),
    );
}

/// Operation 0 recuts in both orders; 1 subtracts to empty and recovers; 2
/// reconstructs the complete source from complementary halves in both orders.
pub fn workflow(kind: usize, operation: usize, map: &Matrix4, scale: &Real) {
    let (source, cutter, _, _) = seam::fixture(kind);
    let source = source.transformed(map).unwrap();
    let cutter = cutter.transformed(map).unwrap();
    let half = boolean::intersection(&source, &cutter).unwrap();
    let other = boolean::difference(&source, &cutter).unwrap();
    match operation {
        0 => {
            for (index, result) in [
                boolean::intersection(&half, &cutter),
                boolean::intersection(&cutter, &half),
            ]
            .into_iter()
            .enumerate()
            {
                let result = result
                    .unwrap_or_else(|error| panic!("kind={kind} recut order={index}: {error:?}"));
                check_output(&result, kind, false, map, scale);
            }
        }
        1 => {
            let empty = boolean::difference(&half, &cutter)
                .unwrap_or_else(|error| panic!("kind={kind} clear: {error:?}"));
            assert!(empty.is_empty());
            assert_eq!(
                empty.model().to_json().unwrap(),
                BodySet::empty().model().to_json().unwrap()
            );
            let recovered = boolean::union(&empty, &half).unwrap();
            check_output(&recovered, kind, false, map, scale);
        }
        2 => {
            for (index, result) in [boolean::union(&half, &other), boolean::union(&other, &half)]
                .into_iter()
                .enumerate()
            {
                let result = result
                    .unwrap_or_else(|error| panic!("kind={kind} restore order={index}: {error:?}"));
                check_output(&result, kind, true, map, scale);
            }
        }
        _ => unreachable!(),
    }
}

pub fn original(kind: usize, operation: usize) {
    workflow(kind, operation, &Matrix4::identity(), &Real::one());
}
