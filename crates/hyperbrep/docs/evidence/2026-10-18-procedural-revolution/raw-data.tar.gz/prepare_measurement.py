"""Instrument first and repeated complete invocations without changing fixtures."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
old='''    operation();
    CALLS.store(0, Ordering::Relaxed);'''
first='''    CALLS.store(0, Ordering::Relaxed);
    BYTES.store(0, Ordering::Relaxed);
    COUNTING.store(true, Ordering::Relaxed);
    let started = Instant::now();
    black_box(operation)();
    let first_elapsed = started.elapsed().as_nanos();
    COUNTING.store(false, Ordering::Relaxed);
    println!(
        "{{\\\"case\\\":\\\"{name}\\\",\\\"phase\\\":\\\"first_fresh_input\\\",\\\"outcome\\\":\\\"{outcome}\\\",\\\"iterations\\\":1,\\\"elapsed_ns\\\":{first_elapsed},\\\"allocation_calls\\\":{},\\\"requested_bytes\\\":{}}}",
        CALLS.load(Ordering::Relaxed), BYTES.load(Ordering::Relaxed)
    );
    CALLS.store(0, Ordering::Relaxed);'''
for p in (OUT/'consumers').glob('*/*/main.rs'):
 s=p.read_text();assert old in s,p
 s=s.replace(old,first)
 s=s.replace('\\"iterations\\":{iterations}', '\\"phase\\":\\"repeated_fresh_input\\",\\"iterations\\":{iterations}')
 p.write_text(s)
p=OUT/'consumer-projects.json';x=json.loads(p.read_text());x['prepared_inputs']={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'consumers').rglob('*') if p.is_file()};p.write_text(json.dumps(x,indent=2)+'\n')
