"""Repeat source-qualified complete export recipes and compare native bytes."""
from pathlib import Path
import hashlib,json
from run import OUT,ROOT,run
from source_identity import source_identity
records={s:{r['cohort']:r for r in json.loads((OUT/f'{s}-consumers.json').read_text())} for s in ['baseline','candidate']}
roots={'baseline':Path('/mnt/development/csgrs'),'candidate':ROOT}
identities={s:json.loads((OUT/f'{s}-consumer-source.json').read_text()) for s in roots}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];pairs=[]
for name,key in [('revolution','HYPERBREP_SELECTED_REVOLUTION_ARTIFACT_DIR'),('procedural','HYPERBREP_SELECTED_PROCEDURAL_ARTIFACT_DIR'),('solids','HYPERBREP_PROCEDURAL_REVOLUTION_ARTIFACT_DIR')]:
 for side in (['candidate'] if name=='solids' else ['baseline','candidate']):
  binary=records[side][name]['native'];assert sha(Path(binary['path']))==binary['sha256']
  for repeat in range(2):
   destination=OUT/'artifacts'/side/name/str(repeat);destination.mkdir(parents=True,exist_ok=False)
   assert run(dict(label=f'artifact-{side}-{name}-{repeat}',command=[binary['path'],'all'],env={key:str(destination)},seconds=1200))==0
   assert all(source_identity(root)==identities[s] for s,root in roots.items())
   files=sorted(p for p in destination.rglob('*') if p.is_file());assert files
   for p in files:
    relative=p.relative_to(destination)
    if repeat: assert p.read_bytes()==(destination.parent/'0'/relative).read_bytes(),(name,relative)
    rows.append(dict(cohort=name,side=side,repeat=repeat,name=str(relative),path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
   (OUT/'artifact-generation.json').write_text(json.dumps(rows,indent=2)+'\n')
 for after in [r for r in rows if r['cohort']==name and r['side']=='candidate' and r['repeat']==0]:
  before=next(r for r in rows if r['cohort']==name and r['side']==('candidate' if name=='solids' else 'baseline') and r['repeat']==(1 if name=='solids' else 0) and r['name']==after['name'])
  pairs.append(dict(name=name+'/'+after['name'],baseline=before['path'],candidate=after['path']))
(OUT/'generated-artifact-pairs.json').write_text(json.dumps(pairs,indent=2)+'\n')
print('Native artifact comparison pairs:',len(pairs),flush=True)
