"""Append one finite increment without closing any broader work package."""
import json
from run import OUT,ROOT
from update_ledger import update_block
name='2026-10-18-procedural-revolution'; ident='procedural-revolution-2026-10-18'
dest=ROOT/'crates/hyperbrep/docs/evidence'/name
summary=json.loads((OUT/'qualification-summary.json').read_text())
contract=json.loads((OUT/'contract-before-edit.json').read_text())
p=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
data=json.loads(p.read_text()); assert not data['complete']
assert all(r['id']!=ident for r in data['increments'])
assert len(data['work_packages'])==28 and all(r['status'] in ['open','in-progress'] for r in data['work_packages'])
data['increments'].append(dict(id=ident,work_packages=['WP02','WP07','WP09','WP13','WP21'],properties=contract['properties'],change='Construct and independently admit complete solid revolutions of retained procedural and Boolean-selected profiles. Add filled-region revolution with holes, disconnected components and empty results while preserving native carriers.',sources=['../src/construction/revolution.rs','../src/topology/validation/retained_revolution.rs','../src/topology/validation/shell.rs','../src/ownership/builder.rs'],evidence=f'evidence/{name}/manifest.json',validation=summary['qualification'],cost_evidence=summary['costs'],limits=summary['limits']))
data['updated_on']='2026-10-19'
data['next_actions'].insert(0,f'Preserve evidence/{name}/manifest.json and all earlier original profiles, archives and adverse costs. Continue its next-domains.md: selected angular/axial fields, partial and singular revolutions, general surface arrangements/Booleans, metrics, STEP, resource bounds and shipped consumers. Complete positive-radius procedural revolutions do not close any work package or waive full pre-push qualification.')
p.write_text(json.dumps(data,indent=2)+'\n')
p=ROOT/'docs/properties-status.json'
ledger=json.loads(p.read_text())['current_work']['hyperbrep']
ledger.update(latest_evidence=f'crates/hyperbrep/docs/evidence/{name}/manifest.json',latest_feature_evidence=f'crates/hyperbrep/docs/evidence/{name}/manifest.json',latest_implementation=ident,qualification=' '.join(summary[k] for k in ['qualification','costs','limits']))
record=update_block(p,ledger)
(dest/'ledger-update.json').write_text(json.dumps(record,indent=2)+'\n')
print('Appended increment',len(data['increments']),'with all 28 work packages still open/in progress.')
