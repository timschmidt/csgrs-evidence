"""Record final documentation/format checks without changing qualified source."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time
from run import OUT,ROOT,ENV

DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-18-procedural-revolution'
parser=argparse.ArgumentParser();parser.add_argument('phase',choices=['documents','staged']);args=parser.parse_args()
logdir=DEST/'final-checks';logdir.mkdir(exist_ok=True)
record=DEST/'final-checks.json'
rows=json.loads(record.read_text()) if record.exists() else []
jobs=[('format',['cargo','fmt','--all','--','--check']),
 ('documentation',['python3','-B',str(OUT/'check_documentation.py')]),
 ('diff',['git','diff','--check'])] if args.phase=='documents' else [('staged-diff',['git','diff','--cached','--check'])]
for name,command in jobs:
    path=logdir/(name+'.log');assert not path.exists()
    start=time.monotonic()
    with path.open('w') as log:result=subprocess.run(command,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    row=dict(label=name,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
        log=str(path.relative_to(DEST)),log_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    rows.append(row);record.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert result.returncode==0,path.read_text()
