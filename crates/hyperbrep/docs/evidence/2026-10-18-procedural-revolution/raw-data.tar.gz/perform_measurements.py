"""Measure only after all known build/runtime/archive jobs in this increment end."""
import datetime,json,os,subprocess,sys
from run import OUT,ROOT,ENV
from source_identity import source_identity
rows={r['label']:r for r in json.loads((OUT/'results.json').read_text())}
assert rows['archive-generated-comparison']['exit_code']==0
assert (OUT/'prior-replay-summary.json').exists()
assert len(json.loads((OUT/'candidate-consumers.json').read_text()))==4
assert not (OUT/'costs').exists()
start=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd='/mnt/development/csgrs',text=True).strip(),candidate_base_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),allowed_cpus=sorted(os.sched_getaffinity(0)),load_average=list(os.getloadavg()),scope='All known qualification/build/archive jobs initiated by this workflow have completed before this script. No overlapping compilation, archive generation or evidence compression is initiated during measurement. The shared host is not globally isolated; the execution process namespace does not expose other tool sessions. No global quiescence, CPU-frequency or disabled-cache guarantee is claimed.')
(OUT/'measurement-start.json').write_text(json.dumps(start,indent=2)+'\n')
result=subprocess.run([sys.executable,'-B',str(OUT/'measure_consumers.py')],cwd=ROOT,env=ENV)
end=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=result.returncode,load_average=list(os.getloadavg()),candidate_source_unchanged=source_identity(ROOT)==json.loads((OUT/'candidate-consumer-source.json').read_text()),baseline_source_unchanged=source_identity('/mnt/development/csgrs')==json.loads((OUT/'baseline-consumer-source.json').read_text()))
(OUT/'measurement-end.json').write_text(json.dumps(end,indent=2)+'\n')
assert end['candidate_source_unchanged'] and end['baseline_source_unchanged']
raise SystemExit(result.returncode)
