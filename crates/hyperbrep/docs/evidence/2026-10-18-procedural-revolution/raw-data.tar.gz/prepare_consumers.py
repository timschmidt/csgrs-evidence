"""Prepare affected public source-path consumers, with explicit source roots."""
from pathlib import Path
import hashlib,json,re,shutil,tomllib
OUT=Path(__file__).resolve().parent
BASE=Path('/mnt/development/csgrs'); CANDIDATE=BASE/'target/hyperbrep-development'
E=BASE/'crates/hyperbrep/docs/evidence'
rows=[]
def remap(p,root):
 p=Path(p).resolve()
 for source in [CANDIDATE,BASE]:
  try:return root/p.relative_to(source)
  except ValueError:pass
 return p

def row(name,p,side,groups):
 manifest=tomllib.loads((p/'Cargo.toml').read_text())
 rows.append(dict(cohort=name,project=str(p),side=side,groups=groups,wasm_only=False,has_wasm=True,
  binary=manifest.get('bin',[{'name':manifest['package']['name']}])[0]['name'],
  module=manifest['lib'].get('name',manifest['package']['name'].replace('-','_'))))

for name,source,count in [
 ('revolution',E/'2026-10-18-selected-revolution/consumer-project',8),
 ('procedural',E/'2026-10-18-selected-procedural-profiles/consumer-project',12)]:
 for side,root in [('baseline',BASE),('candidate',CANDIDATE)]:
  target=OUT/'consumers'/side/name; assert not target.exists()
  for p in source.rglob('*'):
   if not p.is_file() or p.suffix not in ['.rs','.toml','.lock']:continue
   dest=target/p.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True);s=p.read_text()
   if p.name=='Cargo.toml':
    s=re.sub(r'path\s*=\s*"([^"]+)"',lambda m:'path = "'+str(remap(p.parent/m[1],root))+'"' if (p.parent/m[1]).is_dir() else m[0],s)
   if p.suffix=='.rs':
    s=re.sub(r'#\[path\s*=\s*"([^"]+)"\]',lambda m:'#[path = "'+str(remap(p.parent/m[1],root))+'"]',s)
   dest.write_text(s)
  if name=='procedural':
   main=target/'main.rs';main.write_text(main.read_text().replace('for (name, operation) in cases() {','for (name, operation) in cases() {\n        if mode == \"measure\" && name != \"full_clipped_parallel_cap_constructs_and_replays\" { continue; }'))
  row(name,target,side,count)

template=(Path('/tmp/hyperbrep-selected-revolution-20261018/consumers/candidate/revolution/main.rs')).read_text()

def project(name,side,root,cases,deps):
 p=OUT/'consumers'/side/name;p.mkdir(parents=True,exist_ok=False)
 package='hyperbrep-procedural-revolution-'+name
 module=package.replace('-','_')
 (p/'Cargo.toml').write_text(f'[package]\nname = "{package}"\nversion = "0.0.0"\nedition = "2024"\n[workspace]\n[[bin]]\nname = "{package}"\npath = "main.rs"\n[lib]\nname = "{module}"\npath = "lib.rs"\ncrate-type = ["cdylib"]\n[dependencies]\n'+''.join(f'{dep} = {{ path = "{root}/crates/{dep}" }}\n' for dep in deps)+'serde_json = "1"\n')
 count=len(cases[1]);(p/'cases.rs').write_text(cases[0]+f'fn cases() -> [(&\'static str,fn());{count}] {{ [\n'+''.join(f'("{label}",{function}),\n' for label,function in cases[1])+'] }\n')
 (p/'main.rs').write_text(template)
 (p/'lib.rs').write_text(f'include!("cases.rs");\n#[unsafe(no_mangle)]\npub extern "C" fn run_probe() -> u32 {{ for (_, case) in cases() {{ case(); }} {count} }}\n')
 row(name,p,side,count)
 return p

for side,root in [('baseline',BASE),('candidate',CANDIDATE)]:
 names=['primitives','clipped_and_voids','profile_families']
 project('native',side,root,(f'#[allow(dead_code)]\n#[path = "{root}/crates/hyperbrep/tests/support/similarity.rs"]\nmod acceptance;\n',[(n,'acceptance::'+n) for n in names]),['hyperbrep','hypercurve','hyperlimit'])

names=re.findall(r'^pub fn (\w+)\(', (CANDIDATE/'crates/hyperbrep/tests/support/procedural_revolution.rs').read_text(),re.M)
step='procedural_revolution_step_rejection_preserves_native_solid'
p=project('solids','candidate',CANDIDATE,(f'#[path = "{CANDIDATE}/crates/hyperbrep/tests/support/procedural_revolution.rs"]\nmod acceptance;\n#[path = "{CANDIDATE}/crates/hyperbrep-io/tests/support/procedural_revolution.rs"]\nmod step_acceptance;\n',[(n,'acceptance::'+n) for n in names]+[(step,'step_boundary')]),['hyperbrep','hyperbrep-io','hypercurve','hyperlimit'])
cases=p/'cases.rs';cases.write_text(cases.read_text()+'\nfn step_boundary() { step_acceptance::procedural_revolution_step_rejection_preserves_native_solid(&acceptance::selected::clipped_parallel_cap()); }\n')
# Absolute costs need completed constructive workflows, not every hostile-control test.
s=(p/'main.rs').read_text().replace('for (name, operation) in cases() {','for (name, operation) in cases() {\n        if mode == "measure" && !["full_parallel_cap_revolves_and_replays", "selected_parallel_cap_revolves_and_replays"].contains(&name) { continue; }')
(p/'main.rs').write_text(s)
audit=[]
for r in rows:
 root=BASE if r['side']=='baseline' else CANDIDATE
 p=Path(r['project'])
 for file in p.rglob('*'):
  if file.suffix not in ['.rs','.toml']:continue
  for path in re.findall(r'(?:path\s*=\s*|include!\()"(/[^\"]+)"',file.read_text()):
   if '/crates/' not in path:continue
   actual=Path(path);assert actual.exists(),actual
   assert actual.is_relative_to(root/'crates'),(root,actual)
   audit.append(dict(file=str(file),root=str(root),path=path))
(OUT/'consumer-root-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
(OUT/'consumer-projects.json').write_text(json.dumps(dict(projects=rows,prepared_inputs={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'consumers').rglob('*') if p.is_file()}),indent=2)+'\n')
print('Prepared',len(rows),'projects; candidate native and WASM groups',sum(r['groups'] for r in rows if r['side']=='candidate'))
