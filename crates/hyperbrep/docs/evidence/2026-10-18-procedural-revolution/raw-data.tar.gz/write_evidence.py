"""Summarize only completed, source-qualified checks and costs."""
from pathlib import Path
import collections,gzip,hashlib,json,re,shutil,subprocess
from run import OUT,ROOT
from source_identity import source_identity
NAME='2026-10-18-procedural-revolution'
DEST=ROOT/'crates/hyperbrep/docs/evidence'/NAME
assert not DEST.exists()
load=lambda name:json.loads((OUT/name).read_text())
write=lambda name,data:(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert source_identity(ROOT)==load('candidate-consumer-source.json')
assert source_identity('/mnt/development/csgrs')==load('baseline-consumer-source.json')
checks=load('results.json'); by={r['label']:r for r in checks}
required=['strict-clippy-all-02','tests-all-features-02','tests-minimal-features-02','clippy-minimal-features-02','rustdoc-02','fuzz-check-02','format-check-02']
assert all(by[k]['exit_code']==0 for k in required)
assert all(r['exit_code']==0 for r in checks if r['label'].startswith(('consumer-01-','archive-','artifact-')))
counts={}
for name in ['tests-all-features-02','tests-minimal-features-02']:
    text=(OUT/(name+'.log')).read_text()
    values=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    counts[name]=dict(passed=sum(int(x[0]) for x in values),failed=sum(int(x[1]) for x in values),ignored=sum(int(x[2]) for x in values),executables_or_doctest_groups=len(values))
    assert not counts[name]['failed']
consumers={side:load(side+'-consumers.json') for side in ['baseline','candidate']}
consumer_counts={side:sum(r['groups'] for r in rows) for side,rows in consumers.items()}
assert consumer_counts=={'baseline':23,'candidate':33}
assert all('wasm' in r for r in consumers['candidate'])
prior=load('prior-replay-summary.json')
artifacts=load('artifact-generation.json'); compared=load('generated-artifact-comparison.json')
assert all(r['byte_identical'] and not r['changed_scalar_encodings'] for r in compared)
old_pairs=sum(not r['name'].startswith('solids/') for r in load('generated-artifact-pairs.json'))
new_pairs=sum(r['name'].startswith('solids/') for r in load('generated-artifact-pairs.json'))
new_rows=[r for r in artifacts if r['cohort']=='solids' and r['repeat']==0]
assert len(new_rows)==new_pairs
sizes={}
for cohort in sorted({r['cohort'] for r in artifacts}):
    rows=[r for r in artifacts if r['cohort']==cohort and r['side']=='candidate' and r['repeat']==0]
    sizes[cohort]=dict(files=len(rows),unique_contents=len({r['sha256'] for r in rows}),total_bytes=sum(r['bytes'] for r in rows),minimum_bytes=min(r['bytes'] for r in rows),maximum_bytes=max(r['bytes'] for r in rows))
write('artifact-size-summary.json',sizes)
costs=load('consumer-costs.json'); assert len(costs['trials'])==21 and len(costs['rows'])==28
assert all(r['exit_code']==r['resource']['exit_code']==0 for r in costs['trials'])
matched=[r for r in costs['rows'] if r['matched_contract']]
adverse=[r for r in matched if r['ratio']>1.1 or any(r['candidate'][k]>r['baseline'][k] for k in ['allocation_calls','requested_bytes'])]
write('adverse-cost-samples.json',adverse)
size_rows=[]
for row in consumers['candidate']:
    before=next((r for r in consumers['baseline'] if r['cohort']==row['cohort']),None)
    size_rows.append(dict(cohort=row['cohort'],baseline_native_bytes=before['native']['bytes'] if before else None,candidate_native_bytes=row['native']['bytes'],candidate_wasm_bytes=row['wasm']['bytes']))
cost_summary=dict(processes=21,completed=21,preserved_workflows=12,new_workflows=2,phases=['first_fresh_input','repeated_fresh_input'],phase_rows=28,matched_phase_rows=24,absolute_phase_rows=4,minimum_ratio=min(r['ratio'] for r in matched),maximum_ratio=max(r['ratio'] for r in matched),over_10_percent_rows=sum(r['ratio']>1.1 for r in matched),allocation_increase_rows=sum(any(r['candidate'][k]>r['baseline'][k] for k in ['allocation_calls','requested_bytes']) for r in matched),binary_sizes=size_rows,maximum_process_rss_kib=max(r['resource']['maximum_rss_kib'] for r in costs['trials']),scope=costs['scope'])
write('cost-summary.json',cost_summary)
qualification=(f"Nine shared public BRep groups, one internal duplicate/gap rejection and one public IO boundary group extend the corpus. BRep/IO release suites pass {counts['tests-all-features-02']['passed']} all-feature and {counts['tests-minimal-features-02']['passed']} minimal-feature tests. Both affected all-target strict Clippy configurations, warning-denied rustdoc, fuzz-target compilation and formatting pass. Source-path consumers execute 23 preserved groups on the baseline and 33 on the candidate; actual zero-import WASM executes all 33 candidate groups. This is the affected boundary corpus, not a rerun of the entire prior 253-group WASM inventory. All {prior['byte_identical_native_archives']} historical native archives re-encode byte-identically; 159 STEP files import {prior['imported_step_bodies']} bodies and replay. The {prior['files']}-file historical inventory has {prior['unique_input_contents']} distinct contents; text controls are inventory-only. All {old_pairs} fresh baseline/candidate native pairs are byte-identical. {new_pairs} new solid archive files ({len({r['sha256'] for r in new_rows})} distinct contents) repeat deterministically and cold-replay. No scalar encoding or schema migration is introduced.")
cost_text=(f"Three alternating pairs cover 12 preserved completed workflows and three absolute processes cover two new construction/replay workflows, each with a first call and three repeated fresh-input calls. All 21 processes pass their assertions. The 24 matched phase ratios range {cost_summary['minimum_ratio']:.6f} to {cost_summary['maximum_ratio']:.6f}; {cost_summary['over_10_percent_rows']} exceed the 10% review marker and {cost_summary['allocation_increase_rows']} increase allocation calls or requested bytes. All adverse samples, RSS and binary/artifact sizes are retained. Instrumented shared-host samples establish neither a general speedup nor internal work/heap bounds.")
limits=("Only complete-turn shells from simple, strictly positive-radius profiles with replayable scalar charts and a common similarity-projectable meridian plane are added. Exact procedural metrics can remain unavailable. General curved solid Booleans, partial/axis-touching revolutions, independent selected angular/axial fields, arbitrary affine transport, procedural STEP, whole-operation work/heap/coefficient/cancellation bounds, runtime fuzz/ASan/lexicase, formal coverage, MSRV, installed distributions and production binding gates remain open. All 28 work packages remain open/in-progress. Full pre-push qualification remains required; the consumed eaa0 one-time exception does not authorize publishing this increment.")
summary=dict(qualification=qualification,costs=cost_text,limits=limits,tests=counts,consumers=consumer_counts,actual_wasm_groups=33,prior=prior,matched_fresh_pairs=old_pairs,new_deterministic_archive_pairs=new_pairs,cost_summary=cost_summary)
write('qualification-summary.json',summary)
write('outcome-coverage.json',dict(certified_completion='Full and selected procedural solid construction, cavities/components/empty, reversal/reflection, selected edge subdivision, exact classification, native cold replay and existing native volume.',qualified_approximate_completion='No new qualified approximate success claimed; exact fixtures remain Certified when an approximate policy is selected.',undecided='No new undecided completion accepted; generic typed predicate frontiers retained.',unsupported='Procedural STEP returns face-attributed UnsupportedSurface(Revolution); unavailable procedural volume returns UnsupportedMeasurement.',invalid_input='Axis/nonpositive enclosure, invalid cavity nesting/contact, incomplete/duplicate coverage and forged archive records reject.',resource_exhaustion='ZERO instrumented work budget rejects cold admission and subsequent ordinary replay recovers.',incorrect_result='None observed in this finite corpus; no exhaustive proof or measured coverage claim.'))
lines=['# Completed-workflow cost observations','',cost_text,'',costs['scope'],'','| Cohort / workflow | Phase | Baseline ms | Candidate ms | Ratio | Baseline allocation calls | Candidate allocation calls |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
for r in costs['rows']:
    b=r.get('baseline'); c=r['candidate']
    lines.append(f"| {r['cohort']} / {r['case']} | {r['phase']} | {b['elapsed_ns']/1e6 if b else '—'} | {c['elapsed_ns']/1e6:.6f} | {r['ratio'] if b else 'absolute only'} | {b['allocation_calls'] if b else '—'} | {c['allocation_calls']} |")
lines+=['','Cumulative requested allocation bytes include reallocations and are not live heap.','Process maximum RSS covers the complete process, including all its cases.','Binary size reflects each actual consumer feature/link graph; the new consumer has no matched baseline.','No retained optimization is justified by these timings; this is a capability extension.','Stable adverse behavior warrants a separate source-bound investigation, preserving all geometry and assertions.']
(OUT/'costs.md').write_text('\n'.join(lines)+'\n')
DEST.mkdir(parents=True)
copy_names=['contract-before-edit.json','contract.md','attempt-review.md','construction-proof.md','independent-oracles.md','next-domains.md','idea-ledger.json','machine.json','build-environment.json','source-audit.json','consumer-root-audit.json','baseline-consumers.json','candidate-consumers.json','qualification-summary.json','cost-summary.json','consumer-costs.json','adverse-cost-samples.json','costs.md','prior-replay-summary.json','artifact-size-summary.json','outcome-coverage.json','test-authoring-correction.json','interrupted-qualification.json']
for name in copy_names: shutil.copy2(OUT/name,DEST/name)
for side in ['baseline','candidate']: shutil.copy2(OUT/(side+'-consumer-source.json'),DEST/(side+'-source.json'))
for name in ['measurement-start.json','measurement-end.json']:
    if (OUT/name).exists(): shutil.copy2(OUT/name,DEST/name)
with (DEST/'qualified-source.patch.gz').open('wb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z: z.write((OUT/'qualified-source.patch').read_bytes())
shutil.copytree(OUT/'consumers/candidate/solids',DEST/'consumer-project')
shutil.copytree(OUT/'archive-project',DEST/'archive-project')
(DEST/'README.md').write_text(f'''# Retained procedural solid revolutions

`builder::revolve_path` and `builder::revolve_path_region` now construct connected
solids from retained procedural profiles, including Boolean-selected endpoints.
The new `builder::revolve_curve_region` consumes material, holes, disconnected
components and empty regions. Native line/circle carriers keep their existing
construction path and exact measurements.

The original full quadratic parallel cap and its Boolean-clipped cap both failed
with `UnsupportedRevolutionProfile` on base `5d2e9d45aa85126b86b687bca4dd4ea1e2746377`.
They now complete without changing their geometry or materializing selected
coordinates. Source charts, roots, meridians and circular orbits remain exact.
The ordinary builder independently replays the complete one-turn product-shell
proof, including multiplicity-one face coverage and cavity containment.

## Qualification

{qualification}

The independent exact samples, near-coincidence checks and topology arguments
are described in [independent-oracles.md](independent-oracles.md) and
[construction-proof.md](construction-proof.md). This is a mathematical argument
connected to executable checks, not a formal program-verification result.
[contract.md](contract.md) and [outcome-coverage.json](outcome-coverage.json)
separate success, unsupported geometry, invalid input and exhaustion.

{cost_text}

[consumer-costs.json](consumer-costs.json) retains every trial;
[costs.md](costs.md) and [cost-summary.json](cost-summary.json) summarize scope and
unfavorable observations. First calls and repeated reconstructed inputs are
separate; immutable global caches can already be warm from earlier cases.

## Scope and continuation

{limits}

See [next-domains.md](next-domains.md) and the
[support matrix](../../SUPPORT_MATRIX.md). Optional measurement failure does not
invalidate the admitted procedural shell. The existing STEP surface blocker is
explicitly tested and does not alter native geometry.

## Reproduction

Recreate the base revision, decompress and apply
[qualified-source.patch.gz](qualified-source.patch.gz), and verify the hashes in
[candidate-source.json](candidate-source.json). The final additions after this
source freeze are documentation and evidence only. The external consumer and
archive projects retain exact source-root paths and locks; remap the baseline
and candidate roots when replaying on another machine, replacing the longest
source root first. These local paths do not
establish installed-package delivery.

[validation.json](validation.json) records commands, feature sets, exits, source
patches, elapsed times and log hashes, including failed development attempts.
[attempt-review.md](attempt-review.md) explains those attempts.
[raw-data.tar.gz](raw-data.tar.gz) preserves raw logs, scripts, locks, fixtures,
old/new archives and samples; [raw-data-index.json](raw-data-index.json) verifies
every member. Frozen binaries/build caches are excluded; hashes and sizes remain.
The final [manifest.json](manifest.json) identifies all evidence files.
''')
write('documentation-stage.json',dict(destination=str(DEST),qualified_source_unchanged=True,qualification=qualification,costs=cost_text,limits=limits))
print(json.dumps(summary,indent=2),flush=True)
