
pub fn procedural_revolution_consumes_regions_holes_components_and_empty() {
    use hypercurve::{BooleanOp, CurveRegionLoopRole, FillRule};
    let outer = radial_path(&selected::clipped_parallel_cap());
    let hole = rectangle(q(13,4),q(15,4),q(-1,2),q(1,2));
    let region = CurveRegion2::try_from_boundary_paths_with_loop_semantics(
        &[outer, hole], &[CurveRegionLoopRole::Material,CurveRegionLoopRole::Hole],
        &[FillRule::NonZero;2]).unwrap();
    let shift = hypercurve::Similarity2::try_from_real_affine(
        1.into(),0.into(),0.into(),1.into(),0.into(),5.into()).unwrap();
    let upper = region.transform_similarity(&shift).unwrap();
    let both = region.boolean_region(&upper,BooleanOp::Union).unwrap();
    let bodies = builder::revolve_curve_region(&both).unwrap();
    assert_eq!(bodies.len(),2);
    for model in [bodies.model(), &replay(bodies.model())] {
        for z in [Real::zero(),Real::from(5)] {
            let material = Point3::new(q(25,8),0.into(),z.clone());
            let cavity = Point3::new(q(7,2),0.into(),z);
            assert_eq!(model.solids().filter(|s| s.classify_point(&material).unwrap()==SolidPointLocation::Inside).count(),1);
            assert!(model.solids().all(|s| s.classify_point(&cavity).unwrap()==SolidPointLocation::Outside));
        }
    }
    let empty = region.boolean_region(&region,BooleanOp::Difference).unwrap();
    for input in [empty,CurveRegion2::empty()] {
        let empty = builder::revolve_curve_region(&input).unwrap();
        assert!(empty.is_empty());
        assert_eq!(replay(empty.model()).solids().len(),0);
        let recovered = boolean::union(&empty,&bodies).unwrap();
        assert_eq!(recovered.len(),2);
        assert!(boolean::intersection(&empty,&bodies).unwrap().is_empty());
        assert!(boolean::difference(&empty,&bodies).unwrap().is_empty());
    }
}
