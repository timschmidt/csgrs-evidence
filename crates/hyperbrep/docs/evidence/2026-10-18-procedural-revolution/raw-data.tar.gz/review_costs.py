"""Keep unfavorable resource observations visible without inferring causation."""
import json,shutil
from run import OUT,ROOT
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-18-procedural-revolution'
load=lambda n:json.loads((OUT/n).read_text())
write=lambda n,x:(OUT/n).write_text(json.dumps(x,indent=2)+'\n')
costs=load('consumer-costs.json'); summary=load('qualification-summary.json'); cs=load('cost-summary.json')
old=summary['costs']
new_rows=[r for r in costs['rows'] if not r['matched_contract']]
selected={r['phase']:r['candidate'] for r in new_rows if r['case']=='selected_parallel_cap_revolves_and_replays'}
f=selected['first_fresh_input'];w=selected['repeated_fresh_input']
extra=(f" The complete new selected-cap recipe takes {f['elapsed_ns']/1e9:.3f}s on its first call and {w['elapsed_ns']/1e9:.3f}s per repeated call, with {f['requested_bytes']/1e9:.3f}/{w['requested_bytes']/1e9:.3f} GB of cumulative requested allocation respectively. Peak process RSS across all trials is {cs['maximum_process_rss_kib']/1024:.2f} MiB. Requested allocation is traffic, not simultaneous live memory. This expensive recipe and the {next(r['elapsed_seconds'] for r in load('results.json') if r['label']=='archive-generated-comparison'):.1f}s repeated archive comparison remain explicit resource follow-ups; no cause or optimization is established.")
summary['costs']=old+extra
cs['new_workflow_phase_rows']=new_rows
cs['repeated_archive_comparison_seconds']=next(r['elapsed_seconds'] for r in load('results.json') if r['label']=='archive-generated-comparison')
summary['cost_summary']=cs
write('cost-summary.json',cs);write('qualification-summary.json',summary)
stage=load('documentation-stage.json');stage['costs']=summary['costs'];write('documentation-stage.json',stage)
for p in [OUT/'costs.md',DEST/'costs.md',DEST/'README.md']:
    text=p.read_text();assert old in text;p.write_text(text.replace(old,summary['costs']))
rows=load('adverse-cost-samples.json')
lines=['# Resource review','',summary['costs'],'','## Preserved workflows','',
'Three phase rows have increased allocation traffic. Their complete raw trials remain in the cost data; no favorable sample was selected to discard them. No matched median timing exceeds the 10% review marker, and these shared-host observations do not establish a speedup.','',
'| Workflow / phase | Time ratio | Allocation-call change | Requested-byte change |','| --- | ---: | ---: | ---: |']
for r in rows:
    b=r['baseline'];c=r['candidate']
    lines.append(f"| {r['case']} / {r['phase']} | {r['ratio']:.6f} | {(c['allocation_calls']/b['allocation_calls']-1)*100:.6f}% | {(c['requested_bytes']/b['requested_bytes']-1)*100:.6f}% |")
lines+=['','## New workflows and remaining work','',
'The full-cap recipe takes about 49 ms first / 41 ms repeated, while the selected-cap recipe takes about 9.15 s / 8.87 s. These are different exact inputs, not a matched comparison establishing the cost of a single representation choice. The selected recipe includes the original Boolean crop, solid construction, exact queries, native export and cold admission. It requests about 74 million allocations per invocation. Profile that entire recipe to locate the responsible work before changing an owner or adding a cache. Preserve the original nonlinear curves, selected endpoints, certainty, validation and output materialization.',
'',
'All three preserved native consumer binaries grow: 40,464 bytes for revolution, 39,168 bytes for procedural profiles and 66,360 bytes for native solids. The new native/WASM consumer sizes and every artifact size are in cost-summary.json and artifact-size-summary.json. The new solid outputs total 6,808,306 bytes across 22 files (13 distinct contents). No matched baseline exists for the previously unsupported construction.',
'',
'The generated archive check takes 1,158.4 seconds and performs eight cold admissions per native pair, including repeated re-encoding stability checks. It completed within its 1,200-second external containment. This runtime is retained validation evidence, not a general import benchmark or an internal work bound. The original 829-file replay took 269.3 seconds.',
'',
'The retained change extends exact completion. It is not a performance-only optimization. Whole-operation work, retained heap, coefficient-growth and cancellation bounds remain open. RSS and cumulative requested allocation do not substitute for those contracts. Earlier adverse campaigns remain unchanged.']
(OUT/'adverse-cost-review.md').write_text('\n'.join(lines)+'\n')
p=OUT/'next-domains.md';p.write_text(p.read_text()+'''\n10. Profile the complete selected-cap construction/query/archive recipe (about\n    9 seconds and 9.46 GB cumulative allocation traffic in this campaign) and\n    repeated archive admission before choosing an optimization. Keep the original\n    selected geometry, all validation and materialized outputs. Locate cost in\n    the actual owner; do not infer a scalar-layer defect from a BRep symptom or\n    duplicate unrelated repairs owned by the concurrent thread. Allocation traffic\n    is not live heap, and the approximately 24 MiB process RSS is not a heap bound.\n''')
for n in ['cost-summary.json','qualification-summary.json','adverse-cost-review.md','next-domains.md']:shutil.copy2(OUT/n,DEST/n)
print('Recorded adverse allocations, expensive selected workflows, binary growth and archive runtime.')
