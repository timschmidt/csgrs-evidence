"""Run dependent boundary checks only after final crate qualification succeeds."""
from pathlib import Path
import json,subprocess,sys,time
out=Path(__file__).resolve().parent
required=['strict-clippy-all-02','tests-all-features-02','tests-minimal-features-02','clippy-minimal-features-02','rustdoc-02','fuzz-check-02','format-check-02']
deadline=time.monotonic()+1800
while True:
    rows={r['label']:r for r in json.loads((out/'results.json').read_text())}
    assert all(rows[k]['exit_code']==0 for k in required if k in rows)
    if all(k in rows for k in required): break
    assert time.monotonic()<deadline,'Final qualification did not finish'
    time.sleep(2)
for script,args in [('qualify_consumers.py',['baseline']),('qualify_consumers.py',['candidate']),('qualify_archives.py',['prior']),('generate_artifacts.py',[]),('qualify_archives.py',['generated'])]:
    print('Starting',script,*args,flush=True)
    subprocess.run([sys.executable,'-B',str(out/script),*args],check=True)
print('All external qualification completed; measurements have not started.',flush=True)
