"""Capture immutable source/environment before final qualification."""
from pathlib import Path
import datetime,hashlib,json,subprocess
import run
R=run.ROOT;O=run.OUT;B=Path('/mnt/development/csgrs')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,d):
 p=O/n;assert not p.exists(),p;p.write_text(json.dumps(d,indent=2)+'\n')
baseline=subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()
assert baseline=='a4cf86f0d4b7d0862a1fa39c39e3efd9e246d54a'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
assert run.git('rev-parse','HEAD')==baseline
names=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines())
names.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
assert all(not p.startswith('crates/hyperbrep/docs/evidence/') for p in names)
assert 'docs/properties-status.json' not in names
names.update(['Cargo.toml','Cargo.lock','rust-toolchain.toml'] if (R/'rust-toolchain.toml').exists() else ['Cargo.toml','Cargo.lock'])
for crate in ['hypersolve','hypercurve','hyperbrep','hyperbrep-io']:names.add('crates/'+crate+'/Cargo.toml')
write('candidate-source.json',dict(baseline=baseline,files={n:sha(R/n) for n in sorted(names)}))
write('baseline-source.json',dict(revision=baseline,clean=True,files={n:sha(B/n) for n in sorted(names) if (B/n).exists()}))
commands=[]
for command in [['rustc','-vV'],['cargo','--version'],['uname','-a'],['lscpu']]:
 r=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True)
 assert r.returncode==0
 commands.append(dict(command=command,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr))
keys=['CARGO_HOME','CARGO_TARGET_DIR','GMP_MPFR_SYS_CACHE','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','TMPDIR','RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUST_TEST_THREADS','HYPERSOLVE_SKIP_BENCHMARK_REPORTS','PATH']
write('environment.json',dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=commands,environment={k:run.ENV[k] for k in keys},workspace_lock_sha256=sha(R/'Cargo.lock'),workspace_lock_matches_baseline=(B/'Cargo.lock').read_bytes()==(R/'Cargo.lock').read_bytes()))
print('Frozen',len(names),'source/documentation/manifest files against',baseline)
