"""Audit the qualified source, exact archive migration and complete cost corpus."""
from pathlib import Path
import hashlib,json,re,statistics,subprocess,sys
import run
O=run.OUT;R=run.ROOT;B=Path('/mnt/development/csgrs')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==source['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
rows=json.loads((O/'results.json').read_text());checks={r['label']:r for r in rows}
assert len(rows)==len(checks)
required=['final-affected-clippy','final-owner-clippy','final-solver-topology',
 'final-owner-regressions','final-owner-rational-map-tests','final-owner-homogeneous-tests',
 'final-brep-release-tests','final-affected-rustdoc','final-brep-fuzz-check',
 'final-fmt-check','final-fuzz-fmt','final-wasm-build','final-wasm-run',
 'new-native-build','new-native-archives','candidate-original-interior-loop',
 'section-negative-control-check']
required += [f'{side}-{family}-{mode}' for side in ['baseline','candidate']
 for family in ['preserved','prior','surface','branches'] for mode in ['build','archives']]
for label in required:assert checks[label]['exit_code']==0,(label,checks[label]['exit_code'])
assert checks['baseline-original-interior-loop']['exit_code']==101
assert 'UnsupportedIntersection' in (O/'baseline-original-interior-loop.log').read_text()
assert checks['baseline-original-interior-loop']['initial_worktree_clean']
assert Path(checks['baseline-original-interior-loop']['source_patch']).read_bytes()==b''
for row in rows:
 assert sha(Path(row['log']))==row['log_sha256']
 assert sha(Path(row['source_patch']))==row['source_patch_sha256']
summary={}
for label in ['final-solver-topology','final-owner-regressions','final-brep-release-tests',
 'final-owner-rational-map-tests','final-owner-homogeneous-tests','section-negative-control-check']:
 counts=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/(label+'.log')).read_text())]
 assert counts,label
 summary[label]=dict(passed=sum(r[0] for r in counts),failed=sum(r[1] for r in counts),ignored=sum(r[2] for r in counts),batches=len(counts))
 assert summary[label]['failed']==0 and summary[label]['ignored']==0
write('test-summary.json',summary)

decoder=json.JSONDecoder()
def ws(s,p):
 while p<len(s) and s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':'
  a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
def migrate(raw):
 text=raw.decode();value=json.loads(text);assert value['version']==13
 a,b=member(text,0,'version');assert text[a:b]=='13'
 edits=[(a,b,'14')]
 def scan(p):
  p=ws(text,p)
  if text[p]=='{':
   p=ws(text,p+1)
   while text[p]!='}':
    key,p=decoder.raw_decode(text,p);p=ws(text,p);assert text[p]==':'
    a=ws(text,p+1);b=scan(a)
    if key=='PolynomialBranch':
     branch=json.loads(text[a:b]);assert isinstance(branch,dict) and 'maps' not in branch
     assert text[b-1]=='}';edits.append((b-1,b-1,',"maps":[]'))
    p=ws(text,b)
    if text[p]==',':p=ws(text,p+1)
   return p+1
  if text[p]=='[':
   p=ws(text,p+1)
   while text[p]!=']':
    p=ws(text,scan(p))
    if text[p]==',':p=ws(text,p+1)
   return p+1
  return decoder.raw_decode(text,p)[1]
 assert ws(text,scan(0))==len(text)
 for a,b,replacement in sorted(edits,reverse=True):text=text[:a]+replacement+text[b:]
 return text.encode()
groups=['baseline','candidate','fibers-baseline','fibers-candidate',
 'prior-baseline','prior-candidate','surface-baseline','surface-candidate','branches-baseline','branches-candidate','new']
artifacts={group:{str(p.relative_to(O/'artifacts'/group)):sha(p)
 for p in sorted((O/'artifacts'/group).glob('*.json'))} for group in groups}
comparisons=[]
for prefix in ['', 'fibers-','prior-','surface-','branches-']:
 assert artifacts[prefix+'baseline'] and artifacts[prefix+'baseline'].keys()==artifacts[prefix+'candidate'].keys()
 for name in artifacts[prefix+'baseline']:
  a=(O/'artifacts'/(prefix+'baseline')/name).read_bytes();b=(O/'artifacts'/(prefix+'candidate')/name).read_bytes()
  assert migrate(a)==b,(prefix,name)
  comparisons.append(dict(group=prefix or 'models',name=name,baseline_sha256=hashlib.sha256(a).hexdigest(),candidate_sha256=hashlib.sha256(b).hexdigest(),identical_after_declared_migration=True))
assert len(comparisons)==270,len(comparisons)
previous=Path('/tmp/hyperbrep-polynomial-section-20261019/artifacts')
prior_preservation=[]
for current_group,old_group in [('baseline','candidate'),('fibers-baseline','fibers-candidate'),('prior-baseline','prior-candidate'),('surface-baseline','surface-candidate'),('branches-baseline','new')]:
 old_files={p.name:p for p in (previous/old_group).glob('*.json')}
 assert old_files.keys()==artifacts[current_group].keys(),(current_group,old_group)
 for name,p in old_files.items():
  assert p.read_bytes()==(O/'artifacts'/current_group/name).read_bytes(),(current_group,name)
  prior_preservation.append(dict(group=current_group,name=name,sha256=sha(p),byte_identical_to_previous_qualified_output=True))
assert len(prior_preservation)==270
write('previous-corpus-audit.json',dict(files=prior_preservation,previous_evidence='2026-10-19-polynomial-branch-replay',unchanged_baseline_outputs=270))
assert artifacts['new']
write('archive-comparison.json',dict(preserved_files=len(comparisons),new_files=len(artifacts['new']),new_unique_payloads=len(set(artifacts['new'].values())),comparisons=comparisons,files=artifacts,contract='Archive 14 permits only the top-level 13→14 header and maps:[] appended to each existing PolynomialBranch object. Every other prior byte must match. Exact assertions, required validation and cold replay run separately.'))
fixture=[]
for name in ['cone-imported-lower.json','cone-imported-band.json','cone-rational-partition.json']:
 p='crates/hyperbrep/tests/fixtures/'+name;assert migrate((B/p).read_bytes())==(R/p).read_bytes()
 fixture.append(dict(path=p,before_sha256=sha(B/p),after_sha256=sha(R/p),only_declared_migration=True))
write('fixture-migration.json',fixture)
for p in ['crates/hyperbrep/tests/support/similarity.rs','crates/hyperbrep/tests/fixtures/cone-circle-point-query.json']:
 assert (B/p).read_bytes()==(R/p).read_bytes()
def rust_function(text,name):
 start=text.index('pub fn '+name+'(');opening=text.index('{',start);depth=1;end=opening+1
 while depth:
  depth+=(text[end]=='{')-(text[end]=='}');end+=1
 return text[start:end]
owner='crates/hypercurve/tests/support/polynomial_curves.rs'
old=(B/owner).read_text();new=(R/owner).read_text()
names=re.findall(r'^pub fn (\w+)\(',old,re.M)
assert len(names)==8
for name in names:assert rust_function(old,name)==rust_function(new,name),name
original=(O/'interior/src/main.rs').read_text()
current=(R/'crates/hyperbrep/tests/support/plane_tensor_sections.rs').read_text()
body=rust_function(current,'original_full_interior_loop').split('{',1)[1].rsplit('}',1)[0]
oldbody=original.split('fn main() {',1)[1].rsplit('}',1)[0]
def formatted_body(body):
 result=subprocess.run(['rustfmt','--edition','2024','--emit','stdout'],input='fn original_full_interior_loop() {'+body+'}\n',text=True,capture_output=True,env=run.ENV,cwd=R,check=True)
 return result.stdout
assert formatted_body(body)==formatted_body(oldbody),'original full fixture changed beyond formatting'
assert (O/'interior/src/main.rs').read_bytes()==Path('/tmp/hyperbrep-polynomial-section-20261019/interior/src/main.rs').read_bytes()
write('source-migration-audit.json',dict(original_owner_functions_byte_identical=names,standalone_original_full_interior_fixture_byte_identical=True,shared_original_full_fixture_identical_after_rustfmt=True,original_conic_negative_control_byte_identical=True,non_model_query_fixture_byte_identical=True,model_fixture_changes='Only declared archive-14 migration; see fixture-migration.json.'))
if '--archives-only' in sys.argv:
 print(json.dumps(dict(preserved_archives=len(comparisons),new_archives=len(artifacts['new']),source_hashes_match=True,required_checks_pass=True)))
 raise SystemExit(0)

raw=[];pairs=[];rss=[]
for family,expected in [('preserved',12),('prior',8),('surface',20),('branches',10)]:
 for repeat in range(3):
  per={}
  for side in ['baseline','candidate']:
   label=f'cost-{family}-{side}-{repeat}';assert checks[label]['exit_code']==0
   samples=[json.loads(l) for l in (O/(label+'.log')).read_text().splitlines() if l.startswith('{')]
   data=[r for r in samples if 'case' in r];assert len(data)==expected,(label,len(data))
   per[side]={(r['case'],r['phase']):r for r in data}
   raw.append(dict(family=family,repeat=repeat,side=side,rows=samples))
   resource=json.loads((O/'costs'/(label+'.json')).read_text());assert resource['exit_code']==0
   rss.append(dict(label=label,**resource))
  assert per['baseline'].keys()==per['candidate'].keys()
  for key,a in per['baseline'].items():
   b=per['candidate'][key];assert a['iterations']==b['iterations'] and a['outcome']==b['outcome']
   pairs.append(dict(family=family,repeat=repeat,case=key[0],phase=key[1],ratio=b['elapsed_ns']/a['elapsed_ns'],allocation_call_delta=b['allocation_calls']-a['allocation_calls'],requested_byte_delta=b['requested_bytes']-a['requested_bytes'],iterations=a['iterations']))
for repeat in range(3):
 label=f'cost-new-{repeat}';assert checks[label]['exit_code']==0
 samples=[json.loads(l) for l in (O/(label+'.log')).read_text().splitlines() if l.startswith('{')]
 assert len([r for r in samples if 'case' in r])==12
 raw.append(dict(family='new',repeat=repeat,side='candidate',rows=samples))
 resource=json.loads((O/'costs'/(label+'.json')).read_text());assert resource['exit_code']==0
 rss.append(dict(label=label,**resource))
assert len(pairs)==150
medians=[]
for family,case,phase in sorted({(r['family'],r['case'],r['phase']) for r in pairs}):
 vals=[r for r in pairs if (r['family'],r['case'],r['phase'])==(family,case,phase)]
 assert len(vals)==3
 medians.append(dict(family=family,case=case,phase=phase,latency_ratio=statistics.median(r['ratio'] for r in vals),allocation_call_deltas=[r['allocation_call_delta'] for r in vals],requested_byte_deltas=[r['requested_byte_delta'] for r in vals]))
assert len(medians)==50
write('cost-analysis.json',dict(scope='Three alternating CPU-0 pinned process pairs each for all six preserved modeling/branch workflows, all four plane/pcurve workflows all ten rational-surface/affine workflows and all five polynomial-replay workflows. Three absolute processes cover six new complete section groups; the unchanged original fixture runs for correctness and is excluded from cost rows because it prints its full debug result. Every call retains assertions, required topology validation, output materialization and replay. First and three repeated fresh-input calls are separate phases; this is not an eviction campaign.',raw_samples=raw,pairs=pairs,phase_medians=medians,process_resources=rss,maximum_rss_kib=max(r['maximum_rss_kib'] for r in rss),increased_allocation_rows=sum(r['allocation_call_delta']>0 for r in pairs),increased_byte_rows=sum(r['requested_byte_delta']>0 for r in pairs),limits='Rust allocation counts and requested traffic exclude foreign allocators and are not live heap. Shared-host timings establish no speedup. New successful contracts have no previous successful timing baseline. All adverse observations are retained.'))
binaries={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((O/'bin').iterdir()) if p.is_file()}
w=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_plane_tensor_consumer.wasm')
binaries['wasm']=dict(bytes=w.stat().st_size,sha256=sha(w));write('binary-sizes.json',binaries)
for family in ['preserved','prior','surface','branches']:
 a=O/family/'baseline';b=O/family/'candidate'
 for p in a.glob('*.rs'):
  assert p.read_text().replace('/mnt/development/csgrs/','/mnt/development/csgrs/target/hyperbrep-development/')==(b/p.name).read_text(),(family,p.name)
write('consumer-source-scope.json',dict(matched_recipes=True,files={str(p.relative_to(O)):sha(p) for family in ['consumer','preserved','prior','surface','branches','interior'] for p in (O/family).rglob('*') if p.is_file() and (p.suffix in {'.rs','.toml'} or p.name=='Cargo.lock')},scope='External source-path projects, without workspace patches. Not installed registry packages or production bindings. All seven new exports execute the same shared public recipes natively and in WASM. Every preserved workflow remains in both correctness and cost qualification.'))
write('verification.json',dict(required_checks=required,source_hashes_match=True,source_files=len(source['files']),baseline_clean=True,baseline_revision=source['baseline'],raw_logs_and_patches_match=True,only_declared_migration_for_prior_artifacts=True,original_conic_rejection_fixture_unchanged=True,original_interior_loop_success_assertion_preserved=True,upstream_observation='No new upstream check in this qualification; main is pinned to the recorded baseline.',no_push=True))
print(json.dumps(dict(tests=summary,archives=len(comparisons),new_archives=len(artifacts['new']),ratio_range=[min(r['latency_ratio'] for r in medians),max(r['latency_ratio'] for r in medians)],binaries=binaries),indent=2))
