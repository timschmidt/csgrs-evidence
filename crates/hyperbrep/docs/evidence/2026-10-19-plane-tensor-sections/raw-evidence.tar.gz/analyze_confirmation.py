"""Keep the fixed confirmation separate from all original cost observations."""
from pathlib import Path
import hashlib,json,statistics
import run
O=run.OUT
source=json.loads((O/'candidate-source.json').read_text())
assert all(hashlib.sha256((run.ROOT/p).read_bytes()).hexdigest()==h for p,h in source['files'].items())
checks={r['label']:r for r in json.loads((O/'results.json').read_text())}
original=json.loads((O/'cost-analysis.json').read_text())
old={(r['family'],r['side']):{(v['case'],v['phase']):v for v in r['rows'] if 'case' in v} for r in original['raw_samples'] if r['repeat']==0 and r['family']!='new'}
raw=[];pairs=[];resources=[]
for family,expected in [('preserved',12),('prior',8),('surface',20),('branches',10)]:
 for repeat in range(3):
  per={}
  for side in ['baseline','candidate']:
   label=f'confirm-{family}-{side}-{repeat}'
   assert checks[label]['exit_code']==0,label
   rows=[json.loads(l) for l in (O/(label+'.log')).read_text().splitlines() if l.startswith('{')]
   data={(r['case'],r['phase']):r for r in rows if 'case' in r};assert len(data)==expected
   for key,r in data.items():
    before=old[family,side][key]
    for field in ['outcome','iterations','allocation_calls','requested_bytes']:assert r[field]==before[field],(label,key,field)
   per[side]=data;raw.append(dict(family=family,repeat=repeat,side=side,rows=rows))
   resource=json.loads((O/'costs'/(label+'.json')).read_text());assert resource['exit_code']==0
   resources.append(dict(label=label,**resource))
  assert per['baseline'].keys()==per['candidate'].keys()
  for key,a in per['baseline'].items():
   b=per['candidate'][key]
   pairs.append(dict(family=family,repeat=repeat,case=key[0],phase=key[1],latency_ratio=b['elapsed_ns']/a['elapsed_ns'],allocation_call_delta=b['allocation_calls']-a['allocation_calls'],requested_byte_delta=b['requested_bytes']-a['requested_bytes']))
assert len(pairs)==150
medians=[]
for key in sorted({(r['family'],r['case'],r['phase']) for r in pairs}):
 rows=[r for r in pairs if (r['family'],r['case'],r['phase'])==key];assert len(rows)==3
 medians.append(dict(family=key[0],case=key[1],phase=key[2],latency_ratio=statistics.median(r['latency_ratio'] for r in rows)))
sizes=json.loads((O/'binary-sizes.json').read_text())
for p in (O/'bin').iterdir():
 assert hashlib.sha256(p.read_bytes()).hexdigest()==sizes[p.name]['sha256']
report=dict(contract='confirmation-contract.md',cpu=10,pairs=pairs,phase_medians=medians,raw_samples=raw,process_resources=resources,original_cost_evidence_unchanged=True,all_original_outcomes_iterations_and_allocation_counts_preserved=True,binary_hashes_unchanged=True,source_hashes_unchanged=True,minimum_ratio=min(r['latency_ratio'] for r in medians),maximum_ratio=max(r['latency_ratio'] for r in medians),above_ten_percent=[r for r in medians if r['latency_ratio']>1.1],maximum_rss_kib=max(r['maximum_rss_kib'] for r in resources),limits='Fixed confirmation on another pinned CPU, not a controlled hardware experiment. Original CPU-0 observations remain separate and retained. No speedup or causal attribution to scheduling, frequency, NUMA, or code is established.')
(O/'cost-confirmation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['minimum_ratio','maximum_ratio','above_ten_percent','maximum_rss_kib']},indent=2))
