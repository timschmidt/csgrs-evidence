"""Record the qualified section increment, preserving every other root-ledger byte."""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess,tarfile
import run
R=run.ROOT;O=run.OUT;NAME='2026-10-19-plane-tensor-sections'
D=R/'crates/hyperbrep/docs/evidence'/NAME
assert not D.exists(), 'Do not rerun after evidence has been copied'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
verification=json.loads((O/'verification.json').read_text())
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
tests=json.loads((O/'test-summary.json').read_text());full=tests['final-brep-release-tests']
cost=json.loads((O/'cost-analysis.json').read_text());art=json.loads((O/'archive-comparison.json').read_text());sizes=json.loads((O/'binary-sizes.json').read_text())
ratios=[r['latency_ratio'] for r in cost['phase_medians']]
q=(f"All-feature release BRep/IO suites pass {full['passed']} tests in {full['batches']} batches, with no failures or ignored tests. Focused solver topology, homogeneous arithmetic and curve polynomial/rational/selected-field/work-budget regressions pass, including five rational-map owner tests. All-target/all-feature Clippy for the four affected crates, warning-denied rustdoc, BRep fuzz-target compilation and formatting pass. Seven shared public section recipes pass natively and as seven actual zero-import Wasmtime exports. They cover the unchanged full 3x3 interior-circle fixture, nonlinear weighted images, selected restriction, reversal, noncircular cubic/cusp/node sections, rational and nonrational isolated contacts, disconnected and mixed-dimensional sets, exact 1e-12 loops, empty and contained sets, original pole guards, malformed replay/admission limits, strict/approximate/strict and budget refusal/recovery, and typed solver/image frontiers. Both pcurve images are independently revalidated over the whole branch after cold replay and after affine transport plus replay. A surface with matching endpoints and a different interior is rejected. The models contain geometry, edges and pcurves; they are not closed solids or trimmed faces. "
 f"All {art['preserved_files']} previous archive payloads match after only the declared version-14 migration; {art['new_files']} new archive records retain {art['new_unique_payloads']} distinct payloads. Exact geometric assertions, required model/image validation and deterministic bytes are checked separately. The byte-preserved standalone interior-loop success assertion fails on the clean baseline with UnsupportedIntersection and passes on the candidate; its shared copy differs only by rustfmt formatting. Strengthened downstream tests reproduced an affine-replay whole-image proof failure before the owner fix; no new Unknown or weaker assertion replaces those successes.")
growth={family:sizes[family+'-candidate']['bytes']-sizes[family+'-baseline']['bytes'] for family in ['preserved','prior','surface','branches']}
slow=[dict(family=r['family'],case=r['case'],phase=r['phase'],ratio=r['latency_ratio']) for r in cost['phase_medians'] if r['latency_ratio']>1.1]
p=(f"Three alternating CPU-0 pinned process pairs retain all twenty-five previously successful workflows: six modeling/branch, four plane/pcurve, ten rational-surface/affine and five polynomial-replay recipes. First and three repeated fresh-input calls retain assertions, materialization, required validation and replay. Three absolute processes run six new section groups; the unchanged original fixture runs for correctness but is excluded from cost rows because it prints its full Debug result. The fifty median paired latency ratios range {min(ratios):.6f} to {max(ratios):.6f}; {len(slow)} exceed the 10% review marker. {cost['increased_allocation_rows']} of 150 paired rows increase counted Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. Maximum observed process RSS in the initial set is {cost['maximum_rss_kib']} KiB. Matched executable byte changes are {growth}. All adverse rows, native/WASM sizes and hashes are retained. Shared-host timings establish no speedup or significance; requested allocation traffic is not live heap and excludes foreign allocator internals. New successful sections have no prior successful timing baseline. The active-total-degree composition and no-map/definition-equality fast paths preserve native source queries while avoiding unnecessary rational-expression growth; the sixteen-image exact owner chain is a finite composition test, not a general resource bound.")
confirmation=json.loads((O/'cost-confirmation.json').read_text())
assert confirmation['all_original_outcomes_iterations_and_allocation_counts_preserved'] and confirmation['binary_hashes_unchanged'] and confirmation['source_hashes_unchanged']
p += (f" A predeclared fixed confirmation ran three additional alternating pairs for all twenty-five preserved workflows on CPU 10, using the same binaries and complete calls. Its fifty median ratios range {confirmation['minimum_ratio']:.6f} to {confirmation['maximum_ratio']:.6f}, with {len(confirmation['above_ten_percent'])} phases above the 10% review marker and maximum process RSS {confirmation['maximum_rss_kib']} KiB. Every outcome, iteration count, allocation count and requested-byte count matches the original same-side samples. Both sets remain separate; neither replaces adverse observations in the other. Sampled CPU frequencies varied, but these observations do not establish a cause for the timing changes. Slower common phases include primitive repeated calls, clipped/void first calls and joint-form first calls. This is retained as a certified completion extension; stable latency non-regression and any general speedup remain unqualified. Controlled performance follow-up is required before either claim.")
limits=("The new complete section domain is plane/rational-Bezier over the entire native rectangle when the finite-fiber solver and whole-box injectivity certificate succeed. Vertical/repeated/boundary components, noninjective or insufficiently certified projections, general NURBS and surface/surface sections, implicit derivative/event queries, trimmed arrangements and their curved solid Booleans remain open. Selected angular/procedural evaluation and the prior native-conic affine cold-replay blocker remain separate limitations. Archive 14 rejects formats through 13 without a compatibility decoder; old bytes require the declared header and empty-map migration. Individual solver controls and metadata limits are not total-work, coefficient-growth, heap, stack or cancellation bounds; external time containment is retained. Source-path native/WASM projects do not establish installed distributions or production bindings. Runtime fuzz/ASan/lexicase, formal proofs, measured coverage, MSRV, full release/workflow and push gates remain unqualified. All 28 work packages remain open/in-progress. The eaa0cae54 push exception is consumed; this increment is not pushed.")
report=dict(increment='plane-tensor-sections-2026-10-19',baseline=source['baseline'],complete=False,retained=True,qualification=q,cost_evidence=p,adverse_time_rows_over_ten_percent=slow,limits=limits,archive_version=14,source_files=len(source['files']))
write(O/'report.json',report)
write(O/'ideas.json',[
 dict(idea='Whole-rectangle homogeneous pullback and complete finite-fiber decomposition',status='kept',evidence='The original full interior-loop failure becomes a strict success. The complete solver retains disconnected, singular and isolated components; independent polynomial fixtures check the admitted sets.'),
 dict(idea='Joint rational images with original guards and source charts',status='kept',evidence='Both pcurves and spatial curves agree through selected restriction, reversal, affine transport and cold replay. Point and branch pole controls reject removable poles instead of cancelling their domain.'),
 dict(idea='Normalized symmetric-Jacobian interval certificate',status='kept',evidence='A sufficient whole-box injectivity proof admits nonlinear weighted images and refuses folded or insufficiently certified projections. Research scope and proof inference are recorded in research.md.'),
 dict(idea='Whole-image equality modulo the source equation',status='kept',evidence='Affine replay exposed structurally different but mathematically identical projected maps. Exact coordinate cross-product divisibility resolves the failure, while perturbations and endpoint-only false images are rejected.'),
 dict(idea='Use active total degree for repeated projective composition',status='kept',evidence='Homogeneous arithmetic tests and sixteen retained projective point images preserve independent exact identities without unnecessary denominator-power inflation. This is a correctness/composition safeguard, not a matched speedup claim.'),
 dict(idea='Preserve control-net and existing linear/bilinear fast paths',status='kept',evidence='Strict one-sided and coplanar nets decide directly; preserved consumers and every adverse cost observation are retained in cost-analysis.json and cost-confirmation.json.'),
 dict(idea='Use UV topology as complete spatial topology without a separate image proof',status='rejected',evidence='Different UV points can share an image. Nonempty polynomial sections require the whole-domain injectivity certificate before publication.'),
 dict(idea='Accept endpoint or sampled agreement as a complete surface image proof',status='rejected',evidence='The explicit negative surface agrees at both branch endpoints but differs in its interior. Whole-equation and coordinate proofs remain mandatory.'),
 dict(idea='Compatibility decoder or independent-coordinate adapter',status='architecture-inapplicable',evidence='The authorized greenfield break uses archive 14 with no adapter. Selected joint fields and original guards remain authoritative.'),
])
(O/'README.md').write_text('# Complete plane/tensor sections\n\n'+q+'\n\n'+p+'\n\n'+limits+'''

`contract.md` records the pre-implementation owners, input domain and property obligations. `implementation-notes.md` explains the full-image proof and the reproduced affine-replay failure. `candidate-source.json`, `verification.json`, `test-summary.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate correctness, deterministic serialization and costs. `ideas.json` records retained and rejected approaches; `next-domains.md` identifies the remaining arrangement and differential work.

`raw-evidence.tar.gz` retains every command/log/source patch, early compiler and composition failures, the original full fixture, external consumer manifests and locks, archive outputs, and raw cost/RSS samples. Executables and caches are excluded. Baseline consumers link the frozen main checkout; candidate consumers link the isolated development checkout. Paths need adjustment for reproduction in a new output directory. Never rerun a frozen snapshot runner after copying its evidence into the repository.

The early section tests exposed a cusp chart-rebasing mismatch. The complete source-parameter proof now applies to polynomial branches. Stronger replay tests then exposed transformed tensor projection definitions that agree only modulo the section equation; Hypercurve owns that proof. Initial compiler failures from the explicit selected-contact API migration and all diagnostic failures remain in the raw record. The final frozen checks qualify the complete change together.
''')
with (O/'README.md').open('a') as note:
 note.write('\nThe first final archive audit used an obsolete six-function fixture inventory. The frozen baseline has eight original owner functions; the corrected audit checks all eight unchanged bodies. No geometry, policy, assertion or production source changed. See `audit-correction.md`; the failed log and original script are retained.\n')
sp=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json';status=json.loads(sp.read_text());before=copy.deepcopy(status)
status['increments'].append(dict(id=report['increment'],work_packages=['WP02','WP05a','WP05b','WP06','WP13','WP21'],properties=['P1','P4','P5','P8','P9','P15','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],change='Construct complete admitted plane/rational-Bezier sections with joint rational images, both pcurves, whole-image validation through affine replay, selected contacts and archive 14.',sources=['../src/geometry/plane_tensor.rs','../src/geometry/planar_image.rs','../src/topology/validation/tensor.rs','../src/persistence/polynomial.rs','../src/persistence/planar_points.rs','../src/persistence/admission/shapes.rs','../../hypersolve/src/bivariate_arithmetic.rs','../../hypercurve/src/rational_map.rs','../../hypercurve/src/polynomial_curve.rs','../../hypercurve/src/polynomial_point.rs','../tests/support/plane_tensor_sections.rs'],evidence='evidence/'+NAME+'/manifest.json',validation=q,cost_evidence=p,limits=limits))
status['next_actions'].insert(0,'Continue WP05a/WP05b/WP06 from evidence/'+NAME+'/next-domains.md. The original full interior-loop plane/tensor target now succeeds with both pcurves and whole-image validation through affine replay. Preserve that success corpus while extending implicit differential/event queries, complete dual-chart trim arrangements and spatial image certificates. General curved solid Booleans and total-resource/release gates remain open.')
assert status['increments'][:-1]==before['increments'] and status['work_packages']==before['work_packages'] and not status['complete'];write(sp,status)
lp=R/'docs/properties-status.json';text=lp.read_bytes().decode('utf-8');ledger=json.loads(text);entry=ledger['current_work']['hyperbrep']
evidence='crates/hyperbrep/docs/evidence/'+NAME
entry.update(latest_implementation=report['increment'],latest_feature_evidence=evidence+'/manifest.json',latest_evidence=evidence+'/manifest.json',qualification=q,performance_evidence=p,limits=limits)
decoder=json.JSONDecoder()
def ws(s,p):
 while s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;lp.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()))
post=[]
for name,command in [('fmt',['cargo','fmt','--all','--','--check']),('fuzz-fmt',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check']),('diff',['git','diff','--check'])]:
 result=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True);(O/('post-doc-'+name+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(name,result.stdout,result.stderr);post.append(dict(name=name,command=command,exit_code=0))
assert all(sha(R/p)==h for p,h in source['files'].items());write(O/'post-documentation-checks.json',dict(checks=post,qualified_source_unchanged=True))
D.mkdir()
for name in ['README.md','contract.md','next-domains.md','report.json','ideas.json','candidate-source.json','baseline-source.json','verification.json','test-summary.json','archive-comparison.json','cost-analysis.json','cost-confirmation.json','confirmation-contract.md','confirmation-environment.json','binary-sizes.json','environment.json','consumer-source-scope.json','fixture-migration.json','previous-corpus-audit.json','source-migration-audit.json','ledger-scope.json','post-documentation-checks.json','implementation-notes.md','research.md','audit-correction.md']:
 shutil.copy(O/name,D/name)
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
 for p in sorted(O.rglob('*')):
  if p.is_file() and not p.is_symlink() and (p.suffix in {'.json','.log','.patch','.py','.rs','.toml','.md'} or p.name=='Cargo.lock'):
   tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
write(D/'manifest.json',dict(increment=report['increment'],baseline=source['baseline'],source_files=len(source['files']),complete=False,retained=True,no_push=True,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file()}))
print(json.dumps(dict(evidence=str(D),increment_count=len(status['increments']),qualification=q,cost_evidence=report['cost_evidence']),indent=2))
