#[allow(dead_code)]
#[path = "/mnt/development/csgrs/crates/hypercurve/tests/support/rational_point_forms.rs"]
mod forms;
#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/rational_surface_evaluation.rs"]
mod surfaces;
fn native_forms_case(){forms::rational_curve_source_and_authored_values(); forms::scalar_chart_images_keep_their_joint_source();}
fn cases()->[(&'static str,fn());10] {[
 ("joint_forms",forms::joint_identities_and_original_poles),
 ("transformed_forms",forms::rational_queries_preserve_similarity_and_cold_sources),
 ("native_forms",native_forms_case),
 ("tensor_images",surfaces::joint_tensor_images_compose_transform_and_replay),
 ("procedural_images",surfaces::selected_rational_extrusions_and_knot_boundaries),
 ("policy_admission",surfaces::rational_surface_policy_and_admission),
 ("knot_domains",surfaces::nurbs_second_span_and_final_endpoint),
 ("affine_families",affine::affine_images_cover_native_and_retained_families),
 ("affine_admission",affine::affine_images_preserve_periods_derivatives_and_admission),
 ("field_resources",owner_resource_and_fields),
]}

#[path="/mnt/development/csgrs/crates/hyperbrep/tests/support/affine_curve_images.rs"]
mod affine;
fn owner_resource_and_fields(){forms::rational_queries_recover_after_budget_refusal();forms::independent_support_fields_keep_rational_identities();}
