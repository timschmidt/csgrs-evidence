"""Run archive/cost audits only after both native qualification streams finish."""
import json,time
import run
O=run.OUT
started=time.monotonic()
while True:
 rows={r['label']:r for r in json.loads((O/'results.json').read_text())}
 failures=[r for name,r in rows.items() if name.startswith(('final-','new-native-','candidate-preserved-','candidate-prior-','candidate-surface-','candidate-branches-')) and r['exit_code']]
 assert not failures,[(r['label'],r['exit_code']) for r in failures]
 if 'final-fuzz-fmt' in rows and 'candidate-original-interior-loop' in rows:
  break
 assert time.monotonic()-started<28800,'qualification did not finish'
 time.sleep(5)
assert run.run(dict(label='final-archive-audit',command=['python3','-B',str(O/'analyze.py'),'--archives-only'],seconds=600))==0
# All compilation and validation processes have ended before these paired costs.
import costs
assert run.run(dict(label='final-evidence-analysis',command=['python3','-B',str(O/'analyze.py')],seconds=600))==0
