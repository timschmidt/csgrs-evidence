import run
O=run.OUT
assert not any(k.startswith('HYPERBREP_') and 'ARTIFACT' in k for k in run.ENV)
(O/'costs').mkdir(exist_ok=True)
for repeat in range(3):
 for family in ['preserved','prior','surface','branches']:
  for side in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   name=family+'-'+side;label='cost-'+name+'-'+str(repeat)
   assert run.run(dict(label=label,source_scope='main baseline a4cf86f0d4b7d0862a1fa39c39e3efd9e246d54a' if side=='baseline' else 'qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','0',str(O/'bin'/name),'measure'],seconds=2400))==0
 label='cost-new-'+str(repeat)
 assert run.run(dict(label=label,source_scope='qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','0',str(O/'bin/new'),'measure'],seconds=2400))==0
