import run
jobs=[
 ('final-affected-clippy',['cargo','clippy','--offline','--locked','-p','hyperbrep','-p','hyperbrep-io','--all-targets','--all-features','--','-D','warnings'],3600),
 ('final-owner-clippy',['cargo','clippy','--offline','--locked','-p','hypersolve','-p','hypercurve','--all-targets','--all-features','--','-D','warnings'],3600),
 ('final-solver-topology',['cargo','test','--offline','--locked','--release','-p','hypersolve','--all-features','--test','bivariate_topology'],2400),
 ('final-owner-regressions',['cargo','test','--offline','--locked','--release','-p','hypercurve','--all-features','--test','polynomial_curves','--test','rational_point_forms','--test','selected_point_definitions','--test','selected_fiber_images','--test','work_budget'],2400),
 ('final-owner-rational-map-tests',['cargo','test','--offline','--locked','--release','-p','hypercurve','--all-features','--lib','rational_map::tests'],2400),
 ('final-owner-homogeneous-tests',['cargo','test','--offline','--locked','--release','-p','hypersolve','--all-features','--lib','bivariate_arithmetic::tests'],2400),
 ('final-brep-release-tests',['cargo','test','--offline','--locked','--release','-p','hyperbrep','-p','hyperbrep-io','--all-features','--no-fail-fast'],10800),
 ('final-affected-rustdoc',['cargo','doc','--offline','--locked','-p','hypersolve','-p','hypercurve','-p','hyperbrep','-p','hyperbrep-io','--all-features','--no-deps'],3600),
 ('final-brep-fuzz-check',['cargo','check','--offline','--locked','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--bins'],2400),
 ('final-fmt-check',['cargo','fmt','--all','--','--check'],600),
 ('final-fuzz-fmt',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check'],600),
]
for label,command,seconds in jobs:
 job=dict(label=label,command=command,seconds=seconds)
 if label=='final-affected-rustdoc':job['env']={'RUSTDOCFLAGS':'-D warnings'}
 run.run(job)
