"""Fixed confirmation from confirmation-contract.md; retain the original observations."""
from pathlib import Path
import json,time
import run
O=run.OUT
assert (O/'verification.json').exists()
assert not any(k.startswith('HYPERBREP_') and 'ARTIFACT' in k for k in run.ENV)
observations=[]
def observe(label,stage):
 fields={}
 for cpu in [0,10]:
  for name in ['scaling_cur_freq','scaling_governor']:
   p=Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq')/name
   fields[f'cpu{cpu}_{name}']=p.read_text().strip() if p.exists() else None
 fields['loadavg']=Path('/proc/loadavg').read_text().strip()
 observations.append(dict(label=label,stage=stage,time_ns=time.time_ns(),**fields))
 (O/'confirmation-environment.json').write_text(json.dumps(observations,indent=2)+'\n')
for repeat in range(3):
 for family in ['preserved','prior','surface','branches']:
  for side in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   name=family+'-'+side;label='confirm-'+name+'-'+str(repeat)
   observe(label,'before')
   assert run.run(dict(label=label,source_scope='frozen baseline/candidate; original binaries unchanged',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','10',str(O/'bin'/name),'measure'],seconds=2400))==0
   observe(label,'after')
