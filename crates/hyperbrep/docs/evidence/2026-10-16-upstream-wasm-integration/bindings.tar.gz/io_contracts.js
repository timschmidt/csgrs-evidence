"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// Compile and execute beside the actual generated csgrs.js and csgrs.d.ts.
const csgrs_1 = require("./csgrs");
function unreachable(value) {
    throw new Error(`Unexpected IO variant: ${value}`);
}
function describe(error) {
    const format = error.format;
    switch (error.code) {
        case "std_io": {
            const kind = error.ioKind;
            const osCode = error.osCode;
            const cause = error.cause;
            return `${format}: ${kind} (${osCode}): ${cause.message}`;
        }
        case "parse_float":
        case "dxf":
        case "gerber_codegen": {
            const cause = error.cause;
            return `${format}: ${cause.message}`;
        }
        case "malformed_input":
        case "unsupported":
        case "geometry":
        case "gerber_parsing": {
            const detail = error.detail;
            return `${format}: ${detail}`;
        }
        case "unrepresentable_coordinate": {
            const field = error.field;
            const target = error.target;
            return `${format}: ${field} cannot use ${target}`;
        }
        case "invalid_metadata": {
            const field = error.field;
            return `${format}: invalid ${field}`;
        }
        case "size_overflow": {
            const limit = error.limit;
            return `${format}: ${limit}`;
        }
        case "construction": {
            const cause = error.cause;
            return `${format}: ${cause.code}: ${cause.message}`;
        }
        default:
            return unreachable(error);
    }
}
function ensure(value, message) {
    if (!value)
        throw new Error(message);
}
function caughtIo(operation) {
    let value;
    try {
        value = operation();
    }
    catch (error) {
        ensure(error instanceof Error && error.name === "GeometryIoError", "typed format failure required");
        // This catch handles only documented CSGRS format entry points. The runtime
        // JS matrix independently verifies their discriminants and variant fields.
        const typed = error;
        ensure(describe(typed).length > 0, "diagnostic must survive");
        return typed;
    }
    if (value instanceof csgrs_1.MeshJs)
        value.free();
    throw new Error("invalid format operation returned a model");
}
const owned = [];
function keep(value) {
    owned.push(value);
    return value;
}
function takeMesh(result) {
    const index = owned.indexOf(result);
    ensure(index >= 0, "owned result required");
    owned.splice(index, 1);
    return keep(result.intoMesh());
}
try {
    const source = keep(csgrs_1.MeshJs.cube(0.25));
    const bytes = source.toSTLBinary();
    const restored = keep(csgrs_1.MeshJs.fromSTL(bytes));
    const empty = keep(new csgrs_1.MeshJs());
    const outcome = keep(restored.unionWithContext(empty, false));
    const certainty = outcome.certainty;
    ensure(certainty === csgrs_1.GeometryCertaintyJs.Certified, "parsed geometry must certify independently");
    const mesh = takeMesh(outcome);
    ensure(mesh.triangleCount() === 12, "complete imported cube required");
    const invalid = caughtIo(() => csgrs_1.MeshJs.fromSTL(new TextEncoder().encode("not an STL")));
    ensure(invalid.code === "std_io" && invalid.format === "STL", "parser category must survive");
    ensure(invalid.cause instanceof Error, "parser cause required");
    const open = keep(csgrs_1.MeshJs.fromArrays(Float64Array.from([0, 0, 0, 1, 0, 0, 0, 1, 0]), Uint32Array.from([0, 1, 2])));
    const topology = caughtIo(() => csgrs_1.MeshJs.fromSTL(open.toSTLBinary()));
    ensure(topology.code === "construction", "native validation failure required");
    const cause = topology.cause;
    ensure(cause.code === "invalid_input", "native category must survive");
    console.log("TypeScript native STL pipeline and discriminated errors passed");
}
finally {
    for (const value of owned.reverse())
        value.free();
}
