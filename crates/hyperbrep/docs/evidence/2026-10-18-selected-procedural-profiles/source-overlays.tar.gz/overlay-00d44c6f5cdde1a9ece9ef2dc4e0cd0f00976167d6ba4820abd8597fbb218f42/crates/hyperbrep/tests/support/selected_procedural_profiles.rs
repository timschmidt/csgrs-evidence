use hyperbrep::*;
use hypercurve::{
    BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval,
    BezierParameterPolynomial, BezierParameterRange2, BooleanOp, Curve2, CurvePath2, CurveRegion2,
    CurveRegionLoopRole, FillRule, LineSeg2, Point2 as Uv, QuadraticBezier2,
};
use std::cmp::Ordering;

#[allow(dead_code)]
#[path = "parallel_profile_extrusion.rs"]
mod original;

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn source() -> Curve2 {
    let root = BezierAlgebraicParameter2::try_isolate(
        BezierParameterPolynomial::try_new_power_basis(vec![
            (-1).into(), 0.into(), 0.into(), 2.into(),
        ]).unwrap(),
        BezierParameterInterval::try_new(q(3, 4), q(7, 8)).unwrap(),
    ).unwrap();
    Curve2::try_analytic_parallel(
        QuadraticBezier2::new(Uv::from_values(0, 0), Uv::from_values(2, 2), Uv::from_values(4, 0))
            .parallel_left(Real::one()).unwrap(),
        BezierParameterRange2::try_new(
            BezierParameter2::Exact(q(1, 4)), BezierParameter2::Algebraic(root),
        ).unwrap(),
    ).unwrap()
}

fn lift(source: Curve2) -> Curve3 {
    Curve3::planar_image(source, Point3::origin(), Vector3::x(), Vector3::y()).unwrap()
}

fn replay(model: &Model) -> Model {
    let json = model.to_json().unwrap();
    let restored = RawModel::from_json(&json, &ArchiveLimits::default()).unwrap().validate().unwrap();
    assert_eq!(restored.to_json().unwrap(), json);
    restored
}

pub fn selected_origin_lines_retain_source_and_replay() {
    let source = lift(source());
    let origin = source.point_at(source.domain().end()).unwrap();
    let line = Curve3::translation(origin.clone(), Vector3::new([0.into(), 0.into(), 3.into()])).unwrap();
    assert_eq!(line.kind(), Curve3Kind::Translation);
    assert!(line.translation_geometry().unwrap().origin.coincides_with(&origin).unwrap());
    assert!(matches!(Curve3::translation(origin.clone(), Vector3::zeros()), Err(GeometryError::DegenerateLine)));
    assert!(matches!(line.point_at(&Real::from(2).into()), Err(GeometryError::ParameterOutsideDomain)));
    let middle = line.point_at(&q(1, 2).into()).unwrap();
    assert!(middle.try_coordinates().is_none());
    assert_eq!(middle.compare_coordinate(&origin, Axis::X).unwrap(), Ordering::Equal);
    assert_eq!(middle.compare_coordinate(&origin, Axis::Y).unwrap(), Ordering::Equal);
    assert_eq!(middle.compare_linear_form(&Vector3::z(), &q(3, 2)).unwrap(), Ordering::Equal);
    let (left, right) = line.split_at(&q(1, 2)).unwrap();
    assert!(left.point_at(left.domain().end()).unwrap().coincides_with(&middle).unwrap());
    assert!(right.point_at(right.domain().start()).unwrap().coincides_with(&middle).unwrap());
    let reversed = line.reversed().unwrap();
    assert!(reversed.point_at(reversed.domain().end()).unwrap().coincides_with(&origin).unwrap());
    let mut builder = ModelBuilder::new();
    builder.vertex(origin).unwrap();
    builder.vertex(middle).unwrap();
    builder.curve(line).unwrap();
    let cold = replay(&builder.finish().unwrap());
    let geometry = cold.curves().next().unwrap();
    assert_eq!(geometry.geometry().kind(), Curve3Kind::Translation);
    geometry.geometry().bounds().unwrap();
    let reflected = replay(&cold.transformed(&Matrix4::from_row_major([
        (-2).into(), 1.into(), 0.into(), 5.into(),
        0.into(), 3.into(), 1.into(), (-2).into(),
        0.into(), 0.into(), 2.into(), 7.into(),
        0.into(), 0.into(), 0.into(), 1.into(),
    ])).unwrap());
    assert_eq!(reflected.curves().next().unwrap().geometry().kind(), Curve3Kind::Translation);
}

pub fn selected_profile_domains_retain_endpoints_and_projection() {
    let source = source();
    let pcurve = Pcurve::new(source.clone());
    let curve = lift(source);
    assert!(curve.domain().end().try_real().is_none());
    assert_eq!(curve.domain().start().compare(&pcurve.domain_start().unwrap()).unwrap(), Ordering::Equal);
    assert_eq!(curve.domain().end().compare(&pcurve.domain_end().unwrap()).unwrap(), Ordering::Equal);
    let endpoint = curve.point_at(curve.domain().end()).unwrap();
    assert!(endpoint.try_coordinates().is_none());
    assert_eq!(endpoint.compare_linear_form(&Vector3::z(), &Real::zero()).unwrap(), Ordering::Equal);
    assert!(matches!(curve.point_at(&Real::one().into()), Err(GeometryError::ParameterOutsideDomain)));
    assert!(matches!(curve.domain().represented_domain(), Err(GeometryError::UnrepresentableParameter)));
    curve.bounds().unwrap();
    let (left, right) = curve.split_at(&q(1, 2)).unwrap();
    assert_eq!(left.domain().end().compare(&q(1, 2).into()).unwrap(), Ordering::Equal);
    assert_eq!(right.domain().end().compare(curve.domain().end()).unwrap(), Ordering::Equal);
    assert!(left.point_at(left.domain().end()).unwrap().coincides_with(&right.point_at(right.domain().start()).unwrap()).unwrap());
    let plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
    let projected = plane.planar_pcurve(&curve).unwrap().unwrap();
    let (scale, offset) = projected.correspondence().affine_coefficients().unwrap();
    assert_eq!(scale, &Real::one());
    assert_eq!(offset, &Real::zero());
    assert!(projected.curve().end().coincides_with(&pcurve.curve().end()).unwrap());
    let extruded = Surface::extrusion(curve.clone(), Vector3::z()).unwrap();
    let SurfaceParameterDomain::Closed(range) = extruded.domain().u() else { panic!("finite profile chart"); };
    assert_eq!(range.end().compare(curve.domain().end()).unwrap(), Ordering::Equal);
    let sample = extruded.point_at(&Point2::new(q(1, 2), 3.into())).unwrap();
    assert_eq!(sample, Point3::new(2.into(), 2.into(), 3.into()));
}

pub fn selected_profile_domains_reverse_transform_and_replay() {
    let curve = lift(source());
    let reversed = curve.reversed().unwrap();
    assert!(reversed.domain().start().try_real().is_none());
    assert_eq!(reversed.domain().start().compare(&(-q(7, 8)).into()).unwrap(), Ordering::Greater);
    assert_eq!(reversed.domain().start().compare(&(-q(3, 4)).into()).unwrap(), Ordering::Less);
    let point = curve.point_at(curve.domain().end()).unwrap();
    assert!(point.coincides_with(&reversed.point_at(reversed.domain().start()).unwrap()).unwrap());
    let twice = reversed.reversed().unwrap();
    assert_eq!(twice.domain().end().compare(curve.domain().end()).unwrap(), Ordering::Equal);
    let transform = Matrix4::from_row_major([
        (-2).into(), 1.into(), 0.into(), 7.into(),
        0.into(), 3.into(), 1.into(), (-1).into(),
        0.into(), 0.into(), 2.into(), 5.into(),
        0.into(), 0.into(), 0.into(), 1.into(),
    ]);
    for source in [curve, reversed] {
        let plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let projected = plane.planar_pcurve(&source).unwrap().unwrap();
        let lifted = lift(projected.curve().clone());
        assert!(lifted.point_at(lifted.domain().start()).unwrap()
            .coincides_with(&source.point_at(source.domain().start()).unwrap()).unwrap());
        let mut builder = ModelBuilder::new();
        builder.vertex(source.point_at(source.domain().start()).unwrap()).unwrap();
        builder.vertex(source.point_at(source.domain().end()).unwrap()).unwrap();
        builder.curve(source.clone()).unwrap();
        let cold = replay(&builder.finish().unwrap());
        let restored = cold.curves().next().unwrap();
        assert_eq!(restored.geometry().domain().start().compare(source.domain().start()).unwrap(), Ordering::Equal);
        assert_eq!(restored.geometry().domain().end().compare(source.domain().end()).unwrap(), Ordering::Equal);
        let mapped = replay(&cold.transformed(&transform).unwrap());
        for (old, new) in cold.vertices().zip(mapped.vertices()) {
            assert!(old.point().transformed(&transform).unwrap().coincides_with(new.point()).unwrap());
        }
    }
}

pub fn clipped_parallel_cap() -> CurveRegion2 {
    let points = [Uv::from_values(0, -3), Uv::from_values(1, -3), Uv::from_values(1, 3), Uv::from_values(0, 3)];
    let path = CurvePath2::try_new((0..4).map(|i| Curve2::from(
        LineSeg2::try_new(points[i].clone(), points[(i + 1) % 4].clone()).unwrap(),
    )).collect()).unwrap();
    let clip = CurveRegion2::try_from_boundary_paths_with_loop_semantics(
        &[path], &[CurveRegionLoopRole::Material], &[FillRule::NonZero],
    ).unwrap();
    original::original_parallel_cap().boolean_region(&clip, BooleanOp::Intersection).unwrap()
}

pub fn full_clipped_parallel_cap_constructs_and_replays() {
    let region = clipped_parallel_cap();
    assert!(region.boundary_loops().iter().flat_map(|b| b.curves())
        .any(|curve| curve.parameter_endpoints().0.scalar().is_none()));
    let bodies = builder::extrude_curve_region(&region, Real::zero(), Real::from(3)).unwrap();
    assert_eq!(bodies.len(), 1);
    let restored = replay(bodies.model());
    for model in [bodies.model(), &restored] {
        let solid = model.solids().next().unwrap();
        for (point, expected) in [
            (Point3::new(q(1, 2), 0.into(), 1.into()), SolidPointLocation::Inside),
            (Point3::new(2.into(), 0.into(), 1.into()), SolidPointLocation::Outside),
            (Point3::new(0.into(), 0.into(), 1.into()), SolidPointLocation::Boundary),
        ] {
            assert_eq!(solid.classify_point(&point).unwrap(), expected);
        }
    }
}

pub fn selected_chord_charts_keep_original_boundary() {
    let region = clipped_parallel_cap();
    let mut changed = 0;
    for curve in region.boundary_loops().iter().flat_map(|b| b.curves()) {
        for source in [curve.clone(), curve.reversed().unwrap()] {
            let chart = source.scalar_chart().unwrap();
            assert_eq!(chart.source(), &source);
            let image = chart.curve();
            assert!(!image.parameter_domain().start().is_algebraic_chord());
            assert!(!image.parameter_domain().end().is_algebraic_chord());
            for (original, mapped) in [
                (source.parameter_endpoints().0, image.parameter_endpoints().0),
                (source.parameter_endpoints().1, image.parameter_endpoints().1),
            ] {
                assert_eq!(chart.parameter(original).unwrap().compare(mapped).unwrap(), Ordering::Equal);
                let uv = mapped.affine_point(Real::one(), Real::zero(), Real::zero(), Real::from(3)).unwrap();
                let u = uv.affine_form(Real::one(), Real::zero(), Real::zero()).parameter().unwrap();
                let v = uv.affine_form(Real::zero(), Real::one(), Real::zero()).parameter().unwrap();
                assert_eq!(u.compare(mapped).unwrap(), Ordering::Equal);
                assert_eq!(v.compare(&Real::from(3).into()).unwrap(), Ordering::Equal);
                assert_eq!(v.scalar(), Some(&Real::from(3)));
                assert!(source.point_at(original).unwrap().coincides_with(&image.point_at(mapped).unwrap()).unwrap());
            }
            if source.parameter_domain().start().is_algebraic_chord() {
                changed += 1;
                assert!(image.source_restriction().is_some());
            }
        }
    }
    assert_eq!(changed, 4);
}
