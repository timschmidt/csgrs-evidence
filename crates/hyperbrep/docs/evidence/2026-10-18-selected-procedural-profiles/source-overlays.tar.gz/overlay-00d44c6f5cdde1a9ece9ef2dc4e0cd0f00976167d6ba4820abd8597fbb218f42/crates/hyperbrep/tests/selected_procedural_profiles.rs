#[path = "support/selected_procedural_profiles.rs"]
mod acceptance;

#[test]
fn selected_profile_domains_retain_endpoints_and_projection() {
    acceptance::selected_profile_domains_retain_endpoints_and_projection();
}

#[test]
fn selected_profile_domains_reverse_transform_and_replay() {
    acceptance::selected_profile_domains_reverse_transform_and_replay();
}

#[test]
fn full_clipped_parallel_cap_constructs_and_replays() {
    acceptance::full_clipped_parallel_cap_constructs_and_replays();
}

#[test]
fn selected_chord_charts_keep_original_boundary() {
    acceptance::selected_chord_charts_keep_original_boundary();
}

#[test]
fn selected_origin_lines_retain_source_and_replay() {
    acceptance::selected_origin_lines_retain_source_and_replay();
}
