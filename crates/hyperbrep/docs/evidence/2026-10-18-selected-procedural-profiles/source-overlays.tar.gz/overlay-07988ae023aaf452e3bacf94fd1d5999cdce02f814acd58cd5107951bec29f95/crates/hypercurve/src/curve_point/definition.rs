//! Replayable source definitions, without serialized certainty claims.

use super::*;
use crate::{BezierParameter2, CurveParameter2, ExactCurveError, ExactCurveResult,
    CurveOperation2, CurveFamily2, RationalBezier2, BezierParallel2, Similarity2};

/// Source definition of an exact point. Selected parameters retain their
/// original authority. Unsupported constructions have no such view yet.
#[derive(Clone, Debug)]
pub enum CurvePointDefinition2 {
    /// Authored exact coordinates.
    Coordinates(Point2),
    /// A rational curve evaluated at a retained parameter.
    Rational { source: RationalBezier2, parameter: CurveParameter2 },
    /// A regular analytic parallel evaluated at a retained parameter.
    Parallel { source: BezierParallel2, parameter: CurveParameter2 },
    /// An exact similarity of a retained point.
    Similarity { source: CurvePoint2, transform: Similarity2 },
}

impl CurvePoint2 {
    /// Returns a checked source definition, without eliminating selected roots.
    /// Construction policies incompatible with strict replay remain blocked.
    pub fn definition(&self) -> ExactCurveResult<CurvePointDefinition2> {
        let blocked = || ExactCurveError::blocked(CurveOperation2::Evaluation,
            CurveFamily2::RationalBezier, UncertaintyReason::Unsupported);
        match &self.0 {
            CurvePointData2::Exact(point) => Ok(CurvePointDefinition2::Coordinates(point.clone())),
            CurvePointData2::Algebraic(point) => {
                let (source, parameter) = point.native_curve_evaluation().ok_or_else(blocked)?;
                Ok(CurvePointDefinition2::Rational { source: source.clone(), parameter: BezierParameter2::Algebraic(parameter.clone()).into() })
            }
            CurvePointData2::AnalyticParallel(point) => {
                let (source, parameter) = point.native_parallel_evaluation().ok_or_else(blocked)?;
                Ok(CurvePointDefinition2::Parallel { source: source.clone(), parameter })
            }
            CurvePointData2::Similarity(point) => {
                let (source, transform) = point.strict_definition().ok_or_else(blocked)?;
                Ok(CurvePointDefinition2::Similarity { source: source.clone(), transform: transform.clone() })
            }
            CurvePointData2::Endpoint(endpoint) => {
                let point = ExactCurveError::decided(CurveOperation2::Evaluation,
                    endpoint.resolve(&CurveContext::STRICT).map_err(|cause|
                        ExactCurveError::invalid_unattributed(CurveOperation2::Evaluation, cause))?)?
                    .ok_or_else(blocked)?;
                point.definition()
            }
            _ => Err(blocked()),
        }
    }
}

impl CurvePointDefinition2 {
    /// Replays the source with pole and regular-normal checks under strict
    /// predicates. The input definition carries no trusted validation flags.
    pub fn into_point(self) -> ExactCurveResult<CurvePoint2> {
        crate::policy::resolve_certified_operation(&CurveContext::STRICT, |policy| match self {
            Self::Coordinates(point) => Ok(point.into()),
            Self::Rational { source, parameter } => crate::curve::curve_evaluation::rational_point(
                &source, &parameter, CurveFamily2::RationalBezier, policy),
            Self::Parallel { source, parameter } => source.checked_native_point(&parameter, policy),
            Self::Similarity { source, transform } => {
                // Replaying the definition establishes its source under the
                // same strict policy; an arbitrary incompatible source cannot
                // acquire a stronger claim merely by being wrapped.
                source.definition()?.into_point()?;
                Ok(crate::BezierSimilarityPoint2::new(source, transform, policy).into())
            }
        }).map(crate::CurveOutcome::into_value)
    }
}
