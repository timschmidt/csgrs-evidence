# HyperBREP

Partial-depth plane/cylinder Booleans now admit piecewise prismatic shells from
complete native boundaries. The supported axial-shell domain includes thin
remaining layers, internal notches, holes, cold archive replay, exact similarities,
periodic seams and subsequent cuts/reconstruction/empty recovery. Shared topology,
oriented section winding and cap transitions are certified before publication;
unsupported surface arrangements remain typed failures. See the
[axial-shell admission record](docs/evidence/2026-10-17-axial-shells/README.md).

Native line/circle extrusion walls use plane/cylinder carriers. This intentionally
changes native archive and STEP output bytes. Certified prism images under a
supported axial shear retain exact extrusion carriers; no fitting or tolerance
is introduced. Numerical certainty, manifold validity and format fidelity remain
separate claims. General affine images of partial-depth analytic shells and full
work/heap/cancellation bounds remain open.

Hyper-native exact boundary representation for CAD.

HyperBREP uses `hyperreal::Real` as its only authoritative scalar and familiar
CAD vocabulary: vertices, edges, edge uses, wires, faces, shells, solids,
`Curve3`, `Pcurve`, `Surface`, and `Model`.

The source model is an immutable typed arena. Geometry and topology are staged
through `ModelBuilder`; invalid references, disconnected wires, mismatched edge
endpoints, and unsupported edge/pcurve/surface agreement cannot be published as
a `Model`.

Public topology is borrowed through `VertexRef`, `EdgeRef`, `FaceRef`,
`SolidRef` and corresponding references for the other entity families.
References retain their model revision through traversal. Cloned models share
one revision; transforms, committed edits and decoded models publish new
revisions. Builders issue scoped keys and reject foreign keys before mutation.
Constructors and Booleans return owned `BodySet` or `SheetSet` selections.
Typed arena positions in errors are diagnostic labels and cannot resolve a
record through the public API.

`ModelBuilder::validate_edge_image` checks a staged edge, candidate pcurve,
explicit correspondence and surface without adding an edge use. It invokes
the same strict whole-curve proof as face construction. This lets exchange
code check alternate source representations before assigning face-local
geometry; success certifies image agreement, not a complete model or source
fidelity. See [exact image agreement](docs/ARCHITECTURE.md#exact-image-agreement).

`boolean::{union, intersection, difference, symmetric_difference}` consume
`&BodySet` and return `BodySet`, so empty and multi-body outputs feed directly
into further operations. `BodySet::empty()` starts an accumulation;
`BodySet::from_solid(solid)` selects an already validated solid while sharing
its model. A selection denotes the regularized union of its bodies, even when
they overlap. Its `len()` counts selected bodies; summing individual volumes
does not measure an overlapping union. Nontrivial Booleans normalize their
results through the same strict native solid kernels. See the
[composition contract and evidence](docs/evidence/2026-10-15-body-set/admission.md).
General surface arrangements, full resource bounds and durable operation
receipts remain open under the [development plan](docs/DEVELOPMENT_PLAN.md).

Selected Bézier profile restrictions with proved exact native images can feed
the planar-face and extrusion builders. Quadratic selected endpoints now permit
the original parabola difference/XOR profiles, including reversed authoring,
affine maps, holes, native replay and repeated supported slab cuts/restoration.
Hypercurve owns the root, complete subcurve and area proofs; BREP retains
whole-boundary validation. Different prism profiles require exact material
intersection and component proofs before an interval continuation can retain
their original solids. Irrational STEP Cartesian vertices remain explicit
encoding errors. Native geometry replay preserves the represented set; complete
authoring-history persistence and general retained spatial carriers remain open.

`OperationContext::strict(WorkBudget { refinements, promotions })` runs a
synchronous batch through `context.evaluate(|| ...)`. Nested BREP, Hypercurve
and Hypersolve calls share the admitted solver work. The returned
`BudgetOutcome` separates resource exhaustion from the callback's domain
result and reports actual usage. These counters cover instrumented root
refinements and algebraic promotions; they do not bound all geometry work,
scalar precision, time or memory. Scopes do not propagate to worker threads
or futures. See [operation scopes](docs/ARCHITECTURE.md#operation-scopes).

Archive input uses `RawModel::from_json(json, &ArchiveLimits::default())` or
caller-selected byte, nesting, token, record, degree, geometry-element and
topology-reference limits. Exceeding a limit returns a typed resource error
before exact-scalar deserialization. `RawModel::validate` then
reconstructs geometry proofs. Input limits do not bound scalar reconstruction
or geometric validation; see the [archive contract](docs/SELECTED_ARCHIVE.md).

Native archives also retain procedural analytic-parallel pcurves: polynomial
or homogeneous rational sources, signed distance, selected ranges and traversal.
Replay rechecks source regularity and preserves subsequent planar subdivision
and region queries. `Curve3::planar_image` retains a planar source in an injective
affine plane frame, with a unit spatial chart mapped to represented source
endpoints. Nonlinear parallel caps now feed planar faces, region/path extrusion,
native replay, edge splits, affine transforms and supported slab Booleans.
Whole source/frame/map proofs validate edge images. Scalar queries reuse the
planar evaluator. Selected spatial points retain their planar source and root;
frame comparisons, bounds, transforms and native replay consume that evidence
without independent coordinates. Selected edge splits preserve cold replay and
supported slab Booleans. Selected endpoints of a newly authored spatial carrier,
general surface intersections, metrics and STEP encodings remain typed. See the
[planar lift admission](docs/evidence/2026-10-18-planar-curve-lift/README.md).

Finite curve/plane queries retain `Parameter` and `GeometricPoint3` in
`CurveSurfacePoint`. Native rational Bézier and NURBS queries reuse the planar
owner's complete root authority for higher-degree equations; planar images
reduce the target plane through their exact frame. `CurveSurfaceContactKind`
distinguishes simple roots, repeated roots and finite boundary contacts without
claiming an integer multiplicity or a global crossing direction at spline joints.
`CurveSurfaceIntersection::Components` retains mixed isolated contacts and
maximal closed `ParameterRange` overlaps, including collapsed spans. The original
source parameters feed edge splitting, selected-point predicates and native
replay. Planar subcurve queries and bounds inspect the consumed source interval;
a pole outside it does not invalidate the finite subcurve. Coefficient-only
surface consumers and STEP still report typed representation limits. This is a
direct API migration with no compatibility adapter; see the
[finite contact admission](docs/evidence/2026-10-18-retained-plane-contacts/README.md).

## Exactness contract

- Authored coordinates, coefficients, domains, weights, knots, and transforms
  use `Real`. Inverse curve queries return opaque `Parameter` values that can
  retain selected algebraic roots without a stored `Real` view.
- `Curve3::point_at(&Parameter)` returns `GeometricPoint3`. Lines and rational
  curves and retained planar lifts retain selected images for exact comparison,
  conservative bounds and
  invertible affine transforms. `try_coordinates` borrows stored coordinates;
  an unavailable view does not make the point approximate. Vertices store these
  points, and `ParameterRange` retains selected edge trims. `EdgeRef::split`
  partitions all incident uses while retaining their parameter correspondence.
  Archive replay covers selected sheet fixtures, subdivided cuboids and cylinder
  axial edges. General selected surface/contact images remain open; see the
  [archive contract](docs/SELECTED_ARCHIVE.md) for the tested boundary.
- Native cylinder validation admits rectangular side partitions covering exactly
  one angular period, including a single side face with a shared seam, unequal
  widths and axial T-junctions. An indexed sweep checks multiplicity one without
  allocating the angular–axial grid. Caps, orientation, incidence and complete
  edge images still require independent exact checks. See the
  [periodic-cylinder evidence](docs/evidence/2026-10-15-periodic-cylinder/README.md).
- Full-period circular and elliptic edges may share one endpoint vertex.
  Circular caps can use one edge, with distinct cap/side uses and seam parameter
  endpoints retained through subdivision and archive replay. Other closed
  families require additional regularity proofs. See the
  [closed-edge contract](docs/ARCHITECTURE.md#closed-edges-and-periodic-seam-uses).
- Geometric equality and ordering use Hyperlimit predicates, not structural
  `PartialEq` or an epsilon.
- An unresolved predicate is a typed error, never `false`.
- Numerical methods may propose candidates but cannot author topology without
  exact certification.
- Tessellations and other approximate outputs are derived data, not source
  BREP truth.

See
[`docs/architecture/0001-exact-decision-contract.md`](docs/architecture/0001-exact-decision-contract.md)
and
[`docs/architecture/0002-model-ownership-and-validity.md`](docs/architecture/0002-model-ownership-and-validity.md)
for the binding design decisions.

## Current exact vertical slice

The clean-break implementation currently provides:

- exact line, circular/elliptic arc, rational Bézier, and finite non-periodic
  NURBS `Curve3` carriers;
- arbitrary positive-order exact derivatives, certified retained parameter
  location, NURBS knot-insertion subdivision, supported reversal, and
  conservative exact curve bounds;
- retained spatial curve images with strict coordinate order/coincidence,
  shared source evidence and explicit unsupported selected angular evaluation;
- parameterized planes plus sphere, cylinder, cone, and torus carriers with
  exact domains, evaluation, and partial derivatives;
- exact extrusion, revolution, tensor-product rational Bézier, and
  tensor-product NURBS surface carriers;
- Hypercurve-owned pcurves;
- private typed-ID arenas and retained adjacency;
- exact edge endpoint validation;
- per-edge-use exact parameter correspondence with affine and native
  directed-angular-sweep relations;
- certified line/plane, circular-arc/plane, axial-line/cylinder,
  circular-edge/cylinder, generator-or-circle/cone, circular-edge/torus, and
  line/circle/ellipse/rational-Bézier/NURBS profile-image agreement on extrusion
  surfaces over complete parameter intervals; exact
  line/circle/rational-Bézier/NURBS meridian and latitude-circle agreement on
  revolution surfaces; plus rational Bézier/NURBS iso-boundary agreement on
  tensor surfaces;
- certified planar loop winding, inner-wire nesting, and exact positive shell
  volume;
- connected closed wires, connected shells, closed-manifold solid checks, and
  certified inward z-prism void shells;
- exact shared-edge `builder::cuboid`, native `builder::cylinder`,
  boundaryless-face `builder::sphere`, truncated `builder::cone_frustum`, and
  periodic-patch `builder::torus` constructors;
- native `builder::revolve` for exact simple off-axis radial/axial polygons,
  with four identity-stitched angular cells per profile edge;
- native `builder::{revolve_contour, revolve_contour_region}` for exact
  off-axis line/arc profiles and cavities; circular profile meridians remain
  native, exact contour first moments drive Pappus volume, and curved face
  area is integrated analytically;
- native `builder::{revolve_path, revolve_path_region}` for exact closed
  `CurvePath2` profiles and cavities; authored Bézier, polynomial B-spline,
  finite NURBS, and single-carrier periodic spline profiles remain native;
  periodic inputs are partitioned into exact clamped knot-span meridians,
  exact span injectivity and pairwise intersections certify simplicity,
  polynomial-equivalent, rational-quadratic, exact homogeneous degree-elevated
  conic, arbitrary-degree at-most-quadratic-weight, and nonuniform rational
  line-image moments drive exact volume; monotone rational Bézier/NURBS line
  images also use their parameterization-independent exact revolution area.
  Arbitrary-degree weight polynomials
  also use exact multiplicity-aware partial fractions when rational-root
  deflation leaves linear factors, a power of one irreducible quadratic, or
  two irreducible quadratics; other residual factors remain explicit
  unsupported measurements. Transverse clipping
  decomposes multi-span NURBS meridians exactly and deduplicates contacts at
  shared knot seams;
- exact `builder::revolve_region` cavities as inward periodic shells with
  first-moment subtraction and radial/profile material classification;
- exact `builder::sphere_with_voids` construction with inward complete-sphere
  cavities, strict nesting, exact volume, and material classification;
- validated open-shell `builder::{rational_bezier_patch, nurbs_patch}`
  constructors with native spline boundary curves and exact parameter maps;
- validated open-shell `builder::planar_face` construction from exact
  `CurvePath2` outer and hole loops in any nondegenerate authored plane frame,
  with Hypercurve-owned simplicity/nesting proof and exact persistent
  promotion of conic and polynomial spline boundaries;
- validated open-shell `builder::extrusion_patch` construction for any exact
  profile family, retaining the profile's native `u` domain and strictly
  ordered finite sweep-coefficient bounds without direct arena manipulation;
- validated open-shell `builder::revolution_patch` construction with native
  meridian domains, exact latitude circles, complete profile/axis-clearance
  certification, and an explicit sub-period angular contract so complete
  revolutions use periodic subdivision;
- exact face area for affine-image rational Bézier and NURBS tensor patches,
  certified from the complete Bernstein/Greville control lattice without
  tessellation; constant weights support arbitrary validated trims, while a
  rank-one positive weight matrix supports a complete patch through its two
  independent exact rational axis reparameterizations. The same complete
  affine-image certificate lets a line-bounded tensor face remain in its
  authored family while serving as an exact prism cap; shell reasoning uses a
  derived canonical plane, never a replacement carrier or sampled fit;
- closed multi-edge rational Bézier/NURBS planar boundaries decompose into
  exact native spans, elevate homogeneously to one degree, and concatenate as
  one closed NURBS trace before topology authorship; this includes circular
  boundaries and elliptic spatial images under skew frames;
- degree-one `2×2` affine rational Bézier and NURBS tensor images with
  nonconstant positive rank-one weights pull rational Bézier boundaries back
  through two exact Möbius inverses and one homogeneous Bernstein denominator
  product; NURBS results retain arbitrary authored active knot domains,
  complete parameterization validation rejects interior-control forgeries,
  and higher-degree projective inverses remain explicitly
  algebraic/unsupported;
- exact extrusion-face area for line profiles, circular profiles swept normal
  to their plane, and rectangular trims of certified planar rational
  Bézier/NURBS profiles whose positive-weight control projections are
  transverse-monotone, including projectively parameterized line images;
  other variable-speed curved profiles are explicit unsupported measurements
  instead of being sampled or assigned a start-derivative scale;
- `builder::tensor_patch_shell` for mixed collections of exact rational
  Bézier/NURBS patch specifications; complete projectively identical
  boundaries are identity-stitched across faces, including reversed traversal
  and globally scaled weights, while unmatched boundaries remain open;
- exact concave-simple-polygon `builder::extrude` plus native line/arc
  `builder::{extrude_contour, extrude_contour_regions}` construction with
  holes and disconnected solids;
- exact `builder::{extrude_path, extrude_path_region, extrude_path_regions}`
  construction from native `CurvePath2` line, circle, rational Bézier, and
  NURBS boundaries, including spline-bounded through-holes and exact material
  classification. A represented integral supplies exact volume; its absence
  returns `UnsupportedMeasurement` from the query without preventing admission
  of a prism whose topology and orientation are independently certified;
- `builder::extrude_curve_region` consumes a regularized `CurveRegion2`
  directly, retaining its component proof and certified native line/arc view.
  Round stroke profiles keep native circular sides through exact area queries,
  STEP exchange and subsequent modeling. Material components, holes, islands
  and canonical empty geometry use the same native construction authority;
  height ordering is checked even for empty input. Native positive rational
  profiles with no represented area integral retain classification, affine
  transforms, cold replay and supported same-profile slab cuts. See the
  [measurement admission evidence](docs/evidence/2026-10-18-measurement-admission/README.md).
  Errors while attempting an available integral still propagate; general
  integration and non-native selected spatial boundaries remain open;
- exact affine `builder::{sweep, sweep_region}` for polygonal linear-path
  sweeps in an explicit model-space profile frame, including through-holes
  and shear without a hidden moving-frame policy;
- exact `builder::{sweep_curve, sweep_curve_region}` for fixed-frame polygon
  or through-hole region sweeps along rational Bézier paths whose normalized
  profile-plane progress is proven affine and strictly positive by Bernstein
  coefficient identity; cap holes remain inner wires in one genus shell,
  lateral curvature is unrestricted, side faces are native tensor rational
  Bézier translation surfaces, and no moving frame or sampling policy is
  inferred;
- exact `builder::{sweep_moving_frame, sweep_moving_frame_region}` for polygon
  or through-hole region sweeps through an explicit shared-weight rational
  Bézier origin/axis frame; complete Bernstein identities prove parallel
  section planes, positive affine progress, and either constant rational or
  strictly positive polynomial oriented section area; the latter is integrated
  exactly, retaining authored shear and taper without inferred Frenet
  transport or sampling;
- exact multi-section `builder::loft` for vertex-corresponding polygons:
  every span independently retains planar homothetic sides or certifies convex
  non-homothetic interpolation with native bilinear tensor patches;
  intermediate rings are identity-shared C⁰ seams, and piecewise quadratic
  section-area integration supplies exact volume without inferred
  correspondence or continuity;
- exact region, multi-region, through-hole, and closed-cavity extrusion
  construction;
- retained exact bounds plus exact planar/spherical/cylindrical/conical/
  toroidal/extrusion/revolution face-area and
  affine-prism/sphere/cylinder/frustum/full-or-planar-capped-torus/revolution
  solid-volume queries;
- cached exact solid point classification plus line/plane, plane/plane,
  circular-or-elliptic-arc/plane, circular-arc/sphere,
  transverse-circular-arc/cylinder-or-cone-or-torus, line/sphere, line/cylinder,
  line/cone, plane/sphere, and sphere/sphere intersections, plus certified
  authored-axis transverse plane/revolution profile sections,
  transverse plane/cone/torus and
  perpendicular/oblique/axial-parallel plane/cylinder cuts,
  parallel-cylinder intersections, coaxial sphere/cylinder,
  sphere/cone/torus, cylinder/cone/torus, cone/cone-or-torus,
  line/rational-Bézier/NURBS revolution/revolution, and torus/torus
  intersections
  with retained two-surface pcurves when their authored frames align or mirror,
  with retained multiplicity, overlaps, coincidence, tangent points, lines,
  circles, exact ellipse curves, and typed mixed-dimensional component sets;
- topology-safe exact family-preserving transforms, including certified
  analytic similarities and reflections with scaled lengths, axial charts,
  selected parameters and solid certificates; arbitrary affine line prisms
  retain their existing domain;
- copy-on-write stable-ID geometry/topology replacement transactions with
  complete validation on commit;
- exact canonical edge splitting with incident pcurve subdivision, native
  root-lineage angular subdivision, forward/reversed wire repair, and full
  certificate-preserving revalidation without nested rational-projection
  expression growth;
- exact planar face splitting along identity-shared line chords, including
  certified hole reassignment, owning-shell repair, and cap-region
  recertification after subdivision;
- exact curve-driven planar splitting that attaches retained intersection-line
  endpoints to existing boundary vertices or splits crossed canonical edges at
  their represented `Real` parameters before identity sharing;
- deterministic exact multi-trace planar arrangement and partitioning,
  independent of caller order and trace direction, with identity-shared
  crossing vertices and explicit duplicate, positive-length-overlap,
  ambiguous-region, and unsupported-curve outcomes;
- deterministic mixed straight/retained-curve face arrangements with exact
  pcurve crossing atomization, descendant-region routing, and wholly interior
  closed curves authored as identity-shared outer/inner wire pairs; nested
  closed loops and boundary-attached traces are invariant under input order
  and direction;
- regularized `boolean::{union, intersection, difference}` for certified exact
  z-prisms, preserving line/arc boundaries across disconnected and holed
  outputs such as native-cylinder lenses and annuli, with explicit empty,
  unsupported-operand, incompatible-slab, and unresolved outcomes;
- arbitrary-orientation parallel/antiparallel cylinder Booleans through an
  exact cylinder-local frame, including coaxial axial-interval regularization
  and native arc-bounded radial results;
- arbitrary-orientation coincident cone-frustum Booleans through exact
  slant-interval regularization, including two-solid interior cuts;
- exact identical-torus Booleans across equivalent periodic frames, including
  reversed carrier axes;
- exact coaxial torus/torus carrier intersection by reducing both ring-torus
  meridians to native profile circles, distinguishing coincidence, separation,
  tangency, and two latitude circles without sampling. Matching and mirrored
  authored frames retain exact constant-latitude pcurves on both carriers;
  bounded periodic grids clip both circles into eight replayable patch traces
  and partition both shells without changing exact volume;
- exact coaxial sphere/torus, cylinder/torus, and cone/torus relations through
  one `Real`-only meridian primitive: circle/circle, vertical-line/circle, and
  nonnegative-ray/circle solves distinguish separation, tangency, and two
  native latitude circles. Matching or mirrored authored frames retain both
  pcurves, and bounded sphere, cylinder, or frustum graphs partition both
  operands, replay, persist, and preserve exact volume;
- exact transverse torus/slab intersection through retained concentric
  latitudes, one or two native annular caps, periodic parameter-cell
  certification, and analytic band measurement/classification;
- exact axis-containing plane/ring-torus carrier intersection as two native
  meridian circles with one authoritative spatial parameter and exact pcurves
  on both carriers. Parallel-to-axis planes retain exact outer tangency and
  certify strict outer separation, while an oblique axial cutter partitions
  all periodic torus cells plus both planar loops without tolerance sewing.
  Standard intersection and torus-minus-cutter difference publish the two
  complementary half-tori through one closed longitude-region certificate,
  with exact area, volume, classification, transforms, and persistence;
- exact coaxial polygonal-revolution Booleans through Hypercurve radial/axial
  regions, including reversed axes, disconnected outputs, and retained
  toroidal-profile cavities;
- strict certified-AABB disjoint Booleans across every current single-solid
  analytic family, with exact full-arena remapping for multi-solid unions;
- equal, strictly contained, and strictly partially overlapping sphere
  Booleans, including exact spherical-cavity difference and two-face periodic
  cap shells stitched on the exact intersection circle;
- exact authored-axis sphere/slab clipping through retained latitude pcurves,
  first-cut whole-sphere partitioning, native one-cap or two-cap spherical
  regions, and analytic segment measurement/classification;
- retained solid intersection graphs with certified per-face broad-phase
  rejection, exact analytic carrier relations, and explicit unsupported-pair
  evidence, plus exact two-face trim clipping for transverse planar carrier
  lines and exact rational-conic clipping against planar face regions, as the
  common input to general intersection-driven splitting; mixed point/curve
  relations clip each dimension independently and retain combined exact trim
  evidence when both survive. Whole boundaryless faces preserve retained point
  and two-pcurve evidence instead of collapsing it to a generic complete
  carrier marker, allowing authored-axis sphere/sphere circles to partition
  both spheres directly into exact caps. Retained line, rational-Bézier, and NURBS
  fragments can be grouped by source face and
  applied through `partition_first_faces` or `partition_second_faces` as
  deterministic validated partitions on either operand. Unsupported transfer
  is a typed error and never silently skips a known exact trace;
- partial coplanar `SurfaceRegion` relations transfer a line-bounded planar
  face boundary onto a contained affine-image rational Bézier or NURBS tensor
  through exact auxiliary-plane sections. The tensor's native rational graph
  pcurves remain authoritative in either graph operand order; no inverse
  fitting or planar replacement is used. When one boundary support crosses
  tensor-face holes, its disjoint material fragments author one exact
  boundary-component bridge cycle. Crossed components compact into the two
  descendant outer wires, surplus wire slots are retired through an explicit
  old-to-new ID map, and every bridge edge remains identity-shared.
  Constant-weight affine tensor carriers also invert rational Bézier and NURBS
  region boundaries directly through a certified native-parameter plane,
  retaining curved pcurves without fitting. Unrepresented inverse images remain
  an explicit unsupported partition;
- perpendicular plane/cylinder graph cuts retain one authoritative spatial
  latitude circle plus exact pcurves on both carriers: native angular-sweep
  correspondence on the planar circle and an affine constant-height line in
  cylinder parameters. Quarter traces coalesce into a certified closed planar
  loop, cylinder parameter rectangles tile exactly across axial subdivision,
  and axial slab clipping survives stitching, rigid orientation, reflection,
  operand reversal, and byte-identical persistence with exact `πr²h` volume;
- authored-frame-aligned coaxial sphere/cylinder cuts retain both exact
  latitude pcurves, clip each circle across the four bounded cylinder patches,
  coalesce those fragments back into one periodic sphere trace, and partition
  both complete carriers. Standard intersection stitches two spherical caps
  and the central cylindrical band with exact area, volume, classification,
  transforms, operand reversal, and byte-identical replay. Complementary
  difference stitches the periodic two-loop spherical band to the inward
  cylinder band as one exact genus-one solid with native area, volume,
  classification, transforms, and replay. Opposite cylinder-minus-sphere
  difference retains the two disconnected capped-cylinder ends, each with a
  native reversed spherical cap and exact exclusion-aware queries. Regular
  union joins the spherical band to both capped cylinder ends as one exact
  shell with true union classification and no false primitive profile.
  Strict cross-family containment regularizes the complete Boolean truth
  table in either direction; the nontrivial difference retains the contained
  finite cylinder or sphere as one native inward void with exact queries.
  The exact clearance fast path precedes carrier intersection, so strictly
  contained off-axis pairs do not pay for or depend on an unsupported
  sphere/cylinder surface relation. Finite coaxial intervals that cross only
  one sphere latitude retain the native one-cap/one-band/one-disk topology
  for intersection, union, and either directed difference, with one exact
  finite-cylinder region certificate rather than symmetric-clip assumptions;
- transverse plane/cone cuts use the same two-pcurve latitude abstraction,
  with cone slant parameter retained exactly. Frustum side descendants prove
  the same no-gap/no-overlap parameter grid, so slab clips remain native conic
  solids with exact frustum volume. The z-prism fast path now requires a real
  translation-family certificate and cannot misclassify a two-layer frustum
  from its vertices alone;
- authored-axis transverse plane/revolution cuts intersect the exact meridian
  profile first, then orbit every isolated positive-radius contact into one
  authoritative spatial circle with exact planar and constant-profile
  pcurves. Exact profile-range grids recertify the retained revolution sides;
  planar annular caps reconstruct the missing radial profile segments, so a
  revolution/slab intersection survives standard stitching with exact area,
  volume, classification, operand reversal, and persistence;
- axis-containing plane/cone cuts retain two native lower-bounded generator
  rays. Each ray owns one authoritative spatial `Real` parameter plus exact
  affine parameter rays on both carriers; face trimming clamps that parameter
  at the apex and publishes only finite two-pcurve fragments. An axial cuboid
  cutter partitions both operands and standard intersection or complementary
  difference publishes either longitudinal half-frustum with exact area,
  volume, halfspace classification, transforms, profile isolation, and
  persistence;
- all-face retained-graph selection through `select_first_faces` and
  `select_second_faces`, with exact pcurve-region witnesses for trimmed planar,
  analytic, and tensor carriers plus canonical parameter-domain witnesses for
  boundaryless faces; every face receives an operation-aware action or a typed
  ownership error;
- all-face selected-result transfer through `stitch_selected_faces`, preserving
  source-local curved edge identity and matching cross-operand edges only by
  exact restricted `Curve3` evidence. Whole spherical faces and intact curved
  shells transfer natively; exact affine Bézier lines and coplanar tensor
  carriers regularize to canonical line/plane geometry with rebuilt projected
  pcurves before ordinary shell validation. Planar faces in mixed curved shells
  likewise rebuild line pcurves from the authoritative spatial edge and plane
  frame instead of persisting arrangement-expression history. Subdivided
  curve-sweep connectors and active tensor subrectangles also recertify exact
  transverse path clips;
- `boolean::intersect_faces` as the same exact carrier-and-trim primitive for
  arbitrary validated faces, including faces in open shells; finite tensor
  iso-curves and plane/extrusion sections therefore do not require fabricated
  solid ownership before both pcurves can be clipped and an exact spatial
  subcurve published;
- exact coincident-plane support arrangements, oriented material-side
  ownership, and selected-face identity stitching for planar union,
  intersection, and difference, including reversed face-local pcurves,
  cross-operand edge-domain remapping, disconnected results, and fully
  revalidated prism-family shells; the standard `union`, `intersection`, and
  `difference` entry points use this route whenever the faster world-z prism
  specialization cannot certify the operands or result;
- an exact convex planar shell fast certificate based on convex line-face
  loops and oriented half-spaces, plus a general straight-planar certificate
  that compares every coincident face region, boundary segment, and transverse
  face-line material interval exactly; this publishes concave non-prismatic
  skew union and difference results, assigns contained inward planar
  components as exact void shells, rejects non-manifold line or point
  contacts, and survives untrusted persistence replay;
- deterministic exact JSON for every current `Curve3` and `Surface` carrier,
  plus native line/circular-arc and rational-Bézier pcurves, through an
  untrusted, fully
  revalidated `RawModel`;
- exact plane intersection for linear-extrusion rational Bézier and
  degree-1-v NURBS tensor patches when the plane selects one bounded native
  iso-curve, plus exact non-isoparametric plane sections of rational Bézier
  and NURBS translation tensors linear in either parameter axis when every
  rational graph coefficient is certified inside the bounded patch; the native
  spatial spline and exact rational graph pcurve are retained without fitting.
  Any positive-weight `2×2` rational Bézier patch, or equivalent degree-one
  `2×2` NURBS patch over arbitrary active knot domains, additionally reduces
  the homogeneous plane numerator to an exact rational-quadratic parameter
  graph and composes it with the weighted surface into an exact
  rational-quartic spatial curve. NURBS pcurves retain authored coordinates;
  neither path samples or fits.
  Exact roots against both tensor boundaries and every graph-denominator pole
  partition sign-changing relations into one or more bounded retained
  branches. Common numerator/denominator roots factor into native crossing
  iso-lines, while sign-definite zero sets return exact boundary iso-lines or
  one/multiple isolated corner points. A complete zero hull returns
  `ContainedSurface` with the exact bounded operand instead of being
  misreported as coincidence or collapsed to a curve result. Face queries
  project the contained face's exact oriented boundary into plane parameters
  and retain the full, partial, holed, or empty overlap as a native
  `CurveRegion2`. An exact region-difference proof records complete contained
  face coverage; certified straight boundary images then become deterministic
  support traces for plane-face partitioning, while partial tensor-side
  partition remains explicit until inverse pcurves are representable;
- exact `Surface::iso_curve` extraction in either tensor direction and
  `FaceRef::split_by_surface_curve` transfer for one retained rational
  Bézier/NURBS iso-curve or complete rational-Bézier or NURBS
  translation-tensor graph sections in either axis, plus complete or clipped
  weighted bilinear rational-Bézier graph sections, including bounded
  pole-separated branches and factorized crossing iso-lines; full homogeneous
  controls, native NURBS domains and knots, and exact rational-Bézier or
  multi-span NURBS graph pcurves,
  curved-loop simplicity, same-boundary two-edge pockets, and orientation are
  recertified, interior endpoints split canonical boundary edges, the new curve
  is identity-shared by both descendants, and the complete open shell is
  revalidated before publication; `FaceRef::split_by_surface_curves`
  applies every retained fragment with an explicit first/second operand
  selector, exact endpoint ordering, deterministic descendant selection, and
  caller-order-independent topology; represented transverse pcurve contacts
  are atomized through Hypercurve's certified curve-intersection evidence,
  while overlaps and unresolved algebraic contacts remain explicit;
- topology-derived curve-sweep certification that cancels internal edges
  across coplanar cap descendants, proves each rational-tensor side group
  tiles its complete exact unit parameter boundary, recovers the authored
  translated path/profile from current topology, and therefore preserves
  volume, classification, and untrusted replay after exact cap-edge,
  cap-face, and tensor-face subdivision;
- exact plane/extrusion-surface intersection as a projected native
  line/rational Bézier/NURBS curve for transverse extrusion directions, or
  exact lifted lines for supported parallel profile contacts; materializable
  retained line/rational-Bézier/NURBS pcurves are clipped in both face regions
  and mapped back to exact `Curve3` subcurves in the intersection graph;
  native finite fragments retain both clipped pcurves and compose exact affine
  parameter maps when a rational Bézier subcurve normalizes to `[0,1]` but a
  NURBS subcurve keeps its native knot interval;
- optional `tessellation` integration with two deliberately separate outputs:
  exact oriented HyperTRI triangulation for validated line-bounded planar
  faces, and explicitly lossy chordal output for line-trimmed rational
  Bézier/NURBS faces under a uniform parameter-subdivision policy; chordal
  artifacts retain every exact `Real` parameter and source-surface image and
  certify only exact vertex incidence, never an unproved interior error bound;
- immutable `Arc`-shared `Model` values.

The implementation intentionally rejects combinations whose proof path has not
landed yet. The [development plan](docs/DEVELOPMENT_PLAN.md) specifies the
remaining kernel, modeling, STEP, persistence, and downstream integration work.
The accompanying [repository audit](docs/REPOSITORY_AUDIT.md) records the
implementation baseline and external reference findings.
The [algorithm research](docs/ALGORITHM_RESEARCH.md) documents feasibility,
source assumptions, prototype gates and performance experiments for that plan.
The [implementation ledger](docs/IMPLEMENTATION_STATUS.json) tracks work
packages, landed increments, verification and the remaining capability gaps.

The downstream [HyperBRep IO crate](../hyperbrep-io/README.md) provides bounded
Part 21 syntax, strict unit-aware faceted/selected analytic import, and exact
faceted or analytic geometry export. Planar/cylindrical/ring-torus faces with line/circle
boundaries retain explicit topology and source parameter maps; native borrowed
circle/cylinder/torus views supply exact carrier data to the writer. Holes, repeated
body occurrences, edits and reflected models remain explicit.
[Its mapping contract](../hyperbrep-io/docs/STEP_MAPPING.md) records the admitted
domain, output representability and loss model. Other analytic/spline families,
voids and whole-document/assembly mapping remain open. Native analytic
similarities now support exact physical scaling before export, including
millimetre/inch workflows; output unit selection remains a separate operation.
See the [similarity contract](docs/ARCHITECTURE.md#analytic-similarity-transport)
for chart restrictions and [evidence](docs/evidence/2026-10-16-analytic-similarity/README.md).
Geometry exchange does not replace native archival replay.

Seam-aligned axial and longitudinal torus halves and longitudinal cone-frustum
halves now complete through strict Booleans, exact similarities, edge splitting,
and untrusted archive replay. Existing boundary traces retain complete overlap
and source-revision evidence through `FaceTracePartitionRef::boundary()`.
The [seam-cut contract](docs/ARCHITECTURE.md#seam-aligned-analytic-cuts) and
[evidence](docs/evidence/2026-10-16-seam-cuts/README.md) delimit this domain.
The same halves also support recut intersection in both orders, subtraction to
canonical empty followed by recovery, and union of complementary halves in both
orders. Nine original configurations and 54 exact similarity configurations
check 126 continuation outputs, including independent exact measures,
classification and split/transform/archive reuse. Public
`FacePairTrim::CoincidentFaces` retains both surface charts; circular boundary
no-ops expose native overlap evidence through
`BoundaryTraceOverlapRef::native_overlap()`. See the
[repeated-composition contract](docs/ARCHITECTURE.md#repeated-curved-composition)
and [evidence](docs/evidence/2026-10-16-curved-coplanar/README.md).
Quarter and band continuations now have a focused acceptance corpus: torus
axial/longitudinal quarters, cone-frustum longitudinal quarters, and axial bands
of longitudinal torus/cone halves. Five original and 30 exact similarity
configurations check intersection in both orders, subtraction, complementary
reconstruction, canonical empty results, independent measures and classification,
subdivision and untrusted replay. Public annular face partitions retain the
source trace indices and model revisions. The
[sector contract](docs/ARCHITECTURE.md#analytic-sector-and-band-continuation)
and [evidence](docs/evidence/2026-10-16-sector-cuts/README.md) state the coverage.
Ring-torus STEP exchange now covers exact latitude/meridian boundaries in the
named whole/half/quarter and rational-band corpus. Both angular coordinates,
periodic lifts, source maps and strict failures remain explicit;
general Boolean closure remains open. See the
[torus exchange admission record](docs/evidence/2026-10-16-torus-exchange/README.md).
Rationally rotated complementary torus cuts also reconstruct in both operand
orders. The full-size acceptance workflows continue through two edge-split,
archive-reload, recut and empty-recovery cycles, checking exact measures,
paired incidence and near-boundary points. Shared scalar rounding and
function-congruence proofs preserve the cold replay contract; see the
[continuation record](docs/evidence/2026-10-17-curved-continuation/README.md).
Rationally rotated cone-frustum cuts also complete the axial-band workflow
and complementary reconstruction in both operand orders. Each runs two further
split/reload/recut/reunion/empty-recovery cycles with independent exact measures,
paired incidence and near-boundary classification. Hyperreal supplies the shared
root and trigonometric proofs; Hypercurve retains the circular chart and paired
overlap endpoint evidence. The [cone continuation record](docs/evidence/2026-10-17-cone-continuation/README.md)
states this finite domain, explicit uncertainty-fixture migration and remaining
exchange/resource limits.

`ConicalRevolution::from_line` recognizes an exact line revolved around a unit
axis. It retains the original line and axis, proves their intersection, and
constructs either `ConeBranch` relative to the apex parameter. The owned chart
maps source angle/line parameters to native angle/slant distance and supplies
a certified point inverse away from the apex. Skew, parallel, perpendicular,
off-carrier and unresolved inputs have typed outcomes. `Surface::conical_geometry`
borrows a native cone's exact frame and semi-angle for consumers.
Cone shell validation also admits a single periodic side face and independently
lifted rectangular partitions after exact period reduction; whole edge images,
orientation and complete nonoverlapping coverage remain required. This supports
native continuation after exact conical LINE-revolution STEP exchange in
HyperBRep IO. See the [cone exchange record](docs/evidence/2026-10-17-cone-exchange/README.md).

Enable the optional derived-output adapter with `--features tessellation`.
HyperTRI remains outside the default core dependency graph.

The current design and certified operation boundary are recorded in
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) and
[`docs/SUPPORT_MATRIX.md`](docs/SUPPORT_MATRIX.md).

## Example

The runnable [`examples/basic.rs`](examples/basic.rs) constructs and measures
one exact cuboid:

```sh
cargo run --example basic
```

The essential construction flow is:

```rust
use hyperbrep::{Point3, Real, builder};

let bodies = builder::cuboid(
    Point3::origin(),
    Point3::new(Real::from(2), Real::from(3), Real::from(5)),
)?;
let exact_volume = bodies.bodies().next().expect("one cuboid").volume()?;
# let _ = exact_volume;
# Ok::<(), Box<dyn std::error::Error>>(())
```

## Development checks

```sh
cargo fmt --all -- --check
cargo test --all-targets
cargo clippy --all-targets -- -D warnings
RUSTDOCFLAGS="-D warnings" cargo doc --no-deps
```

## Non-goals

HyperBREP does not use triangle meshes, voxel fields, physics shapes, or
primitive floats as source topology. Those systems consume validated BREP data
through explicitly derived adapters.

## Extension protocol

Extensions follow the stack-wide [admission protocol](../../docs/admission.md).
It defines the exactness, certainty, boundary, cache, validation, and evidence
requirements shared by the Hyper crates.

Selected geometry archive coverage and remaining replay limits are documented
in [Archive version 9](docs/SELECTED_ARCHIVE.md).

Conic inverse and curve/surface contact queries preserve distant authored
angular charts and distinct full-period seam parameters. Retained Boolean
contacts reuse proven native preimages across periodic charts. Oblique torus
band workflows exercise subdivision, reflection, exact rescaling, replay and
complementary reconstruction; broader arbitrary-angle completion remains open.
