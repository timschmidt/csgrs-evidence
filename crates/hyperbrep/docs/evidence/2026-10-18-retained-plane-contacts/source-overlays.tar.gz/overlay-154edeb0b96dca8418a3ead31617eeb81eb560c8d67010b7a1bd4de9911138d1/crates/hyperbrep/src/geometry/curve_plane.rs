//! Finite plane contacts with retained source parameters and complete components.

use super::*;
use crate::ParameterRange;
use hypercurve::{
    Axis2, CurveIntersectionPairBlockerKind2, CurveParameterSet2, CurvePointLocations2, Similarity2,
};
use hyperreal::RealSign;

pub(super) fn intersect_rational_bezier_plane(
    curve: &Curve3,
    bezier: &RationalBezier3,
    plane: &PlaneSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let projected_controls = bezier
        .control_points
        .iter()
        .map(|point| normal.dot(&(point - &plane.origin)))
        .collect::<Vec<_>>();
    let coefficients = projected_controls
        .iter()
        .zip(&bezier.weights)
        .map(|(value, weight)| weight * value)
        .collect::<Vec<_>>();
    let roots = match coefficients.as_slice() {
        [start, end] => Some(quadratic_roots(Real::zero(), end - start, start.clone())?),
        [start, middle, end] => Some(quadratic_roots(
            start - Real::from(2) * middle + end,
            Real::from(2) * (middle - start),
            start.clone(),
        )?),
        _ => None,
    };
    if let Some(roots) = roots {
        return match roots {
            QuadraticRoots::None => Ok(CurveSurfaceIntersection::None),
            QuadraticRoots::All => Ok(CurveSurfaceIntersection::Contained),
            QuadraticRoots::Isolated(roots) => isolated_line_parameters(curve, roots),
        };
    }
    let mut contained = true;
    for coefficient in &coefficients {
        if !is_zero(coefficient)? {
            contained = false;
            break;
        }
    }
    if contained {
        return Ok(CurveSurfaceIntersection::Contained);
    }
    // Positive native weights certify a nonzero denominator on the unit domain.
    // Reuse the planar owner's complete incidence/root authority for the numerator.
    let projected = Curve2::from(RationalBezier2::try_new(
        projected_controls
            .into_iter()
            .map(|value| CurvePoint2::new(value, Real::zero()))
            .collect(),
        bezier.weights.clone(),
    )?);
    let mut points = Vec::new();
    match projected.point_locations(&CurvePoint2::new(Real::zero(), Real::zero()).into())? {
        CurvePointLocations2::EntireCurve => return Ok(CurveSurfaceIntersection::Contained),
        CurvePointLocations2::Locations(locations) => {
            for location in locations {
                let selected = location.parameter()?;
                let derivative = projected.derivatives_at(&selected, 1)?;
                let multiplicity = classify_derivative(derivative[0].coordinate_sign(Axis2::X)?);
                let parameter = Parameter::from_curve(&selected)?;
                points.push(CurveSurfacePoint {
                    point: curve.point_at(&parameter)?,
                    parameter,
                    multiplicity,
                });
            }
        }
    }
    assemble(curve, points, Vec::new())
}

pub(super) fn intersect_nurbs_plane(
    curve: &Curve3,
    nurbs: &NurbsCurve3,
    plane: &PlaneSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let mut points = Vec::new();
    let mut overlaps = Vec::new();
    for (segment, domain) in decompose_nurbs_into_bezier_segments(nurbs)? {
        let CurveGeometry3::RationalBezier(bezier) = &segment.data.geometry else {
            unreachable!("NURBS decomposition produces rational Bézier segments");
        };
        match intersect_rational_bezier_plane(&segment, bezier, plane)? {
            CurveSurfaceIntersection::None => {}
            CurveSurfaceIntersection::Points(local_points) => {
                let span = domain.end() - domain.start();
                for local in local_points {
                    let parameter = local.parameter.affine_image(&span, domain.start())?;
                    points.push(CurveSurfacePoint {
                        point: curve.point_at(&parameter)?,
                        parameter,
                        multiplicity: local.multiplicity,
                    });
                }
            }
            CurveSurfaceIntersection::Contained => overlaps.push(domain.into()),
            CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
                unreachable!(
                    "one rational plane equation has isolated roots or is identically zero"
                )
            }
        }
    }
    assemble(curve, points, overlaps)
}

pub(super) fn intersect_planar_image_plane(
    curve: &Curve3,
    image: &PlanarCurve3,
    plane: &PlaneSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let a = normal.dot(&image.u);
    let b = normal.dot(&image.v);
    let c = normal.dot(&(&image.origin - &plane.origin));
    // A stored definition alone does not prove that a signed-weight source has
    // no poles. Certify the whole finite source before publishing even containment.
    let bounds = image.source.bounds()?;
    let a_zero = is_zero(&a)?;
    let b_zero = is_zero(&b)?;
    if a_zero && b_zero {
        return Ok(if is_zero(&c)? {
            CurveSurfaceIntersection::Contained
        } else {
            CurveSurfaceIntersection::None
        });
    }
    // Cover every possible source contact by a finite exact line. The added
    // unit extends a conservative enclosure; it is not a coincidence tolerance.
    let endpoints = if !a_zero {
        [bounds.min_y() - Real::one(), bounds.max_y() + Real::one()].map(|y| {
            Ok(CurvePoint2::new(
                ((-&b * &y - &c) / &a).map_err(GeometryError::Numeric)?,
                y,
            ))
        })
    } else {
        [bounds.min_x() - Real::one(), bounds.max_x() + Real::one()].map(|x| {
            Ok(CurvePoint2::new(
                x,
                ((-&c) / &b).map_err(GeometryError::Numeric)?,
            ))
        })
    };
    let [start, end]: [GeometryResult<CurvePoint2>; 2] = endpoints;
    let line = Curve2::from(LineSeg2::try_new(start?, end?)?);
    let intersection = image.source.intersect_curve(&line)?;
    if let Some(blocker) = intersection.blockers().first() {
        return Err(match blocker.kind() {
            CurveIntersectionPairBlockerKind2::Uncertain(reason) => {
                GeometryError::PlanarClassificationUnresolved(*reason)
            }
            CurveIntersectionPairBlockerKind2::IncompleteReplay
            | CurveIntersectionPairBlockerKind2::SharedComponent => {
                GeometryError::UnsupportedIntersection
            }
        });
    }
    let inverse = (Real::one() / (&image.source_end - &image.source_start))
        .map_err(GeometryError::Numeric)?;
    let offset = -&image.source_start * &inverse;
    let transport = |parameter: &hypercurve::CurveParameter2| {
        Parameter::from_curve(parameter)?.affine_image(&inverse, &offset)
    };
    let domain = ParameterRange::from(curve.domain());
    let mut points = Vec::new();
    let mut overlaps = Vec::new();
    let mut derivative_image = None;
    for contact in intersection.contacts() {
        let source_parameter = contact.first().parameter()?;
        let parameter = transport(&source_parameter)?;
        if !domain.contains(&parameter)? {
            continue;
        }
        let multiplicity = match contact.tangent_cross_sign() {
            Some(sign) => classify_derivative(sign),
            None => {
                // Lack of a transverse certificate is not a tangency proof.
                // An exact similarity puts a*x+b*y+c on the first axis while
                // preserving the owner's source chart and parallel authority.
                if derivative_image.is_none() {
                    let transform = Similarity2::try_from_real_affine(
                        a.clone(),
                        b.clone(),
                        -&b,
                        a.clone(),
                        c.clone(),
                        Real::zero(),
                    )?;
                    derivative_image = Some(image.source.transform_similarity(&transform)?);
                }
                let projected = derivative_image
                    .as_ref()
                    .expect("initialized derivative image");
                let mut classification = IntersectionMultiplicity::Simple;
                for side in [
                    hypercurve::CurveParameterSide2::Left,
                    hypercurve::CurveParameterSide2::Right,
                ] {
                    let derivative = projected.derivatives_at_side(&source_parameter, 1, side)?;
                    if derivative[0].coordinate_sign(Axis2::X)? == RealSign::Zero {
                        classification = IntersectionMultiplicity::Tangent;
                    }
                }
                classification
            }
        };
        points.push(CurveSurfacePoint {
            point: curve.point_at(&parameter)?,
            parameter,
            multiplicity,
        });
    }
    let mut append_range =
        |index, range: &hypercurve::CurveParameterRange2| -> GeometryResult<()> {
            let first = transport(&image.source.parameter_from_span(index, range.start())?)?;
            let second = transport(&image.source.parameter_from_span(index, range.end())?)?;
            let (mut start, mut end) = if first.compare(&second)? == Ordering::Greater {
                (second, first)
            } else {
                (first, second)
            };
            if start.compare(domain.start())? == Ordering::Less {
                start = domain.start().clone();
            }
            if end.compare(domain.end())? == Ordering::Greater {
                end = domain.end().clone();
            }
            match start.compare(&end)? {
                Ordering::Less => overlaps.push(ParameterRange::new(start, end)?),
                Ordering::Equal => points.push(CurveSurfacePoint {
                    point: curve.point_at(&start)?,
                    parameter: start,
                    multiplicity: IntersectionMultiplicity::Boundary,
                }),
                Ordering::Greater => {}
            }
            Ok(())
        };
    for overlap in intersection.overlaps() {
        if !overlap.includes_start() || !overlap.includes_end() {
            return Err(GeometryError::UnsupportedIntersection);
        }
        append_range(overlap.first_span_index(), overlap.first_range())?;
    }
    for component in intersection.parameter_components() {
        match component.first_parameters() {
            CurveParameterSet2::Range(range) => append_range(component.first_span_index(), range)?,
            CurveParameterSet2::Single(_) => {
                // The other operand is a noncollapsed line, so a Cartesian
                // range component cannot have only one first-operand parameter.
                return Err(GeometryError::UnsupportedIntersection);
            }
        }
    }
    assemble(curve, points, overlaps)
}

fn is_zero(value: &Real) -> GeometryResult<bool> {
    Ok(decided_order(compare_reals(
        value,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal)
}

fn classify_derivative(sign: RealSign) -> IntersectionMultiplicity {
    if sign == RealSign::Zero {
        IntersectionMultiplicity::Tangent
    } else {
        IntersectionMultiplicity::Simple
    }
}

/// Normalize in the original source chart. Distinct visits to one spatial
/// point remain distinct parameters. Coincident ranges own their endpoints.
fn assemble(
    curve: &Curve3,
    points: Vec<CurveSurfacePoint>,
    overlaps: Vec<ParameterRange>,
) -> GeometryResult<CurveSurfaceIntersection> {
    let mut sorted = Vec::<ParameterRange>::new();
    for range in overlaps {
        let mut index = sorted.len();
        while index > 0 && range.start().compare(sorted[index - 1].start())? == Ordering::Less {
            index -= 1;
        }
        sorted.insert(index, range);
    }
    let mut ranges = Vec::<ParameterRange>::new();
    for range in sorted {
        if let Some(last) = ranges.last_mut()
            && range.start().compare(last.end())? != Ordering::Greater
        {
            if range.end().compare(last.end())? == Ordering::Greater {
                *last = ParameterRange::new(last.start().clone(), range.end().clone())?;
            }
        } else {
            ranges.push(range);
        }
    }
    let mut isolated = Vec::<CurveSurfacePoint>::new();
    'point: for point in points {
        for range in &ranges {
            if range.contains(&point.parameter)? {
                continue 'point;
            }
        }
        let mut index = isolated.len();
        while index > 0 {
            match point.parameter.compare(&isolated[index - 1].parameter)? {
                Ordering::Greater => break,
                Ordering::Less => index -= 1,
                Ordering::Equal => {
                    if point.multiplicity == IntersectionMultiplicity::Tangent {
                        isolated[index - 1].multiplicity = IntersectionMultiplicity::Tangent;
                    }
                    continue 'point;
                }
            }
        }
        isolated.insert(index, point);
    }
    if ranges.is_empty() {
        return Ok(if isolated.is_empty() {
            CurveSurfaceIntersection::None
        } else {
            CurveSurfaceIntersection::Points(isolated)
        });
    }
    if ranges.len() == 1 && isolated.is_empty() {
        let range = ranges.pop().expect("one normalized range");
        let domain = ParameterRange::from(curve.domain());
        return Ok(
            if range.start().compare(domain.start())? == Ordering::Equal
                && range.end().compare(domain.end())? == Ordering::Equal
            {
                CurveSurfaceIntersection::Contained
            } else {
                CurveSurfaceIntersection::Overlap(range)
            },
        );
    }
    Ok(CurveSurfaceIntersection::Components(
        CurveSurfaceComponents {
            points: isolated,
            overlaps: ranges,
        },
    ))
}
