use hypercurve::{Curve2, CurveParameter2, Point2};
use hyperreal::Real;

#[test]
fn overlap_parameters_use_the_original_nonunit_nurbs_chart() {
    let curve = Curve2::try_nurbs(
        1,
        [0, 1, 2]
            .map(|x| Point2::new(Real::from(x), Real::zero()))
            .to_vec(),
        vec![Real::one(); 3],
        [2, 2, 3, 5, 5].map(Real::from).to_vec(),
    )
    .unwrap();
    for curve in [curve.clone(), curve.reversed().unwrap()] {
        let intersection = curve.intersect_curve(&curve).unwrap();
        assert!(intersection.is_complete());
        assert_eq!(intersection.overlaps().len(), 2);
        for overlap in intersection.overlaps() {
            let index = overlap.first_span_index();
            let range = overlap.first_range();
            for parameter in [range.start(), range.end()] {
                let authored = curve.parameter_from_span(index, parameter).unwrap();
                let point = curve.point_at(&authored).unwrap();
                let span = &curve.native_bezier_fragments().unwrap()[index];
                let span_curve = Curve2::from(span.curve());
                let expected = span_curve.point_at(parameter).unwrap();
                assert!(point.coincides_with(&expected).unwrap());
            }
        }
        assert!(
            curve
                .parameter_from_span(usize::MAX, &CurveParameter2::from(Real::zero()))
                .is_err()
        );
    }
}
