//! Canonical exact 3D curves and parameterized surfaces.

use std::cmp::Ordering;
use std::sync::{Arc, OnceLock};

use hypercurve::{
    CircularArc2, Classification, Contour2, Curve2, CurveFamily2, CurveGeometry2, CurveRegion2,
    LineSeg2, Point2 as CurvePoint2, RationalBezier2, Segment2,
};
use hyperlattice::{Aabb, Matrix4, Point2, Point3, Real, Vector2, Vector3};
use hyperlimit::{PredicateOutcome, compare_reals, point3_equal};

use crate::Parameter;
use crate::error::{GeometryError, GeometryResult};

mod analytic;
mod axial_lines;
mod conical_revolution;
mod curve_plane;
mod location;
mod periodic_charts;
mod planar_image;
mod planes;
mod point;
mod spline;
mod transform;
pub use analytic::{CircularArcGeometry, ConeGeometry, CylinderGeometry, TorusGeometry};
pub use conical_revolution::{ConeBranch, ConicalRevolution, ConicalRevolutionChart};
use curve_plane::{intersect_nurbs_plane, intersect_planar_image_plane, intersect_rational_bezier_plane};
use location::{
    locate_ellipse_arc_parameters, locate_line_parameter, locate_nurbs_parameters,
    locate_rational_bezier_parameters,
};
pub use planar_image::PlanarCurveGeometry;
pub(crate) use planar_image::{PlanarCurve3, represented_curve_point};
use planes::intersect_planes;
pub use point::{Axis, GeometricPoint3};
pub use spline::{NurbsCurveGeometry, RationalBezierCurveGeometry};
pub(crate) use transform::TransformMetric;

pub(crate) fn resolve_planar_classification<T>(
    classification: Classification<T>,
) -> GeometryResult<T> {
    match classification {
        Classification::Decided(value) => Ok(value),
        Classification::Uncertain(reason) => {
            Err(GeometryError::PlanarClassificationUnresolved(reason))
        }
    }
}

/// Exact closed parameter interval.
#[derive(Clone, Debug)]
pub struct ParameterDomain {
    start: Real,
    end: Real,
}

impl ParameterDomain {
    /// Constructs a nonempty increasing closed parameter interval.
    pub fn new(start: Real, end: Real) -> GeometryResult<Self> {
        crate::context::strict(
            || match compare_reals(&start, &end, crate::STRICT_PREDICATES) {
                PredicateOutcome::Decided {
                    value: Ordering::Less,
                    ..
                } => Ok(Self { start, end }),
                PredicateOutcome::Decided { .. } => Err(GeometryError::InvalidParameterDomain),
                PredicateOutcome::Unknown { needed, stage } => {
                    Err(GeometryError::PredicateUnresolved { needed, stage })
                }
            },
        )
    }

    /// Returns the conventional unit interval.
    pub fn unit() -> Self {
        Self {
            start: Real::zero(),
            end: Real::one(),
        }
    }

    /// Returns the inclusive interval start.
    pub const fn start(&self) -> &Real {
        &self.start
    }

    /// Returns the inclusive interval end.
    pub const fn end(&self) -> &Real {
        &self.end
    }

    /// Certifies whether `parameter` belongs to this interval.
    pub fn contains(&self, parameter: &Real) -> GeometryResult<bool> {
        crate::context::strict(|| {
            if parameter == &self.start || parameter == &self.end {
                return Ok(true);
            }
            let after_start = decided_order(compare_reals(
                parameter,
                &self.start,
                crate::STRICT_PREDICATES,
            ))?;
            let before_end = decided_order(compare_reals(
                parameter,
                &self.end,
                crate::STRICT_PREDICATES,
            ))?;
            Ok(matches!(after_start, Ordering::Equal | Ordering::Greater)
                && matches!(before_end, Ordering::Equal | Ordering::Less))
        })
    }
}

/// Supported exact spatial curve family.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum Curve3Kind {
    /// Exact affine lift of a retained planar curve.
    PlanarImage,
    /// Finite line segment.
    Line,
    /// Arbitrary-degree rational Bézier curve.
    RationalBezier,
    /// Non-periodic finite-domain NURBS curve.
    Nurbs,
    /// Exact circular arc.
    CircleArc,
    /// Exact elliptic arc.
    EllipseArc,
}

/// Exact first derivative of a spatial curve.
#[derive(Clone, Debug)]
pub struct CurveDerivative3 {
    vector: Vector3,
}

/// Complete exact parameter-location result for one spatial curve.
#[derive(Clone, Debug)]
pub enum CurveParameterLocation {
    /// The point is not on the finite curve.
    None,
    /// All certified exact parameters whose images equal the point.
    /// Selected algebraic roots need not have a stored `Real` view.
    Parameters(Vec<Parameter>),
    /// Every parameter in the curve domain maps to the point.
    EntireDomain,
}

impl CurveDerivative3 {
    /// Returns the exact derivative vector.
    pub const fn vector(&self) -> &Vector3 {
        &self.vector
    }
}

pub(crate) fn native_span_parameter_range(
    curve: &Curve2,
    index: usize,
    range: &hypercurve::CurveParameterRange2,
) -> Result<hypercurve::ParamRange, GeometryError> {
    let spans = curve.native_bezier_fragments()?;
    let (start, end) = spans
        .get(index)
        .ok_or(GeometryError::UnsupportedIntersection)?
        .parameter_range();
    let lift = |parameter: &hypercurve::CurveParameter2| -> Result<Real, GeometryError> {
        let parameter = parameter
            .scalar()
            .ok_or(GeometryError::UnrepresentableParameter)?;
        Ok(start + (end - start) * parameter)
    };
    Ok(hypercurve::ParamRange::new(
        lift(range.start())?,
        lift(range.end())?,
    ))
}

/// Immutable exact face-local parameter-space curve.
///
/// Hypercurve owns the planar curve implementation; HyperBREP binds it to an
/// edge use and surface.
#[derive(Clone, Debug)]
pub struct Pcurve {
    curve: Curve2,
}

impl Pcurve {
    /// Binds an exact Hypercurve carrier for later use by BREP topology.
    pub fn new(curve: Curve2) -> Self {
        Self { curve }
    }

    /// Returns the underlying exact planar curve.
    pub const fn curve(&self) -> &Curve2 {
        &self.curve
    }

    /// Returns the planar curve family.
    pub fn kind(&self) -> CurveFamily2 {
        self.curve.family()
    }

    /// Returns the first parameter in this pcurve's directed retained chart.
    pub fn domain_start(&self) -> GeometryResult<Parameter> {
        Parameter::from_curve(self.curve.parameter_endpoints().0)
    }

    /// Returns the last parameter in this pcurve's directed retained chart.
    pub fn domain_end(&self) -> GeometryResult<Parameter> {
        Parameter::from_curve(self.curve.parameter_endpoints().1)
    }

    pub(crate) fn represented_start(&self) -> GeometryResult<&Real> {
        crate::context::strict(|| {
            self.curve
                .parameter_endpoints()
                .0
                .scalar()
                .ok_or(GeometryError::UnsupportedPcurveContour)
        })
    }

    pub(crate) fn represented_end(&self) -> GeometryResult<&Real> {
        crate::context::strict(|| {
            self.curve
                .parameter_endpoints()
                .1
                .scalar()
                .ok_or(GeometryError::UnsupportedPcurveContour)
        })
    }

    /// Evaluates a face-local point without discarding selected image evidence.
    pub fn point_at(&self, parameter: &Parameter) -> GeometryResult<hypercurve::CurvePoint2> {
        crate::context::strict(|| Ok(self.curve.point_at(&parameter.curve_parameter())?))
    }

    pub(crate) fn evaluate_real(&self, parameter: &Real) -> GeometryResult<Point2> {
        crate::context::strict(|| {
            let point = represented_curve_point(&self.curve, parameter)?;
            Ok(Point2::new(point.x().clone(), point.y().clone()))
        })
    }

    /// Splits this pcurve exactly at a strict interior public parameter.
    pub fn split_at(&self, parameter: &Parameter) -> GeometryResult<(Self, Self)> {
        crate::context::strict(|| {
            let (first, second) = self.curve.split_at(parameter.curve_parameter())?;
            Ok((Self::new(first), Self::new(second)))
        })
    }

    /// Returns the same exact parameter-space image with reversed traversal.
    pub fn reversed(&self) -> GeometryResult<Self> {
        crate::context::strict(|| Ok(Self::new(self.curve.reversed()?)))
    }

    pub(crate) fn endpoints(&self) -> GeometryResult<(Point2, Point2)> {
        Ok((
            self.evaluate_real(self.represented_start()?)?,
            self.evaluate_real(self.represented_end()?)?,
        ))
    }

    pub(crate) fn segment(&self) -> GeometryResult<Segment2> {
        match self.curve.geometry() {
            Some(CurveGeometry2::Line(line)) => Ok(Segment2::Line(line.clone())),
            Some(CurveGeometry2::CircularArc(arc)) => Ok(Segment2::Arc(arc.clone())),
            _ => Err(GeometryError::UnsupportedPcurveContour),
        }
    }

    pub(crate) fn circular_arc(&self) -> Option<&hypercurve::CircularArc2> {
        match self.curve.geometry() {
            Some(CurveGeometry2::CircularArc(arc)) => Some(arc),
            _ => None,
        }
    }

    pub(crate) fn line_segment(&self) -> Option<&hypercurve::LineSeg2> {
        match self.curve.geometry() {
            Some(CurveGeometry2::Line(line)) => Some(line),
            _ => None,
        }
    }

    /// Recovers every incident public parameter without replacing the native
    /// chart or discarding selected-root authority.
    pub(crate) fn parameters_at_point(&self, point: &Point2) -> GeometryResult<Vec<Parameter>> {
        crate::context::strict(|| {
            let point = CurvePoint2::new(point.x.clone(), point.y.clone());
            if let Some(line) = self.line_segment() {
                // A native strict side proof can exclude unrelated source
                // uses before constructing their rational incidence equations.
                // On-line and blocked classifications still use the complete
                // native inverse, including finite domains and root identity.
                match line.classify_point(&point) {
                    Ok(hypercurve::LineSide::Left | hypercurve::LineSide::Right) => {
                        return Ok(Vec::new());
                    }
                    Ok(hypercurve::LineSide::On) | Err(hypercurve::ExactCurveError::Blocked(_)) => {
                    }
                    Err(error) => return Err(error.into()),
                }
            }
            match self.curve.point_locations(&point.into())? {
                hypercurve::CurvePointLocations2::Locations(locations) => locations
                    .iter()
                    .map(|location| Parameter::from_curve(&location.parameter()?))
                    .collect(),
                hypercurve::CurvePointLocations2::EntireCurve => {
                    Err(GeometryError::UnsupportedPcurveContour)
                }
            }
        })
    }

    pub(crate) fn reflected_and_reversed_x(&self, reflection_sum: Real) -> GeometryResult<Self> {
        let reflect = |point: &hypercurve::Point2| {
            hypercurve::Point2::new(&reflection_sum - point.x(), point.y().clone())
        };
        match self.curve.geometry() {
            Some(CurveGeometry2::Line(line)) => Ok(Self::new(Curve2::from(
                hypercurve::LineSeg2::try_new(reflect(line.end()), reflect(line.start()))?,
            ))),
            Some(CurveGeometry2::CircularArc(arc)) => Ok(Self::new(Curve2::from(
                hypercurve::CircularArc2::try_from_center(
                    reflect(arc.end()),
                    reflect(arc.start()),
                    reflect(arc.center()),
                    arc.is_clockwise(),
                )?,
            ))),
            _ => {
                let reflection = hypercurve::Similarity2::try_from_real_affine(
                    -Real::one(),
                    Real::zero(),
                    Real::zero(),
                    Real::one(),
                    reflection_sum,
                    Real::zero(),
                )?;
                Ok(Self::new(
                    self.curve.transform_similarity(&reflection)?.reversed()?,
                ))
            }
        }
    }
}

/// Immutable exact spatial curve.
#[derive(Clone, Debug)]
pub struct Curve3 {
    data: Arc<Curve3Data>,
    parameterization_identity: Arc<()>,
}

#[derive(Debug)]
struct Curve3Data {
    geometry: CurveGeometry3,
    domain: ParameterDomain,
    bounds: OnceLock<Aabb>,
    projections: OnceLock<Box<point::CurveProjections3>>,
}

#[derive(Debug)]
enum CurveGeometry3 {
    PlanarImage(Box<PlanarCurve3>),
    Line(Line3),
    RationalBezier(RationalBezier3),
    Nurbs(NurbsCurve3),
    CircleArc(EllipseArc3),
    EllipseArc(EllipseArc3),
}

#[derive(Clone, Debug)]
pub(crate) enum Curve3ExactData {
    PlanarImage(Box<PlanarCurve3>),
    Line(Box<Line3ExactData>),
    RationalBezier {
        control_points: Vec<Point3>,
        weights: Vec<Real>,
    },
    Nurbs {
        degree: usize,
        control_points: Vec<Point3>,
        weights: Vec<Real>,
        knots: Vec<Real>,
    },
    EllipseArc(Box<EllipseArcExactData>),
}

#[derive(Clone, Debug)]
pub(crate) struct Line3ExactData {
    pub(crate) start: Point3,
    pub(crate) end: Point3,
}

#[derive(Clone, Debug)]
pub(crate) struct EllipseArcExactData {
    pub(crate) circle: bool,
    pub(crate) center: Point3,
    pub(crate) x: Vector3,
    pub(crate) y: Vector3,
    pub(crate) x_radius: Real,
    pub(crate) y_radius: Real,
    pub(crate) domain_start: Real,
    pub(crate) domain_end: Real,
    pub(crate) angle_at_start: Real,
    pub(crate) direction: i8,
}

#[derive(Debug)]
struct Line3 {
    start: Point3,
    end: Point3,
}

#[derive(Debug)]
struct RationalBezier3 {
    control_points: Vec<Point3>,
    weights: Vec<Real>,
    constant_coordinates: [Option<Real>; 3],
    homogeneous_controls: OnceLock<Vec<HomogeneousPoint3>>,
}

#[derive(Debug)]
struct NurbsCurve3 {
    degree: usize,
    control_points: Vec<Point3>,
    weights: Vec<Real>,
    knots: Vec<Real>,
    homogeneous_controls: OnceLock<Vec<HomogeneousPoint3>>,
}

#[derive(Clone, Debug)]
struct EllipseArc3 {
    center: Point3,
    x: Vector3,
    y: Vector3,
    x_radius: Real,
    y_radius: Real,
    angle_at_start: Real,
    direction: i8,
}

#[derive(Clone, Debug)]
struct HomogeneousPoint3 {
    x: Real,
    y: Real,
    z: Real,
    w: Real,
}

type AffineControlGrid = (Vec<Vec<Point3>>, Vec<Vec<Real>>);
type HomogeneousNurbsSplit = (
    Vec<HomogeneousPoint3>,
    Vec<Real>,
    Vec<HomogeneousPoint3>,
    Vec<Real>,
);

impl Curve3 {
    pub(crate) fn shares_identity(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.data, &other.data)
    }

    pub(crate) fn identity_address(&self) -> usize {
        Arc::as_ptr(&self.data) as usize
    }

    /// Constructs a finite exact line segment.
    pub fn line(start: Point3, end: Point3) -> GeometryResult<Self> {
        crate::context::strict(|| {
            // Line restrictions repeatedly consume these exact coordinates.
            // Compact derived algebraic endpoints before another affine image
            // expands them, without changing their values or parameterization.
            let compact = |point: Point3| {
                Point3::new(
                    point.x.compact_pi_laurent().unwrap_or(point.x),
                    point.y.compact_pi_laurent().unwrap_or(point.y),
                    point.z.compact_pi_laurent().unwrap_or(point.z),
                )
            };
            let start = compact(start);
            let end = compact(end);
            match point3_equal(&start, &end, crate::STRICT_PREDICATES) {
                PredicateOutcome::Decided { value: true, .. } => {
                    return Err(GeometryError::DegenerateLine);
                }
                PredicateOutcome::Decided { value: false, .. } => {}
                PredicateOutcome::Unknown { needed, stage } => {
                    return Err(GeometryError::PredicateUnresolved { needed, stage });
                }
            }
            Ok(Self::from_parts(
                CurveGeometry3::Line(Line3 { start, end }),
                ParameterDomain::unit(),
            ))
        })
    }

    /// Constructs an exact circular arc parameterized directly by angle.
    pub fn circle_arc(
        center: Point3,
        x: Vector3,
        y: Vector3,
        radius: Real,
        start_angle: Real,
        end_angle: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            require_positive(&radius, GeometryError::InvalidRadius)?;
            validate_arc_axes(&x, &y)?;
            let domain = validate_arc_domain(start_angle, end_angle)?;
            Ok(Self::from_parts(
                CurveGeometry3::CircleArc(EllipseArc3 {
                    center,
                    x,
                    y,
                    x_radius: radius.clone(),
                    y_radius: radius,
                    angle_at_start: domain.start().clone(),
                    direction: 1,
                }),
                domain,
            ))
        })
    }

    /// Constructs an exact elliptic arc parameterized directly by angle.
    pub fn ellipse_arc(
        center: Point3,
        x: Vector3,
        y: Vector3,
        x_radius: Real,
        y_radius: Real,
        start_angle: Real,
        end_angle: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            require_positive(&x_radius, GeometryError::InvalidEllipseRadii)?;
            require_positive(&y_radius, GeometryError::InvalidEllipseRadii)?;
            validate_arc_axes(&x, &y)?;
            let domain = validate_arc_domain(start_angle, end_angle)?;
            Ok(Self::from_parts(
                CurveGeometry3::EllipseArc(EllipseArc3 {
                    center,
                    x,
                    y,
                    x_radius,
                    y_radius,
                    angle_at_start: domain.start().clone(),
                    direction: 1,
                }),
                domain,
            ))
        })
    }

    /// Constructs an arbitrary-degree rational Bézier curve over `[0, 1]`.
    pub fn rational_bezier(
        control_points: Vec<Point3>,
        weights: Vec<Real>,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            validate_control_net(&control_points, &weights)?;
            validate_positive_weights(&weights)?;
            let constant_coordinates = certified_constant_coordinates(&control_points);
            Ok(Self::from_parts(
                CurveGeometry3::RationalBezier(RationalBezier3 {
                    control_points,
                    weights,
                    constant_coordinates,
                    homogeneous_controls: OnceLock::new(),
                }),
                ParameterDomain::unit(),
            ))
        })
    }

    /// Constructs a finite, non-periodic exact NURBS curve.
    pub fn nurbs(
        degree: usize,
        control_points: Vec<Point3>,
        weights: Vec<Real>,
        knots: Vec<Real>,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            validate_control_net(&control_points, &weights)?;
            validate_positive_weights(&weights)?;
            if degree == 0 || degree >= control_points.len() {
                return Err(GeometryError::InvalidDegree);
            }
            if knots.len() != control_points.len() + degree + 1 {
                return Err(GeometryError::InvalidKnotCount);
            }
            for adjacent in knots.windows(2) {
                if !matches!(
                    decided_order(compare_reals(
                        &adjacent[0],
                        &adjacent[1],
                        crate::STRICT_PREDICATES
                    ))?,
                    Ordering::Less | Ordering::Equal
                ) {
                    return Err(GeometryError::InvalidKnotOrder);
                }
            }
            validate_clamped_knot_multiplicities(degree, &knots)?;
            let domain =
                ParameterDomain::new(knots[degree].clone(), knots[control_points.len()].clone())?;
            Ok(Self::from_parts(
                CurveGeometry3::Nurbs(NurbsCurve3 {
                    degree,
                    control_points,
                    weights,
                    knots,
                    homogeneous_controls: OnceLock::new(),
                }),
                domain,
            ))
        })
    }

    fn from_parts(geometry: CurveGeometry3, domain: ParameterDomain) -> Self {
        Self {
            data: Arc::new(Curve3Data {
                geometry,
                domain,
                bounds: OnceLock::new(),
                projections: OnceLock::new(),
            }),
            parameterization_identity: Arc::new(()),
        }
    }

    fn retaining_parameterization_of(mut self, source: &Self) -> Self {
        self.parameterization_identity = source.parameterization_identity.clone();
        self
    }

    pub(crate) fn shares_parameterization(&self, other: &Self) -> bool {
        Arc::ptr_eq(
            &self.parameterization_identity,
            &other.parameterization_identity,
        )
    }

    pub(crate) fn has_certified_same_parameterization(&self, other: &Self) -> bool {
        if self.shares_parameterization(other) {
            return true;
        }
        let (
            CurveGeometry3::CircleArc(first) | CurveGeometry3::EllipseArc(first),
            CurveGeometry3::CircleArc(second) | CurveGeometry3::EllipseArc(second),
        ) = (&self.data.geometry, &other.data.geometry)
        else {
            return false;
        };
        if self.kind() != other.kind()
            || first.direction != second.direction
            || point3_equal(&first.center, &second.center, crate::STRICT_PREDICATES).value()
                != Some(true)
        {
            return false;
        }
        let equal = |left: &Real, right: &Real| {
            compare_reals(left, right, crate::STRICT_PREDICATES).value() == Some(Ordering::Equal)
        };
        if !first
            .x
            .0
            .iter()
            .zip(&second.x.0)
            .chain(first.y.0.iter().zip(&second.y.0))
            .all(|(left, right)| equal(left, right))
            || !equal(&first.x_radius, &second.x_radius)
            || !equal(&first.y_radius, &second.y_radius)
        {
            return false;
        }
        let direction = Real::from(first.direction);
        let first_offset = &first.angle_at_start - &(direction.clone() * self.domain().start());
        let second_offset = &second.angle_at_start - &(direction * other.domain().start());
        equal(&first_offset, &second_offset)
    }

    /// Returns the curve family.
    pub fn kind(&self) -> Curve3Kind {
        match &self.data.geometry {
            CurveGeometry3::PlanarImage(_) => Curve3Kind::PlanarImage,
            CurveGeometry3::Line(_) => Curve3Kind::Line,
            CurveGeometry3::RationalBezier(_) => Curve3Kind::RationalBezier,
            CurveGeometry3::Nurbs(_) => Curve3Kind::Nurbs,
            CurveGeometry3::CircleArc(_) => Curve3Kind::CircleArc,
            CurveGeometry3::EllipseArc(_) => Curve3Kind::EllipseArc,
        }
    }

    pub(crate) fn canonical_line(&self) -> GeometryResult<Option<Self>> {
        match &self.data.geometry {
            CurveGeometry3::Line(_) => Ok(Some(self.clone())),
            CurveGeometry3::RationalBezier(curve) => {
                let Some(first_weight) = curve.weights.first() else {
                    return Ok(None);
                };
                for weight in &curve.weights {
                    if decided_order(compare_reals(
                        weight,
                        first_weight,
                        crate::STRICT_PREDICATES,
                    ))? != Ordering::Equal
                    {
                        return Ok(None);
                    }
                }
                let start = curve
                    .control_points
                    .first()
                    .expect("validated rational Bézier has controls");
                let end = curve
                    .control_points
                    .last()
                    .expect("validated rational Bézier has controls");
                let degree = curve.control_points.len() - 1;
                if degree == 0 {
                    return Ok(None);
                }
                for (index, point) in curve.control_points.iter().enumerate() {
                    let parameter = (Real::from(index as u64) / Real::from(degree as u64))
                        .map_err(GeometryError::Numeric)?;
                    if !points_equal(point, &start.lerp(end, &parameter))? {
                        return Ok(None);
                    }
                }
                Ok(Some(Self::line(start.clone(), end.clone())?))
            }
            CurveGeometry3::Nurbs(curve) => {
                let Some(first_weight) = curve.weights.first() else {
                    return Ok(None);
                };
                for weight in &curve.weights {
                    if decided_order(compare_reals(
                        weight,
                        first_weight,
                        crate::STRICT_PREDICATES,
                    ))? != Ordering::Equal
                    {
                        return Ok(None);
                    }
                }
                let start = curve
                    .control_points
                    .first()
                    .expect("validated NURBS has controls");
                let end = curve
                    .control_points
                    .last()
                    .expect("validated NURBS has controls");
                let domain_start = self.domain().start();
                let domain_span = self.domain().end() - domain_start;
                for (index, point) in curve.control_points.iter().enumerate() {
                    let greville = curve.knots[(index + 1)..=(index + curve.degree)]
                        .iter()
                        .cloned()
                        .fold(Real::zero(), |sum, knot| sum + knot);
                    let greville = (greville / Real::from(curve.degree as u64))
                        .map_err(GeometryError::Numeric)?;
                    let parameter = ((greville - domain_start) / &domain_span)
                        .map_err(GeometryError::Numeric)?;
                    if !points_equal(point, &start.lerp(end, &parameter))? {
                        return Ok(None);
                    }
                }
                Ok(Some(Self::line(start.clone(), end.clone())?))
            }
            CurveGeometry3::CircleArc(_)
            | CurveGeometry3::EllipseArc(_)
            | CurveGeometry3::PlanarImage(_) => Ok(None),
        }
    }

    /// Returns the exact public parameter domain.
    pub fn domain(&self) -> &ParameterDomain {
        &self.data.domain
    }

    /// Returns conservative exact model-space bounds.
    ///
    /// Positive-weight rational Bézier and NURBS curves lie in the convex hull
    /// of their affine control points, so this bound never samples or converts
    /// to floating point. Only successful bounds are cached; unresolved
    /// comparisons can be retried after scalar evidence strengthens.
    pub fn bounds(&self) -> GeometryResult<Aabb> {
        crate::context::strict(|| {
            crate::cache::get_or_try_init(&self.data.bounds, || match &self.data.geometry {
                CurveGeometry3::PlanarImage(image) => image.bounds(),
                CurveGeometry3::Line(line) => {
                    exact_point_bounds(&[line.start.clone(), line.end.clone()])
                }
                CurveGeometry3::RationalBezier(curve) => exact_point_bounds(&curve.control_points),
                CurveGeometry3::Nurbs(curve) => exact_point_bounds(&curve.control_points),
                CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                    ellipse_arc_conservative_bounds(arc)
                }
            })
            .cloned()
        })
    }

    fn is_strictly_off_axis(&self, axis_origin: &Point3, axis: &Vector3) -> GeometryResult<bool> {
        let radial = |point: &Point3| {
            let relative = point - axis_origin;
            let axial = axis.clone() * axis.dot(&relative);
            relative - axial
        };
        let start_radial = radial(&self.evaluate_real(self.domain().start())?);
        if decided_order(compare_reals(
            &start_radial.norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Greater
        {
            return Ok(false);
        }
        let end_radial = radial(&self.evaluate_real(self.domain().end())?);
        if decided_order(compare_reals(
            &end_radial.norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Greater
        {
            return Ok(false);
        }
        let witness_length = start_radial
            .norm_squared()
            .sqrt()
            .map_err(GeometryError::Numeric)?;
        let witness = (start_radial / witness_length).map_err(GeometryError::Numeric)?;

        // Positive-weight rational bases stay in their affine control hull.
        // A strict axis-containing separating plane is therefore a complete,
        // affine-invariant clearance certificate for the common case.
        let controls = match &self.data.geometry {
            CurveGeometry3::Line(line) => Some(vec![&line.start, &line.end]),
            CurveGeometry3::RationalBezier(curve) => {
                Some(curve.control_points.iter().collect::<Vec<_>>())
            }
            CurveGeometry3::Nurbs(curve) => Some(curve.control_points.iter().collect::<Vec<_>>()),
            CurveGeometry3::CircleArc(_)
            | CurveGeometry3::EllipseArc(_)
            | CurveGeometry3::PlanarImage(_) => None,
        };
        if let Some(controls) = controls {
            let mut separated = true;
            for point in controls {
                let offset = point - axis_origin;
                if decided_order(compare_reals(
                    &witness.dot(&offset),
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))? != Ordering::Greater
                {
                    separated = false;
                    break;
                }
            }
            if separated {
                return Ok(true);
            }
        }

        // When the convex-hull certificate is inconclusive, reduce exact axis
        // contact to membership in two orthogonal planes through the axis.
        // Supported curve/plane intersections enumerate the complete finite
        // parameter interval; unsupported polynomial degrees remain explicit.
        let transverse = axis.cross(&witness);
        let first_plane = Surface::plane(axis_origin.clone(), axis.clone(), witness.clone())?;
        let point_is_on_axis = |point: &GeometricPoint3| -> GeometryResult<bool> {
            Ok(point.compare_linear_form(
                &transverse,
                &transverse.dot(&Vector3::from(axis_origin.clone())),
            )? == Ordering::Equal)
        };
        match first_plane.intersect_curve(self)? {
            CurveSurfaceIntersection::None => Ok(true),
            CurveSurfaceIntersection::Points(points) => {
                for point in points {
                    if point_is_on_axis(&point.point)? {
                        return Ok(false);
                    }
                }
                Ok(true)
            }
            CurveSurfaceIntersection::Contained => {
                let second_plane = Surface::plane(axis_origin.clone(), axis.clone(), transverse.clone())?;
                match second_plane.intersect_curve(self)? {
                    CurveSurfaceIntersection::None => Ok(true),
                    CurveSurfaceIntersection::Points(_) => Ok(false),
                    CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) | CurveSurfaceIntersection::Contained => {
                        Ok(false)
                    }
                }
            }
            CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => Err(GeometryError::UnsupportedIntersection),
        }
    }

    /// Native represented-parameter evaluator used by coefficient algorithms.
    pub(crate) fn evaluate_real(&self, parameter: &Real) -> GeometryResult<Point3> {
        crate::context::strict(|| {
            if !self.domain().contains(parameter)? {
                return Err(GeometryError::ParameterOutsideDomain);
            }
            match &self.data.geometry {
                CurveGeometry3::PlanarImage(image) => image.point_at(parameter),
                CurveGeometry3::Line(line) => {
                    if parameter == self.domain().start() {
                        return Ok(line.start.clone());
                    }
                    if parameter == self.domain().end() {
                        return Ok(line.end.clone());
                    }
                    Ok(line.start.lerp(&line.end, parameter))
                }
                CurveGeometry3::RationalBezier(curve) => {
                    if parameter == self.domain().start() {
                        return Ok(curve.control_points[0].clone());
                    }
                    if parameter == self.domain().end() {
                        return Ok(curve
                            .control_points
                            .last()
                            .expect("validated rational Bezier has controls")
                            .clone());
                    }
                    let mut point =
                        evaluate_homogeneous_bezier(curve.homogeneous_controls(), parameter)?;
                    restore_constant_coordinates(&mut point, &curve.constant_coordinates);
                    Ok(point)
                }
                CurveGeometry3::Nurbs(curve) => {
                    let span = find_span(
                        parameter,
                        self.domain(),
                        curve.degree,
                        curve.control_points.len(),
                        &curve.knots,
                    )?;
                    evaluate_homogeneous_de_boor(
                        curve.homogeneous_controls(),
                        &curve.knots,
                        curve.degree,
                        span,
                        parameter,
                    )
                }
                CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                    Ok(evaluate_ellipse_arc(arc, self.domain(), parameter))
                }
            }
        })
    }

    /// Evaluates one positive-order exact derivative.
    ///
    /// For spline families, an order whose derivative storage cannot be
    /// addressed returns [`hyperreal::Problem::OutOfRange`] inside
    /// [`GeometryError::Numeric`]. A rejected jet-buffer allocation returns
    /// [`hyperreal::Problem::Exhausted`]. Closed-form line and conic derivatives
    /// do not allocate storage proportional to the order.
    pub fn derivative_at(
        &self,
        parameter: &Real,
        order: usize,
    ) -> GeometryResult<CurveDerivative3> {
        crate::context::strict(|| {
            if order == 0 {
                return Err(GeometryError::InvalidDerivativeOrder);
            }
            if !self.domain().contains(parameter)? {
                return Err(GeometryError::ParameterOutsideDomain);
            }
            let vector = match &self.data.geometry {
                CurveGeometry3::PlanarImage(image) => image.derivative_at(parameter, order)?,
                CurveGeometry3::Line(line) => {
                    if order == 1 {
                        &line.end - &line.start
                    } else {
                        Vector3::zero()
                    }
                }
                CurveGeometry3::RationalBezier(curve) => {
                    evaluate_rational_bezier_derivative(curve, parameter, order)?
                }
                CurveGeometry3::Nurbs(curve) => {
                    let span = find_span(
                        parameter,
                        self.domain(),
                        curve.degree,
                        curve.control_points.len(),
                        &curve.knots,
                    )?;
                    evaluate_homogeneous_de_boor_derivative(
                        curve.homogeneous_controls(),
                        &curve.knots,
                        curve.degree,
                        span,
                        parameter,
                        order,
                    )?
                }
                CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                    evaluate_ellipse_arc_derivative(arc, self.domain(), parameter, order)
                }
            };
            Ok(CurveDerivative3 { vector })
        })
    }

    /// Evaluates the curve at its exact domain start.
    pub fn start(&self) -> GeometryResult<Point3> {
        crate::context::strict(|| self.evaluate_real(self.domain().start()))
    }

    /// Evaluates the curve at its exact domain end.
    pub fn end(&self) -> GeometryResult<Point3> {
        crate::context::strict(|| self.evaluate_real(self.domain().end()))
    }

    pub(crate) fn line_endpoints(&self) -> Option<(&Point3, &Point3)> {
        match &self.data.geometry {
            CurveGeometry3::Line(line) => Some((&line.start, &line.end)),
            CurveGeometry3::RationalBezier(_)
            | CurveGeometry3::Nurbs(_)
            | CurveGeometry3::CircleArc(_)
            | CurveGeometry3::EllipseArc(_)
            | CurveGeometry3::PlanarImage(_) => None,
        }
    }

    /// A native center suitable as the common origin of a closed area integral.
    pub(crate) fn analytic_area_origin(&self) -> Option<&Point3> {
        match &self.data.geometry {
            CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => Some(&arc.center),
            _ => None,
        }
    }

    /// Integrates `(position - origin) × d(position)` over a native analytic
    /// span. Half its component along a plane's unit normal is the signed area
    /// contribution. Keeping the spatial angular interval avoids reconstructing
    /// inverse trigonometric expressions from a projected or split pcurve.
    pub(crate) fn analytic_area_vector(
        &self,
        start: &Real,
        end: &Real,
        origin: &Point3,
    ) -> GeometryResult<Option<Vector3>> {
        match &self.data.geometry {
            CurveGeometry3::Line(_) => {
                let start = self.evaluate_real(start)? - origin;
                let end = self.evaluate_real(end)? - origin;
                Ok(Some(start.cross(&end)))
            }
            CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                let displacement = self.evaluate_real(end)? - self.evaluate_real(start)?;
                let angle = Real::from(arc.direction) * (end - start);
                // For r = c + a cos(t) + b sin(t), integration gives
                // (c - origin) × (r(end) - r(start)) + (a × b) Δt.
                Ok(Some(
                    (&arc.center - origin).cross(&displacement)
                        + arc.x.cross(&arc.y) * (&arc.x_radius * &arc.y_radius * angle),
                ))
            }
            CurveGeometry3::RationalBezier(_)
            | CurveGeometry3::Nurbs(_)
            | CurveGeometry3::PlanarImage(_) => Ok(None),
        }
    }

    pub(crate) fn exact_data(&self) -> Curve3ExactData {
        match &self.data.geometry {
            CurveGeometry3::PlanarImage(image) => Curve3ExactData::PlanarImage(image.clone()),
            CurveGeometry3::Line(line) => Curve3ExactData::Line(Box::new(Line3ExactData {
                start: line.start.clone(),
                end: line.end.clone(),
            })),
            CurveGeometry3::RationalBezier(curve) => Curve3ExactData::RationalBezier {
                control_points: curve.control_points.clone(),
                weights: curve.weights.clone(),
            },
            CurveGeometry3::Nurbs(curve) => Curve3ExactData::Nurbs {
                degree: curve.degree,
                control_points: curve.control_points.clone(),
                weights: curve.weights.clone(),
                knots: curve.knots.clone(),
            },
            CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                Curve3ExactData::EllipseArc(Box::new(EllipseArcExactData {
                    circle: matches!(self.data.geometry, CurveGeometry3::CircleArc(_)),
                    center: arc.center.clone(),
                    x: arc.x.clone(),
                    y: arc.y.clone(),
                    x_radius: arc.x_radius.clone(),
                    y_radius: arc.y_radius.clone(),
                    domain_start: self.domain().start().clone(),
                    domain_end: self.domain().end().clone(),
                    angle_at_start: arc.angle_at_start.clone(),
                    direction: arc.direction,
                }))
            }
        }
    }

    pub(crate) fn from_exact_data(data: Curve3ExactData) -> GeometryResult<Self> {
        match data {
            Curve3ExactData::PlanarImage(image) => Self::from_planar_image(*image),
            Curve3ExactData::Line(data) => Self::line(data.start, data.end),
            Curve3ExactData::RationalBezier {
                control_points,
                weights,
            } => Self::rational_bezier(control_points, weights),
            Curve3ExactData::Nurbs {
                degree,
                control_points,
                weights,
                knots,
            } => Self::nurbs(degree, control_points, weights, knots),
            Curve3ExactData::EllipseArc(data) => {
                let EllipseArcExactData {
                    circle,
                    center,
                    x,
                    y,
                    x_radius,
                    y_radius,
                    domain_start,
                    domain_end,
                    angle_at_start,
                    direction,
                } = *data;
                require_positive(&x_radius, GeometryError::InvalidEllipseRadii)?;
                require_positive(&y_radius, GeometryError::InvalidEllipseRadii)?;
                validate_arc_axes(&x, &y)?;
                let domain = validate_arc_domain(domain_start, domain_end)?;
                if !matches!(direction, -1 | 1) {
                    return Err(GeometryError::InvalidParameterDomain);
                }
                if circle
                    && decided_order(compare_reals(
                        &x_radius,
                        &y_radius,
                        crate::STRICT_PREDICATES,
                    ))? != Ordering::Equal
                {
                    return Err(GeometryError::InvalidEllipseRadii);
                }
                let arc = EllipseArc3 {
                    center,
                    x,
                    y,
                    x_radius,
                    y_radius,
                    angle_at_start,
                    direction,
                };
                Ok(Self::from_parts(
                    if circle {
                        CurveGeometry3::CircleArc(arc)
                    } else {
                        CurveGeometry3::EllipseArc(arc)
                    },
                    domain,
                ))
            }
        }
    }

    /// Returns the same geometric image with reversed parameter direction.
    pub fn reversed(&self) -> GeometryResult<Self> {
        crate::context::strict(|| match &self.data.geometry {
            CurveGeometry3::PlanarImage(image) => image.restricted(&Real::one(), &Real::zero()),
            CurveGeometry3::Line(line) => Self::line(line.end.clone(), line.start.clone()),
            CurveGeometry3::RationalBezier(curve) => {
                let mut points = curve.control_points.clone();
                let mut weights = curve.weights.clone();
                points.reverse();
                weights.reverse();
                Self::rational_bezier(points, weights)
            }
            CurveGeometry3::Nurbs(curve) => {
                let mut points = curve.control_points.clone();
                let mut weights = curve.weights.clone();
                points.reverse();
                weights.reverse();
                let domain_sum = self.domain().start() + self.domain().end();
                let knots = curve
                    .knots
                    .iter()
                    .rev()
                    .map(|knot| &domain_sum - knot)
                    .collect();
                Self::nurbs(curve.degree, points, weights, knots)
            }
            CurveGeometry3::CircleArc(arc) => Ok(Self::from_parts(
                CurveGeometry3::CircleArc(reversed_ellipse_arc(arc, self.domain())),
                self.domain().clone(),
            )),
            CurveGeometry3::EllipseArc(arc) => Ok(Self::from_parts(
                CurveGeometry3::EllipseArc(reversed_ellipse_arc(arc, self.domain())),
                self.domain().clone(),
            )),
        })
    }

    /// Splits any supported finite curve at a certified interior parameter.
    ///
    /// Line and rational-Bézier halves use their conventional local unit
    /// interval; NURBS and conic halves retain their native source intervals.
    pub fn split_at(&self, parameter: &Real) -> GeometryResult<(Self, Self)> {
        crate::context::strict(|| {
            require_interior_parameter(self.domain(), parameter)?;
            match &self.data.geometry {
                CurveGeometry3::PlanarImage(image) => Ok((
                    image.restricted(&Real::zero(), parameter)?,
                    image.restricted(parameter, &Real::one())?,
                )),
                CurveGeometry3::Line(line) => {
                    let split = line.start.lerp(&line.end, parameter);
                    Ok((
                        Self::line(line.start.clone(), split.clone())?,
                        Self::line(split, line.end.clone())?,
                    ))
                }
                CurveGeometry3::RationalBezier(curve) => {
                    let (left, right) =
                        split_homogeneous_bezier(curve.homogeneous_controls(), parameter);
                    Ok((
                        rational_bezier_from_homogeneous(left, Some(&curve.constant_coordinates))?,
                        rational_bezier_from_homogeneous(right, Some(&curve.constant_coordinates))?,
                    ))
                }
                CurveGeometry3::Nurbs(curve) => {
                    let (left, right) = split_nurbs_curve(curve, parameter)?;
                    Ok((
                        left.retaining_parameterization_of(self),
                        right.retaining_parameterization_of(self),
                    ))
                }
                CurveGeometry3::CircleArc(arc) => {
                    let (left, right) =
                        split_ellipse_arc(arc, self.domain(), parameter, Curve3Kind::CircleArc)?;
                    Ok((
                        left.retaining_parameterization_of(self),
                        right.retaining_parameterization_of(self),
                    ))
                }
                CurveGeometry3::EllipseArc(arc) => {
                    let (left, right) =
                        split_ellipse_arc(arc, self.domain(), parameter, Curve3Kind::EllipseArc)?;
                    Ok((
                        left.retaining_parameterization_of(self),
                        right.retaining_parameterization_of(self),
                    ))
                }
            }
        })
    }

    /// Returns the exact image over a strictly ordered source-parameter range.
    ///
    /// Line, rational-Bézier and planar-image results use their local unit
    /// domain. NURBS and named conic results retain the selected source
    /// interval because their native knot or angle parameterization is
    /// authoritative.
    pub fn subcurve(&self, start: &Real, end: &Real) -> GeometryResult<Self> {
        crate::context::strict(|| {
            if decided_order(compare_reals(start, end, crate::STRICT_PREDICATES))? != Ordering::Less
                || decided_order(compare_reals(
                    start,
                    self.domain().start(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Less
                || decided_order(compare_reals(
                    end,
                    self.domain().end(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Greater
            {
                return Err(GeometryError::InvalidParameterDomain);
            }
            if decided_order(compare_reals(
                start,
                self.domain().start(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
                && decided_order(compare_reals(
                    end,
                    self.domain().end(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Equal
            {
                return Ok(self.clone());
            }
            match &self.data.geometry {
                CurveGeometry3::PlanarImage(image) => image.restricted(start, end),
                CurveGeometry3::Line(_) => {
                    Self::line(self.evaluate_real(start)?, self.evaluate_real(end)?)
                }
                CurveGeometry3::RationalBezier(curve) => {
                    let controls = if decided_order(compare_reals(
                        start,
                        &Real::zero(),
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Equal
                    {
                        split_homogeneous_bezier(curve.homogeneous_controls(), end).0
                    } else {
                        let (_, right) =
                            split_homogeneous_bezier(curve.homogeneous_controls(), start);
                        let relative_end = ((end - start) / (Real::one() - start))
                            .map_err(GeometryError::Numeric)?;
                        split_homogeneous_bezier(&right, &relative_end).0
                    };
                    rational_bezier_from_homogeneous(controls, Some(&curve.constant_coordinates))
                }
                CurveGeometry3::Nurbs(_) => {
                    let mut selected = self.clone();
                    if decided_order(compare_reals(
                        end,
                        selected.domain().end(),
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Less
                    {
                        selected = selected.split_at(end)?.0;
                    }
                    if decided_order(compare_reals(
                        start,
                        selected.domain().start(),
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Greater
                    {
                        selected = selected.split_at(start)?.1;
                    }
                    Ok(selected)
                }
                CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                    let geometry = EllipseArc3 {
                        angle_at_start: ellipse_arc_angle(arc, self.domain(), start),
                        ..arc.clone()
                    };
                    Ok(Self::from_parts(
                        if matches!(self.data.geometry, CurveGeometry3::CircleArc(_)) {
                            CurveGeometry3::CircleArc(geometry)
                        } else {
                            CurveGeometry3::EllipseArc(geometry)
                        },
                        ParameterDomain::new(start.clone(), end.clone())?,
                    )
                    .retaining_parameterization_of(self))
                }
            }
        })
    }

    /// Locates every certified exact parameter whose image is `point`.
    ///
    /// Rational Bézier and NURBS queries retain selected algebraic roots even
    /// without a stored `Real` view. All three coordinates must be certified;
    /// a planar projection alone is not spatial incidence. Self-intersections
    /// may return more than one parameter. Partly constant NURBS preimages
    /// remain an explicit unsupported result, never an incomplete finite set.
    pub fn parameters_of(&self, point: &Point3) -> GeometryResult<CurveParameterLocation> {
        crate::context::strict(|| match &self.data.geometry {
            CurveGeometry3::PlanarImage(image) => image.parameters_of(point),
            CurveGeometry3::Line(line) => locate_line_parameter(self, line, point),
            CurveGeometry3::RationalBezier(curve) => {
                locate_rational_bezier_parameters(self, curve, point)
            }
            CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                locate_ellipse_arc_parameters(self, arc, point)
            }
            CurveGeometry3::Nurbs(curve) => locate_nurbs_parameters(curve, point),
        })
    }

    pub(crate) fn transformed(&self, transform: &Matrix4) -> GeometryResult<Self> {
        self.transformed_with_metric(&TransformMetric::new(transform))
    }

    pub(crate) fn transformed_with_metric(
        &self,
        metric: &TransformMetric<'_>,
    ) -> GeometryResult<Self> {
        let transform = metric.matrix();
        match &self.data.geometry {
            CurveGeometry3::PlanarImage(image) => image.transformed(transform),
            CurveGeometry3::Line(line) => Self::line(
                transform_point(transform, &line.start)?,
                transform_point(transform, &line.end)?,
            ),
            CurveGeometry3::RationalBezier(curve) => Self::rational_bezier(
                transform_points(transform, &curve.control_points)?,
                curve.weights.clone(),
            ),
            CurveGeometry3::Nurbs(curve) => Self::nurbs(
                curve.degree,
                transform_points(transform, &curve.control_points)?,
                curve.weights.clone(),
                curve.knots.clone(),
            ),
            CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc) => {
                let (x, y, scale) = metric.arc_frame(&arc.x, &arc.y)?;
                let transformed = EllipseArcExactData {
                    circle: matches!(self.data.geometry, CurveGeometry3::CircleArc(_)),
                    center: transform_point(transform, &arc.center)?,
                    x,
                    y,
                    x_radius: &arc.x_radius * &scale,
                    y_radius: &arc.y_radius * &scale,
                    domain_start: self.domain().start().clone(),
                    domain_end: self.domain().end().clone(),
                    angle_at_start: arc.angle_at_start.clone(),
                    direction: arc.direction,
                };
                Self::from_exact_data(Curve3ExactData::EllipseArc(Box::new(transformed)))
            }
        }
    }
}

impl RationalBezier3 {
    fn homogeneous_controls(&self) -> &[HomogeneousPoint3] {
        self.homogeneous_controls
            .get_or_init(|| weighted_controls(&self.control_points, &self.weights))
    }
}

impl NurbsCurve3 {
    fn homogeneous_controls(&self) -> &[HomogeneousPoint3] {
        self.homogeneous_controls
            .get_or_init(|| weighted_controls(&self.control_points, &self.weights))
    }
}

impl RationalBezierSurface {
    fn homogeneous_controls(&self) -> &[Vec<HomogeneousPoint3>] {
        self.homogeneous_controls.get_or_init(|| {
            self.control_points
                .iter()
                .zip(&self.weights)
                .map(|(points, weights)| weighted_controls(points, weights))
                .collect()
        })
    }
}

impl NurbsSurface {
    fn homogeneous_controls(&self) -> &[Vec<HomogeneousPoint3>] {
        self.homogeneous_controls.get_or_init(|| {
            self.control_points
                .iter()
                .zip(&self.weights)
                .map(|(points, weights)| weighted_controls(points, weights))
                .collect()
        })
    }
}

impl HomogeneousPoint3 {
    fn from_affine(point: &Point3, weight: &Real) -> Self {
        Self {
            x: &point.x * weight,
            y: &point.y * weight,
            z: &point.z * weight,
            w: weight.clone(),
        }
    }

    fn lerp(&self, other: &Self, parameter: &Real) -> Self {
        let one_minus = Real::one() - parameter;
        Self {
            x: &one_minus * &self.x + parameter * &other.x,
            y: &one_minus * &self.y + parameter * &other.y,
            z: &one_minus * &self.z + parameter * &other.z,
            w: &one_minus * &self.w + parameter * &other.w,
        }
    }

    fn project(&self) -> GeometryResult<Point3> {
        Ok(Point3::new(
            (&self.x / &self.w).map_err(GeometryError::Numeric)?,
            (&self.y / &self.w).map_err(GeometryError::Numeric)?,
            (&self.z / &self.w).map_err(GeometryError::Numeric)?,
        ))
    }
}

/// Supported exact surface family.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum SurfaceKind {
    /// Unbounded parameterized plane.
    Plane,
    /// Circular cylinder.
    Cylinder,
    /// Sphere.
    Sphere,
    /// Right circular cone.
    Cone,
    /// Non-self-intersecting ring torus.
    Torus,
    /// Linear extrusion of a finite exact profile curve.
    Extrusion,
    /// Full revolution of a finite exact profile curve.
    Revolution,
    /// Tensor-product rational Bézier surface.
    RationalBezier,
    /// Finite non-periodic tensor-product NURBS surface.
    Nurbs,
}

/// Parameter direction retained by a tensor-product iso-curve.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum SurfaceIsoAxis {
    /// Vary `u` while holding `v` constant.
    U,
    /// Vary `v` while holding `u` constant.
    V,
}

#[derive(Clone, Debug)]
pub(crate) enum SurfaceExactData {
    Plane {
        origin: Point3,
        u: Vector3,
        v: Vector3,
    },
    Cylinder {
        origin: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        radius: Real,
    },
    Sphere {
        center: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        radius: Real,
    },
    Cone {
        apex: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        semi_angle: Real,
    },
    Torus {
        center: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        major_radius: Real,
        minor_radius: Real,
    },
    Extrusion {
        profile: Box<Curve3ExactData>,
        direction: Vector3,
    },
    Revolution {
        profile: Box<Curve3ExactData>,
        axis_origin: Point3,
        axis: Vector3,
    },
    RationalBezier {
        control_points: Vec<Vec<Point3>>,
        weights: Vec<Vec<Real>>,
    },
    Nurbs {
        u_degree: usize,
        v_degree: usize,
        control_points: Vec<Vec<Point3>>,
        weights: Vec<Vec<Real>>,
        u_knots: Vec<Real>,
        v_knots: Vec<Real>,
    },
}

/// Conservative exact model-space extent of a surface.
#[derive(Clone, Debug)]
pub enum SurfaceBounds {
    /// The surface is unbounded in model space.
    Unbounded,
    /// The entire surface lies inside this exact axis-aligned box.
    Bounded(Box<Aabb>),
}

/// Canonical domain of one surface parameter axis.
#[derive(Clone, Debug)]
pub enum SurfaceParameterDomain {
    /// Every real parameter is accepted.
    Unbounded,
    /// A finite closed exact interval.
    Closed(ParameterDomain),
    /// A periodic parameter with canonical start and positive period.
    Periodic {
        /// Canonical period start.
        start: Real,
        /// Positive exact period.
        period: Real,
    },
    /// A closed lower bound with no upper bound.
    LowerBounded {
        /// Inclusive exact lower bound.
        start: Real,
    },
}

/// Canonical two-dimensional parameter domain of a surface.
#[derive(Clone, Debug)]
pub struct SurfaceDomain {
    u: SurfaceParameterDomain,
    v: SurfaceParameterDomain,
}

impl SurfaceDomain {
    /// Returns the u-axis domain.
    pub const fn u(&self) -> &SurfaceParameterDomain {
        &self.u
    }

    /// Returns the v-axis domain.
    pub const fn v(&self) -> &SurfaceParameterDomain {
        &self.v
    }
}

/// First partial derivatives of a parametric surface.
#[derive(Clone, Debug)]
pub struct SurfacePartials {
    u: Vector3,
    v: Vector3,
}

/// Exact intersection between a finite spatial curve and a surface.
#[derive(Clone, Debug)]
pub enum CurveSurfaceIntersection {
    /// The finite curve does not meet the surface.
    None,
    /// The finite curve meets the surface at isolated exact points.
    Points(Vec<CurveSurfacePoint>),
    /// A finite exact subinterval of the curve belongs to the surface.
    Overlap(crate::ParameterRange),
    /// Multiple coincident ranges, or isolated points together with ranges.
    /// Points contained in an overlap closure are omitted from the point list.
    Components(CurveSurfaceComponents),
    /// The entire finite curve belongs to the surface.
    Contained,
}

/// One isolated exact curve/surface intersection.
#[derive(Clone, Debug)]
pub struct CurveSurfacePoint {
    /// Parameter on the spatial curve.
    pub parameter: Parameter,
    /// Exact model-space point, retaining selected source evidence when needed.
    pub point: GeometricPoint3,
    /// Certified local intersection multiplicity.
    pub multiplicity: IntersectionMultiplicity,
}

/// Complete isolated and coincident components in the spatial curve's chart.
#[derive(Clone, Debug)]
pub struct CurveSurfaceComponents {
    points: Vec<CurveSurfacePoint>,
    overlaps: Vec<crate::ParameterRange>,
}

impl CurveSurfaceComponents {
    /// Borrows isolated contacts outside every coincident range.
    pub fn points(&self) -> &[CurveSurfacePoint] {
        &self.points
    }

    /// Borrows the disjoint maximal closed coincident ranges.
    pub fn overlaps(&self) -> &[crate::ParameterRange] {
        &self.overlaps
    }
}

/// Certified first-order classification of an isolated intersection.
///
/// For isolated equation roots this distinguishes a simple zero from a repeated zero of the supporting
/// equation; it does not report an exact integer multiplicity. At a spline
/// joint, `Simple` requires simple zeros on every incident span, while `Tangent`
/// records a repeated zero on at least one incident span. Neither establishes
/// smoothness or the global crossing direction at a nonsmooth joint.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum IntersectionMultiplicity {
    /// Each incident span has a nonzero first derivative of its contact equation.
    Simple,
    /// At least one incident span has zero first derivative of its contact equation.
    Tangent,
    /// A coincident support meets the finite surface only at a clipping boundary.
    /// This does not claim a simple or repeated root of the supporting equation.
    Boundary,
}

/// Exact retained intersection between two supported parameterized surfaces.
#[derive(Clone, Debug)]
pub enum SurfaceSurfaceIntersection {
    /// The surfaces do not meet.
    None,
    /// The surfaces denote the same complete carrier.
    Coincident,
    /// The intersection is the complete bounded domain of one surface,
    /// exactly contained in the other surface's carrier.
    ContainedSurface(SurfaceIntersectionOperand),
    /// The surfaces touch at one exact point.
    Point(Box<Point3>),
    /// The surfaces meet at multiple isolated exact points.
    Points(Vec<Point3>),
    /// Two planes meet in an unbounded exact line.
    Line(Box<SurfaceIntersectionLine>),
    /// The surfaces meet in multiple unbounded exact lines.
    Lines(Vec<SurfaceIntersectionLine>),
    /// The surfaces meet in one exact lower-bounded ray.
    Ray(Box<SurfaceIntersectionRay>),
    /// The surfaces meet in multiple exact lower-bounded rays.
    Rays(Vec<SurfaceIntersectionRay>),
    /// The surfaces meet in one exact full circle.
    Circle(Curve3),
    /// The surfaces meet in multiple exact full circles.
    Circles(Vec<Curve3>),
    /// The surfaces meet in one exact full noncircular ellipse.
    Ellipse(Curve3),
    /// Two finite carriers meet in one exact curve with retained parameter
    /// images on both surfaces.
    Curve(Box<SurfaceIntersectionCurve>),
    /// Two finite carriers meet in multiple disjoint exact curves with
    /// retained parameter images on both surfaces.
    Curves(Vec<SurfaceIntersectionCurve>),
    /// The surfaces meet in exact components of more than one dimension.
    Components(Box<SurfaceIntersectionComponents>),
}

/// Exact mixed-dimensional components of one surface/surface intersection.
///
/// Spatial curves appear in `curves` when an exact parameter image on both
/// authored carriers is unavailable. Curves in `surface_curves` retain both
/// exact pcurves. At least two of the three collections are nonempty in
/// relations produced by [`Surface::intersect_surface`].
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionComponents {
    points: Vec<Point3>,
    curves: Vec<Curve3>,
    surface_curves: Vec<SurfaceIntersectionCurve>,
}

impl SurfaceIntersectionComponents {
    pub(crate) fn new(
        points: Vec<Point3>,
        curves: Vec<Curve3>,
        surface_curves: Vec<SurfaceIntersectionCurve>,
    ) -> Self {
        debug_assert!(
            usize::from(!points.is_empty())
                + usize::from(!curves.is_empty())
                + usize::from(!surface_curves.is_empty())
                >= 2
        );
        Self {
            points,
            curves,
            surface_curves,
        }
    }

    /// Returns the isolated exact point components.
    pub fn points(&self) -> &[Point3] {
        &self.points
    }

    /// Returns exact spatial curve components without retained pcurves.
    pub fn curves(&self) -> &[Curve3] {
        &self.curves
    }

    /// Returns exact curve components with pcurves on both surfaces.
    pub fn surface_curves(&self) -> &[SurfaceIntersectionCurve] {
        &self.surface_curves
    }

    fn swapped(mut self) -> Self {
        self.surface_curves = self
            .surface_curves
            .into_iter()
            .map(SurfaceIntersectionCurve::swapped)
            .collect();
        self
    }
}

/// One exact finite surface/surface intersection curve and its two pcurves.
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionCurve {
    curve: Curve3,
    first_pcurve: SurfaceIntersectionPcurve,
    second_pcurve: SurfaceIntersectionPcurve,
    image_certificates: [bool; 2],
    first_boundary_contacts: SurfaceIntersectionBoundaryContacts,
    second_boundary_contacts: SurfaceIntersectionBoundaryContacts,
}

/// Exact model-space support evidence for one trimmed face-boundary contact.
///
/// The support curve and its canonical parameter survive subsequent edge
/// splits. This lets topology recover the current edge or vertex by identity
/// instead of re-solving incidence from independently formed coordinates.
#[derive(Clone, Debug)]
pub(crate) struct SurfaceIntersectionBoundaryContact {
    curve: Curve3,
    parameter: Real,
    affine_parameter: Option<Real>,
    pcurve_point: CurvePoint2,
    spatial_point: Point3,
}

impl SurfaceIntersectionBoundaryContact {
    pub(crate) fn new(
        curve: Curve3,
        parameter: Real,
        affine_parameter: Option<Real>,
        pcurve_point: CurvePoint2,
        spatial_point: Point3,
    ) -> Self {
        Self {
            curve,
            parameter,
            affine_parameter,
            pcurve_point,
            spatial_point,
        }
    }

    pub(crate) const fn curve(&self) -> &Curve3 {
        &self.curve
    }

    pub(crate) const fn parameter(&self) -> &Real {
        &self.parameter
    }

    /// The same spatial preimage before canonicalization, retained from a
    /// certified affine pcurve contact. All incident affine uses can consume
    /// this representative without reconstructing the contact's coordinates.
    pub(crate) const fn affine_parameter(&self) -> Option<&Real> {
        self.affine_parameter.as_ref()
    }

    pub(crate) const fn pcurve_point(&self) -> &CurvePoint2 {
        &self.pcurve_point
    }

    pub(crate) const fn spatial_point(&self) -> &Point3 {
        &self.spatial_point
    }
}

#[derive(Clone, Debug, Default)]
struct SurfaceIntersectionBoundaryContacts {
    start: Vec<SurfaceIntersectionBoundaryContact>,
    end: Vec<SurfaceIntersectionBoundaryContact>,
}

/// Identifies an operand of a surface intersection.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub enum SurfaceIntersectionOperand {
    /// The first surface passed to the intersection query.
    First,
    /// The second surface passed to the intersection query.
    Second,
}

impl SurfaceIntersectionOperand {
    const fn swapped(self) -> Self {
        match self {
            Self::First => Self::Second,
            Self::Second => Self::First,
        }
    }
}

/// Exact surface-parameter image of a retained intersection curve.
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionPcurve {
    domain: ParameterDomain,
    source_scale: Real,
    source_offset: Real,
    mapping: SurfaceIntersectionPcurveMapping,
}

/// Materialized exact Hypercurve pcurve and its spatial-parameter map.
#[derive(Clone, Debug)]
pub struct MaterializedSurfacePcurve {
    curve: Curve2,
    correspondence: SurfacePcurveCorrespondence,
}

/// Exact correspondence from a materialized pcurve to its retained spatial
/// intersection curve.
#[derive(Clone, Debug)]
pub enum SurfacePcurveCorrespondence {
    /// `spatial_parameter = scale * pcurve_parameter + offset`.
    Affine {
        /// Nonzero exact scale.
        scale: Real,
        /// Exact offset.
        offset: Real,
    },
    /// The pcurve's directed angular sweep fraction spans the spatial curve
    /// domain.
    AngularSweep {
        /// Spatial parameter at the pcurve sweep start.
        spatial_start: Real,
        /// Spatial parameter at the pcurve sweep end.
        spatial_end: Real,
    },
}

impl SurfacePcurveCorrespondence {
    /// Returns affine coefficients, or `None` for angular sweep
    /// correspondence.
    pub const fn affine_coefficients(&self) -> Option<(&Real, &Real)> {
        match self {
            Self::Affine { scale, offset } => Some((scale, offset)),
            Self::AngularSweep { .. } => None,
        }
    }
}

#[derive(Clone, Debug)]
enum SurfaceIntersectionPcurveMapping {
    Unsupported,
    RetainedCurve {
        curve: Curve2,
    },
    PlaneProjection {
        spatial: Curve3,
        origin: Point3,
        u: Vector3,
        v: Vector3,
    },
    LinearPlaneSection {
        profile: Curve3,
        plane_origin: Point3,
        plane_normal: Vector3,
        denominator: Real,
        profile_axis: TensorAxis,
        coefficient_scale: Real,
        coefficient_offset: Real,
    },
    TensorIsoV {
        constant: Real,
    },
    TensorIsoU {
        constant: Real,
    },
}

#[derive(Clone, Copy, Debug)]
enum TensorAxis {
    U,
    V,
}

impl SurfaceIntersectionCurve {
    /// Moves one iso pcurve into an equivalent periodic surface chart. The
    /// caller proves that each nonzero displacement is a whole surface period.
    pub(crate) fn translated_iso_pcurve(
        &self,
        operand: SurfaceIntersectionOperand,
        u: &Real,
        v: &Real,
    ) -> GeometryResult<Self> {
        let mut result = self.clone();
        let pcurve = match operand {
            SurfaceIntersectionOperand::First => &mut result.first_pcurve,
            SurfaceIntersectionOperand::Second => &mut result.second_pcurve,
        };
        match &mut pcurve.mapping {
            SurfaceIntersectionPcurveMapping::TensorIsoU { constant } => {
                *constant += u;
                pcurve.source_offset += v;
            }
            SurfaceIntersectionPcurveMapping::TensorIsoV { constant } => {
                *constant += v;
                pcurve.source_offset += u;
            }
            _ => return Err(GeometryError::UnsupportedIntersection),
        }
        Ok(result)
    }

    pub(crate) fn new(
        curve: Curve3,
        first_pcurve: SurfaceIntersectionPcurve,
        second_pcurve: SurfaceIntersectionPcurve,
    ) -> Self {
        Self {
            curve,
            first_pcurve,
            second_pcurve,
            image_certificates: [true, true],
            first_boundary_contacts: SurfaceIntersectionBoundaryContacts::default(),
            second_boundary_contacts: SurfaceIntersectionBoundaryContacts::default(),
        }
    }

    pub(crate) fn on_plane(curve: Curve3, surface: &Surface) -> GeometryResult<Self> {
        Self::on_coincident_planes(curve, surface, surface)
    }

    /// Retains both charts after the caller proves coincident planes and that
    /// the curve lies on their common support.
    pub(crate) fn on_coincident_planes(
        curve: Curve3,
        first: &Surface,
        second: &Surface,
    ) -> GeometryResult<Self> {
        let (SurfaceGeometry::Plane(first), SurfaceGeometry::Plane(second)) =
            (&first.data.geometry, &second.data.geometry)
        else {
            return Err(GeometryError::UnsupportedIntersection);
        };
        Ok(Self::new(
            curve.clone(),
            SurfaceIntersectionPcurve::plane_projection(curve.clone(), first),
            SurfaceIntersectionPcurve::plane_projection(curve, second),
        ))
    }

    pub(crate) fn on_single_plane(
        curve: Curve3,
        surface: &Surface,
        operand: SurfaceIntersectionOperand,
    ) -> GeometryResult<Self> {
        let SurfaceGeometry::Plane(plane) = &surface.data.geometry else {
            return Err(GeometryError::UnsupportedIntersection);
        };
        let plane_pcurve = SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane);
        let unavailable = SurfaceIntersectionPcurve::unsupported(curve.domain().clone());
        let mut intersection = match operand {
            SurfaceIntersectionOperand::First => Self::new(curve, plane_pcurve, unavailable),
            SurfaceIntersectionOperand::Second => Self::new(curve, unavailable, plane_pcurve),
        };
        intersection.image_certificates = match operand {
            SurfaceIntersectionOperand::First => [true, false],
            SurfaceIntersectionOperand::Second => [false, true],
        };
        Ok(intersection)
    }

    #[cfg(test)]
    pub(crate) fn from_exact_pcurves(
        curve: Curve3,
        first_pcurve: Curve2,
        second_pcurve: Curve2,
    ) -> GeometryResult<Self> {
        let mut intersection = Self::new(
            curve,
            SurfaceIntersectionPcurve::retained_curve(first_pcurve)?,
            SurfaceIntersectionPcurve::retained_curve(second_pcurve)?,
        );
        intersection.image_certificates = [false, false];
        Ok(intersection)
    }

    pub(crate) fn from_certified_exact_pcurves(
        curve: Curve3,
        first_pcurve: Curve2,
        second_pcurve: Curve2,
    ) -> GeometryResult<Self> {
        Ok(Self::new(
            curve,
            SurfaceIntersectionPcurve::retained_curve(first_pcurve)?,
            SurfaceIntersectionPcurve::retained_curve(second_pcurve)?,
        ))
    }

    pub(crate) fn from_iso_v_pcurves(
        curve: Curve3,
        first_constant: Real,
        second_constant: Real,
    ) -> Self {
        let domain = curve.domain().clone();
        Self::new(
            curve,
            SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), first_constant),
            SurfaceIntersectionPcurve::tensor_iso_v(domain, second_constant),
        )
    }

    /// Retains a validated edge's affine iso-parameter pcurve on two surfaces
    /// already proved to have the same complete parameterization.
    pub(crate) fn from_certified_iso_boundary(
        curve: Curve3,
        pcurve: &Pcurve,
        edge_scale: &Real,
        edge_offset: &Real,
    ) -> GeometryResult<Option<Self>> {
        let Some(line) = pcurve.line_segment() else {
            return Ok(None);
        };
        let dx = line.end().x() - line.start().x();
        let dy = line.end().y() - line.start().y();
        let (constant, axis, delta, start) =
            if decided_order(compare_reals(&dx, &Real::zero(), crate::STRICT_PREDICATES))?
                == Ordering::Equal
            {
                (
                    line.start().x().clone(),
                    TensorAxis::U,
                    dy,
                    line.start().y(),
                )
            } else if decided_order(compare_reals(&dy, &Real::zero(), crate::STRICT_PREDICATES))?
                == Ordering::Equal
            {
                (
                    line.start().y().clone(),
                    TensorAxis::V,
                    dx,
                    line.start().x(),
                )
            } else {
                return Ok(None);
            };
        let scale = (delta / edge_scale).map_err(GeometryError::Numeric)?;
        let offset = start - &scale * edge_offset;
        let pcurve = SurfaceIntersectionPcurve::tensor_iso(
            curve.domain().clone(),
            constant,
            axis,
            scale,
            offset,
        );
        Ok(Some(Self::new(curve, pcurve.clone(), pcurve)))
    }

    fn swapped(mut self) -> Self {
        std::mem::swap(&mut self.first_pcurve, &mut self.second_pcurve);
        self.image_certificates.swap(0, 1);
        std::mem::swap(
            &mut self.first_boundary_contacts,
            &mut self.second_boundary_contacts,
        );
        self
    }

    pub(crate) fn with_boundary_contacts(
        mut self,
        operand: SurfaceIntersectionOperand,
        start: Vec<SurfaceIntersectionBoundaryContact>,
        end: Vec<SurfaceIntersectionBoundaryContact>,
    ) -> Self {
        let contacts = match operand {
            SurfaceIntersectionOperand::First => &mut self.first_boundary_contacts,
            SurfaceIntersectionOperand::Second => &mut self.second_boundary_contacts,
        };
        contacts.start = start;
        contacts.end = end;
        self
    }

    /// Returns the exact model-space intersection curve.
    pub const fn curve(&self) -> &Curve3 {
        &self.curve
    }

    /// Returns the exact pcurve on the first surface operand.
    pub const fn first_pcurve(&self) -> &SurfaceIntersectionPcurve {
        &self.first_pcurve
    }

    /// Returns the exact pcurve on the second surface operand.
    pub const fn second_pcurve(&self) -> &SurfaceIntersectionPcurve {
        &self.second_pcurve
    }

    /// Returns the retained pcurve for one surface operand.
    pub const fn pcurve(&self, operand: SurfaceIntersectionOperand) -> &SurfaceIntersectionPcurve {
        match operand {
            SurfaceIntersectionOperand::First => &self.first_pcurve,
            SurfaceIntersectionOperand::Second => &self.second_pcurve,
        }
    }

    pub(crate) const fn has_image_certificate(&self, operand: SurfaceIntersectionOperand) -> bool {
        match operand {
            SurfaceIntersectionOperand::First => self.image_certificates[0],
            SurfaceIntersectionOperand::Second => self.image_certificates[1],
        }
    }

    pub(crate) fn start_boundary_contacts(
        &self,
        operand: SurfaceIntersectionOperand,
    ) -> &[SurfaceIntersectionBoundaryContact] {
        match operand {
            SurfaceIntersectionOperand::First => &self.first_boundary_contacts.start,
            SurfaceIntersectionOperand::Second => &self.second_boundary_contacts.start,
        }
    }

    pub(crate) fn end_boundary_contacts(
        &self,
        operand: SurfaceIntersectionOperand,
    ) -> &[SurfaceIntersectionBoundaryContact] {
        match operand {
            SurfaceIntersectionOperand::First => &self.first_boundary_contacts.end,
            SurfaceIntersectionOperand::Second => &self.second_boundary_contacts.end,
        }
    }

    /// Restricts the spatial curve and both exact pcurve mappings to one
    /// increasing represented parameter interval.
    pub fn subcurve(&self, start: &Real, end: &Real) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let curve = self.curve.subcurve(start, end)?;
            let first_pcurve =
                self.first_pcurve
                    .reparameterized_subcurve(start, end, curve.domain())?;
            let second_pcurve =
                self.second_pcurve
                    .reparameterized_subcurve(start, end, curve.domain())?;
            let retain_start = decided_order(compare_reals(
                start,
                self.curve.domain().start(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal;
            let retain_end = decided_order(compare_reals(
                end,
                self.curve.domain().end(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal;
            Ok(Self {
                curve,
                first_pcurve,
                second_pcurve,
                image_certificates: self.image_certificates,
                first_boundary_contacts: SurfaceIntersectionBoundaryContacts {
                    start: if retain_start {
                        self.first_boundary_contacts.start.clone()
                    } else {
                        Vec::new()
                    },
                    end: if retain_end {
                        self.first_boundary_contacts.end.clone()
                    } else {
                        Vec::new()
                    },
                },
                second_boundary_contacts: SurfaceIntersectionBoundaryContacts {
                    start: if retain_start {
                        self.second_boundary_contacts.start.clone()
                    } else {
                        Vec::new()
                    },
                    end: if retain_end {
                        self.second_boundary_contacts.end.clone()
                    } else {
                        Vec::new()
                    },
                },
            })
        })
    }

    /// Returns the same exact spatial and two-operand parameter-space images
    /// with one common reversed traversal.
    pub fn reversed(&self) -> GeometryResult<Self> {
        crate::context::strict(|| {
            Ok(Self {
                curve: self.curve.reversed()?,
                first_pcurve: self.first_pcurve.reversed()?,
                second_pcurve: self.second_pcurve.reversed()?,
                image_certificates: self.image_certificates,
                first_boundary_contacts: SurfaceIntersectionBoundaryContacts {
                    start: self.first_boundary_contacts.end.clone(),
                    end: self.first_boundary_contacts.start.clone(),
                },
                second_boundary_contacts: SurfaceIntersectionBoundaryContacts {
                    start: self.second_boundary_contacts.end.clone(),
                    end: self.second_boundary_contacts.start.clone(),
                },
            })
        })
    }
}

impl SurfaceIntersectionPcurve {
    pub(crate) fn materializes_native_boundary_segment(&self) -> bool {
        self.materializes_native_line()
            || match &self.mapping {
                SurfaceIntersectionPcurveMapping::PlaneProjection { spatial, .. } => {
                    spatial.kind() == Curve3Kind::CircleArc
                }
                SurfaceIntersectionPcurveMapping::RetainedCurve { curve } => {
                    matches!(curve.geometry(), Some(CurveGeometry2::CircularArc(_)))
                }
                _ => false,
            }
    }

    /// Whether materialization uses a native line carrier. This describes the
    /// retained representation, not a geometric straightness classification:
    /// rational/spline mappings retain their families even when collinear.
    pub(crate) fn materializes_native_line(&self) -> bool {
        match &self.mapping {
            SurfaceIntersectionPcurveMapping::TensorIsoU { .. }
            | SurfaceIntersectionPcurveMapping::TensorIsoV { .. } => true,
            SurfaceIntersectionPcurveMapping::PlaneProjection { spatial, .. } => {
                spatial.kind() == Curve3Kind::Line
            }
            SurfaceIntersectionPcurveMapping::LinearPlaneSection { profile, .. } => {
                profile.kind() == Curve3Kind::Line
            }
            SurfaceIntersectionPcurveMapping::RetainedCurve { curve } => {
                matches!(curve.geometry(), Some(CurveGeometry2::Line(_)))
            }
            SurfaceIntersectionPcurveMapping::Unsupported => false,
        }
    }

    pub(crate) fn is_iso_parameter_line(&self) -> bool {
        matches!(
            self.mapping,
            SurfaceIntersectionPcurveMapping::TensorIsoU { .. }
                | SurfaceIntersectionPcurveMapping::TensorIsoV { .. }
        )
    }

    fn unsupported(domain: ParameterDomain) -> Self {
        Self {
            domain,
            source_scale: Real::one(),
            source_offset: Real::zero(),
            mapping: SurfaceIntersectionPcurveMapping::Unsupported,
        }
    }

    fn retained_curve(curve: Curve2) -> GeometryResult<Self> {
        let curve_domain = curve.parameter_domain();
        let (curve_domain_start, curve_domain_end) = curve_domain
            .scalar_endpoints()
            .ok_or(GeometryError::UnsupportedPcurveContour)?;
        Ok(Self {
            domain: ParameterDomain::new(curve_domain_start.clone(), curve_domain_end.clone())?,
            source_scale: Real::one(),
            source_offset: Real::zero(),
            mapping: SurfaceIntersectionPcurveMapping::RetainedCurve { curve },
        })
    }

    fn plane_projection(curve: Curve3, plane: &PlaneSurface) -> Self {
        Self {
            domain: curve.domain().clone(),
            source_scale: Real::one(),
            source_offset: Real::zero(),
            mapping: SurfaceIntersectionPcurveMapping::PlaneProjection {
                spatial: curve,
                origin: plane.origin.clone(),
                u: plane.u.clone(),
                v: plane.v.clone(),
            },
        }
    }

    fn linear_plane_section(
        profile: Curve3,
        plane: &PlaneSurface,
        denominator: Real,
        profile_axis: TensorAxis,
        coefficient_scale: Real,
        coefficient_offset: Real,
    ) -> Self {
        Self {
            domain: profile.domain().clone(),
            source_scale: Real::one(),
            source_offset: Real::zero(),
            mapping: SurfaceIntersectionPcurveMapping::LinearPlaneSection {
                profile,
                plane_origin: plane.origin.clone(),
                plane_normal: plane.u.cross(&plane.v),
                denominator,
                profile_axis,
                coefficient_scale,
                coefficient_offset,
            },
        }
    }

    fn tensor_iso_v(domain: ParameterDomain, constant: Real) -> Self {
        Self {
            domain,
            source_scale: Real::one(),
            source_offset: Real::zero(),
            mapping: SurfaceIntersectionPcurveMapping::TensorIsoV { constant },
        }
    }

    fn tensor_iso(
        domain: ParameterDomain,
        constant: Real,
        profile_axis: TensorAxis,
        coefficient_scale: Real,
        coefficient_offset: Real,
    ) -> Self {
        Self {
            domain,
            source_scale: coefficient_scale,
            source_offset: coefficient_offset,
            mapping: match profile_axis {
                TensorAxis::U => SurfaceIntersectionPcurveMapping::TensorIsoU { constant },
                TensorAxis::V => SurfaceIntersectionPcurveMapping::TensorIsoV { constant },
            },
        }
    }

    /// Returns the pcurve's parameter domain, shared exactly with the spatial
    /// intersection curve.
    pub const fn domain(&self) -> &ParameterDomain {
        &self.domain
    }

    pub(crate) fn is_available(&self) -> bool {
        !matches!(self.mapping, SurfaceIntersectionPcurveMapping::Unsupported)
    }

    /// Evaluates the exact surface parameter corresponding to `parameter` on
    /// the retained spatial curve.
    pub fn point_at(&self, parameter: &Real) -> GeometryResult<Point2> {
        crate::context::strict(|| {
            if !self.domain.contains(parameter)? {
                return Err(GeometryError::ParameterOutsideDomain);
            }
            let source_parameter = &self.source_scale * parameter + &self.source_offset;
            match &self.mapping {
                SurfaceIntersectionPcurveMapping::Unsupported => {
                    Err(GeometryError::UnsupportedIntersection)
                }
                SurfaceIntersectionPcurveMapping::RetainedCurve { curve } => {
                    let point = curve.point_at(&source_parameter.clone().into())?;
                    let point = point
                        .coordinates()
                        .ok_or(GeometryError::UnsupportedPcurveContour)?;
                    Ok(Point2::new(point.x().clone(), point.y().clone()))
                }
                SurfaceIntersectionPcurveMapping::PlaneProjection {
                    spatial,
                    origin,
                    u,
                    v,
                } => project_point_to_plane_frame(
                    origin,
                    u,
                    v,
                    &spatial.evaluate_real(&source_parameter)?,
                ),
                SurfaceIntersectionPcurveMapping::LinearPlaneSection {
                    profile,
                    plane_origin,
                    plane_normal,
                    denominator,
                    profile_axis,
                    coefficient_scale,
                    coefficient_offset,
                    ..
                } => {
                    let profile_point = profile.evaluate_real(&source_parameter)?;
                    let normalized_coefficient =
                        (plane_normal.dot(&(plane_origin - &profile_point)) / denominator)
                            .map_err(GeometryError::Numeric)?;
                    let coefficient =
                        coefficient_offset + coefficient_scale * normalized_coefficient;
                    Ok(match profile_axis {
                        TensorAxis::U => Point2::new(source_parameter, coefficient),
                        TensorAxis::V => Point2::new(coefficient, source_parameter),
                    })
                }
                SurfaceIntersectionPcurveMapping::TensorIsoV { constant } => {
                    Ok(Point2::new(source_parameter, constant.clone()))
                }
                SurfaceIntersectionPcurveMapping::TensorIsoU { constant } => {
                    Ok(Point2::new(constant.clone(), source_parameter))
                }
            }
        })
    }

    /// Restricts this exact surface-parameter mapping without changing its
    /// authoritative spatial-curve parameterization.
    pub fn subcurve(&self, start: &Real, end: &Real) -> GeometryResult<Self> {
        crate::context::strict(|| {
            if !self.domain.contains(start)? || !self.domain.contains(end)? {
                return Err(GeometryError::ParameterOutsideDomain);
            }
            Ok(Self {
                domain: ParameterDomain::new(start.clone(), end.clone())?,
                source_scale: self.source_scale.clone(),
                source_offset: self.source_offset.clone(),
                mapping: self.mapping.clone(),
            })
        })
    }

    /// Returns the same exact parameter-space image with reversed traversal.
    pub fn reversed(&self) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let domain_sum = self.domain.start() + self.domain.end();
            Ok(Self {
                domain: self.domain.clone(),
                source_scale: -self.source_scale.clone(),
                source_offset: &self.source_scale * domain_sum + &self.source_offset,
                mapping: self.mapping.clone(),
            })
        })
    }

    /// Materializes this retained mapping as one exact Hypercurve carrier.
    ///
    /// The returned correspondence maps native pcurve parameters to spatial
    /// parameters, including angular sweep correspondence for circular arcs.
    /// A mapping that cannot be represented by one Hypercurve carrier remains
    /// explicitly unsupported.
    pub fn materialize(&self) -> GeometryResult<MaterializedSurfacePcurve> {
        crate::context::strict(|| {
            let source_start = &self.source_scale * self.domain.start() + &self.source_offset;
            let source_end = &self.source_scale * self.domain.end() + &self.source_offset;
            let source_order = decided_order(compare_reals(
                &source_start,
                &source_end,
                crate::STRICT_PREDICATES,
            ))?;
            if source_order == Ordering::Equal {
                return Err(GeometryError::InvalidParameterDomain);
            }
            let descending = source_order == Ordering::Greater;
            let (ordered_source_start, ordered_source_end) = if descending {
                (&source_end, &source_start)
            } else {
                (&source_start, &source_end)
            };
            let orient_curve = |curve: Curve2| -> GeometryResult<Curve2> {
                if descending {
                    curve.reversed().map_err(GeometryError::from)
                } else {
                    Ok(curve)
                }
            };
            // Materialized iso coordinates become boundary coefficients and
            // are interpolated by later edits. Preserve scalar-proven compact
            // angular forms before that expansion; no recognition limit or
            // spatial parameter correspondence changes.
            let compact =
                |value: &Real| value.compact_pi_laurent().unwrap_or_else(|| value.clone());
            match &self.mapping {
                SurfaceIntersectionPcurveMapping::Unsupported => {
                    Err(GeometryError::UnsupportedIntersection)
                }
                SurfaceIntersectionPcurveMapping::RetainedCurve { curve } => {
                    let domain = curve.parameter_domain();
                    let restricted = if decided_order(compare_reals(
                        ordered_source_start,
                        (domain.start())
                            .scalar()
                            .ok_or(GeometryError::UnsupportedPcurveContour)?,
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Equal
                        && decided_order(compare_reals(
                            ordered_source_end,
                            (domain.end())
                                .scalar()
                                .ok_or(GeometryError::UnsupportedPcurveContour)?,
                            crate::STRICT_PREDICATES,
                        ))? == Ordering::Equal
                    {
                        curve.clone()
                    } else {
                        curve.subcurve(
                            ordered_source_start.clone().into(),
                            ordered_source_end.clone().into(),
                        )?
                    };
                    materialized_surface_pcurve_from_matching_domains(
                        orient_curve(restricted)?,
                        &self.domain,
                    )
                }
                SurfaceIntersectionPcurveMapping::PlaneProjection {
                    spatial,
                    origin,
                    u,
                    v,
                } => {
                    let source_curve =
                        spatial.subcurve(ordered_source_start, ordered_source_end)?;
                    let curve = orient_curve(
                        project_curve_to_plane_frame(&source_curve, origin, u, v)?
                            .ok_or(GeometryError::UnsupportedIntersection)?,
                    )?;
                    if curve.family() == CurveFamily2::CircularArc {
                        Ok(MaterializedSurfacePcurve {
                            curve,
                            correspondence: SurfacePcurveCorrespondence::AngularSweep {
                                spatial_start: self.domain.start().clone(),
                                spatial_end: self.domain.end().clone(),
                            },
                        })
                    } else {
                        materialized_surface_pcurve_from_matching_domains(curve, &self.domain)
                    }
                }
                SurfaceIntersectionPcurveMapping::LinearPlaneSection { .. } => {
                    let mut carriers = self
                        .clipping_carriers()?
                        .ok_or(GeometryError::UnsupportedIntersection)?;
                    if carriers.len() == 1 {
                        return Ok(carriers.remove(0));
                    }
                    let mut curves = Vec::with_capacity(carriers.len());
                    let mut boundaries = Vec::with_capacity(carriers.len() + 1);
                    for carrier in carriers {
                        let domain = carrier.curve.parameter_domain();
                        let (start, end) = domain
                            .scalar_endpoints()
                            .ok_or(GeometryError::UnsupportedPcurveContour)?;
                        if boundaries.is_empty() {
                            boundaries.push(carrier.spatial_parameter_at(start)?);
                        }
                        boundaries.push(carrier.spatial_parameter_at(end)?);
                        curves.push(carrier.curve);
                    }
                    materialized_surface_pcurve_from_matching_domains(
                        concatenate_rational_bezier_spans_as_nurbs(&curves, &boundaries)?,
                        &self.domain,
                    )
                }
                SurfaceIntersectionPcurveMapping::TensorIsoV { constant } => {
                    let curve = orient_curve(Curve2::from(LineSeg2::try_new(
                        CurvePoint2::new(compact(ordered_source_start), compact(constant)),
                        CurvePoint2::new(compact(ordered_source_end), compact(constant)),
                    )?))?;
                    materialized_surface_pcurve_from_matching_domains(curve, &self.domain)
                }
                SurfaceIntersectionPcurveMapping::TensorIsoU { constant } => {
                    let curve = orient_curve(Curve2::from(LineSeg2::try_new(
                        CurvePoint2::new(compact(constant), compact(ordered_source_start)),
                        CurvePoint2::new(compact(constant), compact(ordered_source_end)),
                    )?))?;
                    materialized_surface_pcurve_from_matching_domains(curve, &self.domain)
                }
            }
        })
    }

    fn reparameterized_subcurve(
        &self,
        start: &Real,
        end: &Real,
        target_domain: &ParameterDomain,
    ) -> GeometryResult<Self> {
        if !self.domain.contains(start)? || !self.domain.contains(end)? {
            return Err(GeometryError::ParameterOutsideDomain);
        }
        let source_start = &self.source_scale * start + &self.source_offset;
        let source_end = &self.source_scale * end + &self.source_offset;
        let target_span = target_domain.end() - target_domain.start();
        let source_scale =
            ((&source_end - &source_start) / target_span).map_err(GeometryError::Numeric)?;
        let source_offset = source_start - &source_scale * target_domain.start();
        Ok(Self {
            domain: target_domain.clone(),
            source_scale,
            source_offset,
            mapping: self.mapping.clone(),
        })
    }

    pub(crate) fn clipping_carriers(
        &self,
    ) -> GeometryResult<Option<Vec<MaterializedSurfacePcurve>>> {
        let SurfaceIntersectionPcurveMapping::LinearPlaneSection {
            profile,
            plane_origin,
            plane_normal,
            denominator,
            profile_axis,
            coefficient_scale,
            coefficient_offset,
        } = &self.mapping
        else {
            return match self.materialize() {
                Ok(carrier) => Ok(Some(vec![carrier])),
                Err(GeometryError::UnsupportedIntersection) => Ok(None),
                Err(error) => Err(error),
            };
        };
        // Keep the native rational spans available to the trimming kernel.
        // Restriction and reversal must transport both their geometry and
        // parameters; the source profile's domain need not equal this trace's.
        let Some(carriers) = linear_section_pcurve_carriers(
            profile,
            plane_origin,
            plane_normal,
            denominator,
            *profile_axis,
            coefficient_scale,
            coefficient_offset,
        )?
        else {
            return Ok(None);
        };
        let source_start = &self.source_scale * self.domain.start() + &self.source_offset;
        let source_end = &self.source_scale * self.domain.end() + &self.source_offset;
        let descending = decided_order(compare_reals(
            &source_start,
            &source_end,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Greater;
        let (source_start, source_end) = if descending {
            (source_end, source_start)
        } else {
            (source_start, source_end)
        };
        let mut result = Vec::with_capacity(carriers.len());
        for carrier in carriers {
            let (scale, offset) = carrier
                .correspondence
                .affine_coefficients()
                .ok_or(GeometryError::UnsupportedPcurveContour)?;
            let domain = carrier.curve.parameter_domain();
            let (local_start, local_end) = domain
                .scalar_endpoints()
                .ok_or(GeometryError::UnsupportedPcurveContour)?;
            let carrier_start = scale * local_start + offset;
            let carrier_end = scale * local_end + offset;
            let overlap_start = if decided_order(compare_reals(
                &source_start,
                &carrier_start,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Greater
            {
                source_start.clone()
            } else {
                carrier_start
            };
            let overlap_end = if decided_order(compare_reals(
                &source_end,
                &carrier_end,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
            {
                source_end.clone()
            } else {
                carrier_end
            };
            if decided_order(compare_reals(
                &overlap_start,
                &overlap_end,
                crate::STRICT_PREDICATES,
            ))? != Ordering::Less
            {
                continue;
            }
            let start = ((&overlap_start - offset) / scale).map_err(GeometryError::Numeric)?;
            let end = ((&overlap_end - offset) / scale).map_err(GeometryError::Numeric)?;
            let mut curve =
                if decided_order(compare_reals(&start, local_start, crate::STRICT_PREDICATES))?
                    == Ordering::Equal
                    && decided_order(compare_reals(&end, local_end, crate::STRICT_PREDICATES))?
                        == Ordering::Equal
                {
                    carrier.curve
                } else {
                    carrier.curve.subcurve(start.into(), end.into())?
                };
            let mut spatial_start = ((overlap_start - &self.source_offset) / &self.source_scale)
                .map_err(GeometryError::Numeric)?;
            let mut spatial_end = ((overlap_end - &self.source_offset) / &self.source_scale)
                .map_err(GeometryError::Numeric)?;
            if descending {
                curve = curve.reversed()?;
                std::mem::swap(&mut spatial_start, &mut spatial_end);
            }
            result.push(materialized_surface_pcurve_from_matching_domains(
                curve,
                &ParameterDomain::new(spatial_start, spatial_end)?,
            )?);
        }
        if descending {
            result.reverse();
        }
        Ok(Some(result))
    }
}

impl MaterializedSurfacePcurve {
    /// Returns the exact Hypercurve carrier.
    pub const fn curve(&self) -> &Curve2 {
        &self.curve
    }

    /// Returns the exact pcurve-to-spatial parameter correspondence.
    pub const fn correspondence(&self) -> &SurfacePcurveCorrespondence {
        &self.correspondence
    }

    /// Maps one pcurve parameter to the authoritative spatial-curve parameter.
    pub fn spatial_parameter_at(&self, parameter: &Real) -> GeometryResult<Real> {
        crate::context::strict(|| match &self.correspondence {
            SurfacePcurveCorrespondence::Affine { scale, offset } => Ok(scale * parameter + offset),
            SurfacePcurveCorrespondence::AngularSweep {
                spatial_start,
                spatial_end,
            } => {
                // A periodic seam has two parameter identities even though
                // its endpoint coordinates agree. Preserve the selected end
                // before recovering an angle from the point's position.
                let domain = self.curve.parameter_domain();
                let (start, end) = domain
                    .scalar_endpoints()
                    .ok_or(GeometryError::UnsupportedPcurveContour)?;
                if decided_order(compare_reals(parameter, start, crate::STRICT_PREDICATES))?
                    == Ordering::Equal
                {
                    return Ok(spatial_start.clone());
                }
                if decided_order(compare_reals(parameter, end, crate::STRICT_PREDICATES))?
                    == Ordering::Equal
                {
                    return Ok(spatial_end.clone());
                }
                let Some(CurveGeometry2::CircularArc(arc)) = self.curve.geometry() else {
                    return Err(GeometryError::UnsupportedPcurveContour);
                };
                let point = self.curve.point_at(&parameter.clone().into())?;
                let point = point
                    .coordinates()
                    .ok_or(GeometryError::UnsupportedPcurveContour)?;
                let fraction = match crate::error::classified(arc.sweep_fraction(point))? {
                    Classification::Decided(fraction) => fraction,
                    Classification::Uncertain(reason) => {
                        return Err(GeometryError::PlanarClassificationUnresolved(reason));
                    }
                };
                Ok(spatial_start + (spatial_end - spatial_start) * fraction)
            }
        })
    }
}

fn materialized_surface_pcurve_from_matching_domains(
    curve: Curve2,
    target_domain: &ParameterDomain,
) -> GeometryResult<MaterializedSurfacePcurve> {
    let curve_domain = curve.parameter_domain();
    let (curve_domain_start, curve_domain_end) = curve_domain
        .scalar_endpoints()
        .ok_or(GeometryError::UnsupportedPcurveContour)?;
    let curve_start = curve_domain_start.clone();
    let curve_span = curve_domain_end - &curve_start;
    let target_span = target_domain.end() - target_domain.start();
    let spatial_scale = (target_span / curve_span).map_err(GeometryError::Numeric)?;
    let spatial_offset = target_domain.start() - &spatial_scale * curve_start;
    Ok(MaterializedSurfacePcurve {
        curve,
        correspondence: SurfacePcurveCorrespondence::Affine {
            scale: spatial_scale,
            offset: spatial_offset,
        },
    })
}

/// Exact unbounded line produced by a surface/surface intersection.
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionLine {
    /// One exact point on the line.
    pub point: Point3,
    /// Exact nonzero line direction.
    pub direction: Vector3,
}

/// Exact lower-bounded ray produced by a surface/surface intersection.
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionRay {
    /// Exact point at ray parameter zero.
    pub point: Point3,
    /// Exact nonzero direction for increasing parameters.
    pub direction: Vector3,
    /// Authoritative lower bound of the ray parameter.
    pub minimum: Real,
    first_pcurve: SurfaceIntersectionParameterRay,
    second_pcurve: SurfaceIntersectionParameterRay,
}

/// Exact affine surface-parameter image of an intersection ray.
#[derive(Clone, Debug)]
pub struct SurfaceIntersectionParameterRay {
    origin: Point2,
    direction: Vector2,
}

impl SurfaceIntersectionRay {
    fn new(
        point: Point3,
        direction: Vector3,
        minimum: Real,
        first_pcurve: SurfaceIntersectionParameterRay,
        second_pcurve: SurfaceIntersectionParameterRay,
    ) -> Self {
        Self {
            point,
            direction,
            minimum,
            first_pcurve,
            second_pcurve,
        }
    }

    fn swapped(mut self) -> Self {
        std::mem::swap(&mut self.first_pcurve, &mut self.second_pcurve);
        self
    }

    /// Returns the exact affine parameter ray on one surface operand.
    pub const fn pcurve(
        &self,
        operand: SurfaceIntersectionOperand,
    ) -> &SurfaceIntersectionParameterRay {
        match operand {
            SurfaceIntersectionOperand::First => &self.first_pcurve,
            SurfaceIntersectionOperand::Second => &self.second_pcurve,
        }
    }
}

impl SurfaceIntersectionParameterRay {
    fn new(origin: Point2, direction: Vector2) -> Self {
        Self { origin, direction }
    }

    /// Returns the surface parameter at one authoritative ray parameter.
    pub fn point_at(&self, parameter: &Real) -> Point2 {
        self.origin.clone() + self.direction.clone() * parameter
    }

    /// Returns the exact surface-parameter origin.
    pub const fn origin(&self) -> &Point2 {
        &self.origin
    }

    /// Returns the exact surface-parameter direction.
    pub const fn direction(&self) -> &Vector2 {
        &self.direction
    }
}

impl SurfacePartials {
    /// Returns the partial derivative in the surface `u` direction.
    pub const fn u(&self) -> &Vector3 {
        &self.u
    }

    /// Returns the partial derivative in the surface `v` direction.
    pub const fn v(&self) -> &Vector3 {
        &self.v
    }
}

/// Immutable exact parametric surface.
#[derive(Clone, Debug)]
pub struct Surface {
    data: Arc<SurfaceData>,
}

#[derive(Debug)]
struct SurfaceData {
    geometry: SurfaceGeometry,
    domain: SurfaceDomain,
    bounds: OnceLock<SurfaceBounds>,
}

#[derive(Debug)]
enum SurfaceGeometry {
    Plane(PlaneSurface),
    Cylinder(CylinderSurface),
    Sphere(SphereSurface),
    Cone(ConeSurface),
    Torus(TorusSurface),
    Extrusion(ExtrusionSurface),
    Revolution(RevolutionSurface),
    RationalBezier(RationalBezierSurface),
    Nurbs(NurbsSurface),
}

#[derive(Debug)]
struct PlaneSurface {
    origin: Point3,
    u: Vector3,
    v: Vector3,
}

#[derive(Debug)]
struct OrthonormalFrame3 {
    x: Vector3,
    y: Vector3,
    z: Vector3,
}

#[derive(Debug)]
struct CylinderSurface {
    origin: Point3,
    frame: OrthonormalFrame3,
    radius: Real,
}

#[derive(Debug)]
struct SphereSurface {
    center: Point3,
    frame: OrthonormalFrame3,
    radius: Real,
}

#[derive(Debug)]
struct ConeSurface {
    apex: Point3,
    frame: OrthonormalFrame3,
    semi_angle: Real,
}

#[derive(Debug)]
struct TorusSurface {
    center: Point3,
    frame: OrthonormalFrame3,
    major_radius: Real,
    minor_radius: Real,
}

#[derive(Debug)]
struct ExtrusionSurface {
    profile: Curve3,
    direction: Vector3,
}

#[derive(Debug)]
struct RevolutionSurface {
    profile: Curve3,
    axis_origin: Point3,
    axis: Vector3,
}

#[derive(Debug)]
struct RationalBezierSurface {
    control_points: Vec<Vec<Point3>>,
    weights: Vec<Vec<Real>>,
    homogeneous_controls: OnceLock<Vec<Vec<HomogeneousPoint3>>>,
}

#[derive(Debug)]
struct NurbsSurface {
    u_degree: usize,
    v_degree: usize,
    control_points: Vec<Vec<Point3>>,
    weights: Vec<Vec<Real>>,
    u_knots: Vec<Real>,
    v_knots: Vec<Real>,
    homogeneous_controls: OnceLock<Vec<Vec<HomogeneousPoint3>>>,
}

impl Surface {
    /// Constructs an unbounded exact plane with an authored parameter frame.
    pub fn plane(origin: Point3, u: Vector3, v: Vector3) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let normal_norm = u.cross(&v).norm_squared();
            match compare_reals(&normal_norm, &Real::zero(), crate::STRICT_PREDICATES) {
                PredicateOutcome::Decided {
                    value: Ordering::Greater,
                    ..
                } => Ok(Self::from_parts(
                    SurfaceGeometry::Plane(PlaneSurface { origin, u, v }),
                    SurfaceDomain {
                        u: SurfaceParameterDomain::Unbounded,
                        v: SurfaceParameterDomain::Unbounded,
                    },
                )),
                PredicateOutcome::Decided { .. } => Err(GeometryError::DegeneratePlaneBasis),
                PredicateOutcome::Unknown { needed, stage } => {
                    Err(GeometryError::PredicateUnresolved { needed, stage })
                }
            }
        })
    }

    /// Constructs a circular cylinder with periodic angle `u` and axial `v`.
    pub fn cylinder(
        origin: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        radius: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let frame = validate_orthonormal_frame(x, y, axis)?;
            require_positive(&radius, GeometryError::InvalidRadius)?;
            Ok(Self::from_parts(
                SurfaceGeometry::Cylinder(CylinderSurface {
                    origin,
                    frame,
                    radius,
                }),
                angle_unbounded_domain(),
            ))
        })
    }

    /// Constructs a sphere with longitude `u` and latitude `v`.
    pub fn sphere(
        center: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        radius: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let frame = validate_orthonormal_frame(x, y, axis)?;
            require_positive(&radius, GeometryError::InvalidRadius)?;
            let half_pi = (Real::pi() / Real::from(2)).map_err(GeometryError::Numeric)?;
            Ok(Self::from_parts(
                SurfaceGeometry::Sphere(SphereSurface {
                    center,
                    frame,
                    radius,
                }),
                SurfaceDomain {
                    u: angle_domain(),
                    v: SurfaceParameterDomain::Closed(ParameterDomain::new(
                        -half_pi.clone(),
                        half_pi,
                    )?),
                },
            ))
        })
    }

    /// Constructs a right circular cone with nonnegative slant distance `v`.
    ///
    /// The exact parameterization is
    /// `apex + v*(sin(semi_angle)*(x*cos(u) + y*sin(u)) + cos(semi_angle)*axis)`.
    /// The apex at `v=0` is a parameter singularity.
    pub fn cone(
        apex: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        semi_angle: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let frame = validate_orthonormal_frame(x, y, axis)?;
            let half_pi = (Real::pi() / Real::from(2)).map_err(GeometryError::Numeric)?;
            if decided_order(compare_reals(
                &semi_angle,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
                || decided_order(compare_reals(
                    &semi_angle,
                    &half_pi,
                    crate::STRICT_PREDICATES,
                ))? != Ordering::Less
            {
                return Err(GeometryError::InvalidConeAngle);
            }
            Ok(Self::from_parts(
                SurfaceGeometry::Cone(ConeSurface {
                    apex,
                    frame,
                    semi_angle,
                }),
                SurfaceDomain {
                    u: angle_domain(),
                    v: SurfaceParameterDomain::LowerBounded {
                        start: Real::zero(),
                    },
                },
            ))
        })
    }

    /// Constructs a non-self-intersecting ring torus.
    pub fn torus(
        center: Point3,
        x: Vector3,
        y: Vector3,
        axis: Vector3,
        major_radius: Real,
        minor_radius: Real,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let frame = validate_orthonormal_frame(x, y, axis)?;
            require_positive(&minor_radius, GeometryError::InvalidTorusRadii)?;
            if decided_order(compare_reals(
                &major_radius,
                &minor_radius,
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
            {
                return Err(GeometryError::InvalidTorusRadii);
            }
            Ok(Self::from_parts(
                SurfaceGeometry::Torus(TorusSurface {
                    center,
                    frame,
                    major_radius,
                    minor_radius,
                }),
                SurfaceDomain {
                    u: angle_domain(),
                    v: angle_domain(),
                },
            ))
        })
    }

    /// Constructs the unbounded linear extrusion of a finite profile curve.
    ///
    /// `u` is the profile parameter and `v` is the signed coefficient of the
    /// authored direction: `S(u, v) = profile(u) + v * direction`.
    pub fn extrusion(profile: Curve3, direction: Vector3) -> GeometryResult<Self> {
        crate::context::strict(|| {
            if decided_order(compare_reals(
                &direction.norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
            {
                return Err(GeometryError::DegenerateExtrusionDirection);
            }
            let u_domain = profile.domain().clone();
            Ok(Self::from_parts(
                SurfaceGeometry::Extrusion(ExtrusionSurface { profile, direction }),
                SurfaceDomain {
                    u: SurfaceParameterDomain::Closed(u_domain),
                    v: SurfaceParameterDomain::Unbounded,
                },
            ))
        })
    }

    /// Constructs the full revolution of a finite profile around a unit axis.
    ///
    /// `u` is the periodic revolution angle and `v` is the profile parameter.
    /// Profile points on the axis remain explicit parameter singularities.
    pub fn revolution(profile: Curve3, axis_origin: Point3, axis: Vector3) -> GeometryResult<Self> {
        crate::context::strict(|| {
            if decided_order(compare_reals(
                &axis.norm_squared(),
                &Real::one(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
            {
                return Err(GeometryError::InvalidRevolutionAxis);
            }
            let v_domain = profile.domain().clone();
            Ok(Self::from_parts(
                SurfaceGeometry::Revolution(RevolutionSurface {
                    profile,
                    axis_origin,
                    axis,
                }),
                SurfaceDomain {
                    u: angle_domain(),
                    v: SurfaceParameterDomain::Closed(v_domain),
                },
            ))
        })
    }

    /// Constructs a tensor-product rational Bézier surface over `[0, 1]²`.
    ///
    /// The outer vectors are rows in increasing `v`; each row contains control
    /// points in increasing `u`. Both axes must contain at least two controls.
    pub fn rational_bezier(
        control_points: Vec<Vec<Point3>>,
        weights: Vec<Vec<Real>>,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let (u_count, _) = validate_surface_control_net(&control_points, &weights)?;
            validate_positive_surface_weights(&weights)?;
            debug_assert!(u_count >= 2);
            Ok(Self::from_parts(
                SurfaceGeometry::RationalBezier(RationalBezierSurface {
                    control_points,
                    weights,
                    homogeneous_controls: OnceLock::new(),
                }),
                SurfaceDomain {
                    u: SurfaceParameterDomain::Closed(ParameterDomain::unit()),
                    v: SurfaceParameterDomain::Closed(ParameterDomain::unit()),
                },
            ))
        })
    }

    /// Constructs a finite non-periodic tensor-product NURBS surface.
    ///
    /// The outer vectors are rows in increasing `v`; each row contains control
    /// points in increasing `u`. Knot vectors are clamped and nondecreasing.
    pub fn nurbs(
        u_degree: usize,
        v_degree: usize,
        control_points: Vec<Vec<Point3>>,
        weights: Vec<Vec<Real>>,
        u_knots: Vec<Real>,
        v_knots: Vec<Real>,
    ) -> GeometryResult<Self> {
        crate::context::strict(|| {
            let (u_count, v_count) = validate_surface_control_net(&control_points, &weights)?;
            validate_positive_surface_weights(&weights)?;
            validate_nurbs_axis(u_degree, u_count, &u_knots)?;
            validate_nurbs_axis(v_degree, v_count, &v_knots)?;
            let u_domain =
                ParameterDomain::new(u_knots[u_degree].clone(), u_knots[u_count].clone())?;
            let v_domain =
                ParameterDomain::new(v_knots[v_degree].clone(), v_knots[v_count].clone())?;
            Ok(Self::from_parts(
                SurfaceGeometry::Nurbs(NurbsSurface {
                    u_degree,
                    v_degree,
                    control_points,
                    weights,
                    u_knots,
                    v_knots,
                    homogeneous_controls: OnceLock::new(),
                }),
                SurfaceDomain {
                    u: SurfaceParameterDomain::Closed(u_domain),
                    v: SurfaceParameterDomain::Closed(v_domain),
                },
            ))
        })
    }

    fn from_parts(geometry: SurfaceGeometry, domain: SurfaceDomain) -> Self {
        Self {
            data: Arc::new(SurfaceData {
                geometry,
                domain,
                bounds: OnceLock::new(),
            }),
        }
    }

    /// Returns the surface family.
    pub fn kind(&self) -> SurfaceKind {
        match &self.data.geometry {
            SurfaceGeometry::Plane(_) => SurfaceKind::Plane,
            SurfaceGeometry::Cylinder(_) => SurfaceKind::Cylinder,
            SurfaceGeometry::Sphere(_) => SurfaceKind::Sphere,
            SurfaceGeometry::Cone(_) => SurfaceKind::Cone,
            SurfaceGeometry::Torus(_) => SurfaceKind::Torus,
            SurfaceGeometry::Extrusion(_) => SurfaceKind::Extrusion,
            SurfaceGeometry::Revolution(_) => SurfaceKind::Revolution,
            SurfaceGeometry::RationalBezier(_) => SurfaceKind::RationalBezier,
            SurfaceGeometry::Nurbs(_) => SurfaceKind::Nurbs,
        }
    }

    /// Proves equality of authored periodic analytic parameterizations, including
    /// frame orientation. Coincidence of their unparameterized images alone
    /// is insufficient for reusing face-local boundary curves.
    pub(crate) fn same_periodic_analytic_parameterization(
        &self,
        other: &Self,
    ) -> GeometryResult<bool> {
        let (first_origin, first_frame, second_origin, second_frame, equal_parameters) =
            match (&self.data.geometry, &other.data.geometry) {
                (SurfaceGeometry::Cylinder(first), SurfaceGeometry::Cylinder(second)) => (
                    &first.origin,
                    &first.frame,
                    &second.origin,
                    &second.frame,
                    decided_order(compare_reals(
                        &first.radius,
                        &second.radius,
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Equal,
                ),
                (SurfaceGeometry::Cone(first), SurfaceGeometry::Cone(second)) => (
                    &first.apex,
                    &first.frame,
                    &second.apex,
                    &second.frame,
                    decided_order(compare_reals(
                        &first.semi_angle,
                        &second.semi_angle,
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Equal,
                ),
                (SurfaceGeometry::Torus(first), SurfaceGeometry::Torus(second)) => (
                    &first.center,
                    &first.frame,
                    &second.center,
                    &second.frame,
                    decided_order(compare_reals(
                        &first.major_radius,
                        &second.major_radius,
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Equal
                        && decided_order(compare_reals(
                            &first.minor_radius,
                            &second.minor_radius,
                            crate::STRICT_PREDICATES,
                        ))? == Ordering::Equal,
                ),
                _ => return Ok(false),
            };
        if !equal_parameters || !orthonormal_frames_equal(first_frame, second_frame)? {
            return Ok(false);
        }
        match point3_equal(first_origin, second_origin, crate::STRICT_PREDICATES) {
            PredicateOutcome::Decided { value, .. } => Ok(value),
            PredicateOutcome::Unknown { needed, stage } => {
                Err(GeometryError::PredicateUnresolved { needed, stage })
            }
        }
    }

    pub(crate) fn canonical_plane(&self) -> GeometryResult<Option<Self>> {
        let controls = match &self.data.geometry {
            SurfaceGeometry::Plane(_) => return Ok(Some(self.clone())),
            SurfaceGeometry::RationalBezier(surface) => {
                surface.control_points.iter().flatten().collect::<Vec<_>>()
            }
            SurfaceGeometry::Nurbs(surface) => {
                surface.control_points.iter().flatten().collect::<Vec<_>>()
            }
            SurfaceGeometry::Sphere(_)
            | SurfaceGeometry::Cylinder(_)
            | SurfaceGeometry::Cone(_)
            | SurfaceGeometry::Torus(_)
            | SurfaceGeometry::Extrusion(_)
            | SurfaceGeometry::Revolution(_) => return Ok(None),
        };
        let Some(&origin) = controls.first() else {
            return Ok(None);
        };
        let mut u = None;
        for &point in controls.iter().skip(1) {
            let candidate = point - origin;
            if decided_order(compare_reals(
                &candidate.norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Greater
            {
                u = Some(candidate);
                break;
            }
        }
        let Some(u) = u else {
            return Ok(None);
        };
        let mut v = None;
        for &point in controls.iter().skip(1) {
            let candidate = point - origin;
            if decided_order(compare_reals(
                &u.cross(&candidate).norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Greater
            {
                v = Some(candidate);
                break;
            }
        }
        let Some(v) = v else {
            return Ok(None);
        };
        let normal = u.cross(&v);
        for &point in &controls {
            if decided_order(compare_reals(
                &normal.dot(&(point - origin)),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
            {
                return Ok(None);
            }
        }
        Ok(Some(Self::plane(origin.clone(), u, v)?))
    }

    /// Returns the exact plane whose authored coordinates are this tensor's
    /// native parameters when the tensor is a constant-weight affine image.
    ///
    /// The certificate checks every rational Bézier control against its
    /// Bernstein lattice, or every NURBS control against its normalized
    /// Greville lattice. Nonconstant projective weights and non-affine control
    /// nets remain explicit unsupported cases.
    pub(crate) fn affine_parameter_plane(&self) -> GeometryResult<Option<Self>> {
        let (
            control_points,
            weights,
            u_coordinates,
            v_coordinates,
            u_start,
            u_span,
            v_start,
            v_span,
        ) = match &self.data.geometry {
            SurfaceGeometry::RationalBezier(surface) => {
                let u_count = surface.control_points[0].len();
                let v_count = surface.control_points.len();
                let u_denominator = Real::from(
                    u128::try_from(u_count - 1).expect("usize is representable as u128"),
                );
                let v_denominator = Real::from(
                    u128::try_from(v_count - 1).expect("usize is representable as u128"),
                );
                let coordinates = |count: usize, denominator: &Real| -> GeometryResult<Vec<Real>> {
                    (0..count)
                        .map(|index| {
                            (Real::from(
                                u128::try_from(index).expect("usize is representable as u128"),
                            ) / denominator)
                                .map_err(GeometryError::Numeric)
                        })
                        .collect()
                };
                (
                    &surface.control_points,
                    &surface.weights,
                    coordinates(u_count, &u_denominator)?,
                    coordinates(v_count, &v_denominator)?,
                    Real::zero(),
                    Real::one(),
                    Real::zero(),
                    Real::one(),
                )
            }
            SurfaceGeometry::Nurbs(surface) => {
                let u_count = surface.control_points[0].len();
                let v_count = surface.control_points.len();
                let u_start = surface.u_knots[surface.u_degree].clone();
                let u_end = surface.u_knots[u_count].clone();
                let v_start = surface.v_knots[surface.v_degree].clone();
                let v_end = surface.v_knots[v_count].clone();
                let u_span = &u_end - &u_start;
                let v_span = &v_end - &v_start;
                (
                    &surface.control_points,
                    &surface.weights,
                    normalized_greville_coordinates(
                        u_count,
                        surface.u_degree,
                        &surface.u_knots,
                        &u_start,
                        &u_span,
                    )?,
                    normalized_greville_coordinates(
                        v_count,
                        surface.v_degree,
                        &surface.v_knots,
                        &v_start,
                        &v_span,
                    )?,
                    u_start,
                    u_span,
                    v_start,
                    v_span,
                )
            }
            SurfaceGeometry::Plane(_)
            | SurfaceGeometry::Cylinder(_)
            | SurfaceGeometry::Sphere(_)
            | SurfaceGeometry::Cone(_)
            | SurfaceGeometry::Torus(_)
            | SurfaceGeometry::Extrusion(_)
            | SurfaceGeometry::Revolution(_) => return Ok(None),
        };
        let first_weight = &weights[0][0];
        for weight in weights.iter().flatten().skip(1) {
            if decided_order(compare_reals(
                weight,
                first_weight,
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
            {
                return Ok(None);
            }
        }
        let image_origin = &control_points[0][0];
        let image_u = &control_points[0][control_points[0].len() - 1] - image_origin;
        let image_v = &control_points[control_points.len() - 1][0] - image_origin;
        if decided_order(compare_reals(
            &image_u.cross(&image_v).norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Greater
        {
            return Ok(None);
        }
        for (row, v_coordinate) in control_points.iter().zip(&v_coordinates) {
            for (point, u_coordinate) in row.iter().zip(&u_coordinates) {
                let expected = image_origin.clone()
                    + image_u.clone() * u_coordinate
                    + image_v.clone() * v_coordinate;
                if !points_equal(point, &expected)? {
                    return Ok(None);
                }
            }
        }
        let parameter_u = divide_vector_by_real(image_u, &u_span)?;
        let parameter_v = divide_vector_by_real(image_v, &v_span)?;
        let parameter_origin =
            image_origin.clone() - parameter_u.clone() * &u_start - parameter_v.clone() * &v_start;
        Ok(Some(Self::plane(
            parameter_origin,
            parameter_u,
            parameter_v,
        )?))
    }

    /// Pulls one rational Bézier image curve back through an exact affine
    /// bilinear tensor whose two native axes are independently Möbius
    /// reparameterized.
    ///
    /// This deliberately recognizes only a degree-one `2×2` affine control
    /// lattice with a positive rank-one weight matrix. Rational Bézier unit
    /// domains and arbitrary active NURBS knot domains share the same
    /// normalized fractional-linear inverse; its result is mapped back into
    /// the authored native domain before the two denominators are multiplied
    /// in homogeneous Bernstein form. Higher-degree projective tensor
    /// inverses are generally algebraic rather than rational and remain
    /// unsupported.
    pub(crate) fn affine_bilinear_inverse_pcurve(
        &self,
        curve: &Curve3,
    ) -> GeometryResult<Option<Curve2>> {
        let (control_points, surface_weights, u_start, u_span, v_start, v_span) =
            match &self.data.geometry {
                SurfaceGeometry::RationalBezier(surface)
                    if surface.control_points.len() == 2
                        && surface.weights.len() == 2
                        && surface
                            .control_points
                            .iter()
                            .zip(&surface.weights)
                            .all(|(points, weights)| points.len() == 2 && weights.len() == 2) =>
                {
                    (
                        &surface.control_points,
                        &surface.weights,
                        Real::zero(),
                        Real::one(),
                        Real::zero(),
                        Real::one(),
                    )
                }
                SurfaceGeometry::Nurbs(surface)
                    if surface.u_degree == 1
                        && surface.v_degree == 1
                        && surface.control_points.len() == 2
                        && surface.weights.len() == 2
                        && surface
                            .control_points
                            .iter()
                            .zip(&surface.weights)
                            .all(|(points, weights)| points.len() == 2 && weights.len() == 2) =>
                {
                    let u_start = surface.u_knots[1].clone();
                    let u_end = surface.u_knots[2].clone();
                    let v_start = surface.v_knots[1].clone();
                    let v_end = surface.v_knots[2].clone();
                    (
                        &surface.control_points,
                        &surface.weights,
                        u_start.clone(),
                        u_end - u_start,
                        v_start.clone(),
                        v_end - v_start,
                    )
                }
                _ => return Ok(None),
            };
        let first_weight = &surface_weights[0][0];
        let mut nonconstant_weights = false;
        for weight in surface_weights.iter().flatten().skip(1) {
            if decided_order(compare_reals(
                weight,
                first_weight,
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
            {
                nonconstant_weights = true;
                break;
            }
        }
        if !nonconstant_weights {
            return Ok(None);
        }
        let origin = &control_points[0][0];
        let u = &control_points[0][1] - origin;
        let v = &control_points[1][0] - origin;
        if decided_order(compare_reals(
            &u.cross(&v).norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Greater
            || !points_equal(
                &control_points[1][1],
                &(origin.clone() + u.clone() + v.clone()),
            )?
            || decided_order(compare_reals(
                &(&surface_weights[0][0] * &surface_weights[1][1]),
                &(&surface_weights[0][1] * &surface_weights[1][0]),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
        {
            return Ok(None);
        }
        let Some(projected) = project_curve_to_plane_frame(curve, origin, &u, &v)? else {
            return Ok(None);
        };
        let Some(CurveGeometry2::RationalBezier(projected)) = projected.geometry() else {
            return Ok(None);
        };
        let x = projected
            .homogeneous_controls()
            .iter()
            .map(|control| control.x().clone())
            .collect::<Vec<_>>();
        let y = projected
            .homogeneous_controls()
            .iter()
            .map(|control| control.y().clone())
            .collect::<Vec<_>>();
        let weights = projected.weights();
        let u_numerator = x
            .iter()
            .map(|value| &surface_weights[0][0] * value)
            .collect::<Vec<_>>();
        let u_denominator = weights
            .iter()
            .zip(&x)
            .map(|(weight, value)| {
                &surface_weights[0][1] * (weight - value) + &surface_weights[0][0] * value
            })
            .collect::<Vec<_>>();
        let v_numerator = y
            .iter()
            .map(|value| &surface_weights[0][0] * value)
            .collect::<Vec<_>>();
        let v_denominator = weights
            .iter()
            .zip(&y)
            .map(|(weight, value)| {
                &surface_weights[1][0] * (weight - value) + &surface_weights[0][0] * value
            })
            .collect::<Vec<_>>();
        let u_native_numerator = u_denominator
            .iter()
            .zip(&u_numerator)
            .map(|(denominator, numerator)| &u_start * denominator + &u_span * numerator)
            .collect::<Vec<_>>();
        let v_native_numerator = v_denominator
            .iter()
            .zip(&v_numerator)
            .map(|(denominator, numerator)| &v_start * denominator + &v_span * numerator)
            .collect::<Vec<_>>();
        let common_weights = bernstein_product(&u_denominator, &v_denominator)?;
        for weight in &common_weights {
            if decided_order(compare_reals(
                weight,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
            {
                return Ok(None);
            }
        }
        let u_homogeneous = bernstein_product(&u_native_numerator, &v_denominator)?;
        let v_homogeneous = bernstein_product(&v_native_numerator, &u_denominator)?;
        let controls = u_homogeneous
            .iter()
            .zip(&v_homogeneous)
            .zip(&common_weights)
            .map(|((u, v), weight)| {
                Ok(CurvePoint2::new(
                    (u / weight).map_err(GeometryError::Numeric)?,
                    (v / weight).map_err(GeometryError::Numeric)?,
                ))
            })
            .collect::<GeometryResult<Vec<_>>>()?;
        Ok(Some(Curve2::from(RationalBezier2::try_new(
            controls,
            common_weights,
        )?)))
    }

    /// Extracts one exact tensor-product iso-curve.
    ///
    /// Rational Bézier surfaces collapse the orthogonal homogeneous control
    /// direction with de Casteljau. NURBS surfaces use homogeneous de Boor and
    /// retain the varying direction's authored degree and knot vector.
    pub fn iso_curve(&self, axis: SurfaceIsoAxis, constant: &Real) -> GeometryResult<Curve3> {
        crate::context::strict(|| {
            let homogeneous_to_curve_data = |controls: Vec<HomogeneousPoint3>| {
                let mut points = Vec::with_capacity(controls.len());
                let mut weights = Vec::with_capacity(controls.len());
                for control in controls {
                    weights.push(control.w.clone());
                    points.push(control.project()?);
                }
                Ok::<_, GeometryError>((points, weights))
            };
            match &self.data.geometry {
                SurfaceGeometry::RationalBezier(surface) => {
                    if !ParameterDomain::unit().contains(constant)? {
                        return Err(GeometryError::ParameterOutsideDomain);
                    }
                    let controls = surface.homogeneous_controls();
                    let iso_controls = match axis {
                        SurfaceIsoAxis::U => (0..controls[0].len())
                            .map(|column| {
                                evaluate_homogeneous_bezier_value(
                                    &controls
                                        .iter()
                                        .map(|row| row[column].clone())
                                        .collect::<Vec<_>>(),
                                    constant,
                                )
                                .ok_or(GeometryError::InvalidControlNetShape)
                            })
                            .collect::<GeometryResult<Vec<_>>>()?,
                        SurfaceIsoAxis::V => controls
                            .iter()
                            .map(|row| {
                                evaluate_homogeneous_bezier_value(row, constant)
                                    .ok_or(GeometryError::InvalidControlNetShape)
                            })
                            .collect::<GeometryResult<Vec<_>>>()?,
                    };
                    let (points, weights) = homogeneous_to_curve_data(iso_controls)?;
                    Curve3::rational_bezier(points, weights)
                }
                SurfaceGeometry::Nurbs(surface) => {
                    let (domain, degree, knots, control_count) = match axis {
                        SurfaceIsoAxis::U => (
                            match &self.data.domain.v {
                                SurfaceParameterDomain::Closed(domain) => domain,
                                _ => return Err(GeometryError::InvalidParameterDomain),
                            },
                            surface.v_degree,
                            &surface.v_knots,
                            surface.control_points.len(),
                        ),
                        SurfaceIsoAxis::V => (
                            match &self.data.domain.u {
                                SurfaceParameterDomain::Closed(domain) => domain,
                                _ => return Err(GeometryError::InvalidParameterDomain),
                            },
                            surface.u_degree,
                            &surface.u_knots,
                            surface.control_points[0].len(),
                        ),
                    };
                    if !domain.contains(constant)? {
                        return Err(GeometryError::ParameterOutsideDomain);
                    }
                    let span = find_span(constant, domain, degree, control_count, knots)?;
                    let controls = surface.homogeneous_controls();
                    let iso_controls = match axis {
                        SurfaceIsoAxis::U => (0..controls[0].len())
                            .map(|column| {
                                evaluate_homogeneous_de_boor_jet(
                                    &controls
                                        .iter()
                                        .map(|row| row[column].clone())
                                        .collect::<Vec<_>>(),
                                    &surface.v_knots,
                                    surface.v_degree,
                                    span,
                                    constant,
                                )
                                .map(|(value, _)| value)
                            })
                            .collect::<GeometryResult<Vec<_>>>()?,
                        SurfaceIsoAxis::V => controls
                            .iter()
                            .map(|row| {
                                evaluate_homogeneous_de_boor_jet(
                                    row,
                                    &surface.u_knots,
                                    surface.u_degree,
                                    span,
                                    constant,
                                )
                                .map(|(value, _)| value)
                            })
                            .collect::<GeometryResult<Vec<_>>>()?,
                    };
                    let (points, weights) = homogeneous_to_curve_data(iso_controls)?;
                    match axis {
                        SurfaceIsoAxis::U => Curve3::nurbs(
                            surface.u_degree,
                            points,
                            weights,
                            surface.u_knots.clone(),
                        ),
                        SurfaceIsoAxis::V => Curve3::nurbs(
                            surface.v_degree,
                            points,
                            weights,
                            surface.v_knots.clone(),
                        ),
                    }
                }
                _ => Err(GeometryError::UnsupportedSubdivision),
            }
        })
    }

    /// Returns the canonical exact parameter domain.
    pub fn domain(&self) -> &SurfaceDomain {
        &self.data.domain
    }

    /// Returns conservative exact model-space bounds.
    ///
    /// Positive-weight tensor-product spline surfaces lie in the convex hull
    /// of their affine control net. Infinite analytic families are reported as
    /// unbounded; bounded analytic families use an exact enclosing cube. Only
    /// successful bounds are cached; unresolved comparisons remain retryable.
    pub fn bounds(&self) -> GeometryResult<SurfaceBounds> {
        crate::context::strict(|| {
            crate::cache::get_or_try_init(&self.data.bounds, || match &self.data.geometry {
                SurfaceGeometry::Plane(_)
                | SurfaceGeometry::Cylinder(_)
                | SurfaceGeometry::Cone(_)
                | SurfaceGeometry::Extrusion(_) => Ok(SurfaceBounds::Unbounded),
                SurfaceGeometry::Sphere(surface) => Ok(SurfaceBounds::Bounded(Box::new(
                    centered_cube_bounds(&surface.center, &surface.radius),
                ))),
                SurfaceGeometry::Torus(surface) => {
                    Ok(SurfaceBounds::Bounded(Box::new(centered_cube_bounds(
                        &surface.center,
                        &(&surface.major_radius + &surface.minor_radius),
                    ))))
                }
                SurfaceGeometry::Revolution(surface) => Ok(SurfaceBounds::Bounded(Box::new(
                    revolution_bounds(surface)?,
                ))),
                SurfaceGeometry::RationalBezier(surface) => Ok(SurfaceBounds::Bounded(Box::new(
                    exact_surface_control_bounds(&surface.control_points)?,
                ))),
                SurfaceGeometry::Nurbs(surface) => Ok(SurfaceBounds::Bounded(Box::new(
                    exact_surface_control_bounds(&surface.control_points)?,
                ))),
            })
            .cloned()
        })
    }

    /// Evaluates an exact model-space point.
    pub fn point_at(&self, parameter: &Point2) -> GeometryResult<Point3> {
        crate::context::strict(|| {
            validate_surface_parameter(&self.data.domain, parameter)?;
            match &self.data.geometry {
                SurfaceGeometry::Plane(plane) => {
                    let displacement =
                        plane.u.clone() * &parameter.x + plane.v.clone() * &parameter.y;
                    Ok(plane.origin.clone() + displacement)
                }
                SurfaceGeometry::Cylinder(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    Ok(surface.origin.clone()
                        + surface.frame.x.clone() * (&surface.radius * cos_u)
                        + surface.frame.y.clone() * (&surface.radius * sin_u)
                        + surface.frame.z.clone() * &parameter.y)
                }
                SurfaceGeometry::Sphere(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let (sin_v, cos_v) = (parameter.y.clone().sin(), parameter.y.clone().cos());
                    Ok(surface.center.clone()
                        + surface.frame.x.clone() * (&surface.radius * &cos_v * cos_u)
                        + surface.frame.y.clone() * (&surface.radius * cos_v * sin_u)
                        + surface.frame.z.clone() * (&surface.radius * sin_v))
                }
                SurfaceGeometry::Cone(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let sin_angle = surface.semi_angle.clone().sin();
                    let cos_angle = surface.semi_angle.clone().cos();
                    Ok(surface.apex.clone()
                        + surface.frame.z.clone() * (&parameter.y * cos_angle)
                        + surface.frame.x.clone() * (&parameter.y * &sin_angle * cos_u)
                        + surface.frame.y.clone() * (&parameter.y * sin_angle * sin_u))
                }
                SurfaceGeometry::Torus(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let (sin_v, cos_v) = (parameter.y.clone().sin(), parameter.y.clone().cos());
                    let radial_distance = &surface.major_radius + &surface.minor_radius * &cos_v;
                    Ok(surface.center.clone()
                        + surface.frame.x.clone() * (&radial_distance * cos_u)
                        + surface.frame.y.clone() * (&radial_distance * sin_u)
                        + surface.frame.z.clone() * (&surface.minor_radius * sin_v))
                }
                SurfaceGeometry::Extrusion(surface) => {
                    Ok(surface.profile.evaluate_real(&parameter.x)?
                        + surface.direction.clone() * &parameter.y)
                }
                SurfaceGeometry::Revolution(surface) => {
                    let profile_point = surface.profile.evaluate_real(&parameter.y)?;
                    Ok(rotate_point_about_axis(
                        &profile_point,
                        &surface.axis_origin,
                        &surface.axis,
                        &parameter.x,
                    ))
                }
                SurfaceGeometry::RationalBezier(surface) => {
                    evaluate_tensor_bezier(surface.homogeneous_controls(), parameter)
                }
                SurfaceGeometry::Nurbs(surface) => {
                    evaluate_tensor_nurbs(surface, &self.data.domain, parameter)
                }
            }
        })
    }

    /// Returns exact first partial derivatives.
    pub fn partials_at(&self, parameter: &Point2) -> GeometryResult<SurfacePartials> {
        crate::context::strict(|| {
            validate_surface_parameter(&self.data.domain, parameter)?;
            match &self.data.geometry {
                SurfaceGeometry::Plane(plane) => Ok(SurfacePartials {
                    u: plane.u.clone(),
                    v: plane.v.clone(),
                }),
                SurfaceGeometry::Cylinder(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    Ok(SurfacePartials {
                        u: surface.frame.x.clone() * (-&surface.radius * sin_u)
                            + surface.frame.y.clone() * (&surface.radius * cos_u),
                        v: surface.frame.z.clone(),
                    })
                }
                SurfaceGeometry::Sphere(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let (sin_v, cos_v) = (parameter.y.clone().sin(), parameter.y.clone().cos());
                    Ok(SurfacePartials {
                        u: surface.frame.x.clone() * (-&surface.radius * &cos_v * &sin_u)
                            + surface.frame.y.clone() * (&surface.radius * &cos_v * &cos_u),
                        v: surface.frame.x.clone() * (-&surface.radius * &sin_v * &cos_u)
                            + surface.frame.y.clone() * (-&surface.radius * &sin_v * &sin_u)
                            + surface.frame.z.clone() * (&surface.radius * cos_v),
                    })
                }
                SurfaceGeometry::Cone(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let sin_angle = surface.semi_angle.clone().sin();
                    let cos_angle = surface.semi_angle.clone().cos();
                    Ok(SurfacePartials {
                        u: surface.frame.x.clone() * (-&parameter.y * &sin_angle * &sin_u)
                            + surface.frame.y.clone() * (&parameter.y * &sin_angle * &cos_u),
                        v: surface.frame.x.clone() * (&sin_angle * cos_u)
                            + surface.frame.y.clone() * (&sin_angle * sin_u)
                            + surface.frame.z.clone() * cos_angle,
                    })
                }
                SurfaceGeometry::Torus(surface) => {
                    let (sin_u, cos_u) = (parameter.x.clone().sin(), parameter.x.clone().cos());
                    let (sin_v, cos_v) = (parameter.y.clone().sin(), parameter.y.clone().cos());
                    let radial_distance = &surface.major_radius + &surface.minor_radius * &cos_v;
                    Ok(SurfacePartials {
                        u: surface.frame.x.clone() * (-&radial_distance * &sin_u)
                            + surface.frame.y.clone() * (&radial_distance * &cos_u),
                        v: surface.frame.x.clone() * (-&surface.minor_radius * &sin_v * &cos_u)
                            + surface.frame.y.clone() * (-&surface.minor_radius * &sin_v * &sin_u)
                            + surface.frame.z.clone() * (&surface.minor_radius * cos_v),
                    })
                }
                SurfaceGeometry::Extrusion(surface) => Ok(SurfacePartials {
                    u: surface.profile.derivative_at(&parameter.x, 1)?.vector,
                    v: surface.direction.clone(),
                }),
                SurfaceGeometry::Revolution(surface) => {
                    let profile_point = surface.profile.evaluate_real(&parameter.y)?;
                    let profile_derivative = surface.profile.derivative_at(&parameter.y, 1)?.vector;
                    let relative = &profile_point - &surface.axis_origin;
                    let axial = surface.axis.clone() * surface.axis.dot(&relative);
                    let radial = relative - axial;
                    let sin = parameter.x.clone().sin();
                    let cos = parameter.x.clone().cos();
                    let u = radial.clone() * -sin + surface.axis.cross(&radial) * cos;
                    let v =
                        rotate_vector_about_axis(&profile_derivative, &surface.axis, &parameter.x);
                    Ok(SurfacePartials { u, v })
                }
                SurfaceGeometry::RationalBezier(surface) => {
                    evaluate_tensor_bezier_partials(surface.homogeneous_controls(), parameter)
                }
                SurfaceGeometry::Nurbs(surface) => {
                    evaluate_tensor_nurbs_partials(surface, &self.data.domain, parameter)
                }
            }
        })
    }

    /// Returns the exact unit normal induced by the authored parameter order.
    ///
    /// Poles, cone apices, revolution-axis contacts, and other rank-deficient
    /// parameters return [`GeometryError::SingularSurfaceParameter`].
    pub fn normal_at(&self, parameter: &Point2) -> GeometryResult<Vector3> {
        crate::context::strict(|| {
            let partials = self.partials_at(parameter)?;
            let normal = partials.u.cross(&partials.v);
            if decided_order(compare_reals(
                &normal.norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                return Err(GeometryError::SingularSurfaceParameter);
            }
            normal.normalize().map_err(GeometryError::Numeric)
        })
    }

    /// Splits a supported finite tensor-product surface along interior `u`.
    pub fn split_u_at(&self, parameter: &Real) -> GeometryResult<(Self, Self)> {
        crate::context::strict(|| {
            let SurfaceParameterDomain::Closed(domain) = self.domain().u() else {
                return Err(GeometryError::UnsupportedSubdivision);
            };
            require_interior_parameter(domain, parameter)?;
            match &self.data.geometry {
                SurfaceGeometry::RationalBezier(surface) => {
                    split_rational_bezier_surface_u(surface, parameter)
                }
                SurfaceGeometry::Nurbs(surface) => split_nurbs_surface_u(surface, parameter),
                _ => Err(GeometryError::UnsupportedSubdivision),
            }
        })
    }

    /// Splits a supported finite tensor-product surface along interior `v`.
    pub fn split_v_at(&self, parameter: &Real) -> GeometryResult<(Self, Self)> {
        crate::context::strict(|| {
            let SurfaceParameterDomain::Closed(domain) = self.domain().v() else {
                return Err(GeometryError::UnsupportedSubdivision);
            };
            require_interior_parameter(domain, parameter)?;
            match &self.data.geometry {
                SurfaceGeometry::RationalBezier(surface) => {
                    split_rational_bezier_surface_v(surface, parameter)
                }
                SurfaceGeometry::Nurbs(surface) => split_nurbs_surface_v(surface, parameter),
                _ => Err(GeometryError::UnsupportedSubdivision),
            }
        })
    }

    /// Returns the authored plane origin when this is a plane.
    pub fn plane_origin(&self) -> Option<&Point3> {
        match &self.data.geometry {
            SurfaceGeometry::Plane(plane) => Some(&plane.origin),
            SurfaceGeometry::Cylinder(_)
            | SurfaceGeometry::Sphere(_)
            | SurfaceGeometry::Cone(_)
            | SurfaceGeometry::Torus(_)
            | SurfaceGeometry::Extrusion(_)
            | SurfaceGeometry::Revolution(_)
            | SurfaceGeometry::RationalBezier(_)
            | SurfaceGeometry::Nurbs(_) => None,
        }
    }

    /// Returns the authored plane parameter directions when this is a plane.
    pub fn plane_directions(&self) -> Option<(&Vector3, &Vector3)> {
        match &self.data.geometry {
            SurfaceGeometry::Plane(plane) => Some((&plane.u, &plane.v)),
            SurfaceGeometry::Cylinder(_)
            | SurfaceGeometry::Sphere(_)
            | SurfaceGeometry::Cone(_)
            | SurfaceGeometry::Torus(_)
            | SurfaceGeometry::Extrusion(_)
            | SurfaceGeometry::Revolution(_)
            | SurfaceGeometry::RationalBezier(_)
            | SurfaceGeometry::Nurbs(_) => None,
        }
    }

    pub(crate) fn exact_data(&self) -> SurfaceExactData {
        match &self.data.geometry {
            SurfaceGeometry::Plane(surface) => SurfaceExactData::Plane {
                origin: surface.origin.clone(),
                u: surface.u.clone(),
                v: surface.v.clone(),
            },
            SurfaceGeometry::Cylinder(surface) => SurfaceExactData::Cylinder {
                origin: surface.origin.clone(),
                x: surface.frame.x.clone(),
                y: surface.frame.y.clone(),
                axis: surface.frame.z.clone(),
                radius: surface.radius.clone(),
            },
            SurfaceGeometry::Sphere(surface) => SurfaceExactData::Sphere {
                center: surface.center.clone(),
                x: surface.frame.x.clone(),
                y: surface.frame.y.clone(),
                axis: surface.frame.z.clone(),
                radius: surface.radius.clone(),
            },
            SurfaceGeometry::Cone(surface) => SurfaceExactData::Cone {
                apex: surface.apex.clone(),
                x: surface.frame.x.clone(),
                y: surface.frame.y.clone(),
                axis: surface.frame.z.clone(),
                semi_angle: surface.semi_angle.clone(),
            },
            SurfaceGeometry::Torus(surface) => SurfaceExactData::Torus {
                center: surface.center.clone(),
                x: surface.frame.x.clone(),
                y: surface.frame.y.clone(),
                axis: surface.frame.z.clone(),
                major_radius: surface.major_radius.clone(),
                minor_radius: surface.minor_radius.clone(),
            },
            SurfaceGeometry::Extrusion(surface) => SurfaceExactData::Extrusion {
                profile: Box::new(surface.profile.exact_data()),
                direction: surface.direction.clone(),
            },
            SurfaceGeometry::Revolution(surface) => SurfaceExactData::Revolution {
                profile: Box::new(surface.profile.exact_data()),
                axis_origin: surface.axis_origin.clone(),
                axis: surface.axis.clone(),
            },
            SurfaceGeometry::RationalBezier(surface) => SurfaceExactData::RationalBezier {
                control_points: surface.control_points.clone(),
                weights: surface.weights.clone(),
            },
            SurfaceGeometry::Nurbs(surface) => SurfaceExactData::Nurbs {
                u_degree: surface.u_degree,
                v_degree: surface.v_degree,
                control_points: surface.control_points.clone(),
                weights: surface.weights.clone(),
                u_knots: surface.u_knots.clone(),
                v_knots: surface.v_knots.clone(),
            },
        }
    }

    /// Borrows a native extrusion's exact profile and authored direction.
    ///
    /// Its chart is `S(u, v) = profile(u) + v * direction`; the direction need
    /// not have unit length. Other surface families return `None`. This does
    /// not fit or recognize another carrier as an extrusion.
    pub fn extrusion_profile_and_direction(&self) -> Option<(&Curve3, &Vector3)> {
        match &self.data.geometry {
            SurfaceGeometry::Extrusion(surface) => Some((&surface.profile, &surface.direction)),
            _ => None,
        }
    }

    pub(crate) fn revolution_meridian_curve(&self, angle: &Real) -> GeometryResult<Curve3> {
        let SurfaceGeometry::Revolution(surface) = &self.data.geometry else {
            return Err(GeometryError::UnsupportedSubdivision);
        };
        let rotate_point = |point: &Point3| {
            rotate_point_about_axis(point, &surface.axis_origin, &surface.axis, angle)
        };
        let rotate_vector =
            |vector: &Vector3| rotate_vector_about_axis(vector, &surface.axis, angle);
        match surface.profile.exact_data() {
            Curve3ExactData::PlanarImage(mut image) => {
                image.origin = rotate_point(&image.origin);
                image.u = rotate_vector(&image.u);
                image.v = rotate_vector(&image.v);
                Curve3::from_planar_image(*image)
            }
            Curve3ExactData::Line(line) => {
                Curve3::line(rotate_point(&line.start), rotate_point(&line.end))
            }
            Curve3ExactData::RationalBezier {
                control_points,
                weights,
            } => Curve3::rational_bezier(
                control_points.iter().map(rotate_point).collect::<Vec<_>>(),
                weights,
            ),
            Curve3ExactData::Nurbs {
                degree,
                control_points,
                weights,
                knots,
            } => Curve3::nurbs(
                degree,
                control_points.iter().map(rotate_point).collect::<Vec<_>>(),
                weights,
                knots,
            ),
            Curve3ExactData::EllipseArc(data) => Curve3::from_exact_data(
                Curve3ExactData::EllipseArc(Box::new(EllipseArcExactData {
                    circle: data.circle,
                    center: rotate_point(&data.center),
                    x: rotate_vector(&data.x),
                    y: rotate_vector(&data.y),
                    x_radius: data.x_radius,
                    y_radius: data.y_radius,
                    domain_start: data.domain_start,
                    domain_end: data.domain_end,
                    angle_at_start: data.angle_at_start,
                    direction: data.direction,
                })),
            ),
        }
    }

    pub(crate) fn revolution_profile_is_strictly_off_axis(&self) -> GeometryResult<bool> {
        let SurfaceGeometry::Revolution(surface) = &self.data.geometry else {
            return Err(GeometryError::UnsupportedSubdivision);
        };
        surface
            .profile
            .is_strictly_off_axis(&surface.axis_origin, &surface.axis)
    }

    pub(crate) fn revolution_latitude_curve(
        &self,
        profile_parameter: &Real,
        angle_start: Real,
        angle_end: Real,
    ) -> GeometryResult<Curve3> {
        let SurfaceGeometry::Revolution(surface) = &self.data.geometry else {
            return Err(GeometryError::UnsupportedSubdivision);
        };
        let profile_point = surface.profile.evaluate_real(profile_parameter)?;
        let relative = &profile_point - &surface.axis_origin;
        let axial = surface.axis.clone() * surface.axis.dot(&relative);
        let radial = relative - &axial;
        if decided_order(compare_reals(
            &radial.norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Greater
        {
            return Err(GeometryError::SingularSurfaceParameter);
        }
        let radius = radial
            .norm_squared()
            .sqrt()
            .map_err(GeometryError::Numeric)?;
        let x = (radial / &radius).map_err(GeometryError::Numeric)?;
        let y = surface.axis.cross(&x);
        Curve3::circle_arc(
            surface.axis_origin.clone() + axial,
            x,
            y,
            radius,
            angle_start,
            angle_end,
        )
    }

    pub(crate) fn from_exact_data(data: SurfaceExactData) -> GeometryResult<Self> {
        match data {
            SurfaceExactData::Plane { origin, u, v } => Self::plane(origin, u, v),
            SurfaceExactData::Cylinder {
                origin,
                x,
                y,
                axis,
                radius,
            } => Self::cylinder(origin, x, y, axis, radius),
            SurfaceExactData::Sphere {
                center,
                x,
                y,
                axis,
                radius,
            } => Self::sphere(center, x, y, axis, radius),
            SurfaceExactData::Cone {
                apex,
                x,
                y,
                axis,
                semi_angle,
            } => Self::cone(apex, x, y, axis, semi_angle),
            SurfaceExactData::Torus {
                center,
                x,
                y,
                axis,
                major_radius,
                minor_radius,
            } => Self::torus(center, x, y, axis, major_radius, minor_radius),
            SurfaceExactData::Extrusion { profile, direction } => {
                Self::extrusion(Curve3::from_exact_data(*profile)?, direction)
            }
            SurfaceExactData::Revolution {
                profile,
                axis_origin,
                axis,
            } => Self::revolution(Curve3::from_exact_data(*profile)?, axis_origin, axis),
            SurfaceExactData::RationalBezier {
                control_points,
                weights,
            } => Self::rational_bezier(control_points, weights),
            SurfaceExactData::Nurbs {
                u_degree,
                v_degree,
                control_points,
                weights,
                u_knots,
                v_knots,
            } => Self::nurbs(
                u_degree,
                v_degree,
                control_points,
                weights,
                u_knots,
                v_knots,
            ),
        }
    }

    /// Intersects this surface with a finite spatial curve.
    pub fn intersect_curve(&self, curve: &Curve3) -> GeometryResult<CurveSurfaceIntersection> {
        crate::context::strict(|| {
            if let (
                SurfaceGeometry::Plane(plane),
                CurveGeometry3::CircleArc(arc) | CurveGeometry3::EllipseArc(arc),
            ) = (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_ellipse_arc_plane(curve, arc, plane);
            }
            if let (SurfaceGeometry::Plane(plane), CurveGeometry3::RationalBezier(bezier)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_rational_bezier_plane(curve, bezier, plane);
            }
            if let (SurfaceGeometry::Plane(plane), CurveGeometry3::Nurbs(nurbs)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_nurbs_plane(curve, nurbs, plane);
            }
            if let (SurfaceGeometry::Plane(plane), CurveGeometry3::PlanarImage(image)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_planar_image_plane(curve, image, plane);
            }
            if let (SurfaceGeometry::Sphere(sphere), CurveGeometry3::CircleArc(arc)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_circle_arc_sphere(curve, arc, sphere);
            }
            if let (SurfaceGeometry::Cylinder(cylinder), CurveGeometry3::CircleArc(arc)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_transverse_circle_arc_cylinder(curve, arc, cylinder);
            }
            if let (SurfaceGeometry::Cone(cone), CurveGeometry3::CircleArc(arc)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_transverse_circle_arc_cone(curve, arc, cone);
            }
            if let (SurfaceGeometry::Torus(torus), CurveGeometry3::CircleArc(arc)) =
                (&self.data.geometry, &curve.data.geometry)
            {
                return intersect_transverse_circle_arc_torus(curve, arc, torus);
            }
            let Some((start, end)) = curve.line_endpoints() else {
                return Err(GeometryError::UnsupportedIntersection);
            };
            match &self.data.geometry {
                SurfaceGeometry::Plane(plane) => {
                    let normal = plane.u.cross(&plane.v);
                    let direction = end - start;
                    let denominator = normal.dot(&direction);
                    let start_value = normal.dot(&(start - &plane.origin));
                    match decided_order(compare_reals(
                        &denominator,
                        &Real::zero(),
                        crate::STRICT_PREDICATES,
                    ))? {
                        Ordering::Equal => {
                            if decided_order(compare_reals(
                                &start_value,
                                &Real::zero(),
                                crate::STRICT_PREDICATES,
                            ))? == Ordering::Equal
                            {
                                Ok(CurveSurfaceIntersection::Contained)
                            } else {
                                Ok(CurveSurfaceIntersection::None)
                            }
                        }
                        Ordering::Less | Ordering::Greater => {
                            let parameter =
                                ((-start_value) / denominator).map_err(GeometryError::Numeric)?;
                            isolated_line_parameters(
                                curve,
                                [(parameter, IntersectionMultiplicity::Simple)],
                            )
                        }
                    }
                }
                SurfaceGeometry::Sphere(surface) => {
                    let offset = start - &surface.center;
                    quadratic_line_intersection(curve, &offset, &(end - start), &surface.radius)
                }
                SurfaceGeometry::Cylinder(surface) => {
                    let offset = start - &surface.origin;
                    let direction = end - start;
                    let radial_offset =
                        &offset - &(surface.frame.z.clone() * offset.dot(&surface.frame.z));
                    let radial_direction =
                        &direction - &(surface.frame.z.clone() * direction.dot(&surface.frame.z));
                    quadratic_line_intersection(
                        curve,
                        &radial_offset,
                        &radial_direction,
                        &surface.radius,
                    )
                }
                SurfaceGeometry::Cone(surface) => intersect_line_cone(curve, start, end, surface),
                SurfaceGeometry::Torus(_)
                | SurfaceGeometry::Extrusion(_)
                | SurfaceGeometry::Revolution(_)
                | SurfaceGeometry::RationalBezier(_)
                | SurfaceGeometry::Nurbs(_) => Err(GeometryError::UnsupportedIntersection),
            }
        })
    }

    /// Intersects this surface with another supported surface.
    pub fn intersect_surface(&self, other: &Self) -> GeometryResult<SurfaceSurfaceIntersection> {
        crate::context::strict(|| match (&self.data.geometry, &other.data.geometry) {
            (SurfaceGeometry::Plane(first), SurfaceGeometry::Plane(second)) => {
                intersect_planes(first, second)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Sphere(sphere)) => {
                intersect_plane_sphere(plane, sphere)
            }
            (SurfaceGeometry::Sphere(sphere), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_sphere(plane, sphere).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Cylinder(cylinder)) => {
                intersect_plane_cylinder(plane, cylinder)
            }
            (SurfaceGeometry::Cylinder(cylinder), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_cylinder(plane, cylinder).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Cone(cone)) => {
                intersect_plane_cone(plane, cone)
            }
            (SurfaceGeometry::Cone(cone), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_cone(plane, cone).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Torus(torus)) => {
                intersect_plane_torus(plane, torus)
            }
            (SurfaceGeometry::Torus(torus), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_torus(plane, torus).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Extrusion(surface)) => {
                intersect_plane_extrusion(plane, surface)
            }
            (SurfaceGeometry::Extrusion(surface), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_extrusion(plane, surface).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Revolution(surface)) => {
                intersect_plane_revolution(plane, surface)
            }
            (SurfaceGeometry::Revolution(surface), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_revolution(plane, surface).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Revolution(first), SurfaceGeometry::Revolution(second)) => {
                intersect_coaxial_revolutions(first, second)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::RationalBezier(surface)) => {
                intersect_plane_rational_bezier_surface(plane, surface)
            }
            (SurfaceGeometry::RationalBezier(surface), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_rational_bezier_surface(plane, surface)
                    .map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Plane(plane), SurfaceGeometry::Nurbs(surface)) => {
                intersect_plane_nurbs_surface(plane, surface)
            }
            (SurfaceGeometry::Nurbs(surface), SurfaceGeometry::Plane(plane)) => {
                intersect_plane_nurbs_surface(plane, surface).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Cylinder(first), SurfaceGeometry::Cylinder(second)) => {
                intersect_parallel_cylinders(first, second)
            }
            (SurfaceGeometry::Cone(first), SurfaceGeometry::Cone(second)) => {
                intersect_coaxial_cones(first, second)
            }
            (SurfaceGeometry::Torus(first), SurfaceGeometry::Torus(second)) => {
                intersect_coaxial_tori(first, second)
            }
            (SurfaceGeometry::Sphere(sphere), SurfaceGeometry::Torus(torus)) => {
                intersect_coaxial_sphere_torus(sphere, torus)
            }
            (SurfaceGeometry::Torus(torus), SurfaceGeometry::Sphere(sphere)) => {
                intersect_coaxial_sphere_torus(sphere, torus).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Cylinder(cylinder), SurfaceGeometry::Torus(torus)) => {
                intersect_coaxial_cylinder_torus(cylinder, torus)
            }
            (SurfaceGeometry::Torus(torus), SurfaceGeometry::Cylinder(cylinder)) => {
                intersect_coaxial_cylinder_torus(cylinder, torus).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Cone(cone), SurfaceGeometry::Torus(torus)) => {
                intersect_coaxial_cone_torus(cone, torus)
            }
            (SurfaceGeometry::Torus(torus), SurfaceGeometry::Cone(cone)) => {
                intersect_coaxial_cone_torus(cone, torus).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Cylinder(cylinder), SurfaceGeometry::Cone(cone)) => {
                intersect_coaxial_cylinder_cone(cylinder, cone)
            }
            (SurfaceGeometry::Cone(cone), SurfaceGeometry::Cylinder(cylinder)) => {
                intersect_coaxial_cylinder_cone(cylinder, cone).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Sphere(sphere), SurfaceGeometry::Cylinder(cylinder)) => {
                intersect_coaxial_sphere_cylinder(sphere, cylinder)
            }
            (SurfaceGeometry::Cylinder(cylinder), SurfaceGeometry::Sphere(sphere)) => {
                intersect_coaxial_sphere_cylinder(sphere, cylinder).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Sphere(sphere), SurfaceGeometry::Cone(cone)) => {
                intersect_coaxial_sphere_cone(sphere, cone)
            }
            (SurfaceGeometry::Cone(cone), SurfaceGeometry::Sphere(sphere)) => {
                intersect_coaxial_sphere_cone(sphere, cone).map(swapped_curve_intersection)
            }
            (SurfaceGeometry::Sphere(first), SurfaceGeometry::Sphere(second)) => {
                intersect_spheres(first, second)
            }
            _ => Err(GeometryError::UnsupportedIntersection),
        })
    }

    pub(crate) fn transformed(
        &self,
        metric: &TransformMetric<'_>,
        reflect_parameters: bool,
    ) -> GeometryResult<Self> {
        let transform = metric.matrix();
        match &self.data.geometry {
            SurfaceGeometry::Plane(plane) => {
                let mut u = transform.transform_direction3(&plane.u);
                if reflect_parameters {
                    u = -u;
                }
                Self::plane(
                    transform_point(transform, &plane.origin)?,
                    u,
                    transform.transform_direction3(&plane.v),
                )
            }
            SurfaceGeometry::Cylinder(surface) => {
                let x = metric.unit_direction(&surface.frame.x)?;
                let mut y = metric.unit_direction(&surface.frame.y)?;
                if reflect_parameters {
                    y = -y;
                }
                Self::cylinder(
                    transform_point(transform, &surface.origin)?,
                    x,
                    y,
                    metric.unit_direction(&surface.frame.z)?,
                    metric.length(&surface.radius)?,
                )
            }
            SurfaceGeometry::Torus(surface) => {
                let x = metric.unit_direction(&surface.frame.x)?;
                let mut y = metric.unit_direction(&surface.frame.y)?;
                if reflect_parameters {
                    y = -y;
                }
                Self::torus(
                    transform_point(transform, &surface.center)?,
                    x,
                    y,
                    metric.unit_direction(&surface.frame.z)?,
                    metric.length(&surface.major_radius)?,
                    metric.length(&surface.minor_radius)?,
                )
            }
            SurfaceGeometry::Cone(surface) => {
                let x = metric.unit_direction(&surface.frame.x)?;
                let mut y = metric.unit_direction(&surface.frame.y)?;
                if reflect_parameters {
                    y = -y;
                }
                Self::cone(
                    transform_point(transform, &surface.apex)?,
                    x,
                    y,
                    metric.unit_direction(&surface.frame.z)?,
                    surface.semi_angle.clone(),
                )
            }
            SurfaceGeometry::Sphere(surface) => {
                let x = metric.unit_direction(&surface.frame.x)?;
                let mut y = metric.unit_direction(&surface.frame.y)?;
                if reflect_parameters {
                    y = -y;
                }
                Self::sphere(
                    transform_point(transform, &surface.center)?,
                    x,
                    y,
                    metric.unit_direction(&surface.frame.z)?,
                    metric.length(&surface.radius)?,
                )
            }
            SurfaceGeometry::Revolution(surface) => Self::revolution(
                surface.profile.transformed_with_metric(metric)?,
                transform_point(transform, &surface.axis_origin)?,
                metric.unit_direction(&surface.axis)?,
            ),
            SurfaceGeometry::Extrusion(surface) => {
                let profile = surface.profile.transformed_with_metric(metric)?;
                // Topology reflects u and reverses wire orientation. Here u is
                // the profile parameter, so reverse its exact parameterization;
                // v remains the coefficient of the transformed direction.
                let profile = if reflect_parameters {
                    profile.reversed()?
                } else {
                    profile
                };
                Self::extrusion(profile, transform.transform_direction3(&surface.direction))
            }
            SurfaceGeometry::RationalBezier(surface) => {
                let mut control_points =
                    transform_surface_control_points(transform, &surface.control_points)?;
                let mut weights = surface.weights.clone();
                if reflect_parameters {
                    reverse_surface_u(&mut control_points);
                    reverse_surface_u(&mut weights);
                }
                Self::rational_bezier(control_points, weights)
            }
            SurfaceGeometry::Nurbs(surface) => {
                let mut control_points =
                    transform_surface_control_points(transform, &surface.control_points)?;
                let mut weights = surface.weights.clone();
                let mut u_knots = surface.u_knots.clone();
                if reflect_parameters {
                    reverse_surface_u(&mut control_points);
                    reverse_surface_u(&mut weights);
                    reverse_knot_axis(&mut u_knots);
                }
                Self::nurbs(
                    surface.u_degree,
                    surface.v_degree,
                    control_points,
                    weights,
                    u_knots,
                    surface.v_knots.clone(),
                )
            }
        }
    }
}

fn intersect_ellipse_arc_plane(
    curve: &Curve3,
    arc: &EllipseArc3,
    plane: &PlaneSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let center_value = normal.dot(&(&arc.center - &plane.origin));
    let cosine_coefficient = normal.dot(&(arc.x.clone() * &arc.x_radius));
    let sine_coefficient = normal.dot(&(arc.y.clone() * &arc.y_radius));
    intersect_ellipse_arc_scalar_equation(
        curve,
        arc,
        cosine_coefficient,
        sine_coefficient,
        center_value,
    )
}

fn intersect_circle_arc_sphere(
    curve: &Curve3,
    arc: &EllipseArc3,
    sphere: &SphereSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    intersect_circle_arc_center_radius(curve, arc, &sphere.center, &sphere.radius)
}

fn intersect_circle_arc_center_radius(
    curve: &Curve3,
    arc: &EllipseArc3,
    center: &Point3,
    radius: &Real,
) -> GeometryResult<CurveSurfaceIntersection> {
    let offset = &arc.center - center;
    let twice_radius = Real::from(2) * &arc.x_radius;
    let cosine_coefficient = &twice_radius * arc.x.dot(&offset);
    let sine_coefficient = &twice_radius * arc.y.dot(&offset);
    let center_value = offset.norm_squared() + &arc.x_radius * &arc.x_radius - radius * radius;
    intersect_ellipse_arc_scalar_equation(
        curve,
        arc,
        cosine_coefficient,
        sine_coefficient,
        center_value,
    )
}

fn intersect_transverse_circle_arc_cylinder(
    curve: &Curve3,
    arc: &EllipseArc3,
    cylinder: &CylinderSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let circle_axis = arc.x.cross(&arc.y);
    if decided_order(compare_reals(
        &circle_axis.cross(&cylinder.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    intersect_transverse_circle_arc_radius(
        curve,
        arc,
        &cylinder.origin,
        &cylinder.frame.z,
        &cylinder.radius,
    )
}

fn intersect_transverse_circle_arc_cone(
    curve: &Curve3,
    arc: &EllipseArc3,
    cone: &ConeSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let circle_axis = arc.x.cross(&arc.y);
    if decided_order(compare_reals(
        &circle_axis.cross(&cone.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let center_offset = &arc.center - &cone.apex;
    let height = center_offset.dot(&cone.frame.z);
    if decided_order(compare_reals(
        &height,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Less
    {
        return Ok(CurveSurfaceIntersection::None);
    }
    let (_, cone_radius) = cone_section_parameters(cone, &height)?;
    intersect_transverse_circle_arc_radius(curve, arc, &cone.apex, &cone.frame.z, &cone_radius)
}

fn intersect_transverse_circle_arc_torus(
    curve: &Curve3,
    arc: &EllipseArc3,
    torus: &TorusSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let circle_axis = arc.x.cross(&arc.y);
    if decided_order(compare_reals(
        &circle_axis.cross(&torus.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return intersect_axial_circle_arc_torus(curve, arc, torus, &circle_axis);
    }
    let center_offset = &arc.center - &torus.center;
    let height = center_offset.dot(&torus.frame.z);
    let height_squared = &height * &height;
    let minor_squared = &torus.minor_radius * &torus.minor_radius;
    if decided_order(compare_reals(
        &height_squared,
        &minor_squared,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
    {
        return Ok(CurveSurfaceIntersection::None);
    }
    let radial_delta = (minor_squared - height_squared)
        .sqrt()
        .map_err(GeometryError::Numeric)?;
    let mut radii = vec![&torus.major_radius + &radial_delta];
    if decided_order(compare_reals(
        &radial_delta,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        radii.push(&torus.major_radius - radial_delta);
    }
    let mut combined = Vec::<CurveSurfacePoint>::new();
    for radius in radii {
        match intersect_transverse_circle_arc_radius(
            curve,
            arc,
            &torus.center,
            &torus.frame.z,
            &radius,
        )? {
            CurveSurfaceIntersection::None => {}
            CurveSurfaceIntersection::Points(points) => {
                for point in points {
                    let mut duplicate = false;
                    for existing in &combined {
                        if existing.parameter.compare(&point.parameter)? == Ordering::Equal
                        {
                            duplicate = true;
                            break;
                        }
                    }
                    if !duplicate {
                        combined.push(point);
                    }
                }
            }
            CurveSurfaceIntersection::Contained => {
                return Ok(CurveSurfaceIntersection::Contained);
            }
            CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
                unreachable!("exact circle relation has no proper overlap")
            }
        }
    }
    for index in 1..combined.len() {
        let mut position = index;
        while position > 0
            && combined[position].parameter.compare(&combined[position - 1].parameter)? == Ordering::Less
        {
            combined.swap(position, position - 1);
            position -= 1;
        }
    }
    if combined.is_empty() {
        Ok(CurveSurfaceIntersection::None)
    } else {
        Ok(CurveSurfaceIntersection::Points(combined))
    }
}

fn intersect_axial_circle_arc_torus(
    curve: &Curve3,
    arc: &EllipseArc3,
    torus: &TorusSurface,
    circle_axis: &Vector3,
) -> GeometryResult<CurveSurfaceIntersection> {
    let center_offset = &arc.center - &torus.center;
    if decided_order(compare_reals(
        &circle_axis.dot(&torus.frame.z),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
        || decided_order(compare_reals(
            &circle_axis.dot(&center_offset),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let height = center_offset.dot(&torus.frame.z);
    let radial = &center_offset - &(torus.frame.z.clone() * height);
    let radial_squared = radial.norm_squared();
    if decided_order(compare_reals(
        &radial_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let major_squared = &torus.major_radius * &torus.major_radius;
    let (first_center, second_center) = if radial_squared == major_squared
        || decided_order(compare_reals(
            &radial_squared,
            &major_squared,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
    {
        (
            torus.center.clone() + radial.clone(),
            torus.center.clone() - radial,
        )
    } else {
        let radial = radial.normalize().map_err(GeometryError::Numeric)?;
        (
            torus.center.clone() + radial.clone() * &torus.major_radius,
            torus.center.clone() - radial * &torus.major_radius,
        )
    };
    let mut combined = Vec::<CurveSurfacePoint>::new();
    for center in [&first_center, &second_center] {
        match intersect_circle_arc_center_radius(curve, arc, center, &torus.minor_radius)? {
            CurveSurfaceIntersection::None => {}
            CurveSurfaceIntersection::Points(points) => {
                for point in points {
                    let mut duplicate = false;
                    for existing in &combined {
                        if existing.parameter.compare(&point.parameter)? == Ordering::Equal
                        {
                            duplicate = true;
                            break;
                        }
                    }
                    if !duplicate {
                        combined.push(point);
                    }
                }
            }
            CurveSurfaceIntersection::Contained => {
                return Ok(CurveSurfaceIntersection::Contained);
            }
            CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
                unreachable!("exact circle relation has no proper overlap")
            }
        }
    }
    for index in 1..combined.len() {
        let mut position = index;
        while position > 0
            && combined[position].parameter.compare(&combined[position - 1].parameter)? == Ordering::Less
        {
            combined.swap(position, position - 1);
            position -= 1;
        }
    }
    if combined.is_empty() {
        Ok(CurveSurfaceIntersection::None)
    } else {
        Ok(CurveSurfaceIntersection::Points(combined))
    }
}

fn intersect_transverse_circle_arc_radius(
    curve: &Curve3,
    arc: &EllipseArc3,
    axis_origin: &Point3,
    axis: &Vector3,
    target_radius: &Real,
) -> GeometryResult<CurveSurfaceIntersection> {
    let center_offset = &arc.center - axis_origin;
    let radial_offset = &center_offset - &(axis.clone() * center_offset.dot(axis));
    let twice_radius = Real::from(2) * &arc.x_radius;
    let cosine_coefficient = &twice_radius * arc.x.dot(&radial_offset);
    let sine_coefficient = &twice_radius * arc.y.dot(&radial_offset);
    let center_value = radial_offset.norm_squared() + &arc.x_radius * &arc.x_radius
        - target_radius * target_radius;
    intersect_ellipse_arc_scalar_equation(
        curve,
        arc,
        cosine_coefficient,
        sine_coefficient,
        center_value,
    )
}

fn intersect_ellipse_arc_scalar_equation(
    curve: &Curve3,
    arc: &EllipseArc3,
    cosine_coefficient: Real,
    sine_coefficient: Real,
    center_value: Real,
) -> GeometryResult<CurveSurfaceIntersection> {
    let amplitude_squared =
        &cosine_coefficient * &cosine_coefficient + &sine_coefficient * &sine_coefficient;
    if decided_order(compare_reals(
        &amplitude_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return if decided_order(compare_reals(
            &center_value,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            Ok(CurveSurfaceIntersection::Contained)
        } else {
            Ok(CurveSurfaceIntersection::None)
        };
    }
    let center_squared = &center_value * &center_value;
    let relation = decided_order(compare_reals(
        &center_squared,
        &amplitude_squared,
        crate::STRICT_PREDICATES,
    ))?;
    if relation == Ordering::Greater {
        return Ok(CurveSurfaceIntersection::None);
    }
    let amplitude = amplitude_squared.sqrt().map_err(GeometryError::Numeric)?;
    let phase = certified_atan2(sine_coefficient, cosine_coefficient)?;
    let ratio = ((-center_value) / amplitude).map_err(GeometryError::Numeric)?;
    let offset = ratio.acos().map_err(GeometryError::Numeric)?;
    let angles = if relation == Ordering::Equal {
        vec![phase + offset]
    } else {
        vec![&phase + &offset, phase - offset]
    };
    let multiplicity = if relation == Ordering::Equal {
        IntersectionMultiplicity::Tangent
    } else {
        IntersectionMultiplicity::Simple
    };
    let mut points = Vec::<CurveSurfacePoint>::new();
    for angle in angles {
        let point = arc.center.clone()
            + arc.x.clone() * (&arc.x_radius * angle.clone().cos())
            + arc.y.clone() * (&arc.y_radius * angle.clone().sin());
        let parameters = ellipse_arc_parameters_at_angle(curve, arc, angle)?;
        if parameters.is_empty() {
            continue;
        }
        for parameter in parameters {
            let mut duplicate = false;
            for existing in &points {
                if existing.parameter.compare(&parameter.clone().into())? == Ordering::Equal
                {
                    duplicate = true;
                    break;
                }
            }
            if duplicate {
                continue;
            }
            points.push(CurveSurfacePoint {
                parameter: parameter.into(),
                point: point.clone().into(),
                multiplicity,
            });
        }
    }
    for index in 1..points.len() {
        let mut position = index;
        while position > 0
            && points[position].parameter.compare(&points[position - 1].parameter)? == Ordering::Less
        {
            points.swap(position, position - 1);
            position -= 1;
        }
    }
    if points.is_empty() {
        Ok(CurveSurfaceIntersection::None)
    } else {
        Ok(CurveSurfaceIntersection::Points(points))
    }
}

fn ellipse_arc_parameters_at_angle(
    curve: &Curve3,
    arc: &EllipseArc3,
    angle: Real,
) -> GeometryResult<Vec<Real>> {
    let delta = if arc.direction < 0 {
        &arc.angle_at_start - &angle
    } else {
        &angle - &arc.angle_at_start
    };
    let result = angular_parameter_lifts(&(curve.domain().start() + delta), curve.domain());
    if !matches!(
        result,
        Err(GeometryError::PredicateUnresolved { .. }
            | GeometryError::Numeric(hyperreal::Problem::Exhausted))
    ) {
        return result;
    }
    // A scalar equation can produce an acos phase for a contact already at an
    // atan-authored endpoint. Equality of both unit-circle coordinates proves
    // congruence modulo tau without an unproved inverse-trig identity. In an
    // at-most-one-turn chart this retains precisely the endpoint lift(s).
    // Only a positive exact certificate replaces the original typed failure.
    let sine = angle.clone().sin();
    let cosine = angle.cos();
    for endpoint in [curve.domain().start(), curve.domain().end()] {
        let offset = endpoint - curve.domain().start();
        let phase = if arc.direction < 0 {
            &arc.angle_at_start - offset
        } else {
            &arc.angle_at_start + offset
        };
        if compare_reals(&sine, &phase.clone().sin(), crate::STRICT_PREDICATES).value()
            == Some(Ordering::Equal)
            && compare_reals(&cosine, &phase.cos(), crate::STRICT_PREDICATES).value()
                == Some(Ordering::Equal)
        {
            return angular_parameter_lifts(endpoint, curve.domain());
        }
    }
    result
}

/// All equivalent unit-speed conic parameters in a validated at-most-one-turn
/// domain. The integer quotient selects the first possible lift directly, so
/// enumeration does not grow with the chart's turn number. Scalar quotient and
/// coefficient costs retain their existing resource contract.
/// The two ends of a complete period retain distinct parameter identities.
pub(crate) fn angular_parameter_lifts(
    parameter: &Real,
    domain: &ParameterDomain,
) -> GeometryResult<Vec<Real>> {
    let tau = Real::tau();
    // Reuse these certified orders for both membership and endpoint identity.
    let endpoint_orderings = |value: &Real| {
        crate::context::strict(|| {
            let from_start = decided_order(compare_reals(
                value,
                domain.start(),
                crate::STRICT_PREDICATES,
            ))?;
            let to_end =
                decided_order(compare_reals(value, domain.end(), crate::STRICT_PREDICATES))?;
            Ok::<_, GeometryError>((from_start, to_end))
        })
    };
    let (from_start, to_end) = endpoint_orderings(parameter)?;
    let (first, from_start, to_end) = if from_start != Ordering::Less && to_end != Ordering::Greater
    {
        (parameter.clone(), from_start, to_end)
    } else {
        let turns = ((domain.start() - parameter) / &tau)
            .map_err(GeometryError::Numeric)?
            .ceil_certified()
            .map_err(GeometryError::Numeric)?;
        let first = parameter + Real::new(hyperreal::Rational::from_bigint(turns)) * &tau;
        let (from_start, to_end) = endpoint_orderings(&first)?;
        (first, from_start, to_end)
    };
    if from_start == Ordering::Less || to_end == Ordering::Greater {
        return Ok(Vec::new());
    }
    let at_start = from_start == Ordering::Equal;
    let at_end = to_end == Ordering::Equal;
    if (at_start || at_end)
        && decided_order(compare_reals(
            &(domain.end() - domain.start()),
            &tau,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
    {
        return Ok(vec![domain.start().clone(), domain.end().clone()]);
    }
    Ok(vec![if at_start {
        domain.start().clone()
    } else if at_end {
        domain.end().clone()
    } else {
        first
    }])
}

fn angle_domain() -> SurfaceParameterDomain {
    SurfaceParameterDomain::Periodic {
        start: Real::zero(),
        period: Real::from(2) * Real::pi(),
    }
}

fn angle_unbounded_domain() -> SurfaceDomain {
    SurfaceDomain {
        u: angle_domain(),
        v: SurfaceParameterDomain::Unbounded,
    }
}

fn validate_surface_parameter(domain: &SurfaceDomain, parameter: &Point2) -> GeometryResult<()> {
    if surface_axis_contains(&domain.u, &parameter.x)?
        && surface_axis_contains(&domain.v, &parameter.y)?
    {
        Ok(())
    } else {
        Err(GeometryError::SurfaceParameterOutsideDomain)
    }
}

fn surface_axis_contains(
    domain: &SurfaceParameterDomain,
    parameter: &Real,
) -> GeometryResult<bool> {
    match domain {
        SurfaceParameterDomain::Unbounded | SurfaceParameterDomain::Periodic { .. } => Ok(true),
        SurfaceParameterDomain::Closed(domain) => domain.contains(parameter),
        SurfaceParameterDomain::LowerBounded { start } => Ok(matches!(
            decided_order(compare_reals(parameter, start, crate::STRICT_PREDICATES))?,
            Ordering::Equal | Ordering::Greater
        )),
    }
}

fn require_positive(value: &Real, error: GeometryError) -> GeometryResult<()> {
    if decided_order(compare_reals(
        value,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
    {
        Ok(())
    } else {
        Err(error)
    }
}

fn validate_orthonormal_frame(
    x: Vector3,
    y: Vector3,
    z: Vector3,
) -> GeometryResult<OrthonormalFrame3> {
    let zero = Real::zero();
    let one = Real::one();
    let scalar_checks = [
        (x.norm_squared(), &one),
        (y.norm_squared(), &one),
        (z.norm_squared(), &one),
        (x.dot(&y), &zero),
        (y.dot(&z), &zero),
        (z.dot(&x), &zero),
    ];
    for (actual, expected) in scalar_checks {
        if decided_order(compare_reals(&actual, expected, crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Err(GeometryError::InvalidSurfaceFrame);
        }
    }
    let handedness = x.cross(&y).dot(&z);
    if decided_order(compare_reals(&handedness, &one, crate::STRICT_PREDICATES))? != Ordering::Equal
    {
        return Err(GeometryError::InvalidSurfaceFrame);
    }
    Ok(OrthonormalFrame3 { x, y, z })
}

pub(crate) fn affine_transform_orientation(transform: &Matrix4) -> GeometryResult<Ordering> {
    for (entry, expected) in
        transform.0[3]
            .iter()
            .zip([Real::zero(), Real::zero(), Real::zero(), Real::one()])
    {
        if decided_order(compare_reals(entry, &expected, crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Err(GeometryError::NonAffineTransform);
        }
    }
    let m = &transform.0;
    let determinant = &m[0][0] * (&m[1][1] * &m[2][2] - &m[1][2] * &m[2][1])
        - &m[0][1] * (&m[1][0] * &m[2][2] - &m[1][2] * &m[2][0])
        + &m[0][2] * (&m[1][0] * &m[2][1] - &m[1][1] * &m[2][0]);
    match decided_order(compare_reals(
        &determinant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Greater => Ok(Ordering::Greater),
        Ordering::Equal => Err(GeometryError::SingularTransform),
        Ordering::Less => Ok(Ordering::Less),
    }
}

fn transform_point(transform: &Matrix4, point: &Point3) -> GeometryResult<Point3> {
    transform
        .transform_point3(point)
        .map_err(GeometryError::Numeric)
}

fn transform_points(transform: &Matrix4, points: &[Point3]) -> GeometryResult<Vec<Point3>> {
    transform
        .transform_point3_batch(points)
        .map_err(GeometryError::Numeric)
}

fn transform_surface_control_points(
    transform: &Matrix4,
    control_points: &[Vec<Point3>],
) -> GeometryResult<Vec<Vec<Point3>>> {
    control_points
        .iter()
        .map(|row| transform_points(transform, row))
        .collect()
}

fn reverse_surface_u<T>(rows: &mut [Vec<T>]) {
    for row in rows {
        row.reverse();
    }
}

fn reverse_knot_axis(knots: &mut [Real]) {
    let sum = &knots[0] + &knots[knots.len() - 1];
    knots.reverse();
    for knot in knots {
        *knot = &sum - &*knot;
    }
}

fn swapped_curve_intersection(
    intersection: SurfaceSurfaceIntersection,
) -> SurfaceSurfaceIntersection {
    match intersection {
        SurfaceSurfaceIntersection::Curve(curve) => {
            SurfaceSurfaceIntersection::Curve(Box::new((*curve).swapped()))
        }
        SurfaceSurfaceIntersection::Curves(curves) => SurfaceSurfaceIntersection::Curves(
            curves
                .into_iter()
                .map(SurfaceIntersectionCurve::swapped)
                .collect(),
        ),
        SurfaceSurfaceIntersection::Ray(ray) => {
            SurfaceSurfaceIntersection::Ray(Box::new((*ray).swapped()))
        }
        SurfaceSurfaceIntersection::Rays(rays) => SurfaceSurfaceIntersection::Rays(
            rays.into_iter()
                .map(SurfaceIntersectionRay::swapped)
                .collect(),
        ),
        SurfaceSurfaceIntersection::Components(components) => {
            SurfaceSurfaceIntersection::Components(Box::new((*components).swapped()))
        }
        SurfaceSurfaceIntersection::ContainedSurface(operand) => {
            SurfaceSurfaceIntersection::ContainedSurface(operand.swapped())
        }
        other => other,
    }
}

pub(crate) fn project_point_to_plane_frame(
    origin: &Point3,
    u: &Vector3,
    v: &Vector3,
    point: &Point3,
) -> GeometryResult<Point2> {
    let displacement = point - origin;
    let uu = u.dot(u);
    let uv = u.dot(v);
    let vv = v.dot(v);
    let du = displacement.dot(u);
    let dv = displacement.dot(v);
    let determinant = &uu * &vv - &uv * &uv;
    let x = ((&du * &vv - &dv * &uv) / &determinant).map_err(GeometryError::Numeric)?;
    let y = ((&dv * &uu - &du * &uv) / determinant).map_err(GeometryError::Numeric)?;
    // Replayed endpoints feed native circle-radius and area proofs. Keep each
    // coordinate compact before those consumers multiply repeated projection
    // expressions, using only the scalar-owned bounded exact normal form.
    Ok(Point2::new(
        x.compact_pi_laurent().unwrap_or(x),
        y.compact_pi_laurent().unwrap_or(y),
    ))
}

pub(crate) fn project_curve_to_plane_frame(
    curve: &Curve3,
    origin: &Point3,
    u: &Vector3,
    v: &Vector3,
) -> GeometryResult<Option<Curve2>> {
    let project = |point: &Point3| {
        project_point_to_plane_frame(origin, u, v, point)
            .map(|point| CurvePoint2::new(point.x, point.y))
    };
    match curve.exact_data() {
        Curve3ExactData::Line(line) => Ok(Some(Curve2::from(LineSeg2::try_new(
            project(&line.start)?,
            project(&line.end)?,
        )?))),
        Curve3ExactData::RationalBezier {
            control_points,
            weights,
        } => Ok(Some(Curve2::from(RationalBezier2::try_new(
            control_points
                .iter()
                .map(project)
                .collect::<GeometryResult<Vec<_>>>()?,
            weights,
        )?))),
        Curve3ExactData::Nurbs {
            degree,
            control_points,
            weights,
            knots,
        } => Ok(Some(Curve2::try_nurbs(
            degree,
            control_points
                .iter()
                .map(project)
                .collect::<GeometryResult<Vec<_>>>()?,
            weights,
            knots,
        )?)),
        Curve3ExactData::EllipseArc(data) if data.circle => {
            let center = project(&data.center)?;
            let projected_x =
                project(&(data.center.clone() + data.x.clone() * data.x_radius.clone()))?;
            let projected_y =
                project(&(data.center.clone() + data.y.clone() * data.y_radius.clone()))?;
            let x = (projected_x.x() - center.x(), projected_x.y() - center.y());
            let y = (projected_y.x() - center.x(), projected_y.y() - center.y());
            let xy = &x.0 * &y.0 + &x.1 * &y.1;
            let x_squared = &x.0 * &x.0 + &x.1 * &x.1;
            let y_squared = &y.0 * &y.0 + &y.1 * &y.1;
            if decided_order(compare_reals(&xy, &Real::zero(), crate::STRICT_PREDICATES))?
                != Ordering::Equal
                || decided_order(compare_reals(
                    &x_squared,
                    &y_squared,
                    crate::STRICT_PREDICATES,
                ))? != Ordering::Equal
            {
                return Ok(None);
            }
            let start = project(&curve.start()?)?;
            let end = project(&curve.end()?)?;
            let tangent_point =
                data.center.clone() + curve.derivative_at(curve.domain().start(), 1)?.vector();
            let projected_tangent_point = project(&tangent_point)?;
            let projected_tangent = (
                projected_tangent_point.x() - center.x(),
                projected_tangent_point.y() - center.y(),
            );
            let radial = (start.x() - center.x(), start.y() - center.y());
            let orientation = &radial.0 * &projected_tangent.1 - &radial.1 * &projected_tangent.0;
            let clockwise = decided_order(compare_reals(
                &orientation,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less;
            Ok(Some(Curve2::from(CircularArc2::try_from_center(
                start, end, center, clockwise,
            )?)))
        }
        Curve3ExactData::EllipseArc(_) | Curve3ExactData::PlanarImage(_) => Ok(None),
    }
}

pub(crate) fn lift_curve_from_plane_frame(
    curve: &Curve2,
    origin: &Point3,
    u: &Vector3,
    v: &Vector3,
) -> GeometryResult<Option<Curve3>> {
    let lift = |point: &CurvePoint2| origin.clone() + u.clone() * point.x() + v.clone() * point.y();
    match curve.geometry() {
        None => Ok(None),
        Some(CurveGeometry2::Line(line)) => {
            Ok(Some(Curve3::line(lift(line.start()), lift(line.end()))?))
        }
        Some(CurveGeometry2::RationalBezier(curve)) => Ok(Some(Curve3::rational_bezier(
            curve
                .affine_control_points()
                .ok_or(GeometryError::UnsupportedIntersection)?
                .iter()
                .map(lift)
                .collect(),
            curve.weights().to_vec(),
        )?)),
        Some(CurveGeometry2::Nurbs(curve)) => Ok(Some(Curve3::nurbs(
            curve.degree(),
            curve
                .affine_control_points()
                .ok_or(GeometryError::UnsupportedIntersection)?
                .iter()
                .map(lift)
                .collect(),
            curve.weights().to_vec(),
            curve.knots().to_vec(),
        )?)),
        Some(CurveGeometry2::CircularArc(_))
        | Some(CurveGeometry2::QuadraticBezier(_))
        | Some(CurveGeometry2::CubicBezier(_))
        | Some(CurveGeometry2::RationalQuadraticBezier(_))
        | Some(CurveGeometry2::PolynomialBSpline(_)) => Ok(None),
    }
}

pub(crate) fn lift_curve_from_plane_frame_with_affine_parameter(
    curve: &Curve2,
    origin: &Point3,
    u: &Vector3,
    v: &Vector3,
    scale: &Real,
    offset: &Real,
) -> GeometryResult<Option<Curve3>> {
    let order = decided_order(compare_reals(
        scale,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if order == Ordering::Equal {
        return Err(GeometryError::InvalidParameterDomain);
    }
    let reversed = order == Ordering::Less;
    let lift = |point: &CurvePoint2| origin.clone() + u.clone() * point.x() + v.clone() * point.y();
    match curve.geometry() {
        None => Ok(None),
        Some(CurveGeometry2::Line(line)) => {
            let (start, end) = if reversed {
                (line.end(), line.start())
            } else {
                (line.start(), line.end())
            };
            Ok(Some(Curve3::line(lift(start), lift(end))?))
        }
        Some(CurveGeometry2::RationalBezier(curve)) => {
            let mut control_points = curve
                .affine_control_points()
                .ok_or(GeometryError::UnsupportedIntersection)?
                .to_vec();
            let mut weights = curve.weights().to_vec();
            if reversed {
                control_points.reverse();
                weights.reverse();
            }
            Ok(Some(Curve3::rational_bezier(
                control_points.iter().map(lift).collect(),
                weights,
            )?))
        }
        Some(CurveGeometry2::RationalQuadraticBezier(curve)) => {
            let mut controls = curve.control_points();
            let mut weights = curve.weights().map(Clone::clone);
            if reversed {
                controls.reverse();
                weights.reverse();
            }
            Ok(Some(Curve3::rational_bezier(
                controls.into_iter().map(lift).collect(),
                weights.to_vec(),
            )?))
        }
        Some(CurveGeometry2::Nurbs(curve)) => {
            let mut control_points = curve
                .affine_control_points()
                .ok_or(GeometryError::UnsupportedIntersection)?
                .to_vec();
            let mut weights = curve.weights().to_vec();
            let mut knots = curve.knots().to_vec();
            if reversed {
                control_points.reverse();
                weights.reverse();
                knots.reverse();
            }
            for knot in &mut knots {
                *knot = scale * &*knot + offset;
            }
            Ok(Some(Curve3::nurbs(
                curve.degree(),
                control_points.iter().map(lift).collect(),
                weights,
                knots,
            )?))
        }
        Some(CurveGeometry2::CircularArc(_))
        | Some(CurveGeometry2::QuadraticBezier(_))
        | Some(CurveGeometry2::CubicBezier(_))
        | Some(CurveGeometry2::PolynomialBSpline(_)) => Ok(None),
    }
}

fn linear_section_pcurve_carriers(
    profile: &Curve3,
    plane_origin: &Point3,
    plane_normal: &Vector3,
    denominator: &Real,
    profile_axis: TensorAxis,
    coefficient_scale: &Real,
    coefficient_offset: &Real,
) -> GeometryResult<Option<Vec<MaterializedSurfacePcurve>>> {
    let coefficient = |point: &Point3| {
        let normalized = (plane_normal.dot(&(plane_origin - point)) / denominator)
            .map_err(GeometryError::Numeric)?;
        Ok(coefficient_offset + coefficient_scale * normalized)
    };
    let span = profile.domain().end() - profile.domain().start();
    match &profile.data.geometry {
        CurveGeometry3::Line(line) => Ok(Some(vec![MaterializedSurfacePcurve {
            curve: Curve2::from(LineSeg2::try_new(
                section_parameter_point(
                    profile.domain().start().clone(),
                    coefficient(&line.start)?,
                    profile_axis,
                ),
                section_parameter_point(
                    profile.domain().end().clone(),
                    coefficient(&line.end)?,
                    profile_axis,
                ),
            )?),
            correspondence: SurfacePcurveCorrespondence::Affine {
                scale: span,
                offset: profile.domain().start().clone(),
            },
        }])),
        CurveGeometry3::RationalBezier(curve) => Ok(Some(vec![rational_linear_section_carrier(
            curve,
            profile.domain().start(),
            &span,
            &coefficient,
            profile_axis,
        )?])),
        CurveGeometry3::Nurbs(nurbs) => {
            let mut carriers = Vec::new();
            for (segment, domain) in decompose_nurbs_into_bezier_segments(nurbs)? {
                let CurveGeometry3::RationalBezier(curve) = &segment.data.geometry else {
                    unreachable!("NURBS decomposition produces rational Bézier segments");
                };
                carriers.push(rational_linear_section_carrier(
                    curve,
                    domain.start(),
                    &(domain.end() - domain.start()),
                    &coefficient,
                    profile_axis,
                )?);
            }
            Ok(Some(carriers))
        }
        CurveGeometry3::CircleArc(_)
        | CurveGeometry3::EllipseArc(_)
        | CurveGeometry3::PlanarImage(_) => Ok(None),
    }
}

pub(crate) fn concatenate_rational_bezier_spans_as_nurbs(
    curves: &[Curve2],
    boundaries: &[Real],
) -> GeometryResult<Curve2> {
    if curves.len() < 2 || boundaries.len() != curves.len() + 1 {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let Some(CurveGeometry2::RationalBezier(first)) = curves[0].geometry() else {
        return Err(GeometryError::UnsupportedIntersection);
    };
    let degree = first.degree();
    if degree == 0 {
        return Err(GeometryError::InvalidDegree);
    }
    let mut control_points = first
        .affine_control_points()
        .ok_or(GeometryError::UnsupportedIntersection)?
        .to_vec();
    let mut weights = first.weights().to_vec();
    for curve in &curves[1..] {
        let Some(CurveGeometry2::RationalBezier(curve)) = curve.geometry() else {
            return Err(GeometryError::UnsupportedIntersection);
        };
        if curve.degree() != degree
            || decided_order(compare_reals(
                control_points
                    .last()
                    .expect("first rational span has controls")
                    .x(),
                curve.start().x(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
            || decided_order(compare_reals(
                control_points
                    .last()
                    .expect("first rational span has controls")
                    .y(),
                curve.start().y(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
        {
            return Err(GeometryError::UnsupportedIntersection);
        }
        let scale = (weights
            .last()
            .expect("first rational span has weights")
            .clone()
            / &curve.weights()[0])
            .map_err(GeometryError::Numeric)?;
        control_points.extend(
            curve
                .affine_control_points()
                .ok_or(GeometryError::UnsupportedIntersection)?
                .iter()
                .skip(1)
                .cloned(),
        );
        weights.extend(curve.weights().iter().skip(1).map(|weight| weight * &scale));
    }
    let mut knots = Vec::with_capacity(control_points.len() + degree + 1);
    knots.extend(std::iter::repeat_n(boundaries[0].clone(), degree + 1));
    for boundary in &boundaries[1..boundaries.len() - 1] {
        knots.extend(std::iter::repeat_n(boundary.clone(), degree));
    }
    knots.extend(std::iter::repeat_n(
        boundaries.last().expect("at least two boundaries").clone(),
        degree + 1,
    ));
    Curve2::try_nurbs(degree, control_points, weights, knots).map_err(GeometryError::from)
}

pub(crate) fn materialize_nurbs_parameter_graph(
    degree: usize,
    coefficients: &[Real],
    weights: &[Real],
    knots: &[Real],
    profile_axis: SurfaceIsoAxis,
) -> GeometryResult<Curve2> {
    if coefficients.len() != weights.len() {
        return Err(GeometryError::WeightCountMismatch);
    }
    let synthetic = Curve3::nurbs(
        degree,
        coefficients
            .iter()
            .map(|coefficient| Point3::new(coefficient.clone(), Real::zero(), Real::zero()))
            .collect(),
        weights.to_vec(),
        knots.to_vec(),
    )?;
    let CurveGeometry3::Nurbs(nurbs) = &synthetic.data.geometry else {
        unreachable!("synthetic NURBS graph source retains NURBS geometry");
    };
    let profile_axis = match profile_axis {
        SurfaceIsoAxis::U => TensorAxis::U,
        SurfaceIsoAxis::V => TensorAxis::V,
    };
    let mut curves = Vec::new();
    let mut boundaries = Vec::new();
    for (segment, domain) in decompose_nurbs_into_bezier_segments(nurbs)? {
        let CurveGeometry3::RationalBezier(curve) = &segment.data.geometry else {
            unreachable!("NURBS decomposition produces rational Bézier segments");
        };
        if boundaries.is_empty() {
            boundaries.push(domain.start().clone());
        }
        boundaries.push(domain.end().clone());
        curves.push(
            rational_linear_section_carrier(
                curve,
                domain.start(),
                &(domain.end() - domain.start()),
                &|point| Ok(point.x.clone()),
                profile_axis,
            )?
            .curve,
        );
    }
    match curves.as_slice() {
        [curve] => Ok(curve.clone()),
        _ => concatenate_rational_bezier_spans_as_nurbs(&curves, &boundaries),
    }
}

fn section_parameter_point(
    profile_parameter: Real,
    coefficient: Real,
    profile_axis: TensorAxis,
) -> CurvePoint2 {
    match profile_axis {
        TensorAxis::U => CurvePoint2::new(profile_parameter, coefficient),
        TensorAxis::V => CurvePoint2::new(coefficient, profile_parameter),
    }
}

fn rational_linear_section_carrier(
    curve: &RationalBezier3,
    parameter_start: &Real,
    parameter_span: &Real,
    coefficient: &impl Fn(&Point3) -> GeometryResult<Real>,
    profile_axis: TensorAxis,
) -> GeometryResult<MaterializedSurfacePcurve> {
    let degree_plus_one = curve.weights.len();
    let denominator_degree =
        Real::from(i64::try_from(degree_plus_one).map_err(|_| GeometryError::InvalidDegree)?);
    let section_homogeneous = curve
        .control_points
        .iter()
        .zip(&curve.weights)
        .map(|(point, weight)| Ok::<_, GeometryError>(weight * coefficient(point)?))
        .collect::<Result<Vec<_>, _>>()?;
    let mut elevated_weights = Vec::with_capacity(degree_plus_one + 1);
    let mut elevated_points = Vec::with_capacity(degree_plus_one + 1);
    for index in 0..=degree_plus_one {
        let alpha = (Real::from(i64::try_from(index).map_err(|_| GeometryError::InvalidDegree)?)
            / &denominator_degree)
            .map_err(GeometryError::Numeric)?;
        let one_minus_alpha = Real::one() - &alpha;
        let previous_weight = (index > 0).then(|| curve.weights[index - 1].clone());
        let next_weight = (index < degree_plus_one).then(|| curve.weights[index].clone());
        let elevated_weight = previous_weight
            .as_ref()
            .map_or_else(Real::zero, |weight| &alpha * weight)
            + next_weight
                .as_ref()
                .map_or_else(Real::zero, |weight| &one_minus_alpha * weight);
        let local_parameter_homogeneous = previous_weight
            .as_ref()
            .map_or_else(Real::zero, |weight| &alpha * weight);
        let x_homogeneous =
            parameter_start * &elevated_weight + parameter_span * local_parameter_homogeneous;
        let previous_y = if index > 0 {
            &alpha * &section_homogeneous[index - 1]
        } else {
            Real::zero()
        };
        let next_y = if index < degree_plus_one {
            &one_minus_alpha * &section_homogeneous[index]
        } else {
            Real::zero()
        };
        let y_homogeneous = previous_y + next_y;
        elevated_points.push(section_parameter_point(
            (x_homogeneous / &elevated_weight).map_err(GeometryError::Numeric)?,
            (y_homogeneous / &elevated_weight).map_err(GeometryError::Numeric)?,
            profile_axis,
        ));
        elevated_weights.push(elevated_weight);
    }
    Ok(MaterializedSurfacePcurve {
        curve: Curve2::from(RationalBezier2::try_new(elevated_points, elevated_weights)?),
        correspondence: SurfacePcurveCorrespondence::Affine {
            scale: parameter_span.clone(),
            offset: parameter_start.clone(),
        },
    })
}

fn intersect_plane_rational_bezier_surface(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if let Some(direction) = linear_tensor_u_direction(&surface.control_points, &surface.weights)? {
        let profile_controls = surface
            .control_points
            .iter()
            .map(|row| row[0].clone())
            .collect::<Vec<_>>();
        let profile_weights = surface
            .weights
            .iter()
            .map(|row| row[0].clone())
            .collect::<Vec<_>>();
        let profile = Curve3::rational_bezier(profile_controls.clone(), profile_weights)?;
        match intersect_plane_linear_tensor_graph(
            plane,
            profile,
            &profile_controls,
            direction,
            TensorAxis::V,
            Real::one(),
            Real::zero(),
        ) {
            Ok(intersection) => return Ok(intersection),
            Err(GeometryError::UnsupportedIntersection) => {}
            Err(error) => return Err(error),
        }
    }
    if let Some(direction) = linear_tensor_v_direction(&surface.control_points, &surface.weights)? {
        let profile = Curve3::rational_bezier(
            surface.control_points[0].clone(),
            surface.weights[0].clone(),
        )?;
        match intersect_plane_v_linear_tensor_iso(
            plane,
            profile,
            &surface.control_points[0],
            direction,
            Real::one(),
            Real::zero(),
        ) {
            Ok(intersection) => return Ok(intersection),
            Err(GeometryError::UnsupportedIntersection) => {}
            Err(error) => return Err(error),
        }
    }
    intersect_plane_rational_bilinear(plane, surface)
}

fn intersect_plane_rational_bilinear(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if surface.control_points.len() != 2
        || surface.weights.len() != 2
        || surface
            .control_points
            .iter()
            .zip(&surface.weights)
            .any(|(points, weights)| points.len() != 2 || weights.len() != 2)
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let normal = plane.u.cross(&plane.v);
    let signed_value = |point: &Point3| normal.dot(&(point - &plane.origin));
    let values = [
        [
            signed_value(&surface.control_points[0][0]) * &surface.weights[0][0],
            signed_value(&surface.control_points[0][1]) * &surface.weights[0][1],
        ],
        [
            signed_value(&surface.control_points[1][0]) * &surface.weights[1][0],
            signed_value(&surface.control_points[1][1]) * &surface.weights[1][1],
        ],
    ];
    let orders = values
        .iter()
        .flatten()
        .map(|value| {
            decided_order(compare_reals(
                value,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    if orders.iter().all(|order| *order == Ordering::Greater)
        || orders.iter().all(|order| *order == Ordering::Less)
    {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    if orders.iter().all(|order| *order == Ordering::Equal) {
        return Ok(SurfaceSurfaceIntersection::ContainedSurface(
            SurfaceIntersectionOperand::Second,
        ));
    }
    if let Some(intersection) =
        sign_definite_bilinear_boundary_intersection(plane, surface, &orders)?
    {
        return Ok(intersection);
    }

    for parameter_axis in [TensorAxis::V, TensorAxis::U] {
        let Some(pcurve) = bilinear_plane_parameter_graph(&values, parameter_axis)? else {
            continue;
        };
        if rational_curve_bounds_inside_unit_square(&pcurve)? {
            return Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                rational_bilinear_section(plane, surface, pcurve)?,
            )));
        }
        return clip_rational_bilinear_parameter_graph(plane, surface, &pcurve);
    }
    intersect_plane_bilinear_pole_branches(plane, surface, &values)
}

fn sign_definite_bilinear_boundary_intersection(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    orders: &[Ordering],
) -> GeometryResult<Option<SurfaceSurfaceIntersection>> {
    let has_positive = orders.contains(&Ordering::Greater);
    let has_negative = orders.contains(&Ordering::Less);
    if has_positive && has_negative {
        return Ok(None);
    }

    let zeros = [
        orders[0] == Ordering::Equal,
        orders[1] == Ordering::Equal,
        orders[2] == Ordering::Equal,
        orders[3] == Ordering::Equal,
    ];
    let zero_count = zeros.iter().filter(|zero| **zero).count();
    debug_assert!((1..=3).contains(&zero_count));
    match zero_count {
        1 => {
            let index = zeros
                .iter()
                .position(|zero| *zero)
                .expect("one sign-definite bilinear zero");
            Ok(Some(SurfaceSurfaceIntersection::Point(Box::new(
                bilinear_corner(surface, index),
            ))))
        }
        2 if zeros[0] && zeros[1] => Ok(Some(SurfaceSurfaceIntersection::Curve(Box::new(
            rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::U, &Real::zero())?,
        )))),
        2 if zeros[2] && zeros[3] => Ok(Some(SurfaceSurfaceIntersection::Curve(Box::new(
            rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::U, &Real::one())?,
        )))),
        2 if zeros[0] && zeros[2] => Ok(Some(SurfaceSurfaceIntersection::Curve(Box::new(
            rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::V, &Real::zero())?,
        )))),
        2 if zeros[1] && zeros[3] => Ok(Some(SurfaceSurfaceIntersection::Curve(Box::new(
            rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::V, &Real::one())?,
        )))),
        2 => Ok(Some(SurfaceSurfaceIntersection::Points(
            zeros
                .iter()
                .enumerate()
                .filter(|(_, zero)| **zero)
                .map(|(index, _)| bilinear_corner(surface, index))
                .collect(),
        ))),
        3 => {
            let nonzero = zeros
                .iter()
                .position(|zero| !*zero)
                .expect("one nonzero sign-definite bilinear corner");
            let constant = if nonzero < 2 {
                Real::one()
            } else {
                Real::zero()
            };
            let horizontal =
                rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::U, &constant)?;
            let constant = if nonzero % 2 == 0 {
                Real::one()
            } else {
                Real::zero()
            };
            let vertical =
                rational_bilinear_iso_section(plane, surface, SurfaceIsoAxis::V, &constant)?;
            Ok(Some(SurfaceSurfaceIntersection::Curves(vec![
                horizontal, vertical,
            ])))
        }
        _ => unreachable!("all-zero bilinear relations are handled as overlap"),
    }
}

fn bilinear_corner(surface: &RationalBezierSurface, index: usize) -> Point3 {
    surface.control_points[index / 2][index % 2].clone()
}

fn rational_bilinear_section(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    pcurve: Curve2,
) -> GeometryResult<SurfaceIntersectionCurve> {
    let spatial =
        rational_bilinear_parameter_curve(&surface.control_points, &surface.weights, &pcurve)?
            .ok_or(GeometryError::UnsupportedIntersection)?;
    Ok(SurfaceIntersectionCurve::new(
        spatial.clone(),
        SurfaceIntersectionPcurve::plane_projection(spatial, plane),
        SurfaceIntersectionPcurve::retained_curve(pcurve)?,
    ))
}

fn clip_rational_bilinear_parameter_graph(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    pcurve: &Curve2,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let region = tensor_parameter_region(
        TensorAxis::V,
        &Real::zero(),
        &Real::one(),
        &Real::zero(),
        &Real::one(),
    )?;
    let trimmed = pcurve.trim_inside_region_with_parameters(&region)?;
    let mut intervals: Vec<(Real, Real)> = Vec::with_capacity(trimmed.len());
    for fragment in trimmed {
        let Some((start, end)) = fragment.represented_parameter_range() else {
            return Err(GeometryError::UnrepresentableParameter);
        };
        if let Some((_, previous_end)) = intervals.last_mut()
            && decided_order(compare_reals(
                previous_end,
                &start,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
        {
            *previous_end = end;
        } else {
            intervals.push((start, end));
        }
    }
    let mut sections = intervals
        .into_iter()
        .map(|(start, end)| {
            rational_bilinear_section(
                plane,
                surface,
                pcurve.clone().subcurve(start.into(), end.into())?,
            )
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    match sections.len() {
        0 => Err(GeometryError::UnsupportedIntersection),
        1 => Ok(SurfaceSurfaceIntersection::Curve(Box::new(
            sections.pop().expect("one retained bilinear fragment"),
        ))),
        _ => Ok(SurfaceSurfaceIntersection::Curves(sections)),
    }
}

fn bilinear_plane_parameter_graph(
    values: &[[Real; 2]; 2],
    parameter_axis: TensorAxis,
) -> GeometryResult<Option<Curve2>> {
    let coefficients = bilinear_graph_coefficients(values, parameter_axis);
    bilinear_parameter_graph_from_endpoints(
        coefficients.first_offset,
        coefficients.second_offset,
        coefficients.first_denominator,
        coefficients.second_denominator,
        &Real::zero(),
        &Real::one(),
        parameter_axis,
    )
}

struct BilinearGraphCoefficients {
    first_offset: Real,
    second_offset: Real,
    first_denominator: Real,
    second_denominator: Real,
}

fn bilinear_graph_coefficients(
    values: &[[Real; 2]; 2],
    parameter_axis: TensorAxis,
) -> BilinearGraphCoefficients {
    match parameter_axis {
        TensorAxis::V => BilinearGraphCoefficients {
            first_offset: values[0][0].clone(),
            second_offset: values[1][0].clone(),
            first_denominator: &values[0][1] - &values[0][0],
            second_denominator: &values[1][1] - &values[1][0],
        },
        TensorAxis::U => BilinearGraphCoefficients {
            first_offset: values[0][0].clone(),
            second_offset: values[0][1].clone(),
            first_denominator: &values[1][0] - &values[0][0],
            second_denominator: &values[1][1] - &values[0][1],
        },
    }
}

fn bilinear_parameter_graph_from_endpoints(
    first_offset: Real,
    second_offset: Real,
    first_denominator: Real,
    second_denominator: Real,
    first_parameter: &Real,
    second_parameter: &Real,
    parameter_axis: TensorAxis,
) -> GeometryResult<Option<Curve2>> {
    let first_order = decided_order(compare_reals(
        &first_denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    let second_order = decided_order(compare_reals(
        &second_denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    let sign = match (first_order, second_order) {
        (Ordering::Greater, Ordering::Greater) => Real::one(),
        (Ordering::Less, Ordering::Less) => -Real::one(),
        _ => return Ok(None),
    };
    let denominator_sum = &first_denominator + &second_denominator;
    let middle_denominator = (&denominator_sum / Real::from(2)).map_err(GeometryError::Numeric)?;
    let numerators = [-first_offset, -second_offset];
    let solved_controls = [
        (&numerators[0] / &first_denominator).map_err(GeometryError::Numeric)?,
        ((&numerators[0] + &numerators[1]) / &denominator_sum).map_err(GeometryError::Numeric)?,
        (&numerators[1] / &second_denominator).map_err(GeometryError::Numeric)?,
    ];
    let middle_parameter = ((first_parameter * &second_denominator
        + second_parameter * &first_denominator)
        / &denominator_sum)
        .map_err(GeometryError::Numeric)?;
    let controls = match parameter_axis {
        TensorAxis::V => vec![
            CurvePoint2::new(solved_controls[0].clone(), first_parameter.clone()),
            CurvePoint2::new(solved_controls[1].clone(), middle_parameter),
            CurvePoint2::new(solved_controls[2].clone(), second_parameter.clone()),
        ],
        TensorAxis::U => vec![
            CurvePoint2::new(first_parameter.clone(), solved_controls[0].clone()),
            CurvePoint2::new(middle_parameter, solved_controls[1].clone()),
            CurvePoint2::new(second_parameter.clone(), solved_controls[2].clone()),
        ],
    };
    let weights = vec![
        &sign * first_denominator,
        &sign * middle_denominator,
        sign * second_denominator,
    ];
    Ok(Some(Curve2::from(RationalBezier2::try_new(
        controls, weights,
    )?)))
}

fn intersect_plane_bilinear_pole_branches(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    values: &[[Real; 2]; 2],
) -> GeometryResult<SurfaceSurfaceIntersection> {
    for parameter_axis in [TensorAxis::V, TensorAxis::U] {
        let coefficients = bilinear_graph_coefficients(values, parameter_axis);
        let first_offset = &coefficients.first_offset;
        let second_offset = &coefficients.second_offset;
        let first_denominator = &coefficients.first_denominator;
        let second_denominator = &coefficients.second_denominator;
        let first_denominator_order = decided_order(compare_reals(
            first_denominator,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))?;
        let second_denominator_order = decided_order(compare_reals(
            second_denominator,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))?;
        if first_denominator_order == Ordering::Equal && second_denominator_order == Ordering::Equal
        {
            continue;
        }
        if let Some(pole) = linear_root_in_unit_interval(first_denominator, second_denominator)?
            && decided_order(compare_reals(
                &linear_value(first_offset, second_offset, &pole),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
        {
            return factorized_bilinear_sections(
                plane,
                surface,
                parameter_axis,
                &pole,
                &coefficients,
            );
        }

        let mut boundaries = vec![Real::zero(), Real::one()];
        for (first, second) in [
            (first_offset, second_offset),
            (
                &(first_offset + first_denominator),
                &(second_offset + second_denominator),
            ),
            (first_denominator, second_denominator),
        ] {
            if let Some(root) = linear_root_in_unit_interval(first, second)? {
                insert_sorted_real_unique(&mut boundaries, root)?;
            }
        }

        let mut sections = Vec::new();
        for interval in boundaries.windows(2) {
            let start = &interval[0];
            let end = &interval[1];
            if decided_order(compare_reals(start, end, crate::STRICT_PREDICATES))? != Ordering::Less
            {
                continue;
            }
            let midpoint = ((start + end) / Real::from(2)).map_err(GeometryError::Numeric)?;
            let midpoint_denominator =
                linear_value(first_denominator, second_denominator, &midpoint);
            if decided_order(compare_reals(
                &midpoint_denominator,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                continue;
            }
            let midpoint_solved = (-linear_value(first_offset, second_offset, &midpoint)
                / midpoint_denominator)
                .map_err(GeometryError::Numeric)?;
            if decided_order(compare_reals(
                &midpoint_solved,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
                || decided_order(compare_reals(
                    &midpoint_solved,
                    &Real::one(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Greater
            {
                continue;
            }

            let start_denominator = linear_value(first_denominator, second_denominator, start);
            let end_denominator = linear_value(first_denominator, second_denominator, end);
            let Some(pcurve) = bilinear_parameter_graph_from_endpoints(
                linear_value(first_offset, second_offset, start),
                linear_value(first_offset, second_offset, end),
                start_denominator,
                end_denominator,
                start,
                end,
                parameter_axis,
            )?
            else {
                return Err(GeometryError::UnsupportedIntersection);
            };
            sections.push(rational_bilinear_section(plane, surface, pcurve)?);
        }
        if !sections.is_empty() {
            return match sections.len() {
                1 => Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                    sections.pop().expect("one retained bilinear pole branch"),
                ))),
                _ => Ok(SurfaceSurfaceIntersection::Curves(sections)),
            };
        }
    }
    Err(GeometryError::UnsupportedIntersection)
}

fn factorized_bilinear_sections(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    parameter_axis: TensorAxis,
    pole: &Real,
    coefficients: &BilinearGraphCoefficients,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let pole_iso_axis = match parameter_axis {
        TensorAxis::V => SurfaceIsoAxis::U,
        TensorAxis::U => SurfaceIsoAxis::V,
    };
    let mut sections = vec![rational_bilinear_iso_section(
        plane,
        surface,
        pole_iso_axis,
        pole,
    )?];

    let sample = if decided_order(compare_reals(pole, &Real::zero(), crate::STRICT_PREDICATES))?
        == Ordering::Equal
    {
        Real::one()
    } else {
        Real::zero()
    };
    let sample_denominator = linear_value(
        &coefficients.first_denominator,
        &coefficients.second_denominator,
        &sample,
    );
    if decided_order(compare_reals(
        &sample_denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        let solved = (-linear_value(
            &coefficients.first_offset,
            &coefficients.second_offset,
            &sample,
        ) / sample_denominator)
            .map_err(GeometryError::Numeric)?;
        if decided_order(compare_reals(
            &solved,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Less
            && decided_order(compare_reals(
                &solved,
                &Real::one(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
        {
            let solved_iso_axis = match parameter_axis {
                TensorAxis::V => SurfaceIsoAxis::V,
                TensorAxis::U => SurfaceIsoAxis::U,
            };
            sections.push(rational_bilinear_iso_section(
                plane,
                surface,
                solved_iso_axis,
                &solved,
            )?);
        }
    }
    match sections.len() {
        1 => Ok(SurfaceSurfaceIntersection::Curve(Box::new(
            sections.pop().expect("one retained factorized iso-line"),
        ))),
        _ => Ok(SurfaceSurfaceIntersection::Curves(sections)),
    }
}

fn rational_bilinear_iso_section(
    plane: &PlaneSurface,
    surface: &RationalBezierSurface,
    axis: SurfaceIsoAxis,
    constant: &Real,
) -> GeometryResult<SurfaceIntersectionCurve> {
    let carrier =
        Surface::rational_bezier(surface.control_points.clone(), surface.weights.clone())?;
    let spatial = carrier.iso_curve(axis, constant)?;
    let pcurve = match axis {
        SurfaceIsoAxis::U => Curve2::from(LineSeg2::try_new(
            CurvePoint2::new(Real::zero(), constant.clone()),
            CurvePoint2::new(Real::one(), constant.clone()),
        )?),
        SurfaceIsoAxis::V => Curve2::from(LineSeg2::try_new(
            CurvePoint2::new(constant.clone(), Real::zero()),
            CurvePoint2::new(constant.clone(), Real::one()),
        )?),
    };
    Ok(SurfaceIntersectionCurve::new(
        spatial.clone(),
        SurfaceIntersectionPcurve::plane_projection(spatial, plane),
        SurfaceIntersectionPcurve::retained_curve(pcurve)?,
    ))
}

fn linear_root_in_unit_interval(first: &Real, second: &Real) -> GeometryResult<Option<Real>> {
    let delta = second - first;
    if decided_order(compare_reals(
        &delta,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return Ok(None);
    }
    let root = (-first / delta).map_err(GeometryError::Numeric)?;
    if decided_order(compare_reals(
        &root,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Less
        || decided_order(compare_reals(&root, &Real::one(), crate::STRICT_PREDICATES))?
            == Ordering::Greater
    {
        Ok(None)
    } else {
        Ok(Some(root))
    }
}

fn linear_value(first: &Real, second: &Real, parameter: &Real) -> Real {
    first + (second - first) * parameter
}

fn insert_sorted_real_unique(values: &mut Vec<Real>, value: Real) -> GeometryResult<()> {
    let mut insertion = 0;
    while insertion < values.len() {
        match decided_order(compare_reals(
            &value,
            &values[insertion],
            crate::STRICT_PREDICATES,
        ))? {
            Ordering::Less => break,
            Ordering::Equal => return Ok(()),
            Ordering::Greater => insertion += 1,
        }
    }
    values.insert(insertion, value);
    Ok(())
}

fn rational_curve_bounds_inside_unit_square(curve: &Curve2) -> GeometryResult<bool> {
    let Some(CurveGeometry2::RationalBezier(curve)) = curve.geometry() else {
        return Ok(false);
    };
    let Ok(bounds) = curve.certified_bounds() else {
        return Ok(false);
    };
    for point in [bounds.min(), bounds.max()] {
        for coordinate in [point.x(), point.y()] {
            if decided_order(compare_reals(
                coordinate,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
                || decided_order(compare_reals(
                    coordinate,
                    &Real::one(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Greater
            {
                return Ok(false);
            }
        }
    }
    Ok(true)
}

pub(crate) fn rational_bilinear_parameter_curve(
    surface_points: &[Vec<Point3>],
    surface_weights: &[Vec<Real>],
    pcurve: &Curve2,
) -> GeometryResult<Option<Curve3>> {
    if surface_points.len() != 2
        || surface_weights.len() != 2
        || surface_points
            .iter()
            .zip(surface_weights)
            .any(|(points, weights)| points.len() != 2 || weights.len() != 2)
    {
        return Ok(None);
    }
    let Some(CurveGeometry2::RationalBezier(graph)) = pcurve.geometry() else {
        return Ok(None);
    };
    if graph.degree() != 2 {
        return Ok(None);
    }
    let u: [Real; 3] = std::array::from_fn(|index| graph.homogeneous_controls()[index].x().clone());
    let v: [Real; 3] = std::array::from_fn(|index| graph.homogeneous_controls()[index].y().clone());
    let w: [Real; 3] = std::array::from_fn(|index| graph.weights()[index].clone());
    let w_minus_u = std::array::from_fn(|index| &w[index] - &u[index]);
    let w_minus_v = std::array::from_fn(|index| &w[index] - &v[index]);
    let coefficients = [
        quadratic_bernstein_product(&w_minus_u, &w_minus_v)?,
        quadratic_bernstein_product(&u, &w_minus_v)?,
        quadratic_bernstein_product(&w_minus_u, &v)?,
        quadratic_bernstein_product(&u, &v)?,
    ];
    let corners = [
        &surface_points[0][0],
        &surface_points[0][1],
        &surface_points[1][0],
        &surface_points[1][1],
    ];
    let corner_weights = [
        &surface_weights[0][0],
        &surface_weights[0][1],
        &surface_weights[1][0],
        &surface_weights[1][1],
    ];
    let curve_weights: [Real; 5] = std::array::from_fn(|index| {
        corner_weights
            .iter()
            .zip(&coefficients)
            .fold(Real::zero(), |sum, (weight, coefficients)| {
                sum + *weight * &coefficients[index]
            })
    });
    let mut controls = Vec::with_capacity(5);
    for index in 0..5 {
        let numerator = corners.iter().zip(corner_weights).zip(&coefficients).fold(
            Vector3::zero(),
            |sum, ((point, weight), coefficients)| {
                sum + Vector3::from((*point).clone()) * (weight * &coefficients[index])
            },
        );
        controls.push(Point3::new(
            (&numerator.0[0] / &curve_weights[index]).map_err(GeometryError::Numeric)?,
            (&numerator.0[1] / &curve_weights[index]).map_err(GeometryError::Numeric)?,
            (&numerator.0[2] / &curve_weights[index]).map_err(GeometryError::Numeric)?,
        ));
    }
    Ok(Some(Curve3::rational_bezier(
        controls,
        curve_weights.to_vec(),
    )?))
}

fn quadratic_bernstein_product(first: &[Real; 3], second: &[Real; 3]) -> GeometryResult<[Real; 5]> {
    Ok([
        &first[0] * &second[0],
        ((&first[0] * &second[1] + &first[1] * &second[0]) / Real::from(2))
            .map_err(GeometryError::Numeric)?,
        ((&first[0] * &second[2]
            + Real::from(4) * &first[1] * &second[1]
            + &first[2] * &second[0])
            / Real::from(6))
        .map_err(GeometryError::Numeric)?,
        ((&first[1] * &second[2] + &first[2] * &second[1]) / Real::from(2))
            .map_err(GeometryError::Numeric)?,
        &first[2] * &second[2],
    ])
}

fn bernstein_product(first: &[Real], second: &[Real]) -> GeometryResult<Vec<Real>> {
    let Some(first_degree) = first.len().checked_sub(1) else {
        return Err(GeometryError::InvalidDegree);
    };
    let Some(second_degree) = second.len().checked_sub(1) else {
        return Err(GeometryError::InvalidDegree);
    };
    let product_degree = first_degree
        .checked_add(second_degree)
        .ok_or(GeometryError::InvalidDegree)?;
    let mut product = Vec::with_capacity(product_degree + 1);
    for product_index in 0..=product_degree {
        let first_min = product_index.saturating_sub(second_degree);
        let first_max = first_degree.min(product_index);
        let denominator = binomial_real(product_degree, product_index)?;
        let mut coefficient = Real::zero();
        for (first_index, first_value) in
            first.iter().enumerate().take(first_max + 1).skip(first_min)
        {
            let second_index = product_index - first_index;
            let numerator = binomial_real(first_degree, first_index)?
                * binomial_real(second_degree, second_index)?;
            coefficient += (numerator * first_value * &second[second_index] / &denominator)
                .map_err(GeometryError::Numeric)?;
        }
        product.push(coefficient);
    }
    Ok(product)
}

fn intersect_plane_extrusion(
    plane: &PlaneSurface,
    surface: &ExtrusionSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let denominator = normal.dot(&surface.direction);
    if decided_order(compare_reals(
        &denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        let plane_surface = Surface::plane(plane.origin.clone(), plane.u.clone(), plane.v.clone())?;
        return match plane_surface.intersect_curve(&surface.profile)? {
            CurveSurfaceIntersection::None => Ok(SurfaceSurfaceIntersection::None),
            CurveSurfaceIntersection::Contained | CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
                Err(GeometryError::UnsupportedIntersection)
            }
            CurveSurfaceIntersection::Points(points) => {
                let mut lines = points
                    .into_iter()
                    .map(|point| Ok(SurfaceIntersectionLine {
                        point: point.point.try_coordinates().cloned().ok_or(GeometryError::UnrepresentablePoint)?,
                        direction: surface.direction.clone(),
                    }))
                    .collect::<GeometryResult<Vec<_>>>()?;
                if lines.len() == 1 {
                    Ok(SurfaceSurfaceIntersection::Line(Box::new(
                        lines.pop().expect("one retained extrusion line"),
                    )))
                } else {
                    Ok(SurfaceSurfaceIntersection::Lines(lines))
                }
            }
        };
    }
    if !matches!(
        surface.profile.kind(),
        Curve3Kind::Line | Curve3Kind::RationalBezier | Curve3Kind::Nurbs
    ) {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let curve = project_curve_onto_plane_along_direction(
        &surface.profile,
        plane,
        &surface.direction,
        &denominator,
    )?;
    Ok(SurfaceSurfaceIntersection::Curve(Box::new(
        SurfaceIntersectionCurve::new(
            curve.clone(),
            SurfaceIntersectionPcurve::plane_projection(curve, plane),
            SurfaceIntersectionPcurve::linear_plane_section(
                surface.profile.clone(),
                plane,
                denominator,
                TensorAxis::U,
                Real::one(),
                Real::zero(),
            ),
        ),
    )))
}

fn intersect_plane_revolution(
    plane: &PlaneSurface,
    surface: &RevolutionSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    if decided_order(compare_reals(
        &normal.cross(&surface.axis).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let plane_surface = Surface::plane(plane.origin.clone(), plane.u.clone(), plane.v.clone())?;
    let points = match plane_surface.intersect_curve(&surface.profile)? {
        CurveSurfaceIntersection::None => return Ok(SurfaceSurfaceIntersection::None),
        CurveSurfaceIntersection::Contained | CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
            return Err(GeometryError::UnsupportedIntersection);
        }
        CurveSurfaceIntersection::Points(points) => points,
    };
    let mut sections = Vec::with_capacity(points.len());
    let mut singular = None;
    let mut radii = Vec::<Real>::with_capacity(points.len());
    for point in points {
        let relative = point.point.try_coordinates().ok_or(GeometryError::UnrepresentablePoint)? - &surface.axis_origin;
        let axial_parameter = relative.dot(&surface.axis);
        let center = surface.axis_origin.clone() + surface.axis.clone() * axial_parameter.clone();
        let radial = relative - surface.axis.clone() * axial_parameter;
        let radius_squared = radial.norm_squared();
        if decided_order(compare_reals(
            &radius_squared,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            if singular.replace(center).is_some() {
                return Err(GeometryError::UnsupportedIntersection);
            }
            continue;
        }
        let radius = radius_squared.sqrt().map_err(GeometryError::Numeric)?;
        for existing in &radii {
            if decided_order(compare_reals(existing, &radius, crate::STRICT_PREDICATES))?
                == Ordering::Equal
            {
                return Err(GeometryError::UnsupportedIntersection);
            }
        }
        radii.push(radius.clone());
        let radial_direction = (radial / &radius).map_err(GeometryError::Numeric)?;
        let curve = Curve3::circle_arc(
            center,
            radial_direction.clone(),
            surface.axis.cross(&radial_direction),
            radius,
            Real::zero(),
            Real::tau(),
        )?;
        let domain = curve.domain().clone();
        sections.push(SurfaceIntersectionCurve::new(
            curve.clone(),
            SurfaceIntersectionPcurve::plane_projection(curve, plane),
            SurfaceIntersectionPcurve::tensor_iso_v(domain, point.parameter.try_real().cloned().ok_or(GeometryError::UnrepresentableParameter)?),
        ));
    }
    if let Some(point) = singular {
        if sections.is_empty() {
            return Ok(SurfaceSurfaceIntersection::Point(Box::new(point)));
        }
        return Err(GeometryError::UnsupportedIntersection);
    }
    Ok(match sections.len() {
        0 => SurfaceSurfaceIntersection::None,
        1 => SurfaceSurfaceIntersection::Curve(Box::new(
            sections.pop().expect("one revolution section"),
        )),
        _ => SurfaceSurfaceIntersection::Curves(sections),
    })
}

struct ProjectedRevolutionMeridian {
    curve: Curve2,
    radial_direction: Vector3,
}

fn project_revolution_meridian(
    surface: &RevolutionSurface,
    common_axis_origin: &Point3,
    common_axis: &Vector3,
) -> GeometryResult<ProjectedRevolutionMeridian> {
    let controls = match surface.profile.exact_data() {
        Curve3ExactData::Line(line) => vec![line.start, line.end],
        Curve3ExactData::RationalBezier { control_points, .. }
        | Curve3ExactData::Nurbs { control_points, .. } => control_points,
        Curve3ExactData::EllipseArc(_) | Curve3ExactData::PlanarImage(_) => {
            return Err(GeometryError::UnsupportedIntersection);
        }
    };
    let radials = controls
        .iter()
        .map(|control| {
            let relative = control - common_axis_origin;
            &relative - &(common_axis.clone() * relative.dot(common_axis))
        })
        .collect::<Vec<_>>();
    let mut first_nonzero_radial = None;
    for radial in &radials {
        if decided_order(compare_reals(
            &radial.norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
        {
            first_nonzero_radial = Some(radial);
            break;
        }
    }
    let radial = first_nonzero_radial.ok_or(GeometryError::UnsupportedIntersection)?;
    let radial_length = radial
        .norm_squared()
        .sqrt()
        .map_err(GeometryError::Numeric)?;
    let radial_direction = (radial.clone() / &radial_length).map_err(GeometryError::Numeric)?;
    for radial in &radials {
        if decided_order(compare_reals(
            &radial.cross(&radial_direction).norm_squared(),
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
            || decided_order(compare_reals(
                &radial.dot(&radial_direction),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Greater
        {
            return Err(GeometryError::UnsupportedIntersection);
        }
    }
    let curve = project_curve_to_plane_frame(
        &surface.profile,
        common_axis_origin,
        &radial_direction,
        common_axis,
    )?
    .ok_or(GeometryError::UnsupportedIntersection)?;
    Ok(ProjectedRevolutionMeridian {
        curve,
        radial_direction,
    })
}

fn intersect_coaxial_revolutions(
    first: &RevolutionSurface,
    second: &RevolutionSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &first.axis.cross(&second.axis).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let axis_offset = &second.axis_origin - &first.axis_origin;
    let radial_axis_offset = &axis_offset - &(first.axis.clone() * axis_offset.dot(&first.axis));
    if decided_order(compare_reals(
        &radial_axis_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let axis_dot = first.axis.dot(&second.axis);
    let frames_mirrored = if decided_order(compare_reals(
        &axis_dot,
        &Real::one(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        false
    } else if decided_order(compare_reals(
        &axis_dot,
        &-Real::one(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        true
    } else {
        return Err(GeometryError::UnsupportedIntersection);
    };

    let first_meridian = project_revolution_meridian(first, &first.axis_origin, &first.axis)?;
    let second_meridian = project_revolution_meridian(second, &first.axis_origin, &first.axis)?;
    if first_meridian.curve == second_meridian.curve
        || first_meridian.curve == second_meridian.curve.reversed()?
    {
        return Ok(SurfaceSurfaceIntersection::Coincident);
    }

    let intersections = first_meridian
        .curve
        .intersect_curve(&second_meridian.curve)?;
    if !intersections.is_complete() || !intersections.overlaps().is_empty() {
        return Err(GeometryError::UnsupportedIntersection);
    }
    if intersections.is_disjoint() {
        return Ok(SurfaceSurfaceIntersection::None);
    }

    let radial_frames_equal = decided_order(compare_reals(
        &(&first_meridian.radial_direction - &second_meridian.radial_direction).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal;
    let retain_pcurves = radial_frames_equal;
    let mut circles = Vec::with_capacity(intersections.contacts().len());
    let mut retained = Vec::with_capacity(intersections.contacts().len());
    let mut locations = Vec::<(Real, Real)>::with_capacity(intersections.contacts().len());
    for contact in intersections.contacts() {
        let first_parameter =
            resolve_planar_classification(crate::error::classified(contact.first().parameter())?)?;
        let second_parameter =
            resolve_planar_classification(crate::error::classified(contact.second().parameter())?)?;
        // Spatial isoparametric pcurves currently require scalar parameters.
        let first_parameter = first_parameter
            .scalar()
            .cloned()
            .ok_or(GeometryError::UnrepresentableParameter)?;
        let second_parameter = second_parameter
            .scalar()
            .cloned()
            .ok_or(GeometryError::UnrepresentableParameter)?;
        let first_point = first_meridian
            .curve
            .point_at(&first_parameter.clone().into())?;
        let second_point = second_meridian
            .curve
            .point_at(&second_parameter.clone().into())?;
        let first_point = first_point
            .coordinates()
            .ok_or(GeometryError::UnrepresentableParameter)?;
        let second_point = second_point
            .coordinates()
            .ok_or(GeometryError::UnrepresentableParameter)?;
        if decided_order(compare_reals(
            first_point.x(),
            second_point.x(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
            || decided_order(compare_reals(
                first_point.y(),
                second_point.y(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
        {
            return Err(GeometryError::UnsupportedIntersection);
        }
        for (radius, height) in &locations {
            if decided_order(compare_reals(
                radius,
                first_point.x(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
                && decided_order(compare_reals(
                    height,
                    first_point.y(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Equal
            {
                return Err(GeometryError::UnsupportedIntersection);
            }
        }
        locations.push((first_point.x().clone(), first_point.y().clone()));
        let center = first.axis_origin.clone() + first.axis.clone() * first_point.y().clone();
        let curve = Curve3::circle_arc(
            center,
            first_meridian.radial_direction.clone(),
            first.axis.cross(&first_meridian.radial_direction),
            first_point.x().clone(),
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), first_parameter),
                angular_iso_v_pcurve(domain, second_parameter, frames_mirrored),
            ));
        } else {
            circles.push(curve);
        }
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one revolution/revolution circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match circles.len() {
            1 => SurfaceSurfaceIntersection::Circle(
                circles.pop().expect("one revolution/revolution circle"),
            ),
            _ => SurfaceSurfaceIntersection::Circles(circles),
        })
    }
}

fn intersect_plane_nurbs_surface(
    plane: &PlaneSurface,
    surface: &NurbsSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if surface.u_degree == 1
        && let Some(direction) =
            linear_tensor_u_direction(&surface.control_points, &surface.weights)?
    {
        let profile_controls = surface
            .control_points
            .iter()
            .map(|row| row[0].clone())
            .collect::<Vec<_>>();
        let profile_weights = surface
            .weights
            .iter()
            .map(|row| row[0].clone())
            .collect::<Vec<_>>();
        let profile = Curve3::nurbs(
            surface.v_degree,
            profile_controls.clone(),
            profile_weights,
            surface.v_knots.clone(),
        )?;
        let coefficient_offset = surface.u_knots[surface.u_degree].clone();
        let coefficient_scale =
            &surface.u_knots[surface.control_points[0].len()] - &coefficient_offset;
        match intersect_plane_linear_tensor_graph(
            plane,
            profile,
            &profile_controls,
            direction,
            TensorAxis::V,
            coefficient_scale,
            coefficient_offset,
        ) {
            Ok(intersection) => return Ok(intersection),
            Err(GeometryError::UnsupportedIntersection) => {}
            Err(error) => return Err(error),
        }
    }
    if surface.v_degree == 1
        && let Some(direction) =
            linear_tensor_v_direction(&surface.control_points, &surface.weights)?
    {
        let profile = Curve3::nurbs(
            surface.u_degree,
            surface.control_points[0].clone(),
            surface.weights[0].clone(),
            surface.u_knots.clone(),
        )?;
        let coefficient_offset = surface.v_knots[surface.v_degree].clone();
        let coefficient_scale =
            &surface.v_knots[surface.control_points.len()] - &coefficient_offset;
        return intersect_plane_v_linear_tensor_iso(
            plane,
            profile,
            &surface.control_points[0],
            direction,
            coefficient_scale,
            coefficient_offset,
        );
    }
    intersect_plane_projective_bilinear_nurbs(plane, surface)
}

fn intersect_plane_projective_bilinear_nurbs(
    plane: &PlaneSurface,
    surface: &NurbsSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if surface.u_degree != 1
        || surface.v_degree != 1
        || surface.control_points.len() != 2
        || surface.weights.len() != 2
        || surface
            .control_points
            .iter()
            .zip(&surface.weights)
            .any(|(points, weights)| points.len() != 2 || weights.len() != 2)
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let bezier = RationalBezierSurface {
        control_points: surface.control_points.clone(),
        weights: surface.weights.clone(),
        homogeneous_controls: OnceLock::new(),
    };
    let intersection = intersect_plane_rational_bilinear(plane, &bezier)?;
    let u_start = surface.u_knots[surface.u_degree].clone();
    let u_span = &surface.u_knots[surface.control_points[0].len()] - &u_start;
    let v_start = surface.v_knots[surface.v_degree].clone();
    let v_span = &surface.v_knots[surface.control_points.len()] - &v_start;
    let remap = |mut section: SurfaceIntersectionCurve| -> GeometryResult<_> {
        section.second_pcurve =
            remap_unit_tensor_pcurve(section.second_pcurve, &u_start, &u_span, &v_start, &v_span)?;
        Ok(section)
    };
    Ok(match intersection {
        SurfaceSurfaceIntersection::Curve(section) => {
            SurfaceSurfaceIntersection::Curve(Box::new(remap(*section)?))
        }
        SurfaceSurfaceIntersection::Curves(sections) => SurfaceSurfaceIntersection::Curves(
            sections
                .into_iter()
                .map(remap)
                .collect::<GeometryResult<Vec<_>>>()?,
        ),
        other => other,
    })
}

fn remap_unit_tensor_pcurve(
    pcurve: SurfaceIntersectionPcurve,
    u_start: &Real,
    u_span: &Real,
    v_start: &Real,
    v_span: &Real,
) -> GeometryResult<SurfaceIntersectionPcurve> {
    let SurfaceIntersectionPcurve {
        domain,
        source_scale,
        source_offset,
        mapping,
    } = pcurve;
    let SurfaceIntersectionPcurveMapping::RetainedCurve { curve } = mapping else {
        return Err(GeometryError::UnsupportedIntersection);
    };
    let map = |point: &CurvePoint2| {
        CurvePoint2::new(u_start + u_span * point.x(), v_start + v_span * point.y())
    };
    let curve = match curve.geometry() {
        Some(CurveGeometry2::Line(line)) => {
            Curve2::from(LineSeg2::try_new(map(line.start()), map(line.end()))?)
        }
        Some(CurveGeometry2::RationalBezier(curve)) => {
            let controls = curve
                .homogeneous_controls()
                .iter()
                .map(|control| {
                    hypercurve::HomogeneousControl2::new(
                        u_start * control.weight() + u_span * control.x(),
                        v_start * control.weight() + v_span * control.y(),
                        control.weight().clone(),
                    )
                })
                .collect();
            let Classification::Decided(curve) =
                crate::error::classified(RationalBezier2::from_homogeneous_controls(controls))?
            else {
                return Err(GeometryError::UnsupportedIntersection);
            };
            Curve2::from(curve)
        }
        _ => return Err(GeometryError::UnsupportedIntersection),
    };
    Ok(SurfaceIntersectionPcurve {
        domain,
        source_scale,
        source_offset,
        mapping: SurfaceIntersectionPcurveMapping::RetainedCurve { curve },
    })
}

fn linear_tensor_u_direction(
    control_points: &[Vec<Point3>],
    weights: &[Vec<Real>],
) -> GeometryResult<Option<Vector3>> {
    if control_points.is_empty()
        || control_points.len() != weights.len()
        || control_points
            .iter()
            .zip(weights)
            .any(|(points, row_weights)| points.len() != 2 || row_weights.len() != 2)
    {
        return Ok(None);
    }
    for row in weights {
        if decided_order(compare_reals(&row[0], &row[1], crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Ok(None);
        }
    }
    let direction = &control_points[0][1] - &control_points[0][0];
    if decided_order(compare_reals(
        &direction.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Greater
    {
        return Ok(None);
    }
    for row in control_points {
        if !points_equal(&(row[0].clone() + direction.clone()), &row[1])? {
            return Ok(None);
        }
    }
    Ok(Some(direction))
}

fn linear_tensor_v_direction(
    control_points: &[Vec<Point3>],
    weights: &[Vec<Real>],
) -> GeometryResult<Option<Vector3>> {
    if control_points.len() != 2
        || weights.len() != 2
        || control_points[0].len() != control_points[1].len()
        || weights[0].len() != weights[1].len()
    {
        return Ok(None);
    }
    for (first, second) in weights[0].iter().zip(&weights[1]) {
        if decided_order(compare_reals(first, second, crate::STRICT_PREDICATES))? != Ordering::Equal
        {
            return Ok(None);
        }
    }
    let direction = &control_points[1][0] - &control_points[0][0];
    if decided_order(compare_reals(
        &direction.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Greater
    {
        return Ok(None);
    }
    for (first, second) in control_points[0].iter().zip(&control_points[1]) {
        if !points_equal(&(first.clone() + direction.clone()), second)? {
            return Ok(None);
        }
    }
    Ok(Some(direction))
}

fn intersect_plane_linear_tensor_graph(
    plane: &PlaneSurface,
    profile: Curve3,
    profile_controls: &[Point3],
    direction: Vector3,
    profile_axis: TensorAxis,
    coefficient_scale: Real,
    coefficient_offset: Real,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let signed_plane_value = |point: &Point3| normal.dot(&(point - &plane.origin));
    let values = profile_controls
        .iter()
        .map(signed_plane_value)
        .collect::<Vec<_>>();
    let denominator = normal.dot(&direction);
    if decided_order(compare_reals(
        &denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        if curve_is_strictly_on_one_plane_side(&profile, &signed_plane_value)? {
            return Ok(SurfaceSurfaceIntersection::None);
        }
        let plane_surface = Surface::plane(plane.origin.clone(), plane.u.clone(), plane.v.clone())?;
        return match plane_surface.intersect_curve(&profile)? {
            CurveSurfaceIntersection::None => Ok(SurfaceSurfaceIntersection::None),
            CurveSurfaceIntersection::Contained | CurveSurfaceIntersection::Overlap(_) | CurveSurfaceIntersection::Components(_) => {
                Err(GeometryError::UnsupportedIntersection)
            }
            CurveSurfaceIntersection::Points(points) => {
                let mut curves = points
                    .into_iter()
                    .map(|point| {
                        let coordinates = point.point.try_coordinates().ok_or(GeometryError::UnrepresentablePoint)?;
                        let curve = Curve3::line(coordinates.clone(), coordinates.clone() + direction.clone())?;
                        Ok(SurfaceIntersectionCurve::new(
                            curve.clone(),
                            SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane),
                            SurfaceIntersectionPcurve::tensor_iso(
                                curve.domain().clone(),
                                point.parameter.try_real().cloned().ok_or(GeometryError::UnrepresentableParameter)?,
                                profile_axis,
                                coefficient_scale.clone(),
                                coefficient_offset.clone(),
                            ),
                        ))
                    })
                    .collect::<GeometryResult<Vec<_>>>()?;
                Ok(match curves.as_mut_slice() {
                    [curve] => SurfaceSurfaceIntersection::Curve(Box::new(curve.clone())),
                    _ => SurfaceSurfaceIntersection::Curves(curves),
                })
            }
        };
    }

    let coefficients = values
        .into_iter()
        .map(|value| ((-value) / &denominator).map_err(GeometryError::Numeric))
        .collect::<GeometryResult<Vec<_>>>()?;
    let coefficient_orders = coefficients
        .iter()
        .map(|coefficient| {
            Ok((
                decided_order(compare_reals(
                    coefficient,
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))?,
                decided_order(compare_reals(
                    coefficient,
                    &Real::one(),
                    crate::STRICT_PREDICATES,
                ))?,
            ))
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    if coefficient_orders
        .iter()
        .all(|(zero, _)| *zero == Ordering::Less)
        || coefficient_orders
            .iter()
            .all(|(_, one)| *one == Ordering::Greater)
    {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    let complete = coefficient_orders.iter().all(|(zero, one)| {
        matches!(zero, Ordering::Equal | Ordering::Greater)
            && matches!(one, Ordering::Equal | Ordering::Less)
    });

    let curve =
        project_curve_onto_plane_along_direction(&profile, plane, &direction, &denominator)?;
    let section = SurfaceIntersectionCurve::new(
        curve.clone(),
        SurfaceIntersectionPcurve::plane_projection(curve, plane),
        SurfaceIntersectionPcurve::linear_plane_section(
            profile,
            plane,
            denominator,
            profile_axis,
            coefficient_scale.clone(),
            coefficient_offset.clone(),
        ),
    );
    if complete {
        return Ok(SurfaceSurfaceIntersection::Curve(Box::new(section)));
    }
    clip_linear_tensor_section(
        &section,
        profile_axis,
        &coefficient_offset,
        &(&coefficient_offset + coefficient_scale),
    )
}

fn curve_is_strictly_on_one_plane_side(
    curve: &Curve3,
    signed_plane_value: &impl Fn(&Point3) -> Real,
) -> GeometryResult<bool> {
    let controls_are_strictly_one_sided = |controls: &[Point3]| -> GeometryResult<bool> {
        let orders = controls
            .iter()
            .map(|point| {
                decided_order(compare_reals(
                    &signed_plane_value(point),
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))
            })
            .collect::<GeometryResult<Vec<_>>>()?;
        let endpoints_are = |side| orders.first() == Some(&side) && orders.last() == Some(&side);
        Ok((endpoints_are(Ordering::Greater)
            && orders
                .iter()
                .all(|order| matches!(order, Ordering::Greater | Ordering::Equal)))
            || (endpoints_are(Ordering::Less)
                && orders
                    .iter()
                    .all(|order| matches!(order, Ordering::Less | Ordering::Equal))))
    };

    match &curve.data.geometry {
        CurveGeometry3::Line(line) => {
            controls_are_strictly_one_sided(&[line.start.clone(), line.end.clone()])
        }
        CurveGeometry3::RationalBezier(curve) => {
            controls_are_strictly_one_sided(&curve.control_points)
        }
        CurveGeometry3::Nurbs(curve) => {
            for (span, _) in decompose_nurbs_into_bezier_segments(curve)? {
                let CurveGeometry3::RationalBezier(span) = &span.data.geometry else {
                    unreachable!("NURBS decomposition produces rational Bézier spans");
                };
                if !controls_are_strictly_one_sided(&span.control_points)? {
                    return Ok(false);
                }
            }
            Ok(true)
        }
        CurveGeometry3::CircleArc(_)
        | CurveGeometry3::EllipseArc(_)
        | CurveGeometry3::PlanarImage(_) => Ok(false),
    }
}

fn clip_linear_tensor_section(
    section: &SurfaceIntersectionCurve,
    profile_axis: TensorAxis,
    coefficient_start: &Real,
    coefficient_end: &Real,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let profile_start = section.curve.domain().start();
    let profile_end = section.curve.domain().end();
    let region = tensor_parameter_region(
        profile_axis,
        profile_start,
        profile_end,
        coefficient_start,
        coefficient_end,
    )?;
    let materialized = section.second_pcurve.materialize()?;
    let trimmed = materialized
        .curve()
        .trim_inside_region_with_parameters(&region)?;
    let mut intervals: Vec<(Real, Real)> = Vec::with_capacity(trimmed.len());
    for fragment in trimmed {
        let Some((pcurve_start, pcurve_end)) = fragment.represented_parameter_range() else {
            return Err(GeometryError::UnrepresentableParameter);
        };
        let spatial_start = materialized.spatial_parameter_at(&pcurve_start)?;
        let spatial_end = materialized.spatial_parameter_at(&pcurve_end)?;
        if let Some((_, previous_end)) = intervals.last_mut()
            && decided_order(compare_reals(
                previous_end,
                &spatial_start,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
        {
            *previous_end = spatial_end;
        } else {
            intervals.push((spatial_start, spatial_end));
        }
    }
    let mut fragments = intervals
        .into_iter()
        .map(|(start, end)| section.subcurve(&start, &end))
        .collect::<GeometryResult<Vec<_>>>()?;
    match fragments.len() {
        0 => Err(GeometryError::UnsupportedIntersection),
        1 => Ok(SurfaceSurfaceIntersection::Curve(Box::new(
            fragments.pop().expect("one retained fragment"),
        ))),
        _ => Ok(SurfaceSurfaceIntersection::Curves(fragments)),
    }
}

fn tensor_parameter_region(
    profile_axis: TensorAxis,
    profile_start: &Real,
    profile_end: &Real,
    coefficient_start: &Real,
    coefficient_end: &Real,
) -> GeometryResult<CurveRegion2> {
    let points = match profile_axis {
        TensorAxis::U => [
            CurvePoint2::new(profile_start.clone(), coefficient_start.clone()),
            CurvePoint2::new(profile_end.clone(), coefficient_start.clone()),
            CurvePoint2::new(profile_end.clone(), coefficient_end.clone()),
            CurvePoint2::new(profile_start.clone(), coefficient_end.clone()),
        ],
        TensorAxis::V => [
            CurvePoint2::new(coefficient_start.clone(), profile_start.clone()),
            CurvePoint2::new(coefficient_end.clone(), profile_start.clone()),
            CurvePoint2::new(coefficient_end.clone(), profile_end.clone()),
            CurvePoint2::new(coefficient_start.clone(), profile_end.clone()),
        ],
    };
    let contour = Contour2::try_new(
        (0..points.len())
            .map(|index| {
                LineSeg2::try_new(
                    points[index].clone(),
                    points[(index + 1) % points.len()].clone(),
                )
                .map(Segment2::Line)
            })
            .collect::<Result<Vec<_>, _>>()?,
    )?;
    Ok(CurveRegion2::try_from_native_material_contours(vec![
        contour,
    ])?)
}

fn project_curve_onto_plane_along_direction(
    curve: &Curve3,
    plane: &PlaneSurface,
    direction: &Vector3,
    denominator: &Real,
) -> GeometryResult<Curve3> {
    let normal = plane.u.cross(&plane.v);
    let constant = normal.dot(&Vector3::from(plane.origin.clone()));
    let ratio = |row: usize, column: usize| {
        ((&direction.0[row] * &normal.0[column]) / denominator).map_err(GeometryError::Numeric)
    };
    let translation = |row: usize| {
        ((&direction.0[row] * &constant) / denominator).map_err(GeometryError::Numeric)
    };
    let projection = Matrix4::from_row_major([
        Real::one() - ratio(0, 0)?,
        -ratio(0, 1)?,
        -ratio(0, 2)?,
        translation(0)?,
        -ratio(1, 0)?,
        Real::one() - ratio(1, 1)?,
        -ratio(1, 2)?,
        translation(1)?,
        -ratio(2, 0)?,
        -ratio(2, 1)?,
        Real::one() - ratio(2, 2)?,
        translation(2)?,
        Real::zero(),
        Real::zero(),
        Real::zero(),
        Real::one(),
    ]);
    curve.transformed(&projection)
}

fn intersect_plane_v_linear_tensor_iso(
    plane: &PlaneSurface,
    profile: Curve3,
    profile_controls: &[Point3],
    direction: Vector3,
    coefficient_scale: Real,
    coefficient_offset: Real,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let plane_value = |point: &Point3| normal.dot(&(point - &plane.origin));
    let offset = plane_value(&profile_controls[0]);
    for control in profile_controls.iter().skip(1) {
        if decided_order(compare_reals(
            &plane_value(control),
            &offset,
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
        {
            return intersect_plane_linear_tensor_graph(
                plane,
                profile,
                profile_controls,
                direction,
                TensorAxis::U,
                coefficient_scale,
                coefficient_offset,
            );
        }
    }
    let denominator = normal.dot(&direction);
    if decided_order(compare_reals(
        &denominator,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return if decided_order(compare_reals(
            &offset,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            Err(GeometryError::UnsupportedIntersection)
        } else {
            Ok(SurfaceSurfaceIntersection::None)
        };
    }
    let normalized_fraction = ((-offset) / denominator).map_err(GeometryError::Numeric)?;
    if decided_order(compare_reals(
        &normalized_fraction,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Less
        || decided_order(compare_reals(
            &normalized_fraction,
            &Real::one(),
            crate::STRICT_PREDICATES,
        ))? == Ordering::Greater
    {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    let translated = profile.transformed(&Matrix4::affine_translation([
        direction.0[0].clone() * &normalized_fraction,
        direction.0[1].clone() * &normalized_fraction,
        direction.0[2].clone() * &normalized_fraction,
    ]))?;
    let surface_parameter = coefficient_offset + coefficient_scale * normalized_fraction;
    Ok(SurfaceSurfaceIntersection::Curve(Box::new(
        SurfaceIntersectionCurve::new(
            translated.clone(),
            SurfaceIntersectionPcurve::plane_projection(translated, plane),
            SurfaceIntersectionPcurve::tensor_iso_v(profile.domain().clone(), surface_parameter),
        ),
    )))
}

fn intersect_plane_sphere(
    plane: &PlaneSurface,
    sphere: &SphereSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let normal_squared = normal.norm_squared();
    let axial = decided_order(compare_reals(
        &normal.cross(&sphere.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal;
    let separation = normal.dot(&(&sphere.center - &plane.origin));
    let distance_squared =
        ((&separation * &separation) / &normal_squared).map_err(GeometryError::Numeric)?;
    let radius_squared = &sphere.radius * &sphere.radius;
    match decided_order(compare_reals(
        &distance_squared,
        &radius_squared,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Greater => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal | Ordering::Less => {
            let projection_scale =
                (&separation / &normal_squared).map_err(GeometryError::Numeric)?;
            let center = sphere.center.clone() - normal.clone() * projection_scale;
            if decided_order(compare_reals(
                &distance_squared,
                &radius_squared,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                return Ok(SurfaceSurfaceIntersection::Point(Box::new(center)));
            }
            let radius = (radius_squared - distance_squared)
                .sqrt()
                .map_err(GeometryError::Numeric)?;
            if axial {
                let height = ((-&separation) / normal.dot(&sphere.frame.z))
                    .map_err(GeometryError::Numeric)?;
                let center = sphere.center.clone() + sphere.frame.z.clone() * &height;
                let curve = Curve3::circle_arc(
                    center,
                    sphere.frame.x.clone(),
                    sphere.frame.y.clone(),
                    radius,
                    Real::zero(),
                    Real::tau(),
                )?;
                let latitude = (height / &sphere.radius)
                    .map_err(GeometryError::Numeric)?
                    .asin()
                    .map_err(GeometryError::Numeric)?;
                let domain = curve.domain().clone();
                return Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                    SurfaceIntersectionCurve::new(
                        curve.clone(),
                        SurfaceIntersectionPcurve::plane_projection(curve, plane),
                        SurfaceIntersectionPcurve::tensor_iso_v(domain, latitude),
                    ),
                )));
            }
            let unit_normal = normal.normalize().map_err(GeometryError::Numeric)?;
            let x = plane.u.normalize().map_err(GeometryError::Numeric)?;
            let y = unit_normal.cross(&x);
            Ok(SurfaceSurfaceIntersection::Circle(Curve3::circle_arc(
                center,
                x,
                y,
                radius,
                Real::zero(),
                Real::from(2) * Real::pi(),
            )?))
        }
    }
}

fn intersect_plane_cylinder(
    plane: &PlaneSurface,
    cylinder: &CylinderSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let normal_squared = normal.norm_squared();
    let axis_cross_normal = cylinder.frame.z.cross(&normal);
    if decided_order(compare_reals(
        &axis_cross_normal.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        let denominator = normal.dot(&cylinder.frame.z);
        let numerator = normal.dot(&(&plane.origin - &cylinder.origin));
        let axial_parameter = (numerator / denominator).map_err(GeometryError::Numeric)?;
        let center = cylinder.origin.clone() + cylinder.frame.z.clone() * axial_parameter.clone();
        let curve = Curve3::circle_arc(
            center,
            cylinder.frame.x.clone(),
            cylinder.frame.y.clone(),
            cylinder.radius.clone(),
            Real::zero(),
            Real::from(2) * Real::pi(),
        )?;
        let domain = curve.domain().clone();
        return Ok(SurfaceSurfaceIntersection::Curve(Box::new(
            SurfaceIntersectionCurve::new(
                curve.clone(),
                SurfaceIntersectionPcurve::plane_projection(curve, plane),
                SurfaceIntersectionPcurve::tensor_iso_v(domain, axial_parameter),
            ),
        )));
    }

    let axis_dot_normal = cylinder.frame.z.dot(&normal);
    if decided_order(compare_reals(
        &axis_dot_normal,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        let separation = normal.dot(&(&plane.origin - &cylinder.origin));
        let axial_center = (separation / &axis_dot_normal).map_err(GeometryError::Numeric)?;
        let center = cylinder.origin.clone() + cylinder.frame.z.clone() * axial_center;
        let radial_normal = normal.clone() - cylinder.frame.z.clone() * axis_dot_normal.clone();
        let radial_normal_length = radial_normal
            .norm_squared()
            .sqrt()
            .map_err(GeometryError::Numeric)?;
        let radial_parallel =
            (radial_normal / &radial_normal_length).map_err(GeometryError::Numeric)?;
        let radial_perpendicular = cylinder.frame.z.cross(&radial_parallel);
        let slope = (&radial_normal_length / &axis_dot_normal).map_err(GeometryError::Numeric)?;
        let sloped_axis = radial_parallel - cylinder.frame.z.clone() * slope;
        let sloped_length = sloped_axis
            .norm_squared()
            .sqrt()
            .map_err(GeometryError::Numeric)?;
        let sloped_direction = (sloped_axis / &sloped_length).map_err(GeometryError::Numeric)?;
        return Ok(SurfaceSurfaceIntersection::Ellipse(Curve3::ellipse_arc(
            center,
            radial_perpendicular,
            sloped_direction,
            cylinder.radius.clone(),
            cylinder.radius.clone() * sloped_length,
            Real::zero(),
            Real::from(2) * Real::pi(),
        )?));
    }
    let separation = normal.dot(&(&plane.origin - &cylinder.origin));
    let distance_squared =
        ((&separation * &separation) / &normal_squared).map_err(GeometryError::Numeric)?;
    let radius_squared = &cylinder.radius * &cylinder.radius;
    match decided_order(compare_reals(
        &distance_squared,
        &radius_squared,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Greater => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal | Ordering::Less => {
            let projection_scale =
                (separation / &normal_squared).map_err(GeometryError::Numeric)?;
            let radial_projection = normal.clone() * projection_scale;
            let line_offset_squared = &radius_squared - &distance_squared;
            let tangent = cylinder
                .frame
                .z
                .cross(&normal)
                .normalize()
                .map_err(GeometryError::Numeric)?;
            if decided_order(compare_reals(
                &line_offset_squared,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                return Ok(SurfaceSurfaceIntersection::Line(Box::new(
                    SurfaceIntersectionLine {
                        point: cylinder.origin.clone() + radial_projection,
                        direction: cylinder.frame.z.clone(),
                    },
                )));
            }
            let line_offset = line_offset_squared.sqrt().map_err(GeometryError::Numeric)?;
            Ok(SurfaceSurfaceIntersection::Lines(vec![
                SurfaceIntersectionLine {
                    point: cylinder.origin.clone()
                        + radial_projection.clone()
                        + tangent.clone() * &line_offset,
                    direction: cylinder.frame.z.clone(),
                },
                SurfaceIntersectionLine {
                    point: cylinder.origin.clone() + radial_projection - tangent * line_offset,
                    direction: cylinder.frame.z.clone(),
                },
            ]))
        }
    }
}

fn intersect_plane_cone(
    plane: &PlaneSurface,
    cone: &ConeSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let axis_cross_normal = decided_order(compare_reals(
        &cone.frame.z.cross(&normal).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if axis_cross_normal != Ordering::Equal {
        let axis_dot_normal = cone.frame.z.dot(&normal);
        let apex_separation = normal.dot(&(&cone.apex - &plane.origin));
        if decided_order(compare_reals(
            &axis_dot_normal,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
            || decided_order(compare_reals(
                &apex_separation,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
        {
            return Err(GeometryError::UnsupportedIntersection);
        }
        let radial = normal
            .cross(&cone.frame.z)
            .normalize()
            .map_err(GeometryError::Numeric)?;
        let sine = cone.semi_angle.clone().sin();
        let cosine = cone.semi_angle.clone().cos();
        let ray = |radial: Vector3| -> GeometryResult<SurfaceIntersectionRay> {
            let direction = radial.clone() * &sine + cone.frame.z.clone() * &cosine;
            let plane_origin =
                project_point_to_plane_frame(&plane.origin, &plane.u, &plane.v, &cone.apex)?;
            let plane_end = project_point_to_plane_frame(
                &plane.origin,
                &plane.u,
                &plane.v,
                &(cone.apex.clone() + direction.clone()),
            )?;
            let mut u = certified_atan2(radial.dot(&cone.frame.y), radial.dot(&cone.frame.x))?;
            if decided_order(compare_reals(&u, &Real::zero(), crate::STRICT_PREDICATES))?
                == Ordering::Less
            {
                u += Real::tau();
            }
            Ok(SurfaceIntersectionRay::new(
                cone.apex.clone(),
                direction,
                Real::zero(),
                SurfaceIntersectionParameterRay::new(
                    plane_origin.clone(),
                    Vector2::from_xy(
                        &plane_end.x - &plane_origin.x,
                        &plane_end.y - &plane_origin.y,
                    ),
                ),
                SurfaceIntersectionParameterRay::new(Point2::new(u, Real::zero()), Vector2::y()),
            ))
        };
        return Ok(SurfaceSurfaceIntersection::Rays(vec![
            ray(radial.clone())?,
            ray(-radial)?,
        ]));
    }
    let axial_height = (normal.dot(&(&plane.origin - &cone.apex)) / normal.dot(&cone.frame.z))
        .map_err(GeometryError::Numeric)?;
    match decided_order(compare_reals(
        &axial_height,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal => Ok(SurfaceSurfaceIntersection::Point(Box::new(
            cone.apex.clone(),
        ))),
        Ordering::Greater => {
            let (v, radius) = cone_section_parameters(cone, &axial_height)?;
            let center = cone.apex.clone() + cone.frame.z.clone() * axial_height.clone();
            let curve = Curve3::circle_arc(
                center,
                cone.frame.x.clone(),
                cone.frame.y.clone(),
                radius,
                Real::zero(),
                Real::from(2) * Real::pi(),
            )?;
            let domain = curve.domain().clone();
            Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                SurfaceIntersectionCurve::new(
                    curve.clone(),
                    SurfaceIntersectionPcurve::plane_projection(curve, plane),
                    SurfaceIntersectionPcurve::tensor_iso_v(domain, v),
                ),
            )))
        }
    }
}

/// A transverse section uses the cone's own meridian parameter and radial
/// image. Share this representation between curve and surface intersections,
/// so their witnesses compose with the authored cone pcurves.
fn cone_section_parameters(
    cone: &ConeSurface,
    axial_height: &Real,
) -> GeometryResult<(Real, Real)> {
    let parameter =
        (axial_height / cone.semi_angle.clone().cos()).map_err(GeometryError::Numeric)?;
    let radius = &parameter * cone.semi_angle.clone().sin();
    Ok((parameter, radius))
}

fn intersect_plane_torus(
    plane: &PlaneSurface,
    torus: &TorusSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let normal = plane.u.cross(&plane.v);
    let axis_cross_normal_order = decided_order(compare_reals(
        &torus.frame.z.cross(&normal).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if axis_cross_normal_order != Ordering::Equal {
        let axis_dot_normal = torus.frame.z.dot(&normal);
        let center_separation = normal.dot(&(&torus.center - &plane.origin));
        if decided_order(compare_reals(
            &axis_dot_normal,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
        {
            return Err(GeometryError::UnsupportedIntersection);
        }
        if decided_order(compare_reals(
            &center_separation,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
        {
            let distance_squared = ((&center_separation * &center_separation)
                / normal.norm_squared())
            .map_err(GeometryError::Numeric)?;
            let outer_radius = &torus.major_radius + &torus.minor_radius;
            match decided_order(compare_reals(
                &distance_squared,
                &(&outer_radius * &outer_radius),
                crate::STRICT_PREDICATES,
            ))? {
                Ordering::Greater => return Ok(SurfaceSurfaceIntersection::None),
                Ordering::Equal => {
                    let projection_scale = (center_separation / normal.norm_squared())
                        .map_err(GeometryError::Numeric)?;
                    return Ok(SurfaceSurfaceIntersection::Point(Box::new(
                        torus.center.clone() - normal.clone() * projection_scale,
                    )));
                }
                Ordering::Less => {}
            }
            return Err(GeometryError::UnsupportedIntersection);
        }

        let radial = normal
            .cross(&torus.frame.z)
            .normalize()
            .map_err(GeometryError::Numeric)?;
        let normalize_angle = |angle: Real| -> GeometryResult<Real> {
            Ok(
                if decided_order(compare_reals(
                    &angle,
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Less
                {
                    angle + Real::tau()
                } else {
                    angle
                },
            )
        };
        let section = |radial: Vector3| -> GeometryResult<SurfaceIntersectionCurve> {
            let u = normalize_angle(certified_atan2(
                radial.dot(&torus.frame.y),
                radial.dot(&torus.frame.x),
            )?)?;
            let curve = Curve3::circle_arc(
                torus.center.clone() + radial.clone() * &torus.major_radius,
                radial,
                torus.frame.z.clone(),
                torus.minor_radius.clone(),
                Real::zero(),
                Real::tau(),
            )?;
            let domain = curve.domain().clone();
            Ok(SurfaceIntersectionCurve::new(
                curve.clone(),
                SurfaceIntersectionPcurve::plane_projection(curve, plane),
                SurfaceIntersectionPcurve::tensor_iso(
                    domain,
                    u,
                    TensorAxis::U,
                    Real::one(),
                    Real::zero(),
                ),
            ))
        };
        return Ok(SurfaceSurfaceIntersection::Curves(vec![
            section(radial.clone())?,
            section(-radial)?,
        ]));
    }
    let axial_height = (normal.dot(&(&plane.origin - &torus.center)) / normal.dot(&torus.frame.z))
        .map_err(GeometryError::Numeric)?;
    let axial_squared = &axial_height * &axial_height;
    let minor_squared = &torus.minor_radius * &torus.minor_radius;
    match decided_order(compare_reals(
        &axial_squared,
        &minor_squared,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Greater => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal | Ordering::Less => {
            let radial_offset = (minor_squared - axial_squared)
                .sqrt()
                .map_err(GeometryError::Numeric)?;
            let center = torus.center.clone() + torus.frame.z.clone() * axial_height.clone();
            let normalize_angle = |angle: Real| -> GeometryResult<Real> {
                Ok(
                    if decided_order(compare_reals(
                        &angle,
                        &Real::zero(),
                        crate::STRICT_PREDICATES,
                    ))? == Ordering::Less
                    {
                        angle + Real::tau()
                    } else {
                        angle
                    },
                )
            };
            let section = |radius: Real, v: Real| -> GeometryResult<SurfaceIntersectionCurve> {
                let curve = Curve3::circle_arc(
                    center.clone(),
                    torus.frame.x.clone(),
                    torus.frame.y.clone(),
                    radius,
                    Real::zero(),
                    Real::tau(),
                )?;
                let domain = curve.domain().clone();
                Ok(SurfaceIntersectionCurve::new(
                    curve.clone(),
                    SurfaceIntersectionPcurve::plane_projection(curve, plane),
                    SurfaceIntersectionPcurve::tensor_iso_v(domain, v),
                ))
            };
            if decided_order(compare_reals(
                &radial_offset,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                let v = normalize_angle(certified_atan2(axial_height, radial_offset)?)?;
                return Ok(SurfaceSurfaceIntersection::Curve(Box::new(section(
                    torus.major_radius.clone(),
                    v,
                )?)));
            }
            let outer_v = normalize_angle(certified_atan2(
                axial_height.clone(),
                radial_offset.clone(),
            )?)?;
            let inner_v = normalize_angle(certified_atan2(axial_height, -radial_offset.clone())?)?;
            Ok(SurfaceSurfaceIntersection::Curves(vec![
                section(&torus.major_radius + &radial_offset, outer_v)?,
                section(&torus.major_radius - radial_offset, inner_v)?,
            ]))
        }
    }
}

fn intersect_parallel_cylinders(
    first: &CylinderSurface,
    second: &CylinderSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &first.frame.z.cross(&second.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let displacement = &second.origin - &first.origin;
    let radial_displacement =
        &displacement - &(first.frame.z.clone() * displacement.dot(&first.frame.z));
    let distance_squared = radial_displacement.norm_squared();
    if decided_order(compare_reals(
        &distance_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return if decided_order(compare_reals(
            &first.radius,
            &second.radius,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            Ok(SurfaceSurfaceIntersection::Coincident)
        } else {
            Ok(SurfaceSurfaceIntersection::None)
        };
    }
    let distance = distance_squared
        .clone()
        .sqrt()
        .map_err(GeometryError::Numeric)?;
    let radius_sum = &first.radius + &second.radius;
    let radius_difference = match decided_order(compare_reals(
        &first.radius,
        &second.radius,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => &second.radius - &first.radius,
        Ordering::Equal | Ordering::Greater => &first.radius - &second.radius,
    };
    if decided_order(compare_reals(
        &distance,
        &radius_sum,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
        || decided_order(compare_reals(
            &distance,
            &radius_difference,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Less
    {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    let along = ((&first.radius * &first.radius - &second.radius * &second.radius
        + &distance_squared)
        / (Real::from(2) * &distance))
        .map_err(GeometryError::Numeric)?;
    let unit_displacement = (radial_displacement / &distance).map_err(GeometryError::Numeric)?;
    let base = first.origin.clone() + unit_displacement.clone() * &along;
    let height_squared = &first.radius * &first.radius - &along * &along;
    if decided_order(compare_reals(
        &height_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return Ok(SurfaceSurfaceIntersection::Line(Box::new(
            SurfaceIntersectionLine {
                point: base,
                direction: first.frame.z.clone(),
            },
        )));
    }
    let height = height_squared.sqrt().map_err(GeometryError::Numeric)?;
    let transverse = first.frame.z.cross(&unit_displacement);
    Ok(SurfaceSurfaceIntersection::Lines(vec![
        SurfaceIntersectionLine {
            point: base.clone() + transverse.clone() * &height,
            direction: first.frame.z.clone(),
        },
        SurfaceIntersectionLine {
            point: base - transverse * height,
            direction: first.frame.z.clone(),
        },
    ]))
}

fn intersect_coaxial_sphere_cylinder(
    sphere: &SphereSurface,
    cylinder: &CylinderSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let center_offset = &sphere.center - &cylinder.origin;
    let axial_offset = center_offset.dot(&cylinder.frame.z);
    let radial_offset = center_offset - cylinder.frame.z.clone() * &axial_offset;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let sphere_radius_squared = &sphere.radius * &sphere.radius;
    let cylinder_radius_squared = &cylinder.radius * &cylinder.radius;
    let frames_match = orthonormal_frames_equal(&sphere.frame, &cylinder.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&sphere.frame, &cylinder.frame)?;
    let retain_pcurves = frames_match || frames_mirrored;
    let retained_circle = |height: Real| -> GeometryResult<SurfaceIntersectionCurve> {
        let center = sphere.center.clone() + cylinder.frame.z.clone() * &height;
        let curve = Curve3::circle_arc(
            center.clone(),
            sphere.frame.x.clone(),
            sphere.frame.y.clone(),
            cylinder.radius.clone(),
            Real::zero(),
            Real::tau(),
        )?;
        let sphere_height = (&center - &sphere.center).dot(&sphere.frame.z);
        let latitude = (sphere_height / &sphere.radius)
            .map_err(GeometryError::Numeric)?
            .asin()
            .map_err(GeometryError::Numeric)?;
        let cylinder_height = &axial_offset + height;
        let domain = curve.domain().clone();
        Ok(SurfaceIntersectionCurve::new(
            curve,
            SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), latitude),
            angular_iso_v_pcurve(domain, cylinder_height, frames_mirrored),
        ))
    };
    match decided_order(compare_reals(
        &sphere_radius_squared,
        &cylinder_radius_squared,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal => {
            if retain_pcurves {
                Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                    retained_circle(Real::zero())?,
                )))
            } else {
                Ok(SurfaceSurfaceIntersection::Circle(Curve3::circle_arc(
                    sphere.center.clone(),
                    cylinder.frame.x.clone(),
                    cylinder.frame.y.clone(),
                    cylinder.radius.clone(),
                    Real::zero(),
                    Real::tau(),
                )?))
            }
        }
        Ordering::Greater => {
            let axial_distance = (sphere_radius_squared - cylinder_radius_squared)
                .sqrt()
                .map_err(GeometryError::Numeric)?;
            if retain_pcurves {
                return Ok(SurfaceSurfaceIntersection::Curves(vec![
                    retained_circle(axial_distance.clone())?,
                    retained_circle(-axial_distance)?,
                ]));
            }
            Ok(SurfaceSurfaceIntersection::Circles(vec![
                Curve3::circle_arc(
                    sphere.center.clone() + cylinder.frame.z.clone() * &axial_distance,
                    cylinder.frame.x.clone(),
                    cylinder.frame.y.clone(),
                    cylinder.radius.clone(),
                    Real::zero(),
                    Real::from(2) * Real::pi(),
                )?,
                Curve3::circle_arc(
                    sphere.center.clone() - cylinder.frame.z.clone() * axial_distance,
                    cylinder.frame.x.clone(),
                    cylinder.frame.y.clone(),
                    cylinder.radius.clone(),
                    Real::zero(),
                    Real::from(2) * Real::pi(),
                )?,
            ]))
        }
    }
}

fn intersect_coaxial_sphere_cone(
    sphere: &SphereSurface,
    cone: &ConeSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let center_offset = &sphere.center - &cone.apex;
    let axial_offset = center_offset.dot(&cone.frame.z);
    let radial_offset = center_offset - cone.frame.z.clone() * &axial_offset;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let sine = cone.semi_angle.clone().sin();
    let cosine = cone.semi_angle.clone().cos();
    let discriminant =
        &sphere.radius * &sphere.radius - &axial_offset * &axial_offset * &sine * &sine;
    let discriminant_order = decided_order(compare_reals(
        &discriminant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if discriminant_order == Ordering::Less {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    let root_center = &axial_offset * &cosine;
    let root_parameters = if discriminant_order == Ordering::Equal {
        vec![root_center]
    } else {
        let root_offset = discriminant.sqrt().map_err(GeometryError::Numeric)?;
        vec![&root_center - &root_offset, root_center + root_offset]
    };
    let mut has_apex = false;
    let mut slant_parameters = Vec::with_capacity(root_parameters.len());
    for parameter in root_parameters {
        match decided_order(compare_reals(
            &parameter,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? {
            Ordering::Less => {}
            Ordering::Equal => {
                has_apex = true;
            }
            Ordering::Greater => slant_parameters.push(parameter),
        }
    }
    if has_apex && slant_parameters.is_empty() {
        return Ok(SurfaceSurfaceIntersection::Point(Box::new(
            cone.apex.clone(),
        )));
    }
    if slant_parameters.is_empty() {
        return Ok(SurfaceSurfaceIntersection::None);
    }

    let frames_match = orthonormal_frames_equal(&sphere.frame, &cone.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&sphere.frame, &cone.frame)?;
    let retain_pcurves = frames_match || frames_mirrored;
    let mut circles = Vec::with_capacity(slant_parameters.len());
    let mut retained = Vec::with_capacity(slant_parameters.len());
    for parameter in slant_parameters {
        let axial_height = &parameter * &cosine;
        let radius = &parameter * &sine;
        let center = cone.apex.clone() + cone.frame.z.clone() * &axial_height;
        let curve = Curve3::circle_arc(
            center.clone(),
            cone.frame.x.clone(),
            cone.frame.y.clone(),
            radius,
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let sphere_height = (&center - &sphere.center).dot(&sphere.frame.z);
            let latitude = (sphere_height / &sphere.radius)
                .map_err(GeometryError::Numeric)?
                .asin()
                .map_err(GeometryError::Numeric)?;
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                angular_iso_v_pcurve(domain.clone(), latitude, frames_mirrored),
                SurfaceIntersectionPcurve::tensor_iso_v(domain, parameter),
            ));
        } else {
            circles.push(curve);
        }
    }
    if has_apex {
        return Ok(SurfaceSurfaceIntersection::Components(Box::new(
            SurfaceIntersectionComponents::new(vec![cone.apex.clone()], circles, retained),
        )));
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one retained sphere/cone circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match circles.len() {
            1 => SurfaceSurfaceIntersection::Circle(circles.pop().expect("one sphere/cone circle")),
            _ => SurfaceSurfaceIntersection::Circles(circles),
        })
    }
}

fn intersect_coaxial_cylinder_cone(
    cylinder: &CylinderSurface,
    cone: &ConeSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &cylinder.frame.z.cross(&cone.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let origin_offset = &cylinder.origin - &cone.apex;
    let radial_offset = &origin_offset - &(cone.frame.z.clone() * origin_offset.dot(&cone.frame.z));
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let sine = cone.semi_angle.clone().sin();
    let cosine = cone.semi_angle.clone().cos();
    let slant_parameter = (&cylinder.radius / &sine).map_err(GeometryError::Numeric)?;
    let axial_height = &slant_parameter * cosine;
    let center = cone.apex.clone() + cone.frame.z.clone() * axial_height;
    let curve = Curve3::circle_arc(
        center.clone(),
        cone.frame.x.clone(),
        cone.frame.y.clone(),
        cylinder.radius.clone(),
        Real::zero(),
        Real::tau(),
    )?;
    let frames_match = orthonormal_frames_equal(&cylinder.frame, &cone.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&cylinder.frame, &cone.frame)?;
    if !frames_match && !frames_mirrored {
        return Ok(SurfaceSurfaceIntersection::Circle(curve));
    }
    let cylinder_height = (&center - &cylinder.origin).dot(&cylinder.frame.z);
    let domain = curve.domain().clone();
    Ok(SurfaceSurfaceIntersection::Curve(Box::new(
        SurfaceIntersectionCurve::new(
            curve,
            angular_iso_v_pcurve(domain.clone(), cylinder_height, frames_mirrored),
            SurfaceIntersectionPcurve::tensor_iso_v(domain, slant_parameter),
        ),
    )))
}

fn intersect_coaxial_cones(
    first: &ConeSurface,
    second: &ConeSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let cooriented = decided_order(compare_reals(
        &(&first.frame.z - &second.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal;
    let counteroriented = decided_order(compare_reals(
        &(&first.frame.z + &second.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal;
    if !cooriented && !counteroriented {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let apex_offset = &second.apex - &first.apex;
    let axial_offset = apex_offset.dot(&first.frame.z);
    let radial_offset = apex_offset - first.frame.z.clone() * &axial_offset;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    if counteroriented {
        return intersect_counteroriented_coaxial_cones(first, second, axial_offset);
    }

    if decided_order(compare_reals(
        &first.semi_angle,
        &second.semi_angle,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return if decided_order(compare_reals(
            &axial_offset,
            &Real::zero(),
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            Ok(SurfaceSurfaceIntersection::Coincident)
        } else {
            Ok(SurfaceSurfaceIntersection::None)
        };
    }

    let first_sine = first.semi_angle.clone().sin();
    let first_cosine = first.semi_angle.clone().cos();
    let second_sine = second.semi_angle.clone().sin();
    let second_cosine = second.semi_angle.clone().cos();
    let determinant = &first_cosine * &second_sine - &first_sine * &second_cosine;
    let first_slant =
        (&axial_offset * &second_sine / &determinant).map_err(GeometryError::Numeric)?;
    let second_slant =
        (&axial_offset * &first_sine / determinant).map_err(GeometryError::Numeric)?;
    let first_order = decided_order(compare_reals(
        &first_slant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    let second_order = decided_order(compare_reals(
        &second_slant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if first_order == Ordering::Less || second_order == Ordering::Less {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    if first_order == Ordering::Equal || second_order == Ordering::Equal {
        return Ok(SurfaceSurfaceIntersection::Point(Box::new(
            first.apex.clone(),
        )));
    }

    let axial_height = &first_slant * &first_cosine;
    let radius = &first_slant * &first_sine;
    let center = first.apex.clone() + first.frame.z.clone() * axial_height;
    let curve = Curve3::circle_arc(
        center,
        first.frame.x.clone(),
        first.frame.y.clone(),
        radius,
        Real::zero(),
        Real::tau(),
    )?;
    if !orthonormal_frames_equal(&first.frame, &second.frame)? {
        return Ok(SurfaceSurfaceIntersection::Circle(curve));
    }
    let domain = curve.domain().clone();
    Ok(SurfaceSurfaceIntersection::Curve(Box::new(
        SurfaceIntersectionCurve::new(
            curve,
            SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), first_slant),
            SurfaceIntersectionPcurve::tensor_iso_v(domain, second_slant),
        ),
    )))
}

fn intersect_counteroriented_coaxial_cones(
    first: &ConeSurface,
    second: &ConeSurface,
    axial_offset: Real,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    let axial_order = decided_order(compare_reals(
        &axial_offset,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))?;
    if axial_order == Ordering::Less {
        return Ok(SurfaceSurfaceIntersection::None);
    }
    if axial_order == Ordering::Equal {
        return Ok(SurfaceSurfaceIntersection::Point(Box::new(
            first.apex.clone(),
        )));
    }

    let first_sine = first.semi_angle.clone().sin();
    let first_cosine = first.semi_angle.clone().cos();
    let second_sine = second.semi_angle.clone().sin();
    let second_cosine = second.semi_angle.clone().cos();
    let denominator = &first_cosine * &second_sine + &first_sine * &second_cosine;
    let first_slant =
        (&axial_offset * &second_sine / &denominator).map_err(GeometryError::Numeric)?;
    let second_slant =
        (&axial_offset * &first_sine / denominator).map_err(GeometryError::Numeric)?;
    let axial_height = &first_slant * &first_cosine;
    let radius = &first_slant * &first_sine;
    let center = first.apex.clone() + first.frame.z.clone() * axial_height;
    let curve = Curve3::circle_arc(
        center,
        first.frame.x.clone(),
        first.frame.y.clone(),
        radius,
        Real::zero(),
        Real::tau(),
    )?;
    if !orthonormal_frames_mirrored(&first.frame, &second.frame)? {
        return Ok(SurfaceSurfaceIntersection::Circle(curve));
    }
    let domain = curve.domain().clone();
    Ok(SurfaceSurfaceIntersection::Curve(Box::new(
        SurfaceIntersectionCurve::new(
            curve,
            SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), first_slant),
            SurfaceIntersectionPcurve::tensor_iso(
                domain,
                second_slant,
                TensorAxis::V,
                -Real::one(),
                Real::tau(),
            ),
        ),
    )))
}

fn orthonormal_frames_equal(
    first: &OrthonormalFrame3,
    second: &OrthonormalFrame3,
) -> GeometryResult<bool> {
    [&first.x, &first.y, &first.z]
        .into_iter()
        .zip([&second.x, &second.y, &second.z])
        .try_fold(true, |matches, (first_axis, second_axis)| {
            Ok(matches
                && decided_order(compare_reals(
                    &(first_axis - second_axis).norm_squared(),
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Equal)
        })
}

fn angular_iso_v_pcurve(
    domain: ParameterDomain,
    constant: Real,
    reversed: bool,
) -> SurfaceIntersectionPcurve {
    if reversed {
        SurfaceIntersectionPcurve::tensor_iso(
            domain,
            constant,
            TensorAxis::V,
            -Real::one(),
            Real::tau(),
        )
    } else {
        SurfaceIntersectionPcurve::tensor_iso_v(domain, constant)
    }
}

fn orthonormal_frames_mirrored(
    first: &OrthonormalFrame3,
    second: &OrthonormalFrame3,
) -> GeometryResult<bool> {
    [
        (&first.x, &second.x),
        (&first.y, &-second.y.clone()),
        (&first.z, &-second.z.clone()),
    ]
    .into_iter()
    .try_fold(true, |matches, (first_axis, second_axis)| {
        Ok(matches
            && decided_order(compare_reals(
                &(first_axis - second_axis).norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal)
    })
}

enum MeridianCircleIntersection {
    Coincident,
    Points(Vec<(Real, Real)>),
}

fn intersect_meridian_circles(
    first_center_x: &Real,
    first_center_y: &Real,
    first_radius: &Real,
    second_center_x: &Real,
    second_center_y: &Real,
    second_radius: &Real,
) -> GeometryResult<MeridianCircleIntersection> {
    let displacement_x = second_center_x - first_center_x;
    let displacement_y = second_center_y - first_center_y;
    let distance_squared = &displacement_x * &displacement_x + &displacement_y * &displacement_y;
    if decided_order(compare_reals(
        &distance_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return if decided_order(compare_reals(
            first_radius,
            second_radius,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            Ok(MeridianCircleIntersection::Coincident)
        } else {
            Ok(MeridianCircleIntersection::Points(Vec::new()))
        };
    }

    let distance = distance_squared
        .clone()
        .sqrt()
        .map_err(GeometryError::Numeric)?;
    let radius_sum = first_radius + second_radius;
    let radius_difference = match decided_order(compare_reals(
        first_radius,
        second_radius,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => second_radius - first_radius,
        Ordering::Equal | Ordering::Greater => first_radius - second_radius,
    };
    if decided_order(compare_reals(
        &distance,
        &radius_sum,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
        || decided_order(compare_reals(
            &distance,
            &radius_difference,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Less
    {
        return Ok(MeridianCircleIntersection::Points(Vec::new()));
    }

    let along = ((first_radius * first_radius - second_radius * second_radius + &distance_squared)
        / (Real::from(2) * &distance))
        .map_err(GeometryError::Numeric)?;
    let inverse_distance = (Real::one() / distance).map_err(GeometryError::Numeric)?;
    let unit_x = displacement_x * &inverse_distance;
    let unit_y = displacement_y * inverse_distance;
    let base_x = first_center_x + &unit_x * &along;
    let base_y = first_center_y + &unit_y * &along;
    let transverse_squared = first_radius * first_radius - &along * &along;
    let points = match decided_order(compare_reals(
        &transverse_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => Vec::new(),
        Ordering::Equal => vec![(base_x, base_y)],
        Ordering::Greater => {
            let transverse = transverse_squared.sqrt().map_err(GeometryError::Numeric)?;
            vec![
                (
                    &base_x + &unit_y * &transverse,
                    &base_y - &unit_x * &transverse,
                ),
                (base_x - unit_y * &transverse, base_y + unit_x * transverse),
            ]
        }
    };
    Ok(MeridianCircleIntersection::Points(points))
}

fn intersect_coaxial_sphere_torus(
    sphere: &SphereSurface,
    torus: &TorusSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &sphere.frame.z.cross(&torus.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let center_offset = &torus.center - &sphere.center;
    let axial_offset = center_offset.dot(&sphere.frame.z);
    let radial_offset = center_offset - sphere.frame.z.clone() * &axial_offset;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let profile_points = match intersect_meridian_circles(
        &Real::zero(),
        &Real::zero(),
        &sphere.radius,
        &torus.major_radius,
        &axial_offset,
        &torus.minor_radius,
    )? {
        MeridianCircleIntersection::Coincident => {
            return Err(GeometryError::UnsupportedIntersection);
        }
        MeridianCircleIntersection::Points(points) if points.is_empty() => {
            return Ok(SurfaceSurfaceIntersection::None);
        }
        MeridianCircleIntersection::Points(points) => points,
    };

    let frames_equal = orthonormal_frames_equal(&sphere.frame, &torus.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&sphere.frame, &torus.frame)?;
    let retain_pcurves = frames_equal || frames_mirrored;
    let canonical_angle = |angle: Real| -> GeometryResult<Real> {
        Ok(
            if decided_order(compare_reals(
                &angle,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
            {
                angle + Real::tau()
            } else {
                angle
            },
        )
    };
    let mut curves = Vec::with_capacity(profile_points.len());
    let mut retained = Vec::with_capacity(profile_points.len());
    for (radial_distance, sphere_height) in profile_points {
        let center = sphere.center.clone() + sphere.frame.z.clone() * &sphere_height;
        let curve = Curve3::circle_arc(
            center.clone(),
            sphere.frame.x.clone(),
            sphere.frame.y.clone(),
            radial_distance.clone(),
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let sphere_v = certified_atan2(sphere_height, radial_distance.clone())?;
            let torus_v = canonical_angle(certified_atan2(
                (&center - &torus.center).dot(&torus.frame.z),
                radial_distance - &torus.major_radius,
            )?)?;
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), sphere_v),
                angular_iso_v_pcurve(domain, torus_v, frames_mirrored),
            ));
        } else {
            curves.push(curve);
        }
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one retained sphere/torus circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match curves.len() {
            1 => SurfaceSurfaceIntersection::Circle(curves.pop().expect("one sphere/torus circle")),
            _ => SurfaceSurfaceIntersection::Circles(curves),
        })
    }
}

fn intersect_coaxial_cylinder_torus(
    cylinder: &CylinderSurface,
    torus: &TorusSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &cylinder.frame.z.cross(&torus.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let center_offset = &torus.center - &cylinder.origin;
    let torus_height = center_offset.dot(&cylinder.frame.z);
    let radial_offset = center_offset - cylinder.frame.z.clone() * &torus_height;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let radial_delta = &cylinder.radius - &torus.major_radius;
    let height_squared = &torus.minor_radius * &torus.minor_radius - &radial_delta * &radial_delta;
    let heights = match decided_order(compare_reals(
        &height_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => return Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal => vec![torus_height],
        Ordering::Greater => {
            let height_offset = height_squared.sqrt().map_err(GeometryError::Numeric)?;
            vec![&torus_height - &height_offset, torus_height + height_offset]
        }
    };

    let frames_equal = orthonormal_frames_equal(&cylinder.frame, &torus.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&cylinder.frame, &torus.frame)?;
    let retain_pcurves = frames_equal || frames_mirrored;
    let canonical_angle = |angle: Real| -> GeometryResult<Real> {
        Ok(
            if decided_order(compare_reals(
                &angle,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
            {
                angle + Real::tau()
            } else {
                angle
            },
        )
    };
    let mut curves = Vec::with_capacity(heights.len());
    let mut retained = Vec::with_capacity(heights.len());
    for cylinder_height in heights {
        let center = cylinder.origin.clone() + cylinder.frame.z.clone() * &cylinder_height;
        let curve = Curve3::circle_arc(
            center.clone(),
            cylinder.frame.x.clone(),
            cylinder.frame.y.clone(),
            cylinder.radius.clone(),
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let torus_v = canonical_angle(certified_atan2(
                (&center - &torus.center).dot(&torus.frame.z),
                radial_delta.clone(),
            )?)?;
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), cylinder_height),
                angular_iso_v_pcurve(domain, torus_v, frames_mirrored),
            ));
        } else {
            curves.push(curve);
        }
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one retained cylinder/torus circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match curves.len() {
            1 => {
                SurfaceSurfaceIntersection::Circle(curves.pop().expect("one cylinder/torus circle"))
            }
            _ => SurfaceSurfaceIntersection::Circles(curves),
        })
    }
}

fn intersect_coaxial_cone_torus(
    cone: &ConeSurface,
    torus: &TorusSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &cone.frame.z.cross(&torus.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let center_offset = &torus.center - &cone.apex;
    let torus_height = center_offset.dot(&cone.frame.z);
    let radial_offset = center_offset - cone.frame.z.clone() * &torus_height;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let sine = cone.semi_angle.clone().sin();
    let cosine = cone.semi_angle.clone().cos();
    let projected_center = &torus.major_radius * &sine + &torus_height * &cosine;
    let center_norm_squared =
        &torus.major_radius * &torus.major_radius + &torus_height * &torus_height;
    let transverse_distance_squared = center_norm_squared - &projected_center * &projected_center;
    let discriminant = &torus.minor_radius * &torus.minor_radius - transverse_distance_squared;
    let candidates = match decided_order(compare_reals(
        &discriminant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => return Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal => vec![projected_center],
        Ordering::Greater => {
            let offset = discriminant.sqrt().map_err(GeometryError::Numeric)?;
            vec![&projected_center - &offset, projected_center + offset]
        }
    };
    let slants = candidates
        .into_iter()
        .map(|slant| {
            Ok((
                decided_order(compare_reals(
                    &slant,
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))? == Ordering::Greater,
                slant,
            ))
        })
        .collect::<GeometryResult<Vec<_>>>()?
        .into_iter()
        .filter_map(|(positive, slant)| positive.then_some(slant))
        .collect::<Vec<_>>();
    if slants.is_empty() {
        return Ok(SurfaceSurfaceIntersection::None);
    }

    let frames_equal = orthonormal_frames_equal(&cone.frame, &torus.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&cone.frame, &torus.frame)?;
    let retain_pcurves = frames_equal || frames_mirrored;
    let canonical_angle = |angle: Real| -> GeometryResult<Real> {
        Ok(
            if decided_order(compare_reals(
                &angle,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
            {
                angle + Real::tau()
            } else {
                angle
            },
        )
    };
    let mut curves = Vec::with_capacity(slants.len());
    let mut retained = Vec::with_capacity(slants.len());
    for slant in slants {
        let axial_height = &slant * &cosine;
        let radial_distance = &slant * &sine;
        let center = cone.apex.clone() + cone.frame.z.clone() * axial_height;
        let curve = Curve3::circle_arc(
            center.clone(),
            cone.frame.x.clone(),
            cone.frame.y.clone(),
            radial_distance.clone(),
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let torus_v = canonical_angle(certified_atan2(
                (&center - &torus.center).dot(&torus.frame.z),
                radial_distance - &torus.major_radius,
            )?)?;
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), slant),
                angular_iso_v_pcurve(domain, torus_v, frames_mirrored),
            ));
        } else {
            curves.push(curve);
        }
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one retained cone/torus circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match curves.len() {
            1 => SurfaceSurfaceIntersection::Circle(curves.pop().expect("one cone/torus circle")),
            _ => SurfaceSurfaceIntersection::Circles(curves),
        })
    }
}

fn intersect_coaxial_tori(
    first: &TorusSurface,
    second: &TorusSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    if decided_order(compare_reals(
        &first.frame.z.cross(&second.frame.z).norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }
    let center_offset = &second.center - &first.center;
    let axial_offset = center_offset.dot(&first.frame.z);
    let radial_offset = center_offset - first.frame.z.clone() * &axial_offset;
    if decided_order(compare_reals(
        &radial_offset.norm_squared(),
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? != Ordering::Equal
    {
        return Err(GeometryError::UnsupportedIntersection);
    }

    let profile_points = match intersect_meridian_circles(
        &first.major_radius,
        &Real::zero(),
        &first.minor_radius,
        &second.major_radius,
        &axial_offset,
        &second.minor_radius,
    )? {
        MeridianCircleIntersection::Coincident => {
            return Ok(SurfaceSurfaceIntersection::Coincident);
        }
        MeridianCircleIntersection::Points(points) if points.is_empty() => {
            return Ok(SurfaceSurfaceIntersection::None);
        }
        MeridianCircleIntersection::Points(points) => points,
    };

    let frames_equal = orthonormal_frames_equal(&first.frame, &second.frame)?;
    let frames_mirrored = orthonormal_frames_mirrored(&first.frame, &second.frame)?;
    let retain_pcurves = frames_equal || frames_mirrored;
    let canonical_angle = |angle: Real| -> GeometryResult<Real> {
        Ok(
            if decided_order(compare_reals(
                &angle,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Less
            {
                angle + Real::tau()
            } else {
                angle
            },
        )
    };
    let mut curves = Vec::with_capacity(profile_points.len());
    let mut retained = Vec::with_capacity(profile_points.len());
    for (radial_distance, axial_height) in profile_points {
        let center = first.center.clone() + first.frame.z.clone() * &axial_height;
        let curve = Curve3::circle_arc(
            center.clone(),
            first.frame.x.clone(),
            first.frame.y.clone(),
            radial_distance.clone(),
            Real::zero(),
            Real::tau(),
        )?;
        if retain_pcurves {
            let first_v = canonical_angle(certified_atan2(
                axial_height,
                &radial_distance - &first.major_radius,
            )?)?;
            let second_v = canonical_angle(certified_atan2(
                (&center - &second.center).dot(&second.frame.z),
                radial_distance - &second.major_radius,
            )?)?;
            let domain = curve.domain().clone();
            retained.push(SurfaceIntersectionCurve::new(
                curve,
                SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), first_v),
                angular_iso_v_pcurve(domain, second_v, frames_mirrored),
            ));
        } else {
            curves.push(curve);
        }
    }
    if retain_pcurves {
        Ok(match retained.len() {
            1 => SurfaceSurfaceIntersection::Curve(Box::new(
                retained.pop().expect("one retained torus/torus circle"),
            )),
            _ => SurfaceSurfaceIntersection::Curves(retained),
        })
    } else {
        Ok(match curves.len() {
            1 => SurfaceSurfaceIntersection::Circle(curves.pop().expect("one torus/torus circle")),
            _ => SurfaceSurfaceIntersection::Circles(curves),
        })
    }
}

fn intersect_spheres(
    first: &SphereSurface,
    second: &SphereSurface,
) -> GeometryResult<SurfaceSurfaceIntersection> {
    match point3_equal(&first.center, &second.center, crate::STRICT_PREDICATES) {
        PredicateOutcome::Decided { value: true, .. } => {
            return if decided_order(compare_reals(
                &first.radius,
                &second.radius,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal
            {
                Ok(SurfaceSurfaceIntersection::Coincident)
            } else {
                Ok(SurfaceSurfaceIntersection::None)
            };
        }
        PredicateOutcome::Decided { value: false, .. } => {}
        PredicateOutcome::Unknown { needed, stage } => {
            return Err(GeometryError::PredicateUnresolved { needed, stage });
        }
    }
    let displacement = &second.center - &first.center;
    let distance_squared = displacement.norm_squared();
    let distance = distance_squared
        .clone()
        .sqrt()
        .map_err(GeometryError::Numeric)?;
    let radius_sum = &first.radius + &second.radius;
    let radius_difference = match decided_order(compare_reals(
        &first.radius,
        &second.radius,
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => &second.radius - &first.radius,
        Ordering::Equal | Ordering::Greater => &first.radius - &second.radius,
    };
    if decided_order(compare_reals(
        &distance,
        &radius_sum,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
        || decided_order(compare_reals(
            &distance,
            &radius_difference,
            crate::STRICT_PREDICATES,
        ))? == Ordering::Less
    {
        return Ok(SurfaceSurfaceIntersection::None);
    }

    let denominator = Real::from(2) * &distance;
    let center_distance = ((&first.radius * &first.radius - &second.radius * &second.radius
        + &distance_squared)
        / denominator)
        .map_err(GeometryError::Numeric)?;
    let inverse_distance = (Real::one() / distance).map_err(GeometryError::Numeric)?;
    let normal = displacement * inverse_distance;
    let center = first.center.clone() + normal.clone() * &center_distance;
    let circle_radius_squared = &first.radius * &first.radius - &center_distance * &center_distance;
    match decided_order(compare_reals(
        &circle_radius_squared,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => Ok(SurfaceSurfaceIntersection::None),
        Ordering::Equal => Ok(SurfaceSurfaceIntersection::Point(Box::new(center))),
        Ordering::Greater => {
            let radius = circle_radius_squared
                .sqrt()
                .map_err(GeometryError::Numeric)?;
            let first_axial = decided_order(compare_reals(
                &normal.cross(&first.frame.z).norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal;
            let second_axial = decided_order(compare_reals(
                &normal.cross(&second.frame.z).norm_squared(),
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))? == Ordering::Equal;
            if first_axial && second_axial {
                let curve = Curve3::circle_arc(
                    center.clone(),
                    first.frame.x.clone(),
                    first.frame.y.clone(),
                    radius,
                    Real::zero(),
                    Real::tau(),
                )?;
                let frames_equal = orthonormal_frames_equal(&first.frame, &second.frame)?;
                let frames_mirrored = orthonormal_frames_mirrored(&first.frame, &second.frame)?;
                if frames_equal || frames_mirrored {
                    let first_height = (&center - &first.center).dot(&first.frame.z);
                    let second_height = (&center - &second.center).dot(&second.frame.z);
                    let first_latitude = (first_height / &first.radius)
                        .map_err(GeometryError::Numeric)?
                        .asin()
                        .map_err(GeometryError::Numeric)?;
                    let second_latitude = (second_height / &second.radius)
                        .map_err(GeometryError::Numeric)?
                        .asin()
                        .map_err(GeometryError::Numeric)?;
                    let domain = curve.domain().clone();
                    let second_pcurve = if frames_equal {
                        SurfaceIntersectionPcurve::tensor_iso_v(domain.clone(), second_latitude)
                    } else {
                        SurfaceIntersectionPcurve::tensor_iso(
                            domain.clone(),
                            second_latitude,
                            TensorAxis::V,
                            -Real::one(),
                            Real::tau(),
                        )
                    };
                    return Ok(SurfaceSurfaceIntersection::Curve(Box::new(
                        SurfaceIntersectionCurve::new(
                            curve,
                            SurfaceIntersectionPcurve::tensor_iso_v(domain, first_latitude),
                            second_pcurve,
                        ),
                    )));
                }
                return Ok(SurfaceSurfaceIntersection::Circle(curve));
            }
            let (x, y) = normal
                .orthonormal_basis_checked()
                .map_err(GeometryError::Numeric)?;
            Ok(SurfaceSurfaceIntersection::Circle(Curve3::circle_arc(
                center,
                x,
                y,
                radius,
                Real::zero(),
                Real::from(2) * Real::pi(),
            )?))
        }
    }
}

enum QuadraticRoots {
    None,
    All,
    Isolated(Vec<(Real, IntersectionMultiplicity)>),
}

fn quadratic_roots(a: Real, b: Real, c: Real) -> GeometryResult<QuadraticRoots> {
    if decided_order(compare_reals(&a, &Real::zero(), crate::STRICT_PREDICATES))? == Ordering::Equal
    {
        if decided_order(compare_reals(&b, &Real::zero(), crate::STRICT_PREDICATES))?
            == Ordering::Equal
        {
            return if decided_order(compare_reals(&c, &Real::zero(), crate::STRICT_PREDICATES))?
                == Ordering::Equal
            {
                Ok(QuadraticRoots::All)
            } else {
                Ok(QuadraticRoots::None)
            };
        }
        let parameter = ((-c) / b).map_err(GeometryError::Numeric)?;
        return Ok(QuadraticRoots::Isolated(vec![(
            parameter,
            IntersectionMultiplicity::Simple,
        )]));
    }
    let discriminant = &b * &b - Real::from(4) * &a * &c;
    match decided_order(compare_reals(
        &discriminant,
        &Real::zero(),
        crate::STRICT_PREDICATES,
    ))? {
        Ordering::Less => Ok(QuadraticRoots::None),
        Ordering::Equal => {
            let parameter = ((-b) / (Real::from(2) * a)).map_err(GeometryError::Numeric)?;
            Ok(QuadraticRoots::Isolated(vec![(
                parameter,
                IntersectionMultiplicity::Tangent,
            )]))
        }
        Ordering::Greater => {
            let root = discriminant.sqrt().map_err(GeometryError::Numeric)?;
            let denominator = Real::from(2) * a;
            let first = ((-&b - &root) / &denominator).map_err(GeometryError::Numeric)?;
            let second = ((-&b + root) / denominator).map_err(GeometryError::Numeric)?;
            Ok(QuadraticRoots::Isolated(vec![
                (first, IntersectionMultiplicity::Simple),
                (second, IntersectionMultiplicity::Simple),
            ]))
        }
    }
}

fn intersect_line_cone(
    curve: &Curve3,
    start: &Point3,
    end: &Point3,
    cone: &ConeSurface,
) -> GeometryResult<CurveSurfaceIntersection> {
    let offset = start - &cone.apex;
    let direction = end - start;
    let axial_offset = cone.frame.z.dot(&offset);
    let axial_direction = cone.frame.z.dot(&direction);
    let radial_offset = &offset - &(cone.frame.z.clone() * &axial_offset);
    let radial_direction = &direction - &(cone.frame.z.clone() * &axial_direction);
    let sin = cone.semi_angle.clone().sin();
    let cos = cone.semi_angle.clone().cos();
    let sin_squared = &sin * &sin;
    let cos_squared = &cos * &cos;
    let a = &cos_squared * radial_direction.norm_squared()
        - &sin_squared * &axial_direction * &axial_direction;
    let b = Real::from(2)
        * (&cos_squared * radial_offset.dot(&radial_direction)
            - &sin_squared * &axial_offset * &axial_direction);
    let c =
        &cos_squared * radial_offset.norm_squared() - &sin_squared * &axial_offset * &axial_offset;
    match quadratic_roots(a, b, c)? {
        QuadraticRoots::None => Ok(CurveSurfaceIntersection::None),
        QuadraticRoots::Isolated(roots) => {
            let mut upper_roots = Vec::new();
            for (parameter, multiplicity) in roots {
                let axial = &axial_offset + &parameter * &axial_direction;
                if decided_order(compare_reals(
                    &axial,
                    &Real::zero(),
                    crate::STRICT_PREDICATES,
                ))? != Ordering::Less
                {
                    upper_roots.push((parameter, multiplicity));
                }
            }
            isolated_line_parameters(curve, upper_roots)
        }
        QuadraticRoots::All => {
            let axial_start = axial_offset;
            let axial_end = &axial_start + &axial_direction;
            let start_order = decided_order(compare_reals(
                &axial_start,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))?;
            let end_order = decided_order(compare_reals(
                &axial_end,
                &Real::zero(),
                crate::STRICT_PREDICATES,
            ))?;
            if start_order != Ordering::Less && end_order != Ordering::Less {
                return Ok(CurveSurfaceIntersection::Contained);
            }
            if start_order == Ordering::Less && end_order == Ordering::Less {
                return Ok(CurveSurfaceIntersection::None);
            }
            let boundary = ((-&axial_start) / &axial_direction).map_err(GeometryError::Numeric)?;
            if start_order == Ordering::Equal || end_order == Ordering::Equal {
                return isolated_line_parameters(
                    curve,
                    [(boundary, IntersectionMultiplicity::Boundary)],
                );
            }
            let domain = if start_order == Ordering::Greater {
                ParameterDomain::new(curve.domain().start().clone(), boundary)?
            } else {
                ParameterDomain::new(boundary, curve.domain().end().clone())?
            };
            Ok(CurveSurfaceIntersection::Overlap(domain.into()))
        }
    }
}

fn quadratic_line_intersection(
    curve: &Curve3,
    offset: &Vector3,
    direction: &Vector3,
    radius: &Real,
) -> GeometryResult<CurveSurfaceIntersection> {
    let a = direction.dot(direction);
    let b = Real::from(2) * offset.dot(direction);
    let c = offset.dot(offset) - radius * radius;
    match quadratic_roots(a, b, c)? {
        QuadraticRoots::None => Ok(CurveSurfaceIntersection::None),
        QuadraticRoots::All => Ok(CurveSurfaceIntersection::Contained),
        QuadraticRoots::Isolated(roots) => isolated_line_parameters(curve, roots),
    }
}

fn isolated_line_parameters(
    curve: &Curve3,
    parameters: impl IntoIterator<Item = (Real, IntersectionMultiplicity)>,
) -> GeometryResult<CurveSurfaceIntersection> {
    let mut points = Vec::new();
    for (parameter, multiplicity) in parameters {
        if curve.domain().contains(&parameter)? {
            points.push(CurveSurfacePoint {
                point: curve.evaluate_real(&parameter)?.into(),
                parameter: parameter.into(),
                multiplicity,
            });
        }
    }
    if points.is_empty() {
        Ok(CurveSurfaceIntersection::None)
    } else {
        Ok(CurveSurfaceIntersection::Points(points))
    }
}

fn validate_control_net(control_points: &[Point3], weights: &[Real]) -> GeometryResult<()> {
    if control_points.len() < 2 {
        return Err(GeometryError::TooFewControlPoints);
    }
    if control_points.len() != weights.len() {
        return Err(GeometryError::WeightCountMismatch);
    }
    Ok(())
}

fn decompose_nurbs_into_bezier_segments(
    nurbs: &NurbsCurve3,
) -> GeometryResult<Vec<(Curve3, ParameterDomain)>> {
    let mut breaks = vec![nurbs.knots[nurbs.degree].clone()];
    for knot in &nurbs.knots[(nurbs.degree + 1)..nurbs.control_points.len()] {
        if decided_order(compare_reals(
            knot,
            breaks.last().expect("start break"),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
        {
            breaks.push(knot.clone());
        }
    }
    breaks.push(nurbs.knots[nurbs.control_points.len()].clone());

    let mut controls = nurbs.homogeneous_controls().to_vec();
    let mut knots = nurbs.knots.clone();
    for knot in &breaks[1..breaks.len() - 1] {
        let mut multiplicity = knot_multiplicity(&knots, knot)?;
        while multiplicity < nurbs.degree {
            let span = find_raw_span(knot, nurbs.degree, controls.len(), &knots)?;
            (controls, knots) =
                insert_nurbs_knot_once(&controls, &knots, nurbs.degree, span, multiplicity, knot)?;
            multiplicity += 1;
        }
    }
    let mut segments = Vec::with_capacity(breaks.len() - 1);
    for index in 0..breaks.len() - 1 {
        let control_start = index * nurbs.degree;
        let control_end = control_start + nurbs.degree;
        segments.push((
            rational_bezier_from_homogeneous(controls[control_start..=control_end].to_vec(), None)?,
            ParameterDomain::new(breaks[index].clone(), breaks[index + 1].clone())?,
        ));
    }
    Ok(segments)
}

fn surface_projection_varies(
    control_points: &[Point3],
    axes: (usize, usize),
) -> GeometryResult<bool> {
    for point in &control_points[1..] {
        if decided_order(compare_reals(
            control_coordinate(point, axes.0),
            control_coordinate(&control_points[0], axes.0),
            crate::STRICT_PREDICATES,
        ))? != Ordering::Equal
            || decided_order(compare_reals(
                control_coordinate(point, axes.1),
                control_coordinate(&control_points[0], axes.1),
                crate::STRICT_PREDICATES,
            ))? != Ordering::Equal
        {
            return Ok(true);
        }
    }
    Ok(false)
}

fn control_coordinate(point: &Point3, axis: usize) -> &Real {
    match axis {
        0 => &point.x,
        1 => &point.y,
        2 => &point.z,
        _ => unreachable!("3D coordinate axis"),
    }
}

fn certified_constant_coordinates(control_points: &[Point3]) -> [Option<Real>; 3] {
    std::array::from_fn(|axis| {
        let first = control_coordinate(
            control_points
                .first()
                .expect("validated rational Bezier has control points"),
            axis,
        );
        control_points[1..]
            .iter()
            .all(|point| {
                matches!(
                    compare_reals(
                        control_coordinate(point, axis),
                        first,
                        crate::STRICT_PREDICATES,
                    ),
                    PredicateOutcome::Decided {
                        value: Ordering::Equal,
                        ..
                    }
                )
            })
            .then(|| first.clone())
    })
}

fn restore_constant_coordinates(point: &mut Point3, coordinates: &[Option<Real>; 3]) {
    for (axis, coordinate) in coordinates.iter().enumerate() {
        let Some(coordinate) = coordinate else {
            continue;
        };
        match axis {
            0 => point.x = coordinate.clone(),
            1 => point.y = coordinate.clone(),
            2 => point.z = coordinate.clone(),
            _ => unreachable!("three constant coordinate slots"),
        }
    }
}

fn points_equal(left: &Point3, right: &Point3) -> GeometryResult<bool> {
    match point3_equal(left, right, crate::STRICT_PREDICATES) {
        PredicateOutcome::Decided { value, .. } => Ok(value),
        PredicateOutcome::Unknown { needed, stage } => {
            Err(GeometryError::PredicateUnresolved { needed, stage })
        }
    }
}

fn validate_surface_control_net(
    control_points: &[Vec<Point3>],
    weights: &[Vec<Real>],
) -> GeometryResult<(usize, usize)> {
    if control_points.len() < 2 {
        return Err(GeometryError::InvalidControlNetShape);
    }
    if control_points.len() != weights.len() {
        return Err(GeometryError::SurfaceWeightShapeMismatch);
    }
    let u_count = control_points[0].len();
    if u_count < 2 || control_points.iter().any(|row| row.len() != u_count) {
        return Err(GeometryError::InvalidControlNetShape);
    }
    if weights.iter().any(|row| row.len() != u_count) {
        return Err(GeometryError::SurfaceWeightShapeMismatch);
    }
    Ok((u_count, control_points.len()))
}

fn validate_positive_surface_weights(weights: &[Vec<Real>]) -> GeometryResult<()> {
    for row in weights {
        validate_positive_weights(row)?;
    }
    Ok(())
}

fn validate_nurbs_axis(degree: usize, control_count: usize, knots: &[Real]) -> GeometryResult<()> {
    if degree == 0 || degree >= control_count {
        return Err(GeometryError::InvalidDegree);
    }
    if knots.len() != control_count + degree + 1 {
        return Err(GeometryError::InvalidKnotCount);
    }
    for adjacent in knots.windows(2) {
        if !matches!(
            decided_order(compare_reals(
                &adjacent[0],
                &adjacent[1],
                crate::STRICT_PREDICATES
            ))?,
            Ordering::Less | Ordering::Equal
        ) {
            return Err(GeometryError::InvalidKnotOrder);
        }
    }
    validate_clamped_knot_multiplicities(degree, knots)
}

fn validate_positive_weights(weights: &[Real]) -> GeometryResult<()> {
    for weight in weights {
        match compare_reals(weight, &Real::zero(), crate::STRICT_PREDICATES) {
            PredicateOutcome::Decided {
                value: Ordering::Greater,
                ..
            } => {}
            PredicateOutcome::Decided { .. } => return Err(GeometryError::InvalidWeight),
            PredicateOutcome::Unknown { needed, stage } => {
                return Err(GeometryError::PredicateUnresolved { needed, stage });
            }
        }
    }
    Ok(())
}

fn validate_clamped_knot_multiplicities(degree: usize, knots: &[Real]) -> GeometryResult<()> {
    let endpoint_count = degree + 1;
    for knot in &knots[1..endpoint_count] {
        if decided_order(compare_reals(knot, &knots[0], crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Err(GeometryError::UnclampedNurbs);
        }
    }
    let last = knots.len() - 1;
    for knot in &knots[(last + 1 - endpoint_count)..last] {
        if decided_order(compare_reals(knot, &knots[last], crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Err(GeometryError::UnclampedNurbs);
        }
    }
    // An endpoint run must stop after degree + 1 entries. Checking only the
    // interior runs misses extra knots attached to either clamped endpoint.
    if endpoint_count < knots.len() - endpoint_count {
        for (interior, endpoint) in [
            (&knots[endpoint_count], &knots[0]),
            (&knots[last - endpoint_count], &knots[last]),
        ] {
            if decided_order(compare_reals(interior, endpoint, crate::STRICT_PREDICATES))?
                == Ordering::Equal
            {
                return Err(GeometryError::InvalidKnotMultiplicity);
            }
        }
    }
    let mut run = 1_usize;
    for index in endpoint_count..(knots.len() - endpoint_count) {
        if decided_order(compare_reals(
            &knots[index],
            &knots[index - 1],
            crate::STRICT_PREDICATES,
        ))? == Ordering::Equal
        {
            run += 1;
            if run > degree {
                return Err(GeometryError::InvalidKnotMultiplicity);
            }
        } else {
            run = 1;
        }
    }
    Ok(())
}

fn decided_order(outcome: PredicateOutcome<Ordering>) -> GeometryResult<Ordering> {
    match outcome {
        PredicateOutcome::Decided { value, .. } => Ok(value),
        PredicateOutcome::Unknown { needed, stage } => {
            Err(GeometryError::PredicateUnresolved { needed, stage })
        }
    }
}

pub(crate) fn certified_atan2(y: Real, x: Real) -> GeometryResult<Real> {
    let y_order = decided_order(compare_reals(&y, &Real::zero(), crate::STRICT_PREDICATES))?;
    let x_order = decided_order(compare_reals(&x, &Real::zero(), crate::STRICT_PREDICATES))?;
    match (y_order, x_order) {
        (Ordering::Equal, Ordering::Equal | Ordering::Greater) => Ok(Real::zero()),
        (Ordering::Equal, Ordering::Less) => Ok(Real::pi()),
        (Ordering::Greater, Ordering::Equal) => {
            (Real::pi() / Real::from(2)).map_err(GeometryError::Numeric)
        }
        (Ordering::Less, Ordering::Equal) => {
            (-Real::pi() / Real::from(2)).map_err(GeometryError::Numeric)
        }
        (_, Ordering::Greater) => (y / x)
            .map_err(GeometryError::Numeric)?
            .atan()
            .map_err(GeometryError::Numeric),
        (Ordering::Greater, Ordering::Less) => Ok((y / x)
            .map_err(GeometryError::Numeric)?
            .atan()
            .map_err(GeometryError::Numeric)?
            + Real::pi()),
        (Ordering::Less, Ordering::Less) => Ok((y / x)
            .map_err(GeometryError::Numeric)?
            .atan()
            .map_err(GeometryError::Numeric)?
            - Real::pi()),
    }
}

fn validate_arc_axes(x: &Vector3, y: &Vector3) -> GeometryResult<()> {
    let one = Real::one();
    let zero = Real::zero();
    for (actual, expected) in [
        (x.norm_squared(), &one),
        (y.norm_squared(), &one),
        (x.dot(y), &zero),
    ] {
        if decided_order(compare_reals(&actual, expected, crate::STRICT_PREDICATES))?
            != Ordering::Equal
        {
            return Err(GeometryError::InvalidSurfaceFrame);
        }
    }
    Ok(())
}

fn validate_arc_domain(start: Real, end: Real) -> GeometryResult<ParameterDomain> {
    let domain = ParameterDomain::new(start, end)?;
    let sweep = domain.end() - domain.start();
    if decided_order(compare_reals(
        &sweep,
        &(Real::from(2) * Real::pi()),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
    {
        Err(GeometryError::InvalidArcSweep)
    } else {
        Ok(domain)
    }
}

fn ellipse_arc_angle(arc: &EllipseArc3, domain: &ParameterDomain, parameter: &Real) -> Real {
    let delta = parameter - domain.start();
    if arc.direction > 0 {
        &arc.angle_at_start + delta
    } else {
        &arc.angle_at_start - delta
    }
}

fn evaluate_ellipse_arc(arc: &EllipseArc3, domain: &ParameterDomain, parameter: &Real) -> Point3 {
    let angle = ellipse_arc_angle(arc, domain, parameter);
    let sin = angle.clone().sin();
    let cos = angle.cos();
    arc.center.clone()
        + arc.x.clone() * (&arc.x_radius * cos)
        + arc.y.clone() * (&arc.y_radius * sin)
}

fn evaluate_ellipse_arc_derivative(
    arc: &EllipseArc3,
    domain: &ParameterDomain,
    parameter: &Real,
    order: usize,
) -> Vector3 {
    let angle = ellipse_arc_angle(arc, domain, parameter);
    let sin = angle.clone().sin();
    let cos = angle.cos();
    let (cos_derivative, sin_derivative) = match order % 4 {
        0 => (cos, sin),
        1 => (-sin, cos),
        2 => (-cos, -sin),
        3 => (sin, -cos),
        _ => unreachable!("modulo four"),
    };
    let derivative = arc.x.clone() * (&arc.x_radius * cos_derivative)
        + arc.y.clone() * (&arc.y_radius * sin_derivative);
    if arc.direction > 0 || order.is_multiple_of(2) {
        derivative
    } else {
        -derivative
    }
}

fn reversed_ellipse_arc(arc: &EllipseArc3, domain: &ParameterDomain) -> EllipseArc3 {
    EllipseArc3 {
        angle_at_start: ellipse_arc_angle(arc, domain, domain.end()),
        direction: -arc.direction,
        ..arc.clone()
    }
}

fn split_ellipse_arc(
    arc: &EllipseArc3,
    domain: &ParameterDomain,
    parameter: &Real,
    kind: Curve3Kind,
) -> GeometryResult<(Curve3, Curve3)> {
    let right_angle = ellipse_arc_angle(arc, domain, parameter);
    let left_geometry = arc.clone();
    let right_geometry = EllipseArc3 {
        angle_at_start: right_angle,
        ..arc.clone()
    };
    let left_domain = ParameterDomain::new(domain.start().clone(), parameter.clone())?;
    let right_domain = ParameterDomain::new(parameter.clone(), domain.end().clone())?;
    let wrap = |geometry| match kind {
        Curve3Kind::CircleArc => CurveGeometry3::CircleArc(geometry),
        Curve3Kind::EllipseArc => CurveGeometry3::EllipseArc(geometry),
        Curve3Kind::Line
        | Curve3Kind::RationalBezier
        | Curve3Kind::Nurbs
        | Curve3Kind::PlanarImage => {
            unreachable!("ellipse split kind")
        }
    };
    Ok((
        Curve3::from_parts(wrap(left_geometry), left_domain),
        Curve3::from_parts(wrap(right_geometry), right_domain),
    ))
}

fn ellipse_arc_conservative_bounds(arc: &EllipseArc3) -> GeometryResult<Aabb> {
    let radius = if decided_order(compare_reals(
        &arc.x_radius,
        &arc.y_radius,
        crate::STRICT_PREDICATES,
    ))? == Ordering::Greater
    {
        &arc.x_radius
    } else {
        &arc.y_radius
    };
    Ok(Aabb::new(
        Point3::new(
            &arc.center.x - radius,
            &arc.center.y - radius,
            &arc.center.z - radius,
        ),
        Point3::new(
            &arc.center.x + radius,
            &arc.center.y + radius,
            &arc.center.z + radius,
        ),
    ))
}

fn centered_cube_bounds(center: &Point3, radius: &Real) -> Aabb {
    Aabb::new(
        Point3::new(&center.x - radius, &center.y - radius, &center.z - radius),
        Point3::new(&center.x + radius, &center.y + radius, &center.z + radius),
    )
}

fn revolution_bounds(surface: &RevolutionSurface) -> GeometryResult<Aabb> {
    let bounds = surface.profile.bounds()?;
    let xs = [&bounds.mins.x, &bounds.maxs.x];
    let ys = [&bounds.mins.y, &bounds.maxs.y];
    let zs = [&bounds.mins.z, &bounds.maxs.z];
    let first_offset = Vector3::from_xyz(
        xs[0] - &surface.axis_origin.x,
        ys[0] - &surface.axis_origin.y,
        zs[0] - &surface.axis_origin.z,
    );
    let first_axial = surface.axis.dot(&first_offset);
    let first_radial = first_offset - surface.axis.clone() * first_axial.clone();
    let mut axial_min = first_axial.clone();
    let mut axial_max = first_axial;
    let mut radius_squared = first_radial.norm_squared();
    for x in xs {
        for y in ys {
            for z in zs {
                let offset = Vector3::from_xyz(
                    x - &surface.axis_origin.x,
                    y - &surface.axis_origin.y,
                    z - &surface.axis_origin.z,
                );
                let axial = surface.axis.dot(&offset);
                update_bound_min(&mut axial_min, &axial)?;
                update_bound_max(&mut axial_max, &axial)?;
                let radial = offset - surface.axis.clone() * axial;
                update_bound_max(&mut radius_squared, &radial.norm_squared())?;
            }
        }
    }
    let radius = radius_squared.sqrt().map_err(GeometryError::Numeric)?;
    let coordinate_bounds =
        |origin: &Real, axis_component: &Real| -> GeometryResult<(Real, Real)> {
            let first_axial = axis_component * &axial_min;
            let second_axial = axis_component * &axial_max;
            let (axial_low, axial_high) = if decided_order(compare_reals(
                &first_axial,
                &second_axial,
                crate::STRICT_PREDICATES,
            ))? == Ordering::Greater
            {
                (second_axial, first_axial)
            } else {
                (first_axial, second_axial)
            };
            let radial_factor = (Real::one() - axis_component * axis_component)
                .sqrt()
                .map_err(GeometryError::Numeric)?;
            let radial_extent = &radius * radial_factor;
            Ok((
                origin + axial_low - &radial_extent,
                origin + axial_high + radial_extent,
            ))
        };
    let (min_x, max_x) = coordinate_bounds(&surface.axis_origin.x, &surface.axis.0[0])?;
    let (min_y, max_y) = coordinate_bounds(&surface.axis_origin.y, &surface.axis.0[1])?;
    let (min_z, max_z) = coordinate_bounds(&surface.axis_origin.z, &surface.axis.0[2])?;
    Ok(Aabb::new(
        Point3::new(min_x, min_y, min_z),
        Point3::new(max_x, max_y, max_z),
    ))
}

fn rotate_point_about_axis(
    point: &Point3,
    axis_origin: &Point3,
    axis: &Vector3,
    angle: &Real,
) -> Point3 {
    let relative = point - axis_origin;
    axis_origin.clone() + rotate_vector_about_axis(&relative, axis, angle)
}

fn rotate_vector_about_axis(vector: &Vector3, axis: &Vector3, angle: &Real) -> Vector3 {
    let axial = axis.clone() * axis.dot(vector);
    let radial = vector - &axial;
    let sin = angle.clone().sin();
    let cos = angle.clone().cos();
    axial + radial.clone() * cos + axis.cross(&radial) * sin
}

fn exact_surface_control_bounds(control_points: &[Vec<Point3>]) -> GeometryResult<Aabb> {
    let points = control_points
        .iter()
        .flat_map(|row| row.iter())
        .cloned()
        .collect::<Vec<_>>();
    exact_point_bounds(&points)
}

fn exact_point_bounds(points: &[Point3]) -> GeometryResult<Aabb> {
    let first = &points[0];
    let mut mins = first.clone();
    let mut maxs = first.clone();
    for point in &points[1..] {
        update_bound_min(&mut mins.x, &point.x)?;
        update_bound_min(&mut mins.y, &point.y)?;
        update_bound_min(&mut mins.z, &point.z)?;
        update_bound_max(&mut maxs.x, &point.x)?;
        update_bound_max(&mut maxs.y, &point.y)?;
        update_bound_max(&mut maxs.z, &point.z)?;
    }
    Ok(Aabb::new(mins, maxs))
}

fn update_bound_min(current: &mut Real, candidate: &Real) -> GeometryResult<()> {
    if decided_order(compare_reals(candidate, current, crate::STRICT_PREDICATES))? == Ordering::Less
    {
        *current = candidate.clone();
    }
    Ok(())
}

fn update_bound_max(current: &mut Real, candidate: &Real) -> GeometryResult<()> {
    if decided_order(compare_reals(candidate, current, crate::STRICT_PREDICATES))?
        == Ordering::Greater
    {
        *current = candidate.clone();
    }
    Ok(())
}

fn weighted_controls(points: &[Point3], weights: &[Real]) -> Vec<HomogeneousPoint3> {
    points
        .iter()
        .zip(weights)
        .map(|(point, weight)| HomogeneousPoint3::from_affine(point, weight))
        .collect()
}

fn evaluate_tensor_bezier(
    controls: &[Vec<HomogeneousPoint3>],
    parameter: &Point2,
) -> GeometryResult<Point3> {
    let u_values = controls
        .iter()
        .map(|row| {
            evaluate_homogeneous_bezier_value(row, &parameter.x)
                .ok_or(GeometryError::InvalidControlNetShape)
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    evaluate_homogeneous_bezier_value(&u_values, &parameter.y)
        .ok_or(GeometryError::InvalidControlNetShape)?
        .project()
}

fn evaluate_tensor_bezier_partials(
    controls: &[Vec<HomogeneousPoint3>],
    parameter: &Point2,
) -> GeometryResult<SurfacePartials> {
    let u_values = controls
        .iter()
        .map(|row| {
            evaluate_homogeneous_bezier_value(row, &parameter.x)
                .ok_or(GeometryError::InvalidControlNetShape)
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    let u_derivatives = controls
        .iter()
        .map(|row| {
            evaluate_homogeneous_bezier_derivative_value(row, &parameter.x)
                .ok_or(GeometryError::InvalidControlNetShape)
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    let value = evaluate_homogeneous_bezier_value(&u_values, &parameter.y)
        .ok_or(GeometryError::InvalidControlNetShape)?;
    let u_derivative = evaluate_homogeneous_bezier_value(&u_derivatives, &parameter.y)
        .ok_or(GeometryError::InvalidControlNetShape)?;
    let v_derivative = evaluate_homogeneous_bezier_derivative_value(&u_values, &parameter.y)
        .ok_or(GeometryError::InvalidControlNetShape)?;
    Ok(SurfacePartials {
        u: project_homogeneous_derivative(&value, &u_derivative)?,
        v: project_homogeneous_derivative(&value, &v_derivative)?,
    })
}

fn evaluate_tensor_nurbs(
    surface: &NurbsSurface,
    domain: &SurfaceDomain,
    parameter: &Point2,
) -> GeometryResult<Point3> {
    let (value, _, _) = evaluate_tensor_nurbs_homogeneous(surface, domain, parameter)?;
    value.project()
}

fn evaluate_tensor_nurbs_partials(
    surface: &NurbsSurface,
    domain: &SurfaceDomain,
    parameter: &Point2,
) -> GeometryResult<SurfacePartials> {
    let (value, u_derivative, v_derivative) =
        evaluate_tensor_nurbs_homogeneous(surface, domain, parameter)?;
    Ok(SurfacePartials {
        u: project_homogeneous_derivative(&value, &u_derivative)?,
        v: project_homogeneous_derivative(&value, &v_derivative)?,
    })
}

fn evaluate_tensor_nurbs_homogeneous(
    surface: &NurbsSurface,
    domain: &SurfaceDomain,
    parameter: &Point2,
) -> GeometryResult<(HomogeneousPoint3, HomogeneousPoint3, HomogeneousPoint3)> {
    let SurfaceParameterDomain::Closed(u_domain) = &domain.u else {
        return Err(GeometryError::InvalidParameterDomain);
    };
    let SurfaceParameterDomain::Closed(v_domain) = &domain.v else {
        return Err(GeometryError::InvalidParameterDomain);
    };
    let controls = surface.homogeneous_controls();
    let u_count = controls[0].len();
    let v_count = controls.len();
    let u_span = find_span(
        &parameter.x,
        u_domain,
        surface.u_degree,
        u_count,
        &surface.u_knots,
    )?;
    let v_span = find_span(
        &parameter.y,
        v_domain,
        surface.v_degree,
        v_count,
        &surface.v_knots,
    )?;
    let u_jets = controls
        .iter()
        .map(|row| {
            evaluate_homogeneous_de_boor_jet(
                row,
                &surface.u_knots,
                surface.u_degree,
                u_span,
                &parameter.x,
            )
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    let u_values = u_jets
        .iter()
        .map(|(value, _)| value.clone())
        .collect::<Vec<_>>();
    let u_derivatives = u_jets
        .into_iter()
        .map(|(_, derivative)| derivative)
        .collect::<Vec<_>>();
    let (value, v_derivative) = evaluate_homogeneous_de_boor_jet(
        &u_values,
        &surface.v_knots,
        surface.v_degree,
        v_span,
        &parameter.y,
    )?;
    let (u_derivative, _) = evaluate_homogeneous_de_boor_jet(
        &u_derivatives,
        &surface.v_knots,
        surface.v_degree,
        v_span,
        &parameter.y,
    )?;
    Ok((value, u_derivative, v_derivative))
}

fn evaluate_homogeneous_bezier(
    controls: &[HomogeneousPoint3],
    parameter: &Real,
) -> GeometryResult<Point3> {
    evaluate_homogeneous_bezier_value(controls, parameter)
        .ok_or(GeometryError::TooFewControlPoints)?
        .project()
}

fn evaluate_homogeneous_bezier_value(
    controls: &[HomogeneousPoint3],
    parameter: &Real,
) -> Option<HomogeneousPoint3> {
    let mut level = controls.to_vec();
    while level.len() > 1 {
        level = level
            .windows(2)
            .map(|pair| pair[0].lerp(&pair[1], parameter))
            .collect();
    }
    level.pop()
}

fn evaluate_homogeneous_bezier_derivative_value(
    controls: &[HomogeneousPoint3],
    parameter: &Real,
) -> Option<HomogeneousPoint3> {
    if controls.len() < 2 {
        return None;
    }
    let degree = Real::from((controls.len() - 1) as u64);
    let derivative_controls = controls
        .windows(2)
        .map(|pair| HomogeneousPoint3 {
            x: (&pair[1].x - &pair[0].x) * &degree,
            y: (&pair[1].y - &pair[0].y) * &degree,
            z: (&pair[1].z - &pair[0].z) * &degree,
            w: (&pair[1].w - &pair[0].w) * &degree,
        })
        .collect::<Vec<_>>();
    evaluate_homogeneous_bezier_value(&derivative_controls, parameter)
}

fn evaluate_rational_bezier_derivative(
    curve: &RationalBezier3,
    parameter: &Real,
    order: usize,
) -> GeometryResult<Vector3> {
    let mut jets = derivative_jet_buffer(order)?;
    let mut derivative_controls = curve.homogeneous_controls().to_vec();
    let degree = derivative_controls.len() - 1;
    jets.push(
        evaluate_homogeneous_bezier_value(&derivative_controls, parameter)
            .ok_or(GeometryError::TooFewControlPoints)?,
    );
    for derivative_order in 1..=order {
        if derivative_order > degree {
            jets.push(homogeneous_zero());
            continue;
        }
        let factor = Real::from((degree - derivative_order + 1) as u64);
        derivative_controls = derivative_controls
            .windows(2)
            .map(|pair| homogeneous_difference_scaled(&pair[1], &pair[0], &factor))
            .collect();
        jets.push(
            evaluate_homogeneous_bezier_value(&derivative_controls, parameter)
                .ok_or(GeometryError::TooFewControlPoints)?,
        );
    }
    project_homogeneous_derivative_order(&jets, order)
}

fn find_span(
    parameter: &Real,
    domain: &ParameterDomain,
    degree: usize,
    control_count: usize,
    knots: &[Real],
) -> GeometryResult<usize> {
    if decided_order(compare_reals(
        parameter,
        domain.end(),
        crate::STRICT_PREDICATES,
    ))? == Ordering::Equal
    {
        return Ok(control_count - 1);
    }
    for span in degree..control_count {
        let after_start = decided_order(compare_reals(
            &knots[span],
            parameter,
            crate::STRICT_PREDICATES,
        ))?;
        let before_end = decided_order(compare_reals(
            parameter,
            &knots[span + 1],
            crate::STRICT_PREDICATES,
        ))?;
        if matches!(after_start, Ordering::Less | Ordering::Equal) && before_end == Ordering::Less {
            return Ok(span);
        }
    }
    Err(GeometryError::InvalidParameterDomain)
}

fn evaluate_homogeneous_de_boor(
    controls: &[HomogeneousPoint3],
    knots: &[Real],
    degree: usize,
    span: usize,
    parameter: &Real,
) -> GeometryResult<Point3> {
    evaluate_homogeneous_de_boor_jet(controls, knots, degree, span, parameter)?
        .0
        .project()
}

fn evaluate_homogeneous_de_boor_derivative(
    controls: &[HomogeneousPoint3],
    knots: &[Real],
    degree: usize,
    span: usize,
    parameter: &Real,
    order: usize,
) -> GeometryResult<Vector3> {
    let jets = evaluate_homogeneous_de_boor_jets(controls, knots, degree, span, parameter, order)?;
    project_homogeneous_derivative_order(&jets, order)
}

fn evaluate_homogeneous_de_boor_jet(
    controls: &[HomogeneousPoint3],
    knots: &[Real],
    degree: usize,
    span: usize,
    parameter: &Real,
) -> GeometryResult<(HomogeneousPoint3, HomogeneousPoint3)> {
    let jets = evaluate_homogeneous_de_boor_jets(controls, knots, degree, span, parameter, 1)?;
    Ok((jets[0].clone(), jets[1].clone()))
}

fn evaluate_homogeneous_de_boor_jets(
    controls: &[HomogeneousPoint3],
    knots: &[Real],
    degree: usize,
    span: usize,
    parameter: &Real,
    order: usize,
) -> GeometryResult<Vec<HomogeneousPoint3>> {
    let zero = homogeneous_zero();
    let mut level = controls[(span - degree)..=span]
        .iter()
        .cloned()
        .map(|value| {
            let mut jets = derivative_jet_buffer(order)?;
            jets.push(value);
            jets.extend(std::iter::repeat_n(zero.clone(), order));
            Ok(jets)
        })
        .collect::<GeometryResult<Vec<_>>>()?;
    for stage in 1..=degree {
        for local in (stage..=degree).rev() {
            let knot_index = span - degree + local;
            let denominator = &knots[knot_index + degree - stage + 1] - &knots[knot_index];
            let alpha = ((parameter - &knots[knot_index]) / &denominator)
                .map_err(GeometryError::Numeric)?;
            let alpha_derivative = (Real::one() / &denominator).map_err(GeometryError::Numeric)?;
            let left = &level[local - 1];
            let right = &level[local];
            let mut jets = derivative_jet_buffer(order)?;
            jets.push(left[0].lerp(&right[0], &alpha));
            for derivative_order in 1..=order {
                let base = left[derivative_order].lerp(&right[derivative_order], &alpha);
                let factor = Real::from(derivative_order as u64) * &alpha_derivative;
                jets.push(homogeneous_add(
                    &base,
                    &homogeneous_difference_scaled(
                        &right[derivative_order - 1],
                        &left[derivative_order - 1],
                        &factor,
                    ),
                ));
            }
            level[local] = jets;
        }
    }
    Ok(level.pop().expect("a degree-d span has d+1 jet buffers"))
}

/// Reserves one complete derivative buffer before evaluating its entries.
/// Address-space overflow and allocator refusal are distinct typed failures.
/// This does not bound scalar allocations or total work across all buffers.
fn derivative_jet_buffer<T>(order: usize) -> GeometryResult<Vec<T>> {
    let count = order
        .checked_add(1)
        .ok_or(GeometryError::Numeric(hyperreal::Problem::OutOfRange))?;
    std::alloc::Layout::array::<T>(count)
        .map_err(|_| GeometryError::Numeric(hyperreal::Problem::OutOfRange))?;
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| GeometryError::Numeric(hyperreal::Problem::Exhausted))?;
    Ok(values)
}

fn homogeneous_zero() -> HomogeneousPoint3 {
    HomogeneousPoint3 {
        x: Real::zero(),
        y: Real::zero(),
        z: Real::zero(),
        w: Real::zero(),
    }
}

fn homogeneous_difference_scaled(
    left: &HomogeneousPoint3,
    right: &HomogeneousPoint3,
    factor: &Real,
) -> HomogeneousPoint3 {
    HomogeneousPoint3 {
        x: (&left.x - &right.x) * factor,
        y: (&left.y - &right.y) * factor,
        z: (&left.z - &right.z) * factor,
        w: (&left.w - &right.w) * factor,
    }
}

fn homogeneous_add(left: &HomogeneousPoint3, right: &HomogeneousPoint3) -> HomogeneousPoint3 {
    HomogeneousPoint3 {
        x: &left.x + &right.x,
        y: &left.y + &right.y,
        z: &left.z + &right.z,
        w: &left.w + &right.w,
    }
}

fn project_homogeneous_derivative_order(
    jets: &[HomogeneousPoint3],
    order: usize,
) -> GeometryResult<Vector3> {
    let mut derivatives = derivative_jet_buffer(order)?;
    derivatives.push(divide_vector_by_real(
        Vector3::from_xyz(jets[0].x.clone(), jets[0].y.clone(), jets[0].z.clone()),
        &jets[0].w,
    )?);
    for derivative_order in 1..=order {
        let mut numerator = Vector3::from_xyz(
            jets[derivative_order].x.clone(),
            jets[derivative_order].y.clone(),
            jets[derivative_order].z.clone(),
        );
        for weight_order in 1..=derivative_order {
            let coefficient =
                binomial_real(derivative_order, weight_order)? * &jets[weight_order].w;
            numerator =
                numerator - derivatives[derivative_order - weight_order].clone() * coefficient;
        }
        derivatives.push(divide_vector_by_real(numerator, &jets[0].w)?);
    }
    Ok(derivatives.pop().expect("positive derivative order"))
}

fn divide_vector_by_real(vector: Vector3, denominator: &Real) -> GeometryResult<Vector3> {
    Ok(Vector3::from_xyz(
        (vector.0[0].clone() / denominator).map_err(GeometryError::Numeric)?,
        (vector.0[1].clone() / denominator).map_err(GeometryError::Numeric)?,
        (vector.0[2].clone() / denominator).map_err(GeometryError::Numeric)?,
    ))
}

fn normalized_greville_coordinates(
    count: usize,
    degree: usize,
    knots: &[Real],
    domain_start: &Real,
    domain_span: &Real,
) -> GeometryResult<Vec<Real>> {
    let degree_scalar = Real::from(u128::try_from(degree).expect("usize is representable as u128"));
    (0..count)
        .map(|index| {
            let sum = knots[index + 1..=index + degree]
                .iter()
                .fold(Real::zero(), |sum, knot| sum + knot);
            let greville = (sum / &degree_scalar).map_err(GeometryError::Numeric)?;
            ((greville - domain_start) / domain_span).map_err(GeometryError::Numeric)
        })
        .collect()
}

fn binomial_real(n: usize, k: usize) -> GeometryResult<Real> {
    let k = k.min(n - k);
    let mut result = Real::one();
    for index in 1..=k {
        result = (result * Real::from((n + 1 - index) as u64) / Real::from(index as u64))
            .map_err(GeometryError::Numeric)?;
    }
    Ok(result)
}

fn project_homogeneous_derivative(
    value: &HomogeneousPoint3,
    derivative: &HomogeneousPoint3,
) -> GeometryResult<Vector3> {
    let denominator = &value.w * &value.w;
    Ok(Vector3::from_xyz(
        ((&derivative.x * &value.w - &value.x * &derivative.w) / &denominator)
            .map_err(GeometryError::Numeric)?,
        ((&derivative.y * &value.w - &value.y * &derivative.w) / &denominator)
            .map_err(GeometryError::Numeric)?,
        ((&derivative.z * &value.w - &value.z * &derivative.w) / denominator)
            .map_err(GeometryError::Numeric)?,
    ))
}

fn require_interior_parameter(domain: &ParameterDomain, parameter: &Real) -> GeometryResult<()> {
    let after_start = decided_order(compare_reals(
        parameter,
        domain.start(),
        crate::STRICT_PREDICATES,
    ))?;
    let before_end = decided_order(compare_reals(
        parameter,
        domain.end(),
        crate::STRICT_PREDICATES,
    ))?;
    if after_start == Ordering::Greater && before_end == Ordering::Less {
        Ok(())
    } else {
        Err(GeometryError::SplitAtBoundary)
    }
}

fn split_homogeneous_bezier(
    controls: &[HomogeneousPoint3],
    parameter: &Real,
) -> (Vec<HomogeneousPoint3>, Vec<HomogeneousPoint3>) {
    let mut level = controls.to_vec();
    let mut left = Vec::with_capacity(controls.len());
    let mut right = Vec::with_capacity(controls.len());
    left.push(level[0].clone());
    right.push(level[level.len() - 1].clone());
    while level.len() > 1 {
        level = level
            .windows(2)
            .map(|pair| pair[0].lerp(&pair[1], parameter))
            .collect();
        left.push(level[0].clone());
        right.push(level[level.len() - 1].clone());
    }
    right.reverse();
    (left, right)
}

fn rational_bezier_from_homogeneous(
    controls: Vec<HomogeneousPoint3>,
    constant_coordinates: Option<&[Option<Real>; 3]>,
) -> GeometryResult<Curve3> {
    let mut points = Vec::with_capacity(controls.len());
    let mut weights = Vec::with_capacity(controls.len());
    for control in controls {
        let mut point = control.project()?;
        if let Some(constant_coordinates) = constant_coordinates {
            restore_constant_coordinates(&mut point, constant_coordinates);
        }
        points.push(point);
        weights.push(control.w);
    }
    Curve3::rational_bezier(points, weights)
}

fn split_rational_bezier_surface_u(
    surface: &RationalBezierSurface,
    parameter: &Real,
) -> GeometryResult<(Surface, Surface)> {
    let mut left = Vec::with_capacity(surface.control_points.len());
    let mut right = Vec::with_capacity(surface.control_points.len());
    for row in surface.homogeneous_controls() {
        let (left_row, right_row) = split_homogeneous_bezier(row, parameter);
        left.push(left_row);
        right.push(right_row);
    }
    Ok((
        rational_bezier_surface_from_homogeneous(left)?,
        rational_bezier_surface_from_homogeneous(right)?,
    ))
}

fn split_rational_bezier_surface_v(
    surface: &RationalBezierSurface,
    parameter: &Real,
) -> GeometryResult<(Surface, Surface)> {
    let transposed = transpose_homogeneous_grid(surface.homogeneous_controls());
    let mut left = Vec::with_capacity(transposed.len());
    let mut right = Vec::with_capacity(transposed.len());
    for column in &transposed {
        let (left_column, right_column) = split_homogeneous_bezier(column, parameter);
        left.push(left_column);
        right.push(right_column);
    }
    Ok((
        rational_bezier_surface_from_homogeneous(transpose_homogeneous_grid(&left))?,
        rational_bezier_surface_from_homogeneous(transpose_homogeneous_grid(&right))?,
    ))
}

fn rational_bezier_surface_from_homogeneous(
    controls: Vec<Vec<HomogeneousPoint3>>,
) -> GeometryResult<Surface> {
    let (points, weights) = project_homogeneous_grid(controls)?;
    Surface::rational_bezier(points, weights)
}

fn split_nurbs_surface_u(
    surface: &NurbsSurface,
    parameter: &Real,
) -> GeometryResult<(Surface, Surface)> {
    let mut left = Vec::with_capacity(surface.control_points.len());
    let mut right = Vec::with_capacity(surface.control_points.len());
    let mut left_knots = None;
    let mut right_knots = None;
    for row in surface.homogeneous_controls() {
        let (left_row, row_left_knots, right_row, row_right_knots) = split_nurbs_homogeneous(
            surface.u_degree,
            row.clone(),
            surface.u_knots.clone(),
            parameter,
        )?;
        left.push(left_row);
        right.push(right_row);
        left_knots.get_or_insert(row_left_knots);
        right_knots.get_or_insert(row_right_knots);
    }
    Ok((
        nurbs_surface_from_homogeneous(
            surface.u_degree,
            surface.v_degree,
            left,
            left_knots.expect("nonempty control net"),
            surface.v_knots.clone(),
        )?,
        nurbs_surface_from_homogeneous(
            surface.u_degree,
            surface.v_degree,
            right,
            right_knots.expect("nonempty control net"),
            surface.v_knots.clone(),
        )?,
    ))
}

fn split_nurbs_surface_v(
    surface: &NurbsSurface,
    parameter: &Real,
) -> GeometryResult<(Surface, Surface)> {
    let transposed = transpose_homogeneous_grid(surface.homogeneous_controls());
    let mut left = Vec::with_capacity(transposed.len());
    let mut right = Vec::with_capacity(transposed.len());
    let mut left_knots = None;
    let mut right_knots = None;
    for column in transposed {
        let (left_column, column_left_knots, right_column, column_right_knots) =
            split_nurbs_homogeneous(surface.v_degree, column, surface.v_knots.clone(), parameter)?;
        left.push(left_column);
        right.push(right_column);
        left_knots.get_or_insert(column_left_knots);
        right_knots.get_or_insert(column_right_knots);
    }
    Ok((
        nurbs_surface_from_homogeneous(
            surface.u_degree,
            surface.v_degree,
            transpose_homogeneous_grid(&left),
            surface.u_knots.clone(),
            left_knots.expect("nonempty control net"),
        )?,
        nurbs_surface_from_homogeneous(
            surface.u_degree,
            surface.v_degree,
            transpose_homogeneous_grid(&right),
            surface.u_knots.clone(),
            right_knots.expect("nonempty control net"),
        )?,
    ))
}

fn nurbs_surface_from_homogeneous(
    u_degree: usize,
    v_degree: usize,
    controls: Vec<Vec<HomogeneousPoint3>>,
    u_knots: Vec<Real>,
    v_knots: Vec<Real>,
) -> GeometryResult<Surface> {
    let (points, weights) = project_homogeneous_grid(controls)?;
    Surface::nurbs(u_degree, v_degree, points, weights, u_knots, v_knots)
}

fn project_homogeneous_grid(
    controls: Vec<Vec<HomogeneousPoint3>>,
) -> GeometryResult<AffineControlGrid> {
    let mut points = Vec::with_capacity(controls.len());
    let mut weights = Vec::with_capacity(controls.len());
    for row in controls {
        let mut point_row = Vec::with_capacity(row.len());
        let mut weight_row = Vec::with_capacity(row.len());
        for control in row {
            point_row.push(control.project()?);
            weight_row.push(control.w);
        }
        points.push(point_row);
        weights.push(weight_row);
    }
    Ok((points, weights))
}

fn transpose_homogeneous_grid(controls: &[Vec<HomogeneousPoint3>]) -> Vec<Vec<HomogeneousPoint3>> {
    (0..controls[0].len())
        .map(|u| controls.iter().map(|row| row[u].clone()).collect())
        .collect()
}

fn split_nurbs_curve(curve: &NurbsCurve3, parameter: &Real) -> GeometryResult<(Curve3, Curve3)> {
    let (left_controls, left_knots, right_controls, right_knots) = split_nurbs_homogeneous(
        curve.degree,
        curve.homogeneous_controls().to_vec(),
        curve.knots.clone(),
        parameter,
    )?;
    Ok((
        nurbs_from_homogeneous(curve.degree, left_controls, left_knots)?,
        nurbs_from_homogeneous(curve.degree, right_controls, right_knots)?,
    ))
}

fn split_nurbs_homogeneous(
    degree: usize,
    mut controls: Vec<HomogeneousPoint3>,
    mut knots: Vec<Real>,
    parameter: &Real,
) -> GeometryResult<HomogeneousNurbsSplit> {
    let mut multiplicity = knot_multiplicity(&knots, parameter)?;
    if multiplicity > degree {
        return Err(GeometryError::InvalidKnotMultiplicity);
    }
    while multiplicity < degree {
        let span = find_raw_span(parameter, degree, controls.len(), &knots)?;
        let (next_controls, next_knots) =
            insert_nurbs_knot_once(&controls, &knots, degree, span, multiplicity, parameter)?;
        controls = next_controls;
        knots = next_knots;
        multiplicity += 1;
    }
    let span = find_raw_span(parameter, degree, controls.len(), &knots)?;
    let shared = span - degree;
    let left_controls = controls[..=shared].to_vec();
    let right_controls = controls[shared..].to_vec();
    let mut left_knots = knots[..=span].to_vec();
    left_knots.push(parameter.clone());
    let mut right_knots = Vec::with_capacity(knots.len() - (span - degree));
    right_knots.push(parameter.clone());
    right_knots.extend_from_slice(&knots[(span - degree + 1)..]);
    Ok((left_controls, left_knots, right_controls, right_knots))
}

fn knot_multiplicity(knots: &[Real], parameter: &Real) -> GeometryResult<usize> {
    let mut count = 0;
    for knot in knots {
        if decided_order(compare_reals(knot, parameter, crate::STRICT_PREDICATES))?
            == Ordering::Equal
        {
            count += 1;
        }
    }
    Ok(count)
}

fn find_raw_span(
    parameter: &Real,
    degree: usize,
    control_count: usize,
    knots: &[Real],
) -> GeometryResult<usize> {
    for span in degree..control_count {
        let after_start = decided_order(compare_reals(
            &knots[span],
            parameter,
            crate::STRICT_PREDICATES,
        ))?;
        let before_end = decided_order(compare_reals(
            parameter,
            &knots[span + 1],
            crate::STRICT_PREDICATES,
        ))?;
        if matches!(after_start, Ordering::Less | Ordering::Equal) && before_end == Ordering::Less {
            return Ok(span);
        }
    }
    Err(GeometryError::InvalidParameterDomain)
}

fn insert_nurbs_knot_once(
    controls: &[HomogeneousPoint3],
    knots: &[Real],
    degree: usize,
    span: usize,
    multiplicity: usize,
    parameter: &Real,
) -> GeometryResult<(Vec<HomogeneousPoint3>, Vec<Real>)> {
    let old_last = controls.len() - 1;
    let mut next = Vec::with_capacity(controls.len() + 1);
    for index in 0..=old_last + 1 {
        let value = if index <= span - degree {
            controls[index].clone()
        } else if index > span - multiplicity {
            controls[index - 1].clone()
        } else {
            let denominator = &knots[index + degree] - &knots[index];
            let alpha =
                ((parameter - &knots[index]) / denominator).map_err(GeometryError::Numeric)?;
            controls[index - 1].lerp(&controls[index], &alpha)
        };
        next.push(value);
    }
    let mut next_knots = Vec::with_capacity(knots.len() + 1);
    next_knots.extend_from_slice(&knots[..=span]);
    next_knots.push(parameter.clone());
    next_knots.extend_from_slice(&knots[(span + 1)..]);
    Ok((next, next_knots))
}

fn nurbs_from_homogeneous(
    degree: usize,
    controls: Vec<HomogeneousPoint3>,
    knots: Vec<Real>,
) -> GeometryResult<Curve3> {
    let mut points = Vec::with_capacity(controls.len());
    let mut weights = Vec::with_capacity(controls.len());
    for control in controls {
        points.push(control.project()?);
        weights.push(control.w);
    }
    Curve3::nurbs(degree, points, weights, knots)
}

#[cfg(test)]
#[path = "geometry/periodic_tests.rs"]
mod periodic_tests;

#[cfg(test)]
mod tests {
    use super::*;
    use hyperlimit::point3_equal;
    use hyperreal::Rational;

    fn r(value: i32) -> Real {
        Real::from(value)
    }

    fn q(numerator: i64, denominator: u64) -> Real {
        Real::new(Rational::fraction(numerator, denominator).unwrap())
    }

    fn p(x: i32, y: i32, z: i32) -> Point3 {
        Point3::new(r(x), r(y), r(z))
    }

    fn assert_points_equal(left: &Point3, right: &Point3) {
        assert_eq!(
            point3_equal(left, right, crate::TEST_ORACLE_PREDICATES).value(),
            Some(true)
        );
    }

    #[test]
    fn analytic_area_vectors_preserve_native_domains_and_orientation() {
        for (a, b) in [(r(2), r(2)), (r(2), r(3))] {
            let curve = if a == b {
                Curve3::circle_arc(
                    p(7, -4, 2),
                    Vector3::x(),
                    Vector3::y(),
                    a.clone(),
                    r(0),
                    Real::tau(),
                )
            } else {
                Curve3::ellipse_arc(
                    p(7, -4, 2),
                    Vector3::x(),
                    Vector3::y(),
                    a.clone(),
                    b.clone(),
                    r(0),
                    Real::tau(),
                )
            }
            .unwrap();
            for (start, end) in [
                (r(0), Real::tau()),
                (Real::pi() * q(1, 6), Real::pi() * q(1, 3)),
            ] {
                let expected = Vector3::z() * (&a * &b * (&end - &start));
                let area = curve
                    .analytic_area_vector(&start, &end, &p(7, -4, 2))
                    .unwrap()
                    .unwrap();
                assert_eq!(
                    point3_equal(
                        &Point3::from(area),
                        &Point3::from(expected.clone()),
                        crate::STRICT_PREDICATES
                    )
                    .value(),
                    Some(true)
                );
                let reversed = curve
                    .analytic_area_vector(&end, &start, &p(7, -4, 2))
                    .unwrap()
                    .unwrap();
                assert_eq!(
                    point3_equal(
                        &Point3::from(reversed),
                        &Point3::from(-expected),
                        crate::STRICT_PREDICATES
                    )
                    .value(),
                    Some(true)
                );
            }
            assert_eq!(
                curve
                    .analytic_area_vector(&r(-1), &r(0), &p(0, 0, 0))
                    .unwrap_err(),
                GeometryError::ParameterOutsideDomain
            );
        }
        let line = Curve3::line(p(1, 0, 0), p(0, 2, 0)).unwrap();
        assert_eq!(
            point3_equal(
                &Point3::from(
                    line.analytic_area_vector(&q(1, 4), &q(3, 4), &p(0, 0, 0))
                        .unwrap()
                        .unwrap()
                ),
                &p(0, 0, 1),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(true)
        );
    }

    #[test]
    fn circular_clipping_preserves_angular_parameter_correspondence() {
        let plane =
            Surface::plane(p(0, -20, -20), Vector3::y() * r(40), Vector3::z() * r(40)).unwrap();
        let spatial = Curve3::circle_arc(
            p(0, 5, 0),
            Vector3::y(),
            Vector3::z(),
            r(2),
            Real::zero(),
            Real::pi() * q(1, 2),
        )
        .unwrap();
        let trace = SurfaceIntersectionCurve::on_plane(spatial, &plane).unwrap();
        let uv = Point2::new((r(25) + r(3).sqrt().unwrap()) * q(1, 40), q(21, 40));
        for (trace, expected) in [
            (trace.clone(), Real::pi() * q(1, 6)),
            (trace.reversed().unwrap(), Real::pi() * q(1, 3)),
        ] {
            let carrier = trace
                .first_pcurve()
                .clipping_carriers()
                .unwrap()
                .unwrap()
                .pop()
                .unwrap();
            assert_eq!(carrier.curve.family(), CurveFamily2::CircularArc);
            let local = Pcurve::new(carrier.curve.clone())
                .parameters_at_point(&uv)
                .unwrap();
            assert_eq!(local.len(), 1);
            let spatial_parameter = carrier
                .spatial_parameter_at(local[0].try_real().unwrap())
                .unwrap();
            assert_eq!(
                hyperlimit::compare_reals(&spatial_parameter, &expected, crate::STRICT_PREDICATES)
                    .value(),
                Some(Ordering::Equal),
            );
            assert_eq!(
                hyperlimit::point2_equal(
                    &trace.first_pcurve().point_at(&spatial_parameter).unwrap(),
                    &uv,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(true),
            );
        }
    }

    #[test]
    fn circular_clipping_preserves_distinct_periodic_endpoint_parameters() {
        let plane = Surface::plane(p(0, 0, 0), Vector3::x(), Vector3::y()).unwrap();
        let trace = SurfaceIntersectionCurve::on_plane(
            Curve3::circle_arc(
                p(0, 0, 0),
                Vector3::x(),
                Vector3::y(),
                r(2),
                Real::zero(),
                Real::tau(),
            )
            .unwrap(),
            &plane,
        )
        .unwrap();
        for trace in [trace.clone(), trace.reversed().unwrap()] {
            let carrier = trace
                .first_pcurve()
                .clipping_carriers()
                .unwrap()
                .unwrap()
                .pop()
                .unwrap();
            for (local, expected) in [(Real::zero(), Real::zero()), (Real::one(), Real::tau())] {
                assert_eq!(
                    hyperlimit::compare_reals(
                        &carrier.spatial_parameter_at(&local).unwrap(),
                        &expected,
                        crate::STRICT_PREDICATES
                    )
                    .value(),
                    Some(Ordering::Equal)
                );
            }
        }
    }

    #[test]
    fn retained_clipping_preserves_restricted_reversed_domain() {
        let source = SurfaceIntersectionPcurve::retained_curve(Curve2::from(
            LineSeg2::try_new(CurvePoint2::new(r(0), r(0)), CurvePoint2::new(r(4), r(0))).unwrap(),
        ))
        .unwrap();
        let restricted = source
            .subcurve(&q(1, 4), &q(3, 4))
            .unwrap()
            .reversed()
            .unwrap();
        let carrier = restricted
            .clipping_carriers()
            .unwrap()
            .unwrap()
            .pop()
            .unwrap();
        for (local, expected_parameter, expected_x) in
            [(r(0), q(1, 4), r(3)), (r(1), q(3, 4), r(1))]
        {
            let spatial_parameter = carrier.spatial_parameter_at(&local).unwrap();
            assert_eq!(
                hyperlimit::compare_reals(
                    &spatial_parameter,
                    &expected_parameter,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
            let point = carrier.curve.point_at(&local.into()).unwrap();
            assert_eq!(
                hyperlimit::compare_reals(
                    point.coordinates().unwrap().x(),
                    &expected_x,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
        }
    }

    #[test]
    fn linear_section_clipping_preserves_restricted_reversed_domain() {
        let profile = Curve3::line(p(0, 0, 0), p(4, 0, 0)).unwrap();
        let plane = Surface::plane(p(0, 0, 1), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceGeometry::Plane(plane) = &plane.data.geometry else {
            unreachable!()
        };
        let source = SurfaceIntersectionPcurve::linear_plane_section(
            profile,
            plane,
            r(1),
            TensorAxis::U,
            r(1),
            r(0),
        );
        let restricted = source
            .subcurve(&q(1, 4), &q(3, 4))
            .unwrap()
            .reversed()
            .unwrap();
        let carrier = restricted
            .clipping_carriers()
            .unwrap()
            .unwrap()
            .pop()
            .unwrap();
        for (local, expected_parameter, expected_x) in
            [(r(0), q(1, 4), q(3, 4)), (r(1), q(3, 4), q(1, 4))]
        {
            let spatial_parameter = carrier.spatial_parameter_at(&local).unwrap();
            assert_eq!(
                hyperlimit::compare_reals(
                    &spatial_parameter,
                    &expected_parameter,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
            let point = carrier.curve.point_at(&local.into()).unwrap();
            assert_eq!(
                hyperlimit::compare_reals(
                    point.coordinates().unwrap().x(),
                    &expected_x,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
        }
    }

    #[test]
    fn circular_pcurve_contact_parameter_replays_exact_point() {
        let point = Point2::new(r(3), r(4));
        let curve = Pcurve::new(Curve2::from(
            CircularArc2::try_from_center(
                CurvePoint2::new(r(5), r(0)),
                CurvePoint2::new(r(0), r(5)),
                CurvePoint2::new(r(0), r(0)),
                false,
            )
            .unwrap(),
        ));
        for curve in [curve.clone(), curve.reversed().unwrap()] {
            let parameters = curve.parameters_at_point(&point).unwrap();
            assert_eq!(parameters.len(), 1);
            let replay = curve
                .evaluate_real(parameters[0].try_real().unwrap())
                .unwrap();
            assert_eq!(
                hyperlimit::point2_equal(&point, &replay, crate::STRICT_PREDICATES).value(),
                Some(true)
            );
            let near = Point2::new(r(3), r(4) + q(1, 1_000_000_000_000));
            assert!(curve.parameters_at_point(&near).unwrap().is_empty());
        }
        let full = Pcurve::new(Curve2::from(
            CircularArc2::try_from_center(
                CurvePoint2::new(r(5), r(0)),
                CurvePoint2::new(r(5), r(0)),
                CurvePoint2::new(r(0), r(0)),
                false,
            )
            .unwrap(),
        ));
        let parameters = full.parameters_at_point(&Point2::new(r(5), r(0))).unwrap();
        assert_eq!(parameters.len(), 2);
        assert_eq!(parameters[0].try_real(), Some(&Real::zero()));
        assert_eq!(parameters[1].try_real(), Some(&Real::one()));
    }

    #[test]
    fn line_pcurve_preimages_preserve_finite_domains_and_reversal() {
        for (dx, dy) in [(6, 8), (0, 8), (6, 0)] {
            let start = Point2::new(r(1), r(2));
            let point = |t: Real| Point2::new(&start.x + r(dx) * &t, &start.y + r(dy) * t);
            let end = point(Real::one());
            let pcurve = Pcurve::new(Curve2::from(
                LineSeg2::try_new(
                    CurvePoint2::new(start.x.clone(), start.y.clone()),
                    CurvePoint2::new(end.x, end.y),
                )
                .unwrap(),
            ));
            for (curve, reversed) in [(pcurve.clone(), false), (pcurve.reversed().unwrap(), true)] {
                for t in [Real::zero(), q(1, 4), q(1, 2), Real::one()] {
                    let expected = point(t.clone());
                    let parameters = curve.parameters_at_point(&expected).unwrap();
                    assert_eq!(parameters.len(), 1);
                    let actual = parameters[0].try_real().unwrap();
                    assert_eq!(
                        compare_reals(
                            actual,
                            &if reversed { Real::one() - &t } else { t },
                            crate::STRICT_PREDICATES,
                        )
                        .value(),
                        Some(Ordering::Equal)
                    );
                    assert_eq!(
                        hyperlimit::point2_equal(
                            &expected,
                            &curve.evaluate_real(actual).unwrap(),
                            crate::STRICT_PREDICATES,
                        )
                        .value(),
                        Some(true)
                    );
                    let tiny = q(1, 1_000_000_000_000);
                    let near = Point2::new(expected.x - r(dy) * &tiny, expected.y + r(dx) * tiny);
                    assert!(curve.parameters_at_point(&near).unwrap().is_empty());
                }
                for t in [q(-1, 2), q(3, 2)] {
                    assert!(curve.parameters_at_point(&point(t)).unwrap().is_empty());
                }
            }
        }
    }

    #[test]
    fn circular_boundary_replays_spatial_image_despite_cached_certificate() {
        use crate::topology::{BuildError, TopologyEditError};
        let (model, _) = crate::construction::cylinder(r(5), r(6)).unwrap();
        let (face, record) = model.faces().next().unwrap();
        let original = model.to_json().unwrap();
        let valid = SurfaceIntersectionCurve::on_plane(
            Curve3::circle_arc(
                p(0, 0, 0),
                Vector3::x(),
                Vector3::y(),
                r(5),
                Real::zero(),
                Real::tau(),
            )
            .unwrap(),
            model.surface(record.surface()).unwrap(),
        )
        .unwrap();
        let wrong = Curve3::circle_arc(
            p(1, 0, 0),
            Vector3::x(),
            Vector3::y(),
            r(4),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        for (a, b) in [
            (valid.curve().start().unwrap(), wrong.start().unwrap()),
            (valid.curve().end().unwrap(), wrong.end().unwrap()),
        ] {
            assert_eq!(
                point3_equal(&a, &b, crate::STRICT_PREDICATES).value(),
                Some(true)
            );
        }
        // The private constructor marks both images certified. The boundary
        // no-op must still replay complete image agreement on the actual face.
        let forged = SurfaceIntersectionCurve::new(
            wrong,
            valid.first_pcurve.clone(),
            valid.second_pcurve.clone(),
        );
        assert!(matches!(
            model.split_face_by_surface_curves(face, &[forged], SurfaceIntersectionOperand::First),
            Err(TopologyEditError::Build(BuildError::EdgeUseSupportMismatch))
        ));
        assert_eq!(model.to_json().unwrap(), original);
        let (unchanged, _) = model
            .split_face_by_surface_curves(face, &[valid], SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(unchanged.to_json().unwrap(), original);
    }

    #[test]
    fn common_analytic_chart_proof_distinguishes_image_and_parameterization() {
        let torus = |x, y, center| Surface::torus(center, x, y, Vector3::z(), r(5), r(2)).unwrap();
        let first = torus(Vector3::x(), Vector3::y(), p(0, 0, 0));
        let same = torus(Vector3::x(), Vector3::y(), p(0, 0, 0));
        assert!(
            first
                .same_periodic_analytic_parameterization(&same)
                .unwrap()
        );
        let rotated = torus(Vector3::y(), -Vector3::x(), p(0, 0, 0));
        assert!(matches!(
            first.intersect_surface(&rotated).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
        assert!(
            !first
                .same_periodic_analytic_parameterization(&rotated)
                .unwrap()
        );
        let near = torus(
            Vector3::x(),
            Vector3::y(),
            Point3::new(q(1, 1_000_000_000_000), r(0), r(0)),
        );
        assert!(
            !first
                .same_periodic_analytic_parameterization(&near)
                .unwrap()
        );
        let angle = q(1, 2).atan().unwrap();
        let cone = |x, y| Surface::cone(p(0, 0, 0), x, y, Vector3::z(), angle.clone()).unwrap();
        let first = cone(Vector3::x(), Vector3::y());
        assert!(
            first
                .same_periodic_analytic_parameterization(&cone(Vector3::x(), Vector3::y()))
                .unwrap()
        );
        assert!(
            !first
                .same_periodic_analytic_parameterization(&cone(Vector3::y(), -Vector3::x()))
                .unwrap()
        );
    }

    #[test]
    fn homogeneous_projection_retains_numeric_failure_causes() {
        use hyperreal::Problem;
        use std::error::Error;

        // This positive difference is below the scalar zero-test budget. Its
        // opaque exponentials prevent structural affine cancellation. It must
        // stay distinct from a denominator proven to be exactly zero.
        let tiny: Real = "1e-2000".parse().unwrap();
        let first = (Real::pi() + &tiny + &tiny).exp().unwrap();
        let second = (Real::pi() + tiny).exp().unwrap();
        let unresolved = first - second;

        for (denominator, expected) in [
            (Real::zero(), Problem::DivideByZero),
            (unresolved, Problem::UnknownZero),
        ] {
            let point = HomogeneousPoint3 {
                x: r(1),
                y: r(2),
                z: r(3),
                w: denominator.clone(),
            };
            let error = point.project().unwrap_err();
            assert_eq!(error, GeometryError::Numeric(expected));
            assert_eq!(
                error.source().unwrap().downcast_ref::<Problem>(),
                Some(&expected)
            );
            assert_eq!(
                divide_vector_by_real(Vector3::from_xyz(r(1), r(2), r(3)), &denominator),
                Err(GeometryError::Numeric(expected))
            );
        }
    }

    #[test]
    fn pcurve_evaluation_is_strict_inside_an_approximate_scope() {
        let curve = Pcurve::new(Curve2::from(
            hypercurve::LineSeg2::try_new(
                CurvePoint2::new(r(0), r(0)),
                CurvePoint2::new(r(1), r(0)),
            )
            .unwrap(),
        ));
        let tiny: Real = "1e-2000".parse().unwrap();
        let first = (Real::pi() + &tiny + &tiny).exp().unwrap();
        let second = (Real::pi() + tiny).exp().unwrap();
        // Strict comparison cannot certify this positive distance outside
        // the endpoint. A surrounding approximation policy must not admit it.
        let parameter = Real::one() + (first - second);
        let strict_error = curve
            .point_at(&crate::Parameter::from_real(parameter.clone()))
            .unwrap_err();
        assert!(matches!(
            strict_error,
            GeometryError::PlanarCurve(hypercurve::ExactCurveError::Blocked(_))
        ));
        let attempted = hypercurve::provisional(|| {
            curve.point_at(&crate::Parameter::from_real(parameter.clone()))
        });
        assert_eq!(attempted.certainty(), hypercurve::CurveCertainty::Certified);
        assert_eq!(attempted.into_unverified().unwrap_err(), strict_error);

        // A later direct Hypercurve call still sees its caller's approximate
        // policy. BREP must restore that scope instead of disabling it globally.
        let restored = hypercurve::provisional(|| {
            assert_eq!(
                curve
                    .point_at(&crate::Parameter::from_real(parameter.clone()))
                    .unwrap_err(),
                strict_error
            );
            curve.curve().point_at(&parameter.clone().into())
        });
        assert_eq!(
            restored.certainty(),
            hypercurve::CurveCertainty::Approximate512Consumed
        );
        assert!(restored.into_unverified().is_ok());

        // A warmed approximate result and explicit display tolerances cannot
        // become authority for the next BREP query either.
        let preview = hypercurve::CurvePreviewOptions::try_approximate_512(1e-6, 0.0).unwrap();
        let previewed = hypercurve::provisional(|| {
            preview.evaluate(|| curve.point_at(&crate::Parameter::from_real(parameter.clone())))
        });
        assert_eq!(previewed.certainty(), hypercurve::CurveCertainty::Certified);
        assert_eq!(previewed.into_unverified().unwrap_err(), strict_error);
    }

    #[test]
    fn line_uses_real_domain_and_exact_evaluation() {
        let curve = Curve3::line(p(0, 0, 0), p(2, 4, 6)).unwrap();
        assert_eq!(curve.kind(), Curve3Kind::Line);
        assert_points_equal(&curve.evaluate_real(&q(1, 2)).unwrap(), &p(1, 2, 3));
        assert_eq!(
            curve.evaluate_real(&r(2)),
            Err(GeometryError::ParameterOutsideDomain)
        );
    }

    #[test]
    fn rational_bezier_evaluates_homogeneously() {
        let curve =
            Curve3::rational_bezier(vec![p(0, 0, 0), p(2, 4, 6)], vec![r(1), r(1)]).unwrap();
        assert_points_equal(&curve.evaluate_real(&q(1, 2)).unwrap(), &p(1, 2, 3));
        let derivative = curve.derivative_at(&q(1, 3), 1).unwrap();
        assert_eq!(derivative.vector().0, [r(2), r(4), r(6)]);
        let bounds = curve.bounds().unwrap();
        assert_points_equal(&bounds.mins, &p(0, 0, 0));
        assert_points_equal(&bounds.maxs, &p(2, 4, 6));
    }

    #[test]
    fn derivative_order_capacity_overflow_is_typed() {
        let controls = vec![p(0, 0, 0), p(2, 4, 6)];
        let weights = vec![r(1), r(2)];
        let bezier = Curve3::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let nurbs = Curve3::nurbs(1, controls, weights, vec![r(0), r(0), r(1), r(1)]).unwrap();
        for curve in [bezier, nurbs] {
            for order in [usize::MAX, usize::MAX - 1] {
                assert_eq!(
                    curve.derivative_at(&q(1, 2), order).unwrap_err(),
                    GeometryError::Numeric(hyperreal::Problem::OutOfRange)
                );
            }
        }
        // Closed-form families need no jet buffer. A large order remains
        // valid when its answer can be obtained directly.
        let line = Curve3::line(p(0, 0, 0), p(2, 4, 6)).unwrap();
        assert_eq!(
            line.derivative_at(&q(1, 2), usize::MAX).unwrap().vector().0,
            [r(0), r(0), r(0)]
        );
    }

    #[test]
    fn every_curve_family_exposes_exact_positive_order_derivatives() {
        let line = Curve3::line(p(0, 0, 0), p(2, 4, 6)).unwrap();
        assert_eq!(
            line.derivative_at(&q(1, 2), 2).unwrap().vector().0,
            Vector3::zero().0
        );
        assert_eq!(
            line.derivative_at(&q(1, 2), 0).unwrap_err(),
            GeometryError::InvalidDerivativeOrder
        );

        let polynomial = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(1, 0, 0), p(4, 0, 0)],
            vec![r(1), r(1), r(1)],
        )
        .unwrap();
        assert_points_equal(
            &Point3::from(
                polynomial
                    .derivative_at(&q(1, 2), 1)
                    .unwrap()
                    .vector()
                    .clone(),
            ),
            &p(4, 0, 0),
        );
        assert_points_equal(
            &Point3::from(
                polynomial
                    .derivative_at(&q(1, 2), 2)
                    .unwrap()
                    .vector()
                    .clone(),
            ),
            &p(4, 0, 0),
        );
        assert_eq!(
            polynomial.derivative_at(&q(1, 2), 3).unwrap().vector().0,
            Vector3::zero().0
        );
        let rational = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(1, 0, 0), p(2, 0, 0)],
            vec![r(1), r(2), r(1)],
        )
        .unwrap();
        assert_points_equal(
            &Point3::from(rational.derivative_at(&r(0), 2).unwrap().vector().clone()),
            &p(-20, 0, 0),
        );

        let nurbs = Curve3::nurbs(
            2,
            vec![p(0, 0, 0), p(1, 0, 0), p(4, 0, 0)],
            vec![r(1), r(1), r(1)],
            vec![r(0), r(0), r(0), r(1), r(1), r(1)],
        )
        .unwrap();
        assert_points_equal(
            &Point3::from(nurbs.derivative_at(&q(1, 2), 2).unwrap().vector().clone()),
            &p(4, 0, 0),
        );
        assert_eq!(
            nurbs.derivative_at(&q(1, 2), 3).unwrap().vector().0,
            Vector3::zero().0
        );

        let half_pi = (Real::pi() / r(2)).unwrap();
        let circle = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(2),
            Real::zero(),
            half_pi,
        )
        .unwrap();
        for (order, expected) in [
            (1, p(0, 2, 0)),
            (2, p(-2, 0, 0)),
            (3, p(0, -2, 0)),
            (4, p(2, 0, 0)),
        ] {
            assert_points_equal(
                &Point3::from(
                    circle
                        .derivative_at(&Real::zero(), order)
                        .unwrap()
                        .vector()
                        .clone(),
                ),
                &expected,
            );
        }
    }

    #[test]
    fn nurbs_uses_its_exact_active_domain() {
        let curve = Curve3::nurbs(
            1,
            vec![p(0, 0, 0), p(2, 0, 0), p(4, 0, 0)],
            vec![r(1), r(1), r(1)],
            vec![r(0), r(0), r(1), r(2), r(2)],
        )
        .unwrap();
        assert_eq!(curve.domain().start(), &r(0));
        assert_eq!(curve.domain().end(), &r(2));
        assert_points_equal(&curve.evaluate_real(&q(3, 2)).unwrap(), &p(3, 0, 0));
        assert_eq!(
            curve.derivative_at(&q(3, 2), 1).unwrap().vector().0,
            [r(2), r(0), r(0)]
        );
    }

    #[test]
    fn reversal_split_and_line_parameter_location_are_exact() {
        let line = Curve3::line(p(1, 2, 3), p(5, 10, 15)).unwrap();
        let parameter = q(1, 4);
        let point = line.evaluate_real(&parameter).unwrap();
        let CurveParameterLocation::Parameters(parameters) = line.parameters_of(&point).unwrap()
        else {
            panic!("line point must have one parameter");
        };
        assert_eq!(parameters.len(), 1);
        assert_eq!(
            parameters[0]
                .compare(&Parameter::from_real(parameter.clone()))
                .unwrap(),
            Ordering::Equal
        );
        assert!(matches!(
            line.parameters_of(&p(2, 5, 6)).unwrap(),
            CurveParameterLocation::None
        ));
        let reversed = line.reversed().unwrap();
        assert_points_equal(
            &line.evaluate_real(&parameter).unwrap(),
            &reversed.evaluate_real(&q(3, 4)).unwrap(),
        );

        let curve = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(2, 4, 0), p(4, 0, 0)],
            vec![r(1), r(2), r(1)],
        )
        .unwrap();
        let (left, right) = curve.split_at(&q(1, 2)).unwrap();
        assert_points_equal(&left.end().unwrap(), &right.start().unwrap());
        assert_points_equal(
            &left.evaluate_real(&q(1, 2)).unwrap(),
            &curve.evaluate_real(&q(1, 4)).unwrap(),
        );
        assert_points_equal(
            &right.evaluate_real(&q(1, 2)).unwrap(),
            &curve.evaluate_real(&q(3, 4)).unwrap(),
        );
        let middle = curve.subcurve(&q(1, 4), &q(3, 4)).unwrap();
        assert_points_equal(
            &middle.start().unwrap(),
            &curve.evaluate_real(&q(1, 4)).unwrap(),
        );
        assert_points_equal(
            &middle.end().unwrap(),
            &curve.evaluate_real(&q(3, 4)).unwrap(),
        );
        assert_points_equal(
            &middle.evaluate_real(&q(1, 2)).unwrap(),
            &curve.evaluate_real(&q(1, 2)).unwrap(),
        );

        let nurbs = Curve3::nurbs(
            2,
            vec![p(0, 0, 0), p(1, 2, 0), p(3, 2, 0), p(4, 0, 0)],
            vec![r(1), r(1), r(1), r(1)],
            vec![r(0), r(0), r(0), r(1), r(2), r(2), r(2)],
        )
        .unwrap();
        let (left, right) = nurbs.split_at(&r(1)).unwrap();
        assert!(left.shares_parameterization(&nurbs));
        assert!(right.shares_parameterization(&nurbs));
        assert_points_equal(&left.end().unwrap(), &right.start().unwrap());
        assert_points_equal(
            &left.evaluate_real(&q(1, 2)).unwrap(),
            &nurbs.evaluate_real(&q(1, 2)).unwrap(),
        );
        assert_points_equal(
            &right.evaluate_real(&q(3, 2)).unwrap(),
            &nurbs.evaluate_real(&q(3, 2)).unwrap(),
        );
        let middle = nurbs.subcurve(&q(1, 2), &q(3, 2)).unwrap();
        assert_eq!(middle.domain().start(), &q(1, 2));
        assert_eq!(middle.domain().end(), &q(3, 2));
        assert_points_equal(
            &middle.evaluate_real(&r(1)).unwrap(),
            &nurbs.evaluate_real(&r(1)).unwrap(),
        );
    }

    #[test]
    fn rational_bezier_and_arc_parameter_location_is_certified() {
        let rational = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(1, 2, 0), p(2, 0, 0)],
            vec![r(1), r(1), r(1)],
        )
        .unwrap();
        let query = rational.evaluate_real(&q(1, 2)).unwrap();
        let CurveParameterLocation::Parameters(parameters) =
            rational.parameters_of(&query).unwrap()
        else {
            panic!("represented Bézier point must retain its parameter");
        };
        assert_eq!(parameters.len(), 1);
        assert_eq!(
            parameters[0]
                .compare(&Parameter::from_real(q(1, 2)))
                .unwrap(),
            Ordering::Equal
        );
        assert!(matches!(
            rational.parameters_of(&p(8, 8, 8)).unwrap(),
            CurveParameterLocation::None
        ));

        let constant =
            Curve3::rational_bezier(vec![p(3, 4, 5), p(3, 4, 5)], vec![r(1), r(2)]).unwrap();
        assert!(matches!(
            constant.parameters_of(&p(3, 4, 5)).unwrap(),
            CurveParameterLocation::EntireDomain
        ));
        let algebraic = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(0, 0, 0), p(1, 0, 0)],
            vec![r(1), r(1), r(1)],
        )
        .unwrap();
        let CurveParameterLocation::Parameters(parameters) = algebraic
            .parameters_of(&Point3::new(q(1, 2), r(0), r(0)))
            .unwrap()
        else {
            panic!("the selected positive square root must survive the query");
        };
        assert_eq!(parameters.len(), 1);
        assert!(parameters[0].try_real().is_none());
        assert_eq!(
            parameters[0]
                .compare(&Parameter::from_real(q(1, 2)))
                .unwrap(),
            Ordering::Greater
        );
        assert_eq!(
            parameters[0].compare(&Parameter::from_real(r(1))).unwrap(),
            Ordering::Less
        );

        let full_circle = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(2),
            Real::zero(),
            Real::from(2) * Real::pi(),
        )
        .unwrap();
        let CurveParameterLocation::Parameters(seam) =
            full_circle.parameters_of(&p(2, 0, 0)).unwrap()
        else {
            panic!("full-circle seam must retain both exact parameters");
        };
        assert_eq!(seam.len(), 2);
        let parameter = (Real::pi() / r(3)).unwrap();
        let point = full_circle.evaluate_real(&parameter).unwrap();
        let CurveParameterLocation::Parameters(parameters) =
            full_circle.parameters_of(&point).unwrap()
        else {
            panic!("arc point must retain its exact angular parameter");
        };
        assert_eq!(
            parameters[0]
                .compare(&Parameter::from_real(parameter.clone()))
                .unwrap(),
            Ordering::Equal
        );

        let nurbs = Curve3::nurbs(
            1,
            vec![p(0, 0, 0), p(2, 0, 0), p(4, 0, 0)],
            vec![r(1), r(1), r(1)],
            vec![r(0), r(0), r(1), r(2), r(2)],
        )
        .unwrap();
        let parameter = q(3, 2);
        let point = nurbs.evaluate_real(&parameter).unwrap();
        let CurveParameterLocation::Parameters(parameters) = nurbs.parameters_of(&point).unwrap()
        else {
            panic!("NURBS point must retain its global parameter");
        };
        assert_eq!(parameters.len(), 1);
        assert_eq!(
            parameters[0]
                .compare(&Parameter::from_real(parameter.clone()))
                .unwrap(),
            Ordering::Equal
        );
    }

    #[test]
    fn parameterized_plane_retains_authored_frame() {
        let surface = Surface::plane(p(1, 2, 3), Vector3::x(), Vector3::z()).unwrap();
        let parameter = Point2::new(r(4), r(5));
        assert_points_equal(&surface.point_at(&parameter).unwrap(), &p(5, 2, 8));
        let partials = surface.partials_at(&parameter).unwrap();
        assert_eq!(partials.u().0, Vector3::x().0);
        assert_eq!(partials.v().0, Vector3::z().0);
    }

    #[test]
    fn tensor_rational_bezier_surface_is_exact_and_bounded_by_its_control_net() {
        let surface = Surface::rational_bezier(
            vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 4, 0), p(2, 4, 2)]],
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        assert_eq!(surface.kind(), SurfaceKind::RationalBezier);
        let middle = Point2::new(q(1, 2), q(1, 2));
        assert_points_equal(
            &surface.point_at(&middle).unwrap(),
            &Point3::new(r(1), r(2), q(1, 2)),
        );
        let partials = surface.partials_at(&middle).unwrap();
        assert_points_equal(&Point3::from(partials.u().clone()), &p(2, 0, 1));
        assert_points_equal(&Point3::from(partials.v().clone()), &p(0, 4, 1));
        let SurfaceBounds::Bounded(bounds) = surface.bounds().unwrap() else {
            panic!("finite spline surface must be bounded");
        };
        assert_points_equal(&bounds.mins, &p(0, 0, 0));
        assert_points_equal(&bounds.maxs, &p(2, 4, 2));
    }

    #[test]
    fn extrusion_and_revolution_surfaces_retain_exact_authored_parameters() {
        let extrusion = Surface::extrusion(
            Curve3::line(p(0, 0, 0), p(2, 0, 0)).unwrap(),
            Vector3::from_xyz(r(0), r(3), r(0)),
        )
        .unwrap();
        assert_eq!(extrusion.kind(), SurfaceKind::Extrusion);
        let parameter = Point2::new(q(1, 2), r(2));
        assert_points_equal(&extrusion.point_at(&parameter).unwrap(), &p(1, 6, 0));
        let partials = extrusion.partials_at(&parameter).unwrap();
        assert_points_equal(&Point3::from(partials.u().clone()), &p(2, 0, 0));
        assert_points_equal(&Point3::from(partials.v().clone()), &p(0, 3, 0));
        assert!(matches!(
            extrusion.bounds().unwrap(),
            SurfaceBounds::Unbounded
        ));

        let revolution = Surface::revolution(
            Curve3::line(p(2, 0, -1), p(2, 0, 1)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(revolution.kind(), SurfaceKind::Revolution);
        let half_pi = (Real::pi() / r(2)).unwrap();
        let parameter = Point2::new(half_pi, q(1, 2));
        assert_points_equal(&revolution.point_at(&parameter).unwrap(), &p(0, 2, 0));
        let partials = revolution.partials_at(&parameter).unwrap();
        assert_points_equal(&Point3::from(partials.u().clone()), &p(-2, 0, 0));
        assert_points_equal(&Point3::from(partials.v().clone()), &p(0, 0, 2));
        let SurfaceBounds::Bounded(bounds) = revolution.bounds().unwrap() else {
            panic!("finite revolution must have conservative bounds");
        };
        assert_points_equal(&bounds.mins, &p(-2, -2, -1));
        assert_points_equal(&bounds.maxs, &p(2, 2, 1));

        let translated_axis = Surface::revolution(
            Curve3::line(p(0, 4, 3), p(3, 4, 3)).unwrap(),
            p(1, 2, 3),
            Vector3::x(),
        )
        .unwrap();
        let SurfaceBounds::Bounded(bounds) = translated_axis.bounds().unwrap() else {
            panic!("an arbitrarily oriented finite revolution must remain bounded");
        };
        assert_points_equal(&bounds.mins, &p(0, 0, 1));
        assert_points_equal(&bounds.maxs, &p(3, 4, 5));
    }

    #[test]
    fn transverse_planes_retain_exact_revolution_profile_sections() {
        let profile = Curve3::line(p(2, 0, -1), p(4, 0, 1)).unwrap();
        let revolution = Surface::revolution(profile, Point3::origin(), Vector3::z()).unwrap();
        let plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            plane.intersect_surface(&revolution).unwrap()
        else {
            panic!("one transverse profile point must retain one revolution circle");
        };
        assert_points_equal(&section.curve().start().unwrap(), &p(3, 0, 0));
        assert_eq!(
            section
                .first_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::CircularArc
        );
        assert_eq!(
            section
                .second_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::Line
        );
        for parameter in [Real::zero(), (Real::pi() / r(2)).unwrap()] {
            let spatial = section.curve().evaluate_real(&parameter).unwrap();
            let plane_parameter = section.first_pcurve().point_at(&parameter).unwrap();
            let revolution_parameter = section.second_pcurve().point_at(&parameter).unwrap();
            assert_eq!(
                compare_reals(&revolution_parameter.y, &q(1, 2), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            assert_points_equal(&plane.point_at(&plane_parameter).unwrap(), &spatial);
            assert_points_equal(
                &revolution.point_at(&revolution_parameter).unwrap(),
                &spatial,
            );
        }
        let SurfaceSurfaceIntersection::Curve(swapped) =
            revolution.intersect_surface(&plane).unwrap()
        else {
            panic!("operand reversal must retain the revolution section");
        };
        let parameter = (Real::pi() / r(2)).unwrap();
        let spatial = swapped.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &revolution
                .point_at(&swapped.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &plane
                .point_at(&swapped.second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let semicircle = Curve3::circle_arc(
            p(3, 0, 0),
            Vector3::x(),
            Vector3::z(),
            Real::one(),
            Real::zero(),
            Real::pi(),
        )
        .unwrap();
        let double = Surface::revolution(semicircle, Point3::origin(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curves(sections) =
            double.intersect_surface(&plane).unwrap()
        else {
            panic!("two profile contacts must retain two revolution circles");
        };
        assert_eq!(sections.len(), 2);
        assert_points_equal(&sections[0].curve().start().unwrap(), &p(4, 0, 0));
        assert_points_equal(&sections[1].curve().start().unwrap(), &p(2, 0, 0));

        let disjoint = Surface::plane(p(0, 0, 2), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            revolution.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let singular = Surface::revolution(
            Curve3::line(p(0, 0, -1), p(0, 0, 1)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Point(point) = singular.intersect_surface(&plane).unwrap()
        else {
            panic!("a transverse revolution-axis contact must retain its singular point");
        };
        assert_points_equal(&point, &Point3::origin());

        let coincident_profile = Surface::revolution(
            Curve3::line(p(2, 0, 0), p(4, 0, 0)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(
            coincident_profile.intersect_surface(&plane).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let axial = Surface::plane(Point3::origin(), Vector3::x(), Vector3::z()).unwrap();
        assert_eq!(
            revolution.intersect_surface(&axial).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_spline_revolutions_retain_exact_meridian_contacts() {
        let profile = Curve3::nurbs(
            1,
            vec![p(2, 0, 0), p(3, 0, 1), p(4, 0, 0)],
            vec![r(1), r(1), r(1)],
            vec![r(0), r(0), r(1), r(2), r(2)],
        )
        .unwrap();
        let first = Surface::revolution(profile.clone(), Point3::origin(), Vector3::z()).unwrap();
        let second = Surface::revolution(
            Curve3::line(p(2, 0, 1), p(4, 0, 1)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = first.intersect_surface(&second).unwrap()
        else {
            panic!("one represented knot contact must lift to one retained latitude");
        };
        assert_points_equal(&section.curve().start().unwrap(), &p(3, 0, 1));
        for parameter in [Real::zero(), (Real::pi() / r(2)).unwrap()] {
            let spatial = section.curve().evaluate_real(&parameter).unwrap();
            let first_parameter = section.first_pcurve().point_at(&parameter).unwrap();
            let second_parameter = section.second_pcurve().point_at(&parameter).unwrap();
            assert_eq!(
                compare_reals(&first_parameter.y, &r(1), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            assert_eq!(
                compare_reals(&second_parameter.y, &q(1, 2), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            assert_points_equal(&first.point_at(&first_parameter).unwrap(), &spatial);
            assert_points_equal(&second.point_at(&second_parameter).unwrap(), &spatial);
        }

        let SurfaceSurfaceIntersection::Curve(swapped) = second.intersect_surface(&first).unwrap()
        else {
            panic!("operand reversal must preserve the retained spline latitude");
        };
        let parameter = (Real::pi() / r(2)).unwrap();
        let spatial = swapped.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &second
                .point_at(&swapped.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &first
                .point_at(&swapped.second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let coincident = Surface::revolution(profile, p(0, 0, 5), Vector3::z()).unwrap();
        assert!(matches!(
            first.intersect_surface(&coincident).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));

        let mirrored = Surface::revolution(
            Curve3::line(p(2, 0, 1), p(4, 0, 1)).unwrap(),
            p(0, 0, 3),
            -Vector3::z(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(mirrored_section) =
            first.intersect_surface(&mirrored).unwrap()
        else {
            panic!("counteroriented coaxial frames must retain a mirrored pcurve");
        };
        let parameter = (Real::pi() / r(2)).unwrap();
        let mirrored_parameter = mirrored_section
            .second_pcurve()
            .point_at(&parameter)
            .unwrap();
        assert_eq!(
            compare_reals(
                &mirrored_parameter.x,
                &(Real::tau() - parameter.clone()),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_points_equal(
            &mirrored.point_at(&mirrored_parameter).unwrap(),
            &mirrored_section.curve().evaluate_real(&parameter).unwrap(),
        );

        let rotated = Surface::revolution(
            Curve3::line(p(0, 2, 1), p(0, 4, 1)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Circle(circle) = first.intersect_surface(&rotated).unwrap()
        else {
            panic!("rotated meridian frames must retain the exact spatial circle only");
        };
        assert_points_equal(&circle.start().unwrap(), &p(3, 0, 1));

        let disjoint = Surface::revolution(
            Curve3::line(p(2, 0, 2), p(4, 0, 2)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert!(matches!(
            first.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
    }

    #[test]
    fn coaxial_revolution_overlap_and_meridian_contracts_are_explicit() {
        let first = Surface::revolution(
            Curve3::line(p(2, 0, 0), p(4, 0, 2)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        let partial_overlap = Surface::revolution(
            Curve3::line(p(3, 0, 1), p(5, 0, 3)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(
            first.intersect_surface(&partial_overlap).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );

        let noncoaxial = Surface::revolution(
            Curve3::line(p(3, 0, 0), p(3, 0, 2)).unwrap(),
            p(1, 0, 0),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(
            first.intersect_surface(&noncoaxial).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );

        let crossing_profile = Surface::revolution(
            Curve3::line(p(-2, 0, 0), p(2, 0, 1)).unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(
            crossing_profile.intersect_surface(&first).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn algebraic_revolution_meridian_contacts_are_not_approximated() {
        let quadratic = Surface::revolution(
            Curve3::rational_bezier(
                vec![p(2, 0, 0), Point3::new(r(2), r(0), q(1, 2)), p(3, 0, 1)],
                vec![r(1), r(1), r(1)],
            )
            .unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        let radial_line = Surface::revolution(
            Curve3::line(
                Point3::new(q(5, 2), r(0), r(0)),
                Point3::new(q(5, 2), r(0), r(1)),
            )
            .unwrap(),
            Point3::origin(),
            Vector3::z(),
        )
        .unwrap();
        assert_eq!(
            quadratic.intersect_surface(&radial_line).unwrap_err(),
            GeometryError::UnrepresentableParameter
        );
    }

    #[test]
    fn tensor_nurbs_surface_uses_both_exact_active_domains_and_partials() {
        let surface = Surface::nurbs(
            1,
            1,
            vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 4, 0), p(2, 4, 2)]],
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
            vec![r(0), r(0), r(2), r(2)],
            vec![r(1), r(1), r(3), r(3)],
        )
        .unwrap();
        assert_eq!(surface.kind(), SurfaceKind::Nurbs);
        let SurfaceParameterDomain::Closed(u_domain) = surface.domain().u() else {
            panic!("NURBS u domain must be closed");
        };
        let SurfaceParameterDomain::Closed(v_domain) = surface.domain().v() else {
            panic!("NURBS v domain must be closed");
        };
        assert_eq!(
            compare_reals(u_domain.end(), &r(2), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(v_domain.start(), &r(1), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        let middle = Point2::new(r(1), r(2));
        assert_points_equal(
            &surface.point_at(&middle).unwrap(),
            &Point3::new(r(1), r(2), q(1, 2)),
        );
        let partials = surface.partials_at(&middle).unwrap();
        assert_points_equal(
            &Point3::from(partials.u().clone()),
            &Point3::new(r(1), r(0), q(1, 2)),
        );
        assert_points_equal(
            &Point3::from(partials.v().clone()),
            &Point3::new(r(0), r(2), q(1, 2)),
        );
    }

    #[test]
    fn tensor_surface_subdivision_preserves_exact_images_on_both_axes() {
        let bezier = Surface::rational_bezier(
            vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 4, 0), p(2, 4, 2)]],
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        let (u_left, u_right) = bezier.split_u_at(&q(1, 2)).unwrap();
        assert_points_equal(
            &u_left.point_at(&Point2::new(q(1, 2), q(3, 4))).unwrap(),
            &bezier.point_at(&Point2::new(q(1, 4), q(3, 4))).unwrap(),
        );
        assert_points_equal(
            &u_right.point_at(&Point2::new(q(1, 2), q(3, 4))).unwrap(),
            &bezier.point_at(&Point2::new(q(3, 4), q(3, 4))).unwrap(),
        );
        let (v_left, v_right) = bezier.split_v_at(&q(1, 2)).unwrap();
        assert_points_equal(
            &v_left.point_at(&Point2::new(q(3, 4), q(1, 2))).unwrap(),
            &bezier.point_at(&Point2::new(q(3, 4), q(1, 4))).unwrap(),
        );
        assert_points_equal(
            &v_right.point_at(&Point2::new(q(3, 4), q(1, 2))).unwrap(),
            &bezier.point_at(&Point2::new(q(3, 4), q(3, 4))).unwrap(),
        );
        let iso_u = bezier.iso_curve(SurfaceIsoAxis::U, &q(3, 4)).unwrap();
        assert_points_equal(
            &iso_u.evaluate_real(&q(1, 3)).unwrap(),
            &bezier.point_at(&Point2::new(q(1, 3), q(3, 4))).unwrap(),
        );
        let iso_v = bezier.iso_curve(SurfaceIsoAxis::V, &q(1, 3)).unwrap();
        assert_points_equal(
            &iso_v.evaluate_real(&q(3, 4)).unwrap(),
            &bezier.point_at(&Point2::new(q(1, 3), q(3, 4))).unwrap(),
        );

        let nurbs = Surface::nurbs(
            2,
            2,
            vec![
                vec![p(0, 0, 0), p(1, 0, 0), p(2, 0, 0)],
                vec![p(0, 1, 0), p(1, 1, 1), p(2, 1, 0)],
                vec![p(0, 2, 0), p(1, 2, 0), p(2, 2, 0)],
            ],
            vec![
                vec![r(1), r(1), r(1)],
                vec![r(1), r(1), r(1)],
                vec![r(1), r(1), r(1)],
            ],
            vec![r(0), r(0), r(0), r(1), r(1), r(1)],
            vec![r(0), r(0), r(0), r(1), r(1), r(1)],
        )
        .unwrap();
        let (u_left, u_right) = nurbs.split_u_at(&q(1, 2)).unwrap();
        for (surface, parameter) in [(&u_left, q(1, 4)), (&u_right, q(3, 4))] {
            assert_points_equal(
                &surface
                    .point_at(&Point2::new(parameter.clone(), q(2, 3)))
                    .unwrap(),
                &nurbs.point_at(&Point2::new(parameter, q(2, 3))).unwrap(),
            );
        }
        let (v_left, v_right) = nurbs.split_v_at(&q(1, 2)).unwrap();
        for (surface, parameter) in [(&v_left, q(1, 4)), (&v_right, q(3, 4))] {
            assert_points_equal(
                &surface
                    .point_at(&Point2::new(q(1, 3), parameter.clone()))
                    .unwrap(),
                &nurbs.point_at(&Point2::new(q(1, 3), parameter)).unwrap(),
            );
        }
        let iso_u = nurbs.iso_curve(SurfaceIsoAxis::U, &q(2, 3)).unwrap();
        assert_points_equal(
            &iso_u.evaluate_real(&q(1, 3)).unwrap(),
            &nurbs.point_at(&Point2::new(q(1, 3), q(2, 3))).unwrap(),
        );
        let iso_v = nurbs.iso_curve(SurfaceIsoAxis::V, &q(1, 3)).unwrap();
        assert_points_equal(
            &iso_v.evaluate_real(&q(2, 3)).unwrap(),
            &nurbs.point_at(&Point2::new(q(1, 3), q(2, 3))).unwrap(),
        );
    }

    #[test]
    fn tensor_surface_validation_and_affine_retention_are_explicit() {
        assert_eq!(
            Surface::rational_bezier(
                vec![vec![p(0, 0, 0), p(1, 0, 0)], vec![p(0, 1, 0)]],
                vec![vec![r(1), r(1)], vec![r(1)]],
            )
            .unwrap_err(),
            GeometryError::InvalidControlNetShape
        );
        assert_eq!(
            Surface::rational_bezier(
                vec![vec![p(0, 0, 0), p(1, 0, 0)], vec![p(0, 1, 0), p(1, 1, 0)]],
                vec![vec![r(1), r(1)], vec![r(1)]],
            )
            .unwrap_err(),
            GeometryError::SurfaceWeightShapeMismatch
        );
        assert_eq!(
            Surface::extrusion(
                Curve3::line(p(0, 0, 0), p(1, 0, 0)).unwrap(),
                Vector3::zero(),
            )
            .unwrap_err(),
            GeometryError::DegenerateExtrusionDirection
        );
        assert_eq!(
            Surface::revolution(
                Curve3::line(p(1, 0, 0), p(1, 0, 1)).unwrap(),
                Point3::origin(),
                Vector3::from_xyz(r(0), r(0), r(2)),
            )
            .unwrap_err(),
            GeometryError::InvalidRevolutionAxis
        );

        let surface = Surface::rational_bezier(
            vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 4, 0), p(2, 4, 2)]],
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        let translated = surface
            .transformed(
                &TransformMetric::new(&Matrix4::affine_translation([r(3), r(-2), r(5)])),
                false,
            )
            .unwrap();
        let parameter = Point2::new(q(1, 4), q(3, 4));
        let expected = surface.point_at(&parameter).unwrap() + Vector3::from_xyz(r(3), r(-2), r(5));
        assert_points_equal(&translated.point_at(&parameter).unwrap(), &expected);

        let reflected = surface
            .transformed(
                &TransformMetric::new(&Matrix4::from_row_major([
                    r(-1),
                    r(0),
                    r(0),
                    r(0),
                    r(0),
                    r(1),
                    r(0),
                    r(0),
                    r(0),
                    r(0),
                    r(1),
                    r(0),
                    r(0),
                    r(0),
                    r(0),
                    r(1),
                ])),
                true,
            )
            .unwrap();
        let mirrored_original = surface.point_at(&Point2::new(q(3, 4), q(3, 4))).unwrap();
        let expected = Point3::new(
            -mirrored_original.x,
            mirrored_original.y,
            mirrored_original.z,
        );
        assert_points_equal(&reflected.point_at(&parameter).unwrap(), &expected);
    }

    #[test]
    fn affine_tensor_parameter_planes_retain_native_bezier_and_nurbs_coordinates() {
        let bezier = Surface::rational_bezier(
            vec![vec![p(2, 3, 5), p(6, 3, 7)], vec![p(2, 9, 8), p(6, 9, 10)]],
            vec![vec![r(2), r(2)], vec![r(2), r(2)]],
        )
        .unwrap();
        let bezier_parameters = bezier.affine_parameter_plane().unwrap().unwrap();
        let parameter = Point2::new(q(1, 3), q(2, 5));
        assert_points_equal(
            &bezier.point_at(&parameter).unwrap(),
            &bezier_parameters.point_at(&parameter).unwrap(),
        );

        let nurbs = Surface::nurbs(
            1,
            1,
            vec![vec![p(2, 3, 5), p(6, 3, 7)], vec![p(2, 9, 8), p(6, 9, 10)]],
            vec![vec![r(3), r(3)], vec![r(3), r(3)]],
            vec![r(2), r(2), r(4), r(4)],
            vec![r(5), r(5), r(9), r(9)],
        )
        .unwrap();
        let nurbs_parameters = nurbs.affine_parameter_plane().unwrap().unwrap();
        let native_parameter = Point2::new(r(3), r(7));
        assert_points_equal(
            &nurbs.point_at(&native_parameter).unwrap(),
            &nurbs_parameters.point_at(&native_parameter).unwrap(),
        );

        let projective = Surface::rational_bezier(
            vec![vec![p(0, 0, 0), p(1, 0, 0)], vec![p(0, 1, 0), p(1, 1, 0)]],
            vec![vec![r(1), r(2)], vec![r(1), r(2)]],
        )
        .unwrap();
        assert!(projective.affine_parameter_plane().unwrap().is_none());
    }

    #[test]
    fn affine_bilinear_projective_weights_have_exact_mobius_inverse_pcurves() {
        let surface = Surface::rational_bezier(
            vec![vec![p(0, 0, 1), p(1, 0, 1)], vec![p(0, 1, 1), p(1, 1, 1)]],
            vec![vec![r(1), r(2)], vec![r(3), r(6)]],
        )
        .unwrap();
        let curve = Curve3::rational_bezier(
            vec![
                Point3::new(r(0), q(1, 4), r(1)),
                Point3::new(q(1, 2), r(0), r(1)),
                Point3::new(r(1), q(3, 4), r(1)),
            ],
            vec![r(1), r(1), r(1)],
        )
        .unwrap();
        let pcurve = surface
            .affine_bilinear_inverse_pcurve(&curve)
            .unwrap()
            .expect("rank-one bilinear weights have a rational Möbius inverse");
        let Some(CurveGeometry2::RationalBezier(inverse)) = pcurve.geometry() else {
            panic!("Möbius inverse retains a rational Bézier carrier");
        };
        assert_eq!(inverse.degree(), 4);
        for parameter in [Real::zero(), q(1, 2), Real::one()] {
            let uv = pcurve
                .point_at(&parameter.clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone();
            assert_points_equal(
                &surface
                    .point_at(&Point2::new(uv.x().clone(), uv.y().clone()))
                    .unwrap(),
                &curve.evaluate_real(&parameter).unwrap(),
            );
        }

        let nurbs = Surface::nurbs(
            1,
            1,
            vec![vec![p(0, 0, 1), p(1, 0, 1)], vec![p(0, 1, 1), p(1, 1, 1)]],
            vec![vec![r(1), r(2)], vec![r(3), r(6)]],
            vec![r(2), r(2), r(5), r(5)],
            vec![r(-3), r(-3), r(7), r(7)],
        )
        .unwrap();
        let native = nurbs
            .affine_bilinear_inverse_pcurve(&curve)
            .unwrap()
            .expect("degree-one NURBS uses the same exact Möbius inverse");
        let Some(CurveGeometry2::RationalBezier(native_inverse)) = native.geometry() else {
            panic!("native-domain Möbius inverse remains rational Bézier");
        };
        assert_eq!(native_inverse.degree(), 4);
        let assert_curve_point = |actual: &CurvePoint2, expected: CurvePoint2| {
            assert_eq!(
                compare_reals(actual.x(), expected.x(), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            assert_eq!(
                compare_reals(actual.y(), expected.y(), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
        };
        assert_curve_point(
            (native.start())
                .coordinates()
                .expect("native fixture value"),
            CurvePoint2::new(r(2), r(-2)),
        );
        assert_curve_point(
            (native.end()).coordinates().expect("native fixture value"),
            CurvePoint2::new(r(5), r(2)),
        );
        for parameter in [Real::zero(), q(1, 2), Real::one()] {
            let uv = native
                .point_at(&parameter.clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone();
            assert_points_equal(
                &nurbs
                    .point_at(&Point2::new(uv.x().clone(), uv.y().clone()))
                    .unwrap(),
                &curve.evaluate_real(&parameter).unwrap(),
            );
        }

        let nonseparable = Surface::rational_bezier(
            vec![vec![p(0, 0, 1), p(1, 0, 1)], vec![p(0, 1, 1), p(1, 1, 1)]],
            vec![vec![r(1), r(2)], vec![r(3), r(5)]],
        )
        .unwrap();
        assert!(
            nonseparable
                .affine_bilinear_inverse_pcurve(&curve)
                .unwrap()
                .is_none()
        );
    }

    #[test]
    fn linear_tensor_surfaces_intersect_parallel_planes_in_exact_iso_curves() {
        let rational = Surface::rational_bezier(
            vec![
                vec![p(0, 0, 0), p(1, 2, 0), p(2, 0, 0)],
                vec![p(0, 0, 2), p(1, 2, 2), p(2, 0, 2)],
            ],
            vec![vec![r(1), r(2), r(1)], vec![r(1), r(2), r(1)]],
        )
        .unwrap();
        let middle_plane = Surface::plane(p(0, 0, 1), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(curve) =
            middle_plane.intersect_surface(&rational).unwrap()
        else {
            panic!("linear rational tensor patch must retain its exact middle iso-curve");
        };
        assert_eq!(curve.curve().kind(), Curve3Kind::RationalBezier);
        assert_points_equal(
            &curve.curve().evaluate_real(&q(1, 2)).unwrap(),
            &rational.point_at(&Point2::new(q(1, 2), q(1, 2))).unwrap(),
        );
        assert_eq!(
            curve.second_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(1, 2))
        );
        assert!(matches!(
            rational
                .intersect_surface(&Surface::plane(p(0, 0, 3), Vector3::x(), Vector3::y()).unwrap())
                .unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let nurbs = Surface::nurbs(
            2,
            1,
            vec![
                vec![p(0, 0, 0), p(1, 2, 0), p(2, 0, 0)],
                vec![p(0, 0, 3), p(1, 2, 3), p(2, 0, 3)],
            ],
            vec![vec![r(1), r(2), r(1)], vec![r(1), r(2), r(1)]],
            vec![r(0), r(0), r(0), r(1), r(1), r(1)],
            vec![r(0), r(0), r(1), r(1)],
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(curve) = nurbs
            .intersect_surface(&middle_plane)
            .expect("linear NURBS tensor iso-curve")
        else {
            panic!("linear NURBS tensor patch must retain one exact iso-curve");
        };
        assert_eq!(curve.curve().kind(), Curve3Kind::Nurbs);
        assert_points_equal(
            &curve.curve().evaluate_real(&q(1, 2)).unwrap(),
            &nurbs.point_at(&Point2::new(q(1, 2), q(1, 3))).unwrap(),
        );
        assert_eq!(
            curve.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(1, 3))
        );

        let bilinear = Surface::rational_bezier(
            vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 0, 2), p(2, 0, 2)]],
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(curve) =
            bilinear.intersect_surface(&middle_plane).unwrap()
        else {
            panic!("bilinear tensor must fall through to its exact v-iso section");
        };
        assert_eq!(
            curve.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(1, 2))
        );

        let transverse = Surface::plane(p(1, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            rational.intersect_surface(&transverse).unwrap()
        else {
            panic!("a represented rational-profile plane root must lift to a tensor iso-curve");
        };
        let parameter = q(1, 2);
        let tensor_parameter = section.first_pcurve().point_at(&parameter).unwrap();
        let plane_parameter = section.second_pcurve().point_at(&parameter).unwrap();
        let point = section.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(&point, &rational.point_at(&tensor_parameter).unwrap());
        assert_points_equal(&point, &transverse.point_at(&plane_parameter).unwrap());
        assert_eq!(tensor_parameter, Point2::new(q(1, 2), q(1, 2)));
    }

    #[test]
    fn u_linear_tensor_surfaces_retain_exact_non_isoparametric_plane_sections() {
        let controls = vec![
            vec![p(0, 0, 0), p(2, 0, 0)],
            vec![p(0, 2, 1), p(2, 2, 1)],
            vec![p(0, 2, 2), p(2, 2, 2)],
        ];
        let weights = vec![vec![r(1), r(1)], vec![r(2), r(2)], vec![r(3), r(3)]];
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let rational = Surface::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            plane.intersect_surface(&rational).unwrap()
        else {
            panic!("u-linear rational tensor must retain its exact oblique section");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::RationalBezier);
        let parameter = q(1, 2);
        let tensor_parameter = Point2::new(q(3, 8), parameter.clone());
        assert_eq!(
            section.second_pcurve().point_at(&parameter).unwrap(),
            tensor_parameter
        );
        assert_points_equal(
            &section.curve().evaluate_real(&parameter).unwrap(),
            &rational.point_at(&tensor_parameter).unwrap(),
        );
        let materialized = section.second_pcurve().materialize().unwrap();
        assert_eq!(materialized.curve().family(), CurveFamily2::RationalBezier);
        assert_eq!(
            materialized
                .curve()
                .point_at(&parameter.clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone(),
            CurvePoint2::new(q(3, 8), q(1, 2))
        );

        let nurbs = Surface::nurbs(
            1,
            2,
            controls,
            weights,
            vec![r(0), r(0), r(1), r(1)],
            vec![r(0), r(0), r(0), r(1), r(1), r(1)],
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = nurbs.intersect_surface(&plane).unwrap()
        else {
            panic!("u-linear NURBS tensor must retain its exact oblique section");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::Nurbs);
        assert_eq!(
            section.first_pcurve().point_at(&parameter).unwrap(),
            Point2::new(q(3, 8), q(1, 2))
        );
        assert_points_equal(
            &section.curve().evaluate_real(&parameter).unwrap(),
            &nurbs.point_at(&Point2::new(q(3, 8), q(1, 2))).unwrap(),
        );

        let disjoint = Surface::plane(
            p(5, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        assert!(matches!(
            rational.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let partially_trimmed = Surface::plane(
            p(1, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        assert_eq!(
            rational.intersect_surface(&partially_trimmed).unwrap_err(),
            GeometryError::UnrepresentableParameter,
            "certified algebraic trim roots must not be approximated into Real"
        );
    }

    #[test]
    fn partial_nurbs_tensor_sections_retain_multiple_disjoint_exact_fragments() {
        let controls = vec![
            vec![p(0, 0, 3), p(2, 0, 3)],
            vec![p(0, 1, 1), p(2, 1, 1)],
            vec![p(0, 2, 3), p(2, 2, 3)],
            vec![p(0, 3, 1), p(2, 3, 1)],
            vec![p(0, 4, 3), p(2, 4, 3)],
        ];
        let weights = vec![vec![r(1), r(1)]; controls.len()];
        let (patch, face) = crate::construction::nurbs_patch(
            1,
            1,
            controls,
            weights,
            vec![r(7), r(7), r(11), r(11)],
            vec![r(2), r(2), r(3), r(4), r(5), r(6), r(6)],
        )
        .unwrap();
        let tensor = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(fragments) =
            tensor.intersect_surface(&plane).unwrap()
        else {
            panic!("piecewise-linear graph must retain two disjoint bounded fragments");
        };
        assert_eq!(fragments.len(), 2);
        for fragment in &fragments {
            for parameter in [
                fragment.curve().domain().start(),
                fragment.curve().domain().end(),
            ] {
                let tensor_parameter = fragment.first_pcurve().point_at(parameter).unwrap();
                assert_eq!(tensor_parameter.x, r(7));
                assert_points_equal(
                    &fragment.curve().evaluate_real(parameter).unwrap(),
                    &tensor.point_at(&tensor_parameter).unwrap(),
                );
            }
        }
        let (partitioned, partition) = patch
            .split_face_by_surface_curves(face, &fragments, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(partition.faces.len(), 3);
        assert_eq!(partition.traces.len(), 2);
        assert_eq!(partitioned.counts().faces, 3);
        for trace in &partition.traces {
            assert_eq!(trace.splits.len(), 1);
            assert_eq!(
                partitioned
                    .uses_of_edge(trace.splits[0].open().unwrap().face.edge)
                    .unwrap()
                    .len(),
                2
            );
        }
        let mut reversed_fragments = fragments.clone();
        reversed_fragments.reverse();
        let (reverse_partitioned, _) = patch
            .split_face_by_surface_curves(
                face,
                &reversed_fragments,
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(
            reverse_partitioned.to_json().unwrap(),
            partitioned.to_json().unwrap()
        );
        let partitioned_json = partitioned.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&partitioned_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            partitioned_json
        );

        let (split, record) = patch
            .split_face_by_surface_curve(face, &fragments[0], SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        let graph_use = split
            .edge_use(record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let graph_pcurve = split.pcurve(graph_use.pcurve()).unwrap();
        let Some(CurveGeometry2::Nurbs(graph)) = graph_pcurve.curve().geometry() else {
            panic!("cross-span partial graph must retain one NURBS pcurve");
        };
        let mut forged_controls = graph.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(
            Curve2::try_nurbs(
                graph.degree(),
                forged_controls,
                graph.weights().to_vec(),
                graph.knots().to_vec(),
            )
            .unwrap(),
        );
        let mut edit = split.edit();
        edit.replace_pcurve(graph_use.pcurve(), forged).unwrap();
        assert!(
            edit.commit().is_err(),
            "partial graph validation must reject an endpoint-preserving control forgery"
        );
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn crossing_tensor_surface_curves_are_atomized_by_exact_pcurve_contacts() {
        let controls = vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 2, 0), p(2, 2, 0)]];
        let weights = vec![vec![Real::one(), Real::one()]; 2];
        let (patch, face) = crate::construction::rational_bezier_patch(controls, weights).unwrap();
        let surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let x_plane = Surface::plane(p(1, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let y_plane = Surface::plane(p(0, 1, 0), Vector3::x(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curve(x_trace) =
            surface.intersect_surface(&x_plane).unwrap()
        else {
            panic!("x selection must retain one exact tensor iso-curve");
        };
        let SurfaceSurfaceIntersection::Curve(y_trace) =
            surface.intersect_surface(&y_plane).unwrap()
        else {
            panic!("y selection must retain one exact tensor iso-curve");
        };

        let traces = [*x_trace, *y_trace];
        let (partitioned, partition) = patch
            .split_face_by_surface_curves(face, &traces, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(partition.faces.len(), 4);
        assert_eq!(partition.traces.len(), 2);
        assert_eq!(
            partition
                .traces
                .iter()
                .map(|trace| trace.segments.len())
                .sum::<usize>(),
            3
        );
        assert_eq!(
            partition
                .traces
                .iter()
                .map(|trace| trace.splits.len())
                .sum::<usize>(),
            3
        );
        let shared_crossing_vertices = partition
            .traces
            .iter()
            .flat_map(|trace| &trace.splits)
            .flat_map(|split| {
                let edge = partitioned.edge(split.open().unwrap().face.edge).unwrap();
                [edge.start(), edge.end()]
            })
            .filter(|vertex| {
                let point = partitioned.vertex(*vertex).unwrap().point();
                point3_equal(
                    (point).try_coordinates().unwrap(),
                    &p(1, 1, 0),
                    crate::STRICT_PREDICATES,
                )
                .value()
                    == Some(true)
            })
            .collect::<std::collections::HashSet<_>>();
        assert_eq!(shared_crossing_vertices.len(), 1);

        let (reversed, _) = patch
            .split_face_by_surface_curves(
                face,
                &[traces[1].clone(), traces[0].clone()],
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        let json = partitioned.to_json().unwrap();
        assert_eq!(reversed.to_json().unwrap(), json);
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn closed_planar_surface_curve_authors_identity_shared_outer_and_inner_wires() {
        let (model, solid) = crate::construction::cuboid(p(0, 0, 0), p(10, 10, 10)).unwrap();
        let (face, surface) = model
            .faces()
            .find_map(|(face, record)| {
                let surface = model.surface(record.surface()).unwrap();
                surface.plane_origin().and_then(|origin| {
                    (point3_equal(origin, &p(0, 0, 10), crate::STRICT_PREDICATES).value()
                        == Some(true))
                    .then_some((face, surface))
                })
            })
            .expect("cuboid has a top planar face");
        let SurfaceGeometry::Plane(plane) = &surface.data.geometry else {
            unreachable!("selected surface is planar");
        };
        let loop_curve = Curve3::rational_bezier(
            vec![
                p(5, 3, 10),
                p(8, 3, 10),
                p(8, 7, 10),
                p(5, 7, 10),
                p(2, 7, 10),
                p(2, 3, 10),
                p(5, 3, 10),
            ],
            vec![Real::one(); 7],
        )
        .unwrap();
        let trace = SurfaceIntersectionCurve::new(
            loop_curve.clone(),
            SurfaceIntersectionPcurve::plane_projection(loop_curve.clone(), plane),
            SurfaceIntersectionPcurve::plane_projection(loop_curve.clone(), plane),
        );
        let materialized = trace.first_pcurve().materialize().unwrap();
        let loop_path =
            hypercurve::CurvePath2::try_new(vec![materialized.curve().clone()]).unwrap();
        assert!(matches!(
            crate::error::classified(loop_path.boundary_loop().unwrap().signed_area()).unwrap(),
            Classification::Decided(Some(_))
        ));
        let original_area = model.face_area(face).unwrap();
        let original_volume = model.solid_volume(solid).unwrap();
        let (partitioned, split) = model
            .split_face_by_surface_curve(face, &trace, SurfaceIntersectionOperand::First)
            .unwrap();
        let closed = split.closed().expect("closed trace returns a loop split");
        assert_eq!(closed.first_face, face);
        assert_eq!(partitioned.face(face).unwrap().inner().len(), 1);
        assert_eq!(
            partitioned.face(closed.second_face).unwrap().outer(),
            Some(closed.second_wire)
        );
        for edge in closed.edges {
            assert_eq!(partitioned.uses_of_edge(edge).unwrap().len(), 2);
        }
        assert_eq!(
            compare_reals(
                &(partitioned.face_area(closed.first_face).unwrap()
                    + partitioned.face_area(closed.second_face).unwrap()),
                &original_area,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                &partitioned.solid_volume(solid).unwrap(),
                &original_volume,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        let json = partitioned.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );

        let reversed_circle = loop_curve.reversed().unwrap();
        let reversed_trace = SurfaceIntersectionCurve::new(
            reversed_circle.clone(),
            SurfaceIntersectionPcurve::plane_projection(reversed_circle.clone(), plane),
            SurfaceIntersectionPcurve::plane_projection(reversed_circle.clone(), plane),
        );
        let (reversed, _) = model
            .split_face_by_surface_curve(face, &reversed_trace, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(reversed.to_json().unwrap(), json);
    }

    #[test]
    fn nested_closed_surface_curves_partition_descendants_independent_of_order_and_direction() {
        let (model, solid) = crate::construction::cuboid(p(0, 0, 0), p(10, 10, 10)).unwrap();
        let (face, surface) = model
            .faces()
            .find_map(|(face, record)| {
                let surface = model.surface(record.surface()).unwrap();
                surface.plane_origin().and_then(|origin| {
                    (point3_equal(origin, &p(0, 0, 10), crate::STRICT_PREDICATES).value()
                        == Some(true))
                    .then_some((face, surface))
                })
            })
            .expect("cuboid has a top planar face");
        let SurfaceGeometry::Plane(plane) = &surface.data.geometry else {
            unreachable!("selected surface is planar");
        };
        let trace = |controls: Vec<Point3>| {
            let curve = Curve3::rational_bezier(controls, vec![Real::one(); 7]).unwrap();
            SurfaceIntersectionCurve::new(
                curve.clone(),
                SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane),
                SurfaceIntersectionPcurve::plane_projection(curve, plane),
            )
        };
        let outer = trace(vec![
            p(5, 2, 10),
            p(8, 2, 10),
            p(8, 8, 10),
            p(5, 8, 10),
            p(2, 8, 10),
            p(2, 2, 10),
            p(5, 2, 10),
        ]);
        let inner = trace(vec![
            p(5, 4, 10),
            p(6, 4, 10),
            p(6, 6, 10),
            p(5, 6, 10),
            p(4, 6, 10),
            p(4, 4, 10),
            p(5, 4, 10),
        ]);
        let original_area = model.face_area(face).unwrap();
        let original_volume = model.solid_volume(solid).unwrap();
        let (partitioned, partition) = model
            .split_face_by_surface_curves(
                face,
                &[inner.clone(), outer.clone()],
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(partition.faces.len(), 3);
        assert_eq!(partition.traces.len(), 2);
        assert!(
            partition
                .traces
                .iter()
                .all(|trace| trace.splits.len() == 1 && trace.splits[0].closed().is_some())
        );
        for split in partition.traces.iter().flat_map(|trace| &trace.splits) {
            for edge in split.closed().unwrap().edges {
                assert_eq!(partitioned.uses_of_edge(edge).unwrap().len(), 2);
            }
        }
        let partitioned_area = partition
            .faces
            .iter()
            .map(|face| partitioned.face_area(*face).unwrap())
            .fold(Real::zero(), |sum, area| sum + area);
        assert_eq!(
            compare_reals(&partitioned_area, &original_area, crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                &partitioned.solid_volume(solid).unwrap(),
                &original_volume,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );

        let reverse_trace = |source: &SurfaceIntersectionCurve| {
            let curve = source.curve().reversed().unwrap();
            SurfaceIntersectionCurve::new(
                curve.clone(),
                SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane),
                SurfaceIntersectionPcurve::plane_projection(curve, plane),
            )
        };
        let (reversed, _) = model
            .split_face_by_surface_curves(
                face,
                &[reverse_trace(&outer), reverse_trace(&inner)],
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        let json = partitioned.to_json().unwrap();
        assert_eq!(reversed.to_json().unwrap(), json);
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn boundary_trace_atomizes_a_closed_curve_into_unambiguous_descendant_segments() {
        let (model, solid) = crate::construction::cuboid(p(0, 0, 0), p(10, 10, 10)).unwrap();
        let (face, surface) = model
            .faces()
            .find_map(|(face, record)| {
                let surface = model.surface(record.surface()).unwrap();
                surface.plane_origin().and_then(|origin| {
                    (point3_equal(origin, &p(0, 0, 10), crate::STRICT_PREDICATES).value()
                        == Some(true))
                    .then_some((face, surface))
                })
            })
            .expect("cuboid has a top planar face");
        let SurfaceGeometry::Plane(plane) = &surface.data.geometry else {
            unreachable!("selected surface is planar");
        };
        let retain = |curve: Curve3| {
            SurfaceIntersectionCurve::new(
                curve.clone(),
                SurfaceIntersectionPcurve::plane_projection(curve.clone(), plane),
                SurfaceIntersectionPcurve::plane_projection(curve, plane),
            )
        };
        let line = retain(Curve3::line(p(5, 0, 10), p(5, 10, 10)).unwrap());
        let closed = retain(
            Curve3::rational_bezier(
                vec![
                    p(5, 3, 10),
                    p(8, 3, 10),
                    p(8, 7, 10),
                    p(5, 7, 10),
                    p(2, 7, 10),
                    p(2, 3, 10),
                    p(5, 3, 10),
                ],
                vec![Real::one(); 7],
            )
            .unwrap(),
        );
        let original_area = model.face_area(face).unwrap();
        let original_volume = model.solid_volume(solid).unwrap();
        let (partitioned, partition) = model
            .split_face_by_surface_curves(
                face,
                &[closed.clone(), line.clone()],
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(partition.faces.len(), 4);
        assert_eq!(partition.traces.len(), 2);
        assert_eq!(
            partition
                .traces
                .iter()
                .map(|trace| trace.segments.len())
                .sum::<usize>(),
            3
        );
        assert!(
            partition
                .traces
                .iter()
                .flat_map(|trace| &trace.splits)
                .all(|split| split.open().is_some())
        );
        let partitioned_area = partition
            .faces
            .iter()
            .map(|face| partitioned.face_area(*face).unwrap())
            .fold(Real::zero(), |sum, area| sum + area);
        assert_eq!(
            compare_reals(&partitioned_area, &original_area, crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                &partitioned.solid_volume(solid).unwrap(),
                &original_volume,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );

        let (reversed, _) = model
            .split_face_by_surface_curves(
                face,
                &[line.reversed().unwrap(), closed.reversed().unwrap()],
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        let json = partitioned.to_json().unwrap();
        assert_eq!(reversed.to_json().unwrap(), json);
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn v_linear_tensor_surfaces_retain_noniso_sections_and_native_domains() {
        let controls = vec![
            vec![p(0, 0, 0), p(1, 2, 0), p(2, 2, 0)],
            vec![p(0, 0, 2), p(1, 2, 2), p(2, 2, 2)],
        ];
        let weights = vec![vec![r(1), r(2), r(3)], vec![r(1), r(2), r(3)]];
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let rational = Surface::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            rational.intersect_surface(&plane).unwrap()
        else {
            panic!("v-linear rational tensor must retain its exact graph section");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::RationalBezier);
        assert_eq!(
            section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(3, 8))
        );
        assert_points_equal(
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &rational.point_at(&Point2::new(q(1, 2), q(3, 8))).unwrap(),
        );

        let nurbs = Surface::nurbs(
            2,
            1,
            controls.clone(),
            weights.clone(),
            vec![r(2), r(2), r(2), r(5), r(5), r(5)],
            vec![r(7), r(7), r(11), r(11)],
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = plane.intersect_surface(&nurbs).unwrap()
        else {
            panic!("v-linear NURBS tensor must retain its native graph section");
        };
        assert_eq!(section.curve().domain().start(), &r(2));
        assert_eq!(section.curve().domain().end(), &r(5));
        assert_eq!(
            section.second_pcurve().point_at(&q(7, 2)).unwrap(),
            Point2::new(q(7, 2), q(17, 2))
        );
        let materialized = section.second_pcurve().materialize().unwrap();
        assert_eq!(
            materialized.correspondence().affine_coefficients(),
            Some((&r(3), &r(2)))
        );
        assert_eq!(
            materialized
                .curve()
                .point_at(&q(1, 2).clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone(),
            CurvePoint2::new(q(7, 2), q(17, 2))
        );

        let (rational_patch, rational_face) =
            crate::construction::rational_bezier_patch(controls.clone(), weights.clone()).unwrap();
        let rational_surface = rational_patch
            .surface(rational_patch.face(rational_face).unwrap().surface())
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(rational_section) =
            rational_surface.intersect_surface(&plane).unwrap()
        else {
            panic!("v-linear rational patch must retain its graph section");
        };
        let (rational_split, _) = rational_patch
            .split_face_by_surface_curve(
                rational_face,
                &rational_section,
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(rational_split.counts().faces, 2);
        let rational_json = rational_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&rational_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            rational_json
        );

        let (nurbs_patch, nurbs_face) = crate::construction::nurbs_patch(
            2,
            1,
            controls,
            weights,
            vec![r(2), r(2), r(2), r(5), r(5), r(5)],
            vec![r(7), r(7), r(11), r(11)],
        )
        .unwrap();
        let nurbs_surface = nurbs_patch
            .surface(nurbs_patch.face(nurbs_face).unwrap().surface())
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(nurbs_section) =
            nurbs_surface.intersect_surface(&plane).unwrap()
        else {
            panic!("v-linear NURBS patch must retain its native graph section");
        };
        let (nurbs_split, _) = nurbs_patch
            .split_face_by_surface_curve(
                nurbs_face,
                &nurbs_section,
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(nurbs_split.counts().faces, 2);
        let nurbs_json = nurbs_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&nurbs_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            nurbs_json
        );
    }

    #[test]
    fn rational_tensor_graph_sections_split_and_revalidate_trimmed_topology() {
        let controls = vec![
            vec![p(0, 0, 0), p(2, 0, 0)],
            vec![p(0, 2, 1), p(2, 2, 1)],
            vec![p(0, 2, 2), p(2, 2, 2)],
        ];
        let weights = vec![vec![r(1), r(1)], vec![r(2), r(2)], vec![r(3), r(3)]];
        let (patch, face) = crate::construction::rational_bezier_patch(controls, weights).unwrap();
        let surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = surface.intersect_surface(&plane).unwrap()
        else {
            panic!("translation tensor must retain one exact graph section");
        };
        let (split, record) = patch
            .split_face_by_surface_curve(face, &section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        assert_eq!(record.first_face(), face);
        let graph_use = split
            .edge_use(record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let graph_pcurve = split.pcurve(graph_use.pcurve()).unwrap();
        let Some(CurveGeometry2::RationalBezier(graph)) = graph_pcurve.curve().geometry() else {
            panic!("split tensor section must retain one rational graph pcurve");
        };
        let mut forged_controls = graph.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(Curve2::from(
            RationalBezier2::try_new(forged_controls, graph.weights().to_vec()).unwrap(),
        ));
        let mut edit = split.edit();
        edit.replace_pcurve(graph_use.pcurve(), forged).unwrap();
        assert!(
            edit.commit().is_err(),
            "endpoint-preserving graph forgery must fail full control-net validation"
        );
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn polynomial_bilinear_plane_sections_are_exact_clipped_and_replayable() {
        let controls = vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 2, 0), p(2, 2, 1)]];
        let weights = vec![vec![r(1), r(1)], vec![r(1), r(1)]];
        let surface = Surface::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let section_plane = Surface::plane(
            p(1, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            surface.intersect_surface(&section_plane).unwrap()
        else {
            panic!("polynomial bilinear patch must retain one exact rational section");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::RationalBezier);
        assert_eq!(
            section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 3), q(1, 2))
        );
        assert_points_equal(
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &Point3::new(q(2, 3), r(1), q(1, 6)),
        );
        // Both sides are rational quartics. Nine distinct exact parameters
        // certify the complete cross-multiplied degree-eight identity
        // independently of the construction's control-net arithmetic.
        for numerator in 0_i64..=8 {
            let parameter = q(numerator, 8);
            let surface_parameter = section.first_pcurve().point_at(&parameter).unwrap();
            assert_points_equal(
                &section.curve().evaluate_real(&parameter).unwrap(),
                &surface
                    .point_at(&Point2::new(
                        surface_parameter.x.clone(),
                        surface_parameter.y.clone(),
                    ))
                    .unwrap(),
            );
        }

        let SurfaceSurfaceIntersection::Curve(swapped) =
            section_plane.intersect_surface(&surface).unwrap()
        else {
            panic!("operand reversal must retain the same exact rational section");
        };
        assert_eq!(
            swapped.second_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 3), q(1, 2))
        );
        assert_points_equal(
            &swapped.curve().evaluate_real(&q(1, 2)).unwrap(),
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
        );

        let u_graph_plane = Surface::plane(
            p(0, 1, 0),
            Vector3::x(),
            Vector3::from_xyz(r(0), r(2), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(u_graph_section) =
            surface.intersect_surface(&u_graph_plane).unwrap()
        else {
            panic!("bilinear plane section must solve through either parameter axis");
        };
        assert_eq!(
            u_graph_section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(1, 3))
        );
        assert_points_equal(
            &u_graph_section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &Point3::new(r(1), q(2, 3), q(1, 6)),
        );

        let clipping_plane = Surface::plane(
            p(3, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(clipped) =
            surface.intersect_surface(&clipping_plane).unwrap()
        else {
            panic!("rectangle clipping must retain the represented section fragment");
        };
        assert_eq!(clipped.curve().domain().start(), &r(0));
        assert_eq!(clipped.curve().domain().end(), &r(1));
        assert_eq!(
            clipped.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), q(1, 2))
        );
        assert_eq!(
            clipped.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(3, 4), r(1))
        );
        assert_points_equal(
            &clipped.curve().evaluate_real(&r(0)).unwrap(),
            &Point3::new(r(2), r(1), q(1, 2)),
        );
        assert_points_equal(
            &clipped.curve().evaluate_real(&r(1)).unwrap(),
            &Point3::new(q(3, 2), r(2), q(3, 4)),
        );

        let disjoint_plane = Surface::plane(
            p(5, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        assert!(matches!(
            surface.intersect_surface(&disjoint_plane).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let pole_plane =
            Surface::plane(Point3::new(r(0), r(0), q(1, 4)), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(pole_branch) =
            surface.intersect_surface(&pole_plane).unwrap()
        else {
            panic!("retained polynomial bilinear pole branch must be exact");
        };
        assert_eq!(
            pole_branch.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), q(1, 4))
        );
        assert_eq!(
            pole_branch.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(1, 4), r(1))
        );
        assert_points_equal(
            &pole_branch.curve().evaluate_real(&r(0)).unwrap(),
            &Point3::new(r(2), q(1, 2), q(1, 4)),
        );
        assert_points_equal(
            &pole_branch.curve().evaluate_real(&r(1)).unwrap(),
            &Point3::new(q(1, 2), r(2), q(1, 4)),
        );

        let off_domain_pole_surface = Surface::rational_bezier(
            vec![
                vec![
                    Point3::new(r(0), r(0), q(-3, 2)),
                    Point3::new(r(2), r(0), r(-2)),
                ],
                vec![p(0, 2, -1), p(2, 2, 1)],
            ],
            vec![vec![r(2), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        let coordinate_plane =
            Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(pole_clipped) = off_domain_pole_surface
            .intersect_surface(&coordinate_plane)
            .unwrap()
        else {
            panic!("UV clipping must precede weighted spatial composition");
        };
        assert_eq!(
            pole_clipped.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), q(2, 3))
        );
        assert_eq!(
            pole_clipped.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(1, 2), r(1))
        );
        assert_points_equal(
            &pole_clipped.curve().evaluate_real(&r(0)).unwrap(),
            &Point3::new(r(2), q(4, 3), r(0)),
        );
        assert_points_equal(
            &pole_clipped.curve().evaluate_real(&r(1)).unwrap(),
            &p(1, 2, 0),
        );

        let translation = Matrix4::affine_translation([r(3), r(-2), r(5)]);
        let translated_surface = surface
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let translated_plane = section_plane
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(translated) = translated_surface
            .intersect_surface(&translated_plane)
            .unwrap()
        else {
            panic!("translated bilinear section must retain its exact construction");
        };
        let expected =
            section.curve().evaluate_real(&q(1, 2)).unwrap() + Vector3::from_xyz(r(3), r(-2), r(5));
        assert_points_equal(
            &translated.curve().evaluate_real(&q(1, 2)).unwrap(),
            &expected,
        );

        let (patch, face) =
            crate::construction::rational_bezier_patch(controls.clone(), weights.clone()).unwrap();
        let patch_surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let SurfaceSurfaceIntersection::Curve(patch_section) =
            patch_surface.intersect_surface(&section_plane).unwrap()
        else {
            panic!("bilinear patch must retain its exact graph section");
        };
        let (split, record) = patch
            .split_face_by_surface_curve(face, &patch_section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        let graph_use = split
            .edge_use(record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let graph_pcurve = split.pcurve(graph_use.pcurve()).unwrap();
        let Some(CurveGeometry2::RationalBezier(graph)) = graph_pcurve.curve().geometry() else {
            panic!("bilinear split must retain its exact rational graph pcurve");
        };
        let mut forged_controls = graph.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(Curve2::from(
            RationalBezier2::try_new(forged_controls, graph.weights().to_vec()).unwrap(),
        ));
        let mut edit = split.edit();
        edit.replace_pcurve(graph_use.pcurve(), forged).unwrap();
        assert!(
            edit.commit().is_err(),
            "endpoint-preserving bilinear graph forgery must fail full control-net validation"
        );
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );

        let SurfaceSurfaceIntersection::Curve(partial_section) =
            patch_surface.intersect_surface(&clipping_plane).unwrap()
        else {
            panic!("bilinear patch must retain its exact clipped graph section");
        };
        let (partial_split, _) = patch
            .split_face_by_surface_curve(face, &partial_section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(partial_split.counts().faces, 2);
        let partial_json = partial_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&partial_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            partial_json
        );
    }

    #[test]
    fn rational_bilinear_plane_sections_preserve_weighted_homogeneous_images() {
        let controls = vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 2, 0), p(2, 2, 1)]];
        let weights = vec![vec![r(1), r(2)], vec![r(3), r(4)]];
        let surface = Surface::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let section_plane = Surface::plane(
            p(1, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            surface.intersect_surface(&section_plane).unwrap()
        else {
            panic!("weighted bilinear patch must retain one exact rational section");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::RationalBezier);
        assert_eq!(
            section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(2, 9), q(1, 2))
        );
        assert_points_equal(
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &Point3::new(q(3, 5), q(29, 20), q(1, 5)),
        );
        // This independently certifies the weighted rational-quartic identity
        // rather than trusting the shared homogeneous construction helper.
        for numerator in 0_i64..=8 {
            let parameter = q(numerator, 8);
            let surface_parameter = section.first_pcurve().point_at(&parameter).unwrap();
            assert_points_equal(
                &section.curve().evaluate_real(&parameter).unwrap(),
                &surface
                    .point_at(&Point2::new(
                        surface_parameter.x.clone(),
                        surface_parameter.y.clone(),
                    ))
                    .unwrap(),
            );
        }

        let SurfaceSurfaceIntersection::Curve(swapped) =
            section_plane.intersect_surface(&surface).unwrap()
        else {
            panic!("weighted bilinear section must survive operand reversal");
        };
        assert_eq!(
            swapped.second_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(2, 9), q(1, 2))
        );
        assert_points_equal(
            &swapped.curve().evaluate_real(&q(1, 2)).unwrap(),
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
        );

        let nurbs = Surface::nurbs(
            1,
            1,
            controls.clone(),
            weights.clone(),
            vec![r(2), r(2), r(5), r(5)],
            vec![r(-3), r(-3), r(7), r(7)],
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(native_section) =
            nurbs.intersect_surface(&section_plane).unwrap()
        else {
            panic!("single-span NURBS must retain the equivalent weighted bilinear section");
        };
        assert_eq!(
            native_section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(8, 3), r(2))
        );
        assert_points_equal(
            &native_section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &section.curve().evaluate_real(&q(1, 2)).unwrap(),
        );
        let SurfaceSurfaceIntersection::Curve(native_swapped) =
            section_plane.intersect_surface(&nurbs).unwrap()
        else {
            panic!("native-domain weighted bilinear section must survive operand reversal");
        };
        assert_eq!(
            native_swapped.second_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(8, 3), r(2))
        );
        for numerator in 0_i64..=8 {
            let parameter = q(numerator, 8);
            let surface_parameter = native_section.first_pcurve().point_at(&parameter).unwrap();
            assert_points_equal(
                &native_section.curve().evaluate_real(&parameter).unwrap(),
                &nurbs
                    .point_at(&Point2::new(
                        surface_parameter.x.clone(),
                        surface_parameter.y.clone(),
                    ))
                    .unwrap(),
            );
        }

        let u_graph_plane = Surface::plane(
            p(0, 1, 0),
            Vector3::x(),
            Vector3::from_xyz(r(0), r(2), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(u_graph_section) =
            surface.intersect_surface(&u_graph_plane).unwrap()
        else {
            panic!("weighted bilinear section must solve through either parameter axis");
        };
        assert_eq!(
            u_graph_section.first_pcurve().point_at(&q(1, 2)).unwrap(),
            Point2::new(q(1, 2), q(1, 6))
        );
        assert_points_equal(
            &u_graph_section.curve().evaluate_real(&q(1, 2)).unwrap(),
            &Point3::new(q(14, 11), q(7, 11), q(2, 11)),
        );

        let clipping_plane = Surface::plane(
            Point3::new(q(5, 2), r(0), r(0)),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(clipped) =
            surface.intersect_surface(&clipping_plane).unwrap()
        else {
            panic!("weighted bilinear section must retain its represented rectangle clip");
        };
        assert_eq!(clipped.curve().domain().start(), &r(0));
        assert_eq!(clipped.curve().domain().end(), &r(1));
        assert_eq!(
            clipped.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), q(1, 7))
        );
        assert_eq!(
            clipped.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(5, 9), r(1))
        );
        assert_points_equal(
            &clipped.curve().evaluate_real(&r(0)).unwrap(),
            &Point3::new(r(2), q(1, 2), q(1, 4)),
        );
        assert_points_equal(
            &clipped.curve().evaluate_real(&r(1)).unwrap(),
            &Point3::new(q(5, 4), r(2), q(5, 8)),
        );
        let SurfaceSurfaceIntersection::Curve(native_clipped) =
            nurbs.intersect_surface(&clipping_plane).unwrap()
        else {
            panic!("single-span NURBS must retain its clipped weighted section");
        };
        assert_eq!(
            native_clipped.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(5), q(-11, 7))
        );
        assert_eq!(
            native_clipped.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(11, 3), r(7))
        );
        for parameter in [Real::zero(), q(1, 2), Real::one()] {
            let uv = native_clipped.first_pcurve().point_at(&parameter).unwrap();
            assert_points_equal(
                &native_clipped.curve().evaluate_real(&parameter).unwrap(),
                &nurbs.point_at(&Point2::new(uv.x, uv.y)).unwrap(),
            );
        }

        let boundary_plane = Surface::plane(Point3::origin(), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curve(native_boundary) =
            nurbs.intersect_surface(&boundary_plane).unwrap()
        else {
            panic!("single-span NURBS must retain its native-domain boundary iso-line");
        };
        assert_eq!(
            native_boundary.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(2), r(-3))
        );
        assert_eq!(
            native_boundary.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(2), r(7))
        );

        let disjoint_plane = Surface::plane(
            p(5, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(2), r(0), r(-1)),
        )
        .unwrap();
        assert!(matches!(
            surface.intersect_surface(&disjoint_plane).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let pole_plane =
            Surface::plane(Point3::new(r(0), r(0), q(1, 4)), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(pole_branch) =
            surface.intersect_surface(&pole_plane).unwrap()
        else {
            panic!("retained weighted bilinear pole branch must be exact");
        };
        assert_eq!(
            pole_branch.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), q(1, 7))
        );
        assert_eq!(
            pole_branch.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(1, 5), r(1))
        );
        assert_points_equal(
            &pole_branch.curve().evaluate_real(&r(0)).unwrap(),
            &Point3::new(r(2), q(1, 2), q(1, 4)),
        );
        assert_points_equal(
            &pole_branch.curve().evaluate_real(&r(1)).unwrap(),
            &Point3::new(q(1, 2), r(2), q(1, 4)),
        );

        let translation = Matrix4::affine_translation([r(3), r(-2), r(5)]);
        let translated_surface = surface
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let translated_plane = section_plane
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(translated) = translated_surface
            .intersect_surface(&translated_plane)
            .unwrap()
        else {
            panic!("translated weighted bilinear section must remain exact");
        };
        let expected =
            section.curve().evaluate_real(&q(1, 2)).unwrap() + Vector3::from_xyz(r(3), r(-2), r(5));
        assert_points_equal(
            &translated.curve().evaluate_real(&q(1, 2)).unwrap(),
            &expected,
        );

        let (patch, face) =
            crate::construction::rational_bezier_patch(controls.clone(), weights.clone()).unwrap();
        let patch_surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let SurfaceSurfaceIntersection::Curve(patch_section) =
            patch_surface.intersect_surface(&section_plane).unwrap()
        else {
            panic!("weighted bilinear patch must retain its exact graph section");
        };
        let (split, record) = patch
            .split_face_by_surface_curve(face, &patch_section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        let graph_use = split
            .edge_use(record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let graph_pcurve = split.pcurve(graph_use.pcurve()).unwrap();
        let Some(CurveGeometry2::RationalBezier(graph)) = graph_pcurve.curve().geometry() else {
            panic!("weighted bilinear split must retain its rational graph pcurve");
        };
        let mut forged_controls = graph.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(Curve2::from(
            RationalBezier2::try_new(forged_controls, graph.weights().to_vec()).unwrap(),
        ));
        let mut edit = split.edit();
        edit.replace_pcurve(graph_use.pcurve(), forged).unwrap();
        assert!(
            edit.commit().is_err(),
            "weighted graph forgery must fail complete homogeneous image validation"
        );
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );

        let SurfaceSurfaceIntersection::Curve(partial_section) =
            patch_surface.intersect_surface(&clipping_plane).unwrap()
        else {
            panic!("weighted bilinear patch must retain its exact clipped graph section");
        };
        let (partial_split, _) = patch
            .split_face_by_surface_curve(face, &partial_section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(partial_split.counts().faces, 2);
        let partial_json = partial_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&partial_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            partial_json
        );

        let (native_patch, native_face) = crate::construction::nurbs_patch(
            1,
            1,
            controls,
            weights,
            vec![r(2), r(2), r(5), r(5)],
            vec![r(-3), r(-3), r(7), r(7)],
        )
        .unwrap();
        let native_patch_surface = native_patch
            .surface(native_patch.face(native_face).unwrap().surface())
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(native_patch_section) = native_patch_surface
            .intersect_surface(&section_plane)
            .unwrap()
        else {
            panic!("native NURBS patch must retain its exact weighted graph section");
        };
        let (native_split, native_record) = native_patch
            .split_face_by_surface_curve(
                native_face,
                &native_patch_section,
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(native_split.counts().faces, 2);
        let native_graph_use = native_split
            .edge_use(native_record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let native_graph = native_split
            .pcurve(native_graph_use.pcurve())
            .unwrap()
            .clone();
        let Some(CurveGeometry2::RationalBezier(native_graph_curve)) =
            native_graph.curve().geometry()
        else {
            panic!("native NURBS split must retain its rational graph pcurve");
        };
        let mut forged_controls = native_graph_curve.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(Curve2::from(
            RationalBezier2::try_new(forged_controls, native_graph_curve.weights().to_vec())
                .unwrap(),
        ));
        let mut edit = native_split.edit();
        edit.replace_pcurve(native_graph_use.pcurve(), forged)
            .unwrap();
        assert!(
            edit.commit().is_err(),
            "native-domain graph forgery must fail complete homogeneous image validation"
        );
        let json = native_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn bilinear_poles_partition_into_exact_bounded_branches() {
        let controls = vec![
            vec![
                Point3::new(r(0), r(0), q(3, 16)),
                Point3::new(r(2), r(0), q(-5, 16)),
            ],
            vec![
                Point3::new(r(0), r(2), q(-5, 16)),
                Point3::new(r(2), r(2), q(3, 16)),
            ],
        ];
        let weights = vec![vec![r(1), r(1)], vec![r(1), r(1)]];
        let surface = Surface::rational_bezier(controls.clone(), weights.clone()).unwrap();
        let plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curves(branches) =
            surface.intersect_surface(&plane).unwrap()
        else {
            panic!("checkerboard bilinear section must retain two bounded pole branches");
        };
        assert_eq!(branches.len(), 2);
        for (branch, expected_start, expected_end, spatial_start, spatial_end) in [
            (
                &branches[0],
                Point2::new(q(3, 8), r(0)),
                Point2::new(r(0), q(3, 8)),
                Point3::new(q(3, 4), r(0), r(0)),
                Point3::new(r(0), q(3, 4), r(0)),
            ),
            (
                &branches[1],
                Point2::new(r(1), q(5, 8)),
                Point2::new(q(5, 8), r(1)),
                Point3::new(r(2), q(5, 4), r(0)),
                Point3::new(q(5, 4), r(2), r(0)),
            ),
        ] {
            assert_eq!(
                branch.first_pcurve().point_at(&r(0)).unwrap(),
                expected_start
            );
            assert_eq!(branch.first_pcurve().point_at(&r(1)).unwrap(), expected_end);
            assert_points_equal(
                &branch.curve().evaluate_real(&r(0)).unwrap(),
                &spatial_start,
            );
            assert_points_equal(&branch.curve().evaluate_real(&r(1)).unwrap(), &spatial_end);
            for numerator in 0_i64..=8 {
                let parameter = q(numerator, 8);
                let surface_parameter = branch.first_pcurve().point_at(&parameter).unwrap();
                assert_points_equal(
                    &branch.curve().evaluate_real(&parameter).unwrap(),
                    &surface.point_at(&surface_parameter).unwrap(),
                );
            }
        }

        let SurfaceSurfaceIntersection::Curves(swapped) =
            plane.intersect_surface(&surface).unwrap()
        else {
            panic!("pole branches must survive operand reversal");
        };
        assert_eq!(swapped.len(), 2);
        for (original, reversed_operands) in branches.iter().zip(&swapped) {
            assert_eq!(
                original.first_pcurve().point_at(&q(1, 2)).unwrap(),
                reversed_operands
                    .second_pcurve()
                    .point_at(&q(1, 2))
                    .unwrap()
            );
            assert_points_equal(
                &original.curve().evaluate_real(&q(1, 2)).unwrap(),
                &reversed_operands.curve().evaluate_real(&q(1, 2)).unwrap(),
            );
        }

        let endpoint_pole_surface = Surface::rational_bezier(
            vec![vec![p(0, 0, 1), p(2, 0, -1)], vec![p(0, 2, 1), p(2, 2, 1)]],
            weights.clone(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(endpoint_branch) =
            endpoint_pole_surface.intersect_surface(&plane).unwrap()
        else {
            panic!("a branch leaving the patch before an endpoint pole must be retained");
        };
        assert_eq!(
            endpoint_branch.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(q(1, 2), r(0))
        );
        assert_eq!(
            endpoint_branch.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(1), q(1, 2))
        );

        let factorized_controls = vec![
            vec![
                Point3::new(r(0), r(0), q(1, 4)),
                Point3::new(r(2), r(0), q(-1, 4)),
            ],
            vec![
                Point3::new(r(0), r(2), q(-1, 4)),
                Point3::new(r(2), r(2), q(1, 4)),
            ],
        ];
        let factorized =
            Surface::rational_bezier(factorized_controls.clone(), weights.clone()).unwrap();
        let SurfaceSurfaceIntersection::Curves(factorized_lines) =
            factorized.intersect_surface(&plane).unwrap()
        else {
            panic!("factorized bilinear relation must retain both exact iso-lines");
        };
        assert_eq!(factorized_lines.len(), 2);
        assert_eq!(
            factorized_lines[0].first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(0), q(1, 2))
        );
        assert_eq!(
            factorized_lines[0].first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(1), q(1, 2))
        );
        assert_eq!(
            factorized_lines[1].first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(q(1, 2), r(0))
        );
        assert_eq!(
            factorized_lines[1].first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(q(1, 2), r(1))
        );
        let (factorized_patch, factorized_face) =
            crate::construction::rational_bezier_patch(factorized_controls, weights.clone())
                .unwrap();
        let (factorized_partition, factorized_record) = factorized_patch
            .split_face_by_surface_curves(
                factorized_face,
                &factorized_lines,
                SurfaceIntersectionOperand::First,
            )
            .unwrap();
        assert_eq!(factorized_record.faces.len(), 4);
        assert_eq!(factorized_partition.counts().faces, 4);
        let factorized_json = factorized_partition.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&factorized_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            factorized_json
        );

        let boundary_surface = |heights: [[i32; 2]; 2]| {
            Surface::rational_bezier(
                vec![
                    vec![p(0, 0, heights[0][0]), p(2, 0, heights[0][1])],
                    vec![p(0, 2, heights[1][0]), p(2, 2, heights[1][1])],
                ],
                vec![vec![r(1), r(1)], vec![r(1), r(1)]],
            )
            .unwrap()
        };
        let SurfaceSurfaceIntersection::Point(single_corner) = boundary_surface([[0, 1], [1, 1]])
            .intersect_surface(&plane)
            .unwrap()
        else {
            panic!("one zero Bernstein corner must be one exact point");
        };
        assert_eq!(*single_corner, p(0, 0, 0));

        let opposite_corners = boundary_surface([[0, 1], [1, 0]]);
        let SurfaceSurfaceIntersection::Points(points) =
            opposite_corners.intersect_surface(&plane).unwrap()
        else {
            panic!("opposite zero Bernstein corners must be two exact points");
        };
        assert_eq!(points, vec![p(0, 0, 0), p(2, 2, 0)]);
        let SurfaceSurfaceIntersection::Points(swapped_points) =
            plane.intersect_surface(&opposite_corners).unwrap()
        else {
            panic!("multiple exact points must survive operand reversal");
        };
        assert_eq!(swapped_points, points);

        let SurfaceSurfaceIntersection::Curve(boundary_edge) = boundary_surface([[0, 0], [1, 1]])
            .intersect_surface(&plane)
            .unwrap()
        else {
            panic!("two adjacent zero Bernstein corners must retain their boundary iso-line");
        };
        assert_eq!(
            boundary_edge.first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(0), r(0))
        );
        assert_eq!(
            boundary_edge.first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(1), r(0))
        );

        let SurfaceSurfaceIntersection::Curves(boundary_pair) = boundary_surface([[1, 0], [0, 0]])
            .intersect_surface(&plane)
            .unwrap()
        else {
            panic!("three zero Bernstein corners must retain both opposite boundary iso-lines");
        };
        assert_eq!(boundary_pair.len(), 2);
        assert_eq!(
            boundary_pair[0].first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(0), r(1))
        );
        assert_eq!(
            boundary_pair[0].first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(1), r(1))
        );
        assert_eq!(
            boundary_pair[1].first_pcurve().point_at(&r(0)).unwrap(),
            Point2::new(r(1), r(0))
        );
        assert_eq!(
            boundary_pair[1].first_pcurve().point_at(&r(1)).unwrap(),
            Point2::new(r(1), r(1))
        );

        let planar_controls = vec![vec![p(0, 0, 0), p(2, 0, 0)], vec![p(0, 2, 0), p(2, 2, 0)]];
        let planar_weights = vec![vec![r(1), r(2)], vec![r(3), r(4)]];
        let planar = Surface::rational_bezier(planar_controls.clone(), planar_weights).unwrap();
        assert!(matches!(
            plane.intersect_surface(&planar).unwrap(),
            SurfaceSurfaceIntersection::ContainedSurface(SurfaceIntersectionOperand::Second)
        ));
        assert!(matches!(
            planar.intersect_surface(&plane).unwrap(),
            SurfaceSurfaceIntersection::ContainedSurface(SurfaceIntersectionOperand::First)
        ));
        let containment_translation = Matrix4::affine_translation([r(3), r(-2), r(5)]);
        assert!(matches!(
            plane
                .transformed(&TransformMetric::new(&containment_translation), false)
                .unwrap()
                .intersect_surface(
                    &planar
                        .transformed(&TransformMetric::new(&containment_translation), false)
                        .unwrap()
                )
                .unwrap(),
            SurfaceSurfaceIntersection::ContainedSurface(SurfaceIntersectionOperand::Second)
        ));

        let (planar_patch, planar_face) = crate::construction::rational_bezier_patch(
            planar_controls,
            vec![vec![r(1), r(1)], vec![r(1), r(1)]],
        )
        .unwrap();
        let patch_surface = planar_patch
            .surface(planar_patch.face(planar_face).unwrap().surface())
            .unwrap();
        let (cube, cube_solid) = crate::construction::cuboid(p(-1, -1, 0), p(3, 3, 1)).unwrap();
        let cube_faces = cube
            .shell(cube.solid(cube_solid).unwrap().outer())
            .unwrap()
            .faces();
        let containing_face = cube_faces
            .iter()
            .copied()
            .find(|cube_face| {
                let cube_surface = cube
                    .surface(cube.face(*cube_face).unwrap().surface())
                    .unwrap();
                matches!(
                    patch_surface.intersect_surface(cube_surface),
                    Ok(SurfaceSurfaceIntersection::ContainedSurface(
                        SurfaceIntersectionOperand::First
                    ))
                )
            })
            .expect("one cuboid cap plane must contain the complete tensor carrier");
        let face_pair = crate::boolean_kernel::intersect_faces(
            &planar_patch,
            planar_face,
            &cube,
            containing_face,
        )
        .unwrap()
        .expect("contained tensor/plane carriers must retain an exact face relation");
        assert!(matches!(
            face_pair.relation(),
            crate::FacePairRelation::Exact(SurfaceSurfaceIntersection::ContainedSurface(
                SurfaceIntersectionOperand::First
            ))
        ));
        let crate::FacePairTrim::SurfaceRegion {
            parameterized_on: SurfaceIntersectionOperand::Second,
            region,
            covers_contained_face,
        } = face_pair.trim()
        else {
            panic!("contained tensor/plane faces must retain an exact two-dimensional trim");
        };
        assert!(!region.is_empty());
        assert!(*covers_contained_face);
        assert!(matches!(
            crate::error::classified(region.loop_role_counts()).unwrap(),
            hypercurve::Classification::Decided((1, 0))
        ));
        let complete_plane_traces = crate::boolean_kernel::contained_face_boundary_traces_on_plane(
            &planar_patch,
            planar_face,
            &cube,
            containing_face,
        )
        .unwrap()
        .expect("represented contained-face boundary must transfer to plane traces");
        assert_eq!(complete_plane_traces.len(), 4);
        let (partitioned_cube, complete_partition) = cube
            .split_face_by_curves(containing_face, &complete_plane_traces)
            .unwrap();
        assert_eq!(complete_partition.faces.len(), 9);
        assert_eq!(partitioned_cube.counts().faces, cube.counts().faces + 8);

        let partial_points = [
            CurvePoint2::new(r(1), r(-1)),
            CurvePoint2::new(r(3), r(-1)),
            CurvePoint2::new(r(3), r(3)),
            CurvePoint2::new(r(1), r(3)),
        ];
        let partial_outline = hypercurve::CurvePath2::try_new(
            (0..4)
                .map(|index| {
                    Curve2::from(
                        LineSeg2::try_new(
                            partial_points[index].clone(),
                            partial_points[(index + 1) % 4].clone(),
                        )
                        .unwrap(),
                    )
                })
                .collect(),
        )
        .unwrap();
        let (partial_plane, partial_face) = crate::construction::planar_face(
            &partial_outline,
            &[],
            p(0, 0, 0),
            Vector3::from_xyz(r(1), r(0), r(0)),
            Vector3::from_xyz(r(0), r(1), r(0)),
        )
        .unwrap();
        let partial_plane_traces = crate::boolean_kernel::contained_face_boundary_traces_on_plane(
            &planar_patch,
            planar_face,
            &partial_plane,
            partial_face,
        )
        .unwrap()
        .expect("represented partial contained-face boundary must transfer to plane traces");
        assert_eq!(partial_plane_traces.len(), 3);
        let (partitioned_partial_plane, partial_partition) = partial_plane
            .split_face_by_curves(partial_face, &partial_plane_traces)
            .unwrap();
        assert_eq!(partial_partition.faces.len(), 6);
        assert_eq!(
            partitioned_partial_plane.counts().faces,
            partial_plane.counts().faces + 5
        );
        for (pair, expected_parameter_operand) in [
            (
                crate::boolean_kernel::intersect_faces(
                    &planar_patch,
                    planar_face,
                    &partial_plane,
                    partial_face,
                )
                .unwrap()
                .unwrap(),
                SurfaceIntersectionOperand::Second,
            ),
            (
                crate::boolean_kernel::intersect_faces(
                    &partial_plane,
                    partial_face,
                    &planar_patch,
                    planar_face,
                )
                .unwrap()
                .unwrap(),
                SurfaceIntersectionOperand::First,
            ),
        ] {
            let crate::FacePairTrim::SurfaceRegion {
                parameterized_on,
                region,
                covers_contained_face,
            } = pair.trim()
            else {
                panic!("partial tensor/plane overlap must retain its exact region");
            };
            assert_eq!(*parameterized_on, expected_parameter_operand);
            assert!(!covers_contained_face);
            assert!(matches!(
                region
                    .filled_area()
                    .unwrap()
                    ,
                Some(area)
                    if compare_reals(&area, &r(2), crate::STRICT_PREDICATES).value()
                        == Some(Ordering::Equal)
            ));
        }

        let rectangle_path = |min_x: i32, min_y: i32, max_x: i32, max_y: i32| {
            let points = [
                CurvePoint2::new(r(min_x), r(min_y)),
                CurvePoint2::new(r(max_x), r(min_y)),
                CurvePoint2::new(r(max_x), r(max_y)),
                CurvePoint2::new(r(min_x), r(max_y)),
            ];
            hypercurve::CurvePath2::try_new(
                (0..4)
                    .map(|index| {
                        Curve2::from(
                            LineSeg2::try_new(
                                points[index].clone(),
                                points[(index + 1) % 4].clone(),
                            )
                            .unwrap(),
                        )
                    })
                    .collect(),
            )
            .unwrap()
        };
        let excluded_outer = rectangle_path(-2, -2, 4, 4);
        let excluded_hole = rectangle_path(-1, -1, 3, 3);
        let (excluded_plane, excluded_face) = crate::construction::planar_face(
            &excluded_outer,
            &[excluded_hole],
            p(0, 0, 0),
            Vector3::from_xyz(r(1), r(0), r(0)),
            Vector3::from_xyz(r(0), r(1), r(0)),
        )
        .unwrap();
        let excluded = crate::boolean_kernel::intersect_faces(
            &planar_patch,
            planar_face,
            &excluded_plane,
            excluded_face,
        )
        .unwrap()
        .expect("overlapping face bounds must reach exact contained-surface trimming");
        assert!(matches!(excluded.trim(), crate::FacePairTrim::NoContact));

        let translation = Matrix4::affine_translation([r(3), r(-2), r(5)]);
        let translated_surface = surface
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let translated_plane = plane
            .transformed(&TransformMetric::new(&translation), false)
            .unwrap();
        let SurfaceSurfaceIntersection::Curves(translated) = translated_surface
            .intersect_surface(&translated_plane)
            .unwrap()
        else {
            panic!("translated pole branches must retain their exact construction");
        };
        assert_eq!(translated.len(), 2);
        for (original, translated) in branches.iter().zip(&translated) {
            let expected = original.curve().evaluate_real(&q(1, 2)).unwrap()
                + Vector3::from_xyz(r(3), r(-2), r(5));
            assert_points_equal(
                &translated.curve().evaluate_real(&q(1, 2)).unwrap(),
                &expected,
            );
        }

        let (patch, face) = crate::construction::rational_bezier_patch(controls, weights).unwrap();
        let patch_surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let SurfaceSurfaceIntersection::Curves(patch_branches) =
            patch_surface.intersect_surface(&plane).unwrap()
        else {
            panic!("pole-branch patch must retain two topology-ready curves");
        };
        let (partitioned, partition) = patch
            .split_face_by_surface_curves(face, &patch_branches, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(partition.faces.len(), 3);
        assert_eq!(partition.traces.len(), 2);
        assert_eq!(partitioned.counts().faces, 3);
        let mut caller_reversed = patch_branches.clone();
        caller_reversed.reverse();
        let (reverse_partitioned, _) = patch
            .split_face_by_surface_curves(face, &caller_reversed, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(
            reverse_partitioned.to_json().unwrap(),
            partitioned.to_json().unwrap()
        );
        let json = partitioned.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn single_span_nurbs_tensor_graph_sections_retain_native_domain_through_topology() {
        let controls = vec![
            vec![p(0, 0, 0), p(2, 0, 0)],
            vec![p(0, 2, 1), p(2, 2, 1)],
            vec![p(0, 2, 2), p(2, 2, 2)],
        ];
        let weights = vec![vec![r(1), r(1)], vec![r(2), r(2)], vec![r(3), r(3)]];
        let (patch, face) = crate::construction::nurbs_patch(
            1,
            2,
            controls,
            weights,
            vec![r(7), r(7), r(11), r(11)],
            vec![r(2), r(2), r(2), r(5), r(5), r(5)],
        )
        .unwrap();
        let surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = surface.intersect_surface(&plane).unwrap()
        else {
            panic!("single-span NURBS tensor must retain one graph section");
        };
        assert_eq!(section.curve().domain().start(), &r(2));
        assert_eq!(section.curve().domain().end(), &r(5));
        let materialized = section.first_pcurve().materialize().unwrap();
        assert_eq!(
            materialized.correspondence().affine_coefficients(),
            Some((&r(3), &r(2)))
        );
        assert_eq!(
            materialized
                .curve()
                .point_at(&q(1, 2).clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone(),
            CurvePoint2::new(q(17, 2), q(7, 2))
        );
        let (split, _) = patch
            .split_face_by_surface_curve(face, &section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );
    }

    #[test]
    fn multi_span_nurbs_tensor_graph_sections_materialize_split_and_replay_exactly() {
        let controls = vec![
            vec![p(0, 0, 0), p(2, 0, 0)],
            vec![p(0, 2, 1), p(2, 2, 1)],
            vec![p(0, 3, 1), p(2, 3, 1)],
            vec![p(0, 1, 2), p(2, 1, 2)],
        ];
        let weights = vec![
            vec![r(1), r(1)],
            vec![r(2), r(2)],
            vec![r(3), r(3)],
            vec![r(1), r(1)],
        ];
        let (patch, face) = crate::construction::nurbs_patch(
            1,
            2,
            controls,
            weights,
            vec![r(7), r(7), r(11), r(11)],
            vec![r(2), r(2), r(2), r(3), r(5), r(5), r(5)],
        )
        .unwrap();
        let surface = patch.surface(patch.face(face).unwrap().surface()).unwrap();
        let plane = Surface::plane(
            p(2, 0, 0),
            Vector3::y(),
            Vector3::from_xyz(r(1), r(0), r(-1)),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = surface.intersect_surface(&plane).unwrap()
        else {
            panic!("multi-span NURBS tensor must retain one graph section");
        };
        assert_eq!(section.curve().domain().start(), &r(2));
        assert_eq!(section.curve().domain().end(), &r(5));
        let materialized = section.first_pcurve().materialize().unwrap();
        assert_eq!(materialized.curve().family(), CurveFamily2::Nurbs);
        assert_eq!(
            materialized.correspondence().affine_coefficients(),
            Some((&r(1), &r(0)))
        );
        for parameter in [r(2), r(3), r(4), r(5)] {
            let surface_parameter = materialized
                .curve()
                .point_at(&parameter.clone().into())
                .unwrap()
                .coordinates()
                .expect("native pcurve coordinates")
                .clone();
            assert_points_equal(
                &section.curve().evaluate_real(&parameter).unwrap(),
                &surface
                    .point_at(&Point2::new(
                        surface_parameter.x().clone(),
                        surface_parameter.y().clone(),
                    ))
                    .unwrap(),
            );
        }
        let (split, record) = patch
            .split_face_by_surface_curve(face, &section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(split.counts().faces, 2);
        let graph_use = split
            .edge_use(record.open().unwrap().face.edge_uses[0])
            .unwrap();
        let graph_pcurve = split.pcurve(graph_use.pcurve()).unwrap();
        let Some(CurveGeometry2::Nurbs(graph)) = graph_pcurve.curve().geometry() else {
            panic!("multi-span tensor split must retain one NURBS graph pcurve");
        };
        let mut forged_controls = graph.affine_control_points().unwrap().to_vec();
        forged_controls[1] = CurvePoint2::new(
            forged_controls[1].x().clone() + Real::one(),
            forged_controls[1].y().clone(),
        );
        let forged = Pcurve::new(
            Curve2::try_nurbs(
                graph.degree(),
                forged_controls,
                graph.weights().to_vec(),
                graph.knots().to_vec(),
            )
            .unwrap(),
        );
        let mut edit = split.edit();
        edit.replace_pcurve(graph_use.pcurve(), forged).unwrap();
        assert!(
            edit.commit().is_err(),
            "endpoint-preserving NURBS graph forgery must fail full control-net validation"
        );
        let json = split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            json
        );

        let (v_patch, v_face) = crate::construction::nurbs_patch(
            2,
            1,
            vec![
                vec![p(0, 0, 0), p(1, 2, 0), p(1, 3, 0), p(2, 1, 0)],
                vec![p(0, 0, 2), p(1, 2, 2), p(1, 3, 2), p(2, 1, 2)],
            ],
            vec![vec![r(1), r(2), r(3), r(1)], vec![r(1), r(2), r(3), r(1)]],
            vec![r(2), r(2), r(2), r(3), r(5), r(5), r(5)],
            vec![r(7), r(7), r(11), r(11)],
        )
        .unwrap();
        let v_surface = v_patch
            .surface(v_patch.face(v_face).unwrap().surface())
            .unwrap();
        let SurfaceSurfaceIntersection::Curve(v_section) =
            v_surface.intersect_surface(&plane).unwrap()
        else {
            panic!("multi-span v-linear NURBS tensor must retain one graph section");
        };
        let v_materialized = v_section.first_pcurve().materialize().unwrap();
        assert_eq!(v_materialized.curve().family(), CurveFamily2::Nurbs);
        assert_eq!(
            v_materialized.correspondence().affine_coefficients(),
            Some((&r(1), &r(0)))
        );
        let (v_split, _) = v_patch
            .split_face_by_surface_curve(v_face, &v_section, SurfaceIntersectionOperand::First)
            .unwrap();
        assert_eq!(v_split.counts().faces, 2);
        let v_json = v_split.to_json().unwrap();
        assert_eq!(
            crate::ImportedModel::from_json(&v_json, &crate::ArchiveLimits::default())
                .unwrap()
                .validate()
                .unwrap()
                .to_json()
                .unwrap(),
            v_json
        );
    }

    #[test]
    fn extrusion_surfaces_intersect_planes_in_exact_native_curves_and_lines() {
        let profile = Curve3::rational_bezier(
            vec![p(0, 0, 0), p(1, 2, 0), p(2, 0, 0)],
            vec![r(1), r(2), r(1)],
        )
        .unwrap();
        let extrusion = Surface::extrusion(profile.clone(), Vector3::z()).unwrap();
        let oblique = Surface::plane(
            Point3::origin(),
            Vector3::from_xyz(r(1), r(0), r(1)),
            Vector3::y(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            extrusion.intersect_surface(&oblique).unwrap()
        else {
            panic!("transverse plane must retain the projected native profile");
        };
        assert_eq!(section.curve().kind(), Curve3Kind::RationalBezier);
        let parameter = q(1, 2);
        let profile_point = profile.evaluate_real(&parameter).unwrap();
        let expected = Point3::new(profile_point.x.clone(), profile_point.y, profile_point.x);
        assert_points_equal(
            &section.curve().evaluate_real(&parameter).unwrap(),
            &expected,
        );
        assert_eq!(
            section.first_pcurve().point_at(&parameter).unwrap(),
            Point2::new(parameter.clone(), expected.z.clone())
        );
        let extrusion_clip = section
            .first_pcurve()
            .clipping_carriers()
            .unwrap()
            .expect("rational extrusion section has an exact planar carrier")
            .pop()
            .expect("one rational extrusion span");
        let extrusion_parameter = extrusion_clip
            .curve
            .point_at(&parameter.clone().into())
            .unwrap()
            .coordinates()
            .expect("native pcurve coordinates")
            .clone();
        assert_eq!(
            compare_reals(
                extrusion_parameter.x(),
                &parameter,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                extrusion_parameter.y(),
                &expected.z,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        let plane_clip = section
            .second_pcurve()
            .clipping_carriers()
            .unwrap()
            .expect("projected rational section has an exact planar carrier")
            .pop()
            .expect("one projected rational span");
        let plane_parameter = plane_clip
            .curve
            .point_at(&parameter.clone().into())
            .unwrap()
            .coordinates()
            .expect("native pcurve coordinates")
            .clone();
        let retained_plane_parameter = section.second_pcurve().point_at(&parameter).unwrap();
        assert_eq!(
            compare_reals(
                plane_parameter.x(),
                &retained_plane_parameter.x,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                plane_parameter.y(),
                &retained_plane_parameter.y,
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );

        let nurbs_profile = Curve3::nurbs(
            1,
            vec![p(0, 0, 0), p(1, 2, 0), p(2, 0, 0)],
            vec![r(1), r(2), r(1)],
            vec![r(2), r(2), r(3), r(4), r(4)],
        )
        .unwrap();
        let nurbs_extrusion = Surface::extrusion(nurbs_profile.clone(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curve(nurbs_section) =
            nurbs_extrusion.intersect_surface(&oblique).unwrap()
        else {
            panic!("transverse NURBS extrusion must retain one exact section");
        };
        let carriers = nurbs_section
            .first_pcurve()
            .clipping_carriers()
            .unwrap()
            .expect("NURBS extrusion section decomposes into rational trim carriers");
        assert_eq!(carriers.len(), 2);
        for carrier in &carriers {
            for local in [Real::zero(), Real::one()] {
                let spatial_parameter = carrier.spatial_parameter_at(&local).unwrap();
                let materialized = carrier
                    .curve
                    .point_at(&local.clone().into())
                    .unwrap()
                    .coordinates()
                    .expect("native pcurve coordinates")
                    .clone();
                let retained = nurbs_section
                    .first_pcurve()
                    .point_at(&spatial_parameter)
                    .unwrap();
                assert_eq!(
                    compare_reals(materialized.x(), &retained.x, crate::STRICT_PREDICATES).value(),
                    Some(Ordering::Equal)
                );
                assert_eq!(
                    compare_reals(materialized.y(), &retained.y, crate::STRICT_PREDICATES).value(),
                    Some(Ordering::Equal)
                );
            }
        }
        let trim_points = [
            CurvePoint2::new(q(5, 2), r(-100)),
            CurvePoint2::new(q(7, 2), r(-100)),
            CurvePoint2::new(q(7, 2), r(100)),
            CurvePoint2::new(q(5, 2), r(100)),
        ];
        let trim_contour = hypercurve::Contour2::try_new(
            (0..trim_points.len())
                .map(|index| {
                    LineSeg2::try_new(
                        trim_points[index].clone(),
                        trim_points[(index + 1) % trim_points.len()].clone(),
                    )
                    .map(Segment2::Line)
                })
                .collect::<Result<Vec<_>, _>>()
                .unwrap(),
        )
        .unwrap();
        let trim_region =
            CurveRegion2::try_from_native_material_contours(vec![trim_contour]).unwrap();
        let mut retained_ranges = Vec::new();
        for carrier in &carriers {
            for fragment in carrier
                .curve
                .trim_inside_region_with_parameters(&trim_region)
                .unwrap()
            {
                let (local_start, local_end) = fragment
                    .represented_parameter_range()
                    .expect("linear region contacts have represented parameters");
                retained_ranges.push((
                    carrier.spatial_parameter_at(&local_start).unwrap(),
                    carrier.spatial_parameter_at(&local_end).unwrap(),
                ));
            }
        }
        assert_eq!(retained_ranges.len(), 2);
        for ((actual_start, actual_end), (expected_start, expected_end)) in retained_ranges
            .into_iter()
            .zip([(q(5, 2), r(3)), (r(3), q(7, 2))])
        {
            assert_eq!(
                compare_reals(&actual_start, &expected_start, crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            assert_eq!(
                compare_reals(&actual_end, &expected_end, crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
        }

        let ruled = Surface::extrusion(Curve3::line(p(0, 0, 0), p(2, 0, 0)).unwrap(), Vector3::z())
            .unwrap();
        let x_one = Surface::plane(p(1, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Line(line) = x_one.intersect_surface(&ruled).unwrap()
        else {
            panic!("parallel plane/profile point must lift to one extrusion line");
        };
        assert_points_equal(&line.point, &p(1, 0, 0));
        assert_points_equal(&Point3::from(line.direction), &Point3::from(Vector3::z()));
        assert!(matches!(
            ruled
                .intersect_surface(&Surface::plane(p(0, 1, 0), Vector3::x(), Vector3::z()).unwrap())
                .unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        assert_eq!(
            ruled
                .intersect_surface(
                    &Surface::plane(Point3::origin(), Vector3::x(), Vector3::z()).unwrap()
                )
                .unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn degenerate_geometry_is_rejected_by_certified_predicates() {
        assert_eq!(
            Curve3::line(p(1, 2, 3), p(1, 2, 3)).unwrap_err(),
            GeometryError::DegenerateLine
        );
        assert_eq!(
            Surface::plane(p(0, 0, 0), Vector3::x(), Vector3::x()).unwrap_err(),
            GeometryError::DegeneratePlaneBasis
        );
    }

    #[test]
    fn line_plane_intersection_distinguishes_point_none_and_contained() {
        let plane = Surface::plane(p(0, 0, 0), Vector3::x(), Vector3::y()).unwrap();
        let crossing = Curve3::line(p(2, 3, -5), p(2, 3, 5)).unwrap();
        match plane.intersect_curve(&crossing).unwrap() {
            CurveSurfaceIntersection::Points(points) => {
                assert_eq!(points.len(), 1);
                let intersection = &points[0];
                assert_eq!(
                    compare_reals(intersection.parameter.try_real().unwrap(), &q(1, 2), crate::STRICT_PREDICATES)
                        .value(),
                    Some(Ordering::Equal)
                );
                assert_points_equal(intersection.point.try_coordinates().unwrap(), &p(2, 3, 0));
                assert_eq!(intersection.multiplicity, IntersectionMultiplicity::Simple);
            }
            other => panic!("expected point intersection, got {other:?}"),
        }
        assert!(matches!(
            plane
                .intersect_curve(&Curve3::line(p(0, 0, 2), p(1, 0, 2)).unwrap())
                .unwrap(),
            CurveSurfaceIntersection::None
        ));
        assert!(matches!(
            plane
                .intersect_curve(&Curve3::line(p(0, 0, 0), p(1, 0, 0)).unwrap())
                .unwrap(),
            CurveSurfaceIntersection::Contained
        ));
    }

    #[test]
    fn ellipse_plane_intersection_retains_exact_parameters_tangency_and_seams() {
        let circle = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(2),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        let y_axis_plane = Surface::plane(Point3::origin(), Vector3::y(), Vector3::z()).unwrap();
        let CurveSurfaceIntersection::Points(points) =
            y_axis_plane.intersect_curve(&circle).unwrap()
        else {
            panic!("diametral plane must retain two circle parameters");
        };
        assert_eq!(points.len(), 2);
        assert_eq!(
            compare_reals(
                points[0].parameter.try_real().unwrap(),
                &(Real::pi() / r(2)).unwrap(),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(
                points[1].parameter.try_real().unwrap(),
                &(r(3) * Real::pi() / r(2)).unwrap(),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert!(
            points
                .iter()
                .all(|point| point.multiplicity == IntersectionMultiplicity::Simple)
        );

        let tangent = Surface::plane(p(2, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let CurveSurfaceIntersection::Points(points) = tangent.intersect_curve(&circle).unwrap()
        else {
            panic!("tangent plane must retain represented seam parameters");
        };
        assert_eq!(points.len(), 2);
        assert_eq!(
            compare_reals(
                points[0].parameter.try_real().unwrap(),
                &Real::zero(),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(points[1].parameter.try_real().unwrap(), &Real::tau(), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert!(
            points
                .iter()
                .all(|point| point.multiplicity == IntersectionMultiplicity::Tangent)
        );

        let carrier_plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            carrier_plane.intersect_curve(&circle).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
        let parallel = Surface::plane(p(0, 0, 1), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            parallel.intersect_curve(&circle).unwrap(),
            CurveSurfaceIntersection::None
        ));

        let ellipse = Curve3::ellipse_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(3),
            r(2),
            Real::zero(),
            Real::pi(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) =
            y_axis_plane.intersect_curve(&ellipse).unwrap()
        else {
            panic!("finite half ellipse must retain its one represented crossing");
        };
        assert_eq!(points.len(), 1);
        assert_eq!(
            compare_reals(
                points[0].parameter.try_real().unwrap(),
                &(Real::pi() / r(2)).unwrap(),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
    }

    #[test]
    fn circle_sphere_intersection_retains_exact_arc_parameters_and_multiplicity() {
        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(5),
        )
        .unwrap();
        let secant = Curve3::circle_arc(
            p(3, 0, 0),
            Vector3::x(),
            Vector3::y(),
            r(4),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) = sphere.intersect_curve(&secant).unwrap()
        else {
            panic!("offset circle must cross the sphere twice");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(3, 4, 0));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(3, -4, 0));
        assert!(
            points
                .iter()
                .all(|point| point.multiplicity == IntersectionMultiplicity::Simple)
        );

        let tangent = Curve3::circle_arc(
            p(4, 0, 0),
            Vector3::x(),
            Vector3::y(),
            r(1),
            Real::zero(),
            Real::pi(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) = sphere.intersect_curve(&tangent).unwrap()
        else {
            panic!("internally tangent circle must retain one point");
        };
        assert_eq!(points.len(), 1);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(5, 0, 0));
        assert_eq!(points[0].multiplicity, IntersectionMultiplicity::Tangent);

        let contained = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(5),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            sphere.intersect_curve(&contained).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
        let inside = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(1),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            sphere.intersect_curve(&inside).unwrap(),
            CurveSurfaceIntersection::None
        ));
    }

    #[test]
    fn transverse_circle_cylinder_intersection_reuses_exact_circle_relation() {
        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(5),
        )
        .unwrap();
        let secant = Curve3::circle_arc(
            p(3, 0, 2),
            Vector3::x(),
            Vector3::y(),
            r(4),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) = cylinder.intersect_curve(&secant).unwrap()
        else {
            panic!("transverse offset circle must cross the cylinder twice");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(3, 4, 2));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(3, -4, 2));

        let tangent = Curve3::circle_arc(
            p(4, 0, -3),
            Vector3::x(),
            Vector3::y(),
            r(1),
            Real::zero(),
            Real::pi(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) = cylinder.intersect_curve(&tangent).unwrap()
        else {
            panic!("transverse tangent circle must retain one point");
        };
        assert_eq!(points.len(), 1);
        assert_eq!(points[0].multiplicity, IntersectionMultiplicity::Tangent);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(5, 0, -3));

        let contained = Curve3::circle_arc(
            p(0, 0, 7),
            Vector3::x(),
            Vector3::y(),
            r(5),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            cylinder.intersect_curve(&contained).unwrap(),
            CurveSurfaceIntersection::Contained
        ));

        let oblique = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::z(),
            r(5),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert_eq!(
            cylinder.intersect_curve(&oblique).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn transverse_circle_cone_intersection_respects_the_upper_nappe() {
        let cone = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            (Real::pi() / r(4)).unwrap(),
        )
        .unwrap();
        let secant = Curve3::circle_arc(
            p(3, 0, 5),
            Vector3::x(),
            Vector3::y(),
            r(4),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) = cone.intersect_curve(&secant).unwrap()
        else {
            panic!("upper transverse circle must meet the cone twice");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(3, 4, 5));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(3, -4, 5));

        let contained = Curve3::circle_arc(
            p(0, 0, 5),
            Vector3::x(),
            Vector3::y(),
            r(5),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            cone.intersect_curve(&contained).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
        let below = Curve3::circle_arc(
            p(0, 0, -5),
            Vector3::x(),
            Vector3::y(),
            r(5),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            cone.intersect_curve(&below).unwrap(),
            CurveSurfaceIntersection::None
        ));
    }

    #[test]
    fn transverse_circle_torus_intersection_checks_both_radial_sections() {
        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let twice_tangent = Curve3::circle_arc(
            p(3, 0, 0),
            Vector3::x(),
            Vector3::y(),
            r(1),
            Real::zero(),
            Real::pi(),
        )
        .unwrap();
        let CurveSurfaceIntersection::Points(points) =
            torus.intersect_curve(&twice_tangent).unwrap()
        else {
            panic!("center-plane circle must touch both torus radial sections");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(4, 0, 0));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(2, 0, 0));
        assert!(
            points
                .iter()
                .all(|point| point.multiplicity == IntersectionMultiplicity::Tangent)
        );

        let outer = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(4),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            torus.intersect_curve(&outer).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
        let above = Curve3::circle_arc(
            p(0, 0, 2),
            Vector3::x(),
            Vector3::y(),
            r(3),
            Real::zero(),
            Real::tau(),
        )
        .unwrap();
        assert!(matches!(
            torus.intersect_curve(&above).unwrap(),
            CurveSurfaceIntersection::None
        ));
    }

    #[test]
    fn line_sphere_and_cylinder_intersections_retain_multiplicity() {
        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let crossing = Curve3::line(p(-3, 0, 0), p(3, 0, 0)).unwrap();
        let CurveSurfaceIntersection::Points(points) = sphere.intersect_curve(&crossing).unwrap()
        else {
            panic!("expected two sphere intersections");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(-2, 0, 0));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(2, 0, 0));
        assert!(
            points
                .iter()
                .all(|point| point.multiplicity == IntersectionMultiplicity::Simple)
        );
        let tangent = Curve3::line(p(-3, 2, 0), p(3, 2, 0)).unwrap();
        let CurveSurfaceIntersection::Points(points) = sphere.intersect_curve(&tangent).unwrap()
        else {
            panic!("expected tangent sphere intersection");
        };
        assert_eq!(points.len(), 1);
        assert_eq!(points[0].multiplicity, IntersectionMultiplicity::Tangent);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(0, 2, 0));

        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let axial = Curve3::line(p(2, 0, -3), p(2, 0, 3)).unwrap();
        assert!(matches!(
            cylinder.intersect_curve(&axial).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
    }

    #[test]
    fn line_cone_intersection_filters_the_lower_nappe_and_retains_overlap() {
        let quarter_turn = (Real::pi() / r(4)).unwrap();
        let cone = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            quarter_turn,
        )
        .unwrap();
        let crossing = Curve3::line(p(-2, 0, 1), p(2, 0, 1)).unwrap();
        let CurveSurfaceIntersection::Points(points) = cone.intersect_curve(&crossing).unwrap()
        else {
            panic!("line through the upper cone must have two intersections");
        };
        assert_eq!(points.len(), 2);
        assert_points_equal(points[0].point.try_coordinates().unwrap(), &p(-1, 0, 1));
        assert_points_equal(points[1].point.try_coordinates().unwrap(), &p(1, 0, 1));

        let lower = Curve3::line(p(-2, 0, -1), p(2, 0, -1)).unwrap();
        assert!(matches!(
            cone.intersect_curve(&lower).unwrap(),
            CurveSurfaceIntersection::None
        ));
        let generator = Curve3::line(p(-2, 0, -2), p(2, 0, 2)).unwrap();
        let CurveSurfaceIntersection::Overlap(domain) = cone.intersect_curve(&generator).unwrap()
        else {
            panic!("generator crossing the apex must retain its upper interval");
        };
        assert_eq!(
            compare_reals(domain.start().try_real().unwrap(), &q(1, 2), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(domain.end().try_real().unwrap(), &r(1), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        let contained = Curve3::line(p(1, 0, 1), p(2, 0, 2)).unwrap();
        assert!(matches!(
            cone.intersect_curve(&contained).unwrap(),
            CurveSurfaceIntersection::Contained
        ));
    }

    #[test]
    fn plane_plane_intersection_is_exact() {
        let x_two = Surface::plane(p(2, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let y_three = Surface::plane(p(0, 3, 0), Vector3::z(), Vector3::x()).unwrap();
        match x_two.intersect_surface(&y_three).unwrap() {
            SurfaceSurfaceIntersection::Line(line) => {
                assert_points_equal(&line.point, &p(2, 3, 0));
                for (actual, expected) in line.direction.0.iter().zip(Vector3::z().0.iter()) {
                    assert_eq!(
                        compare_reals(actual, expected, crate::STRICT_PREDICATES).value(),
                        Some(Ordering::Equal)
                    );
                }
            }
            other => panic!("expected line intersection, got {other:?}"),
        }
        let x_four = Surface::plane(p(4, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        assert!(matches!(
            x_two.intersect_surface(&x_four).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let x_two_other_frame = Surface::plane(p(2, 5, 7), Vector3::z(), Vector3::y()).unwrap();
        assert!(matches!(
            x_two.intersect_surface(&x_two_other_frame).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
    }

    #[test]
    fn plane_cylinder_intersection_retains_circles_ellipses_and_axial_lines() {
        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let transverse = Surface::plane(p(0, 0, 3), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) =
            cylinder.intersect_surface(&transverse).unwrap()
        else {
            panic!("transverse plane must retain a full circle with both exact pcurves");
        };
        assert_points_equal(&section.curve().start().unwrap(), &p(2, 0, 3));
        let cylinder_pcurve = section.first_pcurve().materialize().unwrap();
        assert_eq!(cylinder_pcurve.curve().family(), CurveFamily2::Line);
        assert!(matches!(
            cylinder_pcurve.correspondence(),
            SurfacePcurveCorrespondence::Affine { .. }
        ));
        let plane_pcurve = section.second_pcurve().materialize().unwrap();
        assert_eq!(plane_pcurve.curve().family(), CurveFamily2::CircularArc);
        assert!(matches!(
            plane_pcurve.correspondence(),
            SurfacePcurveCorrespondence::AngularSweep { .. }
        ));

        let secant = Surface::plane(Point3::origin(), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Lines(lines) = secant.intersect_surface(&cylinder).unwrap()
        else {
            panic!("axial secant plane must retain two lines");
        };
        assert_eq!(lines.len(), 2);
        assert_points_equal(&lines[0].point, &p(0, 2, 0));
        assert_points_equal(&lines[1].point, &p(0, -2, 0));
        for line in lines {
            assert_eq!(
                point3_equal(
                    &Point3::from(line.direction),
                    &Point3::from(Vector3::z()),
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(true)
            );
        }

        let tangent = Surface::plane(p(2, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Line(line) = cylinder.intersect_surface(&tangent).unwrap()
        else {
            panic!("axial tangent plane must retain one line");
        };
        assert_points_equal(&line.point, &p(2, 0, 0));
        let disjoint = Surface::plane(p(3, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let oblique = Surface::plane(
            Point3::origin(),
            Vector3::x(),
            Vector3::from_xyz(Real::zero(), Real::one(), Real::one()),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Ellipse(ellipse) =
            cylinder.intersect_surface(&oblique).unwrap()
        else {
            panic!("oblique plane must retain one exact full ellipse");
        };
        assert_eq!(ellipse.kind(), Curve3Kind::EllipseArc);
        assert_points_equal(&ellipse.evaluate_real(&Real::zero()).unwrap(), &p(2, 0, 0));
        assert_points_equal(
            &ellipse
                .evaluate_real(&(Real::pi() / r(2)).unwrap())
                .unwrap(),
            &p(0, -2, -2),
        );
        for parameter in [
            Real::zero(),
            (Real::pi() / r(2)).unwrap(),
            Real::pi(),
            (r(3) * Real::pi() / r(2)).unwrap(),
        ] {
            let point = ellipse.evaluate_real(&parameter).unwrap();
            assert_eq!(
                compare_reals(
                    &(&point.x * &point.x + &point.y * &point.y),
                    &r(4),
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
            assert_eq!(
                compare_reals(&point.y, &point.z, crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
        }
    }

    #[test]
    fn transverse_planes_retain_exact_cone_and_torus_sections() {
        let cone = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            (Real::pi() / r(4)).unwrap(),
        )
        .unwrap();
        let z_two = Surface::plane(p(0, 0, 2), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(section) = cone.intersect_surface(&z_two).unwrap()
        else {
            panic!("transverse upper-cone cut must retain a circle and both exact pcurves");
        };
        assert_points_equal(&section.curve().start().unwrap(), &p(2, 0, 2));
        assert_eq!(
            section
                .first_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::Line
        );
        assert_eq!(
            section
                .second_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::CircularArc
        );
        let apex_plane = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Point(point) = cone.intersect_surface(&apex_plane).unwrap()
        else {
            panic!("apex plane must retain the singular point");
        };
        assert_points_equal(&point, &Point3::origin());
        let below = Surface::plane(p(0, 0, -1), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            cone.intersect_surface(&below).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) =
            torus.intersect_surface(&apex_plane).unwrap()
        else {
            panic!("torus center plane must retain two circles");
        };
        assert_eq!(circles.len(), 2);
        assert_points_equal(&circles[0].curve().start().unwrap(), &p(4, 0, 0));
        assert_points_equal(&circles[1].curve().start().unwrap(), &p(2, 0, 0));
        for section in &circles {
            assert_eq!(
                section
                    .first_pcurve()
                    .materialize()
                    .unwrap()
                    .curve()
                    .family(),
                CurveFamily2::Line
            );
            assert_eq!(
                section
                    .second_pcurve()
                    .materialize()
                    .unwrap()
                    .curve()
                    .family(),
                CurveFamily2::CircularArc
            );
        }
        let tangent = Surface::plane(p(0, 0, 1), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) = torus.intersect_surface(&tangent).unwrap()
        else {
            panic!("top torus plane must retain one tangent circle");
        };
        assert_points_equal(&circle.curve().start().unwrap(), &p(3, 0, 1));
        let disjoint = Surface::plane(p(0, 0, 2), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            torus.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let axial_plane = Surface::plane(Point3::origin(), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Rays(rays) = cone.intersect_surface(&axial_plane).unwrap()
        else {
            panic!("an axis-containing plane must retain both upper-cone generator rays");
        };
        assert_eq!(rays.len(), 2);
        let sqrt_two = r(2).sqrt().unwrap();
        for ray in &rays {
            assert_points_equal(&ray.point, &Point3::origin());
            assert_eq!(
                compare_reals(
                    &ray.direction.norm_squared(),
                    &Real::one(),
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
            assert_eq!(
                compare_reals(&ray.minimum, &Real::zero(), crate::STRICT_PREDICATES).value(),
                Some(Ordering::Equal)
            );
            for parameter in [Real::zero(), sqrt_two.clone()] {
                let spatial = ray.point.clone() + ray.direction.clone() * &parameter;
                assert_points_equal(
                    &cone
                        .point_at(
                            &ray.pcurve(SurfaceIntersectionOperand::First)
                                .point_at(&parameter),
                        )
                        .unwrap(),
                    &spatial,
                );
                assert_points_equal(
                    &axial_plane
                        .point_at(
                            &ray.pcurve(SurfaceIntersectionOperand::Second)
                                .point_at(&parameter),
                        )
                        .unwrap(),
                    &spatial,
                );
            }
        }
        assert_points_equal(
            &(rays[0].point.clone() + rays[0].direction.clone() * &sqrt_two),
            &p(0, -1, 1),
        );
        assert_points_equal(
            &(rays[1].point.clone() + rays[1].direction.clone() * &sqrt_two),
            &p(0, 1, 1),
        );
        let SurfaceSurfaceIntersection::Rays(swapped) =
            axial_plane.intersect_surface(&cone).unwrap()
        else {
            panic!("operand reversal must retain both cone rays");
        };
        assert_eq!(swapped.len(), 2);
        for ray in &swapped {
            let spatial = ray.point.clone() + ray.direction.clone() * &sqrt_two;
            assert_points_equal(
                &axial_plane
                    .point_at(
                        &ray.pcurve(SurfaceIntersectionOperand::First)
                            .point_at(&sqrt_two),
                    )
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &cone
                    .point_at(
                        &ray.pcurve(SurfaceIntersectionOperand::Second)
                            .point_at(&sqrt_two),
                    )
                    .unwrap(),
                &spatial,
            );
        }
        let offset_axial = Surface::plane(p(1, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        assert_eq!(
            cone.intersect_surface(&offset_axial).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn certified_atan2_retains_exact_axes_quadrants_and_symbolic_cancellation() {
        let quarter = (Real::pi() / r(4)).unwrap();
        let half = (Real::pi() / r(2)).unwrap();
        for (y, x, expected) in [
            (Real::zero(), Real::zero(), Real::zero()),
            (Real::zero(), Real::one(), Real::zero()),
            (Real::zero(), -Real::one(), Real::pi()),
            (Real::one(), Real::zero(), half.clone()),
            (-Real::one(), Real::zero(), -half),
            (Real::one(), Real::one(), quarter.clone()),
            (Real::one(), -Real::one(), Real::pi() - &quarter),
            (-Real::one(), -Real::one(), -Real::pi() + &quarter),
            (-Real::one(), Real::one(), -quarter),
        ] {
            assert_eq!(
                compare_reals(
                    &certified_atan2(y, x).unwrap(),
                    &expected,
                    crate::STRICT_PREDICATES
                )
                .value(),
                Some(Ordering::Equal)
            );
        }

        let diagonal = (Real::one() / r(2).sqrt().unwrap()).unwrap();
        let symbolic_zero = r(2) * &diagonal * diagonal - Real::one();
        assert_eq!(
            compare_reals(
                &certified_atan2(Real::one(), symbolic_zero).unwrap(),
                &(Real::pi() / r(2)).unwrap(),
                crate::STRICT_PREDICATES
            )
            .value(),
            Some(Ordering::Equal)
        );
    }

    #[test]
    fn axial_plane_through_ring_torus_retains_two_exact_meridian_circles() {
        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let plane = Surface::plane(Point3::origin(), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Curves(sections) = torus.intersect_surface(&plane).unwrap()
        else {
            panic!("an axial plane through a ring torus must retain two meridian circles");
        };
        assert_eq!(sections.len(), 2);
        assert_points_equal(&sections[0].curve().start().unwrap(), &p(0, -4, 0));
        assert_points_equal(&sections[1].curve().start().unwrap(), &p(0, 4, 0));

        for section in &sections {
            assert_eq!(section.curve().kind(), Curve3Kind::CircleArc);
            assert_eq!(
                section
                    .first_pcurve()
                    .materialize()
                    .unwrap()
                    .curve()
                    .family(),
                CurveFamily2::Line
            );
            assert_eq!(
                section
                    .second_pcurve()
                    .materialize()
                    .unwrap()
                    .curve()
                    .family(),
                CurveFamily2::CircularArc
            );
            for parameter in [Real::zero(), (Real::pi() / r(2)).unwrap(), Real::pi()] {
                let point = section.curve().evaluate_real(&parameter).unwrap();
                assert_points_equal(
                    &torus
                        .point_at(&section.first_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &point,
                );
                assert_points_equal(
                    &plane
                        .point_at(&section.second_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &point,
                );
            }
        }

        let SurfaceSurfaceIntersection::Curves(swapped) = plane.intersect_surface(&torus).unwrap()
        else {
            panic!("operand reversal must retain both meridian circles");
        };
        assert_eq!(swapped.len(), 2);
        assert_eq!(
            swapped[0]
                .first_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::CircularArc
        );
        assert_eq!(
            swapped[0]
                .second_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::Line
        );

        let offset = Surface::plane(p(1, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        assert_eq!(
            torus.intersect_surface(&offset).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let separated = Surface::plane(p(5, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        assert!(matches!(
            torus.intersect_surface(&separated).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let tangent = Surface::plane(p(4, 0, 0), Vector3::y(), Vector3::z()).unwrap();
        let SurfaceSurfaceIntersection::Point(point) = torus.intersect_surface(&tangent).unwrap()
        else {
            panic!("an outer-radius axial plane must retain the exact tangent point");
        };
        assert_points_equal(&point, &p(4, 0, 0));
        let oblique = Surface::plane(
            Point3::origin(),
            Vector3::x(),
            Vector3::from_xyz(Real::zero(), Real::one(), Real::one()),
        )
        .unwrap();
        assert_eq!(
            torus.intersect_surface(&oblique).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn parallel_cylinder_intersections_retain_exact_axial_lines() {
        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let same_axis =
            Surface::cylinder(p(0, 0, 5), Vector3::x(), -Vector3::y(), -Vector3::z(), r(2))
                .unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&same_axis).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
        let concentric_other_radius = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            cylinder
                .intersect_surface(&concentric_other_radius)
                .unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let secant =
            Surface::cylinder(p(3, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Lines(lines) = cylinder.intersect_surface(&secant).unwrap()
        else {
            panic!("parallel secant cylinders must retain two axial lines");
        };
        let half_sqrt_seven = (r(7).sqrt().unwrap() / r(2)).unwrap();
        assert_points_equal(
            &lines[0].point,
            &Point3::new(q(3, 2), half_sqrt_seven.clone(), Real::zero()),
        );
        assert_points_equal(
            &lines[1].point,
            &Point3::new(q(3, 2), -half_sqrt_seven, Real::zero()),
        );

        let tangent =
            Surface::cylinder(p(4, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Line(line) = cylinder.intersect_surface(&tangent).unwrap()
        else {
            panic!("externally tangent cylinders must retain one axial line");
        };
        assert_points_equal(&line.point, &p(2, 0, 0));
        let disjoint =
            Surface::cylinder(p(5, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let skew = Surface::cylinder(
            Point3::origin(),
            Vector3::y(),
            Vector3::z(),
            Vector3::x(),
            r(2),
        )
        .unwrap();
        assert_eq!(
            cylinder.intersect_surface(&skew).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_sphere_cylinder_intersections_retain_exact_circles() {
        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) =
            sphere.intersect_surface(&cylinder).unwrap()
        else {
            panic!("aligned coaxial carriers must retain two circles with exact pcurves");
        };
        let sqrt_five = r(5).sqrt().unwrap();
        assert_points_equal(
            &circles[0].curve().start().unwrap(),
            &Point3::new(r(2), Real::zero(), sqrt_five.clone()),
        );
        assert_points_equal(
            &circles[1].curve().start().unwrap(),
            &Point3::new(r(2), Real::zero(), -sqrt_five),
        );
        for circle in &circles {
            let parameter = Real::pi();
            let spatial = circle.curve().evaluate_real(&parameter).unwrap();
            let sphere_point = sphere
                .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                .unwrap();
            let cylinder_point = cylinder
                .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                .unwrap();
            assert_points_equal(&sphere_point, &spatial);
            assert_points_equal(&cylinder_point, &spatial);
            assert!(circle.first_pcurve().materialize().is_ok());
            assert!(circle.second_pcurve().materialize().is_ok());
        }
        let SurfaceSurfaceIntersection::Curves(swapped) =
            cylinder.intersect_surface(&sphere).unwrap()
        else {
            panic!("operand reversal must retain the same two exact circles");
        };
        let parameter = Real::pi();
        assert_points_equal(
            &cylinder
                .point_at(&swapped[0].first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &swapped[0].curve().evaluate_real(&parameter).unwrap(),
        );
        assert_points_equal(
            &sphere
                .point_at(&swapped[0].second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &swapped[0].curve().evaluate_real(&parameter).unwrap(),
        );
        let rotated_parameters = Surface::sphere(
            Point3::origin(),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
        )
        .unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circles(_)
        ));
        let mirrored_cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(2),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(mirrored_circles) =
            sphere.intersect_surface(&mirrored_cylinder).unwrap()
        else {
            panic!("mirrored coaxial cylinder parameters must retain both circles");
        };
        assert_eq!(mirrored_circles.len(), 2);
        let mirrored_parameter = q(1, 3);
        for mirrored_circle in &mirrored_circles {
            let spatial = mirrored_circle
                .curve()
                .evaluate_real(&mirrored_parameter)
                .unwrap();
            assert_points_equal(
                &mirrored_cylinder
                    .point_at(
                        &mirrored_circle
                            .second_pcurve()
                            .point_at(&mirrored_parameter)
                            .unwrap(),
                    )
                    .unwrap(),
                &spatial,
            );
            let cylinder_pcurve = mirrored_circle.second_pcurve().materialize().unwrap();
            assert_eq!(
                cylinder_pcurve
                    .curve()
                    .start()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::tau()
            );
            assert_eq!(
                cylinder_pcurve
                    .curve()
                    .end()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::zero()
            );
        }

        let tangent = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) =
            cylinder.intersect_surface(&tangent).unwrap()
        else {
            panic!("equal-radius aligned carriers must retain one tangent circle");
        };
        assert_points_equal(&circle.curve().start().unwrap(), &p(2, 0, 0));
        assert!(circle.first_pcurve().materialize().is_ok());
        assert!(circle.second_pcurve().materialize().is_ok());
        let contained = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&contained).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let off_axis =
            Surface::sphere(p(1, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(3)).unwrap();
        assert_eq!(
            cylinder.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_sphere_cone_intersections_retain_native_slant_circles() {
        let semi_angle = q(3, 4).atan().unwrap();
        let cone = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            semi_angle.clone(),
        )
        .unwrap();
        let centered = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) = centered.intersect_surface(&cone).unwrap()
        else {
            panic!("an apex-centered sphere must cut one exact cone latitude");
        };
        assert_points_equal(
            &circle.curve().start().unwrap(),
            &Point3::new(q(6, 5), Real::zero(), q(8, 5)),
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &centered
                    .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &cone
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }

        let two_circle_sphere =
            Surface::sphere(p(0, 0, 5), Vector3::x(), Vector3::y(), Vector3::z(), r(4)).unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) =
            two_circle_sphere.intersect_surface(&cone).unwrap()
        else {
            panic!("a coaxial sphere spanning both cone sheets must retain two upper circles");
        };
        assert_eq!(circles.len(), 2);
        let parameter = q(1, 3);
        for circle in &circles {
            let spatial = circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &two_circle_sphere
                    .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &cone
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }

        let tangent =
            Surface::sphere(p(0, 0, 5), Vector3::x(), Vector3::y(), Vector3::z(), r(3)).unwrap();
        let SurfaceSurfaceIntersection::Curve(tangent_circle) =
            tangent.intersect_surface(&cone).unwrap()
        else {
            panic!("zero discriminant must retain one tangent latitude circle");
        };
        assert_points_equal(
            &tangent_circle.curve().start().unwrap(),
            &Point3::new(q(12, 5), Real::zero(), q(16, 5)),
        );

        let separated =
            Surface::sphere(p(0, 0, 5), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        assert!(matches!(
            separated.intersect_surface(&cone).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
        let apex_only =
            Surface::sphere(p(0, 0, -5), Vector3::x(), Vector3::y(), Vector3::z(), r(5)).unwrap();
        let SurfaceSurfaceIntersection::Point(point) = apex_only.intersect_surface(&cone).unwrap()
        else {
            panic!("the lower coaxial sphere must retain its isolated apex contact");
        };
        assert_points_equal(&point, &Point3::origin());

        let mixed_dimension =
            Surface::sphere(p(0, 0, 5), Vector3::x(), Vector3::y(), Vector3::z(), r(5)).unwrap();
        let SurfaceSurfaceIntersection::Components(components) =
            mixed_dimension.intersect_surface(&cone).unwrap()
        else {
            panic!("apex-plus-circle contact must retain both exact dimensions");
        };
        assert_eq!(components.points().len(), 1);
        assert_points_equal(&components.points()[0], &Point3::origin());
        assert!(components.curves().is_empty());
        assert_eq!(components.surface_curves().len(), 1);
        let mixed_circle = &components.surface_curves()[0];
        assert_points_equal(
            &mixed_circle.curve().start().unwrap(),
            &Point3::new(q(24, 5), Real::zero(), q(32, 5)),
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = mixed_circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &mixed_dimension
                    .point_at(&mixed_circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &cone
                    .point_at(&mixed_circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }
        let SurfaceSurfaceIntersection::Components(swapped) =
            cone.intersect_surface(&mixed_dimension).unwrap()
        else {
            panic!("operand reversal must retain both exact dimensions");
        };
        assert_eq!(swapped.points().len(), 1);
        assert!(swapped.curves().is_empty());
        assert_eq!(swapped.surface_curves().len(), 1);
        let swapped_circle = &swapped.surface_curves()[0];
        let parameter = q(1, 3);
        let spatial = swapped_circle.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &cone
                .point_at(&swapped_circle.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &mixed_dimension
                .point_at(&swapped_circle.second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        let off_axis =
            Surface::sphere(p(1, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        assert_eq!(
            off_axis.intersect_surface(&cone).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );

        let rotated_parameters =
            Surface::sphere(p(0, 0, 5), Vector3::y(), -Vector3::x(), Vector3::z(), r(5)).unwrap();
        let SurfaceSurfaceIntersection::Components(rotated) =
            cone.intersect_surface(&rotated_parameters).unwrap()
        else {
            panic!("rotated parameters must retain the exact spatial components");
        };
        assert_eq!(rotated.points().len(), 1);
        assert_eq!(rotated.curves().len(), 1);
        assert!(rotated.surface_curves().is_empty());
        assert_points_equal(&rotated.points()[0], &Point3::origin());
        assert_points_equal(
            &rotated.curves()[0].start().unwrap(),
            &Point3::new(q(24, 5), Real::zero(), q(32, 5)),
        );

        let mirrored_centered = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(2),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(mirrored_circle) =
            mirrored_centered.intersect_surface(&cone).unwrap()
        else {
            panic!("mirrored sphere/cone frames must retain both exact pcurves");
        };
        let sphere_pcurve = mirrored_circle.first_pcurve().materialize().unwrap();
        assert_eq!(
            sphere_pcurve
                .curve()
                .start()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::tau()
        );
        assert_eq!(
            sphere_pcurve
                .curve()
                .end()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::zero()
        );
        let parameter = q(2, 3);
        let spatial = mirrored_circle.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &mirrored_centered
                .point_at(&mirrored_circle.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
    }

    #[test]
    fn coaxial_cylinder_cone_intersection_retains_native_slant_circle() {
        let semi_angle = q(3, 4).atan().unwrap();
        let cone = Surface::cone(
            p(0, 0, 5),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            semi_angle,
        )
        .unwrap();
        let cylinder =
            Surface::cylinder(p(0, 0, 1), Vector3::x(), Vector3::y(), Vector3::z(), r(3)).unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) = cylinder.intersect_surface(&cone).unwrap()
        else {
            panic!("aligned coaxial cylinder/cone carriers must retain both pcurves");
        };
        assert_points_equal(
            &circle.curve().start().unwrap(),
            &Point3::new(r(3), Real::zero(), r(9)),
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &cylinder
                    .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &cone
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }
        let SurfaceSurfaceIntersection::Curve(swapped) = cone.intersect_surface(&cylinder).unwrap()
        else {
            panic!("operand reversal must retain the same native circle");
        };
        let parameter = q(2, 3);
        assert_points_equal(
            &cone
                .point_at(&swapped.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &swapped.curve().evaluate_real(&parameter).unwrap(),
        );

        let rotated_parameters =
            Surface::cylinder(p(0, 0, 1), Vector3::y(), -Vector3::x(), Vector3::z(), r(3)).unwrap();
        assert!(matches!(
            cone.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circle(_)
        ));
        let mirrored_cylinder =
            Surface::cylinder(p(0, 0, 1), Vector3::x(), -Vector3::y(), -Vector3::z(), r(3))
                .unwrap();
        let SurfaceSurfaceIntersection::Curve(mirrored_circle) =
            mirrored_cylinder.intersect_surface(&cone).unwrap()
        else {
            panic!("mirrored cylinder/cone frames must retain both exact pcurves");
        };
        let cylinder_pcurve = mirrored_circle.first_pcurve().materialize().unwrap();
        assert_eq!(
            cylinder_pcurve
                .curve()
                .start()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::tau()
        );
        assert_eq!(
            cylinder_pcurve
                .curve()
                .end()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::zero()
        );
        let parameter = q(1, 4);
        let spatial = mirrored_circle.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &mirrored_cylinder
                .point_at(&mirrored_circle.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        let off_axis =
            Surface::cylinder(p(1, 0, 1), Vector3::x(), Vector3::y(), Vector3::z(), r(3)).unwrap();
        assert_eq!(
            cone.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let skew =
            Surface::cylinder(p(0, 0, 1), Vector3::y(), Vector3::z(), Vector3::x(), r(3)).unwrap();
        assert_eq!(
            cone.intersect_surface(&skew).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_cone_intersections_retain_native_slant_circle() {
        let wide_angle = Real::one().atan().unwrap();
        let narrow_angle = q(1, 2).atan().unwrap();
        let wide = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            wide_angle.clone(),
        )
        .unwrap();
        let narrow = Surface::cone(
            Point3::new(Real::zero(), Real::zero(), q(-5, 2)),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) = wide.intersect_surface(&narrow).unwrap()
        else {
            panic!("co-oriented coaxial cones must retain their exact common circle");
        };
        assert_points_equal(
            &circle.curve().start().unwrap(),
            &Point3::new(q(5, 2), Real::zero(), q(5, 2)),
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &wide
                    .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &narrow
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }
        let SurfaceSurfaceIntersection::Curve(swapped) = narrow.intersect_surface(&wide).unwrap()
        else {
            panic!("operand reversal must retain the same exact cone circle");
        };
        let parameter = q(1, 3);
        let spatial = swapped.curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &narrow
                .point_at(&swapped.first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &wide
                .point_at(&swapped.second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let shared_apex = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Point(point) =
            wide.intersect_surface(&shared_apex).unwrap()
        else {
            panic!("different coaxial angles with one apex must meet at that apex");
        };
        assert_points_equal(&point, &Point3::origin());

        let same_geometry_rotated = Surface::cone(
            Point3::origin(),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            wide_angle.clone(),
        )
        .unwrap();
        assert!(matches!(
            wide.intersect_surface(&same_geometry_rotated).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
        let translated_parallel = Surface::cone(
            p(0, 0, 1),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            wide_angle,
        )
        .unwrap();
        assert!(matches!(
            wide.intersect_surface(&translated_parallel).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let rotated_parameters = Surface::cone(
            Point3::new(Real::zero(), Real::zero(), q(-5, 2)),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        assert!(matches!(
            wide.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circle(_)
        ));
        let off_axis = Surface::cone(
            Point3::new(Real::one(), Real::zero(), q(-5, 2)),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        assert_eq!(
            wide.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let antiparallel = Surface::cone(
            Point3::new(Real::zero(), Real::zero(), q(5, 2)),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(counteroriented) =
            wide.intersect_surface(&antiparallel).unwrap()
        else {
            panic!("facing coaxial cones must retain their exact common circle");
        };
        assert_points_equal(
            &counteroriented.curve().start().unwrap(),
            &Point3::new(q(5, 6), Real::zero(), q(5, 6)),
        );
        for parameter in [Real::zero(), Real::pi(), Real::tau()] {
            let spatial = counteroriented.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &wide
                    .point_at(&counteroriented.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &antiparallel
                    .point_at(
                        &counteroriented
                            .second_pcurve()
                            .point_at(&parameter)
                            .unwrap(),
                    )
                    .unwrap(),
                &spatial,
            );
        }
        let second_materialized = counteroriented.second_pcurve().materialize().unwrap();
        assert_eq!(
            second_materialized
                .curve()
                .start()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::tau()
        );
        assert_eq!(
            second_materialized
                .curve()
                .end()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::zero()
        );

        let opposite_shared_apex = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            narrow_angle.clone(),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Point(point) =
            wide.intersect_surface(&opposite_shared_apex).unwrap()
        else {
            panic!("opposite cones with one apex must meet at that apex");
        };
        assert_points_equal(&point, &Point3::origin());
        let opening_away = Surface::cone(
            Point3::new(Real::zero(), Real::zero(), q(-5, 2)),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            narrow_angle,
        )
        .unwrap();
        assert!(matches!(
            wide.intersect_surface(&opening_away).unwrap(),
            SurfaceSurfaceIntersection::None
        ));
    }

    #[test]
    fn coaxial_torus_intersections_retain_native_latitude_circles() {
        let first = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let second = Surface::torus(
            p(0, 0, 1),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) = first.intersect_surface(&second).unwrap()
        else {
            panic!("axially offset equal tori must retain two latitude circles");
        };
        assert_eq!(circles.len(), 2);
        let half_sqrt_three = (r(3).sqrt().unwrap() / r(2)).unwrap();
        assert_points_equal(
            &circles[0].curve().start().unwrap(),
            &Point3::new(r(3) + &half_sqrt_three, Real::zero(), q(1, 2)),
        );
        assert_points_equal(
            &circles[1].curve().start().unwrap(),
            &Point3::new(r(3) - &half_sqrt_three, Real::zero(), q(1, 2)),
        );
        for circle in &circles {
            for parameter in [Real::zero(), Real::pi()] {
                let spatial = circle.curve().evaluate_real(&parameter).unwrap();
                assert_points_equal(
                    &first
                        .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
                assert_points_equal(
                    &second
                        .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
            }
        }
        let SurfaceSurfaceIntersection::Curves(swapped) = second.intersect_surface(&first).unwrap()
        else {
            panic!("operand reversal must retain both torus latitude circles");
        };
        let parameter = q(1, 3);
        let spatial = swapped[0].curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &second
                .point_at(&swapped[0].first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &first
                .point_at(&swapped[0].second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let tangent = Surface::torus(
            p(0, 0, 2),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(tangent_circle) =
            first.intersect_surface(&tangent).unwrap()
        else {
            panic!("externally tangent torus profiles must retain one spatial circle");
        };
        assert_points_equal(&tangent_circle.curve().start().unwrap(), &p(3, 0, 1));
        let disjoint = Surface::torus(
            p(0, 0, 3),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            first.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let radial_offset = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(4),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(radial_circles) =
            first.intersect_surface(&radial_offset).unwrap()
        else {
            panic!("different coaxial major radii must intersect through profile circles");
        };
        assert_eq!(radial_circles.len(), 2);
        assert_points_equal(
            &radial_circles[0].curve().start().unwrap(),
            &Point3::new(q(7, 2), Real::zero(), -half_sqrt_three.clone()),
        );
        assert_points_equal(
            &radial_circles[1].curve().start().unwrap(),
            &Point3::new(q(7, 2), Real::zero(), half_sqrt_three),
        );

        let same_rotated = Surface::torus(
            Point3::origin(),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            first.intersect_surface(&same_rotated).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
        let nested_profile = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            q(1, 2),
        )
        .unwrap();
        assert!(matches!(
            first.intersect_surface(&nested_profile).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let mirrored = Surface::torus(
            p(0, 0, 1),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(mirrored_circles) =
            first.intersect_surface(&mirrored).unwrap()
        else {
            panic!("mirrored coaxial torus frames must retain both pcurves");
        };
        for circle in &mirrored_circles {
            let second_pcurve = circle.second_pcurve().materialize().unwrap();
            assert_eq!(
                second_pcurve
                    .curve()
                    .start()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::tau()
            );
            assert_eq!(
                second_pcurve
                    .curve()
                    .end()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::zero()
            );
            let parameter = q(2, 3);
            assert_points_equal(
                &mirrored
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &circle.curve().evaluate_real(&parameter).unwrap(),
            );
        }

        let rotated_parameters = Surface::torus(
            p(0, 0, 1),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            first.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circles(_)
        ));
        let off_axis = Surface::torus(
            p(1, 0, 1),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            first.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_sphere_torus_intersections_retain_native_latitude_circles() {
        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
        )
        .unwrap();
        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) = sphere.intersect_surface(&torus).unwrap()
        else {
            panic!("a sphere cutting both sides of a torus profile must retain two latitudes");
        };
        assert_eq!(circles.len(), 2);
        let height = (r(35).sqrt().unwrap() / r(6)).unwrap();
        assert_points_equal(
            &circles[0].curve().start().unwrap(),
            &Point3::new(q(17, 6), Real::zero(), -height.clone()),
        );
        assert_points_equal(
            &circles[1].curve().start().unwrap(),
            &Point3::new(q(17, 6), Real::zero(), height),
        );
        for circle in &circles {
            for parameter in [Real::zero(), q(2, 3), Real::pi()] {
                let spatial = circle.curve().evaluate_real(&parameter).unwrap();
                assert_points_equal(
                    &sphere
                        .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
                assert_points_equal(
                    &torus
                        .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
            }
        }
        let SurfaceSurfaceIntersection::Curves(swapped) = torus.intersect_surface(&sphere).unwrap()
        else {
            panic!("operand reversal must retain both sphere/torus latitude circles");
        };
        let parameter = q(1, 4);
        let spatial = swapped[0].curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &torus
                .point_at(&swapped[0].first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &sphere
                .point_at(&swapped[0].second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let tangent_sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(tangent) =
            tangent_sphere.intersect_surface(&torus).unwrap()
        else {
            panic!("tangent meridian profiles must retain one spatial latitude");
        };
        assert_points_equal(&tangent.curve().start().unwrap(), &p(2, 0, 0));
        for radius in [r(1), r(5)] {
            let disjoint = Surface::sphere(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                Vector3::z(),
                radius,
            )
            .unwrap();
            assert!(matches!(
                disjoint.intersect_surface(&torus).unwrap(),
                SurfaceSurfaceIntersection::None
            ));
        }

        let mirrored = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(mirrored_circles) =
            sphere.intersect_surface(&mirrored).unwrap()
        else {
            panic!("mirrored sphere/torus frames must retain both pcurves");
        };
        for circle in mirrored_circles {
            let torus_pcurve = circle.second_pcurve().materialize().unwrap();
            assert_eq!(
                torus_pcurve
                    .curve()
                    .start()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::tau()
            );
            assert_eq!(
                torus_pcurve
                    .curve()
                    .end()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::zero()
            );
            let parameter = q(5, 7);
            assert_points_equal(
                &mirrored
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &circle.curve().evaluate_real(&parameter).unwrap(),
            );
        }

        let rotated_parameters = Surface::torus(
            Point3::origin(),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            sphere.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circles(_)
        ));
        let off_axis = Surface::torus(
            p(1, 0, 0),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            sphere.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let transverse = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::z(),
            -Vector3::y(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            sphere.intersect_surface(&transverse).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_cylinder_torus_intersections_retain_native_latitude_circles() {
        let cylinder = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            q(7, 2),
        )
        .unwrap();
        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) =
            cylinder.intersect_surface(&torus).unwrap()
        else {
            panic!("a cylinder cutting both sides of a torus profile must retain two latitudes");
        };
        assert_eq!(circles.len(), 2);
        let height = (r(3).sqrt().unwrap() / r(2)).unwrap();
        assert_points_equal(
            &circles[0].curve().start().unwrap(),
            &Point3::new(q(7, 2), Real::zero(), -height.clone()),
        );
        assert_points_equal(
            &circles[1].curve().start().unwrap(),
            &Point3::new(q(7, 2), Real::zero(), height),
        );
        for circle in &circles {
            for parameter in [Real::zero(), q(3, 5), Real::pi()] {
                let spatial = circle.curve().evaluate_real(&parameter).unwrap();
                assert_points_equal(
                    &cylinder
                        .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
                assert_points_equal(
                    &torus
                        .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
            }
        }
        let SurfaceSurfaceIntersection::Curves(swapped) =
            torus.intersect_surface(&cylinder).unwrap()
        else {
            panic!("operand reversal must retain both cylinder/torus latitude circles");
        };
        let parameter = q(4, 7);
        let spatial = swapped[0].curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &torus
                .point_at(&swapped[0].first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &cylinder
                .point_at(&swapped[0].second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let tangent = Surface::cylinder(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(4),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(tangent_circle) =
            tangent.intersect_surface(&torus).unwrap()
        else {
            panic!("tangent cylinder/torus meridians must retain one latitude");
        };
        assert_points_equal(&tangent_circle.curve().start().unwrap(), &p(4, 0, 0));
        for radius in [r(1), r(5)] {
            let disjoint = Surface::cylinder(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                Vector3::z(),
                radius,
            )
            .unwrap();
            assert!(matches!(
                disjoint.intersect_surface(&torus).unwrap(),
                SurfaceSurfaceIntersection::None
            ));
        }

        let mirrored = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(mirrored_circles) =
            cylinder.intersect_surface(&mirrored).unwrap()
        else {
            panic!("mirrored cylinder/torus frames must retain both pcurves");
        };
        for circle in mirrored_circles {
            let torus_pcurve = circle.second_pcurve().materialize().unwrap();
            assert_eq!(
                torus_pcurve
                    .curve()
                    .start()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::tau()
            );
            assert_eq!(
                torus_pcurve
                    .curve()
                    .end()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::zero()
            );
            let parameter = q(6, 7);
            assert_points_equal(
                &mirrored
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &circle.curve().evaluate_real(&parameter).unwrap(),
            );
        }

        let rotated_parameters = Surface::torus(
            Point3::origin(),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            cylinder.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circles(_)
        ));
        let off_axis = Surface::torus(
            p(1, 0, 0),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            cylinder.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let transverse = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::z(),
            -Vector3::y(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            cylinder.intersect_surface(&transverse).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn coaxial_cone_torus_intersections_retain_native_latitude_circles() {
        let quarter_pi = (Real::pi() / r(4)).unwrap();
        let cone = Surface::cone(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            quarter_pi.clone(),
        )
        .unwrap();
        let torus = Surface::torus(
            p(0, 0, 3),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(circles) = cone.intersect_surface(&torus).unwrap()
        else {
            panic!("a cone cutting both sides of a torus profile must retain two latitudes");
        };
        assert_eq!(circles.len(), 2);
        let half_sqrt_two = (r(2).sqrt().unwrap() / r(2)).unwrap();
        assert_points_equal(
            &circles[0].curve().start().unwrap(),
            &Point3::new(r(3) - &half_sqrt_two, Real::zero(), r(3) - &half_sqrt_two),
        );
        assert_points_equal(
            &circles[1].curve().start().unwrap(),
            &Point3::new(r(3) + &half_sqrt_two, Real::zero(), r(3) + &half_sqrt_two),
        );
        for circle in &circles {
            for parameter in [Real::zero(), q(4, 5), Real::pi()] {
                let spatial = circle.curve().evaluate_real(&parameter).unwrap();
                assert_points_equal(
                    &cone
                        .point_at(&circle.first_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
                assert_points_equal(
                    &torus
                        .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                        .unwrap(),
                    &spatial,
                );
            }
        }
        let SurfaceSurfaceIntersection::Curves(swapped) = torus.intersect_surface(&cone).unwrap()
        else {
            panic!("operand reversal must retain both cone/torus latitude circles");
        };
        let parameter = q(3, 7);
        let spatial = swapped[0].curve().evaluate_real(&parameter).unwrap();
        assert_points_equal(
            &torus
                .point_at(&swapped[0].first_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );
        assert_points_equal(
            &cone
                .point_at(&swapped[0].second_pcurve().point_at(&parameter).unwrap())
                .unwrap(),
            &spatial,
        );

        let tangent_center_height = r(3) - r(2).sqrt().unwrap();
        let tangent = Surface::torus(
            Point3::new(Real::zero(), Real::zero(), tangent_center_height),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curve(tangent_circle) =
            cone.intersect_surface(&tangent).unwrap()
        else {
            panic!("tangent cone/torus meridians must retain one latitude");
        };
        let tangent_coordinate = r(3) - &half_sqrt_two;
        assert_points_equal(
            &tangent_circle.curve().start().unwrap(),
            &Point3::new(tangent_coordinate.clone(), Real::zero(), tangent_coordinate),
        );
        let disjoint = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            cone.intersect_surface(&disjoint).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let mirrored = Surface::torus(
            p(0, 0, 3),
            Vector3::x(),
            -Vector3::y(),
            -Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        let SurfaceSurfaceIntersection::Curves(mirrored_circles) =
            cone.intersect_surface(&mirrored).unwrap()
        else {
            panic!("mirrored cone/torus frames must retain both pcurves");
        };
        for circle in mirrored_circles {
            let torus_pcurve = circle.second_pcurve().materialize().unwrap();
            assert_eq!(
                torus_pcurve
                    .curve()
                    .start()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::tau()
            );
            assert_eq!(
                torus_pcurve
                    .curve()
                    .end()
                    .coordinates()
                    .expect("native fixture endpoint")
                    .x(),
                &Real::zero()
            );
            let parameter = q(6, 7);
            assert_points_equal(
                &mirrored
                    .point_at(&circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &circle.curve().evaluate_real(&parameter).unwrap(),
            );
        }

        let rotated_parameters = Surface::torus(
            p(0, 0, 3),
            Vector3::y(),
            -Vector3::x(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert!(matches!(
            cone.intersect_surface(&rotated_parameters).unwrap(),
            SurfaceSurfaceIntersection::Circles(_)
        ));
        let off_axis = Surface::torus(
            p(1, 0, 3),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            cone.intersect_surface(&off_axis).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
        let transverse = Surface::torus(
            p(0, 0, 3),
            Vector3::x(),
            Vector3::z(),
            -Vector3::y(),
            r(3),
            r(1),
        )
        .unwrap();
        assert_eq!(
            cone.intersect_surface(&transverse).unwrap_err(),
            GeometryError::UnsupportedIntersection
        );
    }

    #[test]
    fn plane_sphere_and_sphere_sphere_intersections_retain_exact_circles() {
        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        let equator = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Curve(circle) = equator.intersect_surface(&sphere).unwrap()
        else {
            panic!("equatorial plane must retain a circle with both exact pcurves");
        };
        assert_eq!(circle.curve().kind(), Curve3Kind::CircleArc);
        assert_points_equal(&circle.curve().start().unwrap(), &p(2, 0, 0));
        assert_eq!(
            circle
                .first_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::CircularArc
        );
        assert_eq!(
            circle
                .second_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::Line
        );
        let SurfaceSurfaceIntersection::Curve(swapped) =
            sphere.intersect_surface(&equator).unwrap()
        else {
            panic!("operand reversal must retain the same exact sphere latitude");
        };
        assert_eq!(
            swapped
                .first_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::Line
        );
        assert_eq!(
            swapped
                .second_pcurve()
                .materialize()
                .unwrap()
                .curve()
                .family(),
            CurveFamily2::CircularArc
        );

        let tangent_plane = Surface::plane(p(0, 0, 2), Vector3::x(), Vector3::y()).unwrap();
        let SurfaceSurfaceIntersection::Point(point) =
            sphere.intersect_surface(&tangent_plane).unwrap()
        else {
            panic!("tangent plane must produce one point");
        };
        assert_points_equal(&point, &p(0, 0, 2));
        let disjoint_plane = Surface::plane(p(0, 0, 3), Vector3::x(), Vector3::y()).unwrap();
        assert!(matches!(
            sphere.intersect_surface(&disjoint_plane).unwrap(),
            SurfaceSurfaceIntersection::None
        ));

        let second =
            Surface::sphere(p(2, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Circle(circle) = sphere.intersect_surface(&second).unwrap()
        else {
            panic!("overlapping spheres must produce a circle");
        };
        let point = circle.start().unwrap();
        assert_eq!(
            compare_reals(&point.x, &r(1), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        let first_radius_squared = Vector3::from(point.clone()).norm_squared();
        let second_radius_squared = (&point - &p(2, 0, 0)).norm_squared();
        assert_eq!(
            compare_reals(&first_radius_squared, &r(4), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );
        assert_eq!(
            compare_reals(&second_radius_squared, &r(4), crate::STRICT_PREDICATES).value(),
            Some(Ordering::Equal)
        );

        let axial_second =
            Surface::sphere(p(0, 0, 2), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Curve(axial_circle) =
            sphere.intersect_surface(&axial_second).unwrap()
        else {
            panic!("authored-axis sphere centers must retain both latitude pcurves");
        };
        assert_points_equal(
            &axial_circle.curve().start().unwrap(),
            &Point3::new(r(3).sqrt().unwrap(), Real::zero(), Real::one()),
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = axial_circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &sphere
                    .point_at(&axial_circle.first_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
            assert_points_equal(
                &axial_second
                    .point_at(&axial_circle.second_pcurve().point_at(&parameter).unwrap())
                    .unwrap(),
                &spatial,
            );
        }

        let mirrored_second =
            Surface::sphere(p(0, 0, 2), Vector3::x(), -Vector3::y(), -Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Curve(mirrored_circle) =
            sphere.intersect_surface(&mirrored_second).unwrap()
        else {
            panic!("mirrored sphere frames must retain reversed longitude");
        };
        let second_pcurve = mirrored_circle.second_pcurve().materialize().unwrap();
        assert_eq!(
            second_pcurve
                .curve()
                .start()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::tau()
        );
        assert_eq!(
            second_pcurve
                .curve()
                .end()
                .coordinates()
                .expect("native fixture endpoint")
                .x(),
            &Real::zero()
        );
        for parameter in [Real::zero(), Real::pi()] {
            let spatial = mirrored_circle.curve().evaluate_real(&parameter).unwrap();
            assert_points_equal(
                &mirrored_second
                    .point_at(
                        &mirrored_circle
                            .second_pcurve()
                            .point_at(&parameter)
                            .unwrap(),
                    )
                    .unwrap(),
                &spatial,
            );
        }

        let rotated_second =
            Surface::sphere(p(0, 0, 2), Vector3::y(), -Vector3::x(), Vector3::z(), r(2)).unwrap();
        assert!(matches!(
            sphere.intersect_surface(&rotated_second).unwrap(),
            SurfaceSurfaceIntersection::Circle(_)
        ));

        let tangent =
            Surface::sphere(p(4, 0, 0), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        let SurfaceSurfaceIntersection::Point(point) = sphere.intersect_surface(&tangent).unwrap()
        else {
            panic!("tangent spheres must produce one point");
        };
        assert_points_equal(&point, &p(2, 0, 0));
        assert!(matches!(
            sphere.intersect_surface(&sphere).unwrap(),
            SurfaceSurfaceIntersection::Coincident
        ));
    }

    #[test]
    fn analytic_surfaces_use_exact_domains_evaluation_and_partials() {
        let cylinder =
            Surface::cylinder(p(1, 2, 3), Vector3::x(), Vector3::y(), Vector3::z(), r(2)).unwrap();
        assert_eq!(cylinder.kind(), SurfaceKind::Cylinder);
        assert_points_equal(
            &cylinder.point_at(&Point2::new(r(0), r(5))).unwrap(),
            &p(3, 2, 8),
        );
        let partials = cylinder.partials_at(&Point2::new(r(0), r(5))).unwrap();
        assert_points_equal(&Point3::from(partials.u().clone()), &p(0, 2, 0));
        assert_points_equal(&Point3::from(partials.v().clone()), &p(0, 0, 1));

        let sphere = Surface::sphere(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(2),
        )
        .unwrap();
        assert_points_equal(
            &sphere.point_at(&Point2::new(r(0), r(0))).unwrap(),
            &p(2, 0, 0),
        );
        let partials = sphere.partials_at(&Point2::new(r(0), r(0))).unwrap();
        assert_points_equal(&Point3::from(partials.u().clone()), &p(0, 2, 0));
        assert_points_equal(&Point3::from(partials.v().clone()), &p(0, 0, 2));
        assert_points_equal(
            &Point3::from(sphere.normal_at(&Point2::new(r(0), r(0))).unwrap()),
            &p(1, 0, 0),
        );
        assert_eq!(
            sphere
                .normal_at(&Point2::new(r(0), (Real::pi() / r(2)).unwrap()))
                .unwrap_err(),
            GeometryError::SingularSurfaceParameter
        );
        assert_eq!(
            sphere.point_at(&Point2::new(r(0), Real::pi())).unwrap_err(),
            GeometryError::SurfaceParameterOutsideDomain
        );

        let cone = Surface::cone(
            p(1, 2, 3),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            (Real::pi() / r(4)).unwrap(),
        )
        .unwrap();
        assert_points_equal(
            &cone.point_at(&Point2::new(r(7), r(0))).unwrap(),
            &p(1, 2, 3),
        );
        assert_eq!(
            cone.normal_at(&Point2::new(r(7), r(0))).unwrap_err(),
            GeometryError::SingularSurfaceParameter
        );
        assert_eq!(
            cone.point_at(&Point2::new(r(0), r(-1))).unwrap_err(),
            GeometryError::SurfaceParameterOutsideDomain
        );

        let torus = Surface::torus(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            Vector3::z(),
            r(4),
            r(1),
        )
        .unwrap();
        assert_points_equal(
            &torus.point_at(&Point2::new(r(0), r(0))).unwrap(),
            &p(5, 0, 0),
        );
    }

    #[test]
    fn analytic_surface_constructors_reject_invalid_exact_geometry() {
        assert_eq!(
            Surface::cylinder(
                Point3::origin(),
                Vector3::x(),
                Vector3::x(),
                Vector3::z(),
                r(1),
            )
            .unwrap_err(),
            GeometryError::InvalidSurfaceFrame
        );
        assert_eq!(
            Surface::sphere(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                Vector3::z(),
                r(0),
            )
            .unwrap_err(),
            GeometryError::InvalidRadius
        );
        assert_eq!(
            Surface::torus(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                Vector3::z(),
                r(2),
                r(2),
            )
            .unwrap_err(),
            GeometryError::InvalidTorusRadii
        );
    }

    #[test]
    fn named_circle_and_ellipse_arcs_retain_exact_angle_semantics() {
        let half_pi = (Real::pi() / r(2)).unwrap();
        let circle = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(2),
            Real::zero(),
            half_pi.clone(),
        )
        .unwrap();
        assert_eq!(circle.kind(), Curve3Kind::CircleArc);
        assert_points_equal(&circle.start().unwrap(), &p(2, 0, 0));
        assert_points_equal(&circle.end().unwrap(), &p(0, 2, 0));
        assert_points_equal(
            &Point3::from(
                circle
                    .derivative_at(&Real::zero(), 1)
                    .unwrap()
                    .vector()
                    .clone(),
            ),
            &p(0, 2, 0),
        );
        let reversed = circle.reversed().unwrap();
        assert_points_equal(&reversed.start().unwrap(), &circle.end().unwrap());
        assert_points_equal(&reversed.end().unwrap(), &circle.start().unwrap());
        let split = (half_pi.clone() / r(2)).unwrap();
        let (left, right) = circle.split_at(&split).unwrap();
        assert!(left.shares_parameterization(&circle));
        assert!(right.shares_parameterization(&circle));
        assert!(left.has_certified_same_parameterization(&right));
        assert_points_equal(&left.end().unwrap(), &right.start().unwrap());
        let retained = circle.subcurve(&split, &half_pi).unwrap();
        assert!(retained.shares_parameterization(&circle));
        let independently_constructed = Curve3::circle_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(2),
            Real::zero(),
            (Real::pi() / r(2)).unwrap(),
        )
        .unwrap();
        assert!(circle.has_certified_same_parameterization(&independently_constructed));

        let ellipse = Curve3::ellipse_arc(
            Point3::origin(),
            Vector3::x(),
            Vector3::y(),
            r(3),
            r(2),
            Real::zero(),
            half_pi,
        )
        .unwrap();
        assert_eq!(ellipse.kind(), Curve3Kind::EllipseArc);
        assert_points_equal(&ellipse.start().unwrap(), &p(3, 0, 0));
        assert_points_equal(&ellipse.end().unwrap(), &p(0, 2, 0));

        assert_eq!(
            Curve3::circle_arc(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                r(1),
                Real::zero(),
                r(3) * Real::pi(),
            )
            .unwrap_err(),
            GeometryError::InvalidArcSweep
        );
    }
}
