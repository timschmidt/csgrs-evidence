#[allow(dead_code)]
#[path = "support/cone_exchange.rs"]
mod acceptance;

#[test]
fn full_size_cone_exchange_preserves_repeated_modeling_and_empty_recovery() {
    acceptance::complete_workflows();
}
#[test]
fn nonterminating_apex_uses_finite_anchor_and_exact_source_parameter_map() {
    acceptance::shifted_apex_and_units();
}
#[test]
fn independent_manual_revolutions_import_and_reexport_without_fitting() {
    acceptance::manual_line_inputs();
}
