#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/section_differentials.rs"]
mod acceptance;
fn cases() -> [(&'static str, fn());6] {[
("regular_sections_restriction_transform_and_replay",acceptance::regular_sections_restriction_transform_and_replay),
("selected_parameters_and_native_spatial_vectors",acceptance::selected_parameters_and_native_spatial_vectors),
("cubic_and_projective_section_jets",acceptance::cubic_and_projective_section_jets),
("smooth_vertical_events_and_singular_frontiers",acceptance::smooth_vertical_events_and_singular_frontiers),
("resource_domain_guards_and_policy_recovery",acceptance::resource_domain_guards_and_policy_recovery),
("selected_parallel_vector_signs",acceptance::selected_parallel_vector_signs),
]}
