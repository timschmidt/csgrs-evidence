include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn regular_sections_restriction_transform_and_replay()->u32 {cases()[0].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn selected_parameters_and_native_spatial_vectors()->u32 {cases()[1].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn cubic_and_projective_section_jets()->u32 {cases()[2].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn smooth_vertical_events_and_singular_frontiers()->u32 {cases()[3].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn resource_domain_guards_and_policy_recovery()->u32 {cases()[4].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn selected_parallel_vector_signs()->u32 {cases()[5].1();1}
