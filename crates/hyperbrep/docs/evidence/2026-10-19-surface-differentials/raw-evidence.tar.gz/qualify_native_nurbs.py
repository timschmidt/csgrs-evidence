from pathlib import Path
import hashlib,json,shutil
import run
O=run.OUT;D=O/'native-nurbs'
assert run.run(dict(label='native-nurbs-format',command=['cargo','fmt','--manifest-path',str(D/'Cargo.toml')],seconds=300))==0
source={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(D.iterdir()) if p.is_file()}
(O/'native-nurbs-source.json').write_text(json.dumps(source,indent=2)+'\n')
pkg='hyperbrep-surface-differential-native-nurbs'
assert run.run(dict(label='native-nurbs-native-build',command=['cargo','build','--offline','--locked','--release','--manifest-path',str(D/'Cargo.toml'),'--bin',pkg],seconds=2400))==0
shutil.copy2(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,O/'bin/native-nurbs-new')
assert run.run(dict(label='native-nurbs-native-run',command=[str(O/'bin/native-nurbs-new'),'all'],env={'HYPERBREP_SURFACE_DIFFERENTIAL_ARTIFACT_DIR':str(O/'artifacts/new')},seconds=1200))==0
assert run.run(dict(label='native-nurbs-wasm-build',command=['cargo','build','--offline','--locked','--release','--target','wasm32-unknown-unknown','--manifest-path',str(D/'Cargo.toml'),'--lib'],env={'CARGO_TARGET_DIR':'/tmp/hyperbrep-review-wasm-target'},seconds=2400))==0
assert run.run(dict(label='native-nurbs-wasm-run',command=['python3','-B',str(O/'wasm_consumer.py'),'/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_surface_differential_native_nurbs.wasm','1',str(O/'native-nurbs-exports.json')],seconds=1200))==0
