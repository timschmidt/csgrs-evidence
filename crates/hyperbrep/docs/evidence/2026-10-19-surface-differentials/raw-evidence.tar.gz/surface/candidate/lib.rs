include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn joint_forms()->u32 {cases()[0].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn transformed_forms()->u32 {cases()[1].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn native_forms()->u32 {cases()[2].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn tensor_images()->u32 {cases()[3].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn procedural_images()->u32 {cases()[4].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn policy_admission()->u32 {cases()[5].1(); 1}

#[unsafe(no_mangle)]
pub extern "C" fn knot_domains()->u32 {cases()[6].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn affine_families()->u32 {cases()[7].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn affine_admission()->u32 {cases()[8].1(); 1}
#[unsafe(no_mangle)]
pub extern "C" fn field_resources()->u32 {cases()[9].1(); 1}
