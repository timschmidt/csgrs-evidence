#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/surface_differentials.rs"]
mod acceptance;
fn cases()->[(&'static str,fn());7] {[
("complete_circle_extrusions_and_both_pcurve_consumers",acceptance::complete_circle_extrusions_and_both_pcurve_consumers),
("cubic_and_projective_chain_rules",acceptance::cubic_and_projective_chain_rules),
("selected_tensors_normals_and_native_knot_charts",acceptance::selected_tensors_normals_and_native_knot_charts),
("native_vector_algebra_affine_transport_and_replay",acceptance::native_vector_algebra_affine_transport_and_replay),
("selected_parallel_oriented_unit_normals",acceptance::selected_parallel_oriented_unit_normals),
("singular_domains_policy_and_budget_recovery",acceptance::singular_domains_policy_and_budget_recovery),
("nonsmooth_knot_ownership_and_reflected_surface_normals",acceptance::nonsmooth_knot_ownership_and_reflected_surface_normals),
]}
