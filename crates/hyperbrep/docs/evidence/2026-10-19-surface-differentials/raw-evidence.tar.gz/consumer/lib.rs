include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn complete_circle_extrusions_and_both_pcurve_consumers()->u32 {cases()[0].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn cubic_and_projective_chain_rules()->u32 {cases()[1].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn selected_tensors_normals_and_native_knot_charts()->u32 {cases()[2].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn native_vector_algebra_affine_transport_and_replay()->u32 {cases()[3].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn selected_parallel_oriented_unit_normals()->u32 {cases()[4].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn singular_domains_policy_and_budget_recovery()->u32 {cases()[5].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn nonsmooth_knot_ownership_and_reflected_surface_normals()->u32 {cases()[6].1();1}
