pub fn nonsmooth_knot_ownership_and_reflected_surface_normals() {
    // A continuous piecewise-linear graph, with a slope discontinuity at u=3.
    // The authored parameter domain is [2,5] x [-4,3].
    let controls = [0,7].into_iter().map(|y| vec![
        Point3::new(0.into(), y.into(), 0.into()),
        Point3::new(1.into(), y.into(), 1.into()),
        Point3::new(2.into(), y.into(), 3.into()),
    ]).collect::<Vec<_>>();
    let make = |net| Surface::nurbs(1,1,net,vec![vec![1.into();3];2],vec![2.into(),2.into(),3.into(),5.into(),5.into()],vec![(-4).into(),(-4).into(),3.into(),3.into()]).unwrap();
    let surface=make(controls.clone());
    let transform=shear(); // det < 0; authored Ru x Rv includes the reflection.
    let reflected=make(controls.iter().map(|row|row.iter().map(|p|transform.transform_point3(p).unwrap()).collect()).collect());
    let parameter=selected_parameter().curve_parameter();
    let gap=(Real::one()/Real::from(1_000_000_000_000u64)).unwrap();
    for (u,slope) in [(2.into(),Real::one()),(Real::from(3)-&gap,Real::one()),(3.into(),q(1,2)),(Real::from(3)+&gap,q(1,2)),(5.into(),q(1,2))] {
        let uv=parameter.affine_point(0.into(),u,7.into(),(-4).into()).unwrap();
        let expected_u=GeometricVector3::from_coordinates(Vector3::new([slope,0.into(),1.into()]));
        let expected_v=real_vector(0,1,0);
        let partials=surface.partials_at(&uv).unwrap();
        assert!(partials.u().equals(&expected_u).unwrap());
        assert!(partials.v().equals(&expected_v).unwrap());
        let normal=surface.normal_at(&uv).unwrap();
        assert!(normal.equals(&expected_u.cross(&expected_v).unwrap().normalized().unwrap()).unwrap());
        unit_and_orthogonal(&partials,&normal);
        let transformed=reflected.partials_at(&uv).unwrap();
        let ru=expected_u.affine_image(&transform).unwrap();
        let rv=expected_v.affine_image(&transform).unwrap();
        assert!(transformed.u().equals(&ru).unwrap());
        assert!(transformed.v().equals(&rv).unwrap());
        let reflected_normal=reflected.normal_at(&uv).unwrap();
        assert!(reflected_normal.equals(&ru.cross(&rv).unwrap().normalized().unwrap()).unwrap());
        unit_and_orthogonal(&transformed,&reflected_normal);
        assert!(!reflected_normal.equals(&normal.affine_image(&transform).unwrap().normalized().unwrap()).unwrap());
    }
    let uv=parameter.affine_point(0.into(),3.into(),7.into(),(-4).into()).unwrap();
    assert!(replay(&surface,"nonsmooth-knot").normal_at(&uv).unwrap().equals(&surface.normal_at(&uv).unwrap()).unwrap());
    assert!(replay(&reflected,"reflected-nonsmooth-knot").normal_at(&uv).unwrap().equals(&reflected.normal_at(&uv).unwrap()).unwrap());
}
