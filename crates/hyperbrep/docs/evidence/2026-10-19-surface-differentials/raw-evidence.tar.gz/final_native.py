from pathlib import Path
import runpy
O=Path(__file__).resolve().parent
for name in ['qualify.py','qualify_consumers.py']:
 runpy.run_path(str(O/name),run_name='__main__')
