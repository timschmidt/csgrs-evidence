from pathlib import Path
import hashlib,json,shutil,subprocess
O=Path(__file__).resolve().parent
P=Path('/tmp/hyperbrep-section-differentials-20261019')
R=Path('/mnt/development/csgrs/target/hyperbrep-development');B=Path('/mnt/development/csgrs')
D=B/'crates/hyperbrep/docs/evidence/2026-10-19-section-differentials'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()=='82f31d335545510a5e5934e49e64540dda825295'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
manifest=json.loads((D/'candidate-source.json').read_text())
assert all(sha(B/n)==v for n,v in manifest['files'].items())
sizes=json.loads((D/'binary-sizes.json').read_text());rows=[]
(O/'bin').mkdir(exist_ok=True)
families={**{f:(f+'/candidate',f+'-candidate') for f in ['preserved','prior','surface','branches','plane']},'differentials':('consumer','new'),'similarity':('similarity','similarity-new')}
for family,(recipe,binary) in families.items():
 src=P/'bin'/binary
 assert sha(src)==sizes[binary]['sha256'] and src.stat().st_size==sizes[binary]['bytes']
 dest=O/'bin'/(family+'-baseline');assert not dest.exists();shutil.copy2(src,dest)
 rows.append(dict(family=family,prior_binary=str(src),copied_binary=str(dest),sha256=sha(dest),bytes=dest.stat().st_size,source_manifest_verified=True))
 target=O/family/'candidate';target.mkdir(parents=True)
 for file in (P/recipe).iterdir():
  if file.is_file() and file.suffix in ['.rs','.toml','.lock']:
   text=file.read_text().replace(str(P),str(O))
   if file.name in ['Cargo.toml','Cargo.lock']:
    old=json.loads(json.dumps(sizes)) # no dependency change; only package name below
    import re
    if file.name=='Cargo.toml':
     package=re.search(r'\[package\]\s*name = "([^"]+)"',text)[1]
     replacement='hyperbrep-surface-differential-'+family+'-candidate'
    text=text.replace(package,replacement).replace(package.replace('-','_'),replacement.replace('-','_'))
   (target/file.name).write_text(text)
(O/'reused-baseline-binaries.json').write_text(json.dumps(dict(baseline='82f31d335545510a5e5934e49e64540dda825295',prior_evidence=str(D),matched_source_files=len(manifest['files']),binaries=rows),indent=2)+'\n')
print('Verified and copied',len(rows),'baselines; original sealed evidence unchanged')
