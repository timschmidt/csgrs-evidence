include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn native_nurbs_differentials() -> u32 {
    run_native_nurbs_differentials();
    1
}
