from pathlib import Path
import run,shutil
O=run.OUT
artifact_env={
 'preserved':lambda side:{'HYPERBREP_BRANCH_ARTIFACTS':str(O/'artifacts'/side),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(O/'artifacts'/('fibers-'+side))},
 'prior':lambda side:{'HYPERBREP_SURFACE_EVALUATION_ARTIFACT_DIR':str(O/'artifacts'/('prior-'+side))},
 'surface':lambda side:{'HYPERBREP_RATIONAL_SURFACE_ARTIFACT_DIR':str(O/'artifacts'/('surface-'+side))},
 'branches':lambda side:{'HYPERBREP_POLYNOMIAL_REPLAY_ARTIFACT_DIR':str(O/'artifacts'/('branches-'+side))},
 'plane':lambda side:{'HYPERBREP_PLANE_TENSOR_ARTIFACT_DIR':str(O/'artifacts'/('plane-'+side))},
 'differentials':lambda side:{'HYPERBREP_SECTION_DIFFERENTIAL_ARTIFACT_DIR':str(O/'artifacts'/('differentials-'+side))},
 'similarity':lambda side:{'HYPERBREP_SECTION_DIFFERENTIAL_ARTIFACT_DIR':str(O/'artifacts'/('differentials-'+side))},
}
for family in artifact_env:
 for side in ['baseline','candidate']:
  if side=='candidate':
   pkg='hyperbrep-surface-differential-'+family+'-candidate'
   assert run.run(dict(label=family+'-candidate-build',command=['cargo','build','--offline','--locked','--release','--manifest-path',str(O/family/'candidate/Cargo.toml'),'--bin',pkg],seconds=2400))==0
   shutil.copy2(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,O/'bin'/(family+'-candidate'))
  assert run.run(dict(label=family+'-'+side+'-archives',command=[str(O/'bin'/(family+'-'+side)),'all'],env=artifact_env[family](side),seconds=2400))==0
pkg='hyperbrep-surface-differential-consumer'
assert run.run(dict(label='new-native-build',command=['cargo','build','--offline','--locked','--release','--manifest-path',str(O/'consumer/Cargo.toml'),'--bin',pkg],seconds=2400))==0
shutil.copy2(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,O/'bin/new')
assert run.run(dict(label='new-native-archives',command=[str(O/'bin/new'),'all'],env={'HYPERBREP_SURFACE_DIFFERENTIAL_ARTIFACT_DIR':str(O/'artifacts/new')},seconds=2400))==0
assert run.run(dict(label='candidate-baseline-success-probe',command=['cargo','run','--offline','--release','--manifest-path',str(O/'candidate-probe/Cargo.toml')],seconds=2400))==0
