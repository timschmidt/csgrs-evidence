include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn whole_branches()->u32 {cases()[0].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn selected_restrictions()->u32 {cases()[1].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn singular_and_tiny()->u32 {cases()[2].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn untrusted_admission()->u32 {cases()[3].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn policy_recovery()->u32 {cases()[4].1();1}
