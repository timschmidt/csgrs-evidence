#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/polynomial_replay.rs"]
mod acceptance;
fn cases() -> [(&'static str,fn());5] { [
("whole_branches",acceptance::complete_branches_compose_and_replay),
("selected_restrictions",acceptance::selected_noncircular_restrictions_and_source_controls),
("singular_and_tiny",acceptance::singular_disconnected_and_tiny_branches_replay),
("untrusted_admission",acceptance::untrusted_branch_definitions_and_predecode_limits),
("policy_recovery",acceptance::branch_replay_policy_budget_and_recovery),
] }
