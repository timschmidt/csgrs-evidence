from pathlib import Path
import hashlib,json,subprocess
import run
O=run.OUT;R=run.ROOT;B=Path('/mnt/development/csgrs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compact=lambda s:subprocess.check_output(['rustfmt','--edition','2024','--config','skip_children=true','--emit','stdout'],input=s,cwd=R,env=run.ENV,text=True)
def partial_views(s):
 for axis in ['u','v']:
  s=s.replace('partials.'+axis+'().clone()', 'partials.'+axis+'().try_coordinates().unwrap().clone()')
  s=s.replace('partials.'+axis+'().0', 'partials.'+axis+'().try_coordinates().unwrap().0')
 return s
def named(s,method,name):
 return s.replace(f'.{method}(&{name})',f'.{method}(&hypercurve::Point2::new({name}.x.clone(), {name}.y.clone()).into())')
n='crates/hyperbrep/src/geometry.rs'
a=(B/n).read_text();b=(R/n).read_text();marker='#[cfg(test)]\nmod tests {'
a=a[a.index(marker):];b=b[b.index(marker):]
for name in ['parameter','middle']:a=named(a,'partials_at',name)
for method,args in [('partials_at','r(0), r(5)'),('partials_at','r(0), r(0)'),('normal_at','r(0), r(0)'),('normal_at','r(0), (Real::pi() / r(2)).unwrap()'),('normal_at','r(7), r(0)')]:
 a=a.replace(f'.{method}(&Point2::new({args}))',f'.{method}(&hypercurve::Point2::new({args}).into())')
a=partial_views(a)
s='sphere.normal_at(&hypercurve::Point2::new(r(0), r(0)).into()).unwrap()';a=a.replace(s,s+'.try_coordinates().unwrap().clone()')
assert compact(a)==compact(b),n
migrated=[]
n='crates/hyperbrep/tests/conical_revolution.rs';a=(B/n).read_text()
for method,name in [('partials_at','native'),('normal_at','native'),('normal_at','at_apex')]:a=named(a,method,name)
a=partial_views(a);s='.normal_at(&hypercurve::Point2::new(native.x.clone(), native.y.clone()).into()).unwrap()';a=a.replace(s,s+'.try_coordinates().unwrap().clone()')
assert compact(a)==compact((R/n).read_text()),n;migrated.append(n)
n='crates/hyperbrep-io/tests/step_write_geometry.rs';a=(B/n).read_text().replace('Orientation, Point2,','Orientation,')
a=a.replace('.normal_at(&Point2::new(Real::zero(), Real::zero()))','.normal_at(&hypercurve::Point2::new(Real::zero(), Real::zero()).into())').replace('normal.dot(&authored)','normal.dot(authored.try_coordinates().unwrap())')
assert compact(a)==compact((R/n).read_text()),n;migrated.append(n)
n='crates/hyperbrep-io/tests/support/analytic_export.rs';a=(B/n).read_text()
for name in ['uv','native_uv']:
 a=a.replace(f'.normal_at(&{name}).unwrap()',f'.normal_at(&hypercurve::Point2::new({name}.x.clone(), {name}.y.clone()).into()).unwrap().try_coordinates().unwrap().clone()')
assert compact(a)==compact((R/n).read_text()),n;migrated.append(n)
files=subprocess.check_output(['git','ls-files','crates/hyperbrep/tests','crates/hyperbrep-io/tests','crates/hypercurve/tests'],cwd=B,text=True).splitlines();unchanged={}
for n in files:
 if n in migrated:continue
 assert (B/n).read_bytes()==(R/n).read_bytes(),n
 unchanged[n]=sha(R/n)
result=dict(api_only_test_migrations=migrated,unit_geometry_assertions='All original bodies preserved by the exact declared joint-UV and optional-coordinate migration.',unchanged_existing_test_files=len(unchanged),unchanged_files=unchanged,new_acceptance=['crates/hyperbrep/tests/support/surface_differentials.rs','crates/hypercurve/tests/support/joint_form_arithmetic.rs'],assertions_removed=0,previous_full_fixtures_preserved=True)
(O/'fixture-migration.json').write_text(json.dumps(result,indent=2)+'\n')
print('Preserved',len(unchanged),'existing test files; three mechanical migrations and unchanged geometry unit assertions.')
