from pathlib import Path
import json,tomllib
O=Path(__file__).resolve().parent;P=Path('/tmp/hyperbrep-section-differentials-20261019');R=Path('/mnt/development/csgrs/target/hyperbrep-development')
names=['complete_circle_extrusions_and_both_pcurve_consumers','cubic_and_projective_chain_rules','selected_tensors_normals_and_native_knot_charts','native_vector_algebra_affine_transport_and_replay','selected_parallel_oriented_unit_normals','singular_domains_policy_and_budget_recovery','nonsmooth_knot_ownership_and_reflected_surface_normals']
target=O/'consumer';target.mkdir()
old=tomllib.loads((P/'consumer/Cargo.toml').read_text())['package']['name'];new='hyperbrep-surface-differential-consumer'
for name in ['Cargo.toml','Cargo.lock','main.rs']:
 s=(P/'consumer'/name).read_text().replace(old,new).replace(old.replace('-','_'),new.replace('-','_'))
 (target/name).write_text(s)
cases=f'#[path = "{R}/crates/hyperbrep/tests/support/surface_differentials.rs"]\nmod acceptance;\nfn cases()->[(&\'static str,fn());{len(names)}] {{[\n'+''.join(f'("{n}",acceptance::{n}),\n' for n in names)+']}\n'
(target/'cases.rs').write_text(cases)
(target/'lib.rs').write_text('include!("cases.rs");\n'+''.join(f'#[unsafe(no_mangle)]\npub extern "C" fn {n}()->u32 {{cases()[{i}].1();1}}\n' for i,n in enumerate(names)))
(O/'wasm-exports.json').write_text(json.dumps([[n,1] for n in names],indent=2)+'\n')
(O/'wasm_consumer.py').write_bytes((P/'wasm_consumer.py').read_bytes())
target=O/'candidate-probe';target.mkdir()
manifest=(O/'baseline-probe/Cargo.toml').read_text().replace('hyperbrep-surface-differential-baseline','hyperbrep-surface-differential-candidate').replace('/mnt/development/csgrs/crates',str(R/'crates'))+'hypercurve={path="'+str(R/'crates/hypercurve')+'"}\n'
(target/'Cargo.toml').write_text(manifest)
s=(O/'baseline-probe/main.rs').read_text().replace('let uv=Point2::new(t,q(1,3));','let uv=hypercurve::Point2::new(t,q(1,3)).into();')
assert s!=(O/'baseline-probe/main.rs').read_text()
(target/'main.rs').write_text(s)
print('Prepared seven standalone surface workflows and direct migrated baseline probe')
