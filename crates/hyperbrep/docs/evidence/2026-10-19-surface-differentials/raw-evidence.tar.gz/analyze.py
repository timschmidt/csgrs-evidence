"""Audit immutable final checks and matched complete workflows; never execute tests here."""
from pathlib import Path
import collections,hashlib,json,re,statistics,subprocess
O=Path(__file__).resolve().parent;R=Path('/mnt/development/csgrs/target/hyperbrep-development');B=Path('/mnt/development/csgrs');P=Path('/tmp/hyperbrep-section-differentials-20261019')
D=B/'crates/hyperbrep/docs/evidence/2026-10-19-section-differentials'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):
 p=O/name;assert not p.exists(),p;p.write_text(json.dumps(data,indent=2)+'\n')
results=json.loads((O/'results.json').read_text());by={r['label']:r for r in results};assert len(by)==len(results)
for r in results:
 assert sha(Path(r['log']))==r['log_sha256'] and sha(Path(r['source_patch']))==r['source_patch_sha256'],r['label']
 assert r['revision_unchanged']
families=['preserved','prior','surface','branches','plane','differentials','similarity']
required=['final-freeze','final-affected-clippy','final-owner-regressions','final-owner-rational-maps','final-owner-derivatives','final-brep-release-tests','final-affected-rustdoc','final-brep-fuzz-check','final-fmt-check','final-fuzz-fmt','final-fixture-migration-audit','final-wasm-build','final-wasm-run','new-native-build','new-native-archives','candidate-baseline-success-probe']
for f in families:required += [f+'-candidate-build',f+'-baseline-archives',f+'-candidate-archives']
required += ['native-nurbs-v2-format','native-nurbs-v2-native-build','native-nurbs-v2-native-run','native-nurbs-v2-wasm-build','native-nurbs-v2-wasm-run']
for n in required:assert by[n]['exit_code']==0,n
for n,h in json.loads((O/'native-nurbs-source.json').read_text()).items():assert sha(O/n)==h,n
assert by['native-nurbs-native-build']['exit_code']==101
wasm_runs=[]
for label,expected,filename in [('final-wasm-run',7,'hyperbrep_surface_differential_consumer.wasm'),('native-nurbs-v2-wasm-run',1,'hyperbrep_surface_differential_native_nurbs.wasm')]:
 entries=[json.loads(line) for line in (O/(label+'.log')).read_text().splitlines() if line.startswith('{')]
 entry=entries[-1]
 assert entry['groups']==expected and len(entry['exports'])==expected and entry['imports']==0,label
 binary=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release')/filename
 assert entry['sha256']==sha(binary) and entry['bytes']==binary.stat().st_size,label
 wasm_runs.append(dict(label=label,**entry))
for label,count in [('new-native-archives',7),('native-nurbs-v2-native-run',1)]:
 assert len(re.findall(r'^case=\S+ outcome=passed$',(O/(label+'.log')).read_text(),re.M))==count,label
assert by['baseline-extrusion-differential-closure']['exit_code']==101
assert 'surface-new-tests-2' in by,'drain the original contained prototype run before qualification finishes'
frozen=json.loads((O/'candidate-source.json').read_text())
for n,h in frozen['files'].items():assert sha(R/n)==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==frozen['baseline']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==frozen['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
save('verification.json',dict(baseline=frozen['baseline'],frozen_source_files=len(frozen['files']),source_unchanged=True,supplement_source='native-nurbs-source.json',new_native_and_wasm_workflows=8,wasm_runs=wasm_runs,main_clean_and_frozen=True,qualifying_labels=required,commands=[{k:r[k] for k in ['label','command','exit_code','elapsed_seconds','log_sha256','source_patch_sha256']} for r in results],retained_nonzero_diagnostics=[r['label'] for r in results if r['exit_code']],scope='Affected owner and downstream qualification only; not the full pre-push workflow matrix. Prototype failures and corrected test assumptions remain recorded.'))
pattern=re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s')
summary={}
for label in ['final-owner-regressions','final-owner-rational-maps','final-owner-derivatives','final-brep-release-tests']:
 rows=pattern.findall((O/(label+'.log')).read_text());assert rows,label
 assert all(x[0]=='ok' and int(x[2])==0 for x in rows),label
 summary[label]=dict(batches=len(rows),**{key:sum(int(x[i]) for x in rows) for i,key in enumerate(['passed','failed','ignored','measured','filtered_out'],1)})
save('test-summary.json',summary)
prior=json.loads((D/'archive-comparison.json').read_text());expect=collections.defaultdict(dict)
for r in prior['comparisons']:expect[r['group']][r['name']]=r['sha256']
expect['differentials']=prior['new_artifacts']
archives=[]
for group,prefix,old in [('models','', 'candidate'),('fibers','fibers-','fibers-candidate'),('plane_points','prior-','prior-candidate'),('surface','surface-','surface-candidate'),('branches','branches-','branches-candidate'),('plane_sections','plane-','plane-candidate'),('differentials','differentials-','new')]:
 paths=[O/'artifacts'/(prefix+'baseline'),O/'artifacts'/(prefix+'candidate'),P/'artifacts'/old]
 names=lambda d:{str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}
 assert all(names(d)==set(expect[group]) for d in paths),group
 for name,h in sorted(expect[group].items()):
  assert all(sha(d/name)==h for d in paths),(group,name)
  archives.append(dict(group=group,name=name,sha256=h,byte_identical_baseline_candidate_prior=True,matches_committed_prior_evidence=True))
assert len(archives)==328,len(archives)
new={str(p.relative_to(O/'artifacts/new')):sha(p) for p in sorted((O/'artifacts/new').rglob('*')) if p.is_file()}
save('archive-comparison.json',dict(archive_version=14,migration='none',preserved_files=len(archives),comparisons=archives,new_files=len(new),new_unique_payloads=len(set(new.values())),new_artifacts=new,scope='Geometry is revalidated and exact queries are re-executed separately from archive byte identity. Transient vector proofs are recomputed, not serialized.'))
sizes={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((O/'bin').iterdir()) if p.is_file()}
p=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_surface_differential_consumer.wasm');sizes[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p))
p=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_surface_differential_native_nurbs.wasm');sizes[p.name]=dict(bytes=p.stat().st_size,sha256=sha(p))
save('binary-sizes.json',sizes)
samples=[];paired=[];new_rows=[]
def cost(label):
 assert by[label]['exit_code']==0,label
 rows=[json.loads(s) for s in (O/(label+'.log')).read_text().splitlines() if s.startswith('{')]
 rows=[r for r in rows if 'case' in r]
 assert len(rows)==len({(r['case'],r['phase']) for r in rows})
 usage=json.loads((O/'costs'/(label+'.json')).read_text());assert usage['exit_code']==0
 samples.append(dict(label=label,rows=rows,resources=usage))
 return {(r['case'],r['phase']):r for r in rows}
for repeat in range(3):
 for f in families:
  a=cost(f'cost-{f}-baseline-{repeat}');b=cost(f'cost-{f}-candidate-{repeat}');assert a.keys()==b.keys(),f
  for key,x in a.items():
   y=b[key];assert (x['outcome'],x['iterations'])==(y['outcome'],y['iterations'])
   paired.append(dict(family=f,repeat=repeat,case=key[0],phase=key[1],baseline=x,candidate=y,latency_ratio=y['elapsed_ns']/x['elapsed_ns'],allocation_calls_delta=y['allocation_calls']-x['allocation_calls'],requested_bytes_delta=y['requested_bytes']-x['requested_bytes']))
 for r in cost('cost-new-'+str(repeat)).values():new_rows.append(dict(repeat=repeat,**r))
 for r in cost('cost-native-nurbs-new-'+str(repeat)).values():new_rows.append(dict(repeat=repeat,**r))
assert len(paired)==228,len(paired)
groups=collections.defaultdict(list)
for r in paired:groups[(r['family'],r['case'],r['phase'])].append(r)
medians=[]
for key,rows in sorted(groups.items()):
 assert len(rows)==3
 medians.append(dict(family=key[0],case=key[1],phase=key[2],median_paired_latency_ratio=statistics.median(r['latency_ratio'] for r in rows),median_allocation_calls_delta=statistics.median(r['allocation_calls_delta'] for r in rows),median_requested_bytes_delta=statistics.median(r['requested_bytes_delta'] for r in rows)))
assert len(medians)==76
assert len(new_rows)==48,len(new_rows)
new_groups=collections.defaultdict(list)
for r in new_rows:new_groups[(r['case'],r['phase'])].append(r)
new_medians=[dict(case=k[0],phase=k[1],iterations=v[0]['iterations'],**{'median_'+m:statistics.median(r[m] for r in v) for m in ['elapsed_ns','allocation_calls','requested_bytes']}) for k,v in sorted(new_groups.items())]
adverse=[r for r in medians if r['median_paired_latency_ratio']>1.1 or r['median_allocation_calls_delta']>0 or r['median_requested_bytes_delta']>0]
save('cost-analysis.json',dict(same_contract_workflows=38,paired_phase_rows=paired,phase_medians=medians,adverse_medians=adverse,new_successful_workflows=8,new_samples=new_rows,new_medians=new_medians,all_process_samples=samples,scope='Three alternating CPU10 pairs of complete fresh-input native workflows; no concurrent builds/tests. Each case first invocation and repeated fresh inputs are separate phases; earlier cases in the same process may have warmed shared state. New successful differential workflows have no successful main-branch baseline. Allocation calls/requested bytes and process RSS are distinct. All previous adverse cost observations remain open; no universal speedup or non-regression claim.'))
print('Verified',len(required),'checks,',len(archives),'preserved archives,',len(new),'new records,',len(paired),'paired cost rows; adverse phase medians',len(adverse))
