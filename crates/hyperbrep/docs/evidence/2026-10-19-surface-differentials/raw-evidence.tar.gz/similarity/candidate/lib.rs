include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn similarity_differentials() -> u32 {
    cases()[0].1();
    1
}
