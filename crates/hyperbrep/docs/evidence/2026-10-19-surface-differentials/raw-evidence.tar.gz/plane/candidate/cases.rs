#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/plane_tensor_sections.rs"]
mod acceptance;
fn cases() -> [(&'static str,fn());7] { [
("original_loop",acceptance::original_full_interior_loop),
("weighted_loops",acceptance::full_loops_and_nonlinear_weighted_images),
("singular_sections",acceptance::noncircular_singular_and_isolated_sections),
("image_guards",acceptance::rational_image_poles_and_replay_guards),
("budget_recovery",acceptance::image_refusal_budget_and_recovery),
("disconnected_sections",acceptance::disconnected_mixed_and_near_coincident_sections),
("solver_frontier",acceptance::empty_contained_boundary_and_solver_frontier),
] }
