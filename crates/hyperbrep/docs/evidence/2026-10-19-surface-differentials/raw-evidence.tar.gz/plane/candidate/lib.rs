include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn original_loop()->u32 {cases()[0].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn weighted_loops()->u32 {cases()[1].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn singular_sections()->u32 {cases()[2].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn image_guards()->u32 {cases()[3].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn budget_recovery()->u32 {cases()[4].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn disconnected_sections()->u32 {cases()[5].1();1}
#[unsafe(no_mangle)]
pub extern "C" fn solver_frontier()->u32 {cases()[6].1();1}
