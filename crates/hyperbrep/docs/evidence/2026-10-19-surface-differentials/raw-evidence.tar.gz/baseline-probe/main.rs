use hyperbrep::*;
fn q(n:i32,d:i32)->Real {(Real::from(n)/Real::from(d)).unwrap()}
fn main(){
 let offsets=[q(0,1),q(-1,2),q(0,1)];
 let net=(0..3).map(|j|(0..3).map(|i|Point3::new(q(i as i32,2),q(j as i32,2),q(7,16)+&offsets[i]+&offsets[j])).collect()).collect();
 let patch=Surface::rational_bezier(net,vec![vec![Real::one();3];3]).unwrap();
 let plane=Surface::plane(Point3::origin(),Vector3::x(),Vector3::y()).unwrap();
 let sections=match plane.intersect_surface(&patch).unwrap(){SurfaceSurfaceIntersection::Curves(c)=>c,other=>panic!("{other:?}")};
 assert_eq!(sections.len(),2);
 for section in sections {
  let curve=section.curve().clone();
  let frame=curve.planar_geometry().unwrap();
  let t=((q(3,5)-frame.source_offset)/frame.source_scale).unwrap();
  let vector=curve.derivative_at(&t.clone().into(),1).unwrap();
  assert!(vector.try_coordinates().is_none());
  let surface=Surface::extrusion(curve,Vector3::z()).unwrap();
  let uv=Point2::new(t,q(1,3));
  let partials=surface.partials_at(&uv);
  let normal=surface.normal_at(&uv);
  println!("partials={:?}; normal={:?}",partials.as_ref().err(),normal.as_ref().err());
  assert!(partials.is_ok() && normal.is_ok(),"an admitted section derivative must remain consumable by extrusion partials and unit normals");
 }
}
