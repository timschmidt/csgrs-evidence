"""Publish this increment's evidence only after frozen-source qualification."""
import hashlib
import json
from pathlib import Path
import shutil

O = Path(__file__).resolve().parent
R = Path('/mnt/development/csgrs/target/hyperbrep-development')
REL = 'crates/hyperbrep/docs/evidence/2026-10-19-surface-differentials'
E = R / REL

def load(name):
    return json.loads((O / name).read_text())

def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert not E.exists()
v, t, a, c = [load(n) for n in ['verification.json', 'test-summary.json', 'archive-comparison.json', 'cost-analysis.json']]
for p, digest in load('candidate-source.json')['files'].items():
    assert hashlib.sha256((R / p).read_bytes()).hexdigest() == digest, p
for p, digest in load('native-nurbs-source.json').items():
    assert hashlib.sha256((O / p).read_bytes()).hexdigest() == digest, p
b = t['final-brep-release-tests']
assert b['failed'] == b['ignored'] == 0
owner = sum(t[k]['passed'] for k in t if k != 'final-brep-release-tests')
validation = (
    f"All-feature release BRep/IO suites pass {b['passed']} tests in {b['batches']} batches, with no failures or ignored tests. "
    f"Focused curve joint-form arithmetic, polynomial/point/fiber/work-budget, rational-map and derivative-owner checks pass {owner} tests. "
    "All-feature/all-target Clippy for Hypercurve, HyperBRep and HyperBRep-IO, warning-denied rustdoc, BRep fuzz-target compilation and formatting pass. "
    "Seven shared surface-differential workflows and one supplemental native-NURBS workflow pass natively and as eight actual zero-import Wasmtime exports. "
    "Independent exact identities cover full implicit-circle extrusion normals and both pcurve chain-rule consumers; restriction, reversal and original/materialized charts; cubic/projective sections; selected unweighted/weighted tensor partials; native Bezier/NURBS vector products; unit/nonunit knot domains and right-owned nonsmooth spans; reflection, shear and cold replay. "
    "The supplemental NURBS consumer independently checks the cross-product Z coordinate for C(t)=(t,t^2,t^3) and C(t)/(1+t), with exact native-chart derivative scaling. "
    "Unit norm, orthogonality, positive/negative comparisons and exact 1e-12 distinctions are separate assertions. Selected parallel unit normals retain orientation for both speed signs while unavailable magnitude operations remain typed. "
    "Zero vectors, singular ranks/cusps, unsupported fields/angular surfaces, original 0/0, invalid domains, policy transitions, fresh budget exhaustion and warmed-proof reuse/recovery are exercised. "
    f"All {a['preserved_files']} prior archive records are byte-identical to the baseline and previous frozen evidence, with archive 14 unchanged; {a['new_files']} new records have {a['new_unique_payloads']} distinct payloads. "
    "Geometric identities, required model validation and deterministic bytes are checked separately. The clean baseline probe reproduces typed Unsupported partial/normal queries on the first full-circle branch; the directly migrated candidate probe successfully checks both branches. "
    "The fixture audit preserves 248 existing test files byte-for-byte, three integration fixtures and geometry unit-test bodies modulo direct joint-UV and coordinate-view API migration. "
    "No complete trimmed-face or curved-solid Boolean result is claimed."
)
phases = c['phase_medians']
pairs = c['paired_phase_rows']
flagged_latency = [p for p in phases if p['median_paired_latency_ratio'] > 1.1]
alloc_increase = sum(p['allocation_calls_delta'] > 0 for p in pairs)
bytes_increase = sum(p['requested_bytes_delta'] > 0 for p in pairs)
sizes = load('binary-sizes.json')
families = ['preserved', 'prior', 'surface', 'branches', 'plane', 'differentials', 'similarity']
delta = {f: sizes[f + '-candidate']['bytes'] - sizes[f + '-baseline']['bytes'] for f in families}
rss = max(p['resources']['maximum_rss_kib'] for p in c['all_process_samples'])
adverse_description = '; '.join(
    f"{p['family']}/{p['case']}/{p['phase']}={p['median_paired_latency_ratio']:.6f}"
    for p in flagged_latency
) or 'none in this sample'
slowest_new = max((p for p in c['new_medians'] if p['phase'] == 'first_fresh_input'), key=lambda p: p['median_elapsed_ns'])
cost = (
    f"Three alternating CPU-10 process pairs run {c['same_contract_workflows']} preserved complete workflows, with all assertions, materialization, validation and replay retained. "
    f"The {len(pairs)} paired phase rows yield {len(phases)} first/repeated-fresh-input phase medians. "
    f"Median paired latency ratios range {min(p['median_paired_latency_ratio'] for p in phases):.6f} to {max(p['median_paired_latency_ratio'] for p in phases):.6f}; {len(flagged_latency)} exceed the 10% review marker: {adverse_description}. "
    f"{alloc_increase} paired rows increase counted Rust allocation calls and {bytes_increase} increase requested bytes. Allocation-call and requested-byte counts are identical in all 228 pairs; this does not resolve the adverse latency observations. "
    f"Maximum observed process RSS is {rss} KiB. Matched executable byte changes are {delta}. "
    "Eight new successful workflows have no successful production baseline and retain three absolute process measurements, including the complete native-NURBS recipe. Native/WASM sizes, hashes and every adverse sample are recorded. "
    f"The most expensive new first invocation is {slowest_new['case']}: its median is {slowest_new['median_elapsed_ns'] / 1e9:.6f} seconds, {slowest_new['median_allocation_calls']} counted allocations and {slowest_new['median_requested_bytes']} requested Rust bytes. This is the full construction/assertion/replay workflow, not one normal query; its high work and allocation traffic remain an explicit performance follow-up. "
    "No qualification build or separate test runs concurrently with measurement. Requested Rust allocation traffic is not live heap and excludes foreign allocator internals. The 10% marker is not a significance test; shared-host timings establish neither a universal speedup nor stable latency non-regression. "
    "The earlier surface/joint_forms/first_fresh_input ratios 1.370930, 1.119002 and 1.371168, and all earlier plane/tensor adverse observations remain open. "
    "The initial full consumer timed out after 1800 seconds; a diagnostic timed out after 600 seconds including compilation. Both are retained as prototype failures, not same-contract speedup evidence. "
    "The structural common-denominator correction and nonrecursive operand Debug prevent demonstrated avoidable growth; neither is a general resource bound. This is a certified-completion extension, not a performance-only change."
)
limits = (
    "Surface::partials_at and normal_at now accept a joint CurvePoint2 directly; SurfacePartials owns GeometricVector3 values and normal_at preserves unit length. All callers migrate directly without compatibility overloads. "
    "Common-source rational arithmetic preserves original operands, denominator guards and selected identity. It does not construct arbitrary independent-field composita. "
    "Positive-root vector carriers support exact comparisons and products in admitted common fields. Selected parallel directions and normals do not imply support for their unavailable radical speed magnitudes or general radical-valued chain-rule sums. "
    "Selected angular/procedural surface queries, singular branch germs and event limits, differential whole-section proofs, general patch-pair sections, folded/vertical/repeated/boundary components and complete trim arrangements remain open. "
    "Selected partial/normal support for retained-profile extrusions does not extend general retained-profile Surface::point_at automatically; its current selected position path still requires native profile coefficients. The native-conic affine cold-replay frontier remains separate. "
    "Archive 14 is unchanged. Transient vector proof carriers are recomputed from validated geometry, not serialized as new authoritative proof claims. "
    "Precision and owner budget controls, shared denominators and bounded diagnostic expansion do not bound total work, coefficient bits, retained operand history, heap, stack or cancellation. Dangerous checks use external containment. "
    "Source-path consumers do not establish installed distributions or production bindings. Runtime fuzz/ASan/lexicase, connected formal proofs, measured coverage, MSRV, full release/workflow and push gates remain unqualified. "
    "All 28 work packages remain open/in-progress. The eaa0cae54 push exception is consumed; this increment is not pushed."
)
record = dict(
    id='surface-differentials-2026-10-19',
    work_packages=['WP02', 'WP03', 'WP05a', 'WP05b', 'WP06', 'WP09', 'WP13', 'WP21'],
    properties=['P1', 'P4', 'P5', 'P6', 'P8', 'P9', 'P15', 'P17', 'P18', 'P19', 'P20', 'P25', 'P26', 'P27', 'P35', 'P36', 'P37', 'P38', 'P39'],
    change='Retain selected surface partials, exact unit normals, shared-source spatial vector algebra and both-pcurve differential consumers through native charts and cold replay.',
    sources=['../../hypercurve/src/curve_point/rational.rs', '../../hypercurve/src/curve_point/rational/arithmetic.rs', '../../hypercurve/src/bezier_offset/rational_form.rs', '../../hypercurve/src/bezier_algebraic_image.rs', '../../hypercurve/src/polynomial_point.rs', '../../hypercurve/src/curve_vector.rs', '../src/geometry/vector.rs', '../src/geometry/vector/algebra.rs', '../src/geometry/surface_point.rs', '../src/geometry/surface_point/rational.rs', '../src/geometry.rs', '../src/parameter.rs', '../src/error.rs', '../../hyperbrep-io/src/step/write/advanced/cone.rs', '../tests/support/surface_differentials.rs', '../../hypercurve/tests/support/joint_form_arithmetic.rs'],
    evidence='evidence/2026-10-19-surface-differentials/manifest.json',
    validation=validation, cost_evidence=cost, limits=limits,
)
dump(O / 'admission-record.json', record)
(O / 'README.md').write_text(
    '# Selected surface differentials and exact unit normals\n\n' + validation + '\n\n' + cost + '\n\n' + limits + '\n\n'
    '`contract.md` records the pre-edit owners, domain and missing acceptance. `implementation-design.md` explains retained common-source arithmetic, original homogeneous differentiation and positive-root divisors. '
    '`research-notes.md` cites primary mathematical references; those references do not substitute for implementation qualification. '
    '`candidate-source.json`, `verification.json`, `test-summary.json`, `fixture-migration.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate source identity, exact behavior, deterministic archives and measured costs. '
    '`native-nurbs-source.json` and `native_nurbs_probe.rs` identify the supplemental complete workflow. `ideas.json` records kept/rejected alternatives; `next-domains.md` carries the full remaining plan.\n\n'
    '`raw-evidence.tar.gz` retains command logs, source patches, failed prototypes, original baseline probe, consumer manifests/locks, archive outputs and raw cost/RSS rows. Executables and caches are excluded. '
    'Seven baseline executables were verified against the prior sealed candidate source hashes and binary hashes/sizes before reuse. Fresh calls regenerate all prior archives. '
    'Reproduction in another checkout requires adjusting explicit source/output paths. Never run frozen evidence drivers in place.\n\n'
    'Early compiler errors, common-denominator degree growth, slow shared-source comparison and excessive Debug expansion remain in the record. '
    'New test assumptions about pcurve reversal and warmed zero-budget proofs were corrected to the documented contracts while retaining full fixtures and independent assertions. '
    'Consumer lock-package labels were corrected before building, with unchanged dependency graphs. The supplemental harness corrected an Ordering import collision and a missing Real tuple annotation before executing any geometry. `working-findings.md` and `consumer-lock-correction.json` record these details. '
    'Final qualification covers the immutable 32-file repository snapshot and the separately hashed supplemental NURBS recipe. The root property ledger changes only within `current_work.hyperbrep`.\n'
)
status_path = R / 'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
before_status = (O / 'implementation-status-before.json').read_bytes()
assert status_path.read_bytes() == before_status
status = json.loads(before_status)
assert len(status['increments']) == 78 and len(status['work_packages']) == 28 and not status['complete']
status['increments'].append(record)
status['updated_on'] = '2026-10-19'
status['next_actions'].insert(0,
    'Continue WP02/WP03/WP05a/WP05b/WP06 from evidence/2026-10-19-surface-differentials/next-domains.md. Preserve the full old corpus and all eight new differential workflows while extending singular branch germs/event limits, complete dual-chart differential proofs, retained-profile selected positions and trim arrangements. Selected partials/unit normals and common-source vector products are now admitted on the recorded domains; independent-field/radical joins remain typed. All modeling, resource and delivery work packages and prior adverse cost observations remain active.')
dump(status_path, status)

def value_span(text, keys):
    decoder = json.JSONDecoder()
    start = 0
    for wanted in keys:
        while text[start].isspace(): start += 1
        assert text[start] == '{'
        pos = start + 1
        while True:
            while text[pos].isspace() or text[pos] == ',': pos += 1
            key, end = decoder.raw_decode(text, pos)
            pos = end
            while text[pos].isspace(): pos += 1
            assert text[pos] == ':'
            pos += 1
            while text[pos].isspace(): pos += 1
            _, end = decoder.raw_decode(text, pos)
            if key == wanted:
                start = pos
                break
            pos = end
            assert text[pos] != '}', wanted
    return start, end

ledger = R / 'docs/properties-status.json'
original = (O / 'properties-status-before.json').read_bytes()
assert ledger.read_bytes() == original
text = original.decode('utf-8')
start, end = value_span(text, ['current_work', 'hyperbrep'])
owned = json.loads(text[start:end])
owned.update(latest_evidence=REL + '/manifest.json', qualification=validation,
    latest_implementation=record['id'], latest_feature_evidence=REL + '/manifest.json',
    performance_evidence=cost, limits=limits)
# No fresh upstream query in this increment: preserve the prior check reference.
line = text[text.rfind('\n', 0, start) + 1:start]
indent = len(line) - len(line.lstrip())
replacement = json.dumps(owned, indent=2).replace('\n', '\n' + ' ' * indent)
new = (text[:start] + replacement + text[end:]).encode('utf-8')
prefix, suffix = text[:start].encode('utf-8'), text[end:].encode('utf-8')
assert new.startswith(prefix) and new.endswith(suffix)
old_obj, new_obj = json.loads(original), json.loads(new)
old_obj['current_work']['hyperbrep'] = new_obj['current_work']['hyperbrep']
assert old_obj == new_obj
ledger.write_bytes(new)
dump(O / 'ledger-byte-scope.json', dict(path='docs/properties-status.json', changed_value='current_work.hyperbrep', prefix_bytes=len(prefix), suffix_bytes=len(suffix), prefix_sha256=hashlib.sha256(prefix).hexdigest(), suffix_sha256=hashlib.sha256(suffix).hexdigest(), outside_bytes_unchanged=True))
old_status = json.loads(before_status)
assert status['increments'][:-1] == old_status['increments']
assert status['work_packages'] == old_status['work_packages']
assert status['next_actions'][1:] == old_status['next_actions']
E.mkdir(parents=True)
visible = ['README.md', 'contract.md', 'implementation-design.md', 'working-findings.md', 'research-notes.md', 'next-domains.md', 'ideas.json', 'cost-contract.md', 'candidate-source.json', 'baseline-source.json', 'environment.json', 'verification.json', 'test-summary.json', 'fixture-migration.json', 'archive-comparison.json', 'cost-analysis.json', 'cost-preflight.json', 'binary-sizes.json', 'reused-baseline-binaries.json', 'consumer-lock-correction.json', 'native-nurbs-correction.json', 'native-nurbs-source.json', 'admission-record.json', 'ledger-byte-scope.json']
for name in visible:
    shutil.copy2(O / name, E / name)
shutil.copy2(O / 'native-nurbs/cases.rs', E / 'native_nurbs_probe.rs')
print(json.dumps(dict(evidence=str(E), increments=len(status['increments']), work_packages=len(status['work_packages']), outside_ledger_bytes_unchanged=True), indent=2))
