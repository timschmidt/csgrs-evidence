from pathlib import Path
import json,tomllib,hashlib
O=Path(__file__).resolve().parent;P=Path('/tmp/hyperbrep-section-differentials-20261019')
families={**{f:f+'/candidate' for f in ['preserved','prior','surface','branches','plane']},'differentials':'consumer','similarity':'similarity'}
rows=[]
for family,recipe in families.items():
 target=O/family/'candidate'
 old=tomllib.loads((P/recipe/'Cargo.toml').read_text())['package']['name']
 name=tomllib.loads((target/'Cargo.toml').read_text())['package']['name']
 source=(P/recipe/'Cargo.lock').read_text()
 fixed=source.replace('name = "'+old+'"','name = "'+name+'"')
 assert fixed!=source
 original=tomllib.loads(source);current=tomllib.loads(fixed)
 expected=dict(original);expected['package']=[{**p,'name':name} if p['name']==old else p for p in original['package']]
 assert expected==current
 (target/'Cargo.lock').write_text(fixed)
 rows.append(dict(family=family,old_name=old,name=name,dependency_graph_preserved=True,sha256=hashlib.sha256(fixed.encode()).hexdigest()))
(O/'consumer-lock-correction.json').write_text(json.dumps(dict(reason='Setup v1 used directory enumeration order for the package-name substitution; lock verification caught a wrong/missing root-package rename before any consumer build. Explicit per-family source manifests supply the corrected root name, with an otherwise identical dependency graph.',locks=rows),indent=2)+'\n')
print('Verified all seven corrected consumer locks; no dependency changes')
