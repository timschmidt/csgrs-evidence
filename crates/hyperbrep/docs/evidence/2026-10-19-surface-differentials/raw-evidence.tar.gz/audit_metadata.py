"""Check the final repository metadata against its pre-edit bytes and frozen code."""
import hashlib
import json
from pathlib import Path
import subprocess

O = Path(__file__).resolve().parent
R = Path('/mnt/development/csgrs/target/hyperbrep-development')
old = (O/'properties-status-before.json').read_bytes()
new = (R/'docs/properties-status.json').read_bytes()
scope = json.loads((O/'ledger-byte-scope.json').read_text())
n, m = scope['prefix_bytes'], scope['suffix_bytes']
assert old[:n] == new[:n] and old[-m:] == new[-m:]
assert hashlib.sha256(new[:n]).hexdigest() == scope['prefix_sha256']
assert hashlib.sha256(new[-m:]).hexdigest() == scope['suffix_sha256']
a,b = json.loads(old), json.loads(new)
a['current_work']['hyperbrep'] = b['current_work']['hyperbrep']
assert a == b

before = json.loads((O/'implementation-status-before.json').read_bytes())
after = json.loads((R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json').read_bytes())
assert len(after['increments']) == 79 and not after['complete']
assert after['increments'][:-1] == before['increments']
assert after['work_packages'] == before['work_packages']
assert after['next_actions'][1:] == before['next_actions']
for key in before:
    if key not in ['increments','next_actions','updated_on']:
        assert before[key] == after[key], key
frozen = json.loads((O/'candidate-source.json').read_text())
for p,h in frozen['files'].items():
    assert hashlib.sha256((R/p).read_bytes()).hexdigest() == h, p
for p,h in json.loads((O/'native-nurbs-source.json').read_text()).items():
    assert hashlib.sha256((O/p).read_bytes()).hexdigest() == h, p
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip() == frozen['baseline']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/mnt/development/csgrs',text=True).strip() == frozen['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd='/mnt/development/csgrs',text=True)
E=R/'crates/hyperbrep/docs/evidence/2026-10-19-surface-differentials'
for p in E.glob('*.json'):
    json.loads(p.read_bytes())
report = dict(prior_increments_preserved=78, work_packages_preserved=28,
    prior_next_actions_preserved=len(before['next_actions']), frozen_source_files=len(frozen['files']),
    outside_hyperbrep_ledger_bytes_preserved=n+m,
    final_implementation_complete=False, main_unchanged=True,
    scope='Metadata-only edits after source qualification; all frozen source/test/documentation hashes unchanged.')
dest=O/'metadata-audit.json'
assert not dest.exists()
dest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

assert (json.dumps(json.loads((R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json').read_bytes()),indent=2)+'\n').encode()==(R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json').read_bytes()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
print('Original JSON escaping/indentation preserved; final diff check passed.')
