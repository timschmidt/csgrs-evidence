include!("/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/surface_differentials.rs");
fn main(){
 let start=std::time::Instant::now();
 macro_rules! stage {($s:expr)=>{println!("{} elapsed {:?}",$s,start.elapsed());};}
 stage!("construct circle");
 let patch=tensor([x(),y(),circle()],one()); let plane=plane();
 let sections=branches(plane.intersect_surface(&patch).unwrap());
 stage!("section complete");
 let curve=sections[0].curve();let at=source_parameter(curve,&q(3,5).into());
 let surface=Surface::extrusion(curve.clone(),Vector3::z()).unwrap();
 let uv=represented(at.try_real().unwrap().clone(),q(1,3));
 let partials=surface.partials_at(&uv).unwrap();stage!("partials");
 let normal=surface.normal_at(&uv).unwrap();stage!("normal");
 println!("length {:?}",normal.compare_squared_length(&1.into()));stage!("length complete");
 println!("dot u {:?}",normal.compare_dot(partials.u(),&0.into()));stage!("dot u complete");
 println!("dot v {:?}",normal.compare_dot(partials.v(),&0.into()));stage!("dot v complete");
 println!("equals {:?}",normal.equals(&partials.normal().unwrap()));stage!("equality complete");
 println!("coordinate {:?}",normal.compare_coordinate(Axis::X,&q(2,5)));stage!("coordinate complete");
 chain(&sections[0],[&plane,&patch],&q(3,5).into());stage!("represented chain complete");
 chain(&sections[0],[&plane,&patch],&selected_parameter());stage!("selected chain complete");
}
