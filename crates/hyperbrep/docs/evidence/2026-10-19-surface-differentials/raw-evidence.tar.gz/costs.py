import collections,hashlib,json
from pathlib import Path
import run
O=run.OUT
assert not any(k.startswith('HYPERBREP_') and 'ARTIFACT' in k for k in run.ENV)
rows={r['label']:r for r in json.loads((O/'results.json').read_text())}
required=['final-affected-clippy','final-owner-regressions','final-owner-rational-maps','final-owner-derivatives','final-brep-release-tests','final-affected-rustdoc','final-brep-fuzz-check','final-fmt-check','final-fuzz-fmt','final-fixture-migration-audit','final-wasm-build','final-wasm-run','new-native-build','new-native-archives','candidate-baseline-success-probe','native-nurbs-v2-native-build','native-nurbs-v2-native-run','native-nurbs-v2-wasm-build','native-nurbs-v2-wasm-run']
for family in ['preserved','prior','surface','branches','plane','differentials','similarity']:
 required += [family+'-candidate-build',family+'-baseline-archives',family+'-candidate-archives']
for label in required:assert rows[label]['exit_code']==0,label
for path,digest in json.loads((O/'candidate-source.json').read_text())['files'].items():assert hashlib.sha256((run.ROOT/path).read_bytes()).hexdigest()==digest,path
for path,digest in json.loads((O/'native-nurbs-source.json').read_text()).items():assert hashlib.sha256((O/path).read_bytes()).hexdigest()==digest,path
prior=json.loads((run.ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-section-differentials/archive-comparison.json').read_text())
expected=collections.defaultdict(dict)
for row in prior['comparisons']:expected[row['group']][row['name']]=row['sha256']
expected['differentials']=prior['new_artifacts']
checked=0
for group,prefix,previous in [('models','', 'candidate'),('fibers','fibers-','fibers-candidate'),('plane_points','prior-','prior-candidate'),('surface','surface-','surface-candidate'),('branches','branches-','branches-candidate'),('plane_sections','plane-','plane-candidate'),('differentials','differentials-','new')]:
 paths=[O/'artifacts'/(prefix+'baseline'),O/'artifacts'/(prefix+'candidate'),Path('/tmp/hyperbrep-section-differentials-20261019/artifacts')/previous]
 for directory in paths:
  assert {str(p.relative_to(directory)) for p in directory.rglob('*') if p.is_file()}==set(expected[group]),group
  for name,digest in expected[group].items():assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==digest,(group,name)
 checked+=len(expected[group])
assert checked==328,checked
report=O/'cost-preflight.json';assert not report.exists()
report.write_text(json.dumps(dict(passed_qualification_labels=required,frozen_source_unchanged=True,preserved_archive_records_checked=checked,baseline_candidate_prior_archive_bytes_equal=True,scope='Correctness, source identity and archive comparisons checked before timed measurement; all qualifying build/test session handles had completed.'),indent=2)+'\n')
(O/'costs').mkdir(exist_ok=True)
for repeat in range(3):
 for family in ['preserved','prior','surface','branches','plane','differentials','similarity']:
  for side in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   name=family+'-'+side;label='cost-'+name+'-'+str(repeat)
   assert run.run(dict(label=label,source_scope='verified 82f31d335 baseline' if side=='baseline' else 'qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','10',str(O/'bin'/name),'measure'],seconds=2400))==0
 label='cost-new-'+str(repeat)
 assert run.run(dict(label=label,source_scope='qualified candidate; new successful contract has no successful baseline',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','10',str(O/'bin/new'),'measure'],seconds=2400))==0
 label='cost-native-nurbs-new-'+str(repeat)
 assert run.run(dict(label=label,source_scope='qualified supplemental candidate; new successful contract has no successful baseline',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','10',str(O/'bin/native-nurbs-new'),'measure'],seconds=2400))==0
