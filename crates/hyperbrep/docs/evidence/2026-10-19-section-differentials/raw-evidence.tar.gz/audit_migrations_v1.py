from pathlib import Path
import hashlib,json,re,subprocess
import run
O=run.OUT;R=run.ROOT;B=Path('/mnt/development/csgrs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compact=lambda s:re.sub(r'\s+','',s)
def migrate(s,affine=False):
 edits=[];pos=0
 while (i:=s.find('.derivative_at(',pos))>=0:
  j=i+len('.derivative_at(');end=j;depth=0
  while end<len(s):
   c=s[end]
   if c in '([{':depth+=1
   if c in ')]}':depth-=1
   if c==',' and depth==0:break
   if depth<0:break
   end+=1
  arg=s[j:end].strip();replacement=None
  if arg.startswith(('&q(', '&r(', '&Real::zero()', '&quarter()')):replacement=arg+'.into()'
  elif arg=='&0.into()':replacement='&Real::zero().into()'
  if replacement:edits.append((j,end,replacement))
  pos=end+1
 for a,b,t in reversed(edits):s=s[:a]+t+s[b:]
 s=s.replace('.vector()', '.try_coordinates().unwrap()')
 if affine:s=s.replace('let at = source.domain().start().try_real().unwrap();','let at = source.domain().start();')
 return s
migrated=[]
for name in ['affine_curve_images','parallel_profile_extrusion','selected_revolution']:
 n='crates/hyperbrep/tests/support/'+name+'.rs'
 expected=migrate((B/n).read_text(),name=='affine_curve_images')
 assert compact(expected)==compact((R/n).read_text()),n
 migrated.append(n)
n='crates/hyperbrep/src/geometry.rs'
a=(B/n).read_text();b=(R/n).read_text();marker='#[cfg(test)]\nmod tests {'
assert marker in a and marker in b
assert compact(migrate(a[a.index(marker):]))==compact(b[b.index(marker):])
# One prior capability-refusal assertion is replaced by two exact component
# identities, keeping its full original construction/restriction/replay fixture.
n='crates/hypercurve/tests/support/polynomial_curves.rs'
a=(B/n).read_text();old='assert!(curve.derivatives_at(&q(1, 2).into(), 1).is_err());'
new='''let derivatives = curve.derivatives_at(&q(1, 2).into(), 1).unwrap();
assert_eq!(derivatives.len(), 1);
assert_eq!(derivatives[0].compare_linear_form(&Real::one(), &Real::zero(), &Real::one()).unwrap(), Ordering::Equal,);
assert_eq!(derivatives[0].compare_linear_form(&Real::zero(), &Real::one(), &Real::zero()).unwrap(), Ordering::Equal,);'''
assert a.count(old)==1
assert compact(a.replace(old,new))==compact((R/n).read_text()),n
migrated.append(n)
files=subprocess.check_output(['git','ls-files','crates/hyperbrep/tests','crates/hypercurve/tests'],cwd=B,text=True).splitlines()
unchanged=[]
for n in files:
 if n in migrated:continue
 assert (B/n).read_bytes()==(R/n).read_bytes(),n
 unchanged.append(n)
result=dict(api_only_support_migrations=migrated[:3],unit_geometry_assertions='all original test bodies preserved modulo the declared Parameter and optional coordinate API migration',strengthened_owner_fixture=migrated[3],owner_change='one old regular-derivative refusal now requires exact dx=1,dy=0; this is a changed cost contract',unchanged_existing_test_files=len(unchanged),unchanged_files={n:sha(R/n) for n in unchanged},new_acceptance='crates/hyperbrep/tests/support/section_differentials.rs',prior_full_plane_tensor_fixture_unchanged=True)
(O/'fixture-migration.json').write_text(json.dumps(result,indent=2)+'\n')
print('Preserved',len(unchanged),'existing test files; three mechanical API migrations, unchanged unit assertions and one strengthened owner frontier.')
