"""Audit completed qualification and costs without re-running any consumer."""
import collections
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess

O = Path(__file__).resolve().parent
R = Path('/mnt/development/csgrs/target/hyperbrep-development')
OLD = Path('/tmp/hyperbrep-plane-tensor-sections-20261019')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    p = O / name
    assert not p.exists(), p
    p.write_text(json.dumps(value, indent=2) + '\n')

results = json.loads((O / 'results.json').read_text())
by_label = {r['label']: r for r in results}
assert len(by_label) == len(results)
for r in results:
    assert r['log_sha256'] == sha(Path(r['log'])), r['label']
    assert r['source_patch_sha256'] == sha(Path(r['source_patch'])), r['label']
    assert r['revision_unchanged'], r['label']

required = [
    'final-freeze', 'final-affected-clippy', 'final-owner-regressions',
    'final-owner-rational-maps', 'final-owner-derivatives',
    'final-brep-release-tests', 'final-affected-rustdoc', 'final-brep-fuzz-check',
    'final-fmt-check', 'final-fuzz-fmt', 'fixture-migration-audit-v2',
    'final-wasm-build', 'final-wasm-run', 'new-native-build',
    'new-native-archives', 'candidate-baseline-success-probe',
    'similarity-native-build-v2', 'similarity-native-run-v2',
    'similarity-wasm-build-v2', 'similarity-wasm-run-v2',
]
families = ['preserved', 'prior', 'surface', 'branches', 'plane']
for family in families:
    required += [family + '-candidate-build']
    required += [family + '-' + side + '-archives' for side in ['baseline', 'candidate']]
for label in required:
    assert by_label[label]['exit_code'] == 0, label
assert by_label['baseline-missing-section-derivative']['exit_code'] != 0

frozen = json.loads((O / 'candidate-source.json').read_text())
for p, digest in frozen['files'].items():
    assert sha(R / p) == digest, p
similarity = json.loads((O / 'similarity-source-v2.json').read_text())
for p, digest in similarity.items():
    assert sha(O / p) == digest, p
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == frozen['baseline']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd='/mnt/development/csgrs', text=True) == ''
save('verification.json', dict(
    baseline=frozen['baseline'], frozen_source_files=len(frozen['files']),
    source_unchanged=True, main_clean_and_frozen=True,
    qualifying_labels=required,
    commands=[{k: r[k] for k in ['label', 'command', 'exit_code', 'elapsed_seconds', 'log_sha256', 'source_patch_sha256']} for r in results],
    retained_nonzero_diagnostics=[r['label'] for r in results if r['exit_code']],
    scope='Affected consumer qualification; not the complete pre-push workflow matrix. Early diagnostics remain separate from final checks.',
))

test_summary = {}
pattern = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s')
for label in ['final-owner-regressions', 'final-owner-rational-maps', 'final-owner-derivatives', 'final-brep-release-tests']:
    matches = pattern.findall((O / (label + '.log')).read_text())
    assert matches, label
    assert all(x[0] == 'ok' and int(x[2]) == 0 for x in matches), label
    test_summary[label] = dict(batches=len(matches), **{
        key: sum(int(x[i]) for x in matches)
        for i, key in enumerate(['passed', 'failed', 'ignored', 'measured', 'filtered_out'], 1)
    })
save('test-summary.json', test_summary)

archive_rows = []
committed_prior = json.loads((R/'crates/hyperbrep/docs/evidence/2026-10-19-plane-tensor-sections/archive-comparison.json').read_text())['files']
for group, before, after, prior in [
    ('models', 'baseline', 'candidate', 'candidate'),
    ('fibers', 'fibers-baseline', 'fibers-candidate', 'fibers-candidate'),
    ('plane_points', 'prior-baseline', 'prior-candidate', 'prior-candidate'),
    ('surface', 'surface-baseline', 'surface-candidate', 'surface-candidate'),
    ('branches', 'branches-baseline', 'branches-candidate', 'branches-candidate'),
    ('plane_sections', 'plane-baseline', 'plane-candidate', 'new'),
]:
    a, b, c = O/'artifacts'/before, O/'artifacts'/after, OLD/'artifacts'/prior
    names = lambda p: {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}
    assert names(a) == names(b) == names(c), group
    assert names(a) == set(committed_prior[prior]), group
    for name in sorted(names(a)):
        assert (a/name).read_bytes() == (b/name).read_bytes() == (c/name).read_bytes(), (group, name)
        assert sha(a/name) == committed_prior[prior][name], (group, name)
        archive_rows.append(dict(group=group, name=name, sha256=sha(a/name), byte_identical_baseline_candidate_prior=True, matches_committed_prior_evidence=True))
assert len(archive_rows) == 305, len(archive_rows)
new_archives = {str(p.relative_to(O/'artifacts/new')): sha(p) for p in sorted((O/'artifacts/new').rglob('*')) if p.is_file()}
save('archive-comparison.json', dict(
    archive_version=14, migration='none', preserved_files=len(archive_rows),
    comparisons=archive_rows, new_files=len(new_archives),
    new_unique_payloads=len(set(new_archives.values())), new_artifacts=new_archives,
    scope='Byte identity is separate from geometric assertions and validation performed by each complete consumer.',
))

sizes = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p)) for p in sorted((O/'bin').iterdir()) if p.is_file()}
for name in ['hyperbrep_section_differential_consumer', 'hyperbrep_section_differential_similarity_consumer']:
    p = Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release')/(name+'.wasm')
    sizes[name+'.wasm'] = dict(bytes=p.stat().st_size, sha256=sha(p))
save('binary-sizes.json', sizes)

samples = []
paired = []
changed = []
def read_cost(label):
    assert by_label[label]['exit_code'] == 0, label
    rows = [json.loads(s) for s in (O/(label+'.log')).read_text().splitlines() if s.startswith('{')]
    costs = [r for r in rows if 'case' in r]
    assert len(costs) == len({(r['case'], r['phase']) for r in costs})
    usage = json.loads((O/'costs'/(label+'.json')).read_text())
    assert usage['exit_code'] == 0
    samples.append(dict(label=label, rows=rows, resources=usage))
    return {(r['case'], r['phase']): r for r in costs}

for repeat in range(3):
    for family in families:
        a = read_cost(f'cost-{family}-baseline-{repeat}')
        b = read_cost(f'cost-{family}-candidate-{repeat}')
        assert a.keys() == b.keys(), family
        for key in a:
            x, y = a[key], b[key]
            assert (x['outcome'], x['iterations']) == (y['outcome'], y['iterations'])
            row = dict(family=family, repeat=repeat, case=key[0], phase=key[1],
                       baseline=x, candidate=y,
                       latency_ratio=y['elapsed_ns']/x['elapsed_ns'],
                       allocation_calls_delta=y['allocation_calls']-x['allocation_calls'],
                       requested_bytes_delta=y['requested_bytes']-x['requested_bytes'])
            if (family, key[0]) == ('preserved', 'polynomial_branches'):
                row['contract_change'] = 'Baseline asserts derivative refusal; candidate asserts exact regular derivative. No same-work ratio claim.'
                changed.append(row)
            else:
                paired.append(row)
assert len(paired) == 180 and len(changed) == 6, (len(paired), len(changed))
grouped = collections.defaultdict(list)
for row in paired:
    grouped[(row['family'], row['case'], row['phase'])].append(row)
medians = []
for key, rows in sorted(grouped.items()):
    assert len(rows) == 3
    medians.append(dict(family=key[0], case=key[1], phase=key[2],
        median_paired_latency_ratio=statistics.median(r['latency_ratio'] for r in rows),
        median_allocation_calls_delta=statistics.median(r['allocation_calls_delta'] for r in rows),
        median_requested_bytes_delta=statistics.median(r['requested_bytes_delta'] for r in rows)))
assert len(medians) == 60

new_samples = []
for repeat in range(3):
    for family in ['new', 'similarity-new']:
        label = f'cost-{family}-{repeat}'
        for row in read_cost(label).values():
            new_samples.append(dict(family=family, repeat=repeat, **row))
assert len(new_samples) == 42
new_groups = collections.defaultdict(list)
for row in new_samples:
    new_groups[(row['family'], row['case'], row['phase'])].append(row)
new_medians = []
for key, rows in sorted(new_groups.items()):
    assert len(rows) == 3
    new_medians.append(dict(family=key[0], case=key[1], phase=key[2], iterations=rows[0]['iterations'], **{
        'median_'+metric: statistics.median(r[metric] for r in rows)
        for metric in ['elapsed_ns', 'allocation_calls', 'requested_bytes']
    }))
ratios = [r['median_paired_latency_ratio'] for r in medians]
summary = dict(same_contract_workflows=30, same_contract_phase_medians=60,
               paired_phase_rows=len(paired), minimum_median_ratio=min(ratios),
               maximum_median_ratio=max(ratios), phases_above_ten_percent=sum(x>1.1 for x in ratios),
               paired_rows_increased_allocation_calls=sum(r['allocation_calls_delta']>0 for r in paired),
               paired_rows_increased_requested_bytes=sum(r['requested_bytes_delta']>0 for r in paired),
               maximum_rss_kib=max(s['resources']['maximum_rss_kib'] for s in samples),
               binary_byte_deltas={f:sizes[f+'-candidate']['bytes']-sizes[f+'-baseline']['bytes'] for f in families},
               new_absolute_workflows=7)
save('cost-analysis.json', dict(
    scope='Three alternating CPU-10 process pairs. First and three repeated fresh-input calls retain all assertions and replay. One deliberately strengthened recipe is separately reported. Seven new absolute workflows have no successful baseline. No compilation ran during measurements.',
    summary=summary, medians=medians, paired_rows=paired,
    changed_contract_rows=changed, new_absolute_medians=new_medians,
    new_absolute_rows=new_samples, raw_samples=samples,
    limitations='The 10% marker is not a significance test. Shared-host timings do not establish a speedup or stable non-regression. Rust requested allocation traffic excludes foreign allocator internals and is not live heap. Prior adverse performance observations remain open.',
))
print(json.dumps(dict(tests=test_summary, archives=len(archive_rows), new_archives=len(new_archives), new_unique=len(set(new_archives.values())), costs=summary), indent=2))
