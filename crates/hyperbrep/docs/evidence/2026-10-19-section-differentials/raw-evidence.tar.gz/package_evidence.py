"""Seal the evidence after final metadata checks. Never execute a frozen runner."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

O=Path(__file__).resolve().parent
R=Path('/mnt/development/csgrs/target/hyperbrep-development')
E=R/'crates/hyperbrep/docs/evidence/2026-10-19-section-differentials'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((O/'results.json').read_text())
labels=['final-metadata-fmt','final-metadata-diff-check','final-metadata-audit','final-metadata-style-audit']
for label in labels:
    r=next(r for r in rows if r['label']==label)
    assert r['exit_code']==0, label
    assert sha(Path(r['log']))==r['log_sha256'],label
    assert sha(Path(r['source_patch']))==r['source_patch_sha256'],label
(E/'final-metadata-checks.json').write_text(json.dumps([r for r in rows if r['label'] in labels],indent=2)+'\n')
shutil.copy2(O/'metadata-audit-v2.json',E/'metadata-audit.json')
shutil.copy2(O/'metadata-format-note.md',E/'metadata-format-note.md')
assert not (O/'FROZEN.md').exists()
(O/'FROZEN.md').write_text('This is a frozen evidence snapshot. Do not run its drivers in place or overwrite logs, source manifests, artifacts, or measurements. Copy a recipe into a fresh output directory and adjust paths for future qualification.\n')
files=[]
for p in sorted(O.rglob('*')):
    rel=p.relative_to(O)
    if any(part in {'bin','target','__pycache__','.git'} for part in rel.parts):continue
    if p.is_file() and p.name!='results.lock':
        assert not p.is_symlink(),p
        files.append(p)
members={str(p.relative_to(O)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
(E/'raw-evidence-members.json').write_text(json.dumps(members,indent=2)+'\n')
archive=E/'raw-evidence.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for p in files:tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,item in members.items():
        data=tar.extractfile(name).read()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256'],name
manifest=dict(
    schema_version=1, increment='section-differentials-2026-10-19',
    baseline='b5988e6c03865713e70a1162d6a75878383f524b',
    source='candidate-source.json', qualification='verification.json',
    final_metadata='final-metadata-checks.json', raw_members='raw-evidence-members.json',
    files={str(p.relative_to(E)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(E.rglob('*')) if p.is_file()},
    limitations='Affected BRep consumer evidence only. No release-readiness, full workflow, stable performance non-regression or push claim. All work packages remain open/in-progress.',
)
(E/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(files=len(manifest['files']),raw_members=len(members),raw_bytes=archive.stat().st_size,manifest=str(E/'manifest.json')),indent=2))
