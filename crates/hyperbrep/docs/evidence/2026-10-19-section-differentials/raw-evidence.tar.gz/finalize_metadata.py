"""Create the admission record only after all frozen-source checks and costs pass."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

O = Path(__file__).resolve().parent
R = Path('/mnt/development/csgrs/target/hyperbrep-development')
REL = 'crates/hyperbrep/docs/evidence/2026-10-19-section-differentials'
E = R / REL

def load(name):
    return json.loads((O/name).read_text())

def dump(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

assert not E.exists()
v, t, a, c = [load(n) for n in ['verification.json', 'test-summary.json', 'archive-comparison.json', 'cost-analysis.json']]
for p, digest in load('candidate-source.json')['files'].items():
    assert hashlib.sha256((R/p).read_bytes()).hexdigest() == digest, p
b = t['final-brep-release-tests']
assert b['failed'] == b['ignored'] == 0
owner = sum(t[k]['passed'] for k in t if k != 'final-brep-release-tests')
validation = (
    f"All-feature release BRep/IO suites pass {b['passed']} tests in {b['batches']} batches, with no failures or ignored tests. "
    f"Focused curve polynomial/point/fiber/work-budget, rational-map and derivative-owner checks pass {owner} tests. "
    "All-feature/all-target Clippy for Hypercurve, HyperBRep and HyperBRep-IO, warning-denied rustdoc, BRep fuzz-target compilation and formatting pass. "
    "Six shared public differential workflows and one additional similarity-composition workflow pass natively and as seven actual zero-import Wasmtime exports. "
    "Independent first/second/third derivative identities cover both full-circle pcurves, selected algebraic parameters, unweighted/projective cubic sections, native Bezier and non-unit-domain NURBS derivatives, restriction, public-chart reversal, general affine transport and cold replay. "
    "Smooth vertical events yield oriented nonzero directions; singular/stationary limits, selected-parallel nonzero-RHS magnitudes, invalid domains/orders and exhausted budgets retain typed outcomes. "
    "Exact 1e-12 linear comparisons, original 0/0 rejection and strict/approximate/strict recovery are exercised. "
    f"All {a['preserved_files']} prior archive records are byte-identical to the baseline and previous frozen evidence, with no migration from archive 14; {a['new_files']} new records have {a['new_unique_payloads']} distinct payloads. "
    "Geometric identities, required model validation and deterministic bytes are checked separately. The clean baseline success probe fails with typed Unsupported derivatives and the directly migrated candidate probe passes. "
    "The fixture audit preserves 172 existing test files byte-for-byte, three support fixtures and the geometry unit-test module modulo mechanical Parameter/coordinate-view API changes, and strengthens one old regular-derivative refusal to exact dx=1,dy=0. "
    "No complete trimmed-face or curved-solid Boolean result is claimed."
)
s = c['summary']
cost = (
    "Three alternating CPU-10 process pairs run all 31 old cost workflows, retaining complete assertions, materialization, validation and replay. "
    "The polynomial_branches recipe now demands a successful exact derivative where its baseline required refusal; its raw costs are kept separately and are not a same-work comparison. "
    f"The other {s['same_contract_workflows']} workflows yield {s['same_contract_phase_medians']} first/repeated-fresh-input phase medians and {s['paired_phase_rows']} paired raw phase rows. "
    f"Median paired latency ratios range {s['minimum_median_ratio']:.6f} to {s['maximum_median_ratio']:.6f}; {s['phases_above_ten_percent']} exceed the 10% review marker. "
    f"{s['paired_rows_increased_allocation_calls']} paired rows increase counted Rust allocation calls and {s['paired_rows_increased_requested_bytes']} increase requested bytes. "
    "Allocation-call and requested-byte counts are identical in all 180 same-contract pairs. The flagged phase is surface/joint_forms/first_fresh_input: its three candidate/baseline latency ratios are 1.370930, 1.119002 and 1.371168. This repeated first-call slowdown remains an explicit performance follow-up; its cause has not been established. "
    f"Maximum observed process RSS is {s['maximum_rss_kib']} KiB. Matched executable byte changes are {s['binary_byte_deltas']}. "
    "Seven new successful differential workflows have no successful baseline and retain three absolute process measurements. Native/WASM sizes, hashes and all adverse samples remain in the record. "
    "No build runs during measurement. Requested Rust allocation traffic is not live heap and excludes foreign allocator internals. "
    "The 10% marker is not a significance test; shared-host timings establish neither a speedup nor stable latency non-regression. "
    "Earlier plane/tensor timing regressions and their separate confirmation remain open and are not superseded. "
    "This is a certified-completion extension, not a performance-only change. The factor-exponent recurrence avoids algebraic denominator doubling; it is not an independently measured speedup claim."
)
limits = (
    "Regular implicit graphs and admitted rational images retain their source chart and support finite derivative orders under owner controls. "
    "Fy-zero derivative limits, gradient-zero branch germs, stationary image tangent limits, same-source spatial vector products, selected surface partials/normals, differential whole-section proofs and trim arrangements remain open. "
    "Selected parallel vectors admit zero-RHS linear signs; radical magnitudes and coordinate-image views remain unsupported. "
    "General NURBS/surface-surface sections, vertical/repeated/boundary components, folded projections, selected angular/procedural evaluation and the previous native-conic affine cold-replay blocker remain separate frontiers. "
    "Curve3::derivative_at now accepts Parameter and returns GeometricVector3; CurveDerivative3 is removed with direct caller migration and no shim. Archive 14 is unchanged. "
    "A replayed coordinate-image point proves its value, not a separately serialized tangent claim. "
    "Jet reservation and owner budgets do not bound total work, coefficient-bit growth, heap, stack or cancellation; externally time-contained checks are not a general resource bound. "
    "Source-path consumers do not establish installed distributions or production bindings. Runtime fuzz/ASan/lexicase, formal proofs, measured coverage, MSRV, full release/workflow and push gates remain unqualified. "
    "All 28 work packages remain open/in-progress. The eaa0cae54 push exception is consumed; this increment is not pushed."
)
record = dict(
    id='section-differentials-2026-10-19',
    work_packages=['WP02','WP05a','WP05b','WP06','WP13','WP21'],
    properties=['P1','P4','P5','P6','P8','P9','P15','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P38','P39'],
    change='Retain exact implicit section jets, oriented smooth-event tangents and spatial differential vectors through selected parameters, affine transport and cold replay.',
    sources=['../../hypercurve/src/polynomial_curve_differential.rs','../../hypercurve/src/curve_vector.rs','../../hypercurve/src/bezier_algebraic_image.rs','../src/geometry/vector.rs','../src/geometry/planar_image.rs','../src/geometry.rs','../src/parameter.rs','../../hyperbrep-io/src/step/write/advanced/geometry.rs','../tests/support/section_differentials.rs'],
    evidence='evidence/2026-10-19-section-differentials/manifest.json',
    validation=validation, cost_evidence=cost, limits=limits,
)
dump(O/'admission-record.json', record)

readme = '# Retained section differentials\n\n' + validation+'\n\n'+cost+'\n\n'+limits+'\n\n'+(
    '`contract.md` identifies the pre-edit owners, domain and missing acceptance. '
    '`implementation-notes.md` records the implicit recurrence, common-field authority, smooth-event orientation and public-chart migration. '
    '`candidate-source.json`, `verification.json`, `test-summary.json`, `fixture-migration.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate source identity, exact behavior, deterministic artifacts and costs. '
    '`ideas.json` records considered approaches; `next-domains.md` carries the full remaining plan forward.\n\n'
    '`raw-evidence.tar.gz` retains command/log/source patches, all initial failures, original baseline probe, consumer manifests/locks, supplemental sources, archive outputs and raw cost/RSS samples. '
    'Executables and caches are excluded. Baseline binaries were SHA-256 verified against the previous frozen candidate and its complete recorded source snapshot was matched to clean main. '
    'Fresh baseline calls regenerate every prior artifact. Reproduction in a new checkout requires adjusting the explicit source/output paths. Never execute a frozen snapshot runner after its evidence is committed.\n\n'
    'Early test assumptions about reversal were corrected to use the public exact chart, while retaining independent derivative/sign assertions. '
    'One early compilation overlapped an API edit and is diagnostic only. The first migration-audit script did not account for two rustfmt-inserted optional commas; its corrected version compares complete formatted bodies without changing production or test source. '
    'The supplemental consumer initially collided with its exported entry-point name; only its private function identifier changed. Both failed harness versions and their corrections remain in the raw record. '
    'Final checks qualify the immutable 32-file candidate snapshot and the separately hashed supplemental recipe.\n'
)
(O/'README.md').write_text(readme)

status_path = R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
before_status = status_path.read_bytes()
status = json.loads(before_status)
assert len(status['increments']) == 77 and len(status['work_packages']) == 28 and not status['complete']
(O/'implementation-status-before.json').write_bytes(before_status)
status['increments'].append(record)
status['updated_on'] = '2026-10-19'
status['next_actions'].insert(0, 'Continue WP05a/WP05b/WP06 from evidence/2026-10-19-section-differentials/next-domains.md. Regular implicit section jets and smooth-event directions now remain exact through selected spatial queries and replay. Preserve the full prior section corpus and seven new differential workflows while extending singular branch germs, same-source vector products, selected surface partials/normals, dual-chart differential proofs and trim arrangements. All modeling, resource and delivery work packages remain active.')
dump(status_path, status)

# Locate the precise nested JSON value without reformatting any surrounding byte.
def value_span(text, keys):
    decoder = json.JSONDecoder()
    start = 0
    for wanted in keys:
        while text[start].isspace(): start += 1
        assert text[start] == '{'
        pos = start + 1
        while True:
            while text[pos].isspace() or text[pos] == ',': pos += 1
            key, end = decoder.raw_decode(text, pos)
            pos = end
            while text[pos].isspace(): pos += 1
            assert text[pos] == ':'
            pos += 1
            while text[pos].isspace(): pos += 1
            _, end = decoder.raw_decode(text, pos)
            if key == wanted:
                start = pos
                break
            pos = end
            assert text[pos] != '}', wanted
    return start, end

ledger = R/'docs/properties-status.json'
original = ledger.read_bytes()
(O/'properties-status-before.json').write_bytes(original)
text = original.decode('utf-8')
start, end = value_span(text, ['current_work','hyperbrep'])
owned = json.loads(text[start:end])
owned.update(latest_evidence=REL+'/manifest.json', qualification=validation,
    latest_implementation=record['id'], latest_feature_evidence=REL+'/manifest.json',
    latest_update_check=REL+'/upstream-check.json', performance_evidence=cost, limits=limits)
line = text[text.rfind('\n', 0, start)+1:start]
indent = len(line)-len(line.lstrip())
replacement = json.dumps(owned, indent=2, ensure_ascii=False).replace('\n', '\n'+' '*indent)
new = (text[:start]+replacement+text[end:]).encode('utf-8')
ledger.write_bytes(new)
prefix, suffix = text[:start].encode('utf-8'), text[end:].encode('utf-8')
assert new.startswith(prefix) and new.endswith(suffix)
old_obj, new_obj = json.loads(original), json.loads(new)
old_obj['current_work']['hyperbrep'] = new_obj['current_work']['hyperbrep']
assert old_obj == new_obj
dump(O/'ledger-byte-scope.json', dict(
    path='docs/properties-status.json', changed_value='current_work.hyperbrep',
    prefix_bytes=len(prefix), suffix_bytes=len(suffix),
    prefix_sha256=hashlib.sha256(prefix).hexdigest(), suffix_sha256=hashlib.sha256(suffix).hexdigest(),
    outside_bytes_unchanged=True,
))
new_status = json.loads(status_path.read_bytes())
old_status = json.loads(before_status)
assert new_status['increments'][:-1] == old_status['increments']
assert new_status['work_packages'] == old_status['work_packages']
assert new_status['next_actions'][1:] == old_status['next_actions']

E.mkdir(parents=True)
visible = ['README.md','contract.md','implementation-notes.md','next-domains.md','ideas.json',
    'cost-contract.md','candidate-source.json','baseline-source.json','environment.json',
    'verification.json','test-summary.json','fixture-migration.json','archive-comparison.json',
    'cost-analysis.json','binary-sizes.json','reused-baseline-binaries.json','upstream-check.json',
    'audit-correction.md','audit-correction.json','similarity-correction.md','similarity-source-v2.json',
    'admission-record.json','ledger-byte-scope.json']
for name in visible:
    shutil.copy2(O/name, E/name)
shutil.copy2(O/'similarity/cases.rs', E/'similarity_probe.rs')
print(json.dumps(dict(evidence=str(E), increments=len(new_status['increments']), work_packages=len(new_status['work_packages']), outside_ledger_bytes_unchanged=True), indent=2))
