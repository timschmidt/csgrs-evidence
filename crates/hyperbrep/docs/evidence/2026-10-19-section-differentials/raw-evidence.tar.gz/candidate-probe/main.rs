use hyperbrep::*;
fn q(n:i32,d:i32)->Real {(Real::from(n)/Real::from(d)).unwrap()}
fn main(){
 let offsets=[q(0,1),q(-1,2),q(0,1)];
 let net=(0..3).map(|j|(0..3).map(|i|Point3::new(q(i as i32,2),q(j as i32,2),q(7,16)+&offsets[i]+&offsets[j])).collect()).collect();
 let surface=Surface::rational_bezier(net,vec![vec![Real::one();3];3]).unwrap();
 let plane=Surface::plane(Point3::origin(),Vector3::x(),Vector3::y()).unwrap();
 let sections=match plane.intersect_surface(&surface).unwrap(){SurfaceSurfaceIntersection::Curves(c)=>c,other=>panic!("{other:?}")};
 assert_eq!(sections.len(),2);
 let parameter=q(3,5);
 for section in sections {
   let pcurve=section.second_pcurve().materialize().unwrap();
   let planar=pcurve.curve().derivative_at(&parameter.clone().into());
   let spatial=section.curve().derivative_at(&parameter.clone().into(),1);
   println!("planar={:?}; spatial={:?}",planar.as_ref().err(),spatial.as_ref().err());
   assert!(planar.is_ok() && spatial.is_ok(),"regular exact section derivatives must be consumable");
 }
}
