//! Independent half-cylinder expectations and complete exact exchange workflows.
use hyperbrep::*;
use hyperbrep_io::step::{StepBody, StepWriteOptions};

#[allow(dead_code)]
#[path = "analytic_export.rs"]
mod analytic;
#[allow(dead_code)]
#[path = "../../../hyperbrep/tests/support/seam_cuts.rs"]
mod seam;

pub fn same_height() -> u64 {
    let source = builder::cylinder(5.into(), 6.into()).unwrap();
    let cutter = builder::cuboid(seam::point(0, -20, 0), seam::point(20, 20, 6)).unwrap();
    let half = boolean::difference(&source, &cutter).unwrap();
    let mut receipt = 0xcbf29ce484222325_u64;
    for reflected in [false, true] {
        let scale = if reflected {
            seam::ratio(1, 1000)
        } else {
            Real::one()
        };
        let map = if reflected {
            seam::similarity(&scale, true)
        } else {
            Matrix4::identity()
        };
        let moved = half.model().transformed(&map).unwrap();
        let replay = seam::reload(&moved);
        let output = analytic::export(
            &[StepBody {
                solid: replay.solids().next().unwrap(),
                name: "half cylinder",
            }],
            &StepWriteOptions::new("prism.step", "2026-10-16T00:00:00"),
        );
        for byte in output.text().bytes() {
            receipt = (receipt ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
        let imported = analytic::reimport(&output);
        let body = imported.bodies()[0].solid();
        analytic::equal(
            &body.volume().unwrap(),
            &(Real::from(75) * Real::pi() * &scale * &scale * &scale),
        );
        let area = body
            .outer()
            .faces()
            .map(|face| face.area().unwrap())
            .fold(Real::zero(), |a, b| a + b);
        analytic::equal(
            &area,
            &((Real::from(55) * Real::pi() + Real::from(60)) * &scale * &scale),
        );
        for (point, expected) in [
            (seam::point(-1, 0, 3), SolidPointLocation::Inside),
            (seam::point(1, 0, 3), SolidPointLocation::Outside),
            (seam::point(0, 0, 3), SolidPointLocation::Boundary),
            (seam::point(-5, 0, 3), SolidPointLocation::Boundary),
        ] {
            assert_eq!(
                body.classify_point(&map.transform_point3(&point).unwrap())
                    .unwrap(),
                expected
            );
        }
        let retained = BodySet::from_solid(body);
        let empty = boolean::difference(&retained, &retained).unwrap();
        assert_eq!(
            empty.model().to_json().unwrap(),
            BodySet::empty().model().to_json().unwrap()
        );
        let recovered = boolean::union(&empty, &retained).unwrap();
        analytic::equal(
            &recovered.bodies().next().unwrap().volume().unwrap(),
            &body.volume().unwrap(),
        );
    }
    receipt
}
