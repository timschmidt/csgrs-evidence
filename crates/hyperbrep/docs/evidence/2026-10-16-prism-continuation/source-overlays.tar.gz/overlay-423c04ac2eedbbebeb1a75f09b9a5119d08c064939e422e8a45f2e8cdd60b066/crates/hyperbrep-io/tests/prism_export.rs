#[allow(dead_code)]
#[path = "support/prism_export.rs"]
mod acceptance;

#[test]
fn exact_prism_extrusions_export_reimport_and_continue() {
    acceptance::same_height();
}
