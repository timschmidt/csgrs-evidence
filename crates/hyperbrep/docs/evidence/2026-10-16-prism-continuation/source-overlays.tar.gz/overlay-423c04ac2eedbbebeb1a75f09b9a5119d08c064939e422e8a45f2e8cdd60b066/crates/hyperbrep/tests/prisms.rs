#[allow(dead_code)]
#[path = "support/prisms.rs"]
mod acceptance;

#[test]
fn circular_region_extrusion_preserves_measurement_and_continuation() {
    acceptance::same_height_cylinder();
}
