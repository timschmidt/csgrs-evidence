#[allow(dead_code)]
#[path = "support/prism_export.rs"]
mod acceptance;

#[test]
fn exact_prism_extrusions_export_reimport_and_continue() {
    acceptance::same_height();
}

#[test]
fn circular_holes_preserve_inward_orientation_and_exact_replay() {
    acceptance::holes();
}

#[test]
fn malformed_prism_exchange_stays_invalid_and_can_be_retried() {
    acceptance::malformed();
}
