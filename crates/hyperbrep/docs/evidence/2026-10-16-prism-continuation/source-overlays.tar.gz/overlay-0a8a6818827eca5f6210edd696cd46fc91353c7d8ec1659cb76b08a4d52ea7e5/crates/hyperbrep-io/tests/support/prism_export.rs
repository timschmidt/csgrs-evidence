//! Independent half-cylinder expectations and complete exact exchange workflows.
use hyperbrep::*;
use hyperbrep_io::step::{StepBody, StepWriteOptions};

#[allow(dead_code)]
#[path = "analytic_export.rs"]
mod analytic;
#[allow(dead_code)]
#[path = "../../../hyperbrep/tests/support/seam_cuts.rs"]
mod seam;

pub fn same_height() -> u64 {
    let source = builder::cylinder(5.into(), 6.into()).unwrap();
    let cutter = builder::cuboid(seam::point(0, -20, 0), seam::point(20, 20, 6)).unwrap();
    let half = boolean::difference(&source, &cutter).unwrap();
    let mut receipt = 0xcbf29ce484222325_u64;
    for reflected in [false, true] {
        let scale = if reflected {
            seam::ratio(1, 1000)
        } else {
            Real::one()
        };
        let map = if reflected {
            seam::similarity(&scale, true)
        } else {
            Matrix4::identity()
        };
        let moved = half.model().transformed(&map).unwrap();
        let replay = seam::reload(&moved);
        let output = analytic::export(
            &[StepBody {
                solid: replay.solids().next().unwrap(),
                name: "half cylinder",
            }],
            &StepWriteOptions::new("prism.step", "2026-10-16T00:00:00"),
        );
        for byte in output.text().bytes() {
            receipt = (receipt ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
        let imported = analytic::reimport(&output);
        let body = imported.bodies()[0].solid();
        analytic::equal(
            &body.volume().unwrap(),
            &(Real::from(75) * Real::pi() * &scale * &scale * &scale),
        );
        let area = body
            .outer()
            .faces()
            .map(|face| face.area().unwrap())
            .fold(Real::zero(), |a, b| a + b);
        analytic::equal(
            &area,
            &((Real::from(55) * Real::pi() + Real::from(60)) * &scale * &scale),
        );
        for (point, expected) in [
            (seam::point(-1, 0, 3), SolidPointLocation::Inside),
            (seam::point(1, 0, 3), SolidPointLocation::Outside),
            (seam::point(0, 0, 3), SolidPointLocation::Boundary),
            (seam::point(-5, 0, 3), SolidPointLocation::Boundary),
        ] {
            assert_eq!(
                body.classify_point(&map.transform_point3(&point).unwrap())
                    .unwrap(),
                expected
            );
        }
        let retained = BodySet::from_solid(body);
        let empty = boolean::difference(&retained, &retained).unwrap();
        assert_eq!(
            empty.model().to_json().unwrap(),
            BodySet::empty().model().to_json().unwrap()
        );
        let recovered = boolean::union(&empty, &retained).unwrap();
        analytic::equal(
            &recovered.bodies().next().unwrap().volume().unwrap(),
            &body.volume().unwrap(),
        );
    }
    receipt
}

pub fn holes() -> u64 {
    use hypercurve::{CircularArc2, Curve2, CurvePath2, Point2 as UV};
    let circle = |r: i32| {
        CurvePath2::try_new(
            [((r, 0), (-r, 0)), ((-r, 0), (r, 0))]
                .into_iter()
                .map(|(a, b)| {
                    Curve2::from(
                        CircularArc2::try_from_center(
                            UV::new(a.0.into(), a.1.into()),
                            UV::new(b.0.into(), b.1.into()),
                            UV::new(0.into(), 0.into()),
                            false,
                        )
                        .unwrap(),
                    )
                })
                .collect(),
        )
        .unwrap()
    };
    let source =
        builder::extrude_path_region(&circle(5), &[circle(2)], 0.into(), 6.into()).unwrap();
    let mut receipt = 0xcbf29ce484222325_u64;
    for reflected in [false, true] {
        let scale = if reflected {
            seam::ratio(1, 1000)
        } else {
            Real::one()
        };
        let map = if reflected {
            seam::similarity(&scale, true)
        } else {
            Matrix4::identity()
        };
        let moved = source.model().transformed(&map).unwrap();
        let replay = seam::reload(&moved);
        let output = analytic::export(
            &[StepBody {
                solid: replay.solids().next().unwrap(),
                name: "annular prism",
            }],
            &StepWriteOptions::new("annulus.step", "2026-10-16T00:00:00"),
        );
        assert!(
            output.bodies()[0]
                .faces()
                .iter()
                .any(|f| f.orientation != f.source.orientation())
        );
        for byte in output.text().bytes() {
            receipt = (receipt ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
        let imported = analytic::reimport(&output);
        let body = imported.bodies()[0].solid();
        analytic::equal(
            &body.volume().unwrap(),
            &(Real::from(126) * Real::pi() * &scale * &scale * &scale),
        );
        let area = body
            .outer()
            .faces()
            .map(|f| f.area().unwrap())
            .fold(Real::zero(), |a, b| a + b);
        analytic::equal(&area, &(Real::from(126) * Real::pi() * &scale * &scale));
        let delta = seam::ratio(1, 1_000_000) * seam::ratio(1, 1_000_000);
        for (x, expected) in [
            (Real::zero(), SolidPointLocation::Outside),
            (Real::from(2), SolidPointLocation::Boundary),
            (Real::from(2) - &delta, SolidPointLocation::Outside),
            (Real::from(2) + &delta, SolidPointLocation::Inside),
            (Real::from(5), SolidPointLocation::Boundary),
            (Real::from(5) + &delta, SolidPointLocation::Outside),
        ] {
            assert_eq!(
                body.classify_point(
                    &map.transform_point3(&Point3::new(x, 0.into(), 3.into()))
                        .unwrap()
                )
                .unwrap(),
                expected
            );
        }
        let edge = imported.bodies()[0]
            .model()
            .edges()
            .find(|e| e.curve().kind() == Curve3Kind::CircleArc)
            .unwrap();
        let (a, b) = edge.domain().try_real_endpoints().unwrap();
        let split = edge.split(((a + b) * seam::ratio(1, 2)).into()).unwrap();
        let replay = seam::reload(split.model());
        analytic::equal(
            &replay.solids().next().unwrap().volume().unwrap(),
            &body.volume().unwrap(),
        );
        let set = BodySet::from_solid(body);
        assert!(boolean::difference(&set, &set).unwrap().is_empty());
    }
    receipt
}

pub fn malformed() {
    use hyperbrep_io::step::{ImportLimits, StepFile, StepReadOptions};
    let source = builder::cylinder(5.into(), 6.into()).unwrap();
    let cutter = builder::cuboid(seam::point(0, -20, 0), seam::point(20, 20, 6)).unwrap();
    let half = boolean::difference(&source, &cutter).unwrap();
    let output = analytic::export(
        &[StepBody {
            solid: half.bodies().next().unwrap(),
            name: "half",
        }],
        &StepWriteOptions::new("invalid.step", "2026-10-16T00:00:00"),
    );
    let face = output.bodies()[0]
        .faces()
        .iter()
        .find(|f| f.source.surface().kind() == SurfaceKind::Extrusion)
        .unwrap();
    let row = output
        .text()
        .lines()
        .find(|line| line.starts_with(&format!("#{}=", face.entity)))
        .unwrap();
    let flipped = if row.ends_with(".T.);") {
        row.replace(".T.);", ".F.);")
    } else {
        row.replace(".F.);", ".T.);")
    };
    let bad_orientation = output.text().replace(row, &flipped);
    // Changing an actual circle radius while retaining its vertices and trims
    // must fail the geometric image contract before solid admission.
    let circle = output
        .text()
        .lines()
        .find(|line| line.contains("=CIRCLE("))
        .unwrap();
    let cut = circle.rfind(',').unwrap();
    let bad_radius = output
        .text()
        .replace(circle, &format!("{},4.);", &circle[..cut]));
    for text in [bad_orientation, bad_radius] {
        let file = StepFile::read(text.as_bytes(), &StepReadOptions::default()).unwrap();
        let error = file
            .import_representation(
                output.representation(),
                &ImportLimits::default(),
                &analytic::context(),
            )
            .result
            .unwrap()
            .unwrap_err();
        assert!(error.entity.is_some());
        // Reusing the same public pipeline after rejection remains successful.
        analytic::reimport(&output);
    }
}
