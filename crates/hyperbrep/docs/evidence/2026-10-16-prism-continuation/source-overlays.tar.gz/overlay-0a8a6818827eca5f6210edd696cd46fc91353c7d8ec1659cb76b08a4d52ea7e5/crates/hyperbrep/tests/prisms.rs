#[allow(dead_code)]
#[path = "support/prisms.rs"]
mod acceptance;

#[test]
fn circular_region_extrusion_preserves_measurement_and_continuation() {
    acceptance::same_height_cylinder();
}

#[test]
fn covering_slabs_preserve_exact_circular_composition() {
    acceptance::covering_cylinders();
}
