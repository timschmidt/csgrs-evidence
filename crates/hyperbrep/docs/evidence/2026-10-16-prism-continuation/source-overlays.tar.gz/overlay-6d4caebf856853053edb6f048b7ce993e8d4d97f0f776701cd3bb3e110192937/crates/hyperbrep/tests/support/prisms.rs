//! Exact prism expectations are derived from circular area and rectangular cuts.
use hyperbrep::{
    BodySet, Curve3Kind, Matrix4, Model, Point3, Real, SolidPointLocation, boolean, builder,
};

#[allow(dead_code)]
#[path = "seam_cuts.rs"]
mod seam;
pub use seam::{equal, point as p, ratio as q};

fn samples(column: usize) -> Vec<(Point3, SolidPointLocation)> {
    use SolidPointLocation::{Boundary as B, Inside as I, Outside as O};
    let delta = q(1, 1_000_000) * q(1, 1_000_000);
    vec![
        (p(-1, 0, 3), [I, O, I]),
        (p(1, 0, 3), [O, I, I]),
        (p(0, 0, 3), [B, B, I]),
        (p(-5, 0, 3), [B, O, B]),
        (p(5, 0, 3), [O, B, B]),
        (
            Point3::new(Real::from(-5) + &delta, 0.into(), 3.into()),
            [I, O, I],
        ),
        (
            Point3::new(Real::from(-5) - &delta, 0.into(), 3.into()),
            [O, O, O],
        ),
        (Point3::new(-&delta, 0.into(), 3.into()), [I, O, I]),
        (Point3::new(delta.clone(), 0.into(), 3.into()), [O, I, I]),
        (p(-1, 0, 0), [B, O, B]),
        (p(-1, 0, 6), [B, O, B]),
        (
            Point3::new((-1).into(), 0.into(), Real::from(6) - &delta),
            [I, O, I],
        ),
        (
            Point3::new((-1).into(), 0.into(), Real::from(6) + &delta),
            [O, O, O],
        ),
    ]
    .into_iter()
    .map(|(point, expected)| (point, expected[column]))
    .collect()
}

fn verify(model: &Model, column: usize, map: &Matrix4, scale: &Real) {
    assert_eq!(model.solids().count(), 1);
    let volume = Real::from(if column == 2 { 150 } else { 75 }) * Real::pi();
    let area = if column == 2 {
        Real::from(110) * Real::pi()
    } else {
        Real::from(55) * Real::pi() + Real::from(60)
    };
    equal(
        &model.solids().next().unwrap().volume().unwrap(),
        &(volume * scale * scale * scale),
    );
    let actual_area = model
        .faces()
        .map(|face| face.area().expect("a circular prism has exact face areas"))
        .fold(Real::zero(), |sum, value| sum + value);
    equal(&actual_area, &(area * scale * scale));
    assert!(
        model
            .edges()
            .any(|edge| edge.curve().kind() == Curve3Kind::CircleArc)
    );
    assert!(model.edges().all(|edge| matches!(
        edge.curve().kind(),
        Curve3Kind::Line | Curve3Kind::CircleArc
    )));
    for edge in model.edges() {
        let uses: Vec<_> = edge.uses().collect();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
    for (point, expected) in samples(column) {
        assert_eq!(
            model
                .solids()
                .next()
                .unwrap()
                .classify_point(&map.transform_point3(&point).unwrap())
                .unwrap(),
            expected
        );
    }
}

fn check(result: &BodySet, column: usize) -> u64 {
    assert_eq!(result.len(), 1);
    let json = result.model().to_json().unwrap();
    let replay = seam::reload(result.model());
    for model in [result.model(), &replay] {
        verify(model, column, &Matrix4::identity(), &Real::one());
    }
    let edge = replay
        .edges()
        .find(|edge| edge.curve().kind() == Curve3Kind::CircleArc)
        .unwrap();
    let middle = ((edge.domain().start().try_real().unwrap()
        + edge.domain().end().try_real().unwrap())
        / Real::from(2))
    .unwrap();
    let split = edge.split(middle.into()).unwrap();
    let replay = seam::reload(split.model());
    verify(&replay, column, &Matrix4::identity(), &Real::one());
    let scale = q(1, 1000);
    let map = seam::similarity(&scale, true);
    let moved = replay.transformed(&map).unwrap();
    verify(&seam::reload(&moved), column, &map, &scale);
    json.bytes().fold(0xcbf29ce484222325_u64, |hash, byte| {
        (hash ^ u64::from(byte)).wrapping_mul(0x100000001b3)
    })
}

/// Same-height control: only representation preservation changes this workflow.
pub fn same_height_cylinder() -> u64 {
    let source = builder::cylinder(5.into(), 6.into()).unwrap();
    let cutter = builder::cuboid(p(0, -20, 0), p(20, 20, 6)).unwrap();
    let difference = boolean::difference(&source, &cutter).unwrap();
    let intersection = boolean::intersection(&source, &cutter).unwrap();
    let mut receipt = check(&difference, 0);
    let mut record = |value: u64| receipt = (receipt ^ value).wrapping_mul(0x100000001b3);
    record(check(&intersection, 1));
    record(check(&boolean::intersection(&cutter, &source).unwrap(), 1));
    let difference = BodySet::from_solid(seam::reload(difference.model()).solids().next().unwrap());
    let intersection =
        BodySet::from_solid(seam::reload(intersection.model()).solids().next().unwrap());
    for (first, second) in [(&difference, &intersection), (&intersection, &difference)] {
        record(check(&boolean::union(first, second).unwrap(), 2));
    }
    record(check(
        &boolean::difference(&difference, &cutter).unwrap(),
        0,
    ));
    let empty = boolean::difference(&difference, &source).unwrap();
    assert_eq!(
        empty.model().to_json().unwrap(),
        BodySet::empty().model().to_json().unwrap()
    );
    record(check(&boolean::union(&empty, &intersection).unwrap(), 1));
    receipt
}
