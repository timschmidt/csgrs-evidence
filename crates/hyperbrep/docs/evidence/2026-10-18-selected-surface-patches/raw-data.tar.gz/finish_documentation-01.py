"""Finalize documentation only after source-frozen qualification and costs complete."""
from pathlib import Path
import collections,copy,hashlib,json,shutil,statistics,subprocess
from source_identity import source_identity
from run import OUT,ROOT

NAME='2026-10-18-selected-surface-patches'
REL=Path('crates/hyperbrep/docs/evidence')/NAME
DEST=ROOT/REL
BASE='eaa0cae54442e0e5c311c3ad917a489e0319892e'
UPSTREAM='dbe99e3cc145e8ca58a53ade6e79fd46311972fb'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda name:json.loads((OUT/name).read_text())
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')

def replace(path,old,new):
    s=path.read_text();assert old in s,(path,old);path.write_text(s.replace(old,new,1))

cost=read('consumer-costs.json');rows=cost['rows'];trials=cost['trials']
assert len(rows)==99 and len(trials)==57
assert all(t['exit_code']==t['resource']['exit_code']==0 for t in trials)
consumers={s:read(s+'-consumers.json') for s in ['baseline','candidate']}
assert [len(consumers[s]) for s in ['baseline','candidate']]==[11,14]
assert sum(r['groups'] for r in consumers['candidate'] if 'native' in r)==107
assert sum(r['groups'] for r in consumers['candidate'] if 'wasm' in r)==245
for side,root in [('baseline',Path('/mnt/development/csgrs')),('candidate',ROOT)]:
    assert source_identity(root)==read(side+'-consumer-source.json')
assert read('artifact-review-summary.json')['fresh_pairs']==282
assert len(read('prior-artifact-replay.json'))==477
assert not DEST.exists()
DEST.mkdir(parents=True)

files={
 'README-draft.md':'README.md','contract-final-draft.md':'contract.md',
 'contract.json':'contract-before-edit.json','construction-proof.md':'construction-proof.md',
 'independent-oracles.md':'independent-oracles.md','attempt-review.md':'attempt-review.md',
 'next-domains.md':'next-domains.md','artifact-review-summary.json':'artifact-review-summary.json',
 'artifact-size-summary.json':'artifact-size-summary.json','baseline-replay.json':'baseline-replay.json',
 'baseline-replay-encoding-sizes.json':'baseline-replay-encoding-sizes.json',
 'replay-correction-comparison.json':'replay-correction-comparison.json',
 'upstream-checkpoint.json':'upstream-checkpoint.json','machine.json':'machine.json',
 'consumer-costs.json':'consumer-costs.json','results.json':'validation.json',
 'baseline-consumers.json':'baseline-consumers.json','candidate-consumers.json':'candidate-consumers.json',
 'baseline-consumer-source.json':'baseline-source.json','candidate-consumer-source.json':'candidate-source.json',
 'consumer-02-candidate-original_wasm-wasm-build.source.patch':'qualified-source.patch',
 'wasm-runner-correction.json':'wasm-runner-correction.json','original-wasm-exports.json':'original-wasm-exports.json',
}
for source,target in files.items():shutil.copy2(OUT/source,DEST/target)
shutil.copytree(OUT/'consumers/candidate/patches',DEST/'consumer-project')
shutil.copytree(OUT/'archive-project',DEST/'archive-project')

matched=[r for r in rows if r['matched_contract']]
new=[r for r in rows if not r['matched_contract']]
assert len(matched)==92 and len(new)==7
slower=[r for r in matched if r['ratio']>1.1]
adverse_alloc=[r for r in matched if any(r['candidate'][k]>r['baseline'][k] for k in ['allocation_calls','requested_bytes'])]
summary=dict(matched_semantic_rows=len(matched),new_absolute_rows=len(new),process_trials=len(trials),
    timing_ratio_min=min(r['ratio'] for r in matched),timing_ratio_max=max(r['ratio'] for r in matched),
    over_ten_percent_review_marker=len(slower),allocation_or_requested_byte_increases=len(adverse_alloc),
    slower_rows=slower,allocation_increase_rows=adverse_alloc,scope=cost['scope'],
    retention='Correctness and selected-domain completion; not an optimization. Archive growth and timing regressions remain explicit follow-up work. No release/performance gate is marked complete.')
write(DEST/'cost-summary.json',summary)
lines=['# Cost observations','',
 'Three alternating pairs per preserved cohort and three absolute new-feature runs. Each case retains one warmup and three measured repetitions, complete fixture bodies and assertions, with allocation counters enabled. Sources and frozen binaries are hash-checked. The host is shared; task builds/tests do not overlap these measurements.','',
 f'The {len(matched)} preserved semantic rows have observed time ratios from {summary["timing_ratio_min"]:.6f} to {summary["timing_ratio_max"]:.6f}. {len(slower)} exceed the descriptive 10% review marker; {len(adverse_alloc)} increase allocation calls or cumulative requested bytes. These samples do not establish significance or a general speedup. All adverse rows are retained below.','',
 'The candidate changes first-export pcurve expression encodings. Comparisons retain the completed semantic workflows, not identical output bytes. Retention is for correctness and expanded selected-domain support. Larger archives and slower workflows remain visible work; this record does not establish release performance admission.','',
 '| Cohort / case | Baseline ms | Candidate ms | Time ratio | Baseline allocations | Candidate allocations | Baseline requested bytes | Candidate requested bytes |',
 '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for r in matched:
    a=r['baseline'];b=r['candidate']
    lines.append(f'| {r["cohort"]} / `{r["case"]}` | {a["elapsed_ns"]/1e6:.6f} | {b["elapsed_ns"]/1e6:.6f} | {r["ratio"]:.6f} | {a["allocation_calls"]:g} | {b["allocation_calls"]:g} | {a["requested_bytes"]:g} | {b["requested_bytes"]:g} |')
lines += ['', '## New groups, absolute costs','',
 '| Case | ms | Allocations | Cumulative requested bytes |','| --- | ---: | ---: | ---: |']
for r in new:
    v=r['candidate'];lines.append(f'| `{r["case"]}` | {v["elapsed_ns"]/1e6:.6f} | {v["allocation_calls"]:g} | {v["requested_bytes"]:g} |')
lines += ['', '## Process and executable observations','',
 'Process RSS includes warmup, all cases and runtime overhead; requested bytes are cumulative, not retained heap. Native binary sizes include the consumer and dependencies. These finite observations do not bound coefficient growth, total work, retained memory or cancellation.','',
 '| Cohort / side | Median process wall seconds | Median peak RSS KiB | Native bytes |','| --- | ---: | ---: | ---: |']
for cohort in dict.fromkeys(r['cohort'] for r in trials):
    for side in ['baseline','candidate']:
        ts=[r for r in trials if r['cohort']==cohort and r['side']==side]
        if ts:
            lines.append(f'| {cohort} / {side} | {statistics.median(t["resource"]["wall_seconds"] for t in ts):.6f} | {statistics.median(t["resource"]["maximum_rss_kib"] for t in ts):g} | {ts[0]["binary"]["bytes"]} |')
lines += ['', 'See [complete data](consumer-costs.json), [summary and adverse rows](cost-summary.json), [archive sizes](artifact-size-summary.json), and the lossless raw-data bundle for every trial/log/resource record.','']
(DEST/'costs.md').write_text('\n'.join(lines))

qualification='Seven shared patch groups, 698 all-feature and 690 minimal-feature BRep/IO release tests pass after the final production edit. The later test alias correction is covered by final focused tests, strict Clippy and consumers. Affected strict Clippy/rustdoc, fuzz-target compilation and formatting pass. Source-path native consumers execute 107 groups plus eight original axial exchange workflows; actual zero-import WASM executes all 245 groups. All 354 prior native archives re-encode byte-identically; 115 STEP files import 125 bodies and replay; eight text controls are inventory-only. Fresh paired exports preserve exact values and structure: 177 byte-identical pairs and 105 explicit coefficient-encoding migrations across 2,952 scalar fields. Every export recipe repeats deterministically; 26 new patch archives also replay stably. The original nonorthogonal planar archive failure is reproduced on eaa0 and compared exactly to the corrected output.'
limits='Finite open-shell planar/extrusion patch support, not general embedding, selected revolution/axial parameters, curved arrangements, solid Boolean closure or complete CAD. First-export encodings intentionally change within schema 10; no compatibility reader. Total work, retained heap, coefficient growth and cancellation bounds, runtime fuzz/ASan/lexicase, formal coverage, MSRV, installed distributions and production bindings remain open. All 28 work packages remain open/in-progress. Full pre-push qualification remains required; the eaa0 one-time exception was consumed and does not authorize publishing this increment.'
cost_text=f'Three alternating pairs cover 92 preserved semantic rows; seven new groups have three absolute trials. All 57 processes pass their assertions. Observed time ratios range {summary["timing_ratio_min"]:.6f}–{summary["timing_ratio_max"]:.6f}; {len(slower)} exceed the 10% review marker and {len(adverse_alloc)} increase allocation calls or requested bytes. Selected-profile exports grow from 7,200,347 to 15,409,257 bytes. All adverse observations are retained. Shared-host instrumented samples, changed expression encodings and process RSS establish neither a byte-preserving optimization nor a general speedup or internal bound.'
write(DEST/'qualification-summary.json',dict(base_revision=BASE,upstream_revision=UPSTREAM,qualification=qualification,costs=cost_text,limits=limits,qualified_source_sha256=sha(DEST/'qualified-source.patch'),properties=['P1','P3','P8','P9','P11','P12','P14','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39']))

status_path=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status=json.loads(status_path.read_text());assert not status['complete']
entry=dict(id='selected-surface-patches-2026-10-18',work_packages=['WP02','WP09','WP13','WP21'],
 properties=['P1','P3','P8','P9','P11','P12','P14','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],
 change='Extend public planar_face and extrusion_patch to retained selected endpoints through existing spatial carriers and complete coordinate-image admission. Preserve unchanged planar pcurve definitions during native encoding to fix reproduced cold expression growth.',
 sources=['../src/construction/patches.rs','../src/construction.rs','../src/persistence.rs'],evidence=f'evidence/{NAME}/manifest.json',validation=qualification,cost_evidence=cost_text,limits=limits)
assert all(r['id']!=entry['id'] for r in status['increments']);status['increments'].append(entry)
wp=next(w for w in status['work_packages'] if w['id']=='WP09');assert wp['status']=='open';wp['status']='in-progress'
wp['progress']='Finite selected standalone extrusion patches only; general sweep/loft, revolution and embedding gates remain open.'
assert len(status['work_packages'])==28 and all(w['status'] in ['open','in-progress'] for w in status['work_packages'])
status['next_actions'].insert(0,f'Preserve evidence/{NAME}/manifest.json: final seven patch groups, 245 WASM groups, 354 unchanged prior native archives, 115 STEP inputs, 282 paired fresh artifacts, 26 new archives and every adverse cost. Follow next-domains.md for selected revolution/axis-clearance, complete contact/arrangement/embedding proofs and justified pcurve expression reuse. These correctness/completeness changes do not establish an optimization or close release gates.')
write(status_path,status)

property_path=ROOT/'docs/properties-status.json';properties=json.loads(property_path.read_text());before=copy.deepcopy(properties)
h=properties['current_work']['hyperbrep'];h.update(latest_evidence=str(REL/'manifest.json'),latest_feature_evidence=str(REL/'manifest.json'),latest_implementation=entry['id'],qualification=qualification+' '+cost_text+' '+limits,latest_update_check=str(REL/'upstream-checkpoint.json'))
assert {k:v for k,v in before['current_work'].items() if k!='hyperbrep'}=={k:v for k,v in properties['current_work'].items() if k!='hyperbrep'}
assert {k:v for k,v in before.items() if k!='current_work'}=={k:v for k,v in properties.items() if k!='current_work'}
write(property_path,properties)

plan=ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md'
needle='The [planar lift increment]'
paragraph=f'''The [selected surface-patch increment](evidence/{NAME}/README.md)
advances WP02/WP09/WP13 with public planar faces and finite extrusion patches
whose endpoints retain selected parameters. Ordinary builder admission proves
complete coordinate boundary images. Holes, reversal, affine transforms, selected
contact splits and cold replay consume the result. A reproduced nonorthogonal
archive-growth bug is corrected by preserving unchanged pcurve definitions;
first-export expression changes and their adverse size/time costs are explicitly
audited. General embedding, revolution latitude generators and CAD closure
remain open; no complete work package or release gate is closed.

'''
replace(plan,needle,paragraph+needle)
support=ROOT/'crates/hyperbrep/docs/SUPPORT_MATRIX.md'
replace(support,'One exact `CurvePath2` outer loop plus disjoint holes in an authored plane / open shell','One exact `CurvePath2` outer loop plus disjoint holes in an authored plane, including supported selected procedural/source-restriction endpoints / open shell')
replace(support,'One finite rectangular exact extrusion face / open shell','One finite rectangular exact extrusion face, including selected profile domains with retained connector origins and authored sweep bounds / open shell')
archive=ROOT/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md'
needle='Version 10 is an intentional schema break, not a byte-preserving optimization.'
replace(archive,needle,needle+f'''

The [selected-patch correction](evidence/{NAME}/README.md)
preserves existing pcurve definitions unless analytic-arc export canonicalizes
an incident spatial vertex. This prevents reproduced growth during cold planar
replay. Schema 10 remains unchanged, but fresh scalar expression encodings may
change; exact coefficients, topology/source records, deterministic repeats and
all observed size/time regressions are audited separately. This is a correctness
repair, not a byte-preserving performance change.''')
readme=ROOT/'crates/hyperbrep/README.md'
replace(readme,'with retained connector origins and complete coordinate image proofs;','with retained connector origins and complete coordinate image proofs; see the\n  [selected-patch evidence](docs/evidence/'+NAME+'/README.md);')
write(OUT/'documentation-stage.json',dict(evidence=str(REL),qualified_code_source='candidate-consumer-source.json',source_patch_sha256=sha(DEST/'qualified-source.patch'),work_packages_complete=0,documentation_only_finalization=True))
print('Documentation and ledgers prepared; final checks, bundle, manifest and commit still required.',flush=True)
