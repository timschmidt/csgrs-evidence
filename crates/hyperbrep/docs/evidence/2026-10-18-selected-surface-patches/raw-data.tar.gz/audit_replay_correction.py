"""Compare the original failing face archive to the corresponding final fixture."""
from pathlib import Path
import hashlib,json
from run import OUT,run
candidate=OUT/'artifacts/candidate/patches/0/patch-010.json'
authored=OUT/'patch-03-authored.json'
assert candidate.exists()
a=json.loads(authored.read_text());b=json.loads(candidate.read_text())
assert set(a)==set(b)
# Every record except the planar pcurve expressions must remain identical.
assert all(a[k]==b[k] for k in a if k!='pcurves'),[k for k in a if a[k]!=b[k] and k!='pcurves']
pairs=[dict(name='nonorthogonal-face-first-export.json',baseline=str(authored),candidate=str(candidate))]
inputs=OUT/'replay-correction-pairs.json';inputs.write_text(json.dumps(pairs,indent=2)+'\n')
binary=OUT/'binaries/candidate-archive-replay'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==json.loads((OUT/'archive-consumer.json').read_text())['binary']['sha256']
assert run(dict(label='archive-01-replay-correction-comparison',command=[str(binary),'--compare',str(inputs)],seconds=900))==0
rows=[json.loads(line) for line in (OUT/'archive-01-replay-correction-comparison.log').read_text().splitlines() if line.startswith('{')]
assert len(rows)==1
(OUT/'replay-correction-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Original failing archive compared with final fixture:',rows,flush=True)
