"""Source identity for the affected kernels, consumers and admission contracts."""
from pathlib import Path
import hashlib

CRATES=['hyperbrep','hyperbrep-io','hypercurve','hyperreal','hyperlimit','hypersolve','hyperlattice','hypertri']
def source_identity(root):
    root=Path(root)
    paths=[root/p for p in ['Cargo.toml','Cargo.lock','AGENTS.md','properties.md','docs/admission.md']]
    for name in CRATES:
        crate=root/'crates'/name
        paths.extend([crate/'Cargo.toml',crate/'README.md',crate/'AGENTS.md'])
        for folder in ['src','tests','benches','examples']:
            paths.extend((crate/folder).rglob('*.rs'))
        paths.extend((crate/'tests/fixtures').glob('*'))
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p.is_file()}
