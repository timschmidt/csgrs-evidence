"""Build complete preserved and new source-path consumers with exact source roots."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
from run import OUT,ROOT,ENV,run
from source_identity import source_identity

projects=json.loads((OUT/'consumer-projects.json').read_text())['projects']
parser=argparse.ArgumentParser()
parser.add_argument('side',choices=['baseline','candidate'])
parser.add_argument('--resume',action='store_true')
parser.add_argument('--epoch',default='01')
args=parser.parse_args()
side=args.side
source_root=Path('/mnt/development/csgrs') if side=='baseline' else ROOT
source=source_identity(source_root)
source_path=OUT/f'{side}-consumer-source.json'
if source_path.exists():
    assert args.resume
    assert json.loads(source_path.read_text())==source,'source changed before resume'
else:
    source_path.write_text(json.dumps(source,indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record_path=OUT/f'{side}-consumers.json'
assert args.resume or not record_path.exists()
records=json.loads(record_path.read_text()) if record_path.exists() else []
for completed in records:
    project=Path(completed['project'])
    assert completed['inputs']=={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
    for kind in ['native','wasm']:
        if kind in completed: assert sha(completed[kind]['path'])==completed[kind]['sha256']
done={r['cohort'] for r in records}
folder=OUT/'binaries';folder.mkdir(exist_ok=True)

def checked(label,args,**kwargs):
    result=run(dict(label=label,command=args,**kwargs))
    assert result==0,label
    assert source_identity(source_root)==source, "consumer source changed during check"

def freeze(p,label):
    dest=folder/label
    assert not dest.exists()
    shutil.copy2(p,dest)
    return dict(path=str(dest),bytes=dest.stat().st_size,sha256=sha(dest))

for item in projects:
    if item['side']!=side or item['cohort'] in done:continue
    name=item['cohort'];project=Path(item['project']);manifest=str(project/'Cargo.toml')
    tag=f'consumer-{args.epoch}-{side}-{name}'
    if not (project/'Cargo.lock').exists():
        checked(tag+'-lock',['cargo','generate-lockfile','--offline','--manifest-path',manifest])
    row=dict(**item,inputs={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()})
    if not item['wasm_only']:
        if side=='candidate':
            checked(tag+'-clippy',['cargo','clippy','--offline','--locked','--all-targets','--manifest-path',manifest,'--','-D','warnings'])
        checked(tag+'-build',['cargo','build','--offline','--locked','--release','--manifest-path',manifest])
        row['native']=freeze(Path(ENV['CARGO_TARGET_DIR'])/'release'/item['binary'],side+'-'+name)
        if not item.get('artifact_only',False):
            checked(tag+'-runtime',[row['native']['path'],'all'],seconds=900)
        if name in ['procedural','contacts','images']:
            checked(tag+'-step',[row['native']['path'],'step'],seconds=900)
    if side=='candidate' and item['has_wasm']:
        checked(tag+'-wasm-build',['cargo','build','--offline','--locked','--release','--lib','--target','wasm32-unknown-unknown','--manifest-path',manifest],env={'RUSTFLAGS':'-D warnings'})
        row['wasm']=freeze(Path(ENV['CARGO_TARGET_DIR'])/'wasm32-unknown-unknown/release'/(item['module']+'.wasm'),side+'-'+name+'.wasm')
        checked(tag+'-wasm-runtime',['python3','-B',str(OUT/'wasm_consumer.py'),row['wasm']['path'],str(item['groups'])],seconds=1800)
    records.append(row)
    record_path.write_text(json.dumps(records,indent=2)+'\n')
print('Completed',side,'consumer projects:',len(records),flush=True)
