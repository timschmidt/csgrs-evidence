"""Run actual no-import WebAssembly acceptance bodies in Wasmtime."""
from pathlib import Path
import hashlib,json,sys,time
sys.path.insert(0,'/tmp/hyperbrep-wasmtime')
import wasmtime
p=Path(sys.argv[1]);expected=int(sys.argv[2]);engine=wasmtime.Engine()
module=wasmtime.Module.from_file(engine,str(p))
assert len(module.imports)==0
store=wasmtime.Store(engine)
instance=wasmtime.Instance(store,module,[])
start=time.perf_counter();groups=instance.exports(store)['run_probe'](store)
assert groups==expected,(groups,expected)
print(json.dumps(dict(groups=groups,imports=0,elapsed_seconds=time.perf_counter()-start,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),scope='Source-path standalone WASM execution; not installed packages or published JavaScript bindings.')))
