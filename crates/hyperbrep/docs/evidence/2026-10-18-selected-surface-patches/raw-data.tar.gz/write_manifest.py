"""Bind final source, checks and compact lossless evidence; exclude self hash."""
from pathlib import Path
import hashlib,json
from run import OUT,ROOT
NAME='2026-10-18-selected-surface-patches'
p=ROOT/'crates/hyperbrep/docs/evidence'/NAME
assert p.exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
q=json.loads((p/'qualification-summary.json').read_text())
files=[f for f in p.rglob('*') if f.is_file() and f.name!='manifest.json']
data=dict(id='selected-surface-patches-2026-10-18',status='finite-feature-qualification-with-explicit-costs-and-open-gates',
 base_revision=q['base_revision'],upstream_revision=q['upstream_revision'],
 implementation=['crates/hyperbrep/src/construction.rs','crates/hyperbrep/src/construction/patches.rs','crates/hyperbrep/src/persistence.rs'],
 tests=['crates/hyperbrep/tests/selected_surface_patches.rs','crates/hyperbrep/tests/support/selected_surface_patches.rs'],
 qualification=q['qualification'],costs=q['costs'],limits=q['limits'],
 source_reconstruction='Recreate the base revision, apply qualified-source.patch, and verify candidate-source.json. Final documentation-only changes are recorded separately. Retained consumer projects/locks and original inputs are in the lossless raw bundle; remap recorded source roots for a different checkout.',
 files={str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(files)},
 complete_work_packages=[],full_development_goal_complete=False,
 publication='eaa0cae54 was already pushed using its one-time exception. This increment does not authorize another push or waive any required check.')
(p/'manifest.json').write_text(json.dumps(data,indent=2)+'\n')
print('Wrote manifest for',len(files),'evidence files.',flush=True)
