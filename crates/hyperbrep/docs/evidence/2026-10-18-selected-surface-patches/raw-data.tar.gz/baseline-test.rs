use hyperbrep::*;
use hypercurve::{
    BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval,
    BezierParameterPolynomial, BezierParameterRange2, Curve2, CurvePath2, QuadraticBezier2,
};

#[allow(dead_code)]
#[path = "support/selected_procedural_profiles.rs"]
mod original;

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn selected_profile() -> Curve3 {
    let root = BezierAlgebraicParameter2::try_isolate(
        BezierParameterPolynomial::try_new_power_basis(vec![
            (-1).into(), 0.into(), 0.into(), 2.into(),
        ])
        .unwrap(),
        BezierParameterInterval::try_new(q(3, 4), q(7, 8)).unwrap(),
    )
    .unwrap();
    let curve = Curve2::try_analytic_parallel(
        QuadraticBezier2::new(
            hypercurve::Point2::from_values(0, 0),
            hypercurve::Point2::from_values(2, 2),
            hypercurve::Point2::from_values(4, 0),
        )
        .parallel_left(Real::one())
        .unwrap(),
        BezierParameterRange2::try_new(
            BezierParameter2::Exact(q(1, 4)),
            BezierParameter2::Algebraic(root),
        )
        .unwrap(),
    )
    .unwrap();
    Curve3::planar_image(curve, Point3::origin(), Vector3::x(), Vector3::y()).unwrap()
}

#[test]
fn selected_extrusion_patch_builds_and_replays() {
    let profile = selected_profile();
    assert!(profile.domain().end().try_real().is_none());
    let sheet = builder::extrusion_patch(profile, Vector3::z(), (-1).into(), 2.into())
        .expect("retained profile endpoints must construct a complete exact extrusion patch");
    let json = sheet.model().to_json().unwrap();
    let cold = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(cold.to_json().unwrap(), json);
    assert_eq!(cold.faces().len(), 1);
    assert_eq!(cold.edges().len(), 4);
}

#[test]
fn selected_planar_face_builds_and_replays() {
    let region = original::clipped_parallel_cap();
    assert_eq!(region.boundary_loops().len(), 1);
    let path = CurvePath2::try_new(region.boundary_loops()[0].curves().to_vec()).unwrap();
    let sheet = builder::planar_face(
        &path,
        &[],
        Point3::origin(),
        Vector3::x(),
        Vector3::y(),
    )
    .expect("the complete selected profile must also construct a standalone planar face");
    let json = sheet.model().to_json().unwrap();
    let cold = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(cold.to_json().unwrap(), json);
    assert_eq!(cold.faces().len(), 1);
}
