"""Run final checks, package the qualification record, and verify its manifest."""
from pathlib import Path
import hashlib,json,subprocess,sys,time
from run import OUT,ROOT,ENV
NAME='2026-10-18-selected-surface-patches'
DEST=ROOT/'crates/hyperbrep/docs/evidence'/NAME
assert (OUT/'documentation-stage.json').exists()
assert len(json.loads((OUT/'consumer-costs.json').read_text())['trials'])==57
folder=DEST/'final-checks';folder.mkdir(exist_ok=False)
rows=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check(label,command):
    path=folder/(label+'.log');assert not path.exists()
    print('Running final check',label,flush=True);start=time.monotonic()
    with path.open('w') as log:
        result=subprocess.run(command,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    row=dict(label=label,command=command,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,log=str(path.relative_to(DEST)),log_sha256=sha(path))
    rows.append(row)
    (DEST/'final-checks.json').write_text(json.dumps(dict(checks=rows,scope='Checks after documentation finalization. Runtime code and test hashes are compared to qualified inputs; full repository pre-push qualification remains open.'),indent=2)+'\n')
    print('Finished',label,'exit',result.returncode,'seconds',round(row['elapsed_seconds'],2),flush=True)
    if result.returncode:print(path.read_text()[-5000:],flush=True)
    assert result.returncode==0,label
check('format',['cargo','fmt','--all','--','--check'])
check('diff',['git','diff','--check'])
check('raw-evidence-package',[sys.executable,'-B',str(OUT/'package_evidence.py')])
subprocess.run([sys.executable,'-B',str(OUT/'write_manifest.py')],check=True,cwd=ROOT,env=ENV)
check('documentation',[sys.executable,'-B',str(OUT/'check_documentation.py')])
subprocess.run([sys.executable,'-B',str(OUT/'write_manifest.py')],check=True,cwd=ROOT,env=ENV)
manifest=json.loads((DEST/'manifest.json').read_text())
actual={str(p.relative_to(DEST)) for p in DEST.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert actual==set(manifest['files'])
for name,row in manifest['files'].items():
    p=DEST/name;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],name
for p in DEST.rglob('*.json'):json.loads(p.read_text())
print('Verified final manifest:',len(actual),'files; no implementation or fixture edits after qualification.',flush=True)
