#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/docs/evidence/2026-10-18-native-boundary-images/consumer-project/acceptance.rs"]
mod acceptance;
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/docs/evidence/2026-10-18-native-boundary-images/consumer-project/images.rs"]
mod images;
#[unsafe(no_mangle)]
pub extern "C" fn run_probe() -> u32 {
    acceptance::run_all();
    images::run_all();
    14
}
