"""Execute recorded pre-push commands without hiding failures or changing source."""
import hashlib
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/mnt/development/csgrs/target/hyperbrep-development')
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ)
ENV.update(CARGO_HOME='/tmp/hyperbrep-review-cargo',
           CARGO_TARGET_DIR='/tmp/hyperbrep-review-target',
           GMP_MPFR_SYS_CACHE='/tmp/hyperbrep-upstream-tools/gmp-cache',
           CARGO_INCREMENTAL='0', CARGO_BUILD_JOBS='2',
           TMPDIR='/mnt/development/csgrs/target/hyperbrep-prepush-tmp',
           PYTHONDONTWRITEBYTECODE='1', CARGO_TERM_COLOR='never',
           RUSTUP_HOME='/tmp/hyperbrep-prepush-rustup', RUSTUP_TOOLCHAIN='prepush-stable',
           HYPERSOLVE_SKIP_BENCHMARK_REPORTS='1',
           RUST_TEST_THREADS='2',
           XDG_CACHE_HOME='/tmp/hyperbrep-prepush-20261018/cache',
           npm_config_cache='/tmp/hyperbrep-prepush-20261018/npm-cache')
ENV['PATH'] = ':'.join([
    '/tmp/hyperbrep-prepush-20261018/bin',
    '/tmp/hyperbrep-binding-tools/node-v22.23.3-linux-x64/bin',
    '/tmp/hyperbrep-binding-tools/wasm-bindgen-0.2.126-x86_64-unknown-linux-musl',
    str(ROOT/'tests/wasm/node_modules/.bin'),
    '/tmp/hyperbrep-upstream-tools/usr/bin', '/home/tim/.cargo/bin', ENV['PATH']])

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def run(job):
    label=job['label']
    path=OUT/(label+'.log')
    assert not path.exists(), path
    before=git('rev-parse','HEAD')
    clean=not git('status','--porcelain')
    patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)
    for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines():
        if name.endswith(('.rs','.toml','.json','.md','.py')):
            added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=ROOT,capture_output=True)
            assert added.returncode in (0,1), added.stderr
            patch += added.stdout
    patch_path=OUT/(label+'.source.patch')
    patch_path.write_bytes(patch)
    env=dict(ENV,**job.get('env',{}))
    command=['timeout','--signal=TERM','--kill-after=30s',str(job.get('seconds',7200))+'s',*job['command']]
    print('Running',label,flush=True)
    start=time.monotonic()
    with path.open('w') as log:
        result=subprocess.run(command,cwd=ROOT/job.get('cwd','.'),env=env,stdout=log,stderr=subprocess.STDOUT)
    row=dict(**job,source_patch=str(patch_path),source_patch_sha256=hashlib.sha256(patch).hexdigest(),log=str(path),exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,
             revision=before,revision_unchanged=git('rev-parse','HEAD')==before,
             initial_worktree_clean=clean,final_status=git('status','--porcelain'),
             log_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    ledger=OUT/'results.json'
    with (OUT/'results.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        rows=json.loads(ledger.read_text()) if ledger.exists() else []
        rows.append(row)
        temporary=ledger.with_suffix('.json.new')
        temporary.write_text(json.dumps(rows,indent=2)+'\n')
        temporary.replace(ledger)
    print('Finished',label,'exit',result.returncode,'seconds',round(row['elapsed_seconds'],1),flush=True)
    if result.returncode:
        print('\n'.join(line[:700] for line in path.read_text(errors='replace').splitlines()[-18:]),flush=True)
    assert row['revision_unchanged']
    return result.returncode

if __name__ == '__main__':
    jobs=json.loads((OUT/(sys.argv[1]+'.json')).read_text())
    for job in jobs:
        run(job)
