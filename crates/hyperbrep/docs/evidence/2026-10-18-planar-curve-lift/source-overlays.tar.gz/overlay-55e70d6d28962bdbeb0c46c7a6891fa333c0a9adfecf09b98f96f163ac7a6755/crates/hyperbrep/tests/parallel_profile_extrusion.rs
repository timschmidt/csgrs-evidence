#[path = "support/parallel_profile_extrusion.rs"]
mod acceptance;

#[test]
fn original_nonlinear_parallel_cap_extrudes_and_replays() {
    acceptance::original_nonlinear_parallel_cap_extrudes_and_replays();
}

#[test]
fn planar_images_preserve_exact_frame_and_chart() {
    acceptance::planar_images_preserve_exact_frame_and_chart();
}

#[test]
fn parallel_cap_classification_and_edge_split() {
    acceptance::parallel_cap_classification_and_edge_split();
}

#[test]
fn parallel_cap_affine_transform_and_cold_replay() {
    acceptance::parallel_cap_affine_transform_and_cold_replay();
}

#[test]
fn parallel_cap_repeated_slab_booleans() {
    acceptance::parallel_cap_repeated_slab_booleans();
}

#[test]
fn parallel_extrusion_point_queries() {
    acceptance::parallel_extrusion_point_queries();
}

