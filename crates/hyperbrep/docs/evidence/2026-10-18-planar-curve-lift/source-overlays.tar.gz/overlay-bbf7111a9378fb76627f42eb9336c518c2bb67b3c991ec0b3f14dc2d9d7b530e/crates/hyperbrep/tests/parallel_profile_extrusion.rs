use hyperbrep::{ArchiveLimits, RawModel, builder};
use hypercurve::{
    BezierParameter2, BezierParameterRange2, Curve2, CurveCertainty, CurvePath2, CurveRegion2,
    CurveRegionLoopRole, FillRule, Point2, PredicatePolicy, QuadraticBezier2, Real,
};

// Original full parallel-cap diagnostic, including its quadratic straight
// closing segments. A native-line simplification is not this acceptance input.
fn original_parallel_cap() -> CurveRegion2 {
    let parallel = QuadraticBezier2::new(
        Point2::from_values(0, 0),
        Point2::from_values(2, 2),
        Point2::from_values(4, 0),
    )
    .parallel_left(Real::one())
    .unwrap();
    let left = parallel.point_at(&Real::zero()).unwrap();
    let right = parallel.point_at(&Real::one()).unwrap();
    let analytic = Curve2::try_analytic_parallel(
        parallel,
        BezierParameterRange2::try_new(
            BezierParameter2::Exact(Real::one()),
            BezierParameter2::Exact(Real::zero()),
        )
        .unwrap(),
    )
    .unwrap();
    let lower_left = Point2::new(left.x().clone(), (-2).into());
    let lower_right = Point2::new(right.x().clone(), (-2).into());
    let quadratic_line = |a: Point2, b: Point2| {
        let midpoint = a.lerp(&b, (Real::one() / Real::from(2)).unwrap());
        Curve2::from(QuadraticBezier2::new(a, midpoint, b))
    };
    let path = CurvePath2::try_new(vec![
        analytic,
        quadratic_line(left, lower_left.clone()),
        quadratic_line(lower_left, lower_right.clone()),
        quadratic_line(lower_right, right),
    ])
    .unwrap();
    CurveRegion2::try_from_boundary_paths_with_loop_semantics(
        &[path],
        &[CurveRegionLoopRole::Material],
        &[FillRule::NonZero],
    )
    .unwrap()
}

#[test]
fn original_nonlinear_parallel_cap_extrudes_and_replays() {
    let region = original_parallel_cap();
    let outcome = hypercurve::evaluate_under(PredicatePolicy::STRICT, || {
        builder::extrude_curve_region(&region, Real::zero(), Real::from(3))
    });
    assert_eq!(outcome.certainty(), CurveCertainty::Certified);
    let bodies = outcome.into_unverified().unwrap();
    assert_eq!(bodies.len(), 1);
    for wire in bodies.model().wires().take(2) {
        let curves = wire.edge_uses().map(|usage| usage.pcurve().geometry().curve().clone()).collect();
        let path = CurvePath2::try_new(curves).unwrap();
        eprintln!("cap orientation: {:?}", path.simple_loop_orientation());
        let curves = path.curves();
        let contact = curves[0].intersect_curve(&curves[1]).unwrap();
        eprintln!("first cap join: contacts={} complete={} expected={:?} actual={:?}",
            contact.contacts().len(), contact.is_complete(), curves[0].parameter_endpoints().1,
            contact.contacts().first().map(|c| c.first().parameter()));
    }
    let json = bodies.model().to_json().unwrap();
    #[cfg(not(target_arch = "wasm32"))]
    if let Some(directory) = std::env::var_os("HYPERBREP_PLANAR_LIFT_ARTIFACT_DIR") {
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(std::path::PathBuf::from(directory).join("original-cap.json"), &json).unwrap();
    }
    let rebuilt = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(rebuilt.to_json().unwrap(), json);
}
