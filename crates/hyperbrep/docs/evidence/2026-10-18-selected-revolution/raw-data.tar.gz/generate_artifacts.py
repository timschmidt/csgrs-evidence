"""Materialize complete fixtures twice in separate processes on both revisions."""
from pathlib import Path
import hashlib,json,sys
from run import OUT,run

requested=sys.argv[1:] or ['baseline','candidate']
assert requested and all(s in ['baseline','candidate'] for s in requested) and len(set(requested))==len(requested)
records={side:{r['cohort']:r for r in json.loads((OUT/f'{side}-consumers.json').read_text())} for side in requested}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
configs=[
 ('selected',None,'artifacts'),
 ('measurement','HYPERBREP_MEASUREMENT_EXPORT_DIR','all'),
 ('images',None,'artifacts'),
 ('parallel','HYPERBREP_PARALLEL_ARCHIVE_DIR','all'),
 ('planar','HYPERBREP_PLANAR_LIFT_ARTIFACT_DIR','all'),
 ('selected_planar','HYPERBREP_SELECTED_PLANAR_ARTIFACT_DIR','all'),
 ('contacts','HYPERBREP_PLANE_CONTACT_ARTIFACT_DIR','all'),
 ('procedural','HYPERBREP_SELECTED_PROCEDURAL_ARTIFACT_DIR','all'),
 ('spline_artifacts',None,None),
 ('original_native',None,None),
 ('patches','HYPERBREP_SELECTED_PATCH_ARTIFACT_DIR','all'),
 ('revolution','HYPERBREP_SELECTED_REVOLUTION_ARTIFACT_DIR','all'),
]
ledger=OUT/'artifact-generation.json'
rows=json.loads(ledger.read_text()) if ledger.exists() else []
assert not any(r['side'] in requested for r in rows), 'requested side already has recorded artifacts'
pairs=[]
for name,envkey,mode in configs:
 for side in requested:
  if name=='revolution' and side=='baseline':continue
  record=records[side][name];binary=record['native']
  assert sha(Path(binary['path']))==binary['sha256']
  for repeat in range(2):
   dest=OUT/'artifacts'/side/name/str(repeat)
   assert not dest.exists();dest.mkdir(parents=True)
   env={envkey:str(dest)} if envkey else {}
   if name=='original_native':
    commands=[[binary['path'],str(dest),str(kind),str(reflected).lower()] for kind in range(4) for reflected in [False,True]]
   elif mode is None:commands=[[binary['path'],str(dest)]]
   elif envkey:commands=[[binary['path'],mode]]
   else:commands=[[binary['path'],mode,str(dest)]]
   for i,command in enumerate(commands):
    label=f'artifact-01-{side}-{name}-{repeat}-{i}'
    assert run(dict(label=label,command=command,env=env,seconds=1200))==0,label
   files=sorted(p for p in dest.rglob('*') if p.is_file())
   assert files,name
   for p in files:
    relative=p.relative_to(dest)
    rows.append(dict(cohort=name,side=side,repeat=repeat,name=str(relative),path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
    if repeat:
     first=dest.parent/'0'/relative
     assert first.read_bytes()==p.read_bytes(),(name,relative)
   (OUT/'artifact-generation.json').write_text(json.dumps(rows,indent=2)+'\n')
 for row in [r for r in rows if r['cohort']==name and r['side']=='candidate' and r['repeat']==0]:
  if name!='revolution':
   before=next(r for r in rows if r['cohort']==name and r['side']=='baseline' and r['repeat']==0 and r['name']==row['name'])
   pairs.append(dict(name=name+'/'+row['name'],baseline=before['path'],candidate=row['path']))
(OUT/'generated-artifact-pairs.json').write_text(json.dumps(pairs,indent=2)+'\n')
print('Generated artifact rows:',len(rows),'paired artifacts:',len(pairs),'selected sides:',requested,flush=True)
