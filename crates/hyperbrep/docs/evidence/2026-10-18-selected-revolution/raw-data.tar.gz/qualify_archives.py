"""Admit historical inputs and compare complete fresh artifacts on frozen sources."""
from pathlib import Path
import collections
import hashlib
import json
import shutil
import sys

from run import OUT, ROOT, ENV, run
from source_identity import source_identity

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source = json.loads((OUT / 'candidate-frozen-source.json').read_text())
assert source_identity(ROOT) == source
project = OUT / 'archive-project'
manifest = str(project / 'Cargo.toml')
record_path = OUT / 'archive-consumer.json'

def checked(label, command, **kwargs):
    assert run(dict(label=label, command=command, **kwargs)) == 0, label
    assert source_identity(ROOT) == source

if not record_path.exists():
    checked('archive-clippy', ['cargo', 'clippy', '--offline', '--locked', '--all-targets',
        '--manifest-path', manifest, '--', '-D', 'warnings'])
    checked('archive-build', ['cargo', 'build', '--offline', '--locked', '--release', '--manifest-path', manifest])
    binary = OUT / 'binaries/candidate-archive-replay'
    assert not binary.exists()
    shutil.copy2(Path(ENV['CARGO_TARGET_DIR']) / 'release/hyperbrep-revolution-archive-consumer', binary)
    record = dict(binary=dict(path=str(binary), bytes=binary.stat().st_size, sha256=sha(binary)),
        source=source, inputs={str(p.relative_to(project)): sha(p) for p in project.rglob('*') if p.is_file()})
    record_path.write_text(json.dumps(record, indent=2) + '\n')
else:
    record = json.loads(record_path.read_text())
    assert record['source'] == source
    binary = Path(record['binary']['path'])
    assert sha(binary) == record['binary']['sha256']
    assert record['inputs'] == {str(p.relative_to(project)): sha(p) for p in project.rglob('*') if p.is_file()}

mode = sys.argv[1]
if mode == 'prior':
    inputs = json.loads((OUT / 'prior-artifact-inputs.json').read_text())
    for item in inputs:
        assert sha(item['path']) == item['sha256']
    destination = OUT / 'prior-reencoded'
    assert not destination.exists()
    checked('archive-prior-replay', [str(binary), str(OUT / 'prior-artifact-inputs.json'), str(destination)], seconds=1200)
    rows = [json.loads(line) for line in (OUT / 'archive-prior-replay.log').read_text().splitlines() if line.startswith('{')]
    assert len(rows) == len(inputs)
    native = [item for item in inputs if Path(item['path']).suffix == '.json']
    byte_equal = [item['name'] for item in native if Path(item['path']).read_bytes() == (destination / item['name']).read_bytes()]
    assert len(byte_equal) == len(native), 'Historical native bytes changed; inspect rather than accepting migration silently.'
    assert not any(row['changed_scalar_encodings'] for row in rows)
    summary = dict(files=len(rows), unique_input_contents=len({r['sha256'] for r in inputs}),
        outcomes=dict(collections.Counter(row['outcome'] for row in rows)),
        byte_identical_native_archives=len(byte_equal), imported_step_bodies=sum(r['imported_step_bodies'] for r in rows))
    (OUT / 'prior-artifact-replay.json').write_text(json.dumps(rows, indent=2) + '\n')
    (OUT / 'prior-replay-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
elif mode == 'generated':
    pairs = json.loads((OUT / 'generated-artifact-pairs.json').read_text())
    checked('archive-generated-comparison', [str(binary), '--compare', str(OUT / 'generated-artifact-pairs.json')], seconds=1200)
    rows = [json.loads(line) for line in (OUT / 'archive-generated-comparison.log').read_text().splitlines() if line.startswith('{')]
    assert len(rows) == len(pairs)
    assert all(row['byte_identical'] and not row['changed_scalar_encodings'] for row in rows), 'Fresh artifact encoding changed; review required.'
    (OUT / 'generated-artifact-comparison.json').write_text(json.dumps(rows, indent=2) + '\n')
    summary = dict(pairs=len(rows), byte_identical_pairs=len(rows))
else:
    raise AssertionError(mode)
print(json.dumps(summary, indent=2), flush=True)
