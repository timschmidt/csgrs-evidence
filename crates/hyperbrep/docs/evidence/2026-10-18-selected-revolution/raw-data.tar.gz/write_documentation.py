"""Publish completed finite evidence without altering qualified code or fixtures."""
from pathlib import Path
import gzip, hashlib, json, shutil, subprocess
from run import OUT, ROOT
from source_identity import source_identity
from update_ledger import update_block

NAME = '2026-10-18-selected-revolution'
ID = 'selected-revolution-2026-10-18'
DEST = ROOT / 'crates/hyperbrep/docs/evidence' / NAME
read = lambda name: json.loads((OUT / name).read_text())
q, c = read('qualification-summary.json'), read('cost-summary.json')
assert source_identity(ROOT) == read('candidate-frozen-source.json') == read('candidate-consumer-source.json')
assert not DEST.exists()
DEST.mkdir()
prior = q['prior_artifacts']
qualification = (
    f"Eight shared public groups and one internal face-admission regression extend the retained corpus. "
    f"BRep/IO release suites pass {q['tests']['tests-all-features']['passed']} all-feature and "
    f"{q['tests']['tests-minimal-features']['passed']} minimal-feature tests. Affected all-target strict Clippy, "
    f"warning-denied rustdoc, fuzz-target compilation and formatting pass. Source-path native consumers execute "
    f"{q['native_consumer_groups']} groups plus eight original exchange workflows; actual zero-import WASM executes "
    f"{q['wasm_consumer_groups']} groups, including all nine original exports. "
    f"All {prior['byte_identical_native_archives']} prior native archives re-encode byte-identically; "
    f"{prior['outcomes']['step_import_and_native_replay']} STEP inputs import {prior['imported_step_bodies']} bodies and replay. "
    f"The {prior['files']}-file inventory has {prior['unique_input_contents']} distinct contents; text controls are inventory-only. "
    f"All {q['fresh_byte_identical_pairs']} fresh baseline/candidate pairs remain byte-identical, with no coefficient encoding migration. "
    f"Every export recipe repeats deterministically; {q['new_archives']['files']} new rotation/revolution archive files "
    f"({q['new_archives']['unique_contents']} distinct encodings) also replay stably. "
    f"The initial copied-consumer root error is retained and corrected; its mis-scoped baseline result is excluded."
)
costs = (
    f"Three alternating pairs cover {c['matched_rows']} preserved semantic rows; eight new groups have three absolute trials. "
    f"All {c['process_trials']} processes pass their assertions. Observed time ratios range "
    f"{c['minimum_time_ratio']:.6f} to {c['maximum_time_ratio']:.6f}; {len(c['slower_than_10_percent'])} exceed the 10% review marker "
    f"and {len(c['allocation_increases'])} increase allocation calls or requested bytes. All adverse observations are retained. "
    "Shared-host instrumented samples and process RSS establish neither a general speedup nor internal work/heap bounds."
)
limits = (
    "Finite retained circular orbits and selected open revolution sheets, with complete boundary-image and profile-axis-clearance proofs. "
    "No general rank-two surface regularity, embedding, solid closure or new STEP claim. Independent selected angular/axial parameters, "
    "retained vector derivatives, general affine orbit transport and inverse/intersection families remain typed frontiers. "
    "Schema 10 gains an additive Rotation record; existing corpus bytes are preserved, with no compatibility reader. "
    "Total work, retained heap, coefficient growth, cancellation, runtime fuzz/ASan/lexicase, formal coverage, MSRV, installed distributions "
    "and production binding gates remain open. All 28 work packages remain open/in-progress. Full pre-push qualification remains required; "
    "the consumed eaa0 one-time exception does not authorize publishing this increment."
)
properties = read('contract-before-edit.json')['properties']
metadata = dict(id=ID, status='finite-feature-qualification-with-explicit-costs-and-open-gates',
    base_revision=q['base_revision'], upstream_revision=q['upstream_revision'],
    qualification=qualification, costs=costs, limits=limits, properties=properties,
    complete_work_packages=[], full_development_goal_complete=False)
(OUT / 'documentation-stage.json').write_text(json.dumps(metadata, indent=2) + '\n')
for name in ['contract.md', 'independent-oracles.md', 'next-domains.md']:
    shutil.copy2(OUT / 'drafts' / name, DEST / name)
for name in ['construction-proof.md','attempt-review.md','contract-before-edit.json','qualification-summary.json',
    'consumer-costs.json','cost-summary.json','costs.md','artifact-size-summary.json','prior-artifact-summary.json',
    'prior-replay-summary.json','baseline-consumers.json','candidate-consumers.json','machine.json',
    'upstream-checkpoint.json','original-wasm-exports.json','consumer-path-correction.json','consumer-root-audit.json',
    'adverse-cost-review.md','adverse-cost-samples.json','measurement-start.json','measurement-end.json']:
    shutil.copy2(OUT / name, DEST / name)
for source, dest in [('baseline-consumer-source.json','baseline-source.json'),('candidate-consumer-source.json','candidate-source.json')]:
    shutil.copy2(OUT / source, DEST / dest)
patch = Path(q['source_patch']).read_bytes()
assert hashlib.sha256(patch).hexdigest() == q['qualified_source_sha256']
(DEST / 'qualified-source.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
shutil.copytree(OUT / 'consumers/candidate/revolution', DEST / 'consumer-project')
shutil.copytree(OUT / 'archive-project', DEST / 'archive-project')
(DEST / 'README.md').write_text(f'''# Selected revolution patches and retained circular orbits

`Curve3::rotation` retains an exact spatial point's source and parameter while
rotating it about an authored unit axis. `builder::revolution_patch` now consumes
selected meridian endpoints through retained latitude orbits and native rotated
meridians. Reversal, reflection, selected meridian splits, authored latitude
splits and cold persistence consume the result. Full-period standalone orbits
also admit one shared endpoint and continue through subdivision.

The baseline is `{q['base_revision']}`. Upstream `{q['upstream_revision']}` was
fetched again and is already integrated. All production edits are in HyperBRep;
planar contact, root and point-field authority stay in Hypercurve/Hypersolve.

The [contract](contract.md), [construction argument](construction-proof.md),
[independent exact oracles](independent-oracles.md) and [attempt record](attempt-review.md)
describe the input domain, mathematical obligations and reproduced failures.
Ordinary face admission repeats complete profile-axis clearance, so cold loading
cannot rely on the convenience constructor. Boundary-image agreement alone did
not reject an interior axis crossing; the preserved regression now does.

## Qualification

{qualification}

All added geometry tests run under exact policies. Independent midpoint,
oblique-axis, reflected-coordinate, derivative and 1/10^12-gap expectations
complement topology and replay checks. These finite cases do not prove all
inputs or general surface embedding. Compilation of fuzz targets is not a
runtime fuzz campaign. Source-path projects and WASM probes are not installed
distributions or shipped bindings.

## Persistence and costs

Schema 10 gains an additive `Rotation` record whose origin is authored
coordinates or a retained curve image. It stores the axis, angular domain and
signed affine angular chart. No image or clearance certificate is trusted from
the archive. Metadata counts the origin and nested sources before scalar
decoding. Existing encodings retain their recipes; no migration or compatibility
reader is introduced for this increment.

{costs}

[Every cost row](costs.md), [raw trials](consumer-costs.json) and
[artifact sizes](artifact-size-summary.json) are retained. The cost campaign uses
one warmup and three measured repetitions per full case, fixed source and binary
hashes, and no overlapping task builds/tests. The previous increment's adverse
expression-size and timing observations remain historical evidence; preserving
its output bytes here does not remove those costs.
The [adverse-cost review](adverse-cost-review.md) preserves the five slower contact
rows and their sample ranges. Overlapping ranges do not prove no regression;
their cause remains unestablished and no extra samples replace this campaign.

## Reproduction and open work

The [raw bundle](raw-data.tar.gz) and its [inventory](raw-data-index.json) retain
successful and failed logs, exact source patches, recipes, locks, original inputs
and generated outputs. Frozen binaries are recorded by hash/size but excluded
from the bundle. Recreate the baseline, decompress and apply
[qualified-source.patch.gz](qualified-source.patch.gz), then verify
[candidate-source.json](candidate-source.json). Final documentation changes are
recorded separately. Remap the recorded baseline/candidate path prefixes when
recreating external consumer projects; [source-root audit](consumer-root-audit.json)
records their corrected paths. Use fresh output directories for the drivers.

{limits}

[Next domains](next-domains.md), [commands](validation.json),
[final checks](final-checks.json) and the [manifest](manifest.json) retain the
remaining work and bind claims to executed evidence.
''')

def replace(path, old, new):
    p = ROOT / path
    text = p.read_text()
    assert text.count(old) == 1, (path, old)
    p.write_text(text.replace(old, new))

replace('crates/hyperbrep/README.md',
    '  revolutions use periodic subdivision;\n',
    '  revolutions use periodic subdivision. Selected meridian endpoints retain\n'
    '  latitude origins through `Curve3::rotation`; exact angular charts, similarity\n'
    '  and reflection, edge subdivision and cold replay consume the result. Complete\n'
    '  boundary images and axis clearance do not establish global embedding; see the\n'
    f'  [selected-revolution evidence](docs/evidence/{NAME}/README.md);\n')
replace('crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    '| Finite line | Exact, arbitrary positive derivative order | Exact | Certified | Exact | Exact |',
    '| Rotation of retained point | Authored angle retains source; positive-order derivatives require stored origin coordinates | Conservative full-orbit enclosure | Unsupported | Exact reversal and authored-angle split | Exact origin, axis and angular chart |\n'
    '| Finite line | Exact, arbitrary positive derivative order | Exact | Certified | Exact | Exact |')
replace('crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    'forms through Hypercurve. Scalar parameters expose stored coordinates;\nselected conic angular evaluation returns `UnsupportedSelectedEvaluation`.',
    'forms through Hypercurve. Scalar parameters expose stored coordinates for\nauthored carriers; retained translation/rotation origins can keep selected\nsource images even at scalar parameters. Independently selected conic/rotation\nangular evaluation returns `UnsupportedSelectedEvaluation`.')
replace('crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    'Circle and ellipse edges may retain one vertex at both endpoints when their\nexact interval spans one full period.',
    'Circle, ellipse and nondegenerate retained rotation edges may retain one\nvertex at both endpoints when their exact interval spans one full period.')
replace('crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    'Standalone closed ellipse edges subdivide and replay; this does not add\nellipse/plane pcurve-image admission.',
    'Standalone closed ellipse and retained rotation edges subdivide and replay;\nthis does not add ellipse/plane pcurve-image admission.')
replace('crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    '| Revolution | Periodic × profile domain | Conservative exact | Line/circle/ellipse/rational Bézier/NURBS meridians and latitude circles | Certified similarity / reflection | Exact |',
    '| Revolution | Periodic × profile domain | Conservative exact | Native meridians/latitudes; coordinate charts also retain selected planar-image meridians and rotation origins with complete axis clearance | Certified similarity / reflection | Exact |')
anchor='| `revolution_patch` | One sub-period, completely axis-clear rectangular revolution face / open shell |'
p=ROOT/'crates/hyperbrep/docs/SUPPORT_MATRIX.md';text=p.read_text();assert anchor in text
row=next(line for line in text.splitlines() if line.startswith(anchor))
text=text.replace(row,row.replace('completely axis-clear rectangular revolution face / open shell','completely axis-clear rectangular revolution face / open shell, including supported selected meridian endpoints'))
text=text.replace('\n## Surface carriers\n',f'''\nRetained rotations preserve their point source, unit axis and signed angular chart.
Similarities and reflections transport that chart; general affine transforms,
independent selected angular parameters, retained-vector derivatives and general
inverse/intersection queries remain typed frontiers. Selected revolution patches
prove complete boundary images and axis clearance, not global embedding or solid
interior. See the [finite qualification](evidence/{NAME}/README.md).

## Surface carriers
''');p.write_text(text)
replace('crates/hyperbrep/docs/SELECTED_ARCHIVE.md','translation origins, affine-form point definitions',
    'translation/rotation origins, affine-form point definitions')
replace('crates/hyperbrep/docs/SELECTED_ARCHIVE.md',
    'Coordinate pcurve correspondence records retain a chosen U or V coordinate and',
    f'''`Rotation` curves add an origin (`Coordinates` or `CurveImage`), authored axis
origin/unit direction, angular domain, direction sign and offset to schema 10.
Selected source and parameter identities use the existing graph. Cold admission
reconstructs the nonzero-radius proof, complete boundary images and profile-axis
clearance; no serialized certificate flag is trusted. Each origin and nested
source is charged before scalar decoding. The [revolution qualification](evidence/{NAME}/README.md)
retains all prior corpus bytes and repeated new archives. No old record is
reinterpreted and no compatibility reader is introduced.

Coordinate pcurve correspondence records retain a chosen U or V coordinate and''')
replace('crates/hyperbrep/docs/SELECTED_ARCHIVE.md',
    'coordinate and complete profile or axial translation image. These records carry',
    'coordinate and complete profile or axial translation image. Revolution\nadmission proves complete retained latitude or rotated-meridian images and\nrechecks the profile over its whole interval for axis contact. These records carry')
replace('crates/hyperbrep/docs/DEVELOPMENT_PLAN.md',
    'The [selected surface-patch increment]',
    f'''The [selected revolution increment](evidence/{NAME}/README.md)
advances WP02/WP03/WP09/WP13 with retained circular orbits, selected meridian
endpoints and ordinary complete image/axis-clearance admission. Reflected
similarities, selected meridian splits, latitude splits, full-period standalone
edges and cold persistence consume the result. Schema 10 gains an additive
Rotation record; the retained prior corpus and fresh paired exports keep their
bytes. General surface regularity/embedding, selected angular fields, solid CAD
closure and release/resource gates remain open. All 28 work packages remain
incomplete; the finite evidence does not change their broader acceptance gates.

The [selected surface-patch increment]''')
replace('crates/hyperbrep/docs/DEVELOPMENT_PLAN.md',
    'audited. General embedding, revolution latitude generators and CAD closure\nremain open;',
    'audited. The revolution increment above extends selected latitude generators;\ngeneral embedding and CAD closure remain open;')
replace('crates/hyperbrep/docs/ARCHITECTURE.md',
    '`ModelBuilder::edge` may reference the same vertex twice for a circle or ellipse\nwhose exact parameter interval spans one `tau` period. Positive radii and\nindependent axes, already required by the spatial carrier, prove that this\nclosed curve is regular and simple.',
    '`ModelBuilder::edge` may reference the same vertex twice for a circle, ellipse\nor retained rotation whose exact parameter interval spans one `tau` period.\nPositive radii and independent axes prove the native conic is regular and simple.\nA retained rotation instead certifies a unit axis, a nonzero radial component\nand a signed angular chart with derivative +1 or -1.')
replace('crates/hyperbrep/docs/ARCHITECTURE.md',
    '`Curve3::point_at(&Parameter)` returns `GeometricPoint3`. Authored scalar\nparameters use the native evaluator and store `Point3` coordinates. A selected\nline, rational Bézier or finite NURBS image retains its immutable source curve\nand one shared parameter;',
    '`Curve3::point_at(&Parameter)` returns `GeometricPoint3`. Authored scalar\nparameters on authored carriers store `Point3` coordinates. Retained translation\nand rotation origins can preserve a selected source even at scalar parameters.\nA selected line, rational Bézier, finite NURBS or planar image retains its\nimmutable source curve and one shared parameter;')
replace('crates/hyperbrep/docs/ARCHITECTURE.md',
    '## Closed edges and periodic seam uses',
    f'''## Retained rotation orbits

`Curve3::rotation` stores an exact point, authored unit axis and finite angular
domain of at most one turn. Its chart is `theta = s*t+b`, with `s` equal to +1 or
-1. Authored angular evaluation applies the existing affine rotation primitives
to the retained point. Reversal and restriction preserve the source; similarities
transport the axis as an axial vector, including the orientation sign under
reflection. Bounds conservatively enclose the full orbit. Positive-order vector
derivatives require stored origin coordinates; independent selected angular
parameters and general affine orbit transport remain typed frontiers.

The [rotation implementation](../src/geometry/rotation.rs) owns these invariants.
Selected revolution patches use it for their latitude boundaries. Ordinary
face admission checks complete coordinate images and profile-axis clearance,
including during cold reconstruction. Those checks do not certify general
rank-two surface regularity, global embedding or solid interior. The
[finite evidence](evidence/{NAME}/README.md) records composition and replay.

## Closed edges and periodic seam uses''')

p=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json';status=json.loads(p.read_text())
assert all(i['id'] != ID for i in status['increments'])
status['increments'].append(dict(id=ID,work_packages=['WP02','WP03','WP09','WP13','WP21'],properties=properties,
    change='Add exact retained-point rotation curves and selected-endpoint revolution patches. Ordinary face admission proves complete boundary images and profile-axis clearance; full-period orbit edges split and replay.',
    sources=['../src/geometry/rotation.rs','../src/construction/patches.rs','../src/topology/validation/analytic_image.rs','../src/topology/validation/revolution.rs','../src/persistence.rs'],
    evidence=f'evidence/{NAME}/manifest.json',validation=qualification,cost_evidence=costs,limits=limits))
status['next_actions'][0]=f'Preserve evidence/{NAME}/manifest.json and every earlier corpus/artifact/cost record. Follow its next-domains.md for selected angular/axial fields, complete contact/arrangement/regularity/embedding proofs and further modeling/STEP continuation. Finite retained rotation support does not close general CAD, resource or delivery gates.'
status['next_actions']=[action.replace('beyond native single-vertex circle/ellipse edges:',
    'beyond native single-vertex circle/ellipse and retained-rotation edges:') for action in status['next_actions']]
for wp in status['work_packages']:
    if wp['id']=='WP09':wp['progress']='Finite selected extrusion and sub-period revolution patches, including retained latitude generators and complete axis clearance; general sweep/loft, surface regularity and embedding gates remain open.'
p.write_text(json.dumps(status,indent=2)+'\n')
p=ROOT/'docs/properties-status.json';ledger=json.loads(p.read_text());brep=ledger['current_work']['hyperbrep']
brep.update(latest_evidence=f'crates/hyperbrep/docs/evidence/{NAME}/manifest.json',latest_implementation=ID,
    latest_feature_evidence=f'crates/hyperbrep/docs/evidence/{NAME}/manifest.json',
    latest_update_check=f'crates/hyperbrep/docs/evidence/{NAME}/upstream-checkpoint.json',
    qualification=qualification+' '+costs+' '+limits)
record=update_block(p,brep)
(OUT/'ledger-update.json').write_text(json.dumps(record,indent=2)+'\n')
shutil.copy2(OUT/'ledger-update.json',DEST/'ledger-update.json')
print(json.dumps(metadata,indent=2),flush=True)
