"""Three alternating pairs of complete preserved workflows, then absolute new costs."""
from pathlib import Path
import hashlib,json,os,platform,statistics,subprocess
from run import OUT,ROOT,ENV
from source_identity import source_identity

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={side:{r['cohort']:r for r in json.loads((OUT/f'{side}-consumers.json').read_text())} for side in ['baseline','candidate']}
counts={'images':6,'spline':9,'measurement':7,'selected':11,'parallel':7,'planar':12,'selected_planar':14,'contacts':14,'procedural':12,'patches':7,'revolution':8}
cpu=min(os.sched_getaffinity(0));destination=OUT/'costs';destination.mkdir(exist_ok=False)
sampler=OUT/'measure.py';trials=[];rows=[]
inputs={str(p):sha(p) for p in [Path(__file__),sampler,OUT/'baseline-consumers.json',OUT/'candidate-consumers.json']}
# No source changes, task builds, tests or other task measurements may overlap this driver.
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)
roots={'baseline':Path('/mnt/development/csgrs'),'candidate':ROOT}
identities={side:json.loads((OUT/f'{side}-consumer-source.json').read_text()) for side in roots}
assert all(source_identity(root)==identities[side] for side,root in roots.items())
source_files={str(p):sha(p) for folder in ['src','tests','benches'] for p in (ROOT/'crates/hyperbrep'/folder).rglob('*.rs')}
for cohort,count in counts.items():
    cohort_trials=[]
    sides=['candidate'] if cohort=='revolution' else ['baseline','candidate']
    for trial in range(3):
        for side in (sides if trial%2==0 else list(reversed(sides))):
            binary=records[side][cohort]['native'];assert sha(binary['path'])==binary['sha256']
            label=f'{cohort}-{side}-{trial}';log=destination/(label+'.log');resource=destination/(label+'-resources.json')
            command=['python3','-B',str(sampler),str(resource),'taskset','-c',str(cpu),binary['path'],'measure']
            print('Measuring',label,flush=True)
            with log.open('w') as output:
                result=subprocess.run(['timeout','--signal=TERM','--kill-after=30s','1200s',*command],cwd=ROOT,env=ENV,stdout=output,stderr=subprocess.STDOUT)
            values=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
            row=dict(cohort=cohort,side=side,trial=trial,command=command,exit_code=result.returncode,
                resource=json.loads(resource.read_text()),rows=values,log=str(log),binary=binary)
            trials.append(row);cohort_trials.append(row)
            (destination/'trials.json').write_text(json.dumps(trials,indent=2)+'\n')
            assert result.returncode==row['resource']['exit_code']==0 and len(values)==count,label
            assert subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)==patch
            assert all(source_identity(root)==identities[side] for side,root in roots.items())
            assert all(sha(p)==h for p,h in inputs.items()) and all(sha(p)==h for p,h in source_files.items())
    strip=lambda rows:[{k:v for k,v in row.items() if k not in ['elapsed_ns','allocation_calls','requested_bytes']} for row in rows]
    assert all(strip(t['rows'])==strip(cohort_trials[0]['rows']) for t in cohort_trials),cohort
    for i,case in enumerate(cohort_trials[0]['rows']):
        row=dict(cohort=cohort,case=case['case'],outcome=case['outcome'],iterations=case['iterations'],matched_contract=cohort!='revolution')
        for side in sides:
            samples=[t['rows'][i] for t in cohort_trials if t['side']==side]
            row[side]={key:statistics.median(s[key]/s['iterations'] for s in samples) for key in ['elapsed_ns','allocation_calls','requested_bytes']}
        if row['matched_contract']:row['ratio']=row['candidate']['elapsed_ns']/row['baseline']['elapsed_ns']
        else:row['ratio']=None
        rows.append(row)
    (OUT/'consumer-costs.json').write_text(json.dumps(dict(cpu=cpu,platform=platform.platform(),
        rustc=subprocess.check_output(['rustc','-Vv'],env=ENV,text=True),inputs=inputs,source_files=source_files,
        trials=trials,rows=rows,scope='Three alternating CPU-pinned matched pairs per preserved cohort and three absolute new-feature processes. One warmup and three measured repetitions per case. Complete fixture bodies, exact assertions and output materialization retained. Matched means the same completed semantic workflow; prior archive bytes and all fresh encodings are audited separately. This capability increment makes no optimization claim. Expected failure controls remain labeled mixed groups. Shared host and warm OS caches. Cumulative requested bytes and process RSS do not establish retained-memory or operation-wide work bounds. No error-to-success ratio or general speedup claim.'),indent=2)+'\n')
print('Completed cost rows:',len(rows),'process trials:',len(trials),flush=True)
