"""Relocate unchanged consumer recipes to explicit baseline/candidate source roots."""
from pathlib import Path
import hashlib, json, re, shutil, tomllib

OUT=Path(__file__).resolve().parent
BASE=Path('/mnt/development/csgrs')
CANDIDATE=BASE/'target/hyperbrep-development'
E=BASE/'crates/hyperbrep/docs/evidence'
cohorts=[
 ('patches',E/'2026-10-18-selected-surface-patches/consumer-project',7),
 ('procedural',E/'2026-10-18-selected-procedural-profiles/consumer-project',12),
 ('contacts',E/'2026-10-18-retained-plane-contacts/consumer-project',14),
 ('selected_planar',E/'2026-10-18-selected-planar-images/consumer-project',14),
 ('planar',E/'2026-10-18-planar-curve-lift/consumer-project',12),
 ('parallel',E/'2026-10-18-parallel-pcurve-replay/consumer-project',7),
 ('selected',E/'2026-10-18-selected-profile-extrusion/consumer-project',11),
 ('measurement',E/'2026-10-18-measurement-admission/consumer-project',7),
 ('spline',E/'2026-10-18-spline-exchange/consumer-project',9),
 ('images',E/'2026-10-18-native-boundary-images/consumer-project',14),
]
rows=[]
def remap(path,root):
 path=Path(path).resolve()
 for source_root in [CANDIDATE, BASE]:
  try: return root/path.relative_to(source_root)
  except ValueError: pass
 return path

def copy_project(name,source,groups,side,root,wasm_only=False):
 target=OUT/'consumers'/side/name
 assert not target.exists(),target
 for p in source.rglob('*'):
  if not p.is_file() or any(k in p.relative_to(source).parts for k in ['target','__pycache__','node_modules']): continue
  if p.suffix not in ['.rs','.toml','.lock','.py','.json']: continue
  dest=target/p.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True)
  text=p.read_text()
  if p.name=='Cargo.toml':
   text=re.sub(r'path\s*=\s*"([^"]+)"',lambda m:'path = "'+str(remap(p.parent/m[1],root))+'"' if (p.parent/m[1]).is_dir() else m[0],text)
  if p.suffix=='.rs':
   text=re.sub(r'#\[path\s*=\s*"([^"]+)"\]',lambda m:'#[path = "'+str(remap(p.parent/m[1],root))+'"]',text)
   text=re.sub(r'include!\("(\.\./[^"]+)"\)',lambda m:'include!("'+str(remap(p.parent/m[1],root))+'")',text)
  text=text.replace(str(BASE)+'/crates/',str(root)+'/crates/')
  dest.write_text(text)
 manifest=tomllib.loads((target/'Cargo.toml').read_text())
 binary=manifest.get('bin',[{'name':manifest['package']['name']}])[0]['name']
 module=manifest.get('lib',{}).get('name',manifest['package']['name'].replace('-','_'))
 rows.append(dict(cohort=name,side=side,source_project=str(source),project=str(target),groups=groups,binary=binary,module=module,wasm_only=wasm_only,has_wasm='lib' in manifest))

for name,source,count in cohorts:
 for side,root in [('baseline',BASE),('candidate',CANDIDATE)]:
  copy_project(name,source,count,side,root)
copy_project('images_wasm',E/'2026-10-18-native-boundary-images/wasm-probe',14,'candidate',CANDIDATE,True)
copy_project('original_wasm',Path('/tmp/hyperbrep-axial-shell-wasm-probe'),138,'candidate',CANDIDATE,True)

p=OUT/'consumers/candidate/revolution';p.mkdir(parents=True)
(p/'Cargo.toml').write_text('''[package]
name = "hyperbrep-selected-revolution-consumer"
version = "0.0.0"
edition = "2024"
[workspace]
[[bin]]
name = "hyperbrep-selected-revolution-consumer"
path = "main.rs"
[lib]
name = "hyperbrep_selected_revolution_probe"
path = "lib.rs"
crate-type = ["cdylib"]
[dependencies]
'''+''.join(f'{name} = {{ path = "{CANDIDATE}/crates/{name}" }}\n' for name in ['hyperbrep','hypercurve','hyperlimit'])+'serde_json = "1"\n')
new_names=re.findall(r'^pub fn (\w+)\(', (CANDIDATE/'crates/hyperbrep/tests/support/selected_revolution.rs').read_text(),re.M)
(p/'cases.rs').write_text(f'#[path = "{CANDIDATE}/crates/hyperbrep/tests/support/selected_revolution.rs"]\nmod acceptance;\nfn cases() -> [(&\'static str, fn()); {len(new_names)}] {{\n[\n'+''.join(f'("{n}", acceptance::{n}),\n' for n in new_names)+']\n}\n')
text=(E/'2026-10-18-selected-procedural-profiles/consumer-project/main.rs').read_text()
text=text.replace('''    if mode == "step" {
        selected_procedural_profiles_fail_step_with_attribution_and_native_recovery();
        return;
    }
''','')
(p/'main.rs').write_text(text)
(p/'lib.rs').write_text('include!("cases.rs");\n#[unsafe(no_mangle)]\npub extern "C" fn run_probe() -> u32 {\nfor (_, case) in cases() { case(); }\n'+str(len(new_names))+'\n}\n')
rows.append(dict(cohort='revolution',side='candidate',project=str(p),groups=len(new_names),binary='hyperbrep-selected-revolution-consumer',module='hyperbrep_selected_revolution_probe',wasm_only=False,has_wasm=True))
for name,source in [('spline_artifacts',E/'2026-10-18-spline-exchange/final-review/artifact-project'),('original_native',Path('/tmp/hyperbrep-axial-shell-consumer'))]:
 for side,root in [('baseline',BASE),('candidate',CANDIDATE)]:
  copy_project(name,source,0,side,root)
  rows[-1]['artifact_only']=True

inputs={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (OUT/'consumers').rglob('*') if p.is_file()}
(OUT/'consumer-projects.json').write_text(json.dumps(dict(projects=rows,prepared_inputs=inputs),indent=2)+'\n')
print('Prepared',len(rows),'source-path consumer projects; new fixture groups:',len(new_names))
