"""Summarize only completed, source-bound qualifications and complete cost trials."""
from pathlib import Path
import collections, hashlib, json, re, statistics
from run import OUT

read = lambda name: json.loads((OUT / name).read_text())
write = lambda name, value: (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
results = read('results.json')
by_label = {r['label']: r for r in results}
assert len(by_label) == len(results)
for r in results:
    assert hashlib.sha256(Path(r['log']).read_bytes()).hexdigest() == r['log_sha256']
    assert hashlib.sha256(Path(r['source_patch']).read_bytes()).hexdigest() == r['source_patch_sha256']
checks = ['tests-all-features', 'tests-minimal-features', 'clippy-minimal-features',
    'strict-clippy-02', 'rustdoc', 'fuzz-check', 'format-check',
    'selected-revolution-final-focus', 'cold-axis-admission-fixed',
    'archive-clippy', 'archive-build', 'archive-prior-replay', 'archive-generated-comparison']
assert all(by_label[k]['exit_code'] == 0 for k in checks)
counts = {}
for label in ['tests-all-features', 'tests-minimal-features']:
    lines = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', Path(by_label[label]['log']).read_text())
    counts[label] = dict(zip(['passed', 'failed', 'ignored'], map(sum, zip(*[map(int, row) for row in lines]))))
    assert counts[label]['failed'] == counts[label]['ignored'] == 0
candidate = read('candidate-consumers.json')
baseline = read('baseline-consumers.json')
assert len(candidate) == 15 and len(baseline) == 12
native = sum(r['groups'] for r in candidate if 'native' in r)
wasm = sum(r['groups'] for r in candidate if 'wasm' in r)
assert native == 115 and wasm == 253
prior = read('prior-replay-summary.json')
pairs = read('generated-artifact-comparison.json')
assert len(pairs) == 308 and all(r['byte_identical'] and not r['changed_scalar_encodings'] for r in pairs)
artifacts = read('artifact-generation.json')
sizes = {}
for side in ['baseline', 'candidate']:
    first = [r for r in artifacts if r['side'] == side and r['repeat'] == 0]
    second = [r for r in artifacts if r['side'] == side and r['repeat'] == 1]
    assert {(r['cohort'], r['name'], r['sha256']) for r in first} == {(r['cohort'], r['name'], r['sha256']) for r in second}
    groups = {}
    for cohort in sorted({r['cohort'] for r in first}):
        rows = [r for r in first if r['cohort'] == cohort]
        groups[cohort] = dict(files=len(rows), unique_contents=len({r['sha256'] for r in rows}), bytes=sum(r['bytes'] for r in rows), largest_bytes=max(r['bytes'] for r in rows))
    sizes[side] = groups
new = sizes['candidate']['revolution']
write('artifact-size-summary.json', sizes)
cost = read('consumer-costs.json')
rows, trials = cost['rows'], cost['trials']
assert len(rows) == 107 and len(trials) == 63
assert all(t['exit_code'] == t['resource']['exit_code'] == 0 for t in trials)
matched = [r for r in rows if r['matched_contract']]
assert len(matched) == 99
resources = []
for cohort in dict.fromkeys(t['cohort'] for t in trials):
    item = dict(cohort=cohort)
    for side in ['baseline', 'candidate']:
        ts = [t for t in trials if t['cohort'] == cohort and t['side'] == side]
        if not ts: continue
        assert len(ts) == 3
        item[side] = dict(median_process_wall_seconds=statistics.median(t['resource']['wall_seconds'] for t in ts),
            maximum_process_rss_kib=max(t['resource']['maximum_rss_kib'] for t in ts),
            binary_bytes=ts[0]['binary']['bytes'])
    resources.append(item)
summary = dict(matched_rows=99, absolute_new_rows=8, process_trials=63,
    minimum_time_ratio=min(r['ratio'] for r in matched), maximum_time_ratio=max(r['ratio'] for r in matched),
    median_row_ratio=statistics.median(r['ratio'] for r in matched),
    slower_than_10_percent=[r for r in matched if r['ratio'] > 1.1],
    allocation_increases=[r for r in matched if any(r['candidate'][key] > r['baseline'][key] for key in ['allocation_calls', 'requested_bytes'])],
    process_resources=resources,
    scope=cost['scope'], optimization_claim=False)
write('cost-summary.json', summary)
text = '''# Complete workflow cost observations

This is a capability increment, not an optimization. Three alternating CPU-pinned
pairs retain all 99 preserved rows and every full fixture, assertion, certainty
receipt and output materialization. Eight new groups have three absolute trials;
an earlier unsupported result is not used as their timing baseline. Each process
uses one warmup and three measured repetitions per case. Allocation counters are
enabled. All 63 processes pass their assertions. Sources, recipes and binaries
remain fixed; no task builds, tests or other task measurements overlap the run.

The table reports median time per complete case and cumulative allocation calls
and requested bytes per repetition. Mixed groups include expected typed failure
controls. OS caches are warm on a shared host. These samples, process RSS and
cumulative requests establish neither statistical significance, retained-memory
bounds nor a general speedup. All adverse observations remain visible. Full raw
trials and executable/source hashes are in `consumer-costs.json` and the raw bundle.

'''
text += f"Observed time ratios span {summary['minimum_time_ratio']:.6f}–{summary['maximum_time_ratio']:.6f}; {len(summary['slower_than_10_percent'])} rows exceed the 10% review marker. {len(summary['allocation_increases'])} rows increase allocation calls or requested bytes. The marker is a review aid, not a statistical or release gate.\n\n"
text += '| Cohort / case | Outcome | Before ms | After ms | Ratio | Before / after calls | Before / after requested bytes |\n| --- | --- | ---: | ---: | ---: | ---: | ---: |\n'
for r in rows:
    b, c = r.get('baseline'), r['candidate']
    before = f"{b['elapsed_ns']/1e6:.6f}" if b else 'new'
    ratio = f"{r['ratio']:.6f}" if b else 'absolute'
    calls = f"{b['allocation_calls']:.3f} / {c['allocation_calls']:.3f}" if b else f"new / {c['allocation_calls']:.3f}"
    requested = f"{b['requested_bytes']:.3f} / {c['requested_bytes']:.3f}" if b else f"new / {c['requested_bytes']:.3f}"
    text += f"| {r['cohort']} / {r['case']} | {r['outcome']} | {before} | {c['elapsed_ns']/1e6:.6f} | {ratio} | {calls} | {requested} |\n"
text += '\nProcess RSS includes the entire cohort, warmup and allocator retention; it is not per-operation retained heap. Executables are local release builds with allocation instrumentation.\n\n| Cohort | Before / after max RSS KiB | Before / after executable bytes |\n| --- | ---: | ---: |\n'
for r in resources:
    b, c = r.get('baseline'), r['candidate']
    text += f"| {r['cohort']} | {b['maximum_process_rss_kib'] if b else 'new'} / {c['maximum_process_rss_kib']} | {b['binary_bytes'] if b else 'new'} / {c['binary_bytes']} |\n"
(OUT / 'costs.md').write_text(text)
qualification = dict(base_revision='8c88793eb38c5d95661062ce716339b5b7652dc9',
    upstream_revision='dbe99e3cc145e8ca58a53ade6e79fd46311972fb', tests=counts,
    new_shared_groups=8, new_internal_admission_regressions=1,
    native_consumer_groups=native, original_exchange_workflows=8, wasm_consumer_groups=wasm,
    baseline_projects=len(baseline), candidate_projects=len(candidate), prior_artifacts=prior,
    fresh_byte_identical_pairs=len(pairs), new_archives=new,
    qualified_checks=checks, source_patch=by_label['tests-all-features']['source_patch'],
    qualified_source_sha256=by_label['tests-all-features']['source_patch_sha256'])
write('qualification-summary.json', qualification)
print(json.dumps(qualification, indent=2), flush=True)
