"""Check final documentation and prove qualified code/fixtures stayed unchanged."""
from pathlib import Path
import hashlib,json,re,subprocess
from source_identity import source_identity
from run import OUT,ROOT

NAME='2026-10-18-selected-revolution'
DEST=ROOT/'crates/hyperbrep/docs/evidence'/NAME
qualified=json.loads((OUT/'candidate-consumer-source.json').read_text())
current=source_identity(ROOT)
assert set(qualified)==set(current)
changed=[p for p in current if current[p]!=qualified[p]]
assert changed==['crates/hyperbrep/README.md'],changed
status=json.loads((ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json').read_text())
assert not status['complete'] and len(status['work_packages'])==28
assert len({r['id'] for r in status['work_packages']})==28
assert all(r['status'] in ['open','in-progress'] for r in status['work_packages'])
props=json.loads((ROOT/'docs/properties-status.json').read_text())
old=json.loads(subprocess.check_output(['git','show','HEAD:docs/properties-status.json'],cwd=ROOT,text=True))
assert {k:v for k,v in props.items() if k!='current_work'}=={k:v for k,v in old.items() if k!='current_work'}
assert {k:v for k,v in props['current_work'].items() if k!='hyperbrep'}=={k:v for k,v in old['current_work'].items() if k!='hyperbrep'}
json_files=list(DEST.rglob('*.json'))+[ROOT/'docs/properties-status.json',ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json']
for p in json_files:json.loads(p.read_text())
# Existing repository links outside this change keep their original ownership.
pattern=r'\[[^\]]*\]\(([^)]+)\)'
tracked=[ROOT/'crates/hyperbrep/README.md',ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md',ROOT/'crates/hyperbrep/docs/SUPPORT_MATRIX.md',ROOT/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md',ROOT/'crates/hyperbrep/docs/ARCHITECTURE.md']
links=[]
for p in list(DEST.rglob('*.md'))+tracked:
    old_links=set()
    if p in tracked:
        old_text=subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(ROOT))],cwd=ROOT,text=True)
        old_links=set(re.findall(pattern,old_text))
    for target in re.findall(pattern,p.read_text()):
        if target in old_links or '://' in target or target.startswith(('#','mailto:')):continue
        target=target.split('#')[0].strip('<>')
        if not target:continue
        assert (p.parent/target).exists(),(p,target)
        links.append(dict(source=str(p.relative_to(ROOT)),target=target))
record=dict(qualified_source='candidate-source.json',code_and_fixture_hashes_unchanged=True,documentation_hash_changes=changed,
    json_files_parsed=len(json_files),new_local_links_checked=len(links),links=links,work_packages=28,completed_work_packages=0,
    non_brep_property_ledger_values_unchanged=True,scope='Documentation/ledger validation after qualification. No new runtime implementation claim; full pre-push gates remain required.')
(DEST/'documentation-audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='links'},indent=2),flush=True)
