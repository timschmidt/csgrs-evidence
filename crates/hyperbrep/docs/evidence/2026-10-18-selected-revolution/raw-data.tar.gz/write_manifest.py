"""Bind the finished admission record to its supporting files."""
from pathlib import Path
import hashlib,json
from run import OUT,ROOT

DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-18-selected-revolution'
data=json.loads((OUT/'documentation-stage.json').read_text())
data['implementation']=[
 'crates/hyperbrep/src/geometry/rotation.rs','crates/hyperbrep/src/geometry.rs',
 'crates/hyperbrep/src/geometry/point.rs','crates/hyperbrep/src/construction.rs',
 'crates/hyperbrep/src/construction/patches.rs','crates/hyperbrep/src/lib.rs',
 'crates/hyperbrep/src/ownership/builder.rs','crates/hyperbrep/src/ownership/staging.rs',
 'crates/hyperbrep/src/persistence.rs','crates/hyperbrep/src/persistence/admission/shapes.rs',
 'crates/hyperbrep/src/persistence/limits.rs','crates/hyperbrep/src/topology/builder.rs',
 'crates/hyperbrep/src/topology/helpers.rs','crates/hyperbrep/src/topology/validation/analytic_image.rs',
 'crates/hyperbrep/src/topology/validation/image.rs','crates/hyperbrep/src/topology/validation/revolution.rs']
data['tests']=['crates/hyperbrep/tests/selected_revolution.rs','crates/hyperbrep/tests/support/selected_revolution.rs',
 'crates/hyperbrep/src/construction/patches.rs']
data['source_reconstruction']='Recreate the base revision, decompress qualified-source.patch.gz, apply the exact patch, and verify candidate-source.json. Final documentation-only changes are audited separately. Remap recorded baseline/candidate source roots for external projects; use retained locks, recipes and inputs. No compatibility adapter is required.'
data['publication']='eaa0cae54 was already pushed under its one-time exception. This increment has local affected-scope qualification only; every required repository pre-push check remains required before publication.'
data['files']={str(p.relative_to(DEST)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(DEST/'manifest.json').write_text(json.dumps(data,indent=2)+'\n')
print('Manifest files:',len(data['files']),flush=True)
