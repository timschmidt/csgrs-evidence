import run
assert run.run({'label':'final-wasm-build','command':['cargo','build','--offline','--release','--target','wasm32-unknown-unknown','--manifest-path',str(run.OUT/'consumer/Cargo.toml'),'--lib'],'env':{'CARGO_TARGET_DIR':'/tmp/hyperbrep-review-wasm-target'},'seconds':3600})==0
assert run.run({'label':'final-wasm-run','command':['python3','-B',str(run.OUT/'wasm_consumer.py'),'/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_pcurve_map_consumer.wasm','2',str(run.OUT/'wasm-exports.json')],'seconds':1800})==0
