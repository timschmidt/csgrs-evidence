import hashlib,json,runpy
import run
source=json.loads((run.OUT/'candidate-source.json').read_text())
def verify():
    assert all(hashlib.sha256((run.ROOT/path).read_bytes()).hexdigest()==digest for path,digest in source['files'].items())
verify()
runpy.run_path(str(run.OUT/'qualify.py'),run_name='__main__')
verify()
runpy.run_path(str(run.OUT/'consumers.py'),run_name='__main__')
verify()
