//! Selected chart regression cases; the affine equations are independent oracles.

use super::*;
use hypercurve::{
    BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval,
    BezierParameterPolynomial, CurveParameter2, CurveParameterRange2, QuadraticBezier2,
};

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn selected() -> CurveParameter2 {
    BezierParameter2::Algebraic(
        BezierAlgebraicParameter2::try_isolate(
            BezierParameterPolynomial::try_new_power_basis(vec![
                (-1).into(), 0.into(), 0.into(), 2.into(),
            ])
            .unwrap(),
            BezierParameterInterval::try_new(q(3, 4), q(7, 8)).unwrap(),
        )
        .unwrap(),
    )
    .into()
}

fn retained() -> SurfaceIntersectionPcurve {
    let curve = Curve2::from(QuadraticBezier2::new(
        CurvePoint2::from_values(0, 0),
        CurvePoint2::new(q(1, 2), 0.into()),
        CurvePoint2::from_values(1, 1),
    ))
    .restrict_source(CurveParameterRange2::try_new(q(1, 4).into(), selected()).unwrap())
    .unwrap();
    SurfaceIntersectionPcurve::retained_curve(curve).unwrap()
}

#[test]
fn selected_retained_pcurve_materializes() {
    assert!(retained().materialize().is_ok());
}

#[test]
fn selected_iso_pcurve_materializes() {
    let domain = retained().domain;
    for axis in [TensorAxis::U, TensorAxis::V] {
        assert!(
            SurfaceIntersectionPcurve::tensor_iso(
                domain.clone(), 3.into(), axis, (-2).into(), 5.into(),
            )
            .materialize()
            .is_ok()
        );
    }
}

#[test]
fn materialized_parameter_map_checks_domain() {
    let mapping = SurfaceIntersectionPcurve::tensor_iso_v(ParameterRange::unit(), 3.into())
        .materialize()
        .unwrap();
    for outside in [-1, 2] {
        assert!(matches!(
            mapping.spatial_parameter_at(&Real::from(outside)),
            Err(GeometryError::ParameterOutsideDomain)
        ));
    }
}
