#[allow(dead_code)]
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/pcurve_parameters.rs"]
mod acceptance;
fn cases() -> [(&'static str, fn()); 2] { [
("selected_pcurve_maps_compose_and_replay", acceptance::selected_pcurve_maps_compose_and_replay),
("pcurve_maps_check_domains_and_recover_after_exhaustion", acceptance::pcurve_maps_check_domains_and_recover_after_exhaustion),
] }
