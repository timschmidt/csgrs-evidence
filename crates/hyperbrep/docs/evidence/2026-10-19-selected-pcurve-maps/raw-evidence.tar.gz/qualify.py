import json,run
for job in json.loads((run.OUT/'qualification.json').read_text()):
    assert run.run(job)==0, job['label']
