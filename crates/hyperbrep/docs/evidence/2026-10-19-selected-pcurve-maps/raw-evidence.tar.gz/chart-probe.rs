use hypercurve::*;
fn q(a:i32,b:i32)->Real {(Real::from(a)/Real::from(b)).unwrap()}
fn main(){
let a:CurveParameter2=BezierParameter2::Algebraic(BezierAlgebraicParameter2::try_isolate(BezierParameterPolynomial::try_new_power_basis(vec![(-1).into(),0.into(),0.into(),2.into()]).unwrap(),BezierParameterInterval::try_new(q(3,4),q(7,8)).unwrap()).unwrap()).into();
let b=a.affine_image(&Real::from(-2),&Real::from(5)).unwrap();
println!("b comparison {:?}",b.compare(&Real::from(3).into()));
let point=b.affine_point(1.into(),0.into(),0.into(),0.into());
println!("point constructed {}",point.is_ok());
println!("bounds {:?}",point.unwrap().bounds());
let unit=b.affine_image(&q(4,5),&q(-13,5)).unwrap();
println!("unit {:?} {:?}",unit.compare(&Real::zero().into()),unit.compare(&Real::one().into()));
let recovered=unit.affine_image(&q(-5,8),&q(7,8)).unwrap();
println!("roundtrip {:?}",recovered.compare(&a));
assert_eq!(recovered.compare(&a).unwrap(),std::cmp::Ordering::Equal);
}
