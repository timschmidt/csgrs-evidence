import copy,gzip,hashlib,json,subprocess,tarfile,shutil
from pathlib import Path
import run
O=run.OUT;R=run.ROOT
D=R/'crates/hyperbrep/docs/evidence/2026-10-19-selected-pcurve-maps'
def write(p,obj): p.write_text(json.dumps(obj,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
tests=json.loads((O/'test-summary.json').read_text());cost=json.loads((O/'cost-analysis.json').read_text());art=json.loads((O/'archive-comparison.json').read_text());sizes=json.loads((O/'binary-sizes.json').read_text());src=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in src['files'].items())
q=(f"All-feature release BRep/IO suites pass {tests['final-brep-release-tests-v2']['passed']} tests in {tests['final-brep-release-tests-v2']['batches']} batches, with no failures or ignored tests. Five internal groups cover selected retained/iso materialization, affine charts, reversal, restriction, domain errors, angular seams and checked archives. Two shared public groups pass natively and in actual zero-import Wasmtime, including mixed selected fibers, transforms, three cold replays, strict/approximate/strict scopes, success with zero counted solver work and recovery after promotion exhaustion. The owner selected-fiber tests, affected Hypercurve/BRep/IO all-target/all-feature Clippy and rustdoc with warnings denied, BRep fuzz-target compilation and formatting pass. Six preserved complete workflows emit "+str(art['identical_preserved_files'])+" byte-identical archives; four new archives replay. The original complete biquadratic interior-loop section success assertion still fails with UnsupportedIntersection on baseline and candidate. It remains an open target.")
ratios=[r['latency_ratio'] for r in cost['phase_medians']]
p=(f"Nine CPU-0 pinned processes retain three alternating baseline/candidate pairs for six preserved completed workflows and three absolute processes for two new workflows. First and three repeated fresh-input invocations include assertions, materialization, validation and replay. Twelve median latency ratios span {min(ratios):.6f} to {max(ratios):.6f}; {cost['increased_allocation_rows']} of 36 matched rows increase Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. All adverse rows and raw samples remain. Maximum process RSS is {cost['maximum_rss_kib']} KiB; the matched executable changes by {sizes['candidate']['bytes']-sizes['baseline']['bytes']:+d} bytes. No new stored fields or cache are introduced. Requested Rust allocation traffic is not live heap and excludes foreign allocators. Shared-host timings establish no speedup; newly successful contracts have no successful baseline. Selected iso replay has native correctness coverage without a separate allocation campaign.")
limits=("This completes selected materialized parameter maps and the declared internal selected retained/iso pcurve constructions, not general sections or face arrangements. SurfaceIntersectionPcurve::point_at still requires represented coordinates; Surface::point_at and full section restriction also need retained-image migration. Angular interior selected images remain explicitly unsupported when coordinates are unavailable. Generic exterior affine-point bounds, arbitrary rational maps, implicit-branch derivatives/regularity, whole-branch/event archives, dual-chart section graphs and general patch intersections remain open. Existing solver counters, degree and archive limits do not bound total work, live heap, stack or cancellation. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, production bindings and full workflow/push gates are unqualified. Source consumers are not released packages. All 28 work packages remain open/in-progress. No new push is authorized by the consumed eaa0cae54 exception.")
report=dict(date='2026-10-19',base_revision=src['base'],increment='selected-pcurve-maps-2026-10-19',qualification=q,cost_evidence=p,limits=limits)
write(O/'report.json',report)
# Source patch covers exactly the qualified Rust files, including new regressions.
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*src['files']],cwd=R)
for name in src['files']:
    if subprocess.run(['git','ls-files','--error-unmatch',name],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
        added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=R,capture_output=True)
        assert added.returncode==1;patch+=added.stdout
(O/'qualified-source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
write(O/'source-patch.json',dict(base=src['base'],sha256=hashlib.sha256(patch).hexdigest(),files=list(src['files'])))
ideas=[
 dict(idea='Borrow scalar bounds from the native selected authority',status='kept',evidence='Existing SelectedScalar2 dispatch supplies immutable intervals without proof work or independent roots. Public native/WASM recipes verify exact, algebraic and selected-fiber affine images in positive and negative exterior charts.'),
 dict(idea='Retain source charts through materialized spatial parameter maps',status='kept',evidence='All original baseline assertions now pass; archive/transform consumers retain selected parameters. Domain membership is checked before either affine or angular mapping.'),
 dict(idea='Generated rational Bezier iso carrier',status='rejected',evidence='Point/map checks passed but the complete archive assertion failed with UnsupportedPcurve(RationalBezier). Original failed logs and patches remain.'),
 dict(idea='Use planar point bounds to obtain scalar enclosures',status='rejected',evidence='The standalone clean-baseline probe returns Ordering for exterior affine-point bounds while the composed scalar affine roundtrip is exactly Equal. Native-line and initial spline attempts both hit this prerequisite.'),
 dict(idea='Degree-one native spline with source-coordinate knots',status='kept',evidence='Scalar bounds choose only a finite support. Exact selected restrictions and inverse maps preserve the original chart and replay using the existing SourceRange archive. Native representation classification distinguishes it from a line.'),
 dict(idea='Preserve represented iso and planar projection paths',status='already-satisfied',evidence='Existing paths remain; six completed recipes and deterministic artifacts are compared against frozen 6564f3905.'),
 dict(idea='New global polynomial norm or external CAD kernel for affine chart transport',status='architecture-inapplicable',evidence='Existing selected-scalar affine authority suffices. No new solver or dependency is needed.'),
]
write(O/'ideas.json',ideas)
(O/'next-domains.md').write_text('''# Continue toward complete BRep sections

Preserve the original full interior-loop input and success assertion. This increment does not solve it. The previous [selected-fiber roadmap](../2026-10-19-selected-fiber-images/next-domains.md) remains applicable, with the materialized parameter-map boundary now closed for the declared domain.

1. Move the retained pcurve implementation into `geometry/pcurve.rs` while migrating `SurfaceIntersectionPcurve::point_at` from represented `Real`/`Point2` to retained `Parameter`/`hypercurve::CurvePoint2`, using source authority for affine and plane projections. Migrate actual callers directly. Do not add a compatibility overload. `MaterializedSurfacePcurve::spatial_parameter_at` already retains selected parameters and checks its domain.
2. Give `Surface::point_at` a joint retained UV image authority returning `GeometricPoint3`. Plane images can use affine forms; tensor images need correlated rational maps, not independently reconstructed coordinates. Preserve certainty and source identity through transforms and archives. Keep represented coordinate views explicitly fallible.
3. Retain selected intervals in complete `SurfaceIntersectionCurve` restriction and its spatial curve, both pcurves and boundary contacts. Existing represented native subdivision rebases some charts; the retained path must preserve the common correspondence and source, then prove every image claim.
4. Add whole polynomial-branch replay: equation/domain/solver controls, slab/root selector, restrictions, transforms and event incidence, with admission before decoding and cold recomputation. Scalar point/form replay is not whole-branch authority.
5. Implement the previously described invertible affine projection domain for polynomial height patches. Reuse `Curve3::planar_image`; retain the original tensor chart, plane chart and shared graph. Slab branches can meet at critical/singular events, so do not publish them as disjoint `Curves` without preserving incidence. The full loop, isolated/singular/disconnected components and empty results must be inspected and consumed by restriction/reversal/transform/replay and further modeling.
6. Extend source-bound rational maps, regularity/tangent certificates, vertical/common components, patch-pair images and trim/material arrangements. Maintain exact topology and explicit unsupported/undecided/exhausted outcomes. Complete total-work/heap/stack/cancellation, runtime fuzz/ASan/lexicase, release/MSRV/binding and full workflow gates before broader claims.

The exterior affine-point bounds blocker has a retained standalone probe. It is separate from affine scalar arithmetic, which passed. Use the scalar owner's borrowed bounds where only scalar enclosures are needed; repair generic point bounds when a BRep consumer actually requires that capability. Avoid unrelated upstream cleanup.
''')
D.mkdir(exist_ok=False)
for name in ['contract.md','test-oracle-correction.md','next-domains.md','candidate-source.json','baseline-source.json','environment.json','dependency-comparison.json','upstream-check.json','test-summary.json','archive-comparison.json','cost-analysis.json','binary-sizes.json','verification.json','report.json','source-patch.json','qualified-source.patch.gz','ideas.json']:
    shutil.copy(O/name,D/name)
(D/'README.md').write_text('# Selected pcurve parameter maps\n\nBase: `'+src['base']+'`. Local implementation increment; no push or work-package completion.\n\n'+q+'\n\n'+p+'\n\n'+limits+'''\n\n## API and representation

`MaterializedSurfacePcurve::spatial_parameter_at(&CurveParameter2)` now returns `Parameter`, checks membership, and preserves selected authority. Pass the result directly to `Curve3::point_at`. Callers that still require represented values explicitly request `try_real()` and retain `UnrepresentableParameter`. `SurfaceIntersectionPcurve::subcurve` accepts retained `Parameter` endpoints. There are no legacy overloads.

`CurveParameter2::scalar_bounds` borrows the owning scalar's stored enclosure; it never substitutes a coordinate or refines a root. Selected iso materialization uses a native degree-one spline with the original source coordinate as its knot parameter. Bounds choose only the support; the exact selected restriction controls the output. Existing `SourceRange`/NURBS archives replay it. No schema change is introduced.

## Evidence and reproduction

[Contract](contract.md), [source hashes](candidate-source.json), [tests](test-summary.json), [costs](cost-analysis.json), [artifact comparison](archive-comparison.json), [idea decisions](ideas.json), [next domains](next-domains.md), and [raw evidence](raw-evidence.tar.gz) retain the boundaries and failed attempts. The initial budget oracle incorrectly required exhaustion for a direct replay that performs no counted solver work; its correction and the additional actual exhaustion fixture are documented in [the oracle record](test-oracle-correction.md).

Raw evidence includes the runner/environment, all commands and exits, original probes, per-command source patches, standalone consumer manifests/locks, logs, native archives and allocation/RSS samples. It excludes executables and caches. Paths name the frozen main baseline and separate development checkout; adjust those explicit source/cache paths when reproducing. `source_scope` overrides the runner's development snapshot for baseline-binary jobs. Do not run the snapshot runner after copying evidence into the repository.
''')
# Update the implementation ledger without rewriting historical entries.
status_path=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
old_text=status_path.read_text();status=json.loads(old_text);before=copy.deepcopy(status)
entry=dict(id=report['increment'],work_packages=['WP05a','WP05b','WP06','WP13','WP21'],properties=['P1','P4','P5','P6','P8','P9','P15','P16','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],change='Retain materialized pcurve spatial parameters and selected retained/iso source charts through exact queries and checked archives.',sources=['../src/geometry.rs','../../hypercurve/src/bezier_split.rs','../src/geometry/selected_pcurves.rs','../tests/support/pcurve_parameters.rs'],evidence='evidence/2026-10-19-selected-pcurve-maps/manifest.json',validation=q,cost_evidence=p,limits=limits)
status['increments'].append(entry)
new_text=json.dumps(status,indent=2)+'\n'
assert json.loads(new_text)['increments'][:-1]==before['increments']
assert status['work_packages']==before['work_packages'] and not status['complete']
status_path.write_text(new_text)
plan=R/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md';text=plan.read_text();text=text.replace('Updated 2026-10-19 for selected-fiber\nimages,','Updated 2026-10-19 for selected pcurve\nparameter maps,',1)
marker='Apply [research gates G2–G5]'
assert marker in text
paragraph='''The [selected pcurve parameter-map increment](evidence/2026-10-19-selected-pcurve-maps/README.md)
now maps native pcurve parameters to retained spatial `Parameter` values with
strict domain checks, including selected endpoints. Retained and iso mappings
materialize selected restrictions with checked archive replay. Hypercurve owns
the borrowed scalar-enclosure view; BRep uses a native degree-one spline to keep
selected iso charts unchanged. Existing represented carriers remain preserved.
The API break is direct: `spatial_parameter_at(&CurveParameter2) -> Parameter`
and pcurve `subcurve(&Parameter, &Parameter)`. Consumers needing stored scalar
views explicitly request them. General retained pcurve/surface evaluation,
whole-branch/event replay and complete section topology remain open; follow the
[current next domains](evidence/2026-10-19-selected-pcurve-maps/next-domains.md).
No work package or release gate is closed by this increment.

'''
text=text.replace(marker,paragraph+marker,1);text=text.replace('Follow the current\n[next domains](evidence/2026-10-19-selected-fiber-images/', 'Follow the associated\n[next domains](evidence/2026-10-19-selected-fiber-images/');plan.write_text(text)
matrix=R/'crates/hyperbrep/docs/SUPPORT_MATRIX.md';text=matrix.read_text();marker='## Spatial curve carriers';assert marker in text
text=text.replace(marker,'''Materialized pcurve correspondence now accepts retained `CurveParameter2`
values and returns spatial `Parameter` values, with strict domain membership.
Selected retained/iso mappings preserve restrictions, reversal and checked
archive replay; selected iso carriers use degree-one splines in the original
chart. Represented iso carriers retain native lines. Angular selected interior
queries still fail typed when their coordinates are unavailable. The complete
section evaluator and surface UV evaluator remain separate open boundaries.
See the [parameter-map evidence](evidence/2026-10-19-selected-pcurve-maps/README.md).

'''+marker,1);matrix.write_text(text)
archive=R/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md';archive.write_text(archive.read_text()+'''\nSelected iso pcurves now use a degree-one native NURBS source with the original
coordinate as its knot parameter and an exact `SourceRange` restriction.
Certified scalar bounds choose only a finite source support. They never replace
the selected endpoints. This reuses the existing archive schema and cold
validation; arbitrary generated rational fragments and whole implicit branches
are not thereby admitted. See the [parameter-map record](evidence/2026-10-19-selected-pcurve-maps/README.md).
''')
# Replace precisely current_work.hyperbrep; preserve every other byte.
ledger_path=R/'docs/properties-status.json';text=ledger_path.read_text();ledger=json.loads(text);entry=ledger['current_work']['hyperbrep'];entry.update(latest_implementation=report['increment'],latest_feature_evidence='crates/hyperbrep/docs/evidence/2026-10-19-selected-pcurve-maps/manifest.json',latest_evidence='crates/hyperbrep/docs/evidence/2026-10-19-selected-pcurve-maps/manifest.json',qualification=q,performance_evidence=p,limits=limits,latest_update_check='crates/hyperbrep/docs/evidence/2026-10-19-selected-pcurve-maps/upstream-check.json')
decoder=json.JSONDecoder()
def ws(s,p):
    while s[p].isspace():p+=1
    return p
def member(s,p,key):
    p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
    while s[p]!='}':
        name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
        if name==key:return a,b
        p=ws(s,b)
        if s[p]==',':p=ws(s,p+1)
    raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;ledger_path.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()))
shutil.copy(O/'ledger-scope.json',D/'ledger-scope.json')
# No run.py calls beyond this point: the evidence directory is now in the worktree.
checks=[]
for name,command in [('format',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]:
    result=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True)
    (O/('post-documentation-'+name+'.log')).write_text(result.stdout+result.stderr)
    assert result.returncode==0,(name,result.stderr)
    checks.append(dict(name=name,command=command,exit_code=result.returncode))
assert all(sha(R/p)==h for p,h in src['files'].items())
write(O/'post-documentation-checks.json',dict(checks=checks,qualified_source_unchanged=True))
shutil.copy(O/'post-documentation-checks.json',D/'post-documentation-checks.json')
allowed={'.json','.log','.patch','.py','.rs','.toml','.md'}
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
    for path in sorted(O.rglob('*')):
        if not path.is_file() or path.is_symlink():continue
        if path.suffix not in allowed and path.name!='Cargo.lock':continue
        if any(part in ['bin','__pycache__','target'] for part in path.relative_to(O).parts):continue
        info=tar.gettarinfo(str(path),arcname=str(path.relative_to(O)));info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644
        with path.open('rb') as stream:tar.addfile(info,stream)
write(D/'manifest.json',dict(schema_version=1,base_revision=src['base'],increment=report['increment'],report='report.json',qualification='verification.json',source='candidate-source.json',raw='raw-evidence.tar.gz',files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file()}))
print(json.dumps(dict(evidence=str(D),files=len(list(D.iterdir())),raw_bytes=(D/'raw-evidence.tar.gz').stat().st_size,tests=tests),indent=2))
