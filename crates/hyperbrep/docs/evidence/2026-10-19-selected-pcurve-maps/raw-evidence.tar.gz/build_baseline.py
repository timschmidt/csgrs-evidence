from pathlib import Path
import run, subprocess, shutil
base = Path('/mnt/development/csgrs')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip() == '6564f39051f7db19694d7e0bdd735c45010a355b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=base,text=True).strip()
assert run.run({'label':'baseline-preserved-build','source_scope':'clean main 6564f39051f7db19694d7e0bdd735c45010a355b', 'command':['cargo','build','--offline','--release','--manifest-path',str(run.OUT/'preserved/baseline/Cargo.toml'),'--bin','hyperbrep-pcurve-preserved-baseline'],'seconds':3600})==0
(run.OUT/'bin').mkdir(exist_ok=True)
shutil.copy('/tmp/hyperbrep-review-target/release/hyperbrep-pcurve-preserved-baseline',run.OUT/'bin/baseline')
assert run.run({'label':'baseline-preserved-artifacts','source_scope':'clean main 6564f39051f7db19694d7e0bdd735c45010a355b','command':[str(run.OUT/'bin/baseline'),'all'],'env':{'HYPERBREP_SIMILARITY_ARTIFACT_DIR':str(run.OUT/'artifacts/baseline'),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(run.OUT/'artifacts/fibers-baseline')},'seconds':3600})==0
