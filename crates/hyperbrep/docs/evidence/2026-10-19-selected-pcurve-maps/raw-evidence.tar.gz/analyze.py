import hashlib,json,re,statistics,subprocess
from pathlib import Path
import run
O=run.OUT; R=run.ROOT; B=Path('/mnt/development/csgrs')
def write(name,value): (O/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/name)==digest for name,digest in source['files'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==source['base']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
rows=json.loads((O/'results.json').read_text()); checks={r['label']:r for r in rows}
required=[j['label'] for j in json.loads((O/'qualification.json').read_text())]+['focused-internal-v6','focused-public-v3','final-new-build','final-new-archives','final-candidate-build','final-candidate-archives','final-wasm-build','final-wasm-run','baseline-preserved-archives']
for label in required: assert checks[label]['exit_code']==0,(label,checks[label]['exit_code'])
for label in ['baseline-selected-pcurves','baseline-selected-public-api','baseline-original-interior-loop','final-original-interior-loop']: assert checks[label]['exit_code']==101,label
assert 'UnsupportedIntersection' in (O/'final-original-interior-loop.log').read_text()
for row in rows:
    assert sha(Path(row['log']))==row['log_sha256']
    assert sha(Path(row['source_patch']))==row['source_patch_sha256']
summary={}
for label in ['final-brep-release-tests-v2','final-owner-selected-fiber-tests','focused-internal-v6','focused-public-v3']:
    counts=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/(label+'.log')).read_text())]
    assert counts,label
    summary[label]=dict(passed=sum(r[0] for r in counts),failed=sum(r[1] for r in counts),ignored=sum(r[2] for r in counts),batches=len(counts))
    assert summary[label]['failed']==0
write('test-summary.json',summary)
artifacts={}
for group in ['baseline','candidate','fibers-baseline','fibers-candidate','new']:
    artifacts[group]={str(p.relative_to(O/'artifacts'/group)):sha(p) for p in sorted((O/'artifacts'/group).glob('*.json'))}
assert artifacts['baseline'] and artifacts['baseline']==artifacts['candidate']
assert len(artifacts['fibers-baseline'])==3 and artifacts['fibers-baseline']==artifacts['fibers-candidate']
assert len(artifacts['new'])==4
write('archive-comparison.json',dict(identical_preserved_files=len(artifacts['baseline'])+3,new_files=4,files=artifacts))
raw=[];pairs=[];rss=[]
for repeat in range(3):
    per={}
    for side in ['baseline','candidate','new']:
        label=f'cost-{side}-{repeat}'
        assert checks[label]['exit_code']==0
        samples=[json.loads(line) for line in (O/(label+'.log')).read_text().splitlines() if line.startswith('{')]
        data=[r for r in samples if 'case' in r]
        assert len(data)==(4 if side=='new' else 12)
        per[side]={(r['case'],r['phase']):r for r in data}
        raw.append(dict(repeat=repeat,side=side,rows=samples))
        rss.append(json.loads((O/'costs'/(label+'.json')).read_text()))
    for key,a in per['baseline'].items():
        b=per['candidate'][key]
        assert a['iterations']==b['iterations'] and a['outcome']==b['outcome']
        pairs.append(dict(repeat=repeat,case=key[0],phase=key[1],ratio=b['elapsed_ns']/a['elapsed_ns'],allocation_call_delta=b['allocation_calls']-a['allocation_calls'],requested_byte_delta=b['requested_bytes']-a['requested_bytes'],iterations=a['iterations']))
medians=[]
for case,phase in sorted({(r['case'],r['phase']) for r in pairs}):
    values=[r for r in pairs if (r['case'],r['phase'])==(case,phase)]
    medians.append(dict(case=case,phase=phase,latency_ratio=statistics.median(r['ratio'] for r in values),allocation_call_deltas=[r['allocation_call_delta'] for r in values],requested_byte_deltas=[r['requested_byte_delta'] for r in values]))
write('cost-analysis.json',dict(scope='Three alternating CPU-0 pinned process pairs for six complete preserved recipes, plus three absolute processes for two new recipes. Every invocation keeps assertions, materialization, validation and replay. First and three repeated fresh inputs are distinct phases; they are not a cache-eviction campaign.',raw_samples=raw,pairs=pairs,phase_medians=medians,maximum_rss_kib=max(r['maximum_rss_kib'] for r in rss),increased_allocation_rows=sum(r['allocation_call_delta']>0 for r in pairs),increased_byte_rows=sum(r['requested_byte_delta']>0 for r in pairs),limits='Rust requested allocation traffic excludes foreign allocators and is not live heap. Shared-host timings do not establish a speedup. New successful contracts have no prior successful timing baseline. Selected iso archive recipes have native correctness coverage but no separate allocator campaign.'))
binaries={side:dict(bytes=(O/'bin'/side).stat().st_size,sha256=sha(O/'bin'/side)) for side in ['baseline','candidate','new']}
w=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_pcurve_map_consumer.wasm')
binaries['wasm']=dict(bytes=w.stat().st_size,sha256=sha(w))
write('binary-sizes.json',binaries)
write('verification.json',dict(required_checks=required,source_hashes_match=True,baseline_clean=True,baseline_revision=source['base'],raw_logs_and_patches_match=True,preserved_artifacts_match=True,no_push=True))
print(json.dumps(dict(tests=summary,artifacts=len(artifacts['baseline'])+3,medians=medians,binaries=binaries),indent=2))
