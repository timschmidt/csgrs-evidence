use hyperbrep::{OperationContext, WorkBudget, builder};
use hyperbrep_io::step::{StepBody, StepWriteOptions, WriteErrorKind, write_advanced};

#[path = "../../../hyperbrep/tests/support/selected_profile_source.rs"]
mod native;

pub fn selected_profile_step_vertices_remain_explicitly_unencodable() {
    let context = OperationContext::strict(WorkBudget {
        refinements: 100_000,
        promotions: 10_000,
    });
    let options = StepWriteOptions::new("selected.step", "2026-10-18T00:00:00");
    for xor in [false, true] {
        for affine in [false, true] {
            let (region, _) = native::profile(xor, affine, false);
            let original = builder::extrude_curve_region(&region, 0.into(), 3.into()).unwrap();
            for model in [original.model().clone(), native::replay(original.model())] {
                let bodies = model
                    .solids()
                    .map(|solid| StepBody {
                        solid,
                        name: "selected exact profile",
                    })
                    .collect::<Vec<_>>();
                let error = write_advanced(&bodies, &options, &context)
                    .result
                    .unwrap()
                    .unwrap_err();
                assert!(
                    matches!(error.kind, WriteErrorKind::NonRational),
                    "{error:?}"
                );
                assert!(error.body.is_some());
                assert!(error.entity.is_some());
                // No partial file replaces the exact model on failure.
                assert_eq!(
                    native::replay(&model).to_json().unwrap(),
                    model.to_json().unwrap()
                );
            }
        }
    }
}
