#[path = "support/selected_profiles.rs"]
mod acceptance;

#[test]
fn selected_profile_step_vertices_remain_explicitly_unencodable() {
    acceptance::selected_profile_step_vertices_remain_explicitly_unencodable();
}
