use hyperbrep::*;
use hypercurve::{
    BooleanOp, Curve2, CurvePath2, CurveRegion2, FillRule, LineSeg2, QuadraticBezier2,
};

fn p(x: i32, y: i32) -> hypercurve::Point2 {
    hypercurve::Point2::from_values(x, y)
}

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn line(a: hypercurve::Point2, b: hypercurve::Point2) -> Curve2 {
    LineSeg2::try_new(a, b).unwrap().into()
}

pub fn profile(xor: bool, affine: bool, reverse: bool) -> (CurveRegion2, Real) {
    // x = 4t - 2, y = x^2; material lies between this parabola and y = 4.
    let path = CurvePath2::try_new(vec![
        QuadraticBezier2::new(p(-2, 4), p(0, -4), p(2, 4)).into(),
        line(p(2, 4), p(-2, 4)),
    ])
    .unwrap();
    let path = if reverse {
        path.reversed().unwrap()
    } else {
        path
    };
    let source = CurveRegion2::try_from_boundary_paths(&[path], FillRule::EvenOdd).unwrap();
    let points = [p(-3, 2), p(3, 2), p(3, 5), p(-3, 5)];
    let clip = CurvePath2::try_new(
        (0..4)
            .map(|i| line(points[i].clone(), points[(i + 1) % 4].clone()))
            .collect(),
    )
    .unwrap();
    let clip = CurveRegion2::try_from_boundary_paths(&[clip], FillRule::EvenOdd).unwrap();
    let mut region = source
        .boolean_region(
            &clip,
            if xor {
                BooleanOp::Xor
            } else {
                BooleanOp::Difference
            },
        )
        .unwrap();
    assert!(region.has_algebraic_fragments());
    // Integral of 2-x^2 from -sqrt(2) to sqrt(2); XOR adds the other difference.
    let root = Real::from(2).sqrt().unwrap();
    let mut area = if xor {
        q(22, 3) + q(16, 3) * root
    } else {
        q(8, 3) * root
    };
    if affine {
        region = region
            .transform_affine(
                &(-2).into(),
                &0.into(),
                &0.into(),
                &3.into(),
                &7.into(),
                &(-1).into(),
            )
            .unwrap();
        area *= Real::from(6);
    }
    (region, area)
}

pub fn replay(model: &Model) -> Model {
    let text = model.to_json().unwrap();
    let cold = RawModel::from_json(&text, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(cold.to_json().unwrap(), text);
    cold
}

fn volume(model: &Model, expected: &Real) {
    let actual: Real = model.solids().map(|s| s.volume().unwrap()).sum();
    assert_eq!(
        hyperlimit::compare_reals(&actual, expected, STRICT_PREDICATES).value(),
        Some(std::cmp::Ordering::Equal),
    );
}

fn location(model: &Model, point: &Point3) -> SolidPointLocation {
    let mut result = SolidPointLocation::Outside;
    for solid in model.solids() {
        match solid.classify_point(point).unwrap() {
            SolidPointLocation::Inside => return SolidPointLocation::Inside,
            SolidPointLocation::Boundary => result = SolidPointLocation::Boundary,
            SolidPointLocation::Outside => {}
        }
    }
    result
}

fn verify(model: &Model, area: &Real, xor: bool, affine: bool) {
    assert_eq!(model.solids().count(), if xor { 2 } else { 1 });
    volume(model, &(area * Real::from(3)));
    let gap: Real = "1e-12".parse().unwrap();
    for (x, y, expected) in [
        (0.into(), 1.into(), SolidPointLocation::Inside),
        (0.into(), 3.into(), SolidPointLocation::Outside),
        (0.into(), 0.into(), SolidPointLocation::Boundary),
        (1.into(), 1.into(), SolidPointLocation::Boundary),
        (1.into(), Real::one() + &gap, SolidPointLocation::Inside),
        (1.into(), Real::one() - &gap, SolidPointLocation::Outside),
        (0.into(), 2.into(), SolidPointLocation::Boundary),
        (0.into(), Real::from(2) - &gap, SolidPointLocation::Inside),
        (0.into(), Real::from(2) + &gap, SolidPointLocation::Outside),
        (
            0.into(),
            q(9, 2),
            if xor {
                SolidPointLocation::Inside
            } else {
                SolidPointLocation::Outside
            },
        ),
        (
            q(5, 2),
            3.into(),
            if xor {
                SolidPointLocation::Inside
            } else {
                SolidPointLocation::Outside
            },
        ),
    ] {
        let (x, y) = if affine {
            (
                Real::from(-2) * x + Real::from(7),
                Real::from(3) * y - Real::one(),
            )
        } else {
            (x, y)
        };
        let point = Point3::new(x, y, q(3, 2));
        assert_eq!(location(model, &point), expected, "{point:?}");
    }
    for edge in model.edges() {
        let uses = edge.uses().collect::<Vec<_>>();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
}

pub fn selected_boolean_profiles_extrude_and_replay() {
    for xor in [false, true] {
        for affine in [false, true] {
            for reverse in [false, true] {
                let (region, area) = profile(xor, affine, reverse);
                let result =
                    hypercurve::evaluate_under(hypercurve::PredicatePolicy::STRICT, || {
                        builder::extrude_curve_region(&region, 0.into(), 3.into())
                    });
                assert_eq!(result.certainty(), hypercurve::CurveCertainty::Certified);
                let bodies = result.into_unverified().unwrap();
                for model in [bodies.model().clone(), replay(bodies.model())] {
                    verify(&model, &area, xor, affine);
                }
            }
        }
    }
}

pub fn selected_profile_paths_share_native_image_admission() {
    for xor in [false, true] {
        for reverse in [false, true] {
            let (region, area) = profile(xor, false, reverse);
            let regions = region
                .material_components()
                .unwrap()
                .iter()
                .map(|component| {
                    let mut paths = component
                        .boundary_loops()
                        .iter()
                        .map(|boundary| {
                            let path = CurvePath2::try_new(boundary.curves().to_vec()).unwrap();
                            if reverse {
                                path.reversed().unwrap()
                            } else {
                                path
                            }
                        })
                        .collect::<Vec<_>>();
                    (paths.remove(0), paths)
                })
                .collect::<Vec<_>>();
            let bodies = builder::extrude_path_regions(&regions, 0.into(), 3.into()).unwrap();
            verify(&replay(bodies.model()), &area, xor, false);
            if !xor {
                let path = &regions[0].0;
                for bodies in [
                    builder::extrude_path(path, 0.into(), 3.into()).unwrap(),
                    builder::extrude_path_region(path, &[], 0.into(), 3.into()).unwrap(),
                ] {
                    verify(&replay(bodies.model()), &area, false, false);
                }
                let sheet =
                    builder::planar_face(path, &[], Point3::origin(), Vector3::x(), Vector3::y())
                        .unwrap();
                let cold = replay(sheet.model());
                let actual = cold.faces().next().unwrap().area().unwrap();
                assert_eq!(
                    hyperlimit::compare_reals(&actual, &area, STRICT_PREDICATES).value(),
                    Some(std::cmp::Ordering::Equal)
                );
            }
        }
    }
}

pub fn selected_profile_edits_and_slab_booleans_preserve_exact_material() {
    for xor in [false, true] {
        for affine in [false, true] {
            let (region, area) = profile(xor, affine, false);
            let original = builder::extrude_curve_region(&region, 0.into(), 3.into()).unwrap();
            let edge = original
                .model()
                .edges()
                .find(|edge| edge.curve().kind() == Curve3Kind::RationalBezier)
                .unwrap();
            let split = edge.split(q(1, 2).into()).unwrap();
            let cold = replay(split.model());
            verify(&cold, &area, xor, affine);
            let mut current = BodySet::empty();
            for solid in cold.solids() {
                current = boolean::union(&current, &BodySet::from_solid(solid)).unwrap();
            }
            for _ in 0..2 {
                let cutter = builder::extrude_curve_region(&region, 1.into(), 2.into()).unwrap();
                let middle = boolean::intersection(&current, &cutter).unwrap();
                let ends = boolean::difference(&current, &cutter)
                    .unwrap_or_else(|error| panic!("slab difference xor={xor} affine={affine}: {error:?}"));
                volume(&replay(middle.model()), &area);
                volume(&replay(ends.model()), &(&area * Real::from(2)));
                assert_eq!(ends.len(), if xor { 4 } else { 2 });
                current = boolean::union(&ends, &middle).unwrap();
                verify(&replay(current.model()), &area, xor, affine);
                assert!(boolean::difference(&current, &original).unwrap().is_empty());
                assert!(boolean::difference(&original, &current).unwrap().is_empty());
                let empty = boolean::difference(&current, &current).unwrap();
                assert!(empty.is_empty());
                assert_eq!(replay(empty.model()).counts().solids, 0);
                current = boolean::union(&empty, &current).unwrap();
            }
            for identity in [
                boolean::union(&current, &BodySet::empty()).unwrap(),
                boolean::difference(&current, &BodySet::empty()).unwrap(),
            ] {
                verify(&replay(identity.model()), &area, xor, affine);
            }
            assert!(
                boolean::intersection(&current, &BodySet::empty())
                    .unwrap()
                    .is_empty()
            );
            assert!(
                boolean::difference(&BodySet::empty(), &current)
                    .unwrap()
                    .is_empty()
            );
        }
    }
}

pub fn selected_profiles_keep_holes_and_disconnected_components() {
    let (region, area) = profile(false, false, false);
    let points = [
        hypercurve::Point2::new(q(-1, 2), 1.into()),
        hypercurve::Point2::new(q(1, 2), 1.into()),
        hypercurve::Point2::new(q(1, 2), q(3, 2)),
        hypercurve::Point2::new(q(-1, 2), q(3, 2)),
    ];
    let hole = CurvePath2::try_new(
        (0..4)
            .map(|i| line(points[i].clone(), points[(i + 1) % 4].clone()))
            .collect(),
    )
    .unwrap();
    let hole = CurveRegion2::try_from_boundary_paths(&[hole], FillRule::EvenOdd).unwrap();
    let shifted = region
        .transform_affine(
            &1.into(),
            &0.into(),
            &0.into(),
            &1.into(),
            &8.into(),
            &0.into(),
        )
        .unwrap();
    let combined = region
        .boolean_region(&hole, BooleanOp::Difference)
        .unwrap()
        .boolean_region(&shifted, BooleanOp::Union)
        .unwrap();
    let bodies = builder::extrude_curve_region(&combined, 0.into(), 3.into()).unwrap();
    let expected = (area * Real::from(2) - q(1, 2)) * Real::from(3);
    for model in [bodies.model().clone(), replay(bodies.model())] {
        assert_eq!(model.solids().count(), 2);
        volume(&model, &expected);
        for (x, y, expected) in [
            (0.into(), q(5, 4), SolidPointLocation::Outside),
            (q(1, 2), q(5, 4), SolidPointLocation::Boundary),
            (8.into(), 1.into(), SolidPointLocation::Inside),
        ] {
            assert_eq!(location(&model, &Point3::new(x, y, 1.into())), expected);
        }
    }
}
