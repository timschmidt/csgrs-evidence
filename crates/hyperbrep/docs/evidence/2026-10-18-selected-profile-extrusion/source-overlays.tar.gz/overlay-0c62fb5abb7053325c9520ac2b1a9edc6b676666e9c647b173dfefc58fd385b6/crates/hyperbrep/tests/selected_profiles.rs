#[path = "support/selected_profiles.rs"]
mod acceptance;

#[test]
fn selected_boolean_profiles_extrude_and_replay() {
    acceptance::selected_boolean_profiles_extrude_and_replay();
}
