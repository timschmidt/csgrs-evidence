import json,run
job=json.loads((run.OUT/"qualification.json").read_text())[0]
assert run.run(job)==0
