import json,sys
from pathlib import Path
out=Path(__file__).parent
edits={}
for line in (out/sys.argv[1]).read_text().splitlines():
 try:r=json.loads(line)
 except ValueError:continue
 if r.get('reason')!='compiler-message' or r['message']['level']!='error':continue
 for span in r['message']['spans']:
  if not span['is_primary'] or span['label']!='expected `&CurvePoint2`, found `&Point2`':continue
  path=Path(span['file_name']).resolve();data=path.read_bytes()
  assert '/tests/' in str(path) or '/benches/' in str(path) or path.name.endswith('_tests.rs'),path
  start,end=span['byte_start'],span['byte_end']
  pos=data[:start].rfind(b'.point_at(')
  assert pos>=0 and not data[pos+10:start].strip()
  last=end
  while data[last:last+1] in (b' ',b'\n',b'\r',b','):last+=1
  assert data[last:last+1]==b')'
  arg=data[start:end].decode()
  converted=('&{ let uv = '+arg+'; hypercurve::Point2::new(uv.x.clone(), uv.y.clone()).into() }').encode()
  suffix=b'.map(|point| point.try_coordinates().expect("represented surface fixture").clone())'
  edits.setdefault(path,{})[(start,end)]=converted
  edits[path][(last+1,last+1)]=suffix
for path,ops in edits.items():
 data=path.read_bytes()
 for (start,end),replacement in sorted(ops.items(),reverse=True): data=data[:start]+replacement+data[end:]
 path.write_bytes(data)
print({str(k):len(v)//2 for k,v in edits.items()})
(out/(sys.argv[1]+'.external-migration.json')).write_text(json.dumps({str(k):len(v)//2 for k,v in edits.items()},indent=2)+'\n')
