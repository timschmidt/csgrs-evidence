import copy, hashlib, json, shutil, subprocess, tarfile
from pathlib import Path
import run
O=run.OUT; R=run.ROOT
D=R/'crates/hyperbrep/docs/evidence/2026-10-19-surface-evaluation'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
tests=json.loads((O/'test-summary.json').read_text())['final-brep-release-tests-v2']
cost=json.loads((O/'cost-analysis.json').read_text()); art=json.loads((O/'archive-comparison.json').read_text()); sizes=json.loads((O/'binary-sizes.json').read_text())
ratios=[r['latency_ratio'] for r in cost['phase_medians']]
q=(f"All-feature release BRep/IO suites pass {tests['passed']} tests in {tests['batches']} batches, with no failures or ignored tests. "
   "The public boundary preserves represented values across all nine surface families and retains joint selected UVs on planes. Five shared public functions pass natively and through four actual zero-import Wasmtime exports: mixed polynomial fibers, independent plane/linear identities, exact near-coincidence, shears/reflections, translation/rotation edges, three cold archive replays, selected section pcurve images, finite/periodic domains, hostile selectors/frames, nested predecode limits and strict/approximate/strict plus zero-budget refusal/recovery. A source-lifetime unit test verifies owned surfaces are released without cycles. Affected all-target/all-feature BRep/IO Clippy and rustdoc with warnings denied, fuzz-target compilation and formatting pass. "
   f"All {art['preserved_files']} preserved archive payloads match after the declared version-11 migration; deterministic bytes and exact geometry are checked independently within each revision. Three new archive files reproduce one identical transformed sweep model. The complete interior-loop section success assertion still fails with UnsupportedIntersection on baseline and candidate and remains unchanged.")
p=(f"Three alternating CPU-0 pinned pairs for six complete preserved workflows and three absolute processes for four new workflows retain first and three repeated fresh-input invocations. Every invocation includes assertions, materialization, validation and replay. Twelve median latency ratios span {min(ratios):.6f} to {max(ratios):.6f}; {cost['increased_allocation_rows']} of 36 paired rows increase Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. All adverse samples remain. Maximum process RSS is {cost['maximum_rss_kib']} KiB; the matched executable changes by {sizes['candidate']['bytes']-sizes['baseline']['bytes']:+d} bytes. Shared-host timings establish no speedup. Requested Rust allocation traffic is not live heap and excludes foreign allocators. New successful selected plane images have no prior successful baseline. The represented-family and source-lifetime unit matrix has no separate allocation campaign. The archive translation record is boxed to avoid enlarging every raw curve record; no new cache is introduced. Per complete invocation, allocation calls rise by 5,632 for primitives (0.2144%), 4,126 for clipped_and_voids (0.0567%) and 1,378 for profile_families (0.1213%); the other three workflows keep their allocation counts. Requested bytes decrease in four workflows and stay unchanged in two. This measured tradeoff is retained for the new exact composition capability. See the complete per-case deltas in cost-analysis.json.")
limits=("Surface::point_at admits retained plane images and preserves all represented surface evaluators. Selected nonlinear surface images remain UnsupportedSelectedEvaluation after exact domain checks; joint rational tensor/procedural maps need source-bound owner authority. Point bounds inherit Hypercurve's existing representation limits, including the separate exterior affine-point issue. Selected whole-section restriction, whole polynomial-branch/event persistence, general sections/trim arrangements and the original complete interior-loop target remain open. Archive 11 deliberately rejects previous versions and changes translation origins; no compatibility decoder or API overload exists. Source consumers do not establish installed distribution or production binding readiness. Solver counters and archive quotas do not bound total work, live heap, stack or cancellation. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, full workflows and push gates remain unqualified. All 28 work packages remain open/in-progress. The consumed eaa0cae54 exception does not authorize publishing this increment.")
report={'increment':'surface-evaluation-2026-10-19','baseline':source['baseline'],'retained':True,'complete':False,'qualification':q,'cost_evidence':p,'limits':limits}
write(O/'report.json',report)
write(O/'ideas.json',[
 {'idea':'Retain a surface plus the whole joint UV point for selected plane images','status':'kept','reason':'Completes pcurve-to-plane and point/sweep/archive composition without reconstructing coordinate roots; independent linear identities and replay pass.'},
 {'idea':'Share planar affine-form query logic between curve and surface images','status':'kept','reason':'One Hypercurve proof owner; all preserved workflows and migrated archives pass; costs retained without a speedup claim.'},
 {'idea':'Inline generalized translation origin in RawCurve3','status':'rejected','reason':'Clippy found a 288-byte enum with an 80-byte second-largest variant. Box the translation definition like rotation; preserve the serialized definition and all assertions.'},
 {'idea':'Dummy source curve, independent UV roots, legacy overload or decoder','status':'rejected','reason':'Would discard joint source semantics or contradict the greenfield API/archive contract.'},
 {'idea':'General selected nonlinear surface maps','status':'open','reason':'Requires correlated rational/transcendental image authority in the source owner; return typed blockers and preserve the original full hard case.'}
])
(O/'next-domains.md').write_text('''# Continue toward complete surface sections

The public surface evaluator now consumes a joint retained UV point and returns a retained spatial point. Plane images keep the surface and original point directly, including through affine transforms, sweep origins and checked archive 11 replay. Coefficient algorithms share the unchanged private represented evaluator. Preserve all full hard cases and the earlier selected-pcurve/fiber evidence.

1. Extend Hypercurve/Hypersolve source-bound rational forms and image authority for arbitrary joint UV fields, excluding poles and retaining the base/selector relation. Consume them in HyperBRep tensor, extrusion and revolution surface images. Do not manufacture dummy curves, split a joint fiber into independent roots, or use samples as point authority. Angular images need their own certified representation. Existing plane support does not imply nonlinear support.
2. Retain selected intervals in complete SurfaceIntersectionCurve restrictions, spatial curves, both pcurves and boundary contacts. Preserve common source charts, events, orientation, domain boundaries, transforms and downstream materialization/replay. Represented subdivision currently rebases charts.
3. Persist whole polynomial branches/events with equation/domain/solver controls, slab/root selection, restrictions, transforms and graph incidence. Point-image persistence is not branch persistence. Admit metadata before decoding and replay cold without proof flags.
4. Implement the invertible-affine-projection height-patch section plan using the existing planar lift and both original charts. Join critical/singular events in one section graph; preserve complete loops, isolated points, disconnected and singular components, empty sets and exact further composition. Keep the original full biquadratic interior-loop success assertion unchanged.
5. Complete general patch pairs, regularity/tangents, vertical/common components, trim/material arrangements and downstream modeling. Repair the separate exterior affine-point bounds owner only as needed by real BRep consumers.
6. Preserve declared archive/API migrations and exact corpus assertions while checking costs. Resource/cancellation, runtime fuzz/ASan/lexicase, formal/coverage, installed release/MSRV/binding and complete workflow/push gates remain independent open work.

The prior [pcurve evaluation roadmap](../2026-10-19-pcurve-evaluation/next-domains.md) and [selected fiber roadmap](../2026-10-19-selected-fiber-images/next-domains.md) retain their original full inputs and adverse measurements.
''')
(O/'README.md').write_text('# Retained joint UV surface evaluation\n\n'+q+'\n\n'+p+'\n\n'+limits+'''

`contract.md` declares the pre-implementation domain and owners. `source-migration-audit.json` proves the represented surface evaluator body is byte-identical; public API and archive changes are deliberate migrations. `verification.json`, `test-summary.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate correctness, serialization and cost claims.

`raw-evidence.tar.gz` retains command logs, failure histories, source patches, native archives, standalone consumer manifests/locks/recipes and raw allocation/RSS samples. It excludes executables and caches. Every run is externally time-contained. Adjust the explicit local source/cache paths when reproducing. Baseline source is the frozen main checkout; candidate source is the development checkout. Do not run the snapshot runner after copying this evidence into the repository.

Earlier migration compilations failed on old callers and two new test expressions; direct callers were migrated without changing geometry assertions. Clippy rejected an oversized raw curve variant; boxing its translation definition fixed it. The first WASM run passed but exposed one unused shared support function in the standalone harness; the final harness executes that function too and rebuilds/reruns without warnings. Three cone regression archives required only the version-header migration; every geometry byte and assertion is preserved. The standalone interior-loop probe required the same public API migration before reaching its original success assertion. The separate fuzz format check also found pre-existing wrapping in the changed caller file; rustfmt and a fresh fuzz-bin check pass. No original hard-case assertion was weakened. Schema comparisons explicitly normalize only version 10→11 and the old translation source/parameter pair into the new generic origin. All other payloads must match exactly.
''')
# Status preserves historical increments and package statuses.
sp=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'; status=json.loads(sp.read_text()); before=copy.deepcopy(status)
status['increments'].append({'id':report['increment'],'work_packages':['WP02','WP05a','WP05b','WP06','WP13','WP21'],'properties':['P1','P4','P5','P6','P8','P9','P15','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],'change':'Retain joint plane UV images through surface evaluation, spatial point queries, affine transforms, sweep origins and checked archive 11 replay.','sources':['../src/geometry/surface_point.rs','../src/geometry/point.rs','../src/persistence/spatial_points.rs','../src/persistence/admission/shapes.rs','../tests/support/surface_evaluation.rs'],'evidence':'evidence/2026-10-19-surface-evaluation/manifest.json','validation':q,'cost_evidence':p,'limits':limits})
status['next_actions'].insert(0,'Continue WP05a/WP05b from evidence/2026-10-19-surface-evaluation/next-domains.md. Plane UV images now retain joint source evidence; nonlinear rational/tensor/procedural images, selected whole-section restrictions and complete branch/event replay remain required. Preserve the original interior-loop success assertion, all prior exact fixtures, archive migrations and adverse cost evidence.')
assert status['increments'][:-1]==before['increments'] and status['work_packages']==before['work_packages'] and not status['complete']
write(sp,status)
plan=R/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md';s=plan.read_text().replace("Updated 2026-10-19 for retained pcurve\nevaluation,", "Updated 2026-10-19 for retained surface\nevaluation,",1)
s=s.replace('General `Surface::point_at`\nUV images, whole-section selected restriction and branch/event persistence remain\nrequired next steps.', 'Selected nonlinear `Surface::point_at`\nimages, whole-section selected restriction and branch/event persistence remain\nrequired next steps.')
s=s.replace('[current next domains](evidence/2026-10-19-pcurve-evaluation/', '[associated next domains](evidence/2026-10-19-pcurve-evaluation/')
marker='Apply [research gates G2–G5]';assert marker in s
s=s.replace(marker,'''The [retained surface evaluation increment](evidence/2026-10-19-surface-evaluation/README.md)
now takes a joint Hypercurve UV point and returns `GeometricPoint3`. Plane images
retain their source surface and UV evidence directly; shared affine queries,
transforms, straight/rotational sweep origins and checked archive 11 replay
consume the result. Represented formulas remain in one private coefficient
evaluator. Nonlinear selected images fail typed after domain checks. Archive 11
uses a generic sweep origin and has no legacy decoder. Follow the
[current next domains](evidence/2026-10-19-surface-evaluation/next-domains.md)
for source-bound nonlinear maps, complete selected section restrictions and
branch/event persistence. Work-package and publication gates remain open.

'''+marker,1);plan.write_text(s)
matrix=R/'crates/hyperbrep/docs/SUPPORT_MATRIX.md';s=matrix.read_text().replace('Archive version 10','Archive version 11')
s=s.replace('The complete\nsection evaluator and surface UV evaluator remain separate open boundaries.', 'The complete\nsection evaluator and nonlinear selected surface images remain open boundaries.')
s=s.replace('`Surface::point_at` still needs retained joint-UV migration.', '`Surface::point_at` consumes joint UV points and retains plane images; nonlinear selected images remain typed blockers.')
marker='## Spatial curve carriers';assert marker in s
s=s.replace(marker,'''`Surface::point_at(&hypercurve::CurvePoint2)` returns `GeometricPoint3`.
Represented inputs preserve all nine surface evaluators. Selected plane images
retain the source surface and joint UV authority, with exact affine queries,
conservative source bounds, transforms, translation/rotation origins and archive
11 replay. Finite and lower-bounded domains are checked before representation
dispatch; periodic axes retain their unbounded real semantics. Selected nonlinear
images remain unsupported. Bounds retain the planar owner's representation
limits. See the [surface evidence](evidence/2026-10-19-surface-evaluation/README.md).

'''+marker,1);matrix.write_text(s)
architecture=R/'crates/hyperbrep/docs/ARCHITECTURE.md';s=architecture.read_text().replace('Archive version 10','Archive version 11')
s=s.replace('Builder incidence\nchecks compare retained curve images;', 'Builder incidence\nchecks compare retained images;')
s=s.replace('The XY and XZ curves and their selected images are prepared independently on\ndemand.', 'For native curve images, the XY and XZ projections and their selected points are\nprepared independently on demand.')
s=s.replace('General retained surface evaluation and full selected section restriction remain\nopen boundaries,', 'Selected nonlinear surface evaluation and full selected section restriction remain\nopen boundaries,')
marker='Retained pcurves may run in either source direction;';assert marker in s
s=s.replace(marker,'''`Surface::point_at(&hypercurve::CurvePoint2)` returns `GeometricPoint3`.
`geometry/surface_point.rs` validates retained UV domains; plane evaluation stores
the immutable surface and the joint UV point directly. Spatial affine-form
queries share the planar owner's proofs with curve images. Point transforms map
the source plane frame without changing the UV selector. The private represented
surface evaluator remains the common coefficient path. Endpoint image validation
consumes retained pcurve and surface points directly. Archive 11 persists surface
point definitions and generic translation/rotation origins through
`persistence/spatial_points.rs`; nested shape admission precedes scalar decoding.
See the [surface evaluation record](evidence/2026-10-19-surface-evaluation/README.md).
'''+marker,1);architecture.write_text(s)
archive=R/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md';s=archive.read_text().replace('# Selected geometry in archive version 10','# Selected geometry in archive version 11',1)
s=s.replace('Vertices are\n`Coordinates([Real; 3])` or `CurveImage { source, parameter }`.', 'Vertices are\n`Coordinates([Real; 3])`, `CurveImage { source, parameter }`, or\n`SurfaceImage { source, parameter }`. A surface image embeds the checked surface\ndefinition and one complete planar point definition; it does not store independent\nUV roots. Nested surface and point records consume admission quotas before scalar\ndecoding. Rebuilding the surface and evaluating the UV rechecks frame validity,\ndomain membership and the admitted image family.')
s=s.replace('`Translation { source, parameter, displacement }` retains a\nstraight unit-chart sweep of a point through a nonzero authored displacement.\nIts origin uses an inline spatial source and selected parameter, with recursive\nrecord admission.', '`Translation { origin, displacement }` retains a\nstraight unit-chart sweep of a point through a nonzero authored displacement.\nIts origin shares the rotation origin definition: `Coordinates`, `CurveImage`\nwith an inline curve and parameter, or `SurfaceImage` with a surface and joint\nUV point. Recursive record admission covers every embedded definition.')
s=s.replace('No new schema is\nintroduced;', 'That pcurve increment introduced no new schema;')
s+='''

Version 11 deliberately rejects version 10 and earlier. The old translation
`source`/`parameter` pair is replaced by a generic `origin`; there is no legacy
decoder. Plane images preserve joint polynomial-fiber and selected rational UV
evidence through point queries, affine transforms, sweeps and cold replay.
This is a point-image capability, not whole surface-intersection branch or
nonlinear surface-image persistence. Existing payloads are compared after only
the declared schema migration, alongside unchanged exact geometric assertions.
See the [surface archive evidence](evidence/2026-10-19-surface-evaluation/README.md).
''';archive.write_text(s)
# Change only the current_work.hyperbrep JSON value, preserving every outside byte.
lp=R/'docs/properties-status.json';text=lp.read_text();ledger=json.loads(text)
entry=ledger['current_work']['hyperbrep'];entry.update(latest_implementation=report['increment'],latest_feature_evidence='crates/hyperbrep/docs/evidence/2026-10-19-surface-evaluation/manifest.json',latest_evidence='crates/hyperbrep/docs/evidence/2026-10-19-surface-evaluation/manifest.json',qualification=q,performance_evidence=p,limits=limits,latest_update_check='crates/hyperbrep/docs/evidence/2026-10-19-surface-evaluation/upstream-check.json')
decoder=json.JSONDecoder()
def ws(s,p):
 while s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;lp.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()))
# Finish local checks before copying evidence. Never invoke run.run after this point.
checks=[]
for name,cmd in [('format',['cargo','fmt','--all','--','--check']),('fuzz-format',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check']),('diff',['git','diff','--check'])]:
 result=subprocess.run(cmd,cwd=R,env=run.ENV,capture_output=True,text=True)
 (O/('post-documentation-'+name+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(name,result.stderr)
 checks.append(dict(name=name,command=cmd,exit_code=result.returncode))
assert all(sha(R/p)==h for p,h in source['files'].items())
write(O/'post-documentation-checks.json',dict(checks=checks,qualified_source_unchanged=True))
D.mkdir()
for name in ['README.md','contract.md','next-domains.md','report.json','ideas.json','candidate-source.json','baseline-source.json','verification.json','test-summary.json','archive-comparison.json','cost-analysis.json','binary-sizes.json','environment.json','upstream-check.json','source-migration-audit.json','dependency-comparison.json','consumer-source-scope.json','auxiliary-source-scope.json','fixture-migration.json','source-patch.json','ledger-scope.json','post-documentation-checks.json']:
 shutil.copy(O/name,D/name)
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
 for path in sorted(O.rglob('*')):
  if not path.is_file() or path.is_symlink():continue
  if path.suffix in {'.json','.log','.patch','.py','.rs','.toml','.md'} or path.name=='Cargo.lock':
   tar.add(path,arcname=str(path.relative_to(O)),recursive=False)
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(D.iterdir()) if p.is_file()}
write(D/'manifest.json',dict(increment=report['increment'],baseline=source['baseline'],source_files=len(source['files']),complete=False,retained=True,no_push=True,files=files))
print(json.dumps({'evidence':str(D),'source_files':len(source['files']),'increment_count':len(status['increments']),'qualification':q,'cost_evidence':p},indent=2))
