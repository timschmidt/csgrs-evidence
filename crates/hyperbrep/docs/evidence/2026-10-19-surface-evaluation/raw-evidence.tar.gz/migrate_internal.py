import json,re,sys
from pathlib import Path
out=Path(__file__).parent
log=out/sys.argv[1]
edits={}
for l in log.read_text().splitlines():
 try:r=json.loads(l)
 except ValueError:continue
 if r.get('reason')!='compiler-message':continue
 m=r['message']
 if m['level']!='error':continue
 for span in m['spans']:
  if not span['is_primary'] or span['label']!='expected `&CurvePoint2`, found `&Point2`':continue
  path=Path(span['file_name'])
  if not str(path).startswith('crates/hyperbrep/src/'):continue
  data=path.read_bytes();start=span['byte_start']
  prefix=data[:start]
  pos=prefix.rfind(b'.point_at(')
  assert pos>=0 and not prefix[pos+len(b'.point_at('):].strip(),(path,start)
  edits.setdefault(path,set()).add(pos)
for path, positions in edits.items():
 data=path.read_bytes()
 for pos in sorted(positions,reverse=True):
  assert data[pos:pos+10]==b'.point_at('
  data=data[:pos]+b'.evaluate_real('+data[pos+10:]
 path.write_bytes(data)
print({str(k):len(v) for k,v in edits.items()})
(out/(sys.argv[1]+'.migration.json')).write_text(json.dumps({str(k):sorted(v) for k,v in edits.items()},indent=2)+'\n')
