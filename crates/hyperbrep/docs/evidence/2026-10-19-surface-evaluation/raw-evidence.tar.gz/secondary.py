import json,run
for job in json.loads((run.OUT/"qualification.json").read_text())[1:]:
    assert run.run(job)==0,job["label"]
