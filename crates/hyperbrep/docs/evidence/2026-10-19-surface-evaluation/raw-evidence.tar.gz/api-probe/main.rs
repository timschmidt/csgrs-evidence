use hyperbrep::{Surface,Point3,Vector3,GeometricPoint3};
fn main() {
    let source = hypercurve::Point2::from_values(2, 3).into();
    let plane = Surface::plane(Point3::origin(),Vector3::x(),Vector3::y()).unwrap();
    let point: GeometricPoint3 = plane.point_at(&source).unwrap();
    assert!(point.try_coordinates().is_some());
}
