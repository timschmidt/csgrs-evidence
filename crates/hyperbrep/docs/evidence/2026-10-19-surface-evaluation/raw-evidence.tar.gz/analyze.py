import hashlib,json,re,statistics,subprocess
from pathlib import Path
import run
O=run.OUT; R=run.ROOT; B=Path('/mnt/development/csgrs')
def write(name,value): (O/name).write_text(json.dumps(value,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/name)==digest for name,digest in source['files'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==source['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
rows=json.loads((O/'results.json').read_text()); checks={r['label']:r for r in rows}
required=[j['label'] for j in json.loads((O/'qualification.json').read_text())]+['final-affected-clippy-2','final-new-build','final-new-archives','final-candidate-build','final-candidate-archives','final-wasm-build-2','final-wasm-run-2','baseline-preserved-archives']
for label in required: assert checks[label]['exit_code']==0,(label,checks[label]['exit_code'])
for label in ['baseline-api-missing','baseline-original-interior-loop','final-original-interior-loop-2']: assert checks[label]['exit_code']==101,label
assert 'UnsupportedIntersection' in (O/'final-original-interior-loop-2.log').read_text()
for row in rows:
    assert sha(Path(row['log']))==row['log_sha256']
    assert sha(Path(row['source_patch']))==row['source_patch_sha256']
summary={}
for label in ['final-brep-release-tests-v2','focused-surface-evaluation']:
    counts=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/(label+'.log')).read_text())]
    assert counts,label
    summary[label]=dict(passed=sum(r[0] for r in counts),failed=sum(r[1] for r in counts),ignored=sum(r[2] for r in counts),batches=len(counts))
    assert summary[label]['failed']==0
write('test-summary.json',summary)
artifacts={}
for group in ['baseline','candidate','fibers-baseline','fibers-candidate','new']:
    artifacts[group]={str(p.relative_to(O/'artifacts'/group)):sha(p) for p in sorted((O/'artifacts'/group).glob('*.json'))}
def migrate(value):
    if isinstance(value,list): return [migrate(v) for v in value]
    if not isinstance(value,dict): return value
    value={k:migrate(v) for k,v in value.items()}
    if 'Translation' in value:
        v=value['Translation']
        assert set(v)=={'source','parameter','displacement'}
        value['Translation']={'origin':{'CurveImage':{'source':v['source'],'parameter':v['parameter']}},'displacement':v['displacement']}
    return value
comparisons=[]
for prefix in ['', 'fibers-']:
    assert artifacts[prefix+'baseline'] and artifacts[prefix+'baseline'].keys()==artifacts[prefix+'candidate'].keys()
    for name in artifacts[prefix+'baseline']:
        a=(O/'artifacts'/(prefix+'baseline')/name).read_text()
        b=(O/'artifacts'/(prefix+'candidate')/name).read_text()
        source_payload=json.loads(a); assert source_payload['version']==10; source_payload['version']=11
        assert migrate(source_payload)==json.loads(b),(prefix,name)
        comparisons.append(dict(group=prefix or 'models',name=name,baseline_sha256=hashlib.sha256(a.encode()).hexdigest(),candidate_sha256=hashlib.sha256(b.encode()).hexdigest(),identical_after_version_only=a.replace('"version":10','"version":11').replace('"version": 10','"version": 11')==b,exact_after_declared_migration=True))
assert len(comparisons)==230
assert len(artifacts['new'])==3
write('archive-comparison.json',dict(preserved_files=len(comparisons),new_files=3,new_unique_payloads=len(set(artifacts['new'].values())),identical_after_version_only=sum(r['identical_after_version_only'] for r in comparisons),comparisons=comparisons,files=artifacts,contract='Archive 11 migration: version plus generic translation origins. Full exact geometric assertions and cold replay remain in every recipe. Not byte-identical across versions.'))
raw=[];pairs=[];rss=[]
for repeat in range(3):
    per={}
    for side in ['baseline','candidate','new']:
        label=f'cost-{side}-{repeat}'
        assert checks[label]['exit_code']==0
        samples=[json.loads(line) for line in (O/(label+'.log')).read_text().splitlines() if line.startswith('{')]
        data=[r for r in samples if 'case' in r]
        assert len(data)==(8 if side=='new' else 12)
        per[side]={(r['case'],r['phase']):r for r in data}
        raw.append(dict(repeat=repeat,side=side,rows=samples))
        rss.append(json.loads((O/'costs'/(label+'.json')).read_text()))
    for key,a in per['baseline'].items():
        b=per['candidate'][key]
        assert a['iterations']==b['iterations'] and a['outcome']==b['outcome']
        pairs.append(dict(repeat=repeat,case=key[0],phase=key[1],ratio=b['elapsed_ns']/a['elapsed_ns'],allocation_call_delta=b['allocation_calls']-a['allocation_calls'],requested_byte_delta=b['requested_bytes']-a['requested_bytes'],iterations=a['iterations']))
medians=[]
for case,phase in sorted({(r['case'],r['phase']) for r in pairs}):
    values=[r for r in pairs if (r['case'],r['phase'])==(case,phase)]
    medians.append(dict(case=case,phase=phase,latency_ratio=statistics.median(r['ratio'] for r in values),allocation_call_deltas=[r['allocation_call_delta'] for r in values],requested_byte_deltas=[r['requested_byte_delta'] for r in values]))
write('cost-analysis.json',dict(scope='Three alternating CPU-0 pinned process pairs for six complete preserved recipes, plus three absolute processes for four new recipes. Every invocation keeps assertions, materialization, validation and replay. First and three repeated fresh inputs are distinct phases; they are not a cache-eviction campaign.',raw_samples=raw,pairs=pairs,phase_medians=medians,maximum_rss_kib=max(r['maximum_rss_kib'] for r in rss),increased_allocation_rows=sum(r['allocation_call_delta']>0 for r in pairs),increased_byte_rows=sum(r['requested_byte_delta']>0 for r in pairs),limits='Rust requested allocation traffic excludes foreign allocators and is not live heap. Shared-host timings do not establish a speedup. New successful contracts have no prior successful timing baseline. The all-family represented evaluator and source-ownership unit tests have native correctness coverage but no separate allocation campaign.'))
binaries={side:dict(bytes=(O/'bin'/side).stat().st_size,sha256=sha(O/'bin'/side)) for side in ['baseline','candidate','new']}
w=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_surface_evaluation_consumer.wasm')
binaries['wasm']=dict(bytes=w.stat().st_size,sha256=sha(w))
write('binary-sizes.json',binaries)
write('verification.json',dict(required_checks=required,source_hashes_match=True,baseline_clean=True,baseline_revision=source['baseline'],raw_logs_and_patches_match=True,preserved_artifacts_match_after_declared_migration=True,no_push=True))
verification=json.loads((O/'verification.json').read_text())
verification['source_scope']='Native/WASM consumers, full release and workspace Clippy use the same 42 frozen source files. One separate fuzz-manifest caller is migrated later and covered by final fuzz compilation/formatting. Earlier focused tests precede boxed translation layout and added hostile controls; full tests cover both.'
verification['fixture_migration']=json.loads((O/'fixture-migration.json').read_text())
verification['auxiliary_source_scope']=json.loads((O/'auxiliary-source-scope.json').read_text())
verification['upstream_observation']=json.loads((O/'upstream-check.json').read_text())
write('verification.json',verification)
print(json.dumps(dict(tests=summary,artifacts=len(comparisons),median_ratio_range=[min(r['latency_ratio'] for r in medians),max(r['latency_ratio'] for r in medians)],binaries=binaries),indent=2))
