include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn joint_plane_images() -> u32 { cases()[0].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn domains_and_admission() -> u32 { cases()[1].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn policy_recovery() -> u32 { cases()[2].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn pcurve_surface_images() -> u32 { cases()[3].1(); 1 }
