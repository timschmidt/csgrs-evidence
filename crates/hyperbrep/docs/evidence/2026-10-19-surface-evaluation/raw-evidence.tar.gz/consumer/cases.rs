#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/surface_evaluation.rs"]
mod acceptance;
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/pcurve_evaluation.rs"]
mod pcurves;
fn cases() -> [(&'static str,fn());4] { [
("joint_plane_images", acceptance::joint_plane_images_compose_and_replay),
("domains_and_admission", acceptance::selected_domains_and_archive_admission),
("policy_recovery", acceptance::selected_surface_policy_and_recovery),
("pcurve_surface_images", pcurve_pipeline),
] }

fn pcurve_pipeline() { pcurves::selected_section_pcurves_preserve_images_and_replay(); pcurves::selected_evaluation_policy_budget_and_recovery(); }
