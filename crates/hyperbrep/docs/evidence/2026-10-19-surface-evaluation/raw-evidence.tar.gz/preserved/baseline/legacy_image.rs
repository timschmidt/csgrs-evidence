use hypersolve::*;
fn p(rows: &[&[i64]]) -> BivariatePolynomial { BivariatePolynomial::new(rows.iter().map(|r| r.iter().copied().map(Into::into).collect()).collect()) }
pub fn legacy_local_global_images() {
    let mut root=AlgebraicRootRepresentation { constraint_index:0, symbol:SymbolId(0), interval_index:0,
        polynomial_coefficients:vec![(-2).into(),0.into(),1.into()], interval:IsolatedRootInterval {lower:1.into(),upper:2.into(),exact_root:None,distinct_root_count:1},
        validation:AlgebraicRootValidationReport{status:AlgebraicRootValidationStatus::Valid,message:None}};
    root.validation=validate_algebraic_root_representation(&root,PredicatePolicy::STRICT);
    assert!(root.is_valid());
    let f=p(&[&[0,0,0,1], &[-1]]);
    // y^3=alpha, z=y^3+y=alpha+y. Squaring the independent local
    // identity z^3+6z=3alpha(z^2+1) gives z^6-6z^4-18=0.
    let g=p(&[&[0,1], &[-1], &[], &[-1]]);
    for local in [false,true] {
        let project = if local { project_algebraic_fiber_polynomial_image_relation } else { project_algebraic_fiber_polynomial_image };
        let r=project(&f,CurveResultantParameter::First,&g,CurveResultantParameter::Second,&root,
            AlgebraicFiberPolynomialImageProjectionConfig{max_fiber_degree:3,max_retained_degree:2,max_image_degree_bound:3},PredicatePolicy::STRICT);
        assert_eq!(r.status,AlgebraicFiberPolynomialImageProjectionStatus::Constructed);
        assert_eq!(r.certainty,hyperlimit::Certainty::Exact);
        assert!(r.identically_zero_fiber_factor.is_none());
        let relation=r.retained_relation.unwrap();
        let expected=p(&[&[0,6,0,1], &[-3,0,-3]]);
        for i in 0..relation.coefficients.len().max(expected.coefficients.len()) {
            for j in 0..4 {
                let a=relation.coefficients.get(i).and_then(|r|r.get(j)).cloned().unwrap_or_else(|| 0.into());
                let b=expected.coefficients.get(i).and_then(|r|r.get(j)).cloned().unwrap_or_else(|| 0.into());
                assert!((a-b).exact_rational_normal_form().unwrap().is_zero());
            }
        }
        if local { assert!(r.coefficients.is_empty()); } else {
            assert_eq!(r.coefficients.len(),7);
            let expected=p(&[&[-18,0,0,0,-6,0,1]]);
            for (actual,expected) in r.coefficients.iter().zip(&expected.coefficients[0]) {
                assert!((actual-expected).exact_rational_normal_form().unwrap().is_zero());
            }
        }
    }
}
