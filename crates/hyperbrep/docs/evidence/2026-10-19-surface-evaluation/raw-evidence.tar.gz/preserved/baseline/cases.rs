#[allow(dead_code)]
#[path = "similarity.rs"]
mod acceptance;
fn cases() -> [(&'static str,fn());6] { [
("primitives",acceptance::primitives),
("clipped_and_voids",acceptance::clipped_and_voids),
("profile_families",acceptance::profile_families),
("polynomial_branches", polynomial_preserved),
("legacy_local_global_images", legacy::legacy_local_global_images),
("selected_fiber_replay", fibers::mixed_fiber_charts_survive_brep_archives_and_transforms),
] }

#[allow(dead_code)]
#[path = "/mnt/development/csgrs/crates/hypercurve/tests/support/polynomial_curves.rs"]
mod branches;
fn polynomial_preserved() { branches::closed_loop_evaluation_split_reverse_and_source_identity(); branches::algebraic_slice_keeps_correlated_noncircular_fiber(); branches::similarity_and_point_replay_keep_source_chart(); branches::algebraic_events_and_tiny_loops_preserve_selected_endpoints(); }

#[path = "legacy_image.rs"]
mod legacy;

#[allow(dead_code)]
#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/selected_fiber_images.rs"]
mod fibers;
