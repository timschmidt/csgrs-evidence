import run,shutil
from pathlib import Path
assert run.run({'label':'baseline-api-missing','command':['cargo','check','--offline','--manifest-path',str(run.OUT/'api-probe/Cargo.toml')],'seconds':1800})==101
assert run.run({'label':'baseline-preserved-build','command':['cargo','build','--offline','--release','--manifest-path',str(run.OUT/'preserved/baseline/Cargo.toml'),'--bin','hyperbrep-surface-preserved-baseline'],'seconds':3600})==0
shutil.copy(Path('/tmp/hyperbrep-review-target/release/hyperbrep-surface-preserved-baseline'),run.OUT/'bin/baseline')
assert run.run({'label':'baseline-preserved-archives','command':[str(run.OUT/'bin/baseline'),'all'],'env':{'HYPERBREP_BRANCH_ARTIFACTS':str(run.OUT/'artifacts/baseline'),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(run.OUT/'artifacts/fibers-baseline')},'seconds':1800})==0
assert run.run({'label':'baseline-original-interior-loop','command':['cargo','run','--offline','--release','--manifest-path',str(run.OUT/'original-brep-probe/Cargo.toml')],'seconds':1800})==101
