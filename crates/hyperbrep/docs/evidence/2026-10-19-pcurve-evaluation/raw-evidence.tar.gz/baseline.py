import run, shutil
from pathlib import Path
assert run.run({'label':'baseline-preserved-build','command':['cargo','build','--offline','--release','--manifest-path',str(run.OUT/'preserved/baseline/Cargo.toml'),'--bin','hyperbrep-evaluation-preserved-baseline'],'source_scope':'clean main 1c792919a','seconds':3600})==0
shutil.copy(Path('/tmp/hyperbrep-review-target/release/hyperbrep-evaluation-preserved-baseline'),run.OUT/'bin/baseline')
assert run.run({'label':'baseline-preserved-archives','command':[str(run.OUT/'bin/baseline'),'all'],'env':{'HYPERBREP_BRANCH_ARTIFACTS':str(run.OUT/'artifacts/baseline'),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(run.OUT/'artifacts/fibers-baseline')},'source_scope':'clean main 1c792919a','seconds':1800})==0
assert run.run({'label':'baseline-original-interior-loop','command':['cargo','run','--offline','--release','--manifest-path',str(run.OUT/'original-brep-probe/Cargo.toml')],'seconds':1800})==101
