include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn composition() -> u32 { cases()[0].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn failure_recovery() -> u32 { cases()[1].1(); 1 }
