#[allow(dead_code)]
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/pcurve_evaluation.rs"]
mod acceptance;
fn cases() -> [(&'static str,fn());2] { [
("selected_section_pcurves_preserve_images_and_replay", acceptance::selected_section_pcurves_preserve_images_and_replay),
("selected_evaluation_policy_budget_and_recovery", acceptance::selected_evaluation_policy_budget_and_recovery),
] }
