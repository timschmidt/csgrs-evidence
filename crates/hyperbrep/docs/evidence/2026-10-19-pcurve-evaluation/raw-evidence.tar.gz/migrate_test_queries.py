from pathlib import Path
import re
import run
R=run.ROOT
files=['geometry.rs','geometry/axial_lines.rs','geometry/periodic_charts.rs','boolean_kernel.rs','boolean_kernel/seam_tests.rs']
for file in files:
 p=R/'crates/hyperbrep/src'/file;s=p.read_text()
 if file.endswith('seam_tests.rs'):a=0
 else:a=s.index('#[cfg(test)]\nmod tests')
 part=s[a:];changes=[]
 pattern=r'(?:first_pcurve\(\)|second_pcurve\(\)|pcurve\([^()]*\)|\bpcurve)\s*\.point_at\('
 for m in re.finditer(pattern,part):
  end=m.end();depth=1
  while depth:
   if part[end]=='(':depth+=1
   elif part[end]==')':depth-=1
   end+=1
  if not re.match(r'\s*\.unwrap\(\)',part[end:]):continue
  arg=part[m.end():end-1]
  # Existing fixtures explicitly assert that their coordinate view remains available.
  replacement='&Real::clone('+arg+').into()).map(crate::geometry::represented_test_surface_parameter)'
  changes.append((m.end(),end,replacement))
 for aa,bb,v in reversed(changes):part=part[:aa]+v+part[bb:]
 p.write_text(s[:a]+part)
 print(file,len(changes))
p=R/'crates/hyperbrep/src/geometry.rs';s=p.read_text();a=s.index('#[cfg(test)]\nmod tests')
s=s[:a]+'''/// Existing coordinate fixtures must keep their represented view after migration.
#[cfg(test)]
pub(crate) fn represented_test_surface_parameter(point: hypercurve::CurvePoint2) -> Point2 {
    let coordinates = point.coordinates().expect("represented pcurve fixture");
    Point2::new(coordinates.x().clone(), coordinates.y().clone())
}

'''+s[a:];p.write_text(s)
