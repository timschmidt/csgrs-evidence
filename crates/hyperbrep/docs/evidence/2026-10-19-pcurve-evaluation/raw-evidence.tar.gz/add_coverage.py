from pathlib import Path
import run
R=run.ROOT
p=R/'crates/hyperbrep/src/geometry/selected_pcurves.rs';s=p.read_text();s+='''

#[test]
fn selected_linear_sections_use_all_native_spans_and_axis_charts() {
    // Two unequal knot spans represent (t+2,0,0), t in [-2,7].
    let profile = Curve3::nurbs(1, [0,5,9].map(|x|Point3::new(x.into(),0.into(),0.into())).to_vec(),vec![Real::one();3],vec![(-2).into(),(-2).into(),3.into(),7.into(),7.into()]).unwrap();
    let plane = PlaneSurface {origin:Point3::origin(),u:Vector3::from_xyz(1.into(),0.into(),1.into()),v:Vector3::y()};
    for axis in [TensorAxis::U,TensorAxis::V] {
        // denominator -1 gives -x; the retained scale -2 and offset 5 give 2t+9.
        let mapping = SurfaceIntersectionPcurve::linear_plane_section(profile.clone(),&plane,(-1).into(),axis,(-2).into(),5.into());
        for shift in [0,4] {
            let source = selected().affine_image(&Real::one(),&Real::from(shift)).unwrap();
            let expected = match axis {
                TensorAxis::U => source.affine_point(1.into(),0.into(),2.into(),9.into()).unwrap(),
                TensorAxis::V => source.affine_point(2.into(),9.into(),1.into(),0.into()).unwrap(),
            };
            for reverse in [false,true] {
                let (current,parameter) = if reverse {(mapping.reversed().unwrap(),source.affine_image(&(-1).into(),&5.into()).unwrap())} else {(mapping.clone(),source.clone())};
                let parameter = Parameter::from_curve(&parameter).unwrap();
                assert!(current.point_at(&parameter).unwrap().coincides_with(&expected).unwrap());
                assert!(current.subcurve(current.domain().start(),&parameter).unwrap().point_at(&parameter).unwrap().coincides_with(&expected).unwrap());
            }
        }
    }
}

#[test]
fn face_classification_consumes_retained_pcurve_images() {
    let vertices = [(0,0),(1,0),(1,1),(0,1)];
    let boundary = hypercurve::CurvePath2::try_new((0..4).map(|i| {
        let (x,y)=vertices[i];let (a,b)=vertices[(i+1)%4];
        Curve2::from(LineSeg2::try_new(CurvePoint2::from_values(x,y),CurvePoint2::from_values(a,b)).unwrap())
    }).collect()).unwrap();
    let (model,face) = crate::construction::planar_face(&boundary,&[],Point3::origin(),Vector3::x(),Vector3::y()).unwrap();
    let parameter = Parameter::from_curve(&selected()).unwrap();
    for (constant,expected) in [(q(1,2),hypercurve::ContourPointLocation::Inside),(Real::zero(),hypercurve::ContourPointLocation::Boundary),(Real::from(2),hypercurve::ContourPointLocation::Outside)] {
        let mapping = SurfaceIntersectionPcurve::tensor_iso_v(ParameterRange::unit(),constant);
        let point = mapping.point_at(&parameter).unwrap();
        assert!(point.coordinates().is_none());
        assert_eq!(model.classify_surface_parameter_on_face(face,&point).unwrap(),Classification::Decided(expected));
    }
}
''';p.write_text(s)
p=R/'crates/hyperbrep/tests/support/pcurve_evaluation.rs';s=p.read_text();s=s.replace('for trace in [','for (index, trace) in [',1).replace('original.subcurve(&q(1, 4), &q(7, 8)).unwrap(),\n        ] {','original.subcurve(&q(1, 4), &q(7, 8)).unwrap(),\n        ].into_iter().enumerate() {',1)
old='''            let json = builder.finish().unwrap().to_json().unwrap();''';assert old in s;s=s.replace(old,old+'''
            #[cfg(not(target_arch = "wasm32"))]
            if let Ok(directory) = std::env::var("HYPERBREP_PCURVE_EVALUATION_ARTIFACT_DIR") {
                let directory = std::path::PathBuf::from(directory);
                std::fs::create_dir_all(&directory).unwrap();
                std::fs::write(directory.join(format!("section-{nurbs}-{index}.json")), &json).unwrap();
            }
            #[cfg(target_arch = "wasm32")]
            let _ = index;
''',1);p.write_text(s)
