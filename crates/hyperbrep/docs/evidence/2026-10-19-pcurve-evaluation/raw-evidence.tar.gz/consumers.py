import json, shutil, subprocess
from pathlib import Path
import run
out=run.OUT
for side, package, manifest in [
    ('new','hyperbrep-pcurve-evaluation-consumer',out/'consumer/Cargo.toml'),
    ('candidate','hyperbrep-evaluation-preserved-candidate',out/'preserved/candidate/Cargo.toml')]:
    assert run.run({'label':'final-'+side+'-build','command':['cargo','build','--offline','--release','--manifest-path',str(manifest),'--bin',package],'seconds':3600})==0
    shutil.copy(Path('/tmp/hyperbrep-review-target/release')/package,out/'bin'/side)
    env=({'HYPERBREP_PCURVE_EVALUATION_ARTIFACT_DIR':str(out/'artifacts/new')} if side=='new' else
         {'HYPERBREP_BRANCH_ARTIFACTS':str(out/'artifacts/candidate'),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(out/'artifacts/fibers-candidate')})
    assert run.run({'label':'final-'+side+'-archives','command':[str(out/'bin'/side),'all'],'env':env,'seconds':1800})==0
assert run.run({'label':'final-original-interior-loop','command':['cargo','run','--offline','--release','--manifest-path',str(out/'original-brep-probe/Cargo.toml')],'seconds':1800})==101
