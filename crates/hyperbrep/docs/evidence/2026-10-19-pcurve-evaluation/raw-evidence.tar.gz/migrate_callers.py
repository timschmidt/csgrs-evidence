from pathlib import Path
import re
import run
R=run.ROOT
# These consumers perform coordinate arithmetic, so request a stored view explicitly.
for file in ['crates/hyperbrep/src/boolean_kernel.rs','crates/hyperbrep/src/boolean_kernel/periodic.rs']:
 p=R/file;s=p.read_text();start=0
 if file.endswith('boolean_kernel.rs'):
  a=s.index('fn iso_v_constants(');b=s.index('\nfn add_opposite_planar_edge_supports',a)
 else:a=0;b=len(s)
 part=s[a:b]
 # Every point_at in these finite iso-chart routines is a retained pcurve query.
 pattern=r'\.point_at\('
 changes=[]
 for m in re.finditer(pattern,part):
  end=m.end();depth=1
  while depth:
   if part[end]=='(':depth+=1
   elif part[end]==')':depth-=1
   end+=1
  if part[end:end+1]!='?':continue
  arg=part[m.end():end-1]
  arg=arg.replace('represented_start()?','start()').replace('represented_end()?','end()')
  if arg in ['start','end']:arg='&Real::clone('+arg+').into()'
  replacement='.point_at('+arg+')?.coordinates().cloned().ok_or(GeometryError::UnrepresentablePoint)?'
  changes.append((m.start(),end+1,replacement))
 for a1,b1,v in reversed(changes):part=part[:a1]+v+part[b1:]
 # Hypercurve's represented Point2 deliberately exposes borrowed coordinates.
 for name in ['first_start','first_end','second_start','second_end','start','end','a','b']:
  for axis in ['x','y']:
   part=part.replace('&'+name+'.'+axis,name+'.'+axis+'()')
   part=re.sub(r'\b'+name+r'\.'+axis+r'\b(?!\()',name+'.'+axis+'().clone()',part)
 p.write_text(s[:a]+part+s[b:])
p=R/'crates/hyperbrep/src/boolean_kernel.rs';s=p.read_text()
s=s.replace('let parameter = fragment.first_pcurve().point_at(&midpoint)?;\n        let parameter = hypercurve::Point2::new(parameter.x, parameter.y);','let parameter = fragment.first_pcurve().point_at(&midpoint.into())?;')
p.write_text(s)
p=R/'crates/hyperbrep/src/topology/edit/partition.rs';s=p.read_text().replace('let parameter = segment.pcurve(operand).point_at(&midpoint)?;\n                        let witness = CurvePoint2::new(parameter.x, parameter.y);','let witness = segment.pcurve(operand).point_at(&midpoint.into())?;');p.write_text(s)
p=R/'crates/hyperbrep/src/topology/query.rs';s=p.read_text();a=s.index('    pub(crate) fn classify_surface_parameter_on_face(');b=s.index('\n    }',a)+6
part=s[a:b].replace('point: &CurvePoint2,','point: &hypercurve::CurvePoint2,').replace('&point.clone().into()','point');s=s[:a]+part+s[b:]
s=s.replace('self.classify_surface_parameter_on_face(face, &point)','self.classify_surface_parameter_on_face(face, &point.into())')
p.write_text(s)
p=R/'crates/hyperbrep/src/boolean_kernel.rs';s=p.read_text().replace('model.classify_surface_parameter_on_face(face, &candidate)?','model.classify_surface_parameter_on_face(face, &candidate.into())?');p.write_text(s)
