from pathlib import Path
import re,json
import run
R=run.ROOT
assert {r['label']:r for r in json.loads((run.OUT/'results.json').read_text())}['baseline-selected-evaluation-api']['exit_code']==101
p=R/'crates/hyperbrep/src/geometry.rs';text=p.read_text()
a=text.index('impl SurfaceIntersectionPcurve {');b=text.index('fn orient_affine_surface_pcurve(',a)
block=text[a:b];text=text[:a]+text[b:]
text=text.replace('mod periodic_charts;','mod periodic_charts;\nmod pcurve;',1)
for name in ['unsupported','retained_curve','plane_projection','linear_plane_section','tensor_iso_v','tensor_iso','reparameterized_subcurve']:
    block=block.replace('    fn '+name+'(', '    pub(super) fn '+name+'(')
a=block.index('    /// Evaluates the exact surface parameter');b=block.index('    /// Restricts this exact surface-parameter mapping',a)
block=block[:a]+'''    /// Evaluates the retained UV image at one spatial-curve parameter.
    ///
    /// Selected parameters and point images keep their source evidence. A
    /// stored coordinate view is optional, not a prerequisite for evaluation.
    /// Membership is checked before applying the source map. Native rational
    /// projections and section spans retain their charts; planar procedural
    /// projections require an admitted similarity of their source chart.
    pub fn point_at(&self, parameter: &Parameter) -> GeometryResult<hypercurve::CurvePoint2> {
        crate::context::strict(|| {
            if !self.domain.contains(parameter)? {
                return Err(GeometryError::ParameterOutsideDomain);
            }
            let source = parameter.affine_image(&self.source_scale, &self.source_offset)?;
            match &self.mapping {
                SurfaceIntersectionPcurveMapping::Unsupported => {
                    Err(GeometryError::UnsupportedIntersection)
                }
                SurfaceIntersectionPcurveMapping::RetainedCurve { curve } => {
                    Ok(curve.point_at(&source.curve_parameter())?)
                }
                SurfaceIntersectionPcurveMapping::PlaneProjection { spatial, origin, u, v } => {
                    let point = spatial.point_at(&source)?;
                    if let Some(point) = point.try_coordinates() {
                        let uv = project_point_to_plane_frame(origin, u, v, point)?;
                        return Ok(CurvePoint2::new(uv.x, uv.y).into());
                    }
                    if let CurveGeometry3::PlanarImage(image) = &spatial.data.geometry {
                        let projected = image.materialize_plane_projection(origin, u, v)?;
                        let local = source.affine_image(&image.source_scale, &image.source_offset)?;
                        return Ok(projected.curve.point_at(&local.curve_parameter())?);
                    }
                    let projected = project_curve_to_plane_frame(spatial, origin, u, v)?
                        .ok_or(GeometryError::UnsupportedSelectedEvaluation)?;
                    Ok(projected.point_at(&source.curve_parameter())?)
                }
                SurfaceIntersectionPcurveMapping::LinearPlaneSection {
                    profile, plane_origin, plane_normal, denominator, profile_axis,
                    coefficient_scale, coefficient_offset,
                } => {
                    if let Some(parameter) = source.try_real() {
                        let profile_point = profile.evaluate_real(parameter)?;
                        let normalized = (plane_normal.dot(&(plane_origin - &profile_point)) / denominator)
                            .map_err(GeometryError::Numeric)?;
                        let coefficient = coefficient_offset + coefficient_scale * normalized;
                        return Ok(section_parameter_point(parameter.clone(), coefficient, *profile_axis).into());
                    }
                    let carriers = linear_section_pcurve_carriers(profile, plane_origin, plane_normal,
                        denominator, *profile_axis, coefficient_scale, coefficient_offset)?
                        .ok_or(GeometryError::UnsupportedSelectedEvaluation)?;
                    for carrier in carriers {
                        let (scale, offset) = carrier.correspondence.affine_coefficients()
                            .ok_or(GeometryError::UnsupportedPcurveContour)?;
                        let inverse = (Real::one() / scale).map_err(GeometryError::Numeric)?;
                        let local = source.affine_image(&inverse, &(-offset * &inverse))?.curve_parameter();
                        let domain = carrier.curve.parameter_domain();
                        if local.compare(domain.start())? != Ordering::Less
                            && local.compare(domain.end())? != Ordering::Greater {
                            return Ok(carrier.curve.point_at(&local)?);
                        }
                    }
                    Err(GeometryError::ParameterOutsideDomain)
                }
                SurfaceIntersectionPcurveMapping::TensorIsoV { constant } => {
                    Ok(source.curve_parameter().affine_point(Real::one(), Real::zero(), Real::zero(), constant.clone())?)
                }
                SurfaceIntersectionPcurveMapping::TensorIsoU { constant } => {
                    Ok(source.curve_parameter().affine_point(Real::zero(), constant.clone(), Real::one(), Real::zero())?)
                }
            }
        })
    }

'''+block[b:]
(R/'crates/hyperbrep/src/geometry/pcurve.rs').write_text('//! Retained surface-parameter images and their exact spatial correspondence.\n\nuse super::*;\n\n'+block)
p.write_text(text)
