import copy,gzip,hashlib,json,subprocess,tarfile,shutil
from pathlib import Path
import run
O=run.OUT;R=run.ROOT
D=R/'crates/hyperbrep/docs/evidence/2026-10-19-pcurve-evaluation'
def write(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
src=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in src['files'].items())
tests=json.loads((O/'test-summary.json').read_text());cost=json.loads((O/'cost-analysis.json').read_text());art=json.loads((O/'archive-comparison.json').read_text());sizes=json.loads((O/'binary-sizes.json').read_text())
q=(f"All-feature release BRep/IO suites pass {tests['final-brep-release-tests-v2']['passed']} tests in {tests['final-brep-release-tests-v2']['batches']} batches, with no failures or ignored tests. Nine internal groups cover retained/iso images, planar lifts, angular blockers, both axes and unequal exterior NURBS knot spans, reversal/restriction and retained face classification. Two shared public groups pass natively and in actual zero-import Wasmtime: independently derived selected UV images on cubic extrusion/plane sections, rational Bezier and NURBS sources, reversal, restriction, three cold archive replays, translation/replay, strict/approximate/strict certainty and refusal/recovery after a zero solver-work allowance. Affected all-target/all-feature BRep/IO Clippy and rustdoc with warnings denied, BRep fuzz-target compilation and formatting pass. Six preserved complete workflows emit {art['identical_preserved_files']} byte-identical archives; six new image models replay. The original complete biquadratic interior-loop section success assertion still fails with UnsupportedIntersection on baseline and candidate. It remains an open target.")
ratios=[x['latency_ratio'] for x in cost['phase_medians']]
p=(f"Nine CPU-0 pinned processes retain three alternating baseline/candidate pairs for six completed preserved workflows and three absolute processes for two new workflows. First and three repeated fresh-input invocations include assertions, materialization, validation and replay. Twelve median latency ratios span {min(ratios):.6f} to {max(ratios):.6f}; {cost['increased_allocation_rows']} of 36 matched rows increase Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. All adverse rows and raw samples remain. Maximum process RSS is {cost['maximum_rss_kib']} KiB; the matched executable changes by {sizes['candidate']['bytes']-sizes['baseline']['bytes']:+d} bytes. No new stored fields or cache are introduced. Requested Rust allocation traffic is not live heap and excludes foreign allocators. Shared-host timings establish no speedup; newly successful selected evaluation has no successful baseline. The broader private mapping matrix has native correctness coverage without a separate allocation campaign.")
p += " All six allocation/byte increases belong to clipped_and_voids: +17,408 allocation calls and +1,271,040 requested bytes per complete invocation (about 0.24% and 0.25% of the baseline). The other five preserved workflows retain their counts. This measured cost is retained for the new exact composition capability, not presented as an optimization."
limits=("The admitted evaluation domain retains existing represented paths and adds native selected retained/iso, rational plane-projection and linear-section images, plus planar lifts whose projected source chart admits a similarity. Selected angular images and general procedural non-similarity projection remain typed blockers. Generic exterior affine-point bounds remain a separate owner limitation. Surface::point_at still requires represented UV coordinates. General joint UV surface images, selected whole-section restriction, whole polynomial-branch/event replay, general sections/face arrangements and the full interior-loop target remain open. Selected linear-section queries construct the existing rational span carriers per query; no general cost bound or new cache is claimed. Solver counters, degree and archive limits do not bound total work, live heap, stack or cancellation. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, production bindings and full workflow/push gates remain unqualified. Source consumers are not released packages. All 28 work packages remain open/in-progress. The consumed eaa0cae54 exception does not authorize publishing this increment.")
report=dict(date='2026-10-19',base_revision=src['base'],increment='pcurve-evaluation-2026-10-19',qualification=q,cost_evidence=p,limits=limits)
write(O/'report.json',report)
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*src['files']],cwd=R)
for name in src['files']:
 if subprocess.run(['git','ls-files','--error-unmatch',name],cwd=R,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
  added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=R,capture_output=True);assert added.returncode==1;patch+=added.stdout
(O/'qualified-source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
write(O/'source-patch.json',dict(base=src['base'],sha256=hashlib.sha256(patch).hexdigest(),files=list(src['files'])))
write(O/'ideas.json',[
 dict(idea='Retained Parameter to CurvePoint2 evaluation in the pcurve owner',status='kept',evidence='The baseline public consumer cannot compile; the same selected input and exact image/archive assertions now pass. No legacy overload exists.'),
 dict(idea='Reconstruct independent UV roots or substitute coordinates from enclosures',status='architecture-inapplicable',evidence='Existing point/parameter authorities preserve source identity. The new path directly feeds exact queries, native point archives and face classification.'),
 dict(idea='Reuse exact rational section span carriers and their affine correspondence',status='kept',evidence='Both axes and unequal non-unit knot spans retain exact selected maps, restrictions and reversal. The cubic public fixtures derive UV expectations independently.'),
 dict(idea='Use current represented evaluation paths and demand represented views only at remaining coordinate consumers',status='kept',evidence='Existing assertions still demand their coordinate views; all BRep/IO tests and deterministic preserved artifacts are retained. Test-only coordinate extraction is an assertion on existing fixtures, not a public compatibility layer.'),
 dict(idea='General affine procedural point projection through the current similarity transform',status='rejected',evidence='A similarity certificate does not admit arbitrary affine transforms. General joint-source images remain an explicit owner extension instead of a false admission.'),
 dict(idea='Retain the extension with its measured supported-workflow cost',status='kept',evidence='All 230 preserved archives and semantic assertions remain. clipped_and_voids adds 17,408 allocation calls and 1,271,040 requested bytes per invocation, about 0.24% and 0.25%; the other five preserved recipes retain their counts. Completeness advances while the adverse timing/allocation rows remain explicit. No speedup is claimed.'),
 dict(idea='Add another projection or section-span cache now',status='rejected',evidence='No cache is needed to establish the finite composition contract. Measured cost records are retained; any future preparation/cache needs a separate lifetime/resource/certainty contract.'),
 dict(idea='Existing angular seam identities and native selected scalar affine transport',status='already-satisfied',evidence='Reused without new scalar/predicate machinery. The internal matrix preserves represented seams and typed selected angular failure.'),
])
(O/'next-domains.md').write_text('''# Continue toward complete surface sections

The pcurve evaluation boundary now takes retained parameters and returns retained UV points. Existing coordinate consumers request views explicitly; face classification directly consumes retained points. Preserve the original full interior-loop input and success assertion while implementing the remaining boundaries.

1. Migrate `Surface::point_at` to joint retained `hypercurve::CurvePoint2` UV input and `GeometricPoint3` output. The spatial point owner should retain the source/frame or surface image directly. Do not manufacture a dummy curve to host a point, reconstruct independent UV roots, or add a legacy overload. Plane queries can pull affine forms back through the frame; tensor queries need correlated rational maps. Preserve represented fast paths, exact domain/periodic semantics, certainty, transforms and checked archive replay.
2. Extend the curve/solver owner's source-bound rational-form/image authority for arbitrary joint UV fields and non-similarity procedural projections. Native rational control images already cover their finite family; source-bound polynomial fibers need their base/selector evidence. Exclude poles and retain the original branch. Do not mistake similarity support for general affine support.
3. Retain selected intervals in complete `SurfaceIntersectionCurve` restrictions, spatial curves, both pcurves and boundary contacts. Existing represented native subdivision rebases charts. The retained path must transport the common chart and preserve source/event incidence. Reversal, transforms, boundaries and downstream materialization/replay need exact image assertions.
4. Add whole polynomial-branch/event persistence with equation/domain/solver controls, slab/root selector, restrictions, transforms and graph incidence; admit before decoding and recompute cold. Persisting selected UV point graphs does not persist whole branches.
5. Implement the existing invertible-affine-projection plan for polynomial height patches using `Curve3::planar_image`, both surface charts and a shared section graph. Critical/singular events join branches; do not label those pieces disjoint curves. Consume complete loops, isolated points, singular/disconnected components and empty sets through restriction, reversal, transform, replay and further modeling.
6. Complete general rational maps, regularity/tangents, vertical/common components, patch pairs and trim/material arrangements. Resource/cancellation, runtime fuzz/ASan/lexicase, release/MSRV/binding and full workflow gates remain independent requirements.

The prior [parameter-map roadmap](../2026-10-19-selected-pcurve-maps/next-domains.md) and [selected-fiber roadmap](../2026-10-19-selected-fiber-images/next-domains.md) retain their original hard cases. The exterior affine-point bounds blocker is separate from scalar affine arithmetic; repair that owner only when a BRep consumer needs it.
''')
D.mkdir(exist_ok=False)
for name in ['contract.md','next-domains.md','candidate-source.json','baseline-source.json','environment.json','dependency-comparison.json','upstream-check.json','test-summary.json','archive-comparison.json','cost-analysis.json','binary-sizes.json','verification.json','report.json','source-patch.json','qualified-source.patch.gz','ideas.json','source-move-audit.json']:
 shutil.copy(O/name,D/name)
(D/'README.md').write_text('# Retained pcurve evaluation\n\nBase: `'+src['base']+'`. Local implementation increment; no push or work-package completion.\n\n'+q+'\n\n'+p+'\n\n'+limits+'''\n
## API and ownership

`SurfaceIntersectionPcurve::point_at(&Parameter) -> GeometryResult<hypercurve::CurvePoint2>` retains selected parameters and UV point evidence. Pcurve evaluation/materialization/correspondence now live in `geometry/pcurve.rs`; exact parameter and point operations remain Hypercurve-owned. Native represented evaluations use existing formulas. Selected rational projections and linear sections use existing exact carriers and native parameter maps. Planar lifts retain source charts under admitted similarity projections. Iso queries reuse scalar affine-point authority.

Boolean midpoint classification and topology partitioning pass the retained UV image directly to the face classifier. Periodic coordinate arithmetic explicitly requests a stored view and fails typed when unavailable. Existing represented test fixtures still assert that their coordinate view exists; their geometric assertions remain. Bench/fuzz consumers migrate directly. No compatibility overload, new representation tag, archive schema or dependency is added.

Selected UV images persist as exact chord endpoints through the existing point graph. This does not establish arbitrary generated rational carrier or whole-branch persistence. The new public oracle uses `(x,y,z)=(t³,t,t³)` cut at `x=1/2`, so the two UV images are independently `(alpha,1/2)` and `(1/2,alpha)`, with `2*alpha³-1=0`.

## Evidence and reproduction

[Contract](contract.md), [source hashes](candidate-source.json), [test counts](test-summary.json), [costs](cost-analysis.json), [artifacts](archive-comparison.json), [idea decisions](ideas.json), [next domains](next-domains.md) and [raw evidence](raw-evidence.tar.gz) retain the finite scope. The original API refusal, original complete section failure, mechanical caller migration errors and a WASM runner invocation missing its export list all remain recorded. The export list was supplied and the same compiled WASM artifact passed both exports; no kernel change was needed for that harness failure.

Raw evidence contains every recorded command/exit/source patch/log, standalone consumer manifests/locks, native archives and allocation/RSS samples. Executables and caches are excluded. Adjust the explicit source/cache paths to reproduce. Baseline jobs name the frozen main checkout; candidate jobs use the development checkout. Do not run the snapshot runner after copying evidence into the repository. Qualification scopes and any final caller-only migrations are recorded in verification.json.
''')
status_path=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status=json.loads(status_path.read_text());before=copy.deepcopy(status)
status['increments'].append(dict(id=report['increment'],work_packages=['WP02','WP05a','WP05b','WP06','WP13','WP21'],properties=['P1','P4','P5','P6','P8','P9','P15','P16','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],change='Retain selected parameters and UV images through pcurve evaluation, exact face classification and checked point-graph replay.',sources=['../src/geometry/pcurve.rs','../src/geometry/selected_pcurves.rs','../src/topology/query.rs','../tests/support/pcurve_evaluation.rs'],evidence='evidence/2026-10-19-pcurve-evaluation/manifest.json',validation=q,cost_evidence=p,limits=limits))
assert status['increments'][:-1]==before['increments'] and status['work_packages']==before['work_packages'] and not status['complete']
write(status_path,status)
plan=R/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md';text=plan.read_text().replace('Updated 2026-10-19 for selected pcurve\nparameter maps,','Updated 2026-10-19 for retained pcurve\nevaluation,',1)
text=text.replace('[current next domains](evidence/2026-10-19-selected-pcurve-maps/','[associated next domains](evidence/2026-10-19-selected-pcurve-maps/')
marker='Apply [research gates G2–G5]';assert marker in text
text=text.replace(marker,'''The [retained pcurve evaluation increment](evidence/2026-10-19-pcurve-evaluation/README.md)
now evaluates selected spatial parameters into retained UV images, with direct
caller migration and no legacy overload. Native rational sections/projections,
retained/iso mappings and admitted planar-source similarity projections preserve
source evidence through queries and point-graph replay. Face classification
consumes the retained UV point directly. `geometry/pcurve.rs` owns these maps;
Hypercurve retains scalar and point proof authority. General `Surface::point_at`
UV images, whole-section selected restriction and branch/event persistence remain
required next steps. Follow the [current next domains](evidence/2026-10-19-pcurve-evaluation/next-domains.md).
No work package or release gate is closed by this increment.

'''+marker,1);plan.write_text(text)
matrix=R/'crates/hyperbrep/docs/SUPPORT_MATRIX.md';text=matrix.read_text();marker='## Spatial curve carriers';assert marker in text
text=text.replace(marker,'''Retained pcurve `point_at` accepts `Parameter` and returns
`hypercurve::CurvePoint2`, preserving selected UV images. Native rational
sections/projections, retained/iso charts and admitted planar-lift similarity
charts support exact queries and point-graph replay. The face classifier accepts
these images directly; periodic coordinate arithmetic explicitly requests a
stored view. Selected angular and general procedural non-similarity projections
remain typed blockers. `Surface::point_at` still needs retained joint-UV migration.
See the [evaluation evidence](evidence/2026-10-19-pcurve-evaluation/README.md).

'''+marker,1);matrix.write_text(text)
architecture=R/'crates/hyperbrep/docs/ARCHITECTURE.md';text=architecture.read_text();marker='Retained pcurves may run in either source direction;';assert marker in text
text=text.replace(marker,'''`SurfaceIntersectionPcurve::point_at(&Parameter)` returns a retained Hypercurve
`CurvePoint2`, with exact domain checks and no coordinate reconstruction.
`geometry/pcurve.rs` owns evaluation and correspondence. Native rational section
spans and plane projections preserve selected parameters; iso/retained mappings
reuse their source authority. Planar procedural projections currently require a
similarity of the source chart. Face classification accepts the retained UV
point directly; coordinate algorithms explicitly request an optional view.
General retained surface evaluation and full selected section restriction remain
open boundaries, documented in the [evaluation record](evidence/2026-10-19-pcurve-evaluation/README.md).
'''+marker,1);architecture.write_text(text)
archive=R/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md';archive.write_text(archive.read_text()+'''\nSelected section UV evaluations now feed exact chord endpoint definitions in the
existing retained point graph. Rational Bezier/NURBS section roots, restrictions
and reversal replay cold with independently checked UV images. The same models
retain their spatial selected point through transform/replay. No new schema is
introduced; whole polynomial branches and arbitrary generated rational curve
carriers remain separate persistence targets. See the [evaluation record](evidence/2026-10-19-pcurve-evaluation/README.md).
''')
# Byte-preserving ownership boundary for the repository ledger.
ledger_path=R/'docs/properties-status.json';text=ledger_path.read_text();ledger=json.loads(text)
entry=ledger['current_work']['hyperbrep'];entry.update(latest_implementation=report['increment'],latest_feature_evidence='crates/hyperbrep/docs/evidence/2026-10-19-pcurve-evaluation/manifest.json',latest_evidence='crates/hyperbrep/docs/evidence/2026-10-19-pcurve-evaluation/manifest.json',qualification=q,performance_evidence=p,limits=limits,latest_update_check='crates/hyperbrep/docs/evidence/2026-10-19-pcurve-evaluation/upstream-check.json')
decoder=json.JSONDecoder()
def ws(s,p):
 while s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;ledger_path.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()));shutil.copy(O/'ledger-scope.json',D/'ledger-scope.json')
# No snapshot runner after the evidence copy.
checks=[]
for name,command in [('format',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]:
 result=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True)
 (O/('post-documentation-'+name+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0,(name,result.stderr)
 checks.append(dict(name=name,command=command,exit_code=result.returncode))
assert all(sha(R/p)==h for p,h in src['files'].items())
write(O/'post-documentation-checks.json',dict(checks=checks,qualified_source_unchanged=True));shutil.copy(O/'post-documentation-checks.json',D/'post-documentation-checks.json')
allowed={'.json','.log','.patch','.py','.rs','.toml','.md'}
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
 for path in sorted(O.rglob('*')):
  if not path.is_file() or path.is_symlink():continue
  if path.suffix not in allowed and path.name!='Cargo.lock':continue
  if any(part in ['bin','__pycache__','target'] for part in path.relative_to(O).parts):continue
  info=tar.gettarinfo(str(path),arcname=str(path.relative_to(O)));info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644
  with path.open('rb') as stream:tar.addfile(info,stream)
write(D/'manifest.json',dict(schema_version=1,base_revision=src['base'],increment=report['increment'],report='report.json',qualification='verification.json',source='candidate-source.json',raw='raw-evidence.tar.gz',files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file()}))
print(json.dumps(dict(evidence=str(D),files=len(list(D.iterdir())),raw_bytes=(D/'raw-evidence.tar.gz').stat().st_size,tests=tests),indent=2))
