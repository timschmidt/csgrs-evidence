use hyperbrep::{
    ArchiveLimits, Curve3, CurveParameterLocation, Matrix4, Point3, RawModel, Real, Surface,
    CurveSurfaceIntersection, Vector3, boolean, builder,
};

fn p(x: i32, y: i32, z: i32) -> Point3 {
    Point3::new(x.into(), y.into(), z.into())
}

fn equal(a: &Real, b: &Real) {
    assert_eq!(
        hyperlimit::compare_reals(a, b, hyperbrep::STRICT_PREDICATES).value(),
        Some(std::cmp::Ordering::Equal),
    );
}

#[test]
fn distant_angular_charts_preserve_conic_inverse_and_plane_contacts() {
    let quarter = (Real::pi() / Real::from(2)).unwrap();
    for turn in [-7, -1, 0, 1, 7] {
        let start = Real::from(turn) * Real::tau();
        for ellipse in [false, true] {
            let curve = if ellipse {
                Curve3::ellipse_arc(p(0, 0, 0), Vector3::x(), Vector3::y(), 3.into(), 2.into(), start.clone(), &start + Real::pi())
            } else {
                Curve3::circle_arc(p(0, 0, 0), Vector3::x(), Vector3::y(), 2.into(), start.clone(), &start + Real::pi())
            }.unwrap();
            let point = p(0, 2, 0);
            let CurveParameterLocation::Parameters(parameters) = curve.parameters_of(&point).unwrap() else {
                panic!("missing inverse: turn={turn} ellipse={ellipse}")
            };
            assert_eq!(parameters.len(), 1);
            equal(parameters[0].try_real().unwrap(), &(&start + &quarter));
            let plane = Surface::plane(p(0, 0, 0), Vector3::y(), Vector3::z()).unwrap();
            let CurveSurfaceIntersection::Points(points) = plane.intersect_curve(&curve).unwrap() else {
                panic!("missing plane contact: turn={turn} ellipse={ellipse}")
            };
            assert_eq!(points.len(), 1);
            equal(&points[0].parameter, &(&start + &quarter));
        }
    }
}

#[test]
fn oblique_torus_half_continues_into_axial_band() {
    let source = builder::torus(5.into(), 2.into()).unwrap();
    let r = (Real::from(2).sqrt().unwrap() / Real::from(2)).unwrap();
    let rotation = Matrix4::from_row_major([
        r.clone(), -&r, 0.into(), 0.into(), r.clone(), r, 0.into(), 0.into(),
        0.into(), 0.into(), 1.into(), 0.into(), 0.into(), 0.into(), 0.into(), 1.into(),
    ]);
    let cutter = builder::cuboid(p(0, -20, -20), p(20, 20, 20))
        .unwrap().transformed(&rotation).unwrap();
    let half = boolean::intersection(&source, &cutter).unwrap();
    let band = builder::cuboid(p(-20, -20, 1), p(20, 20, 20)).unwrap();
    let result = boolean::intersection(&half, &band).unwrap();
    let json = result.model().to_json().unwrap();
    let replay = RawModel::from_json(&json, &ArchiveLimits::default()).unwrap().validate().unwrap();
    let expected = Real::from(5) * Real::pi()
        * ((Real::from(4) * Real::pi() / Real::from(3)).unwrap() - Real::from(3).sqrt().unwrap());
    for model in [result.model(), &replay] {
        assert_eq!(model.solids().count(), 1);
        equal(&model.solids().next().unwrap().volume().unwrap(), &expected);
        for edge in model.edges() {
            let uses: Vec<_> = edge.uses().collect();
            assert_eq!(uses.len(), 2);
            assert_ne!(uses[0].direction(), uses[1].direction());
        }
    }
}
