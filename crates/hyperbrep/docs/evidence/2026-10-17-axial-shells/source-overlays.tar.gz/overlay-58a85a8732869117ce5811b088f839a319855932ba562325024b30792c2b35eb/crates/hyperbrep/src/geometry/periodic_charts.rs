//! Certified chart transitions on coincident periodic native carriers.
use super::*;

impl SurfaceIntersectionCurve {
    /// The source pcurve is an already validated complete edge image. Cylinder
    /// frames prove a global angular reversal/phase and axial reversal/offset;
    /// target trim lifting subsequently chooses the authored whole-period lift.
    pub(crate) fn from_coincident_iso_boundary(
        curve: Curve3,
        pcurve: &Pcurve,
        edge_scale: &Real,
        edge_offset: &Real,
        source: &Surface,
        target: &Surface,
        target_operand: SurfaceIntersectionOperand,
    ) -> GeometryResult<Option<Self>> {
        let Some(mut trace) =
            Self::from_certified_iso_boundary(curve, pcurve, edge_scale, edge_offset)?
        else {
            return Ok(None);
        };
        if source.same_periodic_analytic_parameterization(target)? {
            return Ok(Some(trace));
        }
        let Some((sign, phase, height)) = source.coincident_cylinder_chart(target)? else { return Ok(None) };
        let pcurve = match target_operand {
            SurfaceIntersectionOperand::First => &mut trace.first_pcurve,
            SurfaceIntersectionOperand::Second => &mut trace.second_pcurve,
        };
        let offset = match &mut pcurve.mapping {
            SurfaceIntersectionPcurveMapping::TensorIsoU { constant } => {
                *constant = &sign * &*constant + phase;
                &height
            }
            SurfaceIntersectionPcurveMapping::TensorIsoV { constant } => {
                *constant = &sign * &*constant + height;
                &phase
            }
            _ => return Ok(None),
        };
        pcurve.source_scale = &sign * &pcurve.source_scale;
        pcurve.source_offset = &sign * &pcurve.source_offset + offset;
        Ok(Some(trace))
    }
}

impl Surface {
    /// A global chart equivalence, established from complete cylinder frames.
    fn coincident_cylinder_chart(&self, target: &Self) -> GeometryResult<Option<(Real, Real, Real)>> {
        let (SurfaceGeometry::Cylinder(source), SurfaceGeometry::Cylinder(target)) =
            (&self.data.geometry, &target.data.geometry)
        else {
            return Ok(None);
        };
        let equal = |a: &Real, b: &Real| -> GeometryResult<bool> {
            Ok(decided_order(compare_reals(a, b, crate::STRICT_PREDICATES))? == Ordering::Equal)
        };
        let displacement = &source.origin - &target.origin;
        if !equal(&source.radius, &target.radius)?
            || !equal(
                &source.frame.z.cross(&target.frame.z).norm_squared(),
                &Real::zero(),
            )?
            || !equal(
                &displacement.cross(&target.frame.z).norm_squared(),
                &Real::zero(),
            )?
        {
            return Ok(None);
        }
        let sign = source.frame.z.dot(&target.frame.z);
        let phase = certified_atan2(
            source.frame.x.dot(&target.frame.y),
            source.frame.x.dot(&target.frame.x),
        )?;
        let height = displacement.dot(&target.frame.z);
        Ok(Some((sign, phase, height)))
    }

    pub(crate) fn coincident_cylinder_parameter(&self, target: &Self, parameter: &Point2)
        -> GeometryResult<Option<Point2>>
    {
        Ok(self.coincident_cylinder_chart(target)?.map(|(sign, phase, height)| {
            Point2::new(&sign * &parameter.x + phase, sign * &parameter.y + height)
        }))
    }
}
