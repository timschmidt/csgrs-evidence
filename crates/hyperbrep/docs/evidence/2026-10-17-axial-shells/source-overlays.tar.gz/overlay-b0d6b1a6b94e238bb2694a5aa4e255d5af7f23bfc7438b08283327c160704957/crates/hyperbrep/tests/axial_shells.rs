//! Full-size partial-depth cuts and their independent material expectations.
use hyperbrep::*;

fn point(x: i32, y: i32, z: i32) -> Point3 {
    Point3::new(x.into(), y.into(), z.into())
}
fn equal(a: &Real, b: &Real) {
    assert_eq!(
        hyperlimit::compare_reals(a, b, STRICT_PREDICATES).value(),
        Some(std::cmp::Ordering::Equal)
    );
}

fn cut(kind: usize) {
    let delta: Real = "1e-12".parse().unwrap();
    let (low, high) = match kind {
        0 => ((-20).into(), Real::from(6) - &delta),
        1 => (delta.clone(), 20.into()),
        2 => (2.into(), 4.into()),
        _ => ((-20).into(), 20.into()),
    };
    let cylinder = builder::cylinder(5.into(), 6.into()).unwrap();
    let tool = builder::cuboid(
        Point3::new(0.into(), (-20).into(), low),
        Point3::new(20.into(), 20.into(), high),
    )
    .unwrap();
    let result = if kind == 3 {
        boolean::difference(&tool, &cylinder)
    } else {
        boolean::difference(&cylinder, &tool)
    }
    .unwrap();
    let pi = Real::pi();
    let (volume, area) = match kind {
        0 | 1 => (
            Real::from(75) * &pi + (Real::from(25) * &pi * &delta / Real::from(2)).unwrap(),
            (Real::from(80) + Real::from(5) * &delta) * &pi + Real::from(60)
                - Real::from(10) * &delta,
        ),
        2 => (
            Real::from(125) * &pi,
            Real::from(125) * &pi + Real::from(20),
        ),
        _ => (
            Real::from(32_000) - Real::from(75) * &pi,
            Real::from(6340) + Real::from(55) * &pi,
        ),
    };
    let json = result.model().to_json().unwrap();
    let cold = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(cold.to_json().unwrap(), json);
    for model in [result.model(), &cold] {
        assert_eq!(model.solids().count(), 1);
        equal(&model.solids().next().unwrap().volume().unwrap(), &volume);
        equal(&model.faces().map(|f| f.area().unwrap()).sum(), &area);
        for edge in model.edges() {
            let uses = edge.uses().collect::<Vec<_>>();
            assert_eq!(uses.len(), 2);
            assert_ne!(uses[0].direction(), uses[1].direction());
        }
        let solid = model.solids().next().unwrap();
        use SolidPointLocation::{Boundary, Inside, Outside};
        for (p, expected) in if kind == 3 {
            vec![
                (point(1, 0, 3), Outside),
                (point(6, 0, 3), Inside),
                (point(5, 0, 3), Boundary),
            ]
        } else {
            vec![
                (point(-1, 0, 3), Inside),
                (point(1, 0, 3), Outside),
                (point(0, 0, 3), Boundary),
            ]
        } {
            assert_eq!(solid.classify_point(&p).unwrap(), expected);
        }
        if kind < 3 {
            let event = match kind {
                0 => Real::from(6) - &delta,
                1 => delta.clone(),
                _ => Real::from(2),
            };
            assert_eq!(
                solid
                    .classify_point(&Point3::new((-1).into(), 0.into(), event.clone()))
                    .unwrap(),
                Inside
            );
            assert_eq!(
                solid
                    .classify_point(&Point3::new(1.into(), 0.into(), event.clone()))
                    .unwrap(),
                Boundary
            );
            let half = (&delta / Real::from(2)).unwrap();
            let below = solid
                .classify_point(&Point3::new(1.into(), 0.into(), &event - &half))
                .unwrap();
            let above = solid
                .classify_point(&Point3::new(1.into(), 0.into(), &event + half))
                .unwrap();
            assert_eq!(
                (below, above),
                if kind == 0 {
                    (Outside, Inside)
                } else {
                    (Inside, Outside)
                }
            );
        }
    }
}

#[test]
fn axial_shell_upper_thin_layer() {
    cut(0)
}
#[test]
fn axial_shell_lower_thin_layer() {
    cut(1)
}
#[test]
fn axial_shell_interior_notch() {
    cut(2)
}
#[test]
fn axial_shell_reversed_covering_difference() {
    cut(3)
}
