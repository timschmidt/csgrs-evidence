#[path = "support/axial_shells.rs"]
mod support;
#[test]
fn axial_shell_upper_thin_layer() {
    support::workflow(0, false);
}
#[test]
fn axial_shell_lower_thin_layer() {
    support::workflow(1, false);
}
#[test]
fn axial_shell_interior_notch() {
    support::workflow(2, false);
}
#[test]
fn axial_shell_reversed_covering_difference() {
    support::workflow(3, false);
}
#[test]
fn axial_shell_reflected_upper() {
    support::workflow(0, true);
}
#[test]
fn axial_shell_reflected_lower() {
    support::workflow(1, true);
}
#[test]
fn axial_shell_reflected_interior() {
    support::workflow(2, true);
}
#[test]
fn axial_shell_reflected_reverse() {
    support::workflow(3, true);
}
