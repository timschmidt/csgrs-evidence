//! Seam-aligned complete workflows shared by native, WASM and cost consumers.
use hyperbrep::{
    ArchiveLimits, BodySet, Matrix4, Model, Point3, RawModel, Real, SolidPointLocation, boolean,
    builder,
};
use std::cmp::Ordering;

pub fn ratio(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}
pub fn point(x: i32, y: i32, z: i32) -> Point3 {
    Point3::new(x.into(), y.into(), z.into())
}
#[track_caller]
pub fn equal(a: &Real, b: &Real) {
    assert_eq!(
        hyperlimit::compare_reals(a, b, hyperbrep::STRICT_PREDICATES).value(),
        Some(Ordering::Equal),
        "actual={a:?}, expected={b:?}"
    );
}
pub fn fixture(kind: usize) -> (BodySet, BodySet, Real, Real) {
    let source = if kind == 2 {
        builder::cone_frustum(5.into(), 2.into(), 6.into()).unwrap()
    } else {
        builder::torus(5.into(), 2.into()).unwrap()
    };
    let cutter = if kind == 0 {
        builder::cuboid(point(-20, -20, 0), point(20, 20, 20))
    } else {
        builder::cuboid(point(0, -20, -20), point(20, 20, 20))
    }
    .unwrap();
    let (volume, area) = if kind == 2 {
        (
            Real::from(39) * Real::pi(),
            Real::from(42)
                + ((Real::from(29) + Real::from(21) * Real::from(5).sqrt().unwrap()) * Real::pi()
                    / Real::from(2))
                .unwrap(),
        )
    } else {
        let half = Real::from(20) * Real::pi() * Real::pi();
        (
            half.clone(),
            half + Real::from(if kind == 0 { 40 } else { 8 }) * Real::pi(),
        )
    };
    (source, cutter, volume, area)
}
pub fn reload(model: &Model) -> Model {
    let json = model.to_json().unwrap();
    let loaded = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(loaded.to_json().unwrap(), json);
    loaded
}
fn measures(model: &Model, volume: &Real, area: &Real) {
    equal(&model.solids().next().unwrap().volume().unwrap(), volume);
    equal(
        &model
            .faces()
            .map(|f| f.area().unwrap())
            .fold(Real::zero(), |sum, value| sum + value),
        area,
    );
    for edge in model.edges() {
        let uses = edge.uses().collect::<Vec<_>>();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
}
pub fn similarity(scale: &Real, reflected: bool) -> Matrix4 {
    let sign = if reflected { -Real::one() } else { Real::one() };
    // A cyclic permutation moves the old axial seam onto a world coordinate
    // plane; the rational rotation also exercises non-coordinate meridians.
    Matrix4::from_row_major([
        0.into(),
        0.into(),
        scale.clone(),
        3.into(),
        scale * ratio(3, 5) * &sign,
        -scale * ratio(4, 5),
        0.into(),
        (-2).into(),
        scale * ratio(4, 5) * sign,
        scale * ratio(3, 5),
        0.into(),
        7.into(),
        0.into(),
        0.into(),
        0.into(),
        1.into(),
    ])
}
fn samples(kind: usize, difference: bool) -> Vec<(Point3, SolidPointLocation)> {
    use SolidPointLocation::{Boundary, Inside, Outside};
    let sign = if difference {
        -Real::one()
    } else {
        Real::one()
    };
    let delta = ratio(1, 1_000_000) * ratio(1, 1_000_000);
    match kind {
        0 => vec![
            (Point3::new(5.into(), 0.into(), sign.clone()), Inside),
            (Point3::new(5.into(), 0.into(), -&sign), Outside),
            (point(5, 0, 0), Boundary),
            (point(0, 0, 0), Outside),
            (Point3::new(5.into(), 0.into(), &sign * &delta), Inside),
            (Point3::new(5.into(), 0.into(), -(&sign * &delta)), Outside),
            (
                Point3::new(5.into(), 0.into(), &sign * (Real::from(2) - &delta)),
                Inside,
            ),
            (
                Point3::new(5.into(), 0.into(), &sign * Real::from(2)),
                Boundary,
            ),
            (
                Point3::new(5.into(), 0.into(), &sign * (Real::from(2) + &delta)),
                Outside,
            ),
        ],
        1 => vec![
            (
                Point3::new(&sign * Real::from(5), 0.into(), 0.into()),
                Inside,
            ),
            (
                Point3::new(-(&sign * Real::from(5)), 0.into(), 0.into()),
                Outside,
            ),
            (point(0, 5, 0), Boundary),
            (point(0, 0, 0), Outside),
            (Point3::new(&sign * &delta, 5.into(), 0.into()), Inside),
            (Point3::new(-(&sign * &delta), 5.into(), 0.into()), Outside),
            (
                Point3::new(&sign * (Real::from(7) - &delta), 0.into(), 0.into()),
                Inside,
            ),
            (
                Point3::new(&sign * Real::from(7), 0.into(), 0.into()),
                Boundary,
            ),
            (
                Point3::new(&sign * (Real::from(7) + &delta), 0.into(), 0.into()),
                Outside,
            ),
        ],
        2 => vec![
            (Point3::new(sign.clone(), 0.into(), 3.into()), Inside),
            (Point3::new(-&sign, 0.into(), 3.into()), Outside),
            (point(0, 0, 3), Boundary),
            (point(0, 0, 7), Outside),
            (Point3::new(&sign * &delta, 0.into(), 3.into()), Inside),
            (Point3::new(-(&sign * &delta), 0.into(), 3.into()), Outside),
            (
                Point3::new(&sign * (ratio(7, 2) - &delta), 0.into(), 3.into()),
                Inside,
            ),
            (
                Point3::new(&sign * ratio(7, 2), 0.into(), 3.into()),
                Boundary,
            ),
            (
                Point3::new(&sign * (ratio(7, 2) + &delta), 0.into(), 3.into()),
                Outside,
            ),
        ],
        _ => unreachable!(),
    }
}
pub fn check_case(kind: usize, map: &Matrix4, scale: &Real) -> u64 {
    let (source, cutter, volume, area) = fixture(kind);
    let source = source.transformed(map).unwrap();
    let cutter = cutter.transformed(map).unwrap();
    let expected_volume = &volume * scale * scale * scale;
    let expected_area = &area * scale * scale;
    let mut receipt = 0xcbf29ce484222325_u64;
    for (difference, result) in [
        (false, boolean::intersection(&source, &cutter)),
        (false, boolean::intersection(&cutter, &source)),
        (true, boolean::difference(&source, &cutter)),
    ] {
        let result = result.unwrap_or_else(|error| {
            panic!("case={kind} difference={difference}, scale={scale:?}, map={map:?}: {error:?}")
        });
        assert_eq!(result.len(), 1);
        let loaded = reload(result.model());
        for model in [result.model(), &loaded] {
            measures(model, &expected_volume, &expected_area);
            for (point, expected) in samples(kind, difference) {
                let point = map.transform_point3(&point).unwrap();
                assert_eq!(
                    model
                        .solids()
                        .next()
                        .unwrap()
                        .classify_point(&point)
                        .unwrap(),
                    expected,
                    "case={kind} difference={difference}"
                );
            }
        }
        for byte in loaded.to_json().unwrap().bytes() {
            receipt = (receipt ^ u64::from(byte)).wrapping_mul(0x100000001b3);
        }
        // Consume the output through a shared-edge edit, untrusted replay and
        // a reflected similarity, retaining exact measures and incidence.
        let edge = loaded.edges().next().unwrap();
        let middle = ((edge.domain().start().try_real().unwrap()
            + edge.domain().end().try_real().unwrap())
            / Real::from(2))
        .unwrap();
        let split = edge.split(middle.into()).unwrap();
        let replay = reload(split.model());
        measures(&replay, &expected_volume, &expected_area);
        let moved = replay
            .transformed(&similarity(&ratio(1, 1000), true))
            .unwrap();
        measures(
            &reload(&moved),
            &(&expected_volume * ratio(1, 1_000_000_000)),
            &(&expected_area * ratio(1, 1_000_000)),
        );
    }
    receipt
}
pub fn original(kind: usize) -> u64 {
    check_case(kind, &Matrix4::identity(), &Real::one())
}
pub fn transforms() -> usize {
    let mut count = 0;
    for scale in [
        ratio(1, 1000),
        ratio(127, 5000),
        Real::from(2).sqrt().unwrap(),
    ] {
        for reflected in [false, true] {
            for kind in 0..3 {
                check_case(kind, &similarity(&scale, reflected), &scale);
                count += 3;
            }
        }
    }
    count
}
