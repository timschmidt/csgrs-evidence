use hyperbrep::{ArchiveLimits, BodySet, Point3, RawModel, Real, boolean, builder};

fn point(x: i32, y: i32, z: i32) -> Point3 {
    Point3::new(x.into(), y.into(), z.into())
}

fn check_half(source: BodySet, cutter: BodySet, volume: Real, area: Real) {
    for result in [
        boolean::intersection(&source, &cutter),
        boolean::intersection(&cutter, &source),
        boolean::difference(&source, &cutter),
    ] {
        let result = result.expect("original seam-aligned cut must complete");
        assert_eq!(result.bodies().len(), 1);
        let json = result.model().to_json().unwrap();
        let replay = RawModel::from_json(&json, &ArchiveLimits::default())
            .unwrap()
            .validate()
            .unwrap();
        assert_eq!(replay.to_json().unwrap(), json);
        for model in [result.model(), &replay] {
            for (actual, expected) in [
                (model.solids().next().unwrap().volume().unwrap(), &volume),
                (
                    model
                        .faces()
                        .map(|face| face.area().unwrap())
                        .fold(Real::zero(), |sum, value| sum + value),
                    &area,
                ),
            ] {
                assert_eq!(
                    hyperlimit::compare_reals(&actual, expected, hyperbrep::STRICT_PREDICATES)
                        .value(),
                    Some(std::cmp::Ordering::Equal),
                    "independently derived half-solid measure"
                );
            }
        }
    }
}

#[test]
fn torus_axial_half_on_existing_seams() {
    check_half(
        builder::torus(5.into(), 2.into()).unwrap(),
        builder::cuboid(point(-20, -20, 0), point(20, 20, 20)).unwrap(),
        Real::from(20) * Real::pi() * Real::pi(),
        Real::from(20) * Real::pi() * Real::pi() + Real::from(40) * Real::pi(),
    );
}

#[test]
fn torus_longitudinal_half_on_existing_seams() {
    check_half(
        builder::torus(5.into(), 2.into()).unwrap(),
        builder::cuboid(point(0, -20, -20), point(20, 20, 20)).unwrap(),
        Real::from(20) * Real::pi() * Real::pi(),
        Real::from(20) * Real::pi() * Real::pi() + Real::from(8) * Real::pi(),
    );
}

#[test]
fn cone_longitudinal_half_on_existing_seams() {
    check_half(
        builder::cone_frustum(5.into(), 2.into(), 6.into()).unwrap(),
        builder::cuboid(point(0, -20, -20), point(20, 20, 20)).unwrap(),
        Real::from(39) * Real::pi(),
        Real::from(42)
            + ((Real::from(29) + Real::from(21) * Real::from(5).sqrt().unwrap()) * Real::pi()
                / Real::from(2))
            .unwrap(),
    );
}
