#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/edge_images.rs"]
mod images;
#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/edge_image_queries.rs"]
mod queries;
#[allow(dead_code)]
#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/seam_cuts.rs"]
mod seam;
#[path = "/mnt/development/csgrs/crates/hyperbrep-io/tests/support/seam_export.rs"]
mod seam_export;
#[allow(dead_code)]
#[path = "/mnt/development/csgrs/crates/hyperbrep/tests/support/similarity.rs"]
mod similarity;
use analytic::cylinder;
#[path = "/mnt/development/csgrs/crates/hyperbrep-io/tests/support/supplied_pcurves.rs"]
mod supplied;

#[path = "/mnt/development/csgrs/crates/hyperbrep-io/tests/support/analytic_export.rs"]
mod analytic;
mod faceted;

#[unsafe(no_mangle)]
pub extern "C" fn run_probe() -> u32 {
    cylinder::closed_circle();
    cylinder::parameters();
    cylinder::representations();
    cylinder::oblique_frames();
    cylinder::units();
    cylinder::composition();
    cylinder::failures();
    cylinder::admission();
    images::parameterizations();
    images::faults();
    queries::parameter_and_radius_failures();
    queries::unresolved_is_not_success();
    queries::unsupported_is_not_endpoint_agreement();
    supplied::source_maps();
    supplied::representations();
    supplied::composition();
    supplied::failures();
    supplied::admission();
    analytic::imported_circles();
    analytic::frames_and_edits();
    analytic::planar_holes();
    analytic::units_and_occurrences();
    analytic::composition();
    analytic::failures_and_recovery();
    analytic::limits();
    assert_eq!(faceted::run_probe(), 5);
    similarity::primitives();
    similarity::clipped_and_voids();
    similarity::selected_and_repeated();
    similarity::rejection_and_recovery();
    similarity::periodic_and_near();
    analytic::scaled_units();
    similarity::profile_families();
    for kind in 0..3 {
        seam::original(kind);
    }
    assert_eq!(seam::transforms(), 54);
    assert_eq!(seam::boundary_provenance(), 16);
    seam_export::failures_and_recovery();
    43
}
