import run
from pathlib import Path
R=run.ROOT;O=run.OUT
jobs=[
 ('final-affected-clippy',['cargo','clippy','--offline','--locked','-p','hyperbrep','-p','hyperbrep-io','--all-targets','--all-features','--','-D','warnings'],3600),
 ('final-owner-clippy',['cargo','clippy','--offline','--locked','-p','hypersolve','-p','hypercurve','--all-targets','--all-features','--','-D','warnings'],3600),
 ('final-solver-maps',['cargo','test','--offline','--locked','--release','-p','hypersolve','--all-features','--test','surface_polynomial_maps'],1800),
 ('final-solver-basis-regressions',['cargo','test','--offline','--locked','--release','-p','hypersolve','--all-features','--lib','curve_substitution'],2400),
 ('final-solver-field-regressions',['cargo','test','--offline','--locked','--release','-p','hypersolve','--all-features','--lib','recursive_quadratic_field'],2400),
 ('final-owner-rational-regressions',['cargo','test','--offline','--locked','--release','-p','hypercurve','--all-features','--test','rational_point_forms','--test','selected_point_definitions','--test','selected_fiber_images','--test','work_budget'],2400),
 ('final-brep-release-tests-2',['cargo','test','--offline','--locked','--release','-p','hyperbrep','-p','hyperbrep-io','--all-features','--no-fail-fast'],10800),
 ('final-affected-rustdoc',['cargo','doc','--offline','--locked','-p','hypersolve','-p','hypercurve','-p','hyperbrep','-p','hyperbrep-io','--all-features','--no-deps'],3600),
 ('final-brep-fuzz-check',['cargo','check','--offline','--locked','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--bins'],2400),
 ('final-fmt-check',['cargo','fmt','--all','--','--check'],600),
 ('final-fuzz-fmt',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check'],600),
]
for label,command,seconds in jobs:
 job=dict(label=label,command=command,seconds=seconds)
 if label=='final-affected-rustdoc':job['env']={'RUSTDOCFLAGS':'-D warnings'}
 run.run(job)
