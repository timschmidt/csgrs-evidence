from pathlib import Path
R=Path('/mnt/development/csgrs/target/hyperbrep-development')
p=R/'crates/hypercurve/tests/support/rational_point_forms.rs';s=p.read_text()
a='''    assert!(
        point.rational_form(pole.clone(), pole).is_err(),
        "algebraic 0/0 cannot cancel to one"
    );''';assert a in s;s=s.replace(a,'''    assert!(matches!(point.rational_form(pole.clone(), pole), Err(ExactCurveError::Invalid { cause: CurveError::ZeroRationalPointDenominator, .. })), "algebraic 0/0 cannot cancel to one");''')
a='''    assert!(
        point
            .rational_form(polynomial(&[&[]]), polynomial(&[&[0, 0, 0, 16], &[-1]]))
            .is_err()
    );''';assert a in s;s=s.replace(a,'''    assert!(matches!(point.rational_form(polynomial(&[&[]]), polynomial(&[&[0, 0, 0, 16], &[-1]])), Err(ExactCurveError::Invalid { cause: CurveError::ZeroRationalPointDenominator, .. })));''')
a='''    assert!(
        point
            .rational_form(polynomial(&[&[1]]), polynomial(&[&[-1], &[], &[], &[2]]))
            .is_err()
    );''';assert a in s;s=s.replace(a,'''    assert!(matches!(point.rational_form(polynomial(&[&[1]]), polynomial(&[&[-1], &[], &[], &[2]])), Err(ExactCurveError::Invalid { cause: CurveError::ZeroRationalPointDenominator, .. })));''')
s+='''

pub fn rational_queries_recover_after_budget_refusal() {
    let point = joint_uv();
    let query = || point.rational_form(polynomial(&[&[0,1], &[1]]), polynomial(&[&[1]])).unwrap();
    for policy in [PredicatePolicy::STRICT, PredicatePolicy::APPROXIMATE_512, PredicatePolicy::STRICT] {
        let outcome = evaluate_under(policy, || {
            let form = query();
            assert_eq!(form.compare_to_real(&q(1,2)).unwrap(), Ordering::Greater);
            form.bounds().unwrap();
        });
        assert_eq!(outcome.certainty(),CurveCertainty::Certified);
    }
    let form = query();
    let denied = hypersolve::work_budget::with_budget(hypersolve::work_budget::WorkBudget {refinements:4096,promotions:0}, || {
        let error=form.bounds().unwrap_err();
        assert!(matches!(error,ExactCurveError::Blocked(blocker) if blocker.reason()==UncertaintyReason::BudgetExhausted));
    });
    assert!(denied.result.is_err());
    form.bounds().unwrap();
    assert_eq!(form.compare_to_real(&q(1,2)).unwrap(),Ordering::Greater);
}

pub fn independent_support_fields_keep_rational_identities() {
    let root=|degree:usize| -> CurveParameter2 {
        let mut coefficients=vec![Real::zero();degree+1];coefficients[0]=(-1).into();coefficients[degree]=2.into();
        BezierParameter2::Algebraic(BezierAlgebraicParameter2::try_isolate(
            BezierParameterPolynomial::try_new_power_basis(coefficients).unwrap(),
            BezierParameterInterval::try_new(q(3,4),q(7,8)).unwrap()).unwrap()).into()
    };
    let (x,y)=(root(3),root(5));
    let point=CurvePointDefinition2::SupportingLineIntersection {
        first:[x.affine_point(1.into(),0.into(),0.into(),0.into()).unwrap(),x.affine_point(1.into(),0.into(),0.into(),2.into()).unwrap()],
        second:[y.affine_point(0.into(),0.into(),1.into(),0.into()).unwrap(),y.affine_point(0.into(),2.into(),1.into(),0.into()).unwrap()],
    }.into_point().unwrap();
    assert!(matches!(point.definition().unwrap(),CurvePointDefinition2::SupportingLineIntersection{..}));
    for point in [point.clone(),point.definition().unwrap().into_point().unwrap()] {
        // x^3 = y^5 = 1/2; a shared composite field must preserve both equations.
        let numerator=polynomial(&[&[0,0,0,0,0,2],&[],&[],&[2]]);
        let denominator=polynomial(&[&[1]]);
        let form=point.rational_form(numerator,denominator).unwrap();
        assert_eq!(form.compare_to_real(&2.into()).unwrap(),Ordering::Equal);
        form.bounds().unwrap();
        assert!(matches!(point.rational_form(polynomial(&[&[1]]),polynomial(&[&[-1],&[],&[],&[2]])),Err(ExactCurveError::Invalid{cause:CurveError::ZeroRationalPointDenominator,..})));
    }
}
''';p.write_text(s)
p=R/'crates/hypercurve/tests/rational_point_forms.rs';s=p.read_text();s+='''
#[test]
fn rational_queries_recover_after_budget_refusal(){support::rational_queries_recover_after_budget_refusal();}
#[test]
fn independent_support_fields_keep_rational_identities(){support::independent_support_fields_keep_rational_identities();}
''';p.write_text(s)
# All axes must enclose each selected point.
p=R/'crates/hyperbrep/tests/support/rational_surface_evaluation.rs';s=p.read_text();a='''            let bounds = point.bounds().unwrap();''';assert a in s;s=s.replace(a,a+'''
            for axis in [Axis::X,Axis::Y,Axis::Z] {
                assert_ne!(point.compare_coordinate(&bounds.mins.clone().into(),axis).unwrap(),Ordering::Less);
                assert_ne!(point.compare_coordinate(&bounds.maxs.clone().into(),axis).unwrap(),Ordering::Greater);
            }
''')
s=s.replace('''    let json = model.to_json().unwrap();
    let restored =''','''    let json = model.to_json().unwrap();
    record_archive(&json);
    let restored =''',1)
s+='''

fn record_archive(text: &str) {
    let _=text;
    #[cfg(not(target_arch="wasm32"))]
    if let Ok(folder)=std::env::var("HYPERBREP_RATIONAL_SURFACE_ARTIFACT_DIR") {
        use std::sync::atomic::{AtomicUsize,Ordering};
        static NEXT:AtomicUsize=AtomicUsize::new(0);
        let folder=std::path::PathBuf::from(folder);std::fs::create_dir_all(&folder).unwrap();
        std::fs::write(folder.join(format!("rational-{:03}.json",NEXT.fetch_add(1,Ordering::Relaxed))),text).unwrap();
    }
}

pub fn nurbs_second_span_and_final_endpoint() {
    let uv=point_recipe::joint_uv();
    let scaled=hypercurve::Curve2::try_line(uv,hypercurve::Point2::from_values(0,0).into()).unwrap()
        .transform_similarity(&hypercurve::Similarity2::try_from_real_affine(2.into(),0.into(),0.into(),2.into(),0.into(),0.into()).unwrap()).unwrap().start();
    let root=BezierAlgebraicParameter2::try_isolate(
        BezierParameterPolynomial::try_new_power_basis(vec![2.into(),(-12).into(),24.into(),(-17).into()]).unwrap(),
        BezierParameterInterval::try_new(q(1,3),q(3,8)).unwrap()).unwrap();
    let parameter:hypercurve::CurveParameter2=BezierParameter2::Algebraic(root).into();
    let expected=Surface::plane(Point3::origin(),Vector3::x(),Vector3::y()).unwrap()
        .point_at(&parameter.affine_point(1.into(),0.into(),0.into(),0.into()).unwrap()).unwrap();
    for weighted in [false,true] {
        let point=tensor(true,weighted).point_at(&scaled).unwrap();
        if weighted { assert_eq!(point.compare_coordinate(&expected,Axis::X).unwrap(),Ordering::Equal); }
        else {assert_eq!(point.compare_linear_form(&Vector3::x(),&q(1,2)).unwrap(),Ordering::Equal);}
        assert_eq!(point.compare_linear_form(&Vector3::new([(-1).into(),(-1).into(),1.into()]),&0.into()).unwrap(),Ordering::Equal);
        point.bounds().unwrap();
        let mut builder=ModelBuilder::new();builder.vertex(point).unwrap();replay(&builder.finish().unwrap());
    }
    let endpoint=hypercurve::CurvePointDefinition2::PolynomialFiber {
        equation:hypersolve::BivariatePolynomial::new(vec![vec![0.into(),0.into(),0.into(),16.into()],vec![(-1).into()]]),
        parameter:BezierParameter2::Exact(1.into()),
        root:hypersolve::IsolatedRootInterval {lower:q(3,8),upper:q(1,2),exact_root:None,distinct_root_count:1},
    }.into_point().unwrap();
    let point=tensor(true,false).point_at(&endpoint).unwrap();
    assert!(point.coincides_with(&Point3::new(1.into(),1.into(),2.into()).into()).unwrap());
    let mut builder=ModelBuilder::new();builder.vertex(point).unwrap();replay(&builder.finish().unwrap());
}
''';p.write_text(s)
p=R/'crates/hyperbrep/tests/rational_surface_evaluation.rs';s=p.read_text();s+='''
#[test]
fn nurbs_second_span_and_final_endpoint(){support::nurbs_second_span_and_final_endpoint();}
''';p.write_text(s)
# Extend the existing ownership proof to prepared rational maps as well.
p=R/'crates/hyperbrep/src/geometry/point.rs';s=p.read_text();a='''        let surface = Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap();
        let weak = Arc::downgrade(&surface.data);''';assert s.count(a)==1;s=s.replace(a,'''        for surface in [
            Surface::plane(Point3::origin(), Vector3::x(), Vector3::y()).unwrap(),
            Surface::rational_bezier(vec![vec![Point3::origin(),Point3::new(2.into(),0.into(),0.into())],vec![Point3::new(0.into(),1.into(),0.into()),Point3::new(2.into(),1.into(),0.into())]],vec![vec![Real::one(),Real::from(2)],vec![Real::one(),Real::from(2)]]).unwrap(),
        ] {
        let weak = Arc::downgrade(&surface.data);''');a='''        drop(alias);
        assert!(weak.upgrade().is_none());
    }

    #[test]
    fn selected_planar_points_keep_sources_alive_without_cycles()''';assert a in s;s=s.replace(a,'''        drop(alias);
        assert!(weak.upgrade().is_none());
        }
    }

    #[test]
    fn selected_planar_points_keep_sources_alive_without_cycles()''');p.write_text(s)
