from pathlib import Path
R=Path('/mnt/development/csgrs/target/hyperbrep-development')
link='evidence/2026-10-19-rational-surface-evaluation/README.md'
for rel in ['ARCHITECTURE.md','SUPPORT_MATRIX.md']:
 p=R/'crates/hyperbrep/docs'/rel;s=p.read_text().replace('Archive version 11','Archive version 12')
 s=s.replace('Selected nonlinear surface evaluation and full selected section restriction remain\nopen boundaries,','Selected angular/procedural surface images and full selected section restriction remain\nopen boundaries,')
 s=s.replace('section evaluator and nonlinear selected surface images remain open boundaries.','section evaluator and selected angular/procedural surface images remain open boundaries.')
 s=s.replace('`Surface::point_at` consumes joint UV points and retains plane images; nonlinear selected images remain typed blockers.','`Surface::point_at` consumes joint UV points and retains plane, rational tensor and native rational-profile extrusion images; selected angular and general procedural images remain typed blockers.')
 s=s.replace('Selected nonlinear\nimages remain unsupported.','Selected angular and general procedural\nimages remain unsupported.')
 s+='''

## Rational surface points and affine curve images

`Surface::point_at` admits selected joint UV points on positive-weight rational
Bézier and finite NURBS tensor patches, and extrusions of native line/Bézier/NURBS
profiles. The source surface and entire UV point remain replay authority.
`geometry/surface_point/rational.rs` derives homogeneous coordinate polynomials;
Hypercurve's `CurvePointRationalForm2` evaluates their signs, comparisons and
bounds in the retained joint field. Original denominators are checked before
any cancellation. Hypersolve owns Bernstein and original-knot B-spline basis
conversion and homogeneous recursive-field evaluation. NURBS span ownership is
right-sided at internal knots and includes the final endpoint. Basis conversion
uses an explicit -512 precision floor and preserves undecided/invalid statuses.

Derived coefficient maps are immutable and point-owned. The point retains its
source surface, with no back reference or global cache. Transforms rebuild the
maps from the transformed source and unchanged UV selector. Bounds are exact
conservative enclosures, not promised-width approximations or topology proofs.
Selected angular surfaces and general retained procedural extrusion profiles
remain unsupported. Full section restrictions and branch/event graphs remain
open independently of point evaluation.

`Curve3::affine_image` retains any spatial source under a certified nonsingular
affine matrix. Its `AffineImage` family has a borrowed `affine_geometry` view;
repeated images compose matrices instead of wrapper chains. Evaluation,
derivatives, bounds, inverse location, reversal and restriction delegate to the
source with its typed limitations. Regular angular closed edges remain regular
under the invertible map. General transforms of retained rotations use this carrier when their native
metric path is unavailable. Native conic model transforms keep their existing
metric restriction until complete face-image and replay proofs are available.
Coefficient-only and unsupported surface-intersection algorithms remain typed
blockers; an affine image is not mislabeled as a circle or rotation.

Archive 12 stores the complete source curve and matrix and admits nested source
metadata before decoding scalars. Rational surface maps are recomputed from
source definitions during replay. Versions through 11 are deliberately rejected,
without an adapter. Source-path native/WASM consumers and preserved complete
workflows are recorded in the [admission evidence]('''+link+'''). Installed
distributions, full release/push gates and complete BRep modeling remain open.
'''
 if rel=='SUPPORT_MATRIX.md':
  row='| Planar image |';a=s.index(row);s=s[:a]+'| Affine image | Source-supported exact point/derivative mapped by a certified invertible matrix | Conservative image of source bounds | Source query in inverse coordinates; original typed limitations | Source domain/restriction semantics | Exact source and matrix, archive 12 |\n'+s[a:]
 p.write_text(s)
p=R/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md';s=p.read_text().replace('# Selected geometry in archive version 11','# Selected geometry in archive version 12',1)
s+='''

Version 12 adds `AffineImage { source, transform }` to spatial curves. The source
is the complete embedded spatial curve definition and `transform` is an exact
4×4 affine matrix. Nested record/geometry/degree limits apply before scalar
decoding. Checked reconstruction proves the matrix affine and nonsingular,
rebuilds the source, and composes nested image matrices. No proof bit, sampled
point or prepared rational surface coefficient map is serialized.

Selected rational Bézier/NURBS tensor points and native rational-profile
extrusion points use the existing `SurfaceImage { source, parameter }` record.
Replay checks original weights, domains, knot-span ownership and joint selectors
and rebuilds coefficient maps. Affine-transformed rotation edges retain this
point authority through their embedded source. Versions through 11 are rejected;
there is no legacy decoder. The preserved archive corpus comparison permits
only the top-level 11→12 header change and requires all other bytes to match.
See the [rational surface and affine curve evidence]('''+link+''').
''';p.write_text(s)
p=R/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md';s=p.read_text();marker='Apply [research gates G2–G5]';assert marker in s
s=s.replace(marker,'''The [rational surface evaluation increment]('''+link+''') extends this boundary
to positive-weight Bézier/NURBS tensor patches and native rational-profile
extrusions. Hypercurve owns original-source rational queries; Hypersolve owns
polynomial/basis arithmetic; HyperBRep retains surface/UV authority, prepared
coordinate maps and exact spatial composition. General affine images of retained
rotation curves preserve the full shear/sweep/replay fixture. Archive 12 adds
that curve carrier and rejects earlier versions. Continue with complete selected
section restrictions and branch/event replay, retaining the original complete
interior-loop success assertion. Selected angular images, general procedural
profiles, full resource bounds and release/push gates remain open.

'''+marker,1);p.write_text(s)
p=R/'crates/hyperbrep/README.md';s=p.read_text();s+='''

Selected joint UV evaluation supports planes, positive-weight Bézier/NURBS
tensor patches and extrusions of native line/Bézier/NURBS profiles. Returned
`GeometricPoint3` values retain their source and selectors for exact comparisons,
conservative bounds, affine transforms, sweep origins and checked replay.
`Curve3::affine_image` preserves an original spatial curve under an invertible
affine matrix, including sheared retained rotation curves. Archive 12 is a
breaking format; previous versions are rejected without compatibility adapters.
Selected angular/general procedural evaluation and complete surface-section
arrangements remain open. See the [capability and evidence record](docs/'''+link+''').
''';p.write_text(s)
