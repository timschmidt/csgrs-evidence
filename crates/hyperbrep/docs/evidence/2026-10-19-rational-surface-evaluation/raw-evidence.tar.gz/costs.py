import run
(run.OUT/'costs').mkdir(exist_ok=True)
for repeat in range(3):
    sides=['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']
    for side in sides+['new']:
        label='cost-'+side+'-'+str(repeat)
        assert run.run({'label':label,'source_scope':'frozen main ac81b38f110bdaa4f1eab48ad3836175177e583b' if side=='baseline' else 'qualified candidate',
             'command':['python3','-B',str(run.OUT/'measure.py'),str(run.OUT/'costs'/(label+'.json')),'taskset','-c','0',str(run.OUT/'bin'/side),'measure'],
             'seconds':2400})==0
