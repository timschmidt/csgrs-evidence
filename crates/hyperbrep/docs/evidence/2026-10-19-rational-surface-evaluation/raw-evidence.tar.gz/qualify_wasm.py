import run
O=run.OUT
assert run.run(dict(label='final-wasm-build',command=['cargo','build','--offline','--release','--target','wasm32-unknown-unknown','--manifest-path',str(O/'consumer/Cargo.toml'),'--lib'],env={'CARGO_TARGET_DIR':'/tmp/hyperbrep-review-wasm-target'},seconds=3600))==0
assert run.run(dict(label='final-wasm-run',command=['python3','-B',str(O/'wasm_consumer.py'),'/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_rational_surface_consumer.wasm','10',str(O/'wasm-exports.json')],seconds=1800))==0
