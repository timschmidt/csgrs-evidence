from pathlib import Path
import copy,hashlib,json,shutil,subprocess,tarfile
import run
R=run.ROOT;O=run.OUT;D=R/'crates/hyperbrep/docs/evidence/2026-10-19-rational-surface-evaluation'
assert not D.exists(), 'Do not rerun after evidence has been copied'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
v=json.loads((O/'verification.json').read_text());source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
tests=json.loads((O/'test-summary.json').read_text());full=tests['final-brep-release-tests-2'];cost=json.loads((O/'cost-analysis.json').read_text());art=json.loads((O/'archive-comparison.json').read_text());sizes=json.loads((O/'binary-sizes.json').read_text())
ratios=[r['latency_ratio'] for r in cost['phase_medians']]
q=(f"All-feature release BRep/IO suites pass {full['passed']} tests in {full['batches']} batches, with no failures or ignored tests. Focused Hypersolve basis/field and Hypercurve rational-query, selected-point/fiber and work-budget regressions pass; counts and commands are in test-summary.json. All-target/all-feature Clippy for Hypersolve, Hypercurve, BRep and IO, rustdoc with warnings denied, BRep fuzz-target compilation and formatting pass. Twelve shared public acceptance functions run in ten native groups and ten actual zero-import Wasmtime exports. Coverage includes rational Bézier/NURBS tensors with weighted and unweighted joint UVs, native line/Bézier/NURBS extrusions, both NURBS spans, internal/final knots and shifted original knot coordinates, independent field identities, exact poles and 1e-12 separation, affine rotation/translation edge composition, source lifetime, strict/approximate/strict and budget refusal/recovery, malformed archives and nested predecode admission. "
   f"All {art['preserved_files']} prior archive payloads match byte-for-byte after only the declared version-header migration; {art['new_files']} new archive files retain {art['new_unique_payloads']} distinct payloads. Semantic assertions, validation and cold replay are checked separately. The original full interior-loop success assertion still fails with UnsupportedIntersection on baseline and candidate and remains unchanged.")
p=(f"Three alternating CPU-0 pinned process pairs each measure six complete preserved workflows and three unchanged plane/pcurve workflows; three absolute processes measure ten new acceptance groups. Every invocation retains assertions, materialization, required validation and replay, with first and three repeated fresh-input phases. Median paired latency ratios range from {min(ratios):.6f} to {max(ratios):.6f}; {cost['increased_allocation_rows']} of {len(cost['pairs'])} paired rows increase Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. Maximum measured process RSS is {cost['maximum_rss_kib']} KiB. The matched executable changes by {sizes['candidate']['bytes']-sizes['baseline']['bytes']:+d} bytes; the plane/pcurve cost executable changes by {sizes['prior-cost-candidate']['bytes']-sizes['prior-cost-baseline']['bytes']:+d} bytes. The three prior plane/pcurve recipes request 680, 48 and 48 additional Rust allocation bytes per invocation respectively, with unchanged allocation counts. All adverse rows are retained. Shared-host timings establish no speedup; requested allocation traffic is not live heap and excludes foreign allocators. New successful contracts have no previous successful timing baseline. The prior domains/admission recipe is excluded only from matched costs because its candidate assertions expand the successful contract; complete original correctness recipes and drivers are retained. Per-point prepared rational maps add owned coefficient storage; no global cache is added. Source lifetime and scalar-basis units have no separate matched allocation campaign.")
limits=("Selected angular surfaces, general retained procedural extrusion profiles, full selected section restrictions and branch/event persistence, general section/trim arrangements and the original interior-loop target remain open. Explicit affine curve images preserve supported source operations, with typed coefficient/intersection limitations; native conic model transforms retain their previous metric restriction. An attempted automatic native-conic fallback was rejected because a transformed cylinder returned success but cold replay rejected its plane/curve image agreement. Archive 12 rejects versions through 11 without a compatibility decoder. Existing source-bound scalar/solver counters, fixed basis precision and archive quotas do not bound total work, live heap, stack or cancellation. Source-path native/WASM validation does not establish installed distributions or published bindings. Runtime fuzz/ASan/lexicase, formal proofs, measured coverage, MSRV, full release/workflow and push gates remain unqualified. All 28 work packages remain open/in-progress. The eaa0cae54 push exception is already consumed; this increment is not pushed.")
report=dict(increment='rational-surface-evaluation-2026-10-19',baseline=source['baseline'],complete=False,retained=True,qualification=q,cost_evidence=p,limits=limits,archive_version=12,source_files=len(source['files']))
write(O/'report.json',report)
write(O/'ideas.json',[
 dict(idea='Original-source rational query forms',status='kept',evidence='Owner pole, independent-field, replay, policy and budget tests plus shared native/WASM execution; original denominators cannot cancel away.'),
 dict(idea='Shared native Bernstein and original-coordinate B-spline arithmetic',status='kept',evidence='Existing bounded-degree Bernstein routine is byte-identical; degree-80 identities, nonuniform 2..5 knots, field homogenization and final BRep knot-domain consumers pass.'),
 dict(idea='Point-owned prepared tensor coefficient maps',status='kept',evidence='Exact weighted/unweighted identities, source lifetime, complete shear/sweep/replay fixture, all adverse cost rows retained. Added coefficient storage is explicit.'),
 dict(idea='Generic affine source carrier with composed matrices',status='kept',evidence='All eight existing source families, derivatives, domain operations, bounds, inverse queries where supported, regular periods, invalid matrices, nested admission and repeated replay. Retained rotation model fallback closes the original tensor fixture.'),
 dict(idea='Automatic native-conic model fallback',status='rejected',evidence='candidate-unrequested-conic-fallback-2: nonuniform cylinder transform returned success and volume 4200π, but cold replay failed UnsupportedEdgeUseAgreement. Original rejection fixture retained unchanged.'),
 dict(idea='Additional scalar-chart field implementation',status='already-satisfied',evidence='owner-scalar-chart-blocker passed through the existing recursive authority. No separate chart reconstruction or dummy curve was introduced.'),
 dict(idea='Box the raw affine archive definition',status='kept',evidence='Avoid a sixteen-scalar matrix in every raw curve record; final all-target Clippy and paired whole-workflow resource records use the boxed layout. JSON remains the same.'),
 dict(idea='Independent coordinate-root reconstruction or a floating surrogate',status='architecture-inapplicable',evidence='Would replace joint source authority or demote exact topology; no such representation is used.'),
])
(O/'next-domains.md').write_text('''# Next implementation domains

Continue WP05a/WP05b/WP06 with complete selected surface-section restrictions and branch/event replay. `geometry/surface_point.rs` now owns a joint UV point boundary; `surface_point/rational.rs` prepares rational maps and Hypercurve owns rational source queries. Reuse this authority for whole section carriers without substituting independently reconstructed coordinates or sampled contours. Preserve both original surface charts and source parameter identity through every restriction, inverse query, trim and replay.

Keep the original complete interior-loop success assertion in `interior/baseline` and `interior/candidate` unchanged. Both still report UnsupportedIntersection. Point evaluation and scalar image identities are prerequisites, not completed surface arrangements. Selected angular surfaces and general procedural extrusion profiles remain separate typed boundaries.

The affine curve carrier now preserves sheared retained rotation edges. Complete native conic face-image agreement before enabling automatic general affine conic model transport. The rejected nonuniform cylinder succeeds numerically but fails cold replay with UnsupportedEdgeUseAgreement; retain that probe and the original negative control. Do not publish a partially replayable model as complete.

Preserve all prior exact workflows, version migrations, malformed-input and policy/budget controls, original full fixtures and adverse cost samples. Native and actual WASM consumers must exercise the same complete new contracts. Keep installation, MSRV, bindings, whole-work/resource bounds, directed fuzz/ASan/lexicase, coverage/formal and full repository push gates explicitly open until separately qualified. Respect surrounding-crate ownership and concurrently developed upstream fixes.
''')
(O/'README.md').write_text('# Source-bound rational surface evaluation and affine curve images\n\n'+q+'\n\n'+p+'\n\n'+limits+'''

`contract.md` states the pre-implementation owners, domain and composition requirement. `source-migration-audit.json` verifies unchanged represented surface evaluation and the existing bounded-degree Bernstein converter. `verification.json`, `test-summary.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate exact semantics, replay, artifacts and costs.

`raw-evidence.tar.gz` retains commands, logs, source patches, failure history, external consumer manifests/locks/recipes, native archives and raw timing/allocation/RSS rows. It excludes executables and caches. Commands use external time containment. Adjust local source/cache paths when reproducing in a fresh output directory; never rerun the snapshot runner after copying its evidence into the repository.

Baseline probes reproduce missing rational owner API, unsupported selected tensor evaluation and unsupported retained-rotation shear. Early compilations exposed test accessor/type mistakes and a closure result annotation; all raw failures remain. The first full BRep/IO run reports 756 passing tests and one unchanged conic-transform rejection failure. The standalone probe shows the resulting incomplete replay, so the automatic native-conic fallback is removed instead of weakening that fixture. An initial library field-test filter matched zero tests; the final field run instead executes the public retained-image and bivariate-topology regression targets. The final source boxes the raw affine definition and strengthens derivative, nonunit-knot and field/resource coverage. Archive migration changes only three cone fixture version headers; all original geometry bytes remain intact.
''')
# Append one increment without claiming a work package complete.
sp=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json';status=json.loads(sp.read_text());before=copy.deepcopy(status)
status['increments'].append(dict(id=report['increment'],work_packages=['WP02','WP05a','WP05b','WP06','WP13','WP21'],properties=['P1','P4','P5','P6','P8','P9','P15','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],change='Retain joint rational Bézier/NURBS/extrusion surface points, exact source-bound rational queries and affine images of retained rotation curves through model composition and archive 12 replay.',sources=['../src/geometry/surface_point/rational.rs','../src/geometry/affine_image.rs','../src/geometry/point.rs','../../hypercurve/src/curve_point/rational.rs','../../hypercurve/src/bezier_offset/rational_form.rs','../../hypersolve/src/curve_substitution/basis.rs','../tests/support/rational_surface_evaluation.rs','../tests/support/affine_curve_images.rs'],evidence='evidence/2026-10-19-rational-surface-evaluation/manifest.json',validation=q,cost_evidence=p,limits=limits))
status['next_actions'].insert(0,'Continue WP05a/WP05b from evidence/2026-10-19-rational-surface-evaluation/next-domains.md. Joint rational tensor/extrusion point images now survive affine rotation/translation edge composition and archive 12 replay. Full selected section restrictions, branch/event graphs and the unchanged interior-loop success target remain open. Preserve the native-conic cold-replay blocker before enabling automatic conic affine model transport, all prior fixtures and adverse cost evidence.')
assert status['increments'][:-1]==before['increments'] and status['work_packages']==before['work_packages'] and not status['complete'];write(sp,status)
# Preserve every root ledger byte outside current_work.hyperbrep.
lp=R/'docs/properties-status.json';text=lp.read_text();ledger=json.loads(text);entry=ledger['current_work']['hyperbrep']
entry.update(latest_implementation=report['increment'],latest_feature_evidence='crates/hyperbrep/docs/evidence/2026-10-19-rational-surface-evaluation/manifest.json',latest_evidence='crates/hyperbrep/docs/evidence/2026-10-19-rational-surface-evaluation/manifest.json',qualification=q,performance_evidence=p,limits=limits,latest_update_check='crates/hyperbrep/docs/evidence/2026-10-19-rational-surface-evaluation/upstream-check.json')
decoder=json.JSONDecoder()
def ws(s,p):
 while s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;lp.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()))
post=[]
for name,command in [('fmt',['cargo','fmt','--all','--','--check']),('fuzz-fmt',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check']),('diff',['git','diff','--check'])]:
 result=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True);(O/('post-doc-'+name+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0,(name,result.stderr);post.append(dict(name=name,command=command,exit_code=0))
assert all(sha(R/p)==h for p,h in source['files'].items());write(O/'post-documentation-checks.json',dict(checks=post,qualified_source_unchanged=True))
D.mkdir()
for name in ['README.md','contract.md','next-domains.md','report.json','ideas.json','candidate-source.json','baseline-source.json','verification.json','test-summary.json','archive-comparison.json','cost-analysis.json','binary-sizes.json','environment.json','upstream-check.json','source-migration-audit.json','consumer-source-scope.json','fixture-migration.json','ledger-scope.json','post-documentation-checks.json','implementation-notes.md','research.json']:
 shutil.copy(O/name,D/name)
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
 for p in sorted(O.rglob('*')):
  if p.is_file() and not p.is_symlink() and (p.suffix in {'.json','.log','.patch','.py','.rs','.toml','.md'} or p.name=='Cargo.lock'):
   tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
write(D/'manifest.json',dict(increment=report['increment'],baseline=source['baseline'],source_files=len(source['files']),complete=False,retained=True,no_push=True,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file()}))
print(json.dumps(dict(evidence=str(D),increment_count=len(status['increments']),qualification=q,cost_evidence=report['cost_evidence']),indent=2))
