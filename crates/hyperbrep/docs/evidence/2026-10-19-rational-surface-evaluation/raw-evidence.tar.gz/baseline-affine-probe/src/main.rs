use hyperbrep::*;
fn main() {
    let curve = Curve3::rotation(Point3::new(1.into(), 0.into(), 0.into()).into(),
        Point3::origin(), Vector3::z(), 0.into(), (Real::pi()/Real::from(2)).unwrap()).unwrap();
    let mut builder = ModelBuilder::new();
    let a=builder.vertex(curve.point_at(curve.domain().start()).unwrap()).unwrap();
    let b=builder.vertex(curve.point_at(curve.domain().end()).unwrap()).unwrap();
    let range=curve.domain().clone();
    let c=builder.curve(curve).unwrap();
    builder.edge(&a,&b,&c,range).unwrap();
    let matrix=Matrix4::from_row_major([(-1).into(),2.into(),0.into(),4.into(),
        0.into(),1.into(),0.into(),(-2).into(),0.into(),0.into(),1.into(),1.into(),
        0.into(),0.into(),0.into(),1.into()]);
    builder.finish().unwrap().transformed(&matrix).expect("invertible affine image must remain consumable");
}
