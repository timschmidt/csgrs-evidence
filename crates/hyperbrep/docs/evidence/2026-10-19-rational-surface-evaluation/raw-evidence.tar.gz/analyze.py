from pathlib import Path
import hashlib,json,re,statistics,subprocess
import run
O=run.OUT;R=run.ROOT;B=Path('/mnt/development/csgrs')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==source['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
rows=json.loads((O/'results.json').read_text());checks={r['label']:r for r in rows}
assert len(rows)==len(checks)
required=['final-affected-clippy','final-owner-clippy','final-solver-maps','final-solver-basis-regressions','final-solver-public-field-regressions','final-owner-rational-regressions','final-brep-release-tests-2','final-affected-rustdoc','final-brep-fuzz-check','final-fmt-check','final-fuzz-fmt','final-wasm-build','final-wasm-run','new-native-build','new-native-archives']
required += [f'{side}-{family}-{mode}' for side in ['baseline','candidate'] for family in ['preserved','prior'] for mode in ['build','archives']]
required += [f'{side}-prior-cost-build' for side in ['baseline','candidate']]
for label in required:assert checks[label]['exit_code']==0,(label,checks[label]['exit_code'])
for label in ['baseline-selected-tensor-offline','baseline-owner-missing-api','baseline-retained-rotation-shear','baseline-original-interior-loop','candidate-original-interior-loop']:
 assert checks[label]['exit_code']==101,label
for side in ['baseline','candidate']:assert 'UnsupportedIntersection' in (O/(side+'-original-interior-loop.log')).read_text()
for row in rows:
 assert sha(Path(row['log']))==row['log_sha256']
 assert sha(Path(row['source_patch']))==row['source_patch_sha256']
summary={}
for label in [l for l in required if 'tests-' in l or 'regressions' in l or l=='final-solver-maps']:
 counts=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/(label+'.log')).read_text())]
 assert counts,label
 summary[label]=dict(passed=sum(r[0] for r in counts),failed=sum(r[1] for r in counts),ignored=sum(r[2] for r in counts),batches=len(counts))
 assert summary[label]['failed']==0
write('test-summary.json',summary)
artifacts={}
for group in ['baseline','candidate','fibers-baseline','fibers-candidate','prior-baseline','prior-candidate','new']:
 artifacts[group]={str(p.relative_to(O/'artifacts'/group)):sha(p) for p in sorted((O/'artifacts'/group).glob('*.json'))}
comparisons=[]
for prefix in ['', 'fibers-','prior-']:
 assert artifacts[prefix+'baseline'] and artifacts[prefix+'baseline'].keys()==artifacts[prefix+'candidate'].keys()
 for name in artifacts[prefix+'baseline']:
  a=(O/'artifacts'/(prefix+'baseline')/name).read_bytes();b=(O/'artifacts'/(prefix+'candidate')/name).read_bytes()
  assert a.startswith(b'{"version":11,') and b.startswith(b'{"version":12,')
  assert a.replace(b'{"version":11,',b'{"version":12,',1)==b,(prefix,name)
  comparisons.append(dict(group=prefix or 'models',name=name,baseline_sha256=hashlib.sha256(a).hexdigest(),candidate_sha256=hashlib.sha256(b).hexdigest(),identical_after_version_only=True))
assert len(comparisons)==233,len(comparisons)
assert artifacts['new']
write('archive-comparison.json',dict(preserved_files=len(comparisons),new_files=len(artifacts['new']),new_unique_payloads=len(set(artifacts['new'].values())),comparisons=comparisons,files=artifacts,contract='Archive 12 migration permits only the top-level 11→12 header for prior artifacts. Every other byte must match. Exact semantic assertions and cold replay are checked separately. Prior domain/admission tests include newly successful evaluation controls and are not matched cost workloads.'))
raw=[];pairs=[];rss=[]
for family in ['', 'prior-']:
 for repeat in range(3):
  per={}
  for side in (['baseline','candidate','new'] if not family else ['baseline','candidate']):
   label=f'cost-{family}{side}-{repeat}';assert checks[label]['exit_code']==0
   samples=[json.loads(l) for l in (O/(label+'.log')).read_text().splitlines() if l.startswith('{')]
   data=[r for r in samples if 'case' in r];assert len(data)==(6 if family else 20 if side=='new' else 12),(label,len(data))
   per[side]={(r['case'],r['phase']):r for r in data}
   if family:assert set(r['case'] for r in data)=={'joint_plane_images','policy_recovery','pcurve_surface_images'}
   raw.append(dict(family=family or 'preserved',repeat=repeat,side=side,rows=samples))
   resource=json.loads((O/'costs'/(label+'.json')).read_text());assert resource['exit_code']==0
   rss.append(dict(label=label,**resource))
  assert per['baseline'].keys()==per['candidate'].keys()
  for key,a in per['baseline'].items():
   b=per['candidate'][key];assert a['iterations']==b['iterations'] and a['outcome']==b['outcome']
   pairs.append(dict(repeat=repeat,case=key[0],phase=key[1],ratio=b['elapsed_ns']/a['elapsed_ns'],allocation_call_delta=b['allocation_calls']-a['allocation_calls'],requested_byte_delta=b['requested_bytes']-a['requested_bytes'],iterations=a['iterations']))
assert len(pairs)==54
medians=[]
for case,phase in sorted({(r['case'],r['phase']) for r in pairs}):
 vals=[r for r in pairs if (r['case'],r['phase'])==(case,phase)]
 medians.append(dict(case=case,phase=phase,latency_ratio=statistics.median(r['ratio'] for r in vals),allocation_call_deltas=[r['allocation_call_delta'] for r in vals],requested_byte_deltas=[r['requested_byte_delta'] for r in vals]))
assert len(medians)==18
write('cost-analysis.json',dict(scope='Three alternating CPU-0 pinned process pairs each for six complete preserved workflows and three unchanged plane/pcurve workflows; three absolute processes for ten new workflows. Every invocation includes assertions, output materialization, required topology validation and replay. First and three repeated fresh-input invocations are separate phases, not an eviction campaign. The prior domains_and_admission recipe is excluded only from matched costs because the candidate expands its success controls; the complete original correctness recipes still run.',raw_samples=raw,pairs=pairs,phase_medians=medians,process_resources=rss,maximum_rss_kib=max(r['maximum_rss_kib'] for r in rss),increased_allocation_rows=sum(r['allocation_call_delta']>0 for r in pairs),increased_byte_rows=sum(r['requested_byte_delta']>0 for r in pairs),limits='Rust allocation counts and requested traffic exclude foreign allocators and are not live heap. Shared-host timings establish no speedup. New successful contracts lack a previous successful timing baseline. Unit-level source lifetime, scalar basis conversion and malformed source controls are not separate matched performance campaigns.'))
binaries={side:dict(bytes=(O/'bin'/side).stat().st_size,sha256=sha(O/'bin'/side)) for side in ['baseline','candidate','new','prior-baseline','prior-candidate','prior-cost-baseline','prior-cost-candidate']}
w=Path('/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_rational_surface_consumer.wasm');binaries['wasm']=dict(bytes=w.stat().st_size,sha256=sha(w));write('binary-sizes.json',binaries)
fixture=[]
for name in ['cone-imported-lower.json','cone-imported-band.json','cone-rational-partition.json']:
 p='crates/hyperbrep/tests/fixtures/'+name;a=(B/p).read_bytes();b=(R/p).read_bytes();assert a.replace(b'{"version":11,',b'{"version":12,',1)==b
 fixture.append(dict(path=p,before_sha256=sha(B/p),after_sha256=sha(R/p),only_version_header_changed=True))
write('fixture-migration.json',fixture)
# Only original source definitions and explicit format headers may change in preserved fixtures.
assert (B/'crates/hyperbrep/tests/support/similarity.rs').read_bytes()==(R/'crates/hyperbrep/tests/support/similarity.rs').read_bytes()
for family in ['preserved','prior','prior-original']:
 a=(O/family/'baseline');b=(O/family/'candidate')
 for p in a.glob('*.rs'):
  assert p.read_text().replace('/mnt/development/csgrs/','/mnt/development/csgrs/target/hyperbrep-development/')==(b/p.name).read_text(),(family,p.name)
# Verify the three additionally measured recipes remain byte-identical.
def rust_function(source,name):
 start=source.index('pub fn '+name+'(');opening=source.index('{',start);level=1;end=opening+1
 while level:
  level += (source[end]=='{')-(source[end]=='}');end+=1
 return source[start:end]
old=(B/'crates/hyperbrep/tests/support/surface_evaluation.rs').read_text();new=(R/'crates/hyperbrep/tests/support/surface_evaluation.rs').read_text()
for name in ['joint_plane_images_compose_and_replay','selected_surface_policy_and_recovery']:
 assert rust_function(old,name)==rust_function(new,name),name
assert (B/'crates/hyperbrep/tests/support/pcurve_evaluation.rs').read_bytes()==(R/'crates/hyperbrep/tests/support/pcurve_evaluation.rs').read_bytes()
write('consumer-source-scope.json',dict(matched_recipes=True,files={str(p.relative_to(O)):sha(p) for family in ['consumer','preserved','prior','prior-original','interior'] for p in (O/family).rglob('*') if p.is_file() and (p.suffix in {'.rs','.toml'} or p.name=='Cargo.lock')},scope='Clean external source-path projects. No workspace patches; not installed registry distributions. All ten exports execute the same shared recipes as the native consumer. Three unchanged plane/pcurve workflows are cost-paired. The domains_and_admission recipe is excluded only from matched costs because previously unsupported evaluation controls become successes; all original correctness recipes still run. Original and cost-selection consumer drivers are retained separately.'))
write('verification.json',dict(required_checks=required,source_hashes_match=True,source_files=len(source['files']),baseline_clean=True,baseline_revision=source['baseline'],raw_logs_and_patches_match=True,only_version_migration_for_prior_artifacts=True,original_conic_rejection_fixture_unchanged=True,original_interior_loop_success_assertion_preserved=True,upstream_observation=json.loads((O/'upstream-check.json').read_text()),no_push=True))
print(json.dumps(dict(tests=summary,archives=len(comparisons),new_archives=len(artifacts['new']),ratio_range=[min(r['latency_ratio'] for r in medians),max(r['latency_ratio'] for r in medians)],binaries=binaries),indent=2))
