from pathlib import Path
R=Path('/mnt/development/csgrs/target/hyperbrep-development')
p=R/'crates/hyperbrep/src/persistence.rs';s=p.read_text()
a="""    AffineImage {
        source: Box<RawCurve3>,
        transform: [[Real; 4]; 4],
    },""";assert a in s;s=s.replace(a,'    AffineImage(Box<RawAffineCurve3>),')
a='#[derive(Clone, Debug, Deserialize, Serialize)]\nstruct RawRotationCurve3';assert a in s;s=s.replace(a,'#[derive(Clone, Debug, Deserialize, Serialize)]\nstruct RawAffineCurve3 {\n    source: RawCurve3,\n    transform: [[Real; 4]; 4],\n}\n\n'+a)
a="""        Curve3ExactData::AffineImage(image) => RawCurve3::AffineImage {
            source: Box::new(raw_curve3(image.source.exact_data(), graph)?),
            transform: image.transform.0,
        },""";assert a in s;s=s.replace(a,"""        Curve3ExactData::AffineImage(image) => RawCurve3::AffineImage(Box::new(RawAffineCurve3 {
            source: raw_curve3(image.source.exact_data(), graph)?,
            transform: image.transform.0,
        })),""")
a='        RawCurve3::AffineImage { source, transform } => {';assert a in s;s=s.replace(a,a.replace('{ source, transform }','(image)')+'\n            let RawAffineCurve3 { source, transform } = *image;').replace('Curve3::affine_image(\n                curve3(*source, graph)?,','Curve3::affine_image(\n                curve3(source, graph)?,');p.write_text(s)
p=R/'crates/hyperbrep/tests/support/affine_curve_images.rs';s=p.read_text()
a='        let bounds = image.bounds().unwrap();';assert a in s;s=s.replace(a,a+"""
        for order in [1,2,5] {
            let at=source.domain().start().try_real().unwrap();
            let derivative=source.derivative_at(at,order).unwrap();
            let d=derivative.vector();
            assert_eq!(image.derivative_at(at,order).unwrap().vector(), &Vector3::new([-&d[0]+Real::from(2)*&d[1],d[1].clone(),d[2].clone()]));
        }
""")
a="""        if matches!(
            source.kind(),
            Curve3Kind::Line
                | Curve3Kind::RationalBezier
                | Curve3Kind::Nurbs
                | Curve3Kind::PlanarImage
        ) {""";assert a in s;s=s.replace(a,'        if !matches!(source.kind(), Curve3Kind::Rotation | Curve3Kind::Translation) {');p.write_text(s)
p=R/'crates/hyperbrep/tests/support/rational_surface_evaluation.rs';s=p.read_text();s=s.replace('pub fn nurbs_second_span_and_final_endpoint() {','pub fn nurbs_second_span_and_final_endpoint() {\n    original_nonunit_knot_coordinates();')
s+='''

fn original_nonunit_knot_coordinates() {
    let uv=point_recipe::joint_uv();
    let shifted=hypercurve::Curve2::try_line(uv.clone(),hypercurve::Point2::from_values(0,0).into()).unwrap()
        .transform_similarity(&hypercurve::Similarity2::try_from_real_affine(1.into(),0.into(),0.into(),1.into(),2.into(),0.into()).unwrap()).unwrap().start();
    let controls=(0..4).map(|j|[Real::zero(),Real::zero(),q(1,2),Real::one()].into_iter().map(|x| {
        let y=Real::from(if j==3 {16} else {0});Point3::new(x.clone(),y.clone(),x+y)
    }).collect()).collect();
    let surface=Surface::nurbs(2,3,controls,vec![vec![Real::one();4];4],
        vec![2.into(),2.into(),2.into(),q(5,2),3.into(),3.into(),3.into()],
        vec![0.into(),0.into(),0.into(),0.into(),1.into(),1.into(),1.into(),1.into()]).unwrap();
    let actual=surface.point_at(&shifted).unwrap();
    assert!(actual.coincides_with(&tensor(true,false).point_at(&uv).unwrap()).unwrap());
    assert_eq!(actual.compare_linear_form(&Vector3::x(),&q(1,8)).unwrap(),Ordering::Equal);
    actual.bounds().unwrap();
    let mut builder=ModelBuilder::new();builder.vertex(actual).unwrap();replay(&builder.finish().unwrap());
}
''';p.write_text(s)

p=R/'crates/hyperbrep/src/geometry.rs';s=p.read_text();a="""                let (x, y, scale) = match metric.arc_frame(&arc.x, &arc.y) {
                    Err(GeometryError::UnsupportedTransform) => {
                        return Self::affine_image(self.clone(), transform.clone());
                    }
                    result => result?,
                };""";assert a in s;s=s.replace(a,'                let (x, y, scale) = metric.arc_frame(&arc.x, &arc.y)?;');p.write_text(s)
