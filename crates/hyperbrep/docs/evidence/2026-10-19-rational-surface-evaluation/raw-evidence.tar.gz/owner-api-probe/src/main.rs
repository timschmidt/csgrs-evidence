fn main() {
 let point:hypercurve::CurvePoint2=hypercurve::Point2::from_values(1,2).into();
 let polynomial=hypersolve::BivariatePolynomial::new(vec![vec![1.into()]]);
 let _ = point.rational_form(polynomial.clone(),polynomial).unwrap();
}
