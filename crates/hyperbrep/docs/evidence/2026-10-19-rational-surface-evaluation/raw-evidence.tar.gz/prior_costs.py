from pathlib import Path
import run, shutil
O=run.OUT
for side in ['baseline','candidate']:
 pkg='hyperbrep-rational-prior-'+side
 assert run.run(dict(label=side+'-prior-cost-build',command=['cargo','build','--offline','--release','--manifest-path',str(O/'prior'/side/'Cargo.toml'),'--bin',pkg],seconds=2400))==0
 shutil.copy(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,O/'bin'/('prior-cost-'+side))
for repeat in range(3):
 sides=['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']
 for side in sides:
  label='cost-prior-'+side+'-'+str(repeat)
  assert run.run(dict(label=label,source_scope='frozen main ac81b38f110bdaa4f1eab48ad3836175177e583b' if side=='baseline' else 'qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','0',str(O/'bin'/('prior-cost-'+side)),'measure-common'],seconds=2400))==0
