use hyperbrep::*;
use hypercurve::{BezierAlgebraicParameter2, BezierParameter2, BezierParameterInterval, BezierParameterPolynomial, CurvePointDefinition2};
use hypersolve::{BivariatePolynomial, IsolatedRootInterval};
fn q(a: i32,b: i32)->Real {(Real::from(a)/Real::from(b)).unwrap()}
fn main() {
 let uv=CurvePointDefinition2::PolynomialFiber {
  equation:BivariatePolynomial::new(vec![vec![0.into(),0.into(),0.into(),16.into()],vec![(-1).into()]]),
  parameter:BezierParameter2::Algebraic(BezierAlgebraicParameter2::try_isolate(
   BezierParameterPolynomial::try_new_power_basis(vec![q(-1,8),0.into(),1.into()]).unwrap(),
   BezierParameterInterval::try_new(q(1,3),q(1,2)).unwrap()).unwrap()),
  root:IsolatedRootInterval {lower:q(1,4),upper:q(3,8),exact_root:None,distinct_root_count:1},
 }.into_point().unwrap();
 let controls=(0..3).map(|j|(0..3).map(|i|Point3::new(q(i,2),q(j,2),Real::from(i32::from(i==2)+i32::from(j==2)))).collect()).collect();
 let surface=Surface::rational_bezier(controls,vec![vec![1.into();3];3]).unwrap();
 let image=surface.point_at(&uv).expect("a joint selected UV must retain its exact rational tensor surface image");
 assert!(image.surface_source().is_some());
}
