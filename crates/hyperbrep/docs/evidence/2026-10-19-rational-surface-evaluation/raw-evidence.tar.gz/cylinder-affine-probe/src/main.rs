use hyperbrep::*;
fn main(){
 let source=builder::cylinder(5.into(),7.into()).unwrap();
 let map=Matrix4::affine_nonuniform_scale([2.into(),3.into(),4.into()]);
 match source.transformed(&map) {
  Err(error)=>println!("transform error: {error:?}"),
  Ok(solid)=>{
   println!("transform succeeded");
   println!("volume: {:?}",solid.model().solids().next().unwrap().volume());
   match solid.model().to_json(){
    Err(error)=>println!("archive encoding error: {error:?}"),
    Ok(json)=>match RawModel::from_json(&json,&ArchiveLimits::default()).unwrap().validate(){
     Err(error)=>println!("cold replay error: {error:?}"),Ok(_)=>println!("cold replay succeeded")
    }
   }
  }
 }
}
