//! Original quarter/band continuations, with independent exact expectations.
use hyperbrep::{BodySet, Matrix4, Model, Real, boolean, builder};
#[allow(dead_code)]
#[path = "seam_cuts.rs"]
mod seam;
use seam::{equal, point as p, ratio as q};

fn parent_kind(kind: usize) -> usize {
    match kind { 0 => 0, 1 | 3 => 1, 2 | 4 => 2, _ => unreachable!() }
}

pub fn fixture(kind: usize) -> (BodySet, BodySet, Real, Real) {
    let (source, first_cut, volume, area) = seam::fixture(parent_kind(kind));
    let half = boolean::intersection(&source, &first_cut).unwrap();
    let cutter = if kind < 3 {
        builder::cuboid(p(-20, 0, -20), p(20, 20, 20))
    } else {
        builder::cuboid(p(-20, -20, 1), p(20, 20, 20))
    }.unwrap();
    (half, cutter, volume, area)
}

fn expected(kind: usize, difference: bool) -> (Real, Real) {
    let pi = Real::pi();
    let pi2 = &pi * &pi;
    let sqrt3 = Real::from(3).sqrt().unwrap();
    let sqrt5 = Real::from(5).sqrt().unwrap();
    match kind {
        0 => (Real::from(10) * &pi2, Real::from(10) * pi2 + Real::from(24) * pi),
        1 => (Real::from(10) * &pi2, Real::from(10) * pi2 + Real::from(8) * pi),
        2 => (q(39,2) * &pi, (Real::from(29) + Real::from(21) * sqrt5) * &pi * q(1,4) + Real::from(42)),
        3 if !difference => (Real::from(5) * &pi * (q(4,3) * &pi - &sqrt3),
            q(20,3) * pi2 + Real::from(10) * &pi * &sqrt3 + q(8,3) * pi - Real::from(2) * sqrt3),
        3 => (Real::from(20) * &pi2 - Real::from(5) * &pi * (q(4,3) * &pi - &sqrt3),
            q(40,3) * pi2 + Real::from(10) * &pi * &sqrt3 + q(16,3) * pi + Real::from(2) * sqrt3),
        4 if !difference => (q(665,24) * &pi, (Real::from(97) + Real::from(65) * sqrt5) * pi * q(1,8) + q(65,2)),
        4 => (q(271,24) * &pi, (Real::from(181) + Real::from(19) * sqrt5) * pi * q(1,8) + q(19,2)),
        _ => unreachable!(),
    }
}

fn measures(model: &Model, volume: &Real, area: &Real) {
    assert_eq!(model.solids().count(), 1);
    equal(&model.solids().next().unwrap().volume().unwrap(), volume);
    equal(&model.faces().map(|f| f.area().unwrap()).fold(Real::zero(), |a,b| a+b), area);
    for edge in model.edges() {
        let uses: Vec<_> = edge.uses().collect();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
}

fn check_output(result: &BodySet, volume: &Real, area: &Real) -> u64 {
    assert_eq!(result.len(), 1);
    let replay = seam::reload(result.model());
    for model in [result.model(), &replay] { measures(model, volume, area); }
    let edge = replay.edges().next().unwrap();
    let middle = ((edge.domain().start().try_real().unwrap() + edge.domain().end().try_real().unwrap()) / Real::from(2)).unwrap();
    let split = edge.split(middle.into()).unwrap();
    measures(&seam::reload(split.model()), volume, area);
    let transformed = split.model().transformed(&seam::similarity(&q(1,1000), true)).unwrap();
    measures(&seam::reload(&transformed), &(volume * q(1,1_000_000_000)), &(area * q(1,1_000_000)));
    result.model().to_json().unwrap().bytes().fold(0xcbf29ce484222325_u64, |h,b| (h ^ u64::from(b)).wrapping_mul(0x100000001b3))
}

pub fn workflow(kind: usize, map: &Matrix4, scale: &Real) -> u64 {
    let (half, cutter, parent_volume, parent_area) = fixture(kind);
    let half = half.transformed(map).unwrap();
    let cutter = cutter.transformed(map).unwrap();
    let scale2 = scale * scale;
    let scale3 = &scale2 * scale;
    let (volume, area) = expected(kind, false);
    let intersection = boolean::intersection(&half, &cutter)
        .unwrap_or_else(|e| panic!("kind={kind} intersection: {e:?}"));
    let mut receipt = check_output(&intersection, &(volume.clone() * &scale3), &(area.clone() * &scale2));
    let swapped = boolean::intersection(&cutter, &half)
        .unwrap_or_else(|e| panic!("kind={kind} swapped: {e:?}"));
    receipt ^= check_output(&swapped, &(volume * &scale3), &(area * &scale2));
    let difference = boolean::difference(&half, &cutter)
        .unwrap_or_else(|e| panic!("kind={kind} difference: {e:?}"));
    let (volume, area) = expected(kind, true);
    receipt = receipt.wrapping_mul(0x100000001b3) ^ check_output(&difference, &(volume * &scale3), &(area * &scale2));
    let first = seam::reload(intersection.model());
    let second = seam::reload(difference.model());
    let first = BodySet::from_solid(first.solids().next().unwrap());
    let second = BodySet::from_solid(second.solids().next().unwrap());
    for (a,b) in [(&first,&second), (&second,&first)] {
        let restored = boolean::union(a,b).unwrap_or_else(|e| panic!("kind={kind} reconstruct: {e:?}"));
        receipt = receipt.wrapping_mul(0x100000001b3) ^ check_output(&restored, &(parent_volume.clone() * &scale3), &(parent_area.clone() * &scale2));
    }
    let empty = boolean::difference(&intersection, &cutter).unwrap();
    assert_eq!(empty.model().to_json().unwrap(), BodySet::empty().model().to_json().unwrap());
    receipt
}

pub fn original(kind: usize) -> u64 { workflow(kind, &Matrix4::identity(), &Real::one()) }

pub fn transforms() -> (usize,u64) {
    let mut count = 0;
    let mut receipt = 0xcbf29ce484222325_u64;
    for scale in [q(1,1000), q(127,5000), Real::from(2).sqrt().unwrap()] {
        for reflected in [false,true] {
            for kind in 0..5 {
                receipt = receipt.wrapping_mul(0x100000001b3) ^ workflow(kind, &seam::similarity(&scale,reflected), &scale);
                count += 1;
            }
        }
    }
    (count,receipt)
}
