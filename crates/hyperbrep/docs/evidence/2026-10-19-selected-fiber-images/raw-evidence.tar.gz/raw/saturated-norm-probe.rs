use hypersolve::*;
fn p(rows: &[&[i64]]) -> BivariatePolynomial { BivariatePolynomial::new(rows.iter().map(|r| r.iter().copied().map(Into::into).collect()).collect()) }
fn main() {
 let mut root=AlgebraicRootRepresentation { constraint_index:0, symbol:SymbolId(0), interval_index:0,
 polynomial_coefficients:vec![(-2).into(),0.into(),1.into()], interval:IsolatedRootInterval {lower:1.into(),upper:2.into(),exact_root:None,distinct_root_count:1},
 validation:AlgebraicRootValidationReport{status:AlgebraicRootValidationStatus::Valid,message:None}};
 root.validation=validate_algebraic_root_representation(&root,PredicatePolicy::STRICT);
 let r=project_algebraic_fiber_rational_image_relation(&p(&[&[0,0,0,1],&[0,-1]]),CurveResultantParameter::First,&p(&[&[0,0,1],&[0,1]]),&p(&[&[0,1]]),&root,AlgebraicFiberPolynomialImageProjectionConfig{max_fiber_degree:8,max_retained_degree:8,max_image_degree_bound:8},PredicatePolicy::STRICT);
 println!("status={:?}",r.status);
 for (name,p) in [("relation",r.retained_relation),("factor",r.identically_zero_fiber_factor)] { println!("{}={:?}",name,p.unwrap().coefficients.iter().map(|r| r.iter().map(|v| v.exact_rational_normal_form().unwrap().to_string()).collect::<Vec<_>>()).collect::<Vec<_>>()); }
}
