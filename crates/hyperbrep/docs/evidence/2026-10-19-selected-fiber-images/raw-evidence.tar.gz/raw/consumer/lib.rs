include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn solver0() -> u32 { cases()[0].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn solver1() -> u32 { cases()[1].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn solver2() -> u32 { cases()[2].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn curve0() -> u32 { cases()[3].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn curve1() -> u32 { cases()[4].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn brep0() -> u32 { cases()[5].1(); 1 }
