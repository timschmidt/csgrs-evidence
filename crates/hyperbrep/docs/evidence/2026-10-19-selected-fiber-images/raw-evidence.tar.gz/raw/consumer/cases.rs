#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hypersolve/tests/support/retained_rational_images.rs"]
mod solver;
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hypercurve/tests/support/selected_fiber_images.rs"]
mod curve;
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/selected_fiber_images.rs"]
mod brep;
fn cases() -> [(&'static str, fn()); 6] { [
("mixed_images_keep_the_base_field_on_both_axes",solver::mixed_images_keep_the_base_field_on_both_axes),
("source_poles_and_zero_image_components_remain_explicit",solver::source_poles_and_zero_image_components_remain_explicit),
("rational_image_limits_and_budget_recovery",solver::rational_image_limits_and_budget_recovery),
("mixed_affine_parameters_replay_and_compose",curve::mixed_affine_parameters_replay_and_compose),
("conjugate_selection_similarity_and_policy_recovery",curve::conjugate_selection_similarity_and_policy_recovery),
("mixed_fiber_charts_survive_brep_archives_and_transforms",brep::mixed_fiber_charts_survive_brep_archives_and_transforms),
] }
