"""Record final documentation review without changing qualified implementation."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
import run

OUT=Path(__file__).resolve().parent
ROOT=run.ROOT
BASE=Path('/mnt/development/csgrs')
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-selected-fiber-images'

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

source=json.loads((DEST/'candidate-v3-source.json').read_text())
assert all(digest(ROOT/path)==expected for path,expected in source.items())
decoder=json.JSONDecoder()
def ws(text,pos):
    while text[pos].isspace():pos+=1
    return pos
def member(text,start,key):
    pos=ws(text,start);assert text[pos]=='{';pos=ws(text,pos+1)
    while text[pos]!='}':
        name,pos=decoder.raw_decode(text,pos);pos=ws(text,pos);assert text[pos]==':'
        begin=ws(text,pos+1);_,end=decoder.raw_decode(text,begin)
        if name==key:return begin,end
        pos=ws(text,end)
        if text[pos]==',':pos=ws(text,pos+1)
    raise KeyError(key)
def owner_span(text):
    pos,_=member(text,0,'current_work');return member(text,pos,'hyperbrep')
before=(BASE/'docs/properties-status.json').read_text()
after=(ROOT/'docs/properties-status.json').read_text()
a,b=owner_span(before);c,d=owner_span(after)
assert before[:a]==after[:c] and before[b:]==after[d:]

docs=['crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json','crates/hyperbrep/docs/DEVELOPMENT_PLAN.md',
      'crates/hyperbrep/docs/SUPPORT_MATRIX.md','crates/hyperbrep/docs/SELECTED_ARCHIVE.md','docs/properties-status.json']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*docs],cwd=ROOT)
(OUT/'final-documentation.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
review=json.loads((OUT/'commit-review.json').read_text())
for label,command in [('post-review-format',['cargo','fmt','--all','--','--check']),
                      ('post-review-diff',['git','diff','--check'])]:
    log=OUT/(label+'.log')
    with log.open('w') as stream:
        result=subprocess.run(command,cwd=ROOT,env=run.ENV,stdout=stream,stderr=subprocess.STDOUT)
    review['checks'].append(dict(command=command,exit_code=result.returncode,log=log.name,log_sha256=digest(log)))
    assert result.returncode==0,(label,log)
assert all(digest(ROOT/path)==expected for path,expected in source.items())
write(OUT/'commit-review.json',review)
write(OUT/'final-review.json',dict(
    implementation_unchanged=True,shared_ledger_outside_hyperbrep_byte_identical=True,
    documentation_patch_sha256=hashlib.sha256(patch).hexdigest(),documentation_patch_bytes=len(patch),
    review='Preserved the preexisting implementation-ledger JSON encoding (48 added lines, no changed historical lines) and clarified the affine-first section candidate and remaining rational-map work.',
    full_pre_push_matrix=False,pushed=False,
))
for name in ['commit-review.json','final-review.json','final-documentation.patch.gz']:
    shutil.copy2(OUT/name,DEST/name)
with tarfile.open(DEST/'raw-evidence.tar.gz','w:gz') as tar:
    for path in sorted(OUT.rglob('*')):
        if path.is_symlink() or not path.is_file():continue
        if path.name in ['saturated-norm-probe','results.lock'] or '__pycache__' in path.parts or 'target' in path.relative_to(OUT).parts:continue
        assert path.read_bytes()[:4] not in (b'\x7fELF',b'\x00asm'),path
        tar.add(path,arcname=str(Path('raw')/path.relative_to(OUT)),recursive=False)
manifest=json.loads((DEST/'manifest.json').read_text())
manifest['files']={str(p.relative_to(DEST)):dict(bytes=p.stat().st_size,sha256=digest(p))
                   for p in sorted(DEST.rglob('*')) if p.is_file() and p.name!='manifest.json'}
write(DEST/'manifest.json',manifest)
assert all(digest(DEST/name)==row['sha256'] for name,row in manifest['files'].items())
print('Final documentation, format, diff, owner-byte and frozen-source checks passed; evidence hashes refreshed.')
