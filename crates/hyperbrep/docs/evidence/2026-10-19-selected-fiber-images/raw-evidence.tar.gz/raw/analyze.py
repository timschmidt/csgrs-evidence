"""Verify completed-contract evidence without treating expected frontier failures as success."""
from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess
import tomllib

OUT = Path(__file__).resolve().parent
ROOT = Path('/mnt/development/csgrs/target/hyperbrep-development')
BASE = Path('/mnt/development/csgrs')
REVISION = '76238cec89c6a3a22308f2b9c3e18b5ad58561fd'

def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

rows = json.loads((OUT/'results.json').read_text())
jobs = {row['label']: row for row in rows}
assert len(jobs) == len(rows)
passed = ['candidate-v3-focused','candidate-v3-wasm-build','candidate-v3-wasm-run',
          'final-affected-clippy','final-affected-rustdoc','final-brep-fuzz-check','final-fmt',
          'final-solver-release-tests','final-brep-release-tests',
          'baseline-preserved-build','baseline-preserved-artifacts','baseline-preserved-expanded-build','baseline-preserved-expanded-artifacts',
          'final-new-consumer-build','final-preserved-candidate-build',
          'final-new-consumer-artifacts','final-preserved-candidate-artifacts',
          'final-original-mixed-form']
passed += [f'cost-preserved-{side}-{i}' for side in ['baseline','candidate'] for i in range(3)]
passed += [f'cost-new-{i}' for i in range(3)]
for label in passed:
    assert jobs[label]['exit_code'] == 0, (label, jobs[label])
for label in ['baseline-original-interior-loop','baseline-mixed-selected-form',
              'final-original-interior-loop','baseline-oblique-fillet',
              'baseline-exterior-endpoints','final-curve-release-tests']:
    assert jobs[label]['exit_code'] == 101, label
assert 'UnsupportedIntersection' in (OUT/'final-original-interior-loop.log').read_text()
expected_failures = {
    'bezier_offset::conversion_tests::independent_oblique_chords_support_constrained_fillet_families',
    'bezier_offset::conversion_tests::retained_incident_domains_admit_exterior_affine_endpoints',
}
curve_log = (OUT/'final-curve-release-tests.log').read_text()
assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', curve_log, re.M)) == expected_failures
for name in ['rational_images_select_conjugates_reject_poles_and_keep_base_identity',
             'affine_source_identity_survives_refinement_without_a_cycle',
             'near_pole_images_refine_source_bounds_and_recover_after_exhaustion']:
    assert re.search(r'^test \S*'+name+r' \.\.\. ok$', curve_log, re.M), name
for label, expected in [('baseline-oblique-fillet', next(n for n in expected_failures if 'fillet' in n)),
                        ('baseline-exterior-endpoints', next(n for n in expected_failures if 'exterior' in n))]:
    assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', (OUT/(label+'.log')).read_text(), re.M)) == {expected}

source = json.loads((OUT/'candidate-v3-source.json').read_text())
assert all(digest(ROOT/path) == expected for path, expected in source.items())
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=BASE, text=True).strip() == REVISION
assert not subprocess.check_output(['git','status','--porcelain'], cwd=BASE, text=True).strip()
summary = {}
for label in ['candidate-v3-focused','final-solver-release-tests','final-curve-release-tests','final-brep-release-tests']:
    counts = [tuple(map(int,m)) for m in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (OUT/(label+'.log')).read_text())]
    summary[label] = dict(exit_code=jobs[label]['exit_code'], batches=len(counts),
                          passed=sum(c[0] for c in counts), failed=sum(c[1] for c in counts), ignored=sum(c[2] for c in counts))
assert summary['final-solver-release-tests']['passed'] >= 988
assert summary['final-curve-release-tests']['passed'] >= 2538
assert summary['final-brep-release-tests']['passed'] >= 732
write('test-summary.json',summary)
write('inherited-failures.json',dict(revision=REVISION, unchanged_assertions=True,
    failures=sorted(expected_failures), baseline_logs=['baseline-oblique-fillet.log','baseline-exterior-endpoints.log'],
    candidate_log='final-curve-release-tests.log', scope='Reproduced independently on the clean target baseline; no unrelated owner repair or relaxed assertions.'))

artifacts = {}
for side in ['baseline','candidate','new']:
    directory=OUT/'artifacts'/side
    artifacts[side] = {str(p.relative_to(directory)):dict(bytes=p.stat().st_size, sha256=digest(p)) for p in sorted(directory.rglob('*')) if p.is_file()}
assert artifacts['baseline'] == artifacts['candidate']
assert len(artifacts['baseline']) >= 227
assert len(artifacts['new']) == 3
write('archive-comparison.json',dict(baseline_revision=REVISION, identical_preserved_files=len(artifacts['baseline']),
    files=artifacts, semantics='Complete assertion-bearing modeling recipes run before artifact comparisons; byte equality supplements their exact geometry/topology/source checks.'))

def samples(label):
    data=[json.loads(line) for line in (OUT/(label+'.log')).read_text().splitlines() if line.startswith('{')]
    layout=next(row for row in data if row.get('kind')=='layout')
    data=[row for row in data if 'phase' in row]
    assert len(data)==(12 if label.startswith('cost-new') else 10)
    assert all(row['outcome']=='certified_or_expected_typed_control' for row in data)
    for row in data:
        row['per_invocation_ns']=row['elapsed_ns']/row['iterations']
        row['per_invocation_allocation_calls']=row['allocation_calls']/row['iterations']
        row['per_invocation_requested_bytes']=row['requested_bytes']/row['iterations']
    return layout, {(row['case'],row['phase']):row for row in data}

paired=[]
layouts=[]
for i in range(3):
    old_layout,old=samples(f'cost-preserved-baseline-{i}')
    new_layout,new=samples(f'cost-preserved-candidate-{i}')
    assert old_layout==new_layout
    assert set(old)==set(new)
    layouts.append(old_layout)
    for key in old:
        a,b=old[key],new[key]
        paired.append(dict(process_pair=i,case=key[0],phase=key[1],baseline=a,candidate=b,
            latency_ratio=b['per_invocation_ns']/a['per_invocation_ns'],
            allocation_call_delta=b['per_invocation_allocation_calls']-a['per_invocation_allocation_calls'],
            requested_byte_delta=b['per_invocation_requested_bytes']-a['per_invocation_requested_bytes']))
medians=[]
for key in sorted({(r['case'],r['phase']) for r in paired}):
    group=[r for r in paired if (r['case'],r['phase'])==key]
    medians.append(dict(case=key[0],phase=key[1],median_latency_ratio=statistics.median(r['latency_ratio'] for r in group),
        allocation_call_deltas=[r['allocation_call_delta'] for r in group], requested_byte_deltas=[r['requested_byte_delta'] for r in group]))
absolute=[]
for i in range(3):
    layout,items=samples(f'cost-new-{i}')
    absolute.append(dict(process=i,layout=layout,samples=list(items.values())))
resources={p.stem:json.loads(p.read_text()) for p in sorted((OUT/'costs').glob('*.json'))}
assert len(resources)==9 and all(r['exit_code']==0 for r in resources.values())
costs=dict(processes=9, preserved_workflows=5, matched_process_pairs=3, fresh_inputs_per_case_per_process=4,
    layout=layouts[0], matched_rows=paired, median_rows=medians, new_workflows=absolute,
    allocation_call_increase_rows=sum(r['allocation_call_delta']>0 for r in paired),
    requested_byte_increase_rows=sum(r['requested_byte_delta']>0 for r in paired),
    minimum_median_ratio=min(r['median_latency_ratio'] for r in medians),
    maximum_median_ratio=max(r['median_latency_ratio'] for r in medians),
    process_resources=resources, maximum_rss_kib=max(r['maximum_rss_kib'] for r in resources.values()),
    limits='Shared-host timings, first and repeated fresh inputs, not universal cold caches. Rust request traffic excludes foreign allocators and is not live heap. New successes have no prior successful-work timing baseline. No general speedup or total resource bound is claimed.')
write('cost-analysis.json', costs)
binaries={}
for name,path in {
    'baseline_preserved':'/tmp/hyperbrep-review-target/release/hyperbrep-fiber-preserved-baseline',
    'candidate_preserved':'/tmp/hyperbrep-review-target/release/hyperbrep-fiber-preserved-candidate',
    'candidate_new':'/tmp/hyperbrep-review-target/release/hyperbrep-fiber-image-consumer',
    'candidate_wasm':'/tmp/hyperbrep-review-wasm-target/wasm32-unknown-unknown/release/hyperbrep_fiber_image_consumer.wasm',
}.items():
    path=Path(path);binaries[name]=dict(path=str(path),bytes=path.stat().st_size,sha256=digest(path))
write('binary-sizes.json',binaries)
locks={}
for side in ['baseline','candidate']:
    p=OUT/'preserved'/side/'Cargo.lock'
    packages=tomllib.loads(p.read_text())['package']
    for package in packages:
        if package['name'].startswith('hyperbrep-fiber-preserved-'): package['name']='matched-consumer'
    locks[side]=sorted(packages,key=lambda p:(p['name'],p['version']))
assert locks['baseline']==locks['candidate']
baseline_manifest=(OUT/'preserved/baseline/Cargo.toml').read_text()
candidate_manifest=(OUT/'preserved/candidate/Cargo.toml').read_text()
normalized_manifest=candidate_manifest.replace(str(ROOT),str(BASE)).replace(
    'hyperbrep-fiber-preserved-candidate','hyperbrep-fiber-preserved-baseline').replace(
    'hyperbrep_fiber_preserved_candidate','hyperbrep_fiber_preserved_baseline')
assert baseline_manifest==normalized_manifest
for a in sorted((OUT/'preserved/baseline').glob('*.rs')):
    b=OUT/'preserved/candidate'/a.name
    assert a.read_text()==b.read_text().replace(str(ROOT),str(BASE)), a.name
write('dependency-comparison.json',dict(identical_preserved_dependency_locks_after_consumer_name_normalization=True,
    identical_preserved_manifest_configuration_after_name_and_checkout_normalization=True,
    baseline_lock_sha256=digest(OUT/'preserved/baseline/Cargo.lock'),candidate_lock_sha256=digest(OUT/'preserved/candidate/Cargo.lock')))
write('verification.json',dict(baseline_revision=REVISION, implementation_source_unchanged=True,
    required_passes=passed, test_summary=summary, preserved_archives=len(artifacts['baseline']),
    new_archives=len(artifacts['new']),wasm_groups=6,wasm_imports=0,complete_work_packages=0,
    full_pre_push_matrix=False,pushed=False))
print(json.dumps(dict(tests=summary, archives=len(artifacts['baseline']),
    median_latency_ratio_range=[costs['minimum_median_ratio'],costs['maximum_median_ratio']],
    allocation_call_increase_rows=costs['allocation_call_increase_rows'],requested_byte_increase_rows=costs['requested_byte_increase_rows'],
    maximum_rss_kib=costs['maximum_rss_kib']),indent=2))
