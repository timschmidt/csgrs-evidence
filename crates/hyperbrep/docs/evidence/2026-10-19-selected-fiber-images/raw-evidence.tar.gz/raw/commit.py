"""Commit the qualified local increment and fast-forward brep; never push."""
from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = Path('/mnt/development/csgrs/target/hyperbrep-development')
MAIN = Path('/mnt/development/csgrs')
BASE = '76238cec89c6a3a22308f2b9c3e18b5ad58561fd'
EVIDENCE = 'crates/hyperbrep/docs/evidence/2026-10-19-selected-fiber-images'

def git(root,*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).rstrip('\n')

assert git(ROOT,'branch','--show-current') == 'brep-development'
assert git(MAIN,'branch','--show-current') == 'brep'
assert git(ROOT,'rev-parse','HEAD') == git(MAIN,'rev-parse','HEAD') == BASE
assert not git(MAIN,'status','--porcelain')
assert not git(ROOT,'diff','--cached','--name-only')
source = json.loads((ROOT/EVIDENCE/'candidate-v3-source.json').read_text())
for name,expected in source.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
manifest = json.loads((ROOT/EVIDENCE/'manifest.json').read_text())
for name,expected in manifest['files'].items():
    path=ROOT/EVIDENCE/name
    assert path.stat().st_size == expected['bytes'], name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256'], name

docs = {
    'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json',
    'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md',
    'crates/hyperbrep/docs/SUPPORT_MATRIX.md',
    'crates/hyperbrep/docs/SELECTED_ARCHIVE.md',
    'docs/properties-status.json',
}
allowed=set(source)|docs|{EVIDENCE+'/'+name for name in manifest['files']}|{EVIDENCE+'/manifest.json'}
changed=set(git(ROOT,'diff','--name-only').splitlines())|set(git(ROOT,'ls-files','--others','--exclude-standard').splitlines())
assert changed == allowed, dict(extra=sorted(changed-allowed),missing=sorted(allowed-changed))
subprocess.run(['git','add','--',*sorted(allowed)],cwd=ROOT,check=True)
assert set(git(ROOT,'diff','--cached','--name-only').splitlines())==allowed
subprocess.run(['git','diff','--cached','--check'],cwd=ROOT,check=True)
subprocess.run(['git','commit','-m','Retain exact selected-fiber affine images through BRep replay'],cwd=ROOT,check=True)
revision=git(ROOT,'rev-parse','HEAD')
assert not git(ROOT,'status','--porcelain')
assert git(MAIN,'rev-parse','HEAD') == BASE
assert not git(MAIN,'status','--porcelain')
subprocess.run(['git','merge','--ff-only',revision],cwd=MAIN,check=True)
assert git(MAIN,'rev-parse','HEAD') == revision
assert not git(MAIN,'status','--porcelain')
print(json.dumps(dict(commit=revision,branches=['brep','brep-development'],clean=True,pushed=False)))
