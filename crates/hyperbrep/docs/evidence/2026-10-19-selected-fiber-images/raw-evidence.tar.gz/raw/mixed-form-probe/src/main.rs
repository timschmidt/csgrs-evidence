use hypercurve::*;
use hypersolve::{BivariatePolynomial, IsolatedRootInterval};
fn main() {
    let base = BezierAlgebraicParameter2::try_isolate(
        BezierParameterPolynomial::try_new_power_basis(vec![(-2).into(), 0.into(), 1.into()]).unwrap(),
        BezierParameterInterval::try_new(1.into(), 2.into()).unwrap()).unwrap();
    let point = CurvePointDefinition2::PolynomialFiber {
        equation: BivariatePolynomial::new(vec![vec![0.into(), 0.into(), 0.into(), 1.into()], vec![(-1).into()]]),
        parameter: BezierParameter2::Algebraic(base),
        root: IsolatedRootInterval { lower: 1.into(), upper: (Real::from(3)/Real::from(2)).unwrap(), exact_root: None, distinct_root_count: 1 },
    }.into_point().unwrap();
    let form = point.affine_form(1.into(), 1.into(), 0.into());
    assert!(form.compare_to_real(&Real::from(2)).unwrap().is_gt());
    assert!(form.compare_to_real(&Real::from(3)).unwrap().is_lt());
    let parameter = form.parameter();
    println!("mixed selected affine parameter: {parameter:?}");
    let parameter = parameter.expect("the mixed affine value must retain its exact selected field");
    assert!(parameter.compare(&Real::from(2).into()).unwrap().is_gt());
    assert!(parameter.compare(&Real::from(3).into()).unwrap().is_lt());
}
