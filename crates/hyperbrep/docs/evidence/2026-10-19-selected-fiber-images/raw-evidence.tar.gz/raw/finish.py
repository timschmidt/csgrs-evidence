"""Write bounded evidence and owner-scoped ledgers after qualification completes."""
from pathlib import Path
import copy
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
import run

OUT = Path(__file__).resolve().parent
ROOT = run.ROOT
BASE = Path('/mnt/development/csgrs')
REVISION = '76238cec89c6a3a22308f2b9c3e18b5ad58561fd'
RELATIVE = 'crates/hyperbrep/docs/evidence/2026-10-19-selected-fiber-images'
DEST = ROOT/RELATIVE
assert not DEST.exists(), DEST
subprocess.run(['python3', '-B', str(OUT/'analyze.py')], check=True)

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = json.loads((OUT/'candidate-v3-source.json').read_text())
assert len(source) == 16
assert all(digest(ROOT/name) == expected for name, expected in source.items())
summary = json.loads((OUT/'test-summary.json').read_text())
costs = json.loads((OUT/'cost-analysis.json').read_text())
artifacts = json.loads((OUT/'archive-comparison.json').read_text())
solver = summary['final-solver-release-tests']
curve = summary['final-curve-release-tests']
brep = summary['final-brep-release-tests']

qualification = (
    'Six shared groups (three solver, two curve, one BRep) pass natively and in actual zero-import WebAssembly. '
    'They verify exact local coefficient identities, both axis conventions, saturation and poles, selected conjugates, '
    'mixed affine coordinates, strict/approximate/strict reuse, promotion refusal/recovery and complete BRep '
    'edge/scalar-chart/transform/archive replay. Three internal curve tests also pass, including near-pole '
    'refinement and retained-source lifetime without a reference cycle. '
    f'Final all-feature release suites pass {solver["passed"]} solver and {brep["passed"]} BRep/IO tests. '
    f'The curve suite records {curve["passed"]} passed, {curve["failed"]} failed and {curve["ignored"]} ignored '
    f'tests across {curve["batches"]} batches. Both failures reproduce on clean 76238cec8: oblique-fillet certainty '
    'and the exterior parameter recursive-projective view. Their assertions remain unchanged. '
    'Affected all-feature/all-target Clippy and rustdoc deny warnings; BRep fuzz-target compilation and formatting pass. '
    f'Five preserved assertion-bearing workflows pass on baseline and candidate, including {artifacts["identical_preserved_files"]} '
    'byte-identical BRep archives; the new recipe emits three checked transformed archives. '
    'The original mixed affine-form success assertion now passes. The complete original interior-loop surface-section '
    'success assertion still fails with UnsupportedIntersection; it is not credited as a completed section.'
)
layout = costs['layout']
increased_bytes = [r for r in costs['matched_rows'] if r['requested_byte_delta'] > 0]
assert {r['case'] for r in increased_bytes} == {'polynomial_branches'}
assert {r['requested_byte_delta'] for r in increased_bytes} == {344.0}
legacy_costs = {r['phase']: r['median_latency_ratio'] for r in costs['median_rows'] if r['case']=='legacy_local_global_images'}
binaries = json.loads((OUT/'binary-sizes.json').read_text())
binary_delta = binaries['candidate_preserved']['bytes']-binaries['baseline_preserved']['bytes']
cost_evidence = (
    'Nine CPU-pinned processes retain three alternating baseline/candidate pairs for five preserved workflows '
    '(three complete BRep modeling recipes, polynomial branches and the existing local/global polynomial-image APIs), '
    'plus three absolute processes for six new workflows. First and three repeated fresh-input calls retain all '
    'assertions, validation and output materialization. '
    f'The ten matched median phase ratios range {costs["minimum_median_ratio"]:.6f} to '
    f'{costs["maximum_median_ratio"]:.6f}; {costs["allocation_call_increase_rows"]} of 30 paired rows increase '
    f'counted Rust allocation calls and {costs["requested_byte_increase_rows"]} increase requested bytes. '
    'Each byte increase is 344 bytes per complete polynomial-branch invocation (about 0.0091% of baseline request traffic); '
    'the other preserved workflows have identical allocation calls and requested bytes. '
    f'The legacy local/global projection recipe retains adverse first/repeated median latency ratios '
    f'{legacy_costs["first_fresh_input"]:.6f}/{legacy_costs["repeated_fresh_input"]:.6f}. '
    f'Maximum measured process RSS is {costs["maximum_rss_kib"]} KiB. '
    f'The matched native executable grows by {binary_delta} bytes; all native/WASM artifact sizes and hashes are recorded. '
    'All unfavorable samples remain in cost-analysis.json and the raw record. The public Curve2/CurvePoint2/definition '
    'layouts remain identical to baseline; optional affine provenance adds one pointer to internal selected-fiber '
    'parameter data. Requested allocation traffic excludes foreign allocator internals and is not live heap. '
    'Shared-host timings and finite layouts establish neither a general speedup nor a total resource bound. '
    'New successful operations have no prior successful-work timing baseline.'
)
limits = (
    'This is an exact selected-scalar and replay extension, not a completed general BRep section. '
    'The public solver enumerates local rational images; its caller must exclude poles and select the image of '
    'the retained source. The curve extension selects that image and exposes mixed affine forms of admitted '
    'PolynomialFiber points. General source-bound rational planar/spatial maps, branch derivatives and regularity, '
    'dual surface charts, filled arrangements, trim/material topology and whole-branch replay remain open. '
    'The underlying finite-fiber solver still rejects unsupported vertical/nullified components, generic repeated '
    'factors and whole boundary components. General rational-map persistence remains unsupported; the existing '
    'AffineForm archive covers the implemented affine source recipes. Existing degree caps, refinement/promotion '
    'counters and archive admission limits do not bound total arithmetic, coefficient growth, live heap, stack '
    'or cancellation latency. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, production '
    'bindings and the full pre-push matrix remain unqualified. All 28 work packages remain open/in-progress. '
    'The consumed eaa0cae54 push exception does not authorize publishing this increment.'
)
report = dict(
    date='2026-10-19', base_revision=REVISION, increment='selected-fiber-images-2026-10-19',
    qualification=qualification, cost_evidence=cost_evidence, limits=limits,
    source='candidate-v3-source.json', baseline_source='baseline-source.json',
    checks='results.json', tests='test-summary.json', known_failures='inherited-failures.json',
    costs='cost-analysis.json', artifacts='archive-comparison.json', upstream_check='upstream-check.json',
)
write(OUT/'report.json', report)
write(OUT/'baseline-source.json', dict(
    revision=REVISION, tree=subprocess.check_output(['git','rev-parse',REVISION+'^{tree}'],cwd=BASE,text=True).strip(),
    clean=True, qualification_scope='Clean frozen main checkout; source_scope in baseline job rows overrides runner development-worktree metadata.',
    files={name: digest(BASE/name) for name in source if (BASE/name).is_file()},
))

# Preserve the exact implementation and acceptance inputs before documentation/evidence edits.
tracked = subprocess.check_output(['git','diff','--binary','HEAD','--',*source],cwd=ROOT)
patch = tracked
for name in source:
    if subprocess.run(['git','ls-files','--error-unmatch',name],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
        added = subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=ROOT,capture_output=True)
        assert added.returncode == 1
        patch += added.stdout
(OUT/'qualified-source.patch.gz').write_bytes(gzip.compress(patch, mtime=0))
write(OUT/'source-patch.json', dict(base=REVISION, uncompressed_bytes=len(patch),
    sha256=hashlib.sha256(patch).hexdigest(), scope='Sixteen final implementation/acceptance files; documentation and evidence are recorded separately in the commit.'))

DEST.mkdir()
for name in [
    'report.json','candidate-v3-source.json','baseline-source.json','source-patch.json','qualified-source.patch.gz',
    'results.json','test-summary.json','inherited-failures.json','cost-analysis.json','archive-comparison.json',
    'binary-sizes.json','dependency-comparison.json','verification.json','outcomes.json','environment.json','upstream-check.json',
    'contract.md','construction-argument.md','algorithm-notes.md','attempt-review.md','next-domains.md',
    'preserved-five-recipe-source.json','preserved-recipe-comparison.json','research-sources.json','wasm-exports.json',
]:
    shutil.copy2(OUT/name, DEST/name)

(DEST/'README.md').write_text(f'''# Selected-fiber images and mixed affine coordinate replay

This increment extends WP05a/WP05b prerequisites in Hypersolve and Hypercurve,
consumed through BRep's existing scalar charts, planar spatial images, model
builder and version-10 archive. The original complete surface-section input
and its success assertion remain an explicit failing frontier.

## Implemented contract

`project_algebraic_fiber_rational_image_relation` reuses the selected coefficient
field's local norm and saturation to enumerate images of `N(alpha,y)/D(alpha,y)`.
It does not take a global norm through the base polynomial. Its public report
does not select a source root or certify a denominator: those are consumer
obligations. Hypercurve proves the denominator nonzero, refines outward source
enclosures and isolates/rechecks a unique local image in that same field.

`CurvePointAffineForm2::parameter` now extracts mixed affine coordinates from
admitted `PolynomialFiber` points over algebraic bases. The parameter retains
its original point/form recipe through affine transport and refinement. Existing
`CurveParameter2::affine_form_source` exposes that recipe. The existing BRep
`AffineForm` encoding replays it without a new archive tag or compatibility
adapter. Nested affine point lifts normalize during construction and replay;
the original byte-stability failure remains in the raw record.

The independent identities include `y^3=alpha`, `alpha^2=2`, `z=alpha+y`,
which implies `z^6-6*z^4-18=0`, with positive selected roots. The tests also
retain both fiber conjugates, reducible base carriers, noninjective images,
exact `1/10^12` separation, saturated zero factors and true poles. A norm
enumerates candidates; source enclosures and checked singleton evidence select
the intended image. No approximate midpoint is a coordinate authority.

## Qualification

{qualification}

## Cost and representation

{cost_evidence}

## Boundaries

{limits}

## Evidence and reproduction

[manifest.json](manifest.json) hashes the bounded record. The
[contract](contract.md), [construction argument](construction-argument.md),
[attempt review](attempt-review.md), [inherited failures](inherited-failures.json)
and [next domains](next-domains.md) separate implementation from open work.
[Outcome records](outcomes.json) distinguish completed recipes, typed controls
and the original unsupported section.
[Raw evidence](raw-evidence.tar.gz) retains commands, logs, per-job source
patches, standalone consumers and dependency locks, full archive fixtures,
all raw cost samples and analysis scripts. Compiled binaries are represented
by hashes and sizes; none are included in the archive.

Reproduction uses separate baseline/candidate worktrees at `{REVISION}`
and that revision plus the qualified patch. The original commands used Rust
1.99.0, recorded source paths and offline dependencies. Adjust workspace and
tool-cache paths when reproducing elsewhere. Baseline job `source_scope` fields
identify the frozen main checkout; the generic runner's development patch/status
metadata does not describe those baseline jobs. The earlier four-recipe baseline
artifact run is historical; matched costs use the rebuilt five-recipe consumers.
`analyze.py` requires the full expected failure set, unchanged implementation
hashes, all acceptance successes, matching layouts and preserved archive bytes.
The native source-path and Wasmtime consumers do not qualify installed packages
or production bindings. No push was performed for this increment.
''')

status_path = ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status = json.loads(status_path.read_text())
assert len(status['increments']) == 70
status['updated_on'] = '2026-10-19'
status['increments'].append(dict(
    id=report['increment'],work_packages=['WP05a','WP05b','WP06','WP13','WP21'],
    properties=['P1','P2','P4','P5','P6','P8','P9','P10','P11','P15','P16','P17','P18','P19','P20','P25','P26','P27','P29','P35','P36','P37','P39'],
    change='Select exact rational images in the retained algebraic coefficient field; expose mixed polynomial-point affine parameters and replay their source through existing BRep scalar charts and archives.',
    sources=['../../hypersolve/src/algebraic_fiber.rs','../../hypercurve/src/bezier_offset/selected_fiber.rs','../../hypercurve/src/bezier_offset/affine_form.rs','../../hypercurve/src/polynomial_point.rs','../tests/support/selected_fiber_images.rs'],
    evidence='evidence/2026-10-19-selected-fiber-images/manifest.json',validation=qualification,cost_evidence=cost_evidence,limits=limits,
))
status['next_actions'].insert(0,
    'Continue WP05a/WP05b from evidence/2026-10-19-selected-fiber-images/manifest.json and next-domains.md. Preserve the original complete interior-loop section, all mixed affine point/scalar-chart/transform/archive recipes, independently derived image identities, poles, budgets and every adverse cost. Next retain rational planar maps with source and denominator/regularity authority, selected BRep pcurve evaluation/materialization and both original surface charts. Reuse the existing planar spatial lift for plane/tensor sections; general patch pairs need further spatial images. Complete branch/event replay and section/trim consumers. Do not count a scalar image or a passing archive as a completed section. All work-package and publication gates remain open.')
write(status_path, status)

plan_path = ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md'
plan = plan_path.read_text()
old = 'Status: implementation blueprint. Updated 2026-10-19 for native polynomial\nbranches, upstream `dbe99e3cc` and concurrent development ownership.'
new = 'Status: implementation blueprint. Updated 2026-10-19 for selected-fiber\nimages, upstream `dbe99e3cc` and concurrent development ownership.'
assert plan.count(old) == 1
plan = plan.replace(old,new)
marker = 'Apply [research gates G2–G5]'
assert plan.count(marker) == 1
paragraph = '''The [selected-fiber image increment](evidence/2026-10-19-selected-fiber-images/README.md)
now computes mixed affine coordinates of polynomial-fiber points in their
retained algebraic field. Hypersolve owns local rational-image norms; Hypercurve
owns source selection, denominator checks and replayable affine recipes. BRep
consumes these parameters through existing scalar charts, planar spatial images,
model validation and deterministic archive replay. General rational maps and
their regularity/source certificates, branch derivatives, selected pcurve
evaluation, both surface charts and whole-branch replay remain prerequisites to
the original interior-loop section. Its plane image can reuse BRep's existing
planar spatial lift; general patch pairs require further spatial carriers.
Follow the current
[next domains](evidence/2026-10-19-selected-fiber-images/next-domains.md) before
claiming a complete section or trim arrangement. No work package is closed.

'''
plan_path.write_text(plan.replace(marker, paragraph+marker))

matrix_path = ROOT/'crates/hyperbrep/docs/SUPPORT_MATRIX.md'
matrix = matrix_path.read_text()
old = '''See the [finite evidence](evidence/2026-10-19-polynomial-branches/README.md).
This does not supply general derivatives, filled arrangements, tensor-surface
images, both section charts or whole implicit-branch archives.'''
new = '''See the [finite branch evidence](evidence/2026-10-19-polynomial-branches/README.md).
Mixed affine coordinates now remain selected in the same algebraic field and
carry replayable point/form recipes. Existing BRep scalar charts and planar
spatial images consume them through complete edge validation, transforms and
deterministic native archive replay; see the
[image evidence](evidence/2026-10-19-selected-fiber-images/README.md).
This does not supply general rational planar/spatial maps, branch derivatives,
filled arrangements, tensor-surface images, both section charts or whole
implicit-branch archives.'''
assert matrix.count(old) == 1
matrix_path.write_text(matrix.replace(old,new))

archive_path = ROOT/'crates/hyperbrep/docs/SELECTED_ARCHIVE.md'
archive = archive_path.read_text()
old = '''endpoints consume this point record through the public model loader. General
selected scalar-image persistence still requires owner support. Input admission'''
new = '''endpoints consume this point record through the public model loader. Mixed
affine scalar images of these points now use the existing `AffineForm` record,
retaining the original point and coefficients through scalar charts and spatial
planar-image replay. General rational-image and whole-branch persistence still
require owner support. Input admission'''
assert archive.count(old) == 1
archive = archive.replace(old,new)
old = '''  polynomials in one selected parameter, a strict-compatible similarity, or a
  unique intersection of two exact supporting lines.
  Every selected reference must name an earlier node. Replay reconstructs the
  source and shared parameter field; it does not trust precomputed coordinates.'''
new = '''  polynomials in one selected parameter, a checked `PolynomialFiber`, a
  strict-compatible similarity, or a unique intersection of two exact supporting
  lines. Nested affine lifts of a selected-fiber affine form compose into the
  original source recipe during construction and replay, preserving deterministic
  bytes. Every selected reference must name an earlier node. Replay reconstructs
  the source and shared parameter field; it does not trust precomputed coordinates.'''
assert archive.count(old) == 1
archive_path.write_text(archive.replace(old,new))

# Replace only the current_work.hyperbrep object; other owner bytes must not change.
ledger_path = ROOT/'docs/properties-status.json'
ledger_text = ledger_path.read_text()
ledger = json.loads(ledger_text)
before = copy.deepcopy(ledger)
entry = ledger['current_work']['hyperbrep']
entry.update(latest_evidence=RELATIVE+'/manifest.json',latest_feature_evidence=RELATIVE+'/manifest.json',
    latest_implementation=report['increment'],qualification=qualification,performance_evidence=cost_evidence,
    limits=limits,latest_update_check=RELATIVE+'/upstream-check.json')
comparison = copy.deepcopy(ledger)
comparison['current_work']['hyperbrep'] = before['current_work']['hyperbrep']
assert comparison == before
decoder = json.JSONDecoder()
def whitespace(text,pos):
    while text[pos].isspace(): pos += 1
    return pos
def member(text,start,key):
    pos=whitespace(text,start)
    assert text[pos]=='{'
    pos=whitespace(text,pos+1)
    while text[pos]!='}':
        name,pos=decoder.raw_decode(text,pos)
        pos=whitespace(text,pos)
        assert text[pos]==':'
        begin=whitespace(text,pos+1)
        _,end=decoder.raw_decode(text,begin)
        if name==key:return begin,end
        pos=whitespace(text,end)
        if text[pos]==',':pos=whitespace(text,pos+1)
    raise KeyError(key)
start,_=member(ledger_text,0,'current_work')
start,end=member(ledger_text,start,'hyperbrep')
line=ledger_text[ledger_text.rfind('\n',0,start)+1:start]
base=len(line)-len(line.lstrip())
second=ledger_text[start:end].splitlines()[1]
width=len(second)-len(second.lstrip())-base
block=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*base)
ledger_output=ledger_text[:start]+block+ledger_text[end:]
assert json.loads(ledger_output)==ledger
ledger_path.write_text(ledger_output)
write(OUT/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,
    prefix_sha256=hashlib.sha256(ledger_text[:start].encode()).hexdigest(),
    suffix_sha256=hashlib.sha256(ledger_text[end:].encode()).hexdigest()))
shutil.copy2(OUT/'ledger-scope.json',DEST/'ledger-scope.json')

# Do not use run.py after evidence enters the worktree: its source snapshots would include the record.
final=[]
for name,command in [('format',['cargo','fmt','--all','--','--check']),('diff',['git','diff','--check'])]:
    log=OUT/('commit-review-'+name+'.log')
    with log.open('w') as stream:
        result=subprocess.run(command,cwd=ROOT,env=run.ENV,stdout=stream,stderr=subprocess.STDOUT)
    final.append(dict(command=command,exit_code=result.returncode,log=log.name,log_sha256=digest(log)))
    assert result.returncode==0,(name,log)
assert all(digest(ROOT/name)==expected for name,expected in source.items())
assert len(status['work_packages'])==28 and not status['complete']
write(OUT/'commit-review.json',dict(checks=final,implementation_hashes_unchanged=True,
    shared_ledger_outside_owner_unchanged=True,full_workflow_matrix=False,pushed=False))
shutil.copy2(OUT/'commit-review.json',DEST/'commit-review.json')

archive_path=DEST/'raw-evidence.tar.gz'
with tarfile.open(archive_path,'w:gz') as tar:
    for path in sorted(OUT.rglob('*')):
        if path.is_symlink() or not path.is_file(): continue
        if path.name in ['saturated-norm-probe','results.lock'] or '__pycache__' in path.parts or 'target' in path.relative_to(OUT).parts: continue
        assert path.read_bytes()[:4] not in (b'\x7fELF', b'\x00asm'), path
        tar.add(path,arcname=str(Path('raw')/path.relative_to(OUT)),recursive=False)
files={str(p.relative_to(DEST)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(DEST.rglob('*')) if p.is_file()}
write(DEST/'manifest.json',dict(**report,complete=False,work_packages_closed=0,files=files))
assert all(digest(DEST/name)==row['sha256'] for name,row in files.items())
print('Evidence prepared:',DEST,'files',len(files)+1,'raw bytes',archive_path.stat().st_size)
print(qualification)
print(cost_evidence)
