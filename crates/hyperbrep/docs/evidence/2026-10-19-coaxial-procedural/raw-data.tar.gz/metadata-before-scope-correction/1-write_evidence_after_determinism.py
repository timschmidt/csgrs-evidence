"""Summarize completed evidence without converting finite checks into release claims."""
from pathlib import Path
import gzip,hashlib,json,re,shutil
from run import OUT,ROOT
from source_identity import source_identity
name='2026-10-19-coaxial-procedural';dest=ROOT/'crates/hyperbrep/docs/evidence'/name
load=lambda n:json.loads((OUT/n).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
write=lambda n,x:(OUT/n).write_text(json.dumps(x,indent=2)+'\n')
assert source_identity(ROOT)==load('candidate-consumer-source.json')==load('candidate-frozen-source.json')
assert source_identity('/mnt/development/csgrs')==load('baseline-consumer-source.json')
results=load('results.json');checks={r['label']:r for r in results}
required=['strict-clippy-all-03','tests-all-features-03','tests-minimal-features-02','owner-regressions-02','clippy-minimal-features-02','rustdoc-02','fuzz-check-02','format-check-02','archive-distinct-replay']
assert all(checks[k]['exit_code']==0 for k in required)
def count(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',Path(checks[label]['log']).read_text())
 assert rows and all(int(f)==0 for _,f in rows)
 return sum(int(p) for p,_ in rows)
all_tests=count('tests-all-features-03');minimal=count('tests-minimal-features-02');owner=count('owner-regressions-02')
assert all_tests==729 and minimal==721,(all_tests,minimal)
consumers=load('candidate-consumers.json');baseline=load('baseline-consumers.json');assert len(consumers)==6
assert sum(r['groups'] for r in consumers)==51
for r in consumers:
 for kind in ['native','wasm']:assert sha(r[kind]['path'])==r[kind]['sha256']
 assert checks[r['native_validation_prefix']+'-runtime']['exit_code']==0
 assert checks[r['wasm_validation_prefix']+'-runtime']['exit_code']==0
archives=load('archive-summary.json');costs=load('consumer-costs.json')
assert len(costs['trials'])==30 and len(costs['rows'])==54
assert all(r['exit_code']==r['resource']['exit_code']==0 for r in costs['trials'])
matched=[r for r in costs['rows'] if r['matched_contract']];assert len(matched)==28
adverse=[r for r in matched if r['ratio']>1 or any(r['candidate'][key]>r['baseline'][key] for key in ['allocation_calls','requested_bytes'])]
markers=[r for r in matched if r['ratio']>1.1]
alloc=[r for r in matched if any(r['candidate'][key]>r['baseline'][key] for key in ['allocation_calls','requested_bytes'])]
absolute=[r for r in costs['rows'] if not r['matched_contract']]
selected={r['phase']:r['candidate'] for r in absolute if r['case']=='selected_parallel_revolution_boolean_continues'}
f=selected['first_fresh_input'];w=selected['repeated_fresh_input']
maximum_rss=max(r['resource']['maximum_rss_kib'] for r in costs['trials'])
binaries=[];old={r['cohort']:r for r in baseline}
for r in consumers:
 for kind in ['native','wasm']:
  row=dict(cohort=r['cohort'],kind=kind,candidate=r[kind])
  if r['cohort'] in old:
   b=old[r['cohort']][kind];row.update(baseline=b,delta_bytes=r[kind]['bytes']-b['bytes'])
  binaries.append(row)
cs=dict(matched_phase_rows=len(matched),absolute_phase_rows=len(absolute),processes=len(costs['trials']),minimum_time_ratio=min(r['ratio'] for r in matched),maximum_time_ratio=max(r['ratio'] for r in matched),timing_rows_above_review_marker=len(markers),allocation_growth_rows=len(alloc),maximum_process_rss_kib=maximum_rss,binaries=binaries,absolute_rows=absolute,scope=costs['scope'])
write('cost-summary.json',cs);write('adverse-cost-samples.json',adverse)
qualification=(f'Eight new public Boolean groups and two archive groups extend the BRep corpus; three added owner regressions extend the existing five point-definition tests. A further owner regression preserves exact profile sequence across 64 cold admissions of identical polygon/NURBS archives. Three fresh diagnostic processes repeat the original full union/XOR, NURBS and transformed-axis recipes. Two earlier private-query expectations now assert a usable curved certificate while retaining exact volume, classification and replay oracles. Final BRep/IO release suites pass {all_tests} all-feature and {minimal} minimal-feature tests; {owner} selected Hypercurve owner regressions pass. Both affected all-target Clippy configurations include Hypercurve and deny warnings. Warning-denied rustdoc, BRep fuzz-target compilation and formatting pass. Six source-path projects execute 51 native and 51 actual zero-import WASM groups: 33 preserved BRep groups, ten Boolean/archive groups and eight owner point-definition groups. This is the affected boundary corpus, not the full historical WASM inventory. WASM recipes check cold archive replay internally; the separate file comparison is native, with no cross-platform byte-identity claim. '
 +f"Archive qualification retains {archives['input_aliases']} verified file aliases with {archives['distinct_contents']} distinct payload/extension pairs. Each distinct native or STEP payload is executed once, with repeated cold native admission; text controls are inventory-only. {archives['distinct_outcomes'].get('native_admitted_and_stable',0)} distinct native archives re-encode byte-identically; {archives['distinct_outcomes'].get('step_import_and_native_replay',0)} distinct STEP files import {archives['distinct_step_bodies']} bodies. All {archives['fresh_byte_identical_pairs']} fresh preserved baseline/candidate outputs match bytes; {archives['new_coaxial_files']} new Boolean outputs repeat deterministically. The archive-shape record reports serialized value depth, rational limb counts and retained source/parameter records separately from live memory or execution bounds. No previously admitted native record or scalar encoding is reinterpreted. The schema-10 supporting-line point tag is additive; older readers need not recognize new records.")
cost_text=(f'Three alternating CPU-pinned pairs cover 14 preserved completed workflows. Three absolute processes cover three new Boolean/replay recipes, both archive-control recipes and eight owner point-definition groups. All 30 processes pass; first and repeated fresh-input invocations are separate (three repeats for ordinary groups, one for the expensive overlapping union/XOR group). The 28 matched phase ratios range {cs["minimum_time_ratio"]:.6f} to {cs["maximum_time_ratio"]:.6f}; {len(markers)} exceed the 10% review marker and {len(alloc)} increase allocation traffic. Every raw sample and adverse result is retained. The complete selected-cap Boolean recipe takes {f["elapsed_ns"]/1e9:.3f}s first and {w["elapsed_ns"]/1e9:.3f}s per repeated invocation, requesting {f["requested_bytes"]/1e9:.3f}/{w["requested_bytes"]/1e9:.3f} GB respectively. Maximum process RSS is {maximum_rss/1024:.2f} MiB. Cumulative requested bytes are counted Rust allocation traffic, not live heap or a complete count of foreign allocator traffic. These instrumented shared-host samples establish no general speedup or internal resource bound. Baseline binaries are reused only after source, input and binary-hash verification; all native baseline samples are freshly executed.')
limits=('The extension covers admitted complete-turn, strictly positive-radius revolutions with a proved common axis and owner-supported filled-region operations. General noncoaxial curved Booleans, partial/singular revolutions, independent selected angular/axial fields, general procedural metrics and STEP, complete authoring-intent provenance, total work/heap/coefficient/cancellation bounds, runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions and production bindings remain open. Nested archive limits are checked at depths 1,2,4,8; they do not prove all-depth stack or replay-work safety, and inline point witnesses do not bound shared-source expansion during export. All 28 work packages remain open/in-progress. No full repository pre-push matrix is claimed and the consumed eaa0 one-time push exception does not authorize publishing this increment.')
summary=dict(qualification=qualification,costs=cost_text,limits=limits,tests=dict(all_features=all_tests,minimal_features=minimal,owner_regressions=owner),archives=archives,cost_summary=cs)
write('qualification-summary.json',summary)
# All original development attempts remain linked, including source snapshots.
failures=[r for r in results if r['exit_code']]
lines=['# Development attempts','', 'Every attempt below remains in validation.json and the raw archive, including its exact source patch and full log. Final checks use the frozen source; early compile or behavior failures are not counted as accepted capability.','','| Attempt | Exit | Seconds |','| --- | ---: | ---: |']
for r in failures:lines.append(f"| {r['label']} | {r['exit_code']} | {r['elapsed_seconds']:.3f} |")
lines+=['','The original full and selected caps first failed the public co-axial Boolean dispatch on the base revision. The first extension exposed an unsupported retained supporting-line pair on save. A new source definition fixed that missing domain, but replay then scalar-expanded its affine field and grew one archive from 274,633 to 2,525,872 bytes. Preserving the source affine form fixed this mismatch. The unchanged NURBS fixture next exposed coordinate-image definitions and then two AffineForm/Image mismatches; using the shared original root consistently fixed construction/replay.','', 'Two existing internal tests expected curved revolution certificates to be absent. Each failure was reproduced before updating its assertion to verify a usable curved certificate, no polygon demotion and exact filled-profile classification. Their existing numerical, topology, replay and volume checks remain. Other development failures include a test closure type annotation; no compiler error is credited as a reproduced runtime limitation.','', 'The first fresh-process archive comparison exposed five nonidentical outputs, despite passing exact set and same-process replay checks. Native revolution admission seeded its retained meridian cycle from randomized HashMap traversal. A focused cold-admission regression reproduced this before changing the grouping to stable surface-ID order. Both pre-fix output sets and all full fixtures remain in the audit; no scalar-chart or geometry normalization was used to hide the mismatch.', '', 'The final focused NURBS and point/archive tests, complete BRep/IO suites and native/WASM/archive consumers are recorded separately. No fixture geometry, policy or resolution was weakened.']
(OUT/'attempt-review.md').write_text('\n'.join(lines)+'\n')
lines=['# Cost and size observations','',cost_text,'','## Preserved workflow observations','','All timing increases and allocation-growth rows are listed, including observations below the review marker. A marker flags review, not a causal performance claim.','','| Workflow / phase | Time ratio | Allocation-call change | Requested-byte change |','| --- | ---: | ---: | ---: |']
for r in adverse:
 b=r['baseline'];c=r['candidate'];lines.append(f"| {r['case']} / {r['phase']} | {r['ratio']:.6f} | {(c['allocation_calls']/b['allocation_calls']-1)*100:.5f}% | {(c['requested_bytes']/b['requested_bytes']-1)*100:.5f}% |")
lines+=['','## Binary sizes','','| Consumer | Artifact | Candidate bytes | Baseline delta |','| --- | --- | ---: | ---: |']
for r in binaries:lines.append(f"| {r['cohort']} | {r['kind']} | {r['candidate']['bytes']} | {r.get('delta_bytes','new domain')} |")
lines+=['','The finite source extension is retained for additional exact completion and replay. These samples do not identify a scalar-layer defect or justify unrelated supporting-crate repair. Profile the complete selected recipe before choosing an optimization. Baseline WASM artifacts are reused for size comparison only; candidate WASM execution is fresh. No global cache eviction, host isolation or whole-corpus cost claim is made.']
(OUT/'costs.md').write_text('\n'.join(lines)+'\n')
ideas=load('idea-ledger.json')
for r in ideas:
 if r['status']=='kept-pending-final-qualification':r['status']='kept';r['final_evidence']=['qualification-summary.json','consumer-costs.json','archive-summary.json']
 elif r['status']=='already-satisfied-and-retained':r['status']='already-satisfied'
 elif r['status']=='replaced-in-qualification-harness':r['status']='kept';r['scope']='Audit scheduling only; no kernel performance claim.'
 assert r['status'] in ['kept','rejected','already-satisfied','architecture-inapplicable']
write('idea-ledger.json',ideas)
assert not dest.exists();dest.mkdir(parents=True)
for p in (OUT/'drafts').glob('*.md'):shutil.copy2(p,dest/p.name)
for n in ['qualification-summary.json','cost-summary.json','consumer-costs.json','adverse-cost-samples.json','archive-summary.json','archive-aliases.json','archive-replay-results.json','generated-artifact-pairs.json','artifact-generation.json','consumer-projects.json','candidate-consumers.json','baseline-consumers.json','baseline-binary-reuse.json','baseline-wasm-size-reuse.json','toolchain-hardware.json','contract-before-edit.json','chord-replay-contract.json','nurbs-replay-contract.json','nested-resource-scope.json','idea-ledger.json','measurement-start.json','measurement-end.json','upstream-checkpoint.json','upstream-periodic-check.json','attempt-review.md','costs.md','remote-checkpoint.json','determinism-contract.json','determinism-diagnostic-comparison.json','artifact-nondeterminism-files.json','archive-shape-metrics.json','deterministic-candidate-freeze.json']:
 shutil.copy2(OUT/n,dest/n)
shutil.copy2(OUT/'candidate-frozen-source.json',dest/'candidate-source.json');shutil.copy2(OUT/'baseline-source.json',dest/'baseline-source.json')
with (dest/'qualified-source.patch.gz').open('wb') as f:
 with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:z.write((OUT/'qualified-source.patch').read_bytes())
readme=f'''# Coaxial Booleans with retained curved profiles

Complete positive-radius revolution solids now compose through the existing
Hypercurve filled-region Boolean. Original procedural parallels and
Boolean-selected profiles retain their sources and selected fields; native
polygonal carriers keep their existing path. Reconstruction independently
admits connected components, cavities and empty results. Common-axis proofs
include counterorientation, axial shifts and common similarities/reflections.

Hypercurve owns the new strict supporting-line point definition and the shared
NURBS source-parameter recovery. HyperBRep owns spatial/topological reduction,
reconstruction and metadata-accounted native encoding. No second curve kernel,
coordinate fitting or serialized proof flag is introduced.

## Qualification

{qualification}

See [construction-proof.md](construction-proof.md) and
[independent-oracles.md](independent-oracles.md) for the mathematical domain and
executable expectations. These arguments are not formal program verification.
[attempt-review.md](attempt-review.md) retains all failed development attempts.

## Cost and remaining scope

{cost_text}

[costs.md](costs.md) and [consumer-costs.json](consumer-costs.json) retain the
same-completed-contract observations and every unfavorable sample. Nested
record limits and their measured recipe are finite resource controls.

{limits}

Continue [next-domains.md](next-domains.md) and the complete development plan.

## Reproduction

Recreate base `{load('contract-before-edit.json')['base_revision']}`, apply the
[qualified source patch](qualified-source.patch.gz), and verify
[candidate-source.json](candidate-source.json). Later changes are evidence and
ledger documentation only. Remap absolute project roots when reproducing on a
new machine, preserving locks, source recipes and assertions. Baseline binary
reuse is documented separately; no fresh baseline build is claimed.

[validation.json](validation.json) records commands, features, logs, exits,
source snapshots and elapsed times. [raw-data.tar.gz](raw-data.tar.gz) preserves
scripts, full failed logs, source patches, projects, payloads and samples;
[raw-data-index.json](raw-data-index.json) verifies every member. Archive aliases
map identical payloads explicitly. Frozen build products are excluded; their
hashes and sizes remain. Source-path consumer success is not an installed-package
or production JavaScript-binding claim.
'''
(dest/'README.md').write_text(readme)
write('documentation-stage.json',dict(destination=str(dest),**{k:summary[k] for k in ['qualification','costs','limits']}))
print('Evidence documents written:',dest,flush=True)
