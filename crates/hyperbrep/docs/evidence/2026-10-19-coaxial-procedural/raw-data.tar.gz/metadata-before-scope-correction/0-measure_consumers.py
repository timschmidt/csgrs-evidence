"""Matched costs on affected preserved workflows; absolute new construction costs."""
from pathlib import Path
import hashlib,json,os,platform,statistics,subprocess
from run import OUT,ROOT,ENV
from source_identity import source_identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records={s:{r['cohort']:r for r in json.loads((OUT/f'{s}-consumers.json').read_text())} for s in ['baseline','candidate']}
counts={'revolution':8,'native':3,'procedural':1,'solids':2,'coaxial':5,'point-definitions':8}
cpu=min(os.sched_getaffinity(0));folder=OUT/'costs';folder.mkdir(exist_ok=False)
roots={'baseline':Path('/mnt/development/csgrs'),'candidate':ROOT}
identities={s:json.loads((OUT/f'{s}-consumer-source.json').read_text()) for s in roots}
assert all(source_identity(root)==identities[s] for s,root in roots.items())
rows=[];trials=[]
for cohort,count in counts.items():
 current=[];sides=['candidate'] if cohort in ['coaxial','point-definitions'] else ['baseline','candidate']
 for trial in range(3):
  for side in sides if trial%2==0 else list(reversed(sides)):
   binary=records[side][cohort]['native'];assert sha(binary['path'])==binary['sha256']
   label=f'{cohort}-{side}-{trial}';log=folder/(label+'.log');resource=folder/(label+'-resources.json')
   command=['python3','-B',str(OUT/'measure.py'),str(resource),'taskset','-c',str(cpu),binary['path'],'measure']
   print('Measuring',label,flush=True)
   with log.open('w') as stream:
    result=subprocess.run(['timeout','--signal=TERM','--kill-after=30s','1200s',*command],cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT)
   values=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
   record=dict(cohort=cohort,side=side,trial=trial,command=command,exit_code=result.returncode,resource=json.loads(resource.read_text()),rows=values,log=str(log),binary=binary)
   current.append(record);trials.append(record)
   (folder/'trials.json').write_text(json.dumps(trials,indent=2)+'\n')
   assert result.returncode==record['resource']['exit_code']==0 and len(values)==2*count,label
   assert all(source_identity(root)==identities[s] for s,root in roots.items())
 strip=lambda values:[{k:v for k,v in x.items() if k not in ['elapsed_ns','allocation_calls','requested_bytes']} for x in values]
 assert all(strip(t['rows'])==strip(current[0]['rows']) for t in current)
 for i,case in enumerate(current[0]['rows']):
  row={k:case[k] for k in ['case','phase','outcome','iterations']};row.update(cohort=cohort,matched_contract=cohort not in ['coaxial','point-definitions'])
  for side in sides:
   values=[t['rows'][i] for t in current if t['side']==side]
   row[side]={k:statistics.median(x[k]/x['iterations'] for x in values) for k in ['elapsed_ns','allocation_calls','requested_bytes']}
  row['ratio']=row['candidate']['elapsed_ns']/row['baseline']['elapsed_ns'] if row['matched_contract'] else None
  rows.append(row)
 (OUT/'consumer-costs.json').write_text(json.dumps(dict(cpu=cpu,platform=platform.platform(),rustc=subprocess.check_output(['rustc','-Vv'],env=ENV,text=True),trials=trials,rows=rows,
  scope='Three alternating CPU-pinned baseline/candidate pairs cover fourteen preserved completed workflows: eight retained revolution groups, three similarity/native-solid groups, the original clipped-cap extrusion and both original procedural solid revolution/replay recipes. Three absolute processes cover three newly completed coaxial Boolean/replay workflows, both archive limit/forgery/nesting groups and eight owner point-definition groups. Every process records first invocation and three repeated fresh-input invocations, except the expensive overlapping union/XOR group has one repeated invocation per process. All three processes and complete unchanged geometry remain measured. Assertions and output materialization remain inside timing. Earlier cases can warm immutable global caches; there is no disabled/evicted-cache claim. These instrumented shared-host samples establish neither a general speedup nor internal work/heap/cancellation bounds. Peak process RSS and requested allocation traffic are different quantities. The allocation counter covers Rust GlobalAlloc calls, not foreign allocator internals.'),indent=2)+'\n')
print('Measured',len(rows),'rows in',len(trials),'processes',flush=True)
