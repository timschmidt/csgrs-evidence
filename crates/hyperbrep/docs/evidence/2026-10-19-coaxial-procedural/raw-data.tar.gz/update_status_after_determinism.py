"""Append one finite increment without closing any broader work package."""
import json
from run import OUT,ROOT
from update_ledger import update_block
name='2026-10-19-coaxial-procedural'; ident='coaxial-procedural-2026-10-19'
dest=ROOT/'crates/hyperbrep/docs/evidence'/name
summary=json.loads((OUT/'qualification-summary.json').read_text())
contract=json.loads((OUT/'contract-before-edit.json').read_text())
p=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
data=json.loads(p.read_text()); assert not data['complete']
assert all(r['id']!=ident for r in data['increments'])
assert len(data['work_packages'])==28 and all(r['status'] in ['open','in-progress'] for r in data['work_packages'])
data['increments'].append(dict(id=ident,work_packages=['WP02','WP07','WP08','WP09','WP13','WP21'],properties=contract['properties'],change='Extend common-axis full-turn Booleans to native and retained curved profiles through Hypercurve filled regions, retaining independent supporting-line fields and shared NURBS contact roots across native replay. Reconstruct and admit components, cavities and empty outputs; preserve the native polygon path and stable source order across independent native revolution admissions.',sources=['../src/boolean_kernel/revolution.rs','../src/topology/mod.rs','../src/topology/query.rs','../src/topology/validation/revolution.rs','../src/persistence/planar_points.rs','../src/persistence/admission/shapes.rs','../../hypercurve/src/curve_point/definition.rs','../../hypercurve/src/bezier_offset/affine_form.rs','../../hypercurve/src/bezier_algebraic_image.rs'],evidence=f'evidence/{name}/manifest.json',validation=summary['qualification'],cost_evidence=summary['costs'],limits=summary['limits']))
data['updated_on']='2026-10-19'
data['next_actions'].insert(0,f'Preserve evidence/{name}/manifest.json and all earlier original profiles, archives and adverse costs. Continue its next-domains.md: selected angular/axial fields, partial and singular revolutions, general surface arrangements/Booleans, metrics, STEP, resource bounds and shipped consumers. The common-axis product reduction does not close general surface arrangements, replay resource contracts, any work package or pre-push qualification.')
p.write_text(json.dumps(data,indent=2)+'\n')
p=ROOT/'docs/properties-status.json'
ledger=json.loads(p.read_text())['current_work']['hyperbrep']
ledger.update(latest_evidence=f'crates/hyperbrep/docs/evidence/{name}/manifest.json',latest_feature_evidence=f'crates/hyperbrep/docs/evidence/{name}/manifest.json',latest_implementation=ident,latest_update_check=f'crates/hyperbrep/docs/evidence/{name}/remote-checkpoint.json',qualification=' '.join(summary[k] for k in ['qualification','costs','limits']))
record=update_block(p,ledger)
(dest/'ledger-update.json').write_text(json.dumps(record,indent=2)+'\n')
print('Appended increment',len(data['increments']),'with all 28 work packages still open/in progress.')
