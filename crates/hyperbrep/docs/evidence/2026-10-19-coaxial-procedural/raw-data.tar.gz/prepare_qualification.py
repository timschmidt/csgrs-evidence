"""Bind complete consumer recipes to this candidate; retain prior instrumented baselines."""
from pathlib import Path
import hashlib,json,re,shutil
from run import ROOT,OUT
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[x for x in json.loads((OUT/'preserved-consumers.json').read_text()) if x['side']=='candidate']
# New Boolean/point-archive corpus: direct inclusion of the same support modules.
p=OUT/'consumers/candidate/coaxial'
modules=[('acceptance',ROOT/'crates/hyperbrep/tests/support/coaxial_procedural.rs'),('point_archive',ROOT/'crates/hyperbrep/tests/support/supporting_line_archive.rs')]
entries=[(fn,f'{mod}::{fn}') for mod,path in modules for fn in re.findall(r'^pub fn (\w+)\(',path.read_text(),re.M)]
assert len(entries)==10,entries
p.joinpath('cases.rs').write_text('\n'.join(f'#[path = "{path}"]\nmod {mod};' for mod,path in modules)+'\n'+f"fn cases() -> [(&'static str, fn()); {len(entries)}] {{ [\n"+'\n'.join(f'("{name}", {function}),' for name,function in entries)+'\n] }\n')
p.joinpath('lib.rs').write_text('include!("cases.rs");\n'+'\n'.join(f'#[unsafe(no_mangle)]\npub extern "C" fn run_{i}() -> u32 {{ cases()[{i}].1(); 1 }}' for i in range(len(entries)))+'\n')
exports=OUT/'coaxial-exports.json';exports.write_text(json.dumps([[f'run_{i}',1] for i in range(len(entries))],indent=2)+'\n')
rows.append(dict(cohort='coaxial',side='candidate',project=str(p),groups=len(entries),wasm_only=False,has_wasm=True,binary='hyperbrep-coaxial-procedural-consumer',module='hyperbrep_coaxial_procedural_probe',exports=str(exports),entries=entries))
# Owner unit recipes become source-identical consumer functions, except test annotations.
p=OUT/'consumers/candidate/point-definitions'
source=ROOT/'crates/hypercurve/tests/selected_point_definitions.rs'
original=source.read_text();functions=re.findall(r'^#\[test\]\nfn (\w+)\(',original,re.M)
assert len(functions)==8,functions
converted=original.replace('#[test]\nfn ','pub fn ')
assert converted.replace('pub fn ','#[test]\nfn ')==original
p.joinpath('point_definitions.rs').write_text(converted)
p.joinpath('cases.rs').write_text('#[path = "point_definitions.rs"]\nmod acceptance;\n'+f"fn cases() -> [(&'static str, fn()); {len(functions)}] {{ [\n"+'\n'.join(f'("{fn}", acceptance::{fn}),' for fn in functions)+'\n] }\n')
p.joinpath('lib.rs').write_text('include!("cases.rs");\n#[unsafe(no_mangle)]\npub extern "C" fn run_probe() -> u32 { for (_,case) in cases() { case(); } '+str(len(functions))+' }\n')
rows.append(dict(cohort='point-definitions',side='candidate',project=str(p),groups=len(functions),wasm_only=False,has_wasm=True,binary='hypercurve-supporting-line-definition-consumer',module='hypercurve_supporting_line_definition_probe',transformation='Only #[test] fn changed to pub fn; all recipes and assertions retained.',source=str(source),source_sha256=sha(source),converted_sha256=sha(p/'point_definitions.rs')))
# The prior archive consumer uses the same three cold re-admissions and exact rows.
archive=OUT/'archive-project'
if not archive.exists():
 shutil.copytree('/tmp/hyperbrep-procedural-revolution-20261018/archive-project',archive)
for row in rows:
 project=Path(row['project']);row['inputs']={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
(OUT/'consumer-projects.json').write_text(json.dumps(dict(projects=rows),indent=2)+'\n')
print('Prepared',sum(r['groups'] for r in rows),'groups across',len(rows),'candidate projects')
