"""Retain all earlier qualification records, then freeze the corrected candidate."""
import hashlib,json,subprocess,datetime
from run import ROOT,OUT
from source_identity import source_identity
comparison=json.loads((OUT/'determinism-diagnostic-comparison.json').read_text())
assert len(comparison)==11 and all(r['byte_identical'] for r in comparison)
source=source_identity(ROOT)
assert source==json.loads((OUT/'determinism-diagnostic-source.json').read_text())['source']
old=json.loads((OUT/'candidate-frozen-source-before-determinism.json').read_text())
changed=[p for p in set(source)|set(old) if source.get(p)!=old.get(p)]
assert changed==['crates/hyperbrep/src/topology/validation/revolution.rs'],changed
for name in ['candidate-consumer-source.json','candidate-consumers.json','candidate-wasm-consumers.json','artifact-generation.json']:
 src=OUT/name;dest=OUT/(src.stem+'-before-determinism'+src.suffix)
 assert src.exists() and not dest.exists(),name
 src.rename(dest)
(OUT/'candidate-frozen-source.json').write_text(json.dumps(source,indent=2)+'\n')
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=ROOT)
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines():
 if name.endswith(('.rs','.toml','.json','.md','.py')):
  added=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=ROOT,capture_output=True)
  assert added.returncode in (0,1),added.stderr
  patch+=added.stdout
(OUT/'qualified-source.patch').write_bytes(patch)
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),entries=len(source),changed_since_prior_qualification=changed,patch_bytes=len(patch),patch_sha256=hashlib.sha256(patch).hexdigest(),diagnostic_files_per_run=11,diagnostic_fresh_processes=3,scope='All pre-fix sources, logs, binary hashes and both conflicting artifact sets remain retained. Fresh qualification uses separate binaries, artifact directories and labels.')
(OUT/'deterministic-candidate-freeze.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
