include!("cases.rs");

use std::alloc::{GlobalAlloc, Layout, System};
use std::hint::black_box;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::Instant;

struct CountingAllocator;
static COUNTING: AtomicBool = AtomicBool::new(false);
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
fn record(size: usize) {
    if COUNTING.load(Ordering::Relaxed) {
        CALLS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(size, Ordering::Relaxed);
    }
}
// SAFETY: The original pointers and layouts pass unchanged to System; the
// independent counters neither inspect allocations nor change their lifetime.
unsafe impl GlobalAlloc for CountingAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        record(layout.size());
        unsafe { System.alloc(layout) }
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        record(layout.size());
        unsafe { System.alloc_zeroed(layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        record(size);
        unsafe { System.realloc(ptr, layout, size) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[global_allocator]
static ALLOCATOR: CountingAllocator = CountingAllocator;

fn measure(name: &str, outcome: &str, operation: fn()) {
    CALLS.store(0, Ordering::Relaxed);
    BYTES.store(0, Ordering::Relaxed);
    COUNTING.store(true, Ordering::Relaxed);
    let started = Instant::now();
    black_box(operation)();
    let first_elapsed = started.elapsed().as_nanos();
    COUNTING.store(false, Ordering::Relaxed);
    println!(
        "{{\"case\":\"{name}\",\"phase\":\"first_fresh_input\",\"outcome\":\"{outcome}\",\"iterations\":1,\"elapsed_ns\":{first_elapsed},\"allocation_calls\":{},\"requested_bytes\":{}}}",
        CALLS.load(Ordering::Relaxed), BYTES.load(Ordering::Relaxed)
    );
    CALLS.store(0, Ordering::Relaxed);
    BYTES.store(0, Ordering::Relaxed);
    COUNTING.store(true, Ordering::Relaxed);
    let started = Instant::now();
    let iterations = if name == "coaxial_parallel_union_and_xor_overlap" { 1 } else { 3 };
    for _ in 0..iterations {
        black_box(operation)();
    }
    let elapsed = started.elapsed().as_nanos();
    COUNTING.store(false, Ordering::Relaxed);
    println!(
        "{{\"case\":\"{name}\",\"outcome\":\"{outcome}\",\"phase\":\"repeated_fresh_input\",\"iterations\":{iterations},\"elapsed_ns\":{elapsed},\"allocation_calls\":{},\"requested_bytes\":{}}}",
        CALLS.load(Ordering::Relaxed),
        BYTES.load(Ordering::Relaxed)
    );
}
fn main() {
    let mode = std::env::args().nth(1).unwrap_or_else(|| "all".into());
    for (name, operation) in cases() {
        if mode == "measure" && !["full_parallel_revolution_boolean_continues", "selected_parallel_revolution_boolean_continues", "supporting_line_archive_limits_and_forgery_recover", "nested_supporting_line_archives_replay_with_record_limits", "coaxial_parallel_union_and_xor_overlap"].contains(&name) { continue; }
        if mode == "measure" {
            measure(name, "certified_or_expected_typed_control", operation);
        } else {
            assert_eq!(mode, "all");
            operation();
            println!("case={name} outcome=passed");
        }
    }
}
