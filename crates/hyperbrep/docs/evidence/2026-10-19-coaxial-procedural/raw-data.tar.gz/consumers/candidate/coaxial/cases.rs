#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/coaxial_procedural.rs"]
mod acceptance;
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/supporting_line_archive.rs"]
mod point_archive;
fn cases() -> [(&'static str, fn()); 10] { [
("full_parallel_revolution_boolean_continues", acceptance::full_parallel_revolution_boolean_continues),
("selected_parallel_revolution_boolean_continues", acceptance::selected_parallel_revolution_boolean_continues),
("coaxial_parallel_union_and_xor_overlap", acceptance::coaxial_parallel_union_and_xor_overlap),
("coaxial_native_arc_and_nurbs_profiles_continue", acceptance::coaxial_native_arc_and_nurbs_profiles_continue),
("coaxial_selected_axes_similarities_and_exact_gaps", acceptance::coaxial_selected_axes_similarities_and_exact_gaps),
("coaxial_procedural_cavities_xor_and_empty_recover", acceptance::coaxial_procedural_cavities_xor_and_empty_recover),
("coaxial_selected_split_output_continues", acceptance::coaxial_selected_split_output_continues),
("coaxial_procedural_certainty_budget_and_axis_rejection", acceptance::coaxial_procedural_certainty_budget_and_axis_rejection),
("supporting_line_archive_limits_and_forgery_recover", point_archive::supporting_line_archive_limits_and_forgery_recover),
("nested_supporting_line_archives_replay_with_record_limits", point_archive::nested_supporting_line_archives_replay_with_record_limits),
] }
