include!("cases.rs");
fn main() {
 for (name, case) in cases() {
  if matches!(name, "coaxial_parallel_union_and_xor_overlap" | "coaxial_native_arc_and_nurbs_profiles_continue" | "coaxial_selected_axes_similarities_and_exact_gaps") {
   case();
   println!("case={name} outcome=passed");
  }
 }
}
