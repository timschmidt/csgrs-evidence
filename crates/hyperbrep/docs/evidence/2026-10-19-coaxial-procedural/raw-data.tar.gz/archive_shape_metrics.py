"""Measure serialized structure without treating it as a live heap/work bound."""
from pathlib import Path
import hashlib,json
from run import OUT
assert (OUT/'archive-summary.json').is_file(), 'Admit and compare artifacts before measuring retained structure'
rows=[]
roots=[('preserved_baseline',OUT/'artifacts/baseline'),('corrected_candidate',OUT/'artifacts/candidate-deterministic'),('pre_fix_candidate',OUT/'artifacts/candidate')]
for phase,root in roots:
 for p in sorted(root.rglob('*.json')):
  if p.parent.name!='0':continue
  raw=p.read_bytes();data=json.loads(raw)
  nodes=0;max_depth=0;rationals=0;num_limbs=0;den_limbs=0;max_num_limbs=0;max_den_limbs=0;support_records=0;max_support_depth=0
  pending=[(data,0,0)]
  while pending:
   value,depth,support_depth=pending.pop();nodes+=1;max_depth=max(max_depth,depth)
   if isinstance(value,dict):
    rational=value.get('rational')
    if isinstance(rational,dict) and 'numerator' in rational and 'denominator' in rational:
     n=rational['numerator'];d=rational['denominator']
     assert isinstance(n,list) and isinstance(d,list),(p,'unexpected rational storage')
     assert all(isinstance(x,int) and 0<=x<2**32 for x in n+d),(p,'unexpected rational limb')
     rationals+=1;num_limbs+=len(n);den_limbs+=len(d);max_num_limbs=max(max_num_limbs,len(n));max_den_limbs=max(max_den_limbs,len(d))
    for key,child in value.items():
     selected_depth=support_depth+int(key=='SupportingLineIntersection')
     if key=='SupportingLineIntersection':support_records+=1;max_support_depth=max(max_support_depth,selected_depth)
     pending.append((child,depth+1,selected_depth))
   elif isinstance(value,list):
    pending.extend((child,depth+1,support_depth) for child in value)
  arrays={k:len(data[k]) for k in ['vertices','curves','pcurves','surfaces','edges','edge_uses','wires','faces','shells','solids'] if isinstance(data.get(k),list)}
  selection={k:len(v) for k,v in data.get('selection',{}).items() if isinstance(v,list)}
  rows.append(dict(phase=phase,path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),json_value_nodes=nodes,max_json_value_depth=max_depth,rational_records=rationals,total_numerator_limbs=num_limbs,total_denominator_limbs=den_limbs,max_numerator_limbs=max_num_limbs,max_denominator_limbs=max_den_limbs,supporting_line_records=support_records,max_inline_supporting_line_depth=max_support_depth,model_arrays=arrays,selection_arrays=selection))
summary={}
for phase,_ in roots:
 selected=[r for r in rows if r['phase']==phase]
 assert selected,phase
 summary[phase]=dict(files=len(selected),total_bytes=sum(r['bytes'] for r in selected),max_archive_bytes=max(r['bytes'] for r in selected),max_json_value_depth=max(r['max_json_value_depth'] for r in selected),max_numerator_limbs=max(r['max_numerator_limbs'] for r in selected),max_denominator_limbs=max(r['max_denominator_limbs'] for r in selected),max_inline_supporting_line_depth=max(r['max_inline_supporting_line_depth'] for r in selected))
result=dict(scope='Read-only measurements of each first-pass JSON artifact after exact admission and byte-comparison gates. Scalar limb counts use the stored numerator/denominator arrays (observed unsigned 32-bit entries); they are not polynomial degree, coefficient-computation work, live heap, or a bound on arbitrary input. JSON depth measures the serialized value tree, not Rust stack use. Pre-fix archives are retained as a separate failed-determinism attempt, not a performance baseline. No parameter/source field is rewritten.',summary=summary,rows=rows)
(OUT/'archive-shape-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary),flush=True)
