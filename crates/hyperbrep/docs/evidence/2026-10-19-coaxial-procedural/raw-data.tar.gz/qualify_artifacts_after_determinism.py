"""Compare fresh deterministic outputs and cold-replay every distinct archive content."""
from pathlib import Path
import collections,hashlib,json,shutil
from concurrent.futures import ThreadPoolExecutor,as_completed
from run import ROOT,OUT,ENV,run
from source_identity import source_identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((OUT/'candidate-consumer-source.json').read_text())
assert source_identity(ROOT)==source
records={r['cohort']:r for r in json.loads((OUT/'candidate-consumers.json').read_text())}
keys={'revolution':'HYPERBREP_SELECTED_REVOLUTION_ARTIFACT_DIR','procedural':'HYPERBREP_SELECTED_PROCEDURAL_ARTIFACT_DIR','solids':'HYPERBREP_PROCEDURAL_REVOLUTION_ARTIFACT_DIR','coaxial':'HYPERBREP_COAXIAL_PROCEDURAL_ARTIFACT_DIR'}
def checked(label,command,**kwargs):
 assert run(dict(label=label,command=command,**kwargs))==0,label
 assert source_identity(ROOT)==source
rows=[];pairs=[]
jobs=[]
for name,key in keys.items():
 binary=records[name]['native'];assert sha(binary['path'])==binary['sha256']
 dest=OUT/'artifacts/candidate-deterministic'/name/'1';dest.mkdir(parents=True,exist_ok=False)
 jobs.append((name,key,binary,dest))
# Independent deterministic-output validation; these are not timing samples.
with ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(checked,'artifact-repeat-deterministic-'+name,[binary['path'],'all'],env={key:str(dest)},seconds=1800) for name,key,binary,dest in jobs]
 for future in as_completed(futures):future.result()
for name,key,binary,dest in jobs:
 first=dest.parent/'0'
 assert {p.relative_to(dest) for p in dest.rglob('*') if p.is_file()}=={p.relative_to(first) for p in first.rglob('*') if p.is_file()}
 for p in sorted(dest.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(dest);a=first/relative
  assert a.read_bytes()==p.read_bytes(),('nondeterministic',name,relative)
  for repeat,artifact in [(0,a),(1,p)]:
   rows.append(dict(cohort=name,side='candidate',repeat=repeat,name=str(relative),path=str(artifact),bytes=artifact.stat().st_size,sha256=sha(artifact)))
  baseline=OUT/'artifacts/baseline'/name/'0'/relative
  if name!='coaxial':
   assert baseline.exists(),baseline
   assert baseline.read_bytes()==a.read_bytes(),('baseline changed',name,relative)
   pairs.append(dict(name=name+'/'+str(relative),baseline=str(baseline),candidate=str(a),byte_identical=True,sha256=sha(a),bytes=a.stat().st_size))
 (OUT/'artifact-generation.json').write_text(json.dumps(rows,indent=2)+'\n')
(OUT/'generated-artifact-pairs.json').write_text(json.dumps(pairs,indent=2)+'\n')
# Preserve all previous inputs and generated outputs, plus each fresh artifact.
old=Path('/tmp/hyperbrep-procedural-revolution-20261018')
inputs=[]
def add(name,path,expected=None,scope='historical'):
 p=Path(path);h=sha(p);original_path=str(p)
 if expected:assert h==expected,p
 if not p.is_relative_to(OUT):
  stored=OUT/'prior-inputs'/(h+p.suffix);stored.parent.mkdir(exist_ok=True)
  if stored.exists():assert sha(stored)==h
  else:shutil.copy2(p,stored)
  p=stored
 inputs.append(dict(name=name,path=str(p),original_path=original_path,sha256=h,bytes=p.stat().st_size,scope=scope))
for r in json.loads((old/'prior-artifact-inputs.json').read_text()):add('prior/'+r['name'],r['path'],r['sha256'])
for i,r in enumerate(json.loads((old/'artifact-generation.json').read_text())):add(f'previous-generated/{i}/'+r['name'],r['path'],r['sha256'])
for p in sorted((OUT/'artifacts/baseline').rglob('*')):
 if p.is_file():add('fresh-baseline/'+str(p.relative_to(OUT/'artifacts/baseline')),p,scope='fresh_baseline')
for p in sorted((OUT/'artifacts/candidate').rglob('*')):
 if p.is_file():add('pre-fix-candidate/'+str(p.relative_to(OUT/'artifacts/candidate')),p,scope='retained_failed_determinism_attempt')
for p in sorted((OUT/'determinism-diagnostic-artifacts').rglob('*')):
 if p.is_file():add('determinism-diagnostic/'+str(p.relative_to(OUT/'determinism-diagnostic-artifacts')),p,scope='fresh_determinism_diagnostic')
for r in rows:add('fresh-candidate/'+r['cohort']+'/'+str(r['repeat'])+'/'+r['name'],r['path'],r['sha256'],scope='fresh_candidate')
groups={}
for r in inputs:groups.setdefault((Path(r['path']).suffix,r['sha256']),[]).append(r)
representatives=[];aliases=[]
for i,((extension,h),members) in enumerate(groups.items()):
 representative=dict(members[0],name=f'{i:04d}{extension}')
 representatives.append(representative)
 aliases.append(dict(representative=representative['name'],sha256=h,extension=extension,members=members))
(OUT/'archive-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(OUT/'archive-aliases.json').write_text(json.dumps(aliases,indent=2)+'\n')
unique=OUT/'archive-distinct-inputs.json';unique.write_text(json.dumps(representatives,indent=2)+'\n')
project=OUT/'archive-project';manifest=str(project/'Cargo.toml')
checked('archive-clippy',['cargo','clippy','--offline','--locked','--all-targets','--manifest-path',manifest,'--','-D','warnings'])
checked('archive-build',['cargo','build','--offline','--locked','--release','--manifest-path',manifest])
binary=OUT/'binaries/candidate-archive-replay';assert not binary.exists()
shutil.copy2(Path(ENV['CARGO_TARGET_DIR'])/'release/hyperbrep-revolution-archive-consumer',binary)
(OUT/'archive-consumer.json').write_text(json.dumps(dict(binary=dict(path=str(binary),sha256=sha(binary),bytes=binary.stat().st_size),source=source,inputs={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}),indent=2)+'\n')
destination=OUT/'distinct-reencoded'
checked('archive-distinct-replay',[str(binary),str(unique),str(destination)],seconds=2400)
results=[json.loads(x) for x in (OUT/'archive-distinct-replay.log').read_text().splitlines() if x.startswith('{')]
assert len(results)==len(representatives)
for r in results:assert not r['changed_scalar_encodings'],r['path']
for r in representatives:
 if Path(r['path']).suffix=='.json':assert Path(r['path']).read_bytes()==(destination/r['name']).read_bytes(),r['name']
summary=dict(input_aliases=len(inputs),distinct_contents=len(representatives),alias_extensions=dict(collections.Counter(Path(r['path']).suffix for r in inputs)),distinct_outcomes=dict(collections.Counter(r['outcome'] for r in results)),distinct_step_bodies=sum(r['imported_step_bodies'] for r in results),fresh_byte_identical_pairs=len(pairs),new_coaxial_files=sum(r['cohort']=='coaxial' and r['repeat']==0 for r in rows),scope='Every distinct (file extension, SHA-256) content is executed once by the archive consumer, with three cold native re-admissions per model. All aliases retain verified hashes. Text controls are inventory-only. Candidate recipes execute twice independently; second-pass validation uses up to three independent processes and is not a timing comparison; each preserved candidate output also matches freshly executed frozen-baseline bytes. This deduplicates repeated identical input contents without dropping any distinct fixture.')
(OUT/'archive-replay-results.json').write_text(json.dumps(results,indent=2)+'\n')
(OUT/'archive-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
