
pub fn nested_supporting_line_archives_replay_with_record_limits() {
    let p=|x:i32,y:i32| -> hypercurve::CurvePoint2 { Uv::from_values(x,y).into() };
    for depth in [1,2,4,8] {
        let mut point=CurvePointDefinition2::SupportingLineIntersection {
            first:[p(0,0),p(1,0)],second:[p(2,1),p(2,2)],
        }.into_point().unwrap();
        for i in 1..depth {
            point=CurvePointDefinition2::SupportingLineIntersection {
                first:[point,p(i+3,0)],second:[p(i+2,1),p(i+2,2)],
            }.into_point().unwrap();
        }
        let mut builder=ModelBuilder::new();
        builder.pcurve(Pcurve::new(Curve2::try_line(point,p(depth+2,0)).unwrap())).unwrap();
        let json=builder.finish().unwrap().to_json().unwrap();
        let records=3+4*usize::try_from(depth).unwrap();
        let exact=ArchiveLimits{records,..ArchiveLimits::default()};
        assert!(matches!(RawModel::from_json(&json,&ArchiveLimits{records:records-1,..exact}),Err(PersistenceError::ResourceLimit(ArchiveLimitExceeded{resource:ArchiveResource::Records,observed,..})) if observed==records));
        let cold=RawModel::from_json(&json,&exact).unwrap().validate().unwrap();
        assert_eq!(cold.to_json().unwrap(),json);
        assert!(cold.pcurves().next().unwrap().curve().start().coincides_with(&p(depth+1,0)).unwrap());
    }
}
