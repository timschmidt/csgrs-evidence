"""Build and execute source-qualified native and zero-import WASM consumers."""
from pathlib import Path
import argparse,hashlib,json,shutil,time
from run import OUT,ROOT,ENV,run
from source_identity import source_identity
parser=argparse.ArgumentParser();parser.add_argument('--resume',action='store_true');args=parser.parse_args()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=source_identity(ROOT);identity=OUT/'candidate-consumer-source.json'
if identity.exists():
 assert args.resume and json.loads(identity.read_text())==source
else:identity.write_text(json.dumps(source,indent=2)+'\n')
projects=json.loads((OUT/'consumer-projects.json').read_text())['projects']
path=OUT/'candidate-consumers.json';records=json.loads(path.read_text()) if path.exists() else []
assert args.resume or not records
done={r['cohort'] for r in records}
for r in records:
 for kind in ['native','wasm']:assert sha(r[kind]['path'])==r[kind]['sha256']
keys={'revolution':'HYPERBREP_SELECTED_REVOLUTION_ARTIFACT_DIR','procedural':'HYPERBREP_SELECTED_PROCEDURAL_ARTIFACT_DIR','solids':'HYPERBREP_PROCEDURAL_REVOLUTION_ARTIFACT_DIR','coaxial':'HYPERBREP_COAXIAL_PROCEDURAL_ARTIFACT_DIR'}
def checked(label,command,**kwargs):
 assert run(dict(label=label,command=command,**kwargs))==0,label
 assert source_identity(ROOT)==source,'source changed during qualification'
def freeze(p,name):
 dest=OUT/'binaries'/name;assert not dest.exists();shutil.copy2(p,dest)
 return dict(path=str(dest),bytes=dest.stat().st_size,sha256=sha(dest))
for item in projects:
 name=item['cohort']
 if name in done:continue
 project=Path(item['project']);manifest=str(project/'Cargo.toml');tag='consumer-candidate-deterministic-'+name
 if not (project/'Cargo.lock').exists():checked(tag+'-lock',['cargo','generate-lockfile','--offline','--manifest-path',manifest])
 row=dict(**{k:v for k,v in item.items() if k!='inputs'},inputs={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()})
 checked(tag+'-clippy',['cargo','clippy','--offline','--locked','--all-targets','--manifest-path',manifest,'--','-D','warnings'])
 checked(tag+'-build',['cargo','build','--offline','--locked','--release','--manifest-path',manifest])
 row['native_validation_prefix']=tag
 row['native']=freeze(Path(ENV['CARGO_TARGET_DIR'])/'release'/item['binary'],'candidate-deterministic-'+name)
 capture={}
 if name in keys:
  destination=OUT/'artifacts/candidate-deterministic'/name/'0';destination.mkdir(parents=True,exist_ok=False);capture={keys[name]:str(destination)}
 checked(tag+'-runtime',[row['native']['path'],'all'],env=capture,seconds=1800)
 if name=='procedural':checked(tag+'-step',[row['native']['path'],'step'],seconds=900)
 # Reuse only the separately executed frozen-source WASM qualification.
 began=time.monotonic()
 while True:
  assert not (OUT/'wasm-qualification-failed.json').exists(),'independent WASM qualification failed'
  q=OUT/'candidate-wasm-consumers.json'
  try:completed=json.loads(q.read_text()) if q.exists() else []
  except json.JSONDecodeError:
   time.sleep(0.1)
   continue
  wasm=next((r for r in completed if r['cohort']==name),None)
  if wasm is not None:break
  assert time.monotonic()-began<7200,'WASM qualification wait exhausted'
  time.sleep(3)
 assert row['inputs']==wasm['inputs'] and sha(wasm['wasm']['path'])==wasm['wasm']['sha256']
 row['wasm']=wasm['wasm'];row['wasm_validation_prefix']=wasm['validation_prefix']
 records.append(row);path.write_text(json.dumps(records,indent=2)+'\n')
print('Qualified',sum(r['groups'] for r in records),'native and WASM groups',flush=True)
