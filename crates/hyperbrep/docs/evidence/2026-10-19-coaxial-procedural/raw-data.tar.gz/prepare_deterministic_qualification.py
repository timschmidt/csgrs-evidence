"""Prepare a fresh qualification epoch without overwriting failed attempt artifacts."""
from pathlib import Path
import json
from run import OUT

def variant(name,changes):
 source=(OUT/(name+'.py')).read_text()
 for old,new in changes:
  assert old in source,(name,old)
  source=source.replace(old,new)
 target=OUT/(name+'_after_determinism.py');assert not target.exists();target.write_text(source)

variant('qualify_consumers',[
 ("tag='consumer-candidate-'+name", "tag='consumer-candidate-deterministic-'+name"),
 ("row['native']=freeze", "row['native_validation_prefix']=tag\n row['native']=freeze"),
 ("'candidate-'+name)", "'candidate-deterministic-'+name)"),
 ("'artifacts/candidate'", "'artifacts/candidate-deterministic'"),
])
variant('qualify_wasm',[
 ("tag='parallel-wasm-'+name", "tag='deterministic-wasm-'+name"),
 ("'candidate-'+name+'.wasm'", "'candidate-deterministic-'+name+'.wasm'"),
])
variant('qualify_artifacts',[
 ("'artifacts/candidate'", "'artifacts/candidate-deterministic'"),
 ("'artifact-repeat-'+name", "'artifact-repeat-deterministic-'+name"),
 ("for r in rows:add('fresh-candidate/'", "for p in sorted((OUT/'artifacts/candidate').rglob('*')):\n if p.is_file():add('pre-fix-candidate/'+str(p.relative_to(OUT/'artifacts/candidate')),p,scope='retained_failed_determinism_attempt')\nfor p in sorted((OUT/'determinism-diagnostic-artifacts').rglob('*')):\n if p.is_file():add('determinism-diagnostic/'+str(p.relative_to(OUT/'determinism-diagnostic-artifacts')),p,scope='fresh_determinism_diagnostic')\nfor r in rows:add('fresh-candidate/'"),
])
labels={
 'strict-clippy-all-02':'strict-clippy-all-03',
 'tests-all-features-02':'tests-all-features-03',
 'tests-minimal-features-01':'tests-minimal-features-02',
 'owner-regressions-01':'owner-regressions-02',
 'clippy-minimal-features-01':'clippy-minimal-features-02',
 'rustdoc-01':'rustdoc-02',
 'fuzz-check-01':'fuzz-check-02',
 'format-check-01':'format-check-02',
}
variant('after_checks',list(labels.items())+[("['qualify_consumers.py','qualify_artifacts.py']","['qualify_consumers_after_determinism.py','qualify_artifacts_after_determinism.py']")])
variant('write_evidence',list(labels.items())+[
 ('all_tests==728 and minimal==720','all_tests==729 and minimal==721'),
 ("checks['consumer-candidate-'+r['cohort']+'-runtime']", "checks[r['native_validation_prefix']+'-runtime']"),
 ('Two earlier private-query expectations now assert', 'A further owner regression preserves exact profile sequence across 64 cold admissions of identical polygon/NURBS archives. Three fresh diagnostic processes repeat the original full union/XOR, NURBS and transformed-axis recipes. Two earlier private-query expectations now assert'),
 ("'attempt-review.md','costs.md'", "'attempt-review.md','costs.md','remote-checkpoint.json','determinism-contract.json','determinism-diagnostic-comparison.json','artifact-nondeterminism-files.json'"),
 ("'The final focused NURBS and point/archive tests", "'The first fresh-process archive comparison exposed five nonidentical outputs, despite passing exact set and same-process replay checks. Native revolution admission seeded its retained meridian cycle from randomized HashMap traversal. A focused cold-admission regression reproduced this before changing the grouping to stable surface-ID order. Both pre-fix output sets and all full fixtures remain in the audit; no scalar-chart or geometry normalization was used to hide the mismatch.', '', 'The final focused NURBS and point/archive tests"),
])
print('Prepared separate post-determinism consumer, artifact, orchestration and evidence scripts')
