
pub fn coaxial_parallel_union_and_xor_overlap() {
    let original=cap(false);
    let tool=radial_band(4.into(),6.into());
    let left=boolean::union(&original,&tool).unwrap();
    let right=boolean::union(&tool,&original).unwrap();
    for joined in [&left,&right] {
        assert_eq!(joined.len(),1);
        let cold=replay(joined);
        for (r,z,expected) in [
            (3.into(),0.into(),SolidPointLocation::Inside),
            (7.into(),0.into(),SolidPointLocation::Inside),
            (5.into(),0.into(),SolidPointLocation::Inside),
            (5.into(),q(5,2),SolidPointLocation::Inside),
            (5.into(),q(-5,2),SolidPointLocation::Inside),
            (5.into(),3.into(),SolidPointLocation::Boundary),
            (3.into(),q(5,2),SolidPointLocation::Outside),
            (0.into(),0.into(),SolidPointLocation::Outside),
        ] {assert_eq!(location(&cold,r,z),expected);}
    }
    assert!(boolean::difference(&left,&right).unwrap().is_empty());
    assert!(boolean::difference(&right,&left).unwrap().is_empty());
    let xor=boolean::symmetric_difference(&original,&tool).unwrap();
    // The two side lobes and the band's top/bottom each have a connected
    // volume interior; closures meet along boundary circles only.
    assert_eq!(xor.len(),4);
    let cold=replay(&xor);
    for (r,z,expected) in [
        (3.into(),0.into(),SolidPointLocation::Inside),
        (7.into(),0.into(),SolidPointLocation::Inside),
        (5.into(),q(5,2),SolidPointLocation::Inside),
        (5.into(),q(-5,2),SolidPointLocation::Inside),
        (5.into(),0.into(),SolidPointLocation::Outside),
        (0.into(),0.into(),SolidPointLocation::Outside),
    ] {assert_eq!(location(&cold,r,z),expected);}
    let common=boolean::intersection(&original,&tool).unwrap();
    assert!(boolean::intersection(&xor,&common).unwrap().is_empty());
    let filled=boolean::union(&xor,&common).unwrap();
    assert!(boolean::difference(&filled,&left).unwrap().is_empty());
    assert!(boolean::difference(&left,&filled).unwrap().is_empty());
}
