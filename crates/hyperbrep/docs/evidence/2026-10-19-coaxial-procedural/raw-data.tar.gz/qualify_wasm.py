"""Execute independent WASM checks on the frozen source in a separate Cargo target directory."""
from pathlib import Path
import hashlib,json,shutil,traceback
from run import OUT,ROOT,run
from source_identity import source_identity
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((OUT/'candidate-frozen-source.json').read_text())
projects=json.loads((OUT/'consumer-projects.json').read_text())['projects']
target=Path('/tmp/hyperbrep-review-wasm-target');records=[]
record=OUT/'candidate-wasm-consumers.json';assert not record.exists()
def checked(label,command,**kwargs):
 assert run(dict(label=label,command=command,**kwargs))==0,label
 assert source_identity(ROOT)==source,'frozen source changed during WASM qualification'
try:
 for item in projects:
  name=item['cohort'];p=Path(item['project']);tag='parallel-wasm-'+name
  assert (p/'Cargo.lock').exists()
  inputs={str(q.relative_to(p)):sha(q) for q in p.rglob('*') if q.is_file()}
  checked(tag+'-build',['cargo','build','--offline','--locked','--release','--lib','--target','wasm32-unknown-unknown','--manifest-path',str(p/'Cargo.toml')],env={'RUSTFLAGS':'-D warnings','CARGO_TARGET_DIR':str(target)},seconds=2400)
  binary=OUT/'binaries'/('candidate-'+name+'.wasm');assert not binary.exists();shutil.copy2(target/'wasm32-unknown-unknown/release'/(item['module']+'.wasm'),binary)
  checked(tag+'-runtime',['python3','-B',str(OUT/'wasm_consumer.py'),str(binary),str(item['groups']),*([item['exports']] if 'exports' in item else [])],seconds=2400)
  assert inputs=={str(q.relative_to(p)):sha(q) for q in p.rglob('*') if q.is_file()}
  records.append(dict(cohort=name,groups=item['groups'],project=str(p),inputs=inputs,wasm=dict(path=str(binary),bytes=binary.stat().st_size,sha256=sha(binary)),validation_prefix=tag))
  record.write_text(json.dumps(records,indent=2)+'\n')
 print('All',sum(r['groups'] for r in records),'frozen-source WASM groups passed',flush=True)
except BaseException as error:
 (OUT/'wasm-qualification-failed.json').write_text(json.dumps(dict(error=str(error),completed=[r['cohort'] for r in records],traceback=traceback.format_exc()),indent=2)+'\n')
 raise
