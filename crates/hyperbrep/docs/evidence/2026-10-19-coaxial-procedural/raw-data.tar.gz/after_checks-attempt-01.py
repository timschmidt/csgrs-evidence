"""Continue frozen-source boundary checks only after the affected local matrix passes."""
import json,subprocess,sys,time
from run import ROOT,OUT,ENV
from source_identity import source_identity
required=['tests-all-features-01','tests-minimal-features-01','owner-regressions-01','clippy-minimal-features-01','rustdoc-01','fuzz-check-01','format-check-01']
frozen=json.loads((OUT/'candidate-frozen-source.json').read_text())
assert source_identity(ROOT)==frozen
start=time.monotonic();previous=()
while True:
 rows={r['label']:r for r in json.loads((OUT/'results.json').read_text())}
 completed=tuple(label for label in required if label in rows)
 if completed!=previous:print('Completed local checks:',','.join(completed),flush=True);previous=completed
 for label in completed:
  if rows[label]['exit_code']:raise SystemExit('Local check failed: '+label)
 if len(completed)==len(required):break
 if time.monotonic()-start>10800:raise SystemExit('Timed out waiting for local matrix')
 time.sleep(3)
assert source_identity(ROOT)==frozen
for script in ['qualify_consumers.py','qualify_artifacts.py']:
 print('Starting',script,flush=True)
 result=subprocess.run([sys.executable,'-B',str(OUT/script)],cwd=ROOT,env=ENV)
 if result.returncode:raise SystemExit(result.returncode)
assert source_identity(ROOT)==frozen
print('Native/WASM/archive qualification complete; measurements remain separate.',flush=True)
