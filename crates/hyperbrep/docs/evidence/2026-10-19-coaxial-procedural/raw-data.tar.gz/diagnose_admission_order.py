"""Repeat the unchanged full failing workflows in three fresh native processes."""
from pathlib import Path
import hashlib,json,shutil,time
from concurrent.futures import ThreadPoolExecutor
from run import OUT,ROOT,ENV,run
from source_identity import source_identity
source=source_identity(ROOT)
started=time.monotonic()
while True:
 rows={r['label']:r for r in json.loads((OUT/'results.json').read_text())}
 if 'determinism-native-admission-after' in rows:
  assert rows['determinism-native-admission-after']['exit_code']==0
 if 'determinism-diagnostic-build' in rows:
  assert rows['determinism-diagnostic-build']['exit_code']==0
  break
 assert time.monotonic()-started<1800
 time.sleep(2)
assert source_identity(ROOT)==source
binary=OUT/'binaries/admission-order-diagnostic';assert not binary.exists()
shutil.copy2(Path(ENV['CARGO_TARGET_DIR'])/'release/hyperbrep-admission-order-diagnostic',binary)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'determinism-diagnostic-source.json').write_text(json.dumps({'source':source,'binary_sha256':sha(binary)},indent=2)+'\n')
folders=[];jobs=[]
for i in range(3):
 dest=OUT/'determinism-diagnostic-artifacts'/str(i);dest.mkdir(parents=True,exist_ok=False);folders.append(dest)
 jobs.append(dict(label=f'determinism-diagnostic-run-{i}',command=[str(binary)],env={'HYPERBREP_COAXIAL_PROCEDURAL_ARTIFACT_DIR':str(dest)},seconds=1200))
with ThreadPoolExecutor(max_workers=3) as pool:
 statuses=list(pool.map(run,jobs))
assert statuses==[0]*3,statuses
assert source_identity(ROOT)==source
names=sorted(p.name for p in folders[0].iterdir())
assert all(sorted(p.name for p in f.iterdir())==names for f in folders)
rows=[]
for name in names:
 hashes=[sha(f/name) for f in folders]
 rows.append(dict(name=name,sha256=hashes,byte_identical=len(set(hashes))==1,bytes=[(f/name).stat().st_size for f in folders]))
(OUT/'determinism-diagnostic-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Fresh runs:',len(folders),'files per run:',len(names),'differing:',[r['name'] for r in rows if not r['byte_identical']],flush=True)
assert all(r['byte_identical'] for r in rows)
