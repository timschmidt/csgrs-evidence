"""Retain and verify all raw qualification evidence, excluding build products."""
from pathlib import Path
import gzip, hashlib, json, shutil, tarfile
from run import OUT, ROOT

DEST = ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-coaxial-procedural'
assert DEST.is_dir() and (OUT/'documentation-stage.json').is_file()
assert len(json.loads((OUT/'consumer-costs.json').read_text())['trials']) == 30
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = json.loads((OUT/'archive-inputs.json').read_text())
assert all(sha(r['path']) == r['sha256'] for r in inputs)
shutil.copy2(OUT/'results.json', DEST/'validation.json')
folders = {'archive-project', 'consumers', 'artifacts', 'prior-reencoded', 'costs',
    'prior-inputs', 'distinct-reencoded', 'drafts', 'diagnostic-admission-order',
    'determinism-diagnostic-artifacts', 'metadata-before-scope-correction'}
extensions = {'.json','.log','.rs','.md','.toml','.py','.patch','.lock','.step','.txt'}
files = []
for p in OUT.rglob('*'):
    relative = p.relative_to(OUT)
    if not p.is_file() or p.is_symlink(): continue
    if len(relative.parts) > 1 and relative.parts[0] not in folders: continue
    if any(x in relative.parts for x in ['target','__pycache__','.git','node_modules']): continue
    if p.suffix not in extensions or p.name == 'results.lock': continue
    files.append(p)
files.sort(key=lambda p: str(p.relative_to(OUT)))
index = [dict(path=str(p.relative_to(OUT)), bytes=p.stat().st_size, sha256=sha(p)) for p in files]
(DEST/'raw-data-index.json').write_text(json.dumps(dict(files=index,
    excluded='Frozen binaries build products and caches. Binary hashes/sizes, all original source recipes, logs and reconstruction inputs are retained.'), indent=2)+'\n')
archive=DEST/'raw-data.tar.gz'; assert not archive.exists()
with archive.open('wb') as f:
    with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:
        with tarfile.open(fileobj=z,mode='w|') as tar:
            for p in files:
                info=tar.gettarinfo(str(p),arcname=str(p.relative_to(OUT)))
                info.uid=info.gid=info.mtime=0; info.uname=info.gname=''
                with p.open('rb') as content: tar.addfile(info,content)
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers(); assert len(members)==len(index)
    for member,row in zip(members,index):
        assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
        assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
summary=dict(files=len(index),raw_bytes=sum(r['bytes'] for r in index),compressed_bytes=archive.stat().st_size,
    sha256=sha(archive),original_inputs_retained=len(inputs))
(DEST/'raw-data-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
