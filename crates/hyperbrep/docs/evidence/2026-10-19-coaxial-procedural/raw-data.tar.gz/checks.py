"""Final affected local checks; failures remain in the append-only results ledger."""
from run import run
jobs=[
 {'label':'strict-clippy-all-02','command':['cargo','clippy','--offline','--locked','-p','hyperbrep','-p','hyperbrep-io','-p','hypercurve','--all-features','--all-targets','--','-D','warnings'],'seconds':1800},
 {'label':'tests-all-features-02','command':['cargo','test','--offline','--locked','--release','-p','hyperbrep','-p','hyperbrep-io','--all-features'],'seconds':3600},
 {'label':'tests-minimal-features-01','command':['cargo','test','--offline','--locked','--release','-p','hyperbrep','-p','hyperbrep-io','--no-default-features'],'seconds':3600},
 {'label':'owner-regressions-01','command':['cargo','test','--offline','--locked','--release','-p','hypercurve','--all-features','--test','selected_point_definitions','--test','point_affine_forms','--test','point_equality_contract','--test','hypercurve_curve_point','--test','retained_bezier_images','--test','work_budget'],'seconds':3600},
 {'label':'clippy-minimal-features-01','command':['cargo','clippy','--offline','--locked','-p','hyperbrep','-p','hyperbrep-io','-p','hypercurve','--no-default-features','--all-targets','--','-D','warnings'],'seconds':1800},
 {'label':'rustdoc-01','command':['cargo','doc','--offline','--locked','-p','hyperbrep','-p','hyperbrep-io','-p','hypercurve','--all-features','--no-deps'],'env':{'RUSTDOCFLAGS':'-D warnings'},'seconds':1800},
 {'label':'fuzz-check-01','command':['cargo','check','--offline','--locked','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--bins'],'seconds':1800},
 {'label':'format-check-01','command':['cargo','fmt','--all','--','--check'],'seconds':1800}
]
for job in jobs:
 code=run(job)
 if code:raise SystemExit(code)
