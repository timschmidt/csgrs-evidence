#[allow(dead_code)]
#[path = "support/cone_continuation.rs"]
mod acceptance;
#[allow(dead_code)]
#[path = "support/seam_cuts.rs"]
mod seam;

#[test]
fn rationally_rotated_cone_band_continues() {
    acceptance::band();
}

#[test]
fn rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(false);
}

#[test]
fn swapped_rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(true);
}

#[test]
fn original_rejected_cone_partition_replays_cold() {
    let json = include_str!("fixtures/cone-rational-partition.json");
    let model = hyperbrep::RawModel::from_json(json, &hyperbrep::ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(model.to_json().unwrap(), json);
}

#[test]
fn captured_cone_circle_point_query_replays_cold() {
    let raw: serde_json::Value =
        serde_json::from_str(include_str!("fixtures/cone-circle-point-query.json")).unwrap();
    let point = |name: &str| {
        let [x, y]: [hyperbrep::Real; 2] = serde_json::from_value(raw[name].clone()).unwrap();
        hypercurve::Point2::new(x, y)
    };
    let arc = hypercurve::CircularArc2::try_from_center(
        point("start"),
        point("end"),
        point("center"),
        raw["clockwise"].as_bool().unwrap(),
    )
    .unwrap();
    // This clockwise arc runs from (-4,3) to (-sqrt(5),2*sqrt(5)).
    // It stays in the upper-left quadrant, so (5,0) is on its circle only.
    let curve = hypercurve::Curve2::from(arc);
    let hypercurve::CurvePointLocations2::Locations(locations) =
        curve.point_locations(&point("point").into()).unwrap()
    else {
        panic!("finite arc");
    };
    assert!(locations.is_empty());
}

#[test]
fn cone_overlap_contacts_keep_boundary_endpoint_images() {
    use hypercurve::{
        CircularArc2, Contour2, Curve2, CurvePointLocations2, CurveRegion2, LineSeg2, Point2,
        Segment2,
    };
    let raw: serde_json::Value =
        serde_json::from_str(include_str!("fixtures/cone-circle-point-query.json")).unwrap();
    let point = |name: &str| {
        let [x, y]: [hyperbrep::Real; 2] = serde_json::from_value(raw[name].clone()).unwrap();
        Point2::new(x, y)
    };
    let boundary =
        CircularArc2::try_from_center(point("end"), point("start"), point("center"), false)
            .unwrap();
    let contour = Contour2::try_new(vec![
        Segment2::Arc(boundary.clone()),
        Segment2::Line(LineSeg2::try_new(point("start"), point("center")).unwrap()),
        Segment2::Line(LineSeg2::try_new(point("center"), point("end")).unwrap()),
    ])
    .unwrap();
    let region = CurveRegion2::try_from_native_contours(vec![contour], Vec::new()).unwrap();
    for reversed in [false, true] {
        let mut source = Curve2::from(
            CircularArc2::try_from_center(
                Point2::from_values(-5, 0),
                Point2::from_values(0, 5),
                point("center"),
                true,
            )
            .unwrap(),
        );
        if reversed {
            source = source.reversed().unwrap();
        }
        let fragments = source.trim_inside_region_with_parameters(&region).unwrap();
        assert_eq!(fragments.len(), 1);
        let mut arc_contacts = 0;
        for contacts in [
            fragments[0].start_boundary_contacts(),
            fragments[0].end_boundary_contacts(),
        ] {
            for contact in contacts {
                let carrier = contact.carrier().curve();
                let start_point = carrier.start();
                let end_point = carrier.end();
                let a: hypercurve::CurvePoint2 = boundary.start().clone().into();
                let b: hypercurve::CurvePoint2 = boundary.end().clone().into();
                // Prepared carriers may promote the arc to a rational chart.
                // This sector's only boundary joining A and B is its arc.
                if !((start_point == a && end_point == b) || (start_point == b && end_point == a)) {
                    continue;
                }
                let (start, end) = carrier.parameter_endpoints();
                let expected = if contact.boundary_parameter() == start {
                    carrier.start()
                } else {
                    assert_eq!(contact.boundary_parameter(), end);
                    carrier.end()
                };
                assert_eq!(
                    contact.point(),
                    Some(&expected),
                    "retain the already owned endpoint image"
                );
                let CurvePointLocations2::Locations(locations) = Curve2::from(boundary.clone())
                    .point_locations(contact.point().unwrap())
                    .unwrap()
                else {
                    panic!("finite arc");
                };
                assert_eq!(locations.len(), 1);
                arc_contacts += 1;
            }
        }
        assert!(arc_contacts >= 2);
    }
}
