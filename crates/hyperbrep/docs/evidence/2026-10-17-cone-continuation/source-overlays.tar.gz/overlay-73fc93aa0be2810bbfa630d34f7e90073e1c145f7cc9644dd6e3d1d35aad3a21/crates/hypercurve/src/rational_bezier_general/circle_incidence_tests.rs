use super::*;

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

#[test]
fn cone_arc_excludes_other_points_on_its_circle() {
    let angle = q(1, 2) * (q(3, 4).atan().unwrap() - q(1, 2) * Real::pi());
    let arc = crate::CircularArc2::try_from_center(
        Point2::from_values(-4, 3),
        Point2::new(
            Real::from(5) * angle.clone().sin().unwrap(),
            Real::from(5) * angle.cos().unwrap(),
        ),
        Point2::from_values(0, 0),
        true,
    )
    .unwrap();
    let query = Point2::from_values(5, 0);
    for span in arc.rational_bezier_decomposition().unwrap().spans() {
        let curve = RationalBezier2::from(span.curve().clone());
        assert!(!curve.contains_point(&query).unwrap());
    }
    let curve = crate::Curve2::from(arc);
    let crate::CurvePointLocations2::Locations(locations) =
        curve.point_locations(&query.into()).unwrap()
    else {
        panic!("finite arc");
    };
    assert!(locations.is_empty());
}
