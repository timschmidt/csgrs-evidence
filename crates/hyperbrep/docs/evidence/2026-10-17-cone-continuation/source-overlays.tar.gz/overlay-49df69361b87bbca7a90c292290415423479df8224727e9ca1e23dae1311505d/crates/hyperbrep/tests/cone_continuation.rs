#[allow(dead_code)]
#[path = "support/cone_continuation.rs"]
mod acceptance;
#[allow(dead_code)]
#[path = "support/seam_cuts.rs"]
mod seam;

#[test]
fn rationally_rotated_cone_band_continues() {
    acceptance::band();
}

#[test]
fn rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(false);
}

#[test]
fn swapped_rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(true);
}

#[test]
fn original_rejected_cone_partition_replays_cold() {
    let json = include_str!("fixtures/cone-rational-partition.json");
    let model = hyperbrep::RawModel::from_json(json, &hyperbrep::ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(model.to_json().unwrap(), json);
}
