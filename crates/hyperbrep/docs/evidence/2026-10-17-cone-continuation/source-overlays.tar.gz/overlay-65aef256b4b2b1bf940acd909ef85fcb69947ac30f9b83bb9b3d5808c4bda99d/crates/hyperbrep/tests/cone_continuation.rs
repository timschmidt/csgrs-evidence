#[allow(dead_code)]
#[path = "support/cone_continuation.rs"]
mod acceptance;
#[allow(dead_code)]
#[path = "support/seam_cuts.rs"]
mod seam;

#[test]
fn rationally_rotated_cone_band_continues() {
    acceptance::band();
}

#[test]
fn rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(false);
}

#[test]
fn swapped_rationally_rotated_cone_reconstruction_continues() {
    acceptance::reconstruction(true);
}

#[test]
fn original_rejected_cone_partition_replays_cold() {
    let json = include_str!("fixtures/cone-rational-partition.json");
    let model = hyperbrep::RawModel::from_json(json, &hyperbrep::ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(model.to_json().unwrap(), json);
}

#[test]
fn captured_cone_circle_point_query_replays_cold() {
    let raw: serde_json::Value =
        serde_json::from_str(include_str!("fixtures/cone-circle-point-query.json")).unwrap();
    let point = |name: &str| {
        let [x, y]: [hyperbrep::Real; 2] = serde_json::from_value(raw[name].clone()).unwrap();
        hypercurve::Point2::new(x, y)
    };
    let arc = hypercurve::CircularArc2::try_from_center(
        point("start"),
        point("end"),
        point("center"),
        raw["clockwise"].as_bool().unwrap(),
    )
    .unwrap();
    // This clockwise arc runs from (-4,3) to (-sqrt(5),2*sqrt(5)).
    // It stays in the upper-left quadrant, so (5,0) is on its circle only.
    let curve = hypercurve::Curve2::from(arc);
    let hypercurve::CurvePointLocations2::Locations(locations) =
        curve.point_locations(&point("point").into()).unwrap()
    else {
        panic!("finite arc");
    };
    assert!(locations.is_empty());
}
