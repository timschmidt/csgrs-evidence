include!("cases.rs");
#[unsafe(no_mangle)]
pub extern "C" fn run_0() -> u32 { cases()[0].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_1() -> u32 { cases()[1].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_2() -> u32 { cases()[2].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_3() -> u32 { cases()[3].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_4() -> u32 { cases()[4].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_5() -> u32 { cases()[5].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_6() -> u32 { cases()[6].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_7() -> u32 { cases()[7].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_8() -> u32 { cases()[8].1(); 1 }
#[unsafe(no_mangle)]
pub extern "C" fn run_9() -> u32 { cases()[9].1(); 1 }
