#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hypersolve/tests/support/bivariate_topology.rs"]
mod acceptance;
fn cases() -> [(&'static str, fn()); 10] { [
    ("complete_interior_loop_and_empty_fibers", acceptance::complete_interior_loop_and_empty_fibers),
    ("algebraic_fiber_events_and_quartic_projection_loops", acceptance::algebraic_fiber_events_and_quartic_projection_loops),
    ("irreducible_nodal_quartic_keeps_both_loops", acceptance::irreducible_nodal_quartic_keeps_both_loops),
    ("covertical_critical_points_and_disconnected_loops", acceptance::covertical_critical_points_and_disconnected_loops),
    ("singular_nodes_cusps_and_isolated_contacts_keep_incidence", acceptance::singular_nodes_cusps_and_isolated_contacts_keep_incidence),
    ("trim_boundary_crossings_tangencies_and_corners", acceptance::trim_boundary_crossings_tangencies_and_corners),
    ("degree_drop_and_algebraic_projection_events", acceptance::degree_drop_and_algebraic_projection_events),
    ("original_brep_patch_pullback_and_chart_changes", acceptance::original_brep_patch_pullback_and_chart_changes),
    ("explicit_dimension_degeneracy_budget_and_recovery", acceptance::explicit_dimension_degeneracy_budget_and_recovery),
    ("source_bound_slices_limits_and_recovery", acceptance::source_bound_slices_limits_and_recovery),
] }
