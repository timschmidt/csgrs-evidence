"""Finalize the complete finite evidence inventory, never mark a gate closed."""
from pathlib import Path
import hashlib,json
from run import OUT,ROOT
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-bivariate-cell-prototype'
summary=json.loads((DEST/'qualification-summary.json').read_text())
doc=json.loads((OUT/'documentation-stage.json').read_text())
checks=json.loads((DEST/'final-checks.json').read_text())
assert checks and all(row['exit_code']==0 for row in checks)
manifest={'id':summary['id'],'status':'finite-solver-foundation-qualified; public-BRep-integration-open','base_revision':summary['base_revision'],'upstream_revision':'dbe99e3cc145e8ca58a53ade6e79fd46311972fb','qualification':doc['qualification'],'costs':doc['costs'],'limits':doc['limits'],'properties':doc['entry']['properties'],'complete_work_packages':[],'full_development_goal_complete':False,'implementation':['crates/hypersolve/src/bivariate_topology.rs','crates/hypersolve/src/lib.rs','crates/hypersolve/src/work_budget.rs'],'tests':['crates/hypersolve/tests/bivariate_topology.rs','crates/hypersolve/tests/support/bivariate_topology.rs'],'source_reconstruction':'Recreate 495eb89ca, apply qualified-source.patch.gz and verify candidate-source.json. Remap retained absolute project roots while preserving source recipes, locks and assertions. Later modifications are evidence and BRep-owned plan/ledger documents. Every completed validation attempt, log and source patch is retained in raw-data.tar.gz. Compiled binaries are excluded, with exact sizes/hashes retained.','publication':'The authorized eaa0cae54 was already pushed. This increment remains local; no new push without the required repository matrix.','files':{}}
for p in sorted(DEST.rglob('*')):
 if p.is_file() and p.name!='manifest.json':
  data=p.read_bytes();manifest['files'][str(p.relative_to(DEST))]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,record in manifest['files'].items():
 data=(DEST/name).read_bytes();assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
print('Verified',len(manifest['files']),'manifest files; no completed work packages.')
