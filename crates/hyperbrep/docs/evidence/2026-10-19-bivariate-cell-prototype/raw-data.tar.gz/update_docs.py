"""Connect the qualified solver prerequisite to the existing BRep roadmap."""
from pathlib import Path
import hashlib,json,re,subprocess
from run import OUT,ROOT
NAME='2026-10-19-bivariate-cell-prototype'
DEST=ROOT/'crates/hyperbrep/docs/evidence'/NAME
summary=json.loads((DEST/'qualification-summary.json').read_text())
contract=json.loads((OUT/'contract-before-edit.json').read_text())
assert summary['complete'] is False and summary['completed_work_packages']==[]
qualified=(f"Ten shared rational polynomial topology groups pass natively and in actual zero-import WASM. Two fresh native runs produce 29 byte-identical complete diagnostic graph records. Independent analytic incidence expectations, Sturm counts and whole-strip exclusions check interior loops, covertical critical points, nodes, cusps, isolated points, boundary contacts, degree drops and algebraic events. Later rational slices retain the equation; degree/refinement/work refusal and recovery pass. The final all-feature Hypersolve suite passes {summary['tests']['hypersolve-all-features-tests']['passed']} tests and BRep/IO passes {summary['tests']['brep-all-features-tests']['passed']}; both owners pass all-target Clippy with warnings denied, Hypersolve rustdoc denies warnings, and formatting passes. Three preserved source-path BRep workflows pass on freshly built baseline and candidate binaries. This is an additive solver foundation: the original public biquadratic BRep section still returns UnsupportedIntersection. The exact failing recipe remains in the evidence. Diagnostic JSON is not a native BRep archive or an untrusted proof decoder.")
cost=(f"Nine CPU-pinned processes retain three alternating baseline/candidate pairs for three complete preserved BRep workflows and three absolute processes for ten new topology recipes. First and three repeated fresh-input calls include all assertions; topology costs include graph proof inspection and complete exact diagnostic materialization. The six matched phase ratios range {summary['time_ratio_range'][0]:.6f} to {summary['time_ratio_range'][1]:.6f}; {summary['allocation_growth_rows']} rows increase counted allocation traffic. All samples and adverse results remain. Maximum process RSS is {summary['rss_max_kib']} KiB. Requested Rust allocation traffic is distinct from live heap and excludes foreign allocator internals. The largest diagnostic graph is 2404 bytes; retained rational numerators/denominators reach 82/40 bits. These finite payload metrics do not measure intermediate coefficient growth or prove an execution bound. No general speedup or successful-work baseline for the new capability is claimed.")
limits=("The constructor admits exact rational equations on rational rectangles with finite fibers and complete checked projection/adjacency; it preserves singular incidence but does not classify multiplicity or material transitions. Vertical/nullified fibers, generic repeated factors and whole horizontal boundary components remain typed blockers. Hypercurve branch carriers, BRep spatial and both chart mappings, surface guards, trim arrangements, general patch-pair intersections and branch replay remain open. Input/projection degree, isolation depth, connection refinement and shared work controls are not total work, coefficient, retained-heap, stack or cancellation bounds. All 28 work packages remain open/in-progress. Runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distributions, production bindings and the full pre-push matrix remain unqualified. No additional push is authorized by the consumed eaa0cae54 exception.")
entry={'id':summary['id'],'work_packages':summary['work_packages'],'properties':contract['properties'],'change':'Add a solver-owned exact rational bivariate cell-topology prototype with complete event fibers, retained source equations, certified branch connections and subsequent rational slice queries. Preserve the original public BRep interior-loop failure for carrier integration.','sources':['../../hypersolve/src/bivariate_topology.rs','../../hypersolve/src/lib.rs','../../hypersolve/src/work_budget.rs'],'evidence':f'evidence/{NAME}/manifest.json','validation':qualified,'cost_evidence':cost,'limits':limits}
statuspath=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status=json.loads(statuspath.read_text())
assert len(status['increments'])==68
assert not status['complete']
status['increments'].append(entry)
status['updated_on']='2026-10-19'
wp=next(w for w in status['work_packages'] if w['id']=='WP05a')
assert wp['status']=='open'
wp['status']='in-progress'
status['next_actions'].insert(0,f'Continue WP05a/WP05b from evidence/{NAME}/manifest.json and its next-domains.md. Preserve the original complete interior-loop surface probe, all exact graph fixtures, independent slice/strip checks, typed component blockers and adverse costs. Build retained Hypercurve branches and BRep spatial/dual-chart correspondence before claiming the public section fixed; complete component processing, surface guards, trim arrangements, persistence and resource contracts. This solver prerequisite closes no work package or publication gate.')
statuspath.write_text(json.dumps(status,indent=2)+'\n')
planpath=ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md'
plan=planpath.read_text()
needle='Apply [research gates G2–G5](ALGORITHM_RESEARCH.md#prototype-gates-and-decisive-fixtures)'
assert plan.count(needle)==1
paragraph='''The [rational polynomial cell prototype](evidence/2026-10-19-bivariate-cell-prototype/README.md)
now provides the first WP05a implementation in Hypersolve. It retains complete
projection/event fibers and proves branch adjacency with root-free connection
strips, including interior loops and singular incidence. Its tests replay
independent slice counts and retained exclusions, and exercise subsequent
source-bound rational slices. Vertical/nullified components, generic repeated
factors and whole boundary components still fail typed. This finite graph
is not yet a Hypercurve branch carrier or a BRep section: the original public
biquadratic interior-loop probe remains unsupported. Follow its
[next domains](evidence/2026-10-19-bivariate-cell-prototype/next-domains.md) for
retained planar branches, spatial/dual-chart maps, surface guards, trimming,
component processing, persistence and full resource qualification. WP05a is
in progress; its complete gate and G3/G4 remain open.

'''
planpath.write_text(plan.replace(needle,paragraph+needle))
# Change exactly the BRep-owned value, preserving all other bytes and owners.
ledgerpath=ROOT/'docs/properties-status.json'
old=ledgerpath.read_text();ledger=json.loads(old)
value=ledger['current_work']['hyperbrep']
value['latest_evidence']=f'crates/hyperbrep/docs/evidence/{NAME}/manifest.json'
value['latest_feature_evidence']=value['latest_evidence']
value['latest_update_check']=f'crates/hyperbrep/docs/evidence/{NAME}/remote-checkpoint.json'
value['latest_implementation']=summary['id']
value['qualification']=' '.join([qualified,cost,limits])
matches=list(re.finditer(r'(?m)^([ ]*)"hyperbrep":\s*',old));assert len(matches)==1
match=matches[0];start=match.end();_,length=json.JSONDecoder().raw_decode(old[start:])
indent=match.group(1)
replacement=json.dumps(value,indent=2).replace('\n','\n'+indent)
new=old[:start]+replacement+old[start+length:]
assert json.loads(new)==ledger
ledgerpath.write_text(new)
(DEST/'ledger-update.json').write_text(json.dumps({'owned_value':'current_work.hyperbrep','all_other_bytes_unchanged':old[:start]==new[:start] and old[start+length:]==new[start+len(replacement):],'increment_count':69,'work_packages':28,'status_transition':{'WP05a':['open','in-progress']},'completed_work_packages':[]},indent=2)+'\n')
(DEST/'next-domains.md').write_text('''# Continue from the complete polynomial graph

This increment advances WP05a without resolving the retained public plane-section failure. Keep that executable biquadratic graph unchanged: its zero set is the full radius-1/4 circle inside the unit parameter square. A solver graph alone must not make the public BRep result appear complete.

1. **Hypercurve owns implicit planar branches.** Reuse the retained equation, projection-cell ordinal and ordered root selector in the native curve/point vocabulary. Provide exact point selection, comparison, endpoints, reversal, splitting, transformation and output-to-input composition. Share the source and selected fibers instead of materializing approximate coordinates or introducing another region carrier. Persist defining data and independently revalidate branch selection; the diagnostic JSON from this increment is not an archive admission API.
2. **BRep owns spatial and both surface-chart images.** Pull a plane through a rational patch only after domain and denominator guards are certified. Retain one branch identity with exact tensor spatial mapping and both pcurves, validate correspondence against both original surfaces, and include isolated contacts. The unchanged original probe must pass complete section inspection, split/reverse/transform, save/load and further supported consumption before WP05b claims that case. The existing whole-surface API must not discard trim/guard requirements or substitute a second incompatible branch result.
3. **Complete the exceptional cases deliberately.** Extract vertical/common components and square-free generic factors; retain multiplicity separately from set topology. Reuse the existing Hypersolve `bivariate_components` axis-content and exact-division paths where their applicability is proved; do not duplicate factor authority in BRep. Reconcile boundary components, nullified fibers, cusp/node incidence, singular parameterizations and rank/embedding guards. A zero resultant or empty seed set cannot certify disjointness. Keep every typed-refusal fixture when expanding the domain and add independent successes under the new proof.
4. **Build general face arrangements.** Feed retained chart branches into the owning Hypercurve arrangement, then lift/partition/stitch in BRep with shared source identities. Preserve interior/nested loops, coincident pieces, trim endpoints, material-side semantics and empty results. A correct graph does not by itself establish face winding or a valid solid Boolean.
5. **Finish the resource and delivery contracts.** Measure projection/fiber cost and intermediate coefficient growth on larger degrees; add explicit total-work, retained-memory and cancellation controls before claiming broad bounded execution. Preserve all adverse samples and expensive earlier BRep workflows. Qualify native and WASM consumers, native archive admission, installed packages and actual bindings on the final composition. Runtime fuzz/ASan/lexicase, proof/coverage, MSRV and the full repository pre-push matrix remain open.

The original equation and complete event census are the reusable foundation. Boundary-seeded or proximity-matched tracing is not a substitute for a global completeness certificate. Production remains pure Rust; external kernels are optional validation oracles.
''')
(OUT/'documentation-stage.json').write_text(json.dumps({'entry':entry,'qualification':qualified,'costs':cost,'limits':limits},indent=2)+'\n')
print('Updated BRep plan, increment 69, WP05a and the owned property-ledger value.')
