import hashlib,json
from run import OUT,ROOT
for name,expected in json.loads((OUT/'candidate-source.json').read_text()).items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
print('Frozen candidate source hashes verified.')
