from pathlib import Path
from fractions import Fraction
import hashlib,json,re
from run import OUT

def exact_rational(text):
    mixed=re.fullmatch(r"(-?)([0-9]+) ([0-9]+)/([0-9]+)",text)
    if mixed:
        sign,whole,numerator,denominator=mixed.groups()
        value=Fraction(int(whole))+Fraction(int(numerator),int(denominator))
        return -value if sign else value
    return Fraction(text)

assert exact_rational("1 1/256")==Fraction(257,256)
assert exact_rational("-1 1/256")==Fraction(-257,256)
rows=[]
for path in sorted((OUT/'artifacts/0').glob('*.json')):
    data=json.loads(path.read_text());stats={'max_numerator_bits':0,'max_denominator_bits':0}
    def walk(value):
        if isinstance(value,dict):
            for v in value.values():walk(v)
        elif isinstance(value,list):
            for v in value:walk(v)
        elif isinstance(value,str):
            q=exact_rational(value)
            stats['max_numerator_bits']=max(stats['max_numerator_bits'],abs(q.numerator).bit_length())
            stats['max_denominator_bits']=max(stats['max_denominator_bits'],q.denominator.bit_length())
    walk(data)
    rows.append(dict(file=path.name,bytes=path.stat().st_size,source_degrees=[len(data['equation'])-1,max(map(len,data['equation']))-1],projection_degree=len(data['projection'])-1,events=len(data['events']),arcs=sum(len(x['arcs']) for x in data['slabs']),**stats))
summary={key:max(r[key] for r in rows) for key in ['bytes','projection_degree','events','arcs','max_numerator_bits','max_denominator_bits']}
(OUT/'graph-record-metrics.json').write_text(json.dumps({'records':rows,'maxima':summary,'encoding':'Exact Rational display strings; mixed integer/fraction form is parsed explicitly.','scope':'Retained diagnostic equation/graph payload dimensions on the finite executed corpus; not live heap, transient coefficient growth, polynomial separation complexity, or a general work bound.'},indent=2)+'\n')
print(summary)
