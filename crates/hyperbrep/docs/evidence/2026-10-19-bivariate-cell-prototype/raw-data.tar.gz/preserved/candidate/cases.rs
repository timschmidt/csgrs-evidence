#[allow(dead_code)]
#[path = "/mnt/development/csgrs/target/hyperbrep-development/crates/hyperbrep/tests/support/similarity.rs"]
mod acceptance;
fn cases() -> [(&'static str,fn());3] { [
("primitives",acceptance::primitives),
("clipped_and_voids",acceptance::clipped_and_voids),
("profile_families",acceptance::profile_families),
] }
