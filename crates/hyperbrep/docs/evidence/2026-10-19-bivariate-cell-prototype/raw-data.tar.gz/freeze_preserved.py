"""Freeze freshly qualified preserved-workflow consumers before measuring."""
from pathlib import Path
import hashlib,json,shutil,subprocess
from run import OUT,ROOT
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=json.loads((OUT/'results.json').read_text());labels={r['label']:r for r in rows}
for side in ['baseline','candidate']:
 for stage in ['clippy','build','run']:assert labels[f'preserved-{side}-{stage}']['exit_code']==0
rootmap={'baseline':Path('/mnt/development/csgrs'),'candidate':ROOT}
for side,root in rootmap.items():
 for name,expected in json.loads((OUT/(side+'-source.json')).read_text()).items():assert sha(root/name)==expected,(side,name)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='495eb89cab1f66cea6e466c701a11297d0697f82'
record={}
for side,root in rootmap.items():
 src=Path('/tmp/hyperbrep-review-target/release')/('hyperbrep-cell-preserved-'+side)
 dst=OUT/'binaries'/('preserved-'+side);assert not dst.exists()
 shutil.copy2(src,dst);assert sha(src)==sha(dst)
 project=OUT/'preserved'/side
 record[side]={'binary':{'path':str(dst),'bytes':dst.stat().st_size,'sha256':sha(dst)},'source_root':str(root),'source_hashes':side+'-source.json','project':{str(p.relative_to(project)):sha(p) for p in sorted(project.rglob('*')) if p.is_file()},'groups':3,'scope':'Fresh native release build and run of unchanged public BRep similarity recipes; source-path consumer, not installed distribution.'}
(OUT/'preserved-binaries.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({side:value['binary'] for side,value in record.items()},indent=2))
