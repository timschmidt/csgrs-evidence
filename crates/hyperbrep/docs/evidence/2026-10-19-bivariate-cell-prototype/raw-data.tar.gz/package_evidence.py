"""Keep all attempts and exact diagnostics; exclude compiled executables."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
from run import OUT,ROOT
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-bivariate-cell-prototype'
assert (DEST/'qualification-summary.json').exists()
assert not (DEST/'raw-data.tar.gz').exists()
rows=json.loads((OUT/'results.json').read_text())
for row in rows:
 for pathkey,hashkey in [('log','log_sha256'),('source_patch','source_patch_sha256')]:
  p=Path(row[pathkey]);assert hashlib.sha256(p.read_bytes()).hexdigest()==row[hashkey],str(p)
files=[p for p in sorted(OUT.rglob('*')) if p.is_file() and not any(part in ['binaries','__pycache__'] for part in p.relative_to(OUT).parts) and not p.name.endswith('.lock')]
# Cargo.lock is a qualification input, whereas results.lock is only a mutex.
files += [p for p in sorted(OUT.rglob('Cargo.lock')) if p not in files]
files.sort();index={}
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w',format=tarfile.PAX_FORMAT) as archive:
 for p in files:
  name=str(p.relative_to(OUT));payload=p.read_bytes();info=tarfile.TarInfo(name)
  info.size=len(payload);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(payload))
  index[name]={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
packed=gzip.compress(stream.getvalue(),mtime=0)
(DEST/'raw-data.tar.gz').write_bytes(packed)
(DEST/'raw-data-index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(index)
 for member in members:
  assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
  data=archive.extractfile(member).read();assert len(data)==index[member.name]['bytes'] and hashlib.sha256(data).hexdigest()==index[member.name]['sha256']
record={'files':len(index),'uncompressed_file_bytes':sum(v['bytes'] for v in index.values()),'compressed_bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'every_member_verified':True,'exclusions':['Compiled native/WASM binaries; their sizes and hashes are retained','The results.lock process mutex; every Cargo.lock is included'],'scope':'Every completed validation attempt, source patch, log, consumer recipe/lock, exact diagnostic graph, cost process and evidence helper present at packaging is retained. Final document-check logs live alongside this bundle in the manifest.'}
(DEST/'raw-data-summary.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
