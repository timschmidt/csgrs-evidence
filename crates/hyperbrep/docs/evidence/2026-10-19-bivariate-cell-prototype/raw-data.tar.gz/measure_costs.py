"""Retain all matched and absolute samples after qualification is terminal."""
from pathlib import Path
import datetime,hashlib,json,os,platform,statistics,subprocess
from run import OUT,ROOT,ENV

sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=json.loads((OUT/'results.json').read_text())
required=['consumer-native-run-0','consumer-native-run-1','consumer-wasm-runtime','hypersolve-all-features-tests','hypersolve-strict-clippy','hypersolve-warning-denied-doc','brep-all-features-tests','brep-strict-clippy','format-check','preserved-baseline-run','preserved-candidate-run']
for label in required:
    match=[r for r in rows if r['label']==label]
    assert len(match)==1 and match[0]['exit_code']==0,label
roots={'baseline':Path('/mnt/development/csgrs'),'candidate':ROOT}
identities={side:json.loads((OUT/(side+'-source.json')).read_text()) for side in roots}
def verify_sources():
    for side,root in roots.items():
        for name,expected in identities[side].items():assert sha(root/name)==expected,(side,name)
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=roots['baseline'],text=True).strip()=='495eb89cab1f66cea6e466c701a11297d0697f82'
verify_sources()
folder=OUT/'costs';folder.mkdir(exist_ok=False)
cpu=min(os.sched_getaffinity(0))
binaries={'topology':json.loads((OUT/'consumer-native.json').read_text())['binary']}
for side in ['baseline','candidate']:
    p=OUT/'binaries'/('preserved-'+side)
    binaries[side]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
trials=[];aggregates=[]
for cohort,sides,count in [('preserved',['baseline','candidate'],3),('topology',['topology'],10)]:
    current=[]
    for trial in range(3):
        order=sides if trial%2==0 else list(reversed(sides))
        for side in order:
            binary=binaries[side];assert sha(binary['path'])==binary['sha256']
            label=f'{cohort}-{side}-{trial}';log=folder/(label+'.log');resource=folder/(label+'-resources.json')
            command=['python3','-B',str(OUT/'measure.py'),str(resource),'taskset','-c',str(cpu),binary['path'],'measure']
            print('Measuring',label,flush=True)
            with log.open('w') as stream:
                result=subprocess.run(['timeout','--signal=TERM','--kill-after=30s','1200s',*command],cwd=ROOT,env=ENV,stdout=stream,stderr=subprocess.STDOUT)
            values=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
            record={'cohort':cohort,'side':side,'trial':trial,'command':command,'exit_code':result.returncode,'resource':json.loads(resource.read_text()),'rows':values,'log':str(log),'log_sha256':sha(log),'binary':binary}
            trials.append(record);current.append(record)
            (folder/'trials.json').write_text(json.dumps(trials,indent=2)+'\n')
            assert result.returncode==record['resource']['exit_code']==0 and len(values)==2*count,label
            verify_sources()
    metadata=lambda values:[{k:v for k,v in row.items() if k not in ['elapsed_ns','allocation_calls','requested_bytes']} for row in values]
    assert all(metadata(t['rows'])==metadata(current[0]['rows']) for t in current)
    for i,case in enumerate(current[0]['rows']):
        row={k:case[k] for k in ['case','phase','outcome','iterations']};row.update(cohort=cohort,matched_contract=cohort=='preserved')
        for side in sides:
            samples=[t['rows'][i] for t in current if t['side']==side]
            row[side]={k:statistics.median(sample[k]/sample['iterations'] for sample in samples) for k in ['elapsed_ns','allocation_calls','requested_bytes']}
        row['time_ratio']=row['candidate']['elapsed_ns']/row['baseline']['elapsed_ns'] if cohort=='preserved' else None
        aggregates.append(row)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cpu':cpu,'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','-Vv'],env=ENV,text=True),'binaries':binaries,'trials':trials,'rows':aggregates,'scope':'Three alternating CPU-pinned pairs of preserved complete native BRep workflows plus three absolute native topology processes. Each process executes a first fresh-input call then three repeated fresh-input calls per recipe. All assertions, complete graph proof inspection, and exact diagnostic output materialization remain in the topology timing. Earlier cases may warm caches; no disabled-cache, global-isolation or installed-package claim. Rust GlobalAlloc traffic excludes foreign allocator internals; process RSS is separate. New capability has no successful-work baseline; an earlier unsupported surface section is not a performance baseline.'}
(OUT/'consumer-costs.json').write_text(json.dumps(record,indent=2)+'\n')
print('Completed',len(trials),'processes and',len(aggregates),'phase rows.',flush=True)
