use hyperbrep::*;
fn q(n: i32, d: i32) -> Real { (Real::from(n) / Real::from(d)).unwrap() }
fn main() {
    // z=(u-1/2)^2+(v-1/2)^2-1/16. Its zero set is a complete
    // radius-1/4 circle strictly inside [0,1]^2, with no boundary seed.
    let a = [Real::zero(), q(-1,2), Real::zero()];
    let controls=(0..3).map(|v| (0..3).map(|u| Point3::new(q(u as i32,2),q(v as i32,2),q(7,16)+&a[u]+&a[v])).collect()).collect();
    let surface=Surface::rational_bezier(controls,vec![vec![Real::one();3];3]).unwrap();
    let plane=Surface::plane(Point3::new(0.into(),0.into(),0.into()),Vector3::new(1.into(),0.into(),0.into()),Vector3::new(0.into(),1.into(),0.into())).unwrap();
    for (u,v) in [(q(1,4),q(1,2)),(q(3,4),q(1,2)),(q(1,2),q(1,4)),(q(1,2),q(3,4))] {
        let point=surface.point_at(&Point2::new(u,v)).unwrap();
        assert!(point.z.exact_rational_normal_form().unwrap().is_zero());
    }
    let section=plane.intersect_surface(&surface);
    println!("complete interior circle plane section: {section:?}");
    assert!(section.is_ok(),"an interior-loop section needs a complete surface intersection result");
}
