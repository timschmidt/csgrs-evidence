"""Audit the final documents without crediting them as runtime evidence."""
from pathlib import Path
import hashlib,json,re,subprocess
from run import OUT,ROOT
DEST=ROOT/'crates/hyperbrep/docs/evidence/2026-10-19-bivariate-cell-prototype'
qualified=json.loads((OUT/'candidate-source.json').read_text())
for name,expected in qualified.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
statuspath=ROOT/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
status=json.loads(statuspath.read_text())
oldstatus=json.loads(subprocess.check_output(['git','show','HEAD:crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'],cwd=ROOT,text=True))
assert len(status['increments'])==69 and status['increments'][:-1]==oldstatus['increments']
assert not status['complete'] and len(status['work_packages'])==28
assert all(w['status'] in ['open','in-progress'] for w in status['work_packages'])
expected=oldstatus['work_packages']
wp=next(w for w in expected if w['id']=='WP05a');assert wp['status']=='open';wp['status']='in-progress'
assert status['work_packages']==expected
ledgerpath=ROOT/'docs/properties-status.json';new=ledgerpath.read_text()
old=subprocess.check_output(['git','show','HEAD:docs/properties-status.json'],cwd=ROOT,text=True)
def outside(text):
 matches=list(re.finditer(r'(?m)^([ ]*)"hyperbrep":\s*',text));assert len(matches)==1
 start=matches[0].end();_,length=json.JSONDecoder().raw_decode(text[start:])
 return text[:start]+'<owned-value>'+text[start+length:]
assert outside(old)==outside(new)
oldvalue=json.loads(old);newvalue=json.loads(new)
assert {k:v for k,v in oldvalue.items() if k!='current_work'}=={k:v for k,v in newvalue.items() if k!='current_work'}
assert {k:v for k,v in oldvalue['current_work'].items() if k!='hyperbrep'}=={k:v for k,v in newvalue['current_work'].items() if k!='hyperbrep'}
jsonfiles=list(DEST.rglob('*.json'))+[statuspath,ledgerpath]
for p in jsonfiles:json.loads(p.read_text())
pattern=r'\[[^\]]*\]\(([^)]+)\)'
tracked=[ROOT/'crates/hypersolve/README.md',ROOT/'crates/hyperbrep/docs/DEVELOPMENT_PLAN.md']
links=[]
for p in list(DEST.rglob('*.md'))+tracked:
 oldlinks=set()
 if p in tracked:
  oldtext=subprocess.check_output(['git','show','HEAD:'+str(p.relative_to(ROOT))],cwd=ROOT,text=True)
  oldlinks=set(re.findall(pattern,oldtext))
 for target in re.findall(pattern,p.read_text()):
  if target in oldlinks or '://' in target or target.startswith(('#','mailto:')):continue
  target=target.split('#')[0].strip('<>')
  if not target:continue
  assert (p.parent/target).exists(),(str(p),target)
  links.append({'source':str(p.relative_to(ROOT)),'target':target})
record={'source_entries_verified':len(qualified),'qualified_source_unchanged':True,'json_files_parsed':len(jsonfiles),'new_local_links_checked':len(links),'links':links,'work_packages':28,'completed_work_packages':0,'only_status_change':'WP05a open to in-progress; every deliverable and gate unchanged','earlier_increments_unchanged':True,'non_brep_property_ledger_bytes_unchanged':True,'scope':'Final document consistency only. No additional runtime, shipped-package, proof, full coverage or pre-push completion claim.'}
(DEST/'documentation-audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='links'},indent=2))
