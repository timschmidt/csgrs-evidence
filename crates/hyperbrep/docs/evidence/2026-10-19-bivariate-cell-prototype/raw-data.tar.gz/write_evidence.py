"""Publish the finite prototype record only after checks and costs succeed."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,shutil,subprocess,tarfile
from run import OUT,ROOT
name='2026-10-19-bivariate-cell-prototype';dest=ROOT/'crates/hyperbrep/docs/evidence'/name
assert not dest.exists()
source=json.loads((OUT/'candidate-source.json').read_text())
for path,sha in source.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==sha,path
runs=json.loads((OUT/'results.json').read_text());by_label={r['label']:r for r in runs}
required=['consumer-native-run-0','consumer-native-run-1','consumer-wasm-runtime','hypersolve-all-features-tests','hypersolve-strict-clippy','hypersolve-warning-denied-doc','brep-all-features-tests','brep-strict-clippy','format-check','preserved-baseline-run','preserved-candidate-run']
for label in required:assert by_label[label]['exit_code']==0,label
costs=json.loads((OUT/'consumer-costs.json').read_text());assert len(costs['trials'])==9
assert all(t['exit_code']==0 and t['resource']['exit_code']==0 for t in costs['trials'])
tests={}
for label in ['hypersolve-all-features-tests','brep-all-features-tests']:
    rows=[line for line in Path(by_label[label]['log']).read_text().splitlines() if line.startswith('test result:')]
    tests[label]=dict(groups=len(rows),passed=sum(int(re.search(r'(\d+) passed',r)[1]) for r in rows))
matched=[r for r in costs['rows'] if r['matched_contract']];ratios=[r['time_ratio'] for r in matched]
allocation_growth=[r for r in matched if r['candidate']['allocation_calls']>r['baseline']['allocation_calls'] or r['candidate']['requested_bytes']>r['baseline']['requested_bytes']]
adverse=[r for r in matched if r['time_ratio']>1 or r in allocation_growth]
summary={'id':'bivariate-cell-prototype-2026-10-19','base_revision':'495eb89cab1f66cea6e466c701a11297d0697f82','work_packages':['WP05a','WP05b','WP06','WP02','WP21'],'completed_work_packages':[],'complete':False,'tests':tests,'native_groups':10,'wasm_groups':10,'wasm_imports':0,'native_deterministic_diagnostic_records':29,'matched_preserved_workflows':3,'matched_phase_rows':len(matched),'absolute_topology_phase_rows':20,'measurement_processes':9,'time_ratio_range':[min(ratios),max(ratios)],'allocation_growth_rows':len(allocation_growth),'rss_max_kib':max(t['resource']['maximum_rss_kib'] for t in costs['trials']),'source_patch_sha256':hashlib.sha256((OUT/'candidate-source.patch').read_bytes()).hexdigest(),'limits':['The original public BRep plane/interior-loop section still returns UnsupportedIntersection; the executable failing recipe is retained.','The polynomial graph is a solver-owned foundation, not a Curve2/Curve3 carrier or a complete face-intersection pipeline.','Vertical/nullified components, generic repeated factors, and whole horizontal boundary components remain typed blockers.','Multiplicity/material classification, surface guards, both pcurves, spatial embedding, branch persistence and general arrangements remain open.','Degree/refinement controls and shared work units are not total scalar-work, coefficient-growth, retained-heap, stack or cancellation bounds.','No full pre-push matrix, runtime fuzz/ASan/lexicase, formal/coverage, MSRV, installed distribution or production-binding completion is claimed.']}
dest.mkdir(parents=True)
for filename in ['contract-before-edit.json','candidate-source.json','baseline-source.json','consumer-native.json','consumer-wasm.json','preserved-binaries.json','toolchain-hardware.json','artifact-comparison.json','graph-record-metrics.json','consumer-costs.json','remote-checkpoint.json','attempt-01-review.json','artifact-metrics-attempt-01.json','original-brep-blocker.json']:
    shutil.copy2(OUT/filename,dest/filename)
shutil.copy2(OUT/'construction-argument.md',dest/'construction-argument.md')
(dest/'validation.json').write_text(json.dumps(runs,indent=2)+'\n')
(dest/'qualification-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dest/'adverse-cost-samples.json').write_text(json.dumps(adverse,indent=2)+'\n')
(dest/'qualified-source.patch.gz').write_bytes(gzip.compress((OUT/'candidate-source.patch').read_bytes(),mtime=0))
readme=f"""# Rational polynomial cell topology prototype

Hypersolve now constructs a complete zero-set graph for admitted rational bivariate equations in a closed rational rectangle. It retains the source equation, projection, complete event fibers, ordered branches and root-free connection strips. Subsequent rational slices use the same source. Interior loops, covertical critical points, isolated contacts, nodes, cusps, clipped boundary contacts and degree drops are represented without tracing from boundary seeds or rounding selected roots.

This advances the WP05a prerequisite for general HyperBRep surface intersections. The unchanged biquadratic plane-section probe still returns `UnsupportedIntersection` through the public BRep API, [reproduced on both baseline and final candidate](original-brep-blocker.json). Hypercurve implicit carriers, BRep spatial images and both pcurves, trim arrangements, multiplicity/material semantics and untrusted branch replay are still required. No work package or release gate is closed.

## Evidence

Ten shared regression recipes pass natively and in an actual zero-import WASM module. Two fresh native processes emit 29 byte-identical exact diagnostic graph records. The tests check analytic component/incidence expectations, source replay, independent Sturm slice counts, connection-strip exclusions, tiny-loop preservation, unsupported components, resource refusal and recovery. The graph encoding is a diagnostic record, not a BRep native archive format.

The final all-feature Hypersolve suite passes {tests['hypersolve-all-features-tests']['passed']} tests and BRep/IO passes {tests['brep-all-features-tests']['passed']}. Strict all-target Clippy passes for these owners; Hypersolve warning-denied documentation and workspace formatting pass. Three preserved external BRep workflows pass on freshly built baseline and candidate binaries. These are source-path consumers; installed packages and production bindings remain unqualified.

[Construction argument](construction-argument.md), [qualification summary](qualification-summary.json), [commands and exits](validation.json), and [artifact comparison](artifact-comparison.json) state the finite evidence. Mathematical reasoning and test results are not formal verification. Earlier failed attempts and original source patches remain in the raw record.

## Cost and open scope

Nine CPU-pinned processes retain three alternating baseline/candidate pairs for the three preserved BRep workflows and three absolute processes for all ten new topology recipes. Every recipe includes its original assertions; topology costs include proof inspection and complete exact diagnostic materialization. First and repeated fresh-input calls are separate. The matched timing ratios range from {min(ratios):.6f} to {max(ratios):.6f}; {len(allocation_growth)} rows increase allocation traffic. Maximum process RSS is {summary['rss_max_kib']} KiB. [Every raw sample and phase row](consumer-costs.json), including [adverse results](adverse-cost-samples.json), is retained. Requested Rust allocation traffic is distinct from live memory and excludes foreign allocator internals. These shared-host observations establish no general speedup or internal resource bound; the new capability has no successful-work baseline.

The finite corpus's largest diagnostic graph record is 2,404 bytes, with projection degree 11, six event fibers and four arcs. [Exact payload metrics](graph-record-metrics.json) measure retained rational representations, not intermediate coefficient growth or execution complexity. Input degree, projection degree, fiber depth, connection refinement and shared work units have distinct controls; total work/heap/cancellation contracts remain open.

Vertical components, identically zero boundary restrictions and repeated generic fibers have typed blockers. General branch carriers, rational surface guards and correspondence, singular/common-component completion, full CAD modeling, release consumers and the full repository acceptance matrix remain in the development plan. This increment remains local; the earlier one-time push exception was consumed by `eaa0cae54`.

## Reproduction

Recreate base `495eb89cab1f66cea6e466c701a11297d0697f82`, apply [the qualified patch](qualified-source.patch.gz), and verify [source hashes](candidate-source.json). Remap recorded absolute consumer paths while keeping source recipes, locks and assertions. The raw bundle retains scripts, projects, all logs and patches, and both diagnostic output sets; compiled binaries are excluded and their hashes/sizes are recorded separately. No compatibility adapter or external production kernel was introduced.
"""
(dest/'README.md').write_text(readme)
(dest/'attempt-review.md').write_text('''# Development attempts and remaining public blocker

The raw bundle preserves all commands, exits, logs and source patches, including failed attempts. Final-source qualification is distinguished from these development runs.

- `baseline-interior-loop` failed to compile because the probe used the wrong `Vector3` constructor shape. The corrected, full-size probe compiled and reproduced `UnsupportedIntersection` in `baseline-interior-loop-02`. The initial source and both logs remain.
- `topology-prototype-01` exposed an all-zero polynomial classification bug and a test assumption about optional rational-root materialization. The constructor now classifies all-zero input explicitly. The test compares exact selected-root values against the independent rational oracle, preserving the original equation and every connectivity assertion; it no longer requires an optional storage form. See `attempt-01-review.json` and both source snapshots.
- `topology-prototype-03` failed to compile after moving shared recipes into integration-test support because `BivariatePolynomial` was not imported. The import was added; the later ten-group run and final 985-test owner suite pass. This compile attempt is not runtime evidence.
- The first diagnostic metric analysis could not parse native mixed-fraction display strings. The parser was corrected with positive and negative rational controls. No geometry code or diagnostic output changed; `artifact-metrics-attempt-01.json` records that analysis failure.
- `candidate-original-interior-loop` reran the unchanged public BRep acceptance probe against the final candidate. It still returns `UnsupportedIntersection` and fails the original success assertion. This is an explicitly open WP05b workflow, not a regression or a passing BRep capability. No boundary, fixture, policy or assertion was weakened to conceal it.
''')
print('Wrote',dest)
