use super::*;

#[test]
fn conic_plane_contact_keeps_exact_endpoint_lifts() {
    let q = |n, d| (Real::from(n) / Real::from(d)).unwrap();
    let a = q(3, 4).atan().unwrap();
    let tiny = q(1, 1_000_000) * q(1, 1_000_000);
    for elliptical in [false, true] {
        for shift in [Real::zero(), Real::from(100) * Real::tau()] {
            let start = &a + &shift;
            let end = Real::pi() * q(1, 2) + shift;
            let center = Point3::new(10.into(), 0.into(), 0.into());
            let curve = if elliptical {
                Curve3::ellipse_arc(center, Vector3::x(), Vector3::z(), 10.into(), 5.into(), start, end)
            } else {
                Curve3::circle_arc(center, Vector3::x(), Vector3::z(), 5.into(), start, end)
            }.unwrap();
            for reversed in [false, true] {
                let curve = if reversed {curve.reversed().unwrap()} else {curve.clone()};
                for height in [Real::from(3), Real::from(3) - &tiny, Real::from(3) + &tiny, Real::from(5)] {
                    let plane = Surface::plane(Point3::new(0.into(), 0.into(), height.clone()), Vector3::x(), Vector3::y()).unwrap();
                    let relation = plane.intersect_curve(&curve).unwrap();
                    if height == Real::from(3) - &tiny {
                        assert!(matches!(relation, CurveSurfaceIntersection::None));
                        continue;
                    }
                    let CurveSurfaceIntersection::Points(points) = relation else {panic!("one contact")};
                    assert_eq!(points.len(), 1);
                    assert_eq!(compare_reals(&points[0].point.z, &height, crate::STRICT_PREDICATES).value(), Some(Ordering::Equal));
                    if height == Real::from(3) {
                        let endpoint = if reversed {curve.domain().end()} else {curve.domain().start()};
                        assert_eq!(compare_reals(&points[0].parameter, endpoint, crate::STRICT_PREDICATES).value(), Some(Ordering::Equal));
                        assert_eq!(compare_reals(&points[0].point.x, &Real::from(if elliptical {18} else {14}), crate::STRICT_PREDICATES).value(), Some(Ordering::Equal));
                        assert_eq!(points[0].multiplicity, IntersectionMultiplicity::Simple);
                    } else if height == Real::from(5) {
                        assert_eq!(points[0].multiplicity, IntersectionMultiplicity::Tangent);
                    } else {
                        assert_eq!(compare_reals(&points[0].parameter, curve.domain().start(), crate::STRICT_PREDICATES).value(), Some(Ordering::Greater));
                        assert_eq!(compare_reals(&points[0].parameter, curve.domain().end(), crate::STRICT_PREDICATES).value(), Some(Ordering::Less));
                    }
                }
            }
        }
    }
}
