//! STEP latitude/meridian chart construction, admitted by native image proofs.
use super::*;
use hyperbrep::Surface;

#[derive(Clone)]
pub(super) struct Torus {
    axis: Vector3,
    major: Curve3,
    minor_radius: Real,
}

impl Torus {
    pub(super) fn new(
        frame: &Plane,
        major_radius: Real,
        minor_radius: Real,
        site: Site,
    ) -> Result<(Surface, Self), Error> {
        let axis = frame.x.cross(&frame.y);
        let surface = Surface::torus(
            frame.origin.clone(),
            frame.x.clone(),
            frame.y.clone(),
            axis.clone(),
            major_radius.clone(),
            minor_radius.clone(),
        )
        .map_err(|error| site.error(ErrorKind::Geometry(error)))?;
        let major = full_circle(
            frame.origin.clone(),
            frame.x.clone(),
            frame.y.clone(),
            major_radius,
            site,
        )?;
        Ok((
            surface,
            Self {
                axis,
                major,
                minor_radius,
            },
        ))
    }

    pub(super) fn boundary_segment(
        &self,
        frame: &Plane,
        edge: &Edge,
        from: &Point3,
        direction: &Real,
        previous: Option<&Point2>,
        site: Site,
    ) -> Result<Segment2, Error> {
        let circle = edge
            .circle
            .as_ref()
            .ok_or_else(|| site.error(ErrorKind::Unsupported("noncircular torus boundary")))?;
        let major_radius = self.major.circular_geometry().expect("major circle").radius;
        let latitude = order(
            site,
            &circle.normal.cross(&self.axis).norm_squared(),
            &Real::zero(),
        )? == Ordering::Equal;
        let (canonical, normal) = if latitude {
            let iso = full_circle(
                circle.center.clone(),
                frame.x.clone(),
                frame.y.clone(),
                circle.radius.clone(),
                site,
            )?;
            let minor = full_circle(
                Point3::origin(),
                Vector3::x(),
                Vector3::y(),
                self.minor_radius.clone(),
                site,
            )?;
            let section = Point3::new(
                &circle.radius - major_radius,
                (&circle.center - &frame.origin).dot(&self.axis),
                Real::zero(),
            );
            (
                Point2::new(
                    circles::circle_parameter(&iso, from, site)?,
                    circles::circle_parameter(&minor, &section, site)?,
                ),
                surfaces::aligned_normals(&circle.normal, &self.axis, site)?,
            )
        } else {
            // Native circle location proves that the meridian center lies on
            // the major circle. The resulting radial vector is therefore unit.
            let u = circles::circle_parameter(&self.major, &circle.center, site)?;
            let radial = (&circle.center - &frame.origin)
                * (Real::one() / major_radius).map_err(|e| site.error(ErrorKind::Numeric(e)))?;
            let iso = full_circle(
                circle.center.clone(),
                radial.clone(),
                self.axis.clone(),
                self.minor_radius.clone(),
                site,
            )?;
            (
                Point2::new(u, circles::circle_parameter(&iso, from, site)?),
                surfaces::aligned_normals(&circle.normal, &radial.cross(&self.axis), site)?,
            )
        };
        // Preserve the preceding endpoint's periodic lift. Shared topology and
        // native whole-image validation, not endpoint sampling, admit this UV.
        let start = previous.cloned().unwrap_or(canonical);
        let sweep = &circle.sweep * normal * direction;
        let end = if latitude {
            Point2::new(start.x() + sweep, start.y().clone())
        } else {
            Point2::new(start.x().clone(), start.y() + sweep)
        };
        Ok(Segment2::Line(
            LineSeg2::try_new(start, end).map_err(|e| site.error(ErrorKind::Geometry(e.into())))?,
        ))
    }
}

fn full_circle(
    center: Point3,
    x: Vector3,
    y: Vector3,
    radius: Real,
    site: Site,
) -> Result<Curve3, Error> {
    Curve3::circle_arc(center, x, y, radius, Real::zero(), Real::tau())
        .map_err(|error| site.error(ErrorKind::Geometry(error)))
}
