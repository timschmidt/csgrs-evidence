#[allow(dead_code)]
#[path = "support/torus_exchange.rs"]
mod support;

#[test]
fn native_ring_torus_survives_exact_step_exchange() {
    support::whole();
}

#[test]
fn imported_torus_halves_recut_clear_and_reconstruct() {
    support::halves_and_reconstruction();
}

#[test]
fn rational_torus_band_keeps_exact_measures_and_near_samples() {
    support::rational_band();
}
