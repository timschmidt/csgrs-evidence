//! Canonical owned triangle geometry and kernel polygon-soup preparation.

use std::collections::{BTreeSet, HashMap};
use std::num::NonZeroU32;
use std::sync::{
    Arc, OnceLock, Weak,
    atomic::{AtomicU8, Ordering},
};

use hyperlattice::{Aabb as ExactAabb, HomogeneousPoint3, Matrix4, Point3, Real, Vector3, Vector4};

use crate::context::{CertaintyFact, DecisionContext, MeshCertainty, MeshContext, MeshOutcome};
use crate::error::{HypermeshError, HypermeshResult};
use crate::geometry::{
    Aabb, Classification, Plane, affine_projective_point_decision, axis_ref, compare_real_decision,
};
use crate::point_interner::{PointCoordinates, PointInterner};
use crate::polygon::{
    CompactSourcePolygon, CompactSourcePolygons, ConvexPolygon, RetainedSourcePlanes,
    RetainedSourcePositions, points_require_wide_dyadic_plane_normalization,
    source_triangle_planes,
};
use crate::predicate::classify_point_decision;
use crate::storage_hash::StorageHashMap;
use crate::winding::mesh_winding_number_decision;

mod concatenation;

/// Triangle: three indices into a [`TriangleMesh`]'s position buffer.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Triangle {
    /// First vertex index.
    pub v0: usize,
    /// Second vertex index.
    pub v1: usize,
    /// Third vertex index.
    pub v2: usize,
}

impl Triangle {
    /// Constructs an input triangle.
    pub const fn new(v0: usize, v1: usize, v2: usize) -> Self {
        Self { v0, v1, v2 }
    }

    /// Returns the indices as an array.
    pub const fn indices(self) -> [usize; 3] {
        [self.v0, self.v1, self.v2]
    }
}

#[derive(Debug)]
pub(crate) struct TriangleMeshFacts {
    // Weak owners keep allocation identity stable and make Arc::make_mut
    // detach before editing. They do not retain the source coordinate values.
    source_positions: Weak<[Point3]>,
    source_triangles: Weak<[Triangle]>,
    exact_bounds: OnceLock<Option<Arc<ExactAabb>>>,
    valid_pwn: CertaintyFact,
    axis_aligned_box: OnceLock<Option<Arc<ExactAabb>>>,
    source_polygon_planes: OnceLock<Arc<CompactSourcePolygons>>,
    wide_dyadic_plane_schedule: AtomicU8,
}

impl TriangleMeshFacts {
    fn new(positions: &Arc<[Point3]>, triangles: &Arc<[Triangle]>) -> Self {
        Self {
            source_positions: Arc::downgrade(positions),
            source_triangles: Arc::downgrade(triangles),
            exact_bounds: OnceLock::new(),
            valid_pwn: CertaintyFact::default(),
            axis_aligned_box: OnceLock::new(),
            source_polygon_planes: OnceLock::new(),
            wide_dyadic_plane_schedule: AtomicU8::new(0),
        }
    }

    fn matches_positions(&self, positions: &Arc<[Point3]>) -> bool {
        std::ptr::eq(self.source_positions.as_ptr(), Arc::as_ptr(positions))
    }

    fn matches_triangles(&self, triangles: &Arc<[Triangle]>) -> bool {
        std::ptr::eq(self.source_triangles.as_ptr(), Arc::as_ptr(triangles))
    }

    fn normalizes_wide_dyadic_planes(&self, positions: &[Point3]) -> bool {
        match self.wide_dyadic_plane_schedule.load(Ordering::Relaxed) {
            1 => false,
            2 => true,
            _ => {
                let normalize = points_require_wide_dyadic_plane_normalization(positions);
                // The fact is a deterministic property of immutable positions.
                // Concurrent first consumers may repeat the scan harmlessly.
                self.wide_dyadic_plane_schedule
                    .store(u8::from(normalize) + 1, Ordering::Relaxed);
                normalize
            }
        }
    }
}

/// Canonical owned triangle mesh.
///
/// This is the reusable geometry carrier accepted by Hypermesh operations and
/// produced from [`crate::BooleanMeshBatch`] results. Reusable exact construction
/// planes may be retained privately alongside geometry so iterated operations
/// do not need to expand them again from derived coordinates. Facts are bound
/// to the source buffers: replacing them or editing through `Arc::make_mut`
/// bypasses facts for the previous geometry. Construct a new mesh to cache
/// facts for edited buffers. While retained identities hold weak references,
/// `Arc::get_mut` can return `None` even without another strong owner.
#[derive(Clone, Debug)]
pub struct TriangleMesh {
    /// Vertex positions. Use `Arc::make_mut` for edits; retained identities hold weak references.
    pub positions: Arc<[Point3]>,
    /// Triangle indices. Use `Arc::make_mut` for edits; retained identities hold weak references.
    pub triangles: Arc<[Triangle]>,
    pub(crate) facts: Arc<TriangleMeshFacts>,
}

impl PartialEq for TriangleMesh {
    fn eq(&self, other: &Self) -> bool {
        self.positions == other.positions && self.triangles == other.triangles
    }
}

impl TriangleMesh {
    /// Creates an owned triangle mesh.
    pub fn new(positions: Vec<Point3>, triangles: Vec<Triangle>) -> Self {
        Self::from_shared_positions(positions.into(), triangles)
    }

    pub(crate) fn from_shared_positions(
        positions: Arc<[Point3]>,
        triangles: Vec<Triangle>,
    ) -> Self {
        let triangles = Arc::<[Triangle]>::from(triangles);
        let facts = Arc::new(TriangleMeshFacts::new(&positions, &triangles));
        Self {
            positions,
            triangles,
            facts,
        }
    }

    fn position_facts(&self) -> Option<&TriangleMeshFacts> {
        self.facts
            .matches_positions(&self.positions)
            .then_some(self.facts.as_ref())
    }

    fn geometry_facts(&self) -> Option<&TriangleMeshFacts> {
        self.position_facts()
            .filter(|facts| facts.matches_triangles(&self.triangles))
    }

    pub(crate) fn with_valid_pwn_certainty(self, certainty: MeshCertainty) -> Self {
        if let Some(facts) = self.geometry_facts() {
            facts.valid_pwn.record(certainty);
        }
        self
    }

    /// Returns a borrowed mesh view.
    pub fn as_ref(&self) -> TriangleMeshRef<'_> {
        TriangleMeshRef {
            positions: &self.positions,
            triangles: &self.triangles,
            native: Some(self),
        }
    }

    /// Builds caller-owned native vertex adjacency from triangle index rows.
    ///
    /// The result is deliberately not retained by the mesh carrier. Algorithms
    /// that reuse adjacency keep this value for the duration of their own
    /// operation, so one-shot queries do not permanently increase mesh memory.
    pub fn adjacency(&self) -> HypermeshResult<Vec<Vec<usize>>> {
        self.validate_triangle_indices()?;
        Ok(self.build_adjacency())
    }

    /// Returns `(position rows, directed adjacency entries)` counts without
    /// retaining or materializing the complete adjacency table.
    pub fn connectivity_counts(&self) -> HypermeshResult<(usize, usize)> {
        self.validate_triangle_indices()?;
        let mut edges = BTreeSet::new();
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            for [left, right] in [[a, b], [b, c], [c, a]] {
                if left != right {
                    edges.insert(if left < right {
                        [left, right]
                    } else {
                        [right, left]
                    });
                }
            }
        }
        let adjacency_entries =
            edges
                .len()
                .checked_mul(2)
                .ok_or(HypermeshError::CapacityOverflow {
                    operation: "connectivity counting",
                })?;
        Ok((self.positions.len(), adjacency_entries))
    }

    fn build_adjacency(&self) -> Vec<Vec<usize>> {
        let mut adjacency = vec![BTreeSet::new(); self.positions.len()];
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            for [left, right] in [[a, b], [b, c], [c, a]] {
                if left != right {
                    adjacency[left].insert(right);
                    adjacency[right].insert(left);
                }
            }
        }
        adjacency
            .into_iter()
            .map(|neighbors| neighbors.into_iter().collect())
            .collect()
    }

    fn validate_triangle_indices(&self) -> HypermeshResult<()> {
        for triangle in self.triangles.iter() {
            if let Some(index) = triangle
                .indices()
                .into_iter()
                .find(|index| *index >= self.positions.len())
            {
                return Err(HypermeshError::VertexIndexOutOfBounds {
                    index,
                    vertex_count: self.positions.len(),
                });
            }
        }
        Ok(())
    }

    /// Validates the nonempty closed-PWN input contract used by Boolean operations.
    ///
    /// This proves valid indices, nondegenerate faces and balanced geometric
    /// edge multiplicities. It does not require manifoldness or nonzero enclosed
    /// winding, regularize the surface, or compute its bounds. Canonical empty
    /// geometry still belongs to the modeling layer's empty-set bridge.
    /// Qualified facts are reused only for matching position/index storage and
    /// an admissible policy. A stronger fact requires new native validation.
    pub fn validate_closed_pwn(&self, context: &MeshContext) -> HypermeshResult<MeshOutcome<()>> {
        let decisions = DecisionContext::new(context);
        self.validate_closed_pwn_decision(&decisions)?;
        Ok(decisions.finish(()))
    }

    fn validate_closed_pwn_decision(&self, decisions: &DecisionContext) -> HypermeshResult<()> {
        let view = self.as_ref();
        validate_non_empty_mesh_views(&[view])?;
        if !self
            .geometry_facts()
            .is_some_and(|facts| facts.valid_pwn.consume(decisions))
        {
            validate_source_pwn(decisions, view, 0)?;
        }
        Ok(())
    }

    /// Resolves a triangle's position rows, preserving invalid-index diagnostics.
    pub fn triangle_points(&self, triangle: Triangle) -> HypermeshResult<[&Point3; 3]> {
        let [a, b, c] = triangle.indices().map(|index| {
            self.positions
                .get(index)
                .ok_or(HypermeshError::VertexIndexOutOfBounds {
                    index,
                    vertex_count: self.positions.len(),
                })
        });
        Ok([a?, b?, c?])
    }

    /// Checks indexed edge pairing for a closed, consistently oriented
    /// two-manifold.
    pub fn is_closed_manifold(&self) -> bool {
        let mut edges = HashMap::<[usize; 2], [usize; 2]>::new();
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            if [a, b, c]
                .into_iter()
                .any(|index| index >= self.positions.len())
            {
                return false;
            }
            for [start, end] in [[a, b], [b, c], [c, a]] {
                if start == end {
                    return false;
                }
                let key = if start < end {
                    [start, end]
                } else {
                    [end, start]
                };
                edges.entry(key).or_default()[usize::from(start > end)] += 1;
            }
        }
        !self.triangles.is_empty() && edges.values().all(|uses| uses[0] == 1 && uses[1] == 1)
    }

    /// Returns true when every triangle has valid, nondegenerate exact
    /// geometry and no two triangles cover the same three exact points.
    ///
    /// Position rows are canonicalized by exact coordinate equality before
    /// triangle keys are compared, so independently indexed duplicate faces
    /// are rejected as well.
    pub fn has_unique_nondegenerate_triangles(
        &self,
        context: &MeshContext,
    ) -> HypermeshResult<MeshOutcome<bool>> {
        let decisions = DecisionContext::new(context);
        let unique = self.has_unique_nondegenerate_triangles_decision(&decisions)?;
        Ok(decisions.finish(unique))
    }

    pub(crate) fn has_unique_nondegenerate_triangles_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<bool> {
        let canonical_indices = canonical_position_indices(decisions, &self.positions)?;
        let mut seen = BTreeSet::new();
        for triangle in self.triangles.iter() {
            let indices = triangle.indices();
            let [Some(a), Some(b), Some(c)] = indices.map(|index| self.positions.get(index)) else {
                return Ok(false);
            };
            let mut key = indices.map(|index| canonical_indices[index]);
            if key[0] == key[1]
                || key[1] == key[2]
                || key[0] == key[2]
                || !Plane::decide_points_are_nondegenerate(decisions, a, b, c)?
            {
                return Ok(false);
            }
            key.sort_unstable();
            if !seen.insert(key) {
                return Ok(false);
            }
        }
        Ok(true)
    }

    /// Checks exact geometric edge pairing for a closed, consistently
    /// oriented two-manifold.
    ///
    /// Unlike [`Self::is_closed_manifold`], this canonicalizes independently
    /// indexed position rows by exact coordinate equality. Duplicate faces,
    /// degenerate faces, and geometrically non-manifold edge valence are
    /// rejected.
    pub fn is_closed_manifold_geometry(
        &self,
        context: &MeshContext,
    ) -> HypermeshResult<MeshOutcome<bool>> {
        let decisions = DecisionContext::new(context);
        let closed = self.is_closed_manifold_geometry_decision(&decisions)?;
        Ok(decisions.finish(closed))
    }

    pub(crate) fn is_closed_manifold_geometry_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<bool> {
        if self.triangles.is_empty()
            || !self.has_unique_nondegenerate_triangles_decision(decisions)?
        {
            return Ok(false);
        }
        let canonical_indices = canonical_position_indices(decisions, &self.positions)?;
        let mut edges = HashMap::<[usize; 2], [usize; 2]>::new();
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices().map(|index| canonical_indices[index]);
            for [start, end] in [[a, b], [b, c], [c, a]] {
                let (key, direction) = if start < end {
                    ([start, end], 0)
                } else {
                    ([end, start], 1)
                };
                edges.entry(key).or_default()[direction] += 1;
            }
        }
        Ok(edges.values().all(|uses| *uses == [1, 1]))
    }

    /// Returns policy-certified exact bounds, or `None` for empty geometry.
    pub fn exact_bounds(
        &self,
        context: &MeshContext,
    ) -> HypermeshResult<MeshOutcome<Option<ExactAabb>>> {
        let decisions = DecisionContext::new(context);
        let bounds = self.exact_bounds_decision(&decisions)?;
        Ok(decisions.finish(bounds))
    }

    pub(crate) fn exact_bounds_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<Option<ExactAabb>> {
        // Position facts do not validate an independently mutated index buffer.
        self.validate_triangle_indices()?;
        let facts = self.position_facts();
        if let Some(bounds) = facts.and_then(|facts| facts.exact_bounds.get()) {
            return Ok(bounds.as_deref().cloned());
        }

        let local = decisions.isolated();
        let bounds = self.compute_exact_bounds_decision(&local);
        decisions.absorb(local.certainty());
        let bounds = bounds?;
        if local.certainty() == crate::MeshCertainty::Certified
            && let Some(facts) = facts
        {
            let _ = facts.exact_bounds.set(bounds.clone().map(Arc::new));
            return Ok(facts.exact_bounds.get().and_then(Option::as_deref).cloned());
        }
        Ok(bounds)
    }

    fn compute_exact_bounds_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<Option<ExactAabb>> {
        let Some(first) = self.positions.first().cloned() else {
            return Ok(None);
        };
        let mut bounds = ExactAabb::new(first.clone(), first);
        for point in &self.positions[1..] {
            for axis in 0..3 {
                let value = axis_ref(point, axis);
                let minimum = axis_ref(&bounds.mins, axis);
                if compare_real_decision(decisions, value, minimum)?.is_lt() {
                    *crate::geometry::axis_mut(&mut bounds.mins, axis) = value.clone();
                }
                let maximum = axis_ref(&bounds.maxs, axis);
                if compare_real_decision(decisions, value, maximum)?.is_gt() {
                    *crate::geometry::axis_mut(&mut bounds.maxs, axis) = value.clone();
                }
            }
        }
        Ok(Some(bounds))
    }

    /// Returns a caller-owned finite projection of every exact position.
    ///
    /// This is an explicit approximation boundary for renderers, exporters,
    /// diagnostics, and benchmarks. Native geometry remains exact.
    pub fn finite_positions(&self) -> Option<Vec<[f64; 3]>> {
        self.positions
            .iter()
            .map(|point| {
                Some([
                    point.x.to_f64_lossy()?,
                    point.y.to_f64_lossy()?,
                    point.z.to_f64_lossy()?,
                ])
            })
            .collect()
    }

    /// Returns geometry whose coordinates are exact promotions of
    /// this mesh's finite binary64 projection.
    ///
    /// `None` means at least one native coordinate has no finite projection.
    pub fn materialize_finite(&self) -> Option<Self> {
        let positions = self
            .finite_positions()?
            .into_iter()
            .map(|position| {
                Some(Point3::new(
                    Real::try_from(position[0]).ok()?,
                    Real::try_from(position[1]).ok()?,
                    Real::try_from(position[2]).ok()?,
                ))
            })
            .collect::<Option<Vec<_>>>()?;
        Some(Self::new(positions, self.triangles.to_vec()))
    }

    /// Returns the retained exact convex hull of this mesh's native positions.
    pub fn convex_hull(&self, context: &MeshContext) -> HypermeshResult<MeshOutcome<Self>> {
        crate::convex_hull(context, &self.positions)
    }

    /// Returns policy-certified bounds when the native rows form one complete
    /// axis-aligned box surface.
    pub fn axis_aligned_box_bounds(
        &self,
        context: &MeshContext,
    ) -> HypermeshResult<MeshOutcome<Option<ExactAabb>>> {
        let decisions = DecisionContext::new(context);
        let bounds = self.axis_aligned_box_bounds_decision(&decisions)?;
        Ok(decisions.finish(bounds))
    }

    pub(crate) fn axis_aligned_box_bounds_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<Option<ExactAabb>> {
        let facts = self.geometry_facts();
        if let Some(bounds) = facts.and_then(|facts| facts.axis_aligned_box.get()) {
            return Ok(bounds.as_deref().cloned());
        }

        let local = decisions.isolated();
        let bounds = self.compute_axis_aligned_box_bounds_decision(&local);
        decisions.absorb(local.certainty());
        let bounds = bounds?;
        if let Some(facts) = facts {
            if bounds.is_some() {
                facts.valid_pwn.record(local.certainty());
            }
            if local.certainty() == crate::MeshCertainty::Certified {
                let cached = bounds.as_ref().map(|bounds| {
                    facts
                        .exact_bounds
                        .get()
                        .and_then(Option::as_ref)
                        .cloned()
                        .unwrap_or_else(|| Arc::new(bounds.clone()))
                });
                let _ = facts.axis_aligned_box.set(cached);
                return Ok(facts
                    .axis_aligned_box
                    .get()
                    .and_then(Option::as_deref)
                    .cloned());
            }
        }
        Ok(bounds)
    }

    fn compute_axis_aligned_box_bounds_decision(
        &self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<Option<ExactAabb>> {
        if self.positions.len() != 8 || self.triangles.len() != 12 {
            return Ok(None);
        }
        let Some(bounds) = self.exact_bounds_decision(decisions)? else {
            return Ok(None);
        };
        for axis in 0..3 {
            if compare_real_decision(
                decisions,
                axis_ref(&bounds.mins, axis),
                axis_ref(&bounds.maxs, axis),
            )?
            .is_eq()
            {
                return Ok(None);
            }
        }

        let mut corners = [false; 8];
        let mut position_corners = [0_u8; 8];
        for (position_index, point) in self.positions.iter().enumerate() {
            let mut corner = 0;
            for axis in 0..3 {
                let value = axis_ref(point, axis);
                if compare_real_decision(decisions, value, axis_ref(&bounds.maxs, axis))?.is_eq() {
                    corner |= 1 << axis;
                } else if !compare_real_decision(decisions, value, axis_ref(&bounds.mins, axis))?
                    .is_eq()
                {
                    return Ok(None);
                }
            }
            if std::mem::replace(&mut corners[corner], true) {
                return Ok(None);
            }
            position_corners[position_index] = corner as u8;
        }
        if corners.iter().any(|present| !present) {
            return Ok(None);
        }

        let mut face_triangles = [0_u8; 6];
        let mut face_corner_masks = [0_u8; 6];
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            let Some(corners) = Option::zip(
                Option::zip(position_corners.get(a), position_corners.get(b)),
                position_corners.get(c),
            )
            .map(|((a, b), c)| [*a, *b, *c]) else {
                return Ok(None);
            };
            let corner_mask = corners
                .into_iter()
                .fold(0_u8, |mask, corner| mask | (1_u8 << corner));
            if corner_mask.count_ones() != 3 {
                return Ok(None);
            }
            let mut face = None;
            for axis in 0..3 {
                let side = (corners[0] >> axis) & 1;
                if corners.iter().all(|corner| ((corner >> axis) & 1) == side) {
                    face = Some((axis, side));
                    break;
                }
            }
            let Some((axis, side)) = face else {
                return Ok(None);
            };
            let first_axis = (axis + 1) % 3;
            let second_axis = (axis + 2) % 3;
            let coordinate = |corner: u8, axis| i8::from(((corner >> axis) & 1) != 0);
            let orientation = (coordinate(corners[1], first_axis)
                - coordinate(corners[0], first_axis))
                * (coordinate(corners[2], second_axis) - coordinate(corners[0], second_axis))
                - (coordinate(corners[1], second_axis) - coordinate(corners[0], second_axis))
                    * (coordinate(corners[2], first_axis) - coordinate(corners[0], first_axis));
            if orientation != if side == 0 { -1 } else { 1 } {
                return Ok(None);
            }
            let face = axis * 2 + usize::from(side);
            face_triangles[face] = face_triangles[face].saturating_add(1);
            face_corner_masks[face] |= corner_mask;
        }
        Ok(
            (face_triangles == [2; 6] && face_corner_masks == [0x55, 0xaa, 0x33, 0xcc, 0x0f, 0xf0])
                .then_some(bounds),
        )
    }

    /// Applies an exact homogeneous transform under the selected predicate
    /// policy. Indices must be valid, and the homogeneous scale must have one
    /// nonzero sign on each triangle. A triangle crossing infinity cannot be
    /// represented by a finite triangle joining its transformed vertices.
    pub fn try_transformed(
        &self,
        context: &MeshContext,
        matrix: &Matrix4,
    ) -> HypermeshResult<MeshOutcome<Self>> {
        let decisions = DecisionContext::new(context);
        let transformed = self.try_transformed_decision(&decisions, matrix)?;
        Ok(decisions.finish(transformed))
    }

    fn try_transformed_decision(
        &self,
        decisions: &DecisionContext,
        matrix: &Matrix4,
    ) -> HypermeshResult<Self> {
        self.validate_triangle_indices()?;
        let matrix_facts = matrix.structural_facts();
        let positions = if matrix_facts.is_affine {
            matrix
                .transform_point3_batch(&self.positions)
                .map_err(|_| HypermeshError::UnknownClassification)?
        } else {
            let mut scales = Vec::with_capacity(self.positions.len());
            let positions = self
                .positions
                .iter()
                .map(|point| {
                    let transformed = matrix.transform_vec4_point(&Vector4::new([
                        point.x.clone(),
                        point.y.clone(),
                        point.z.clone(),
                        Real::one(),
                    ]));
                    let [x, y, z, w] = transformed.0;
                    let sign = compare_real_decision(decisions, &w, &Real::zero())?;
                    if sign == std::cmp::Ordering::Equal {
                        return Err(HypermeshError::PointAtInfinity);
                    }
                    scales.push(sign);
                    affine_projective_point_decision(decisions, &HomogeneousPoint3::new(x, y, z, w))
                })
                .collect::<HypermeshResult<Vec<_>>>()?;
            // Homogeneous scale is affine on each source triangle. Equal,
            // nonzero vertex signs certify the entire triangle's finiteness.
            for (triangle_index, triangle) in self.triangles.iter().enumerate() {
                let [a, b, c] = triangle.indices();
                if scales[a] != scales[b] || scales[a] != scales[c] {
                    return Err(HypermeshError::UnboundedProjectiveTriangle { triangle_index });
                }
            }
            positions
        };
        let transformed = Self::new(positions, self.triangles.to_vec());
        let preserves_valid_pwn = matches!(
            matrix_facts.transform_kind,
            hyperlattice::Matrix4TransformKind::Identity
                | hyperlattice::Matrix4TransformKind::AffineTranslation
        ) || matrix_facts.is_affine
            && matrix_facts.transform_kind == hyperlattice::Matrix4TransformKind::SignedPermutation;
        if preserves_valid_pwn
            && let Some(certainty) = self
                .geometry_facts()
                .and_then(|facts| facts.valid_pwn.certainty())
        {
            transformed.facts.valid_pwn.record(certainty);
        }
        Ok(transformed)
    }

    /// Reverses every triangle while sharing the immutable position buffer.
    ///
    /// The returned mesh owns its derived index buffer; callers that need it
    /// repeatedly retain the returned value explicitly.
    pub fn reversed_winding(&self) -> Self {
        let mesh = Self::from_shared_positions(
            Arc::clone(&self.positions),
            self.triangles
                .iter()
                .map(|triangle| Triangle::new(triangle.v2, triangle.v1, triangle.v0))
                .collect(),
        );
        if let Some(certainty) = self
            .geometry_facts()
            .and_then(|facts| facts.valid_pwn.certainty())
        {
            mesh.facts.valid_pwn.record(certainty);
        }
        mesh
    }

    /// Applies an exact `Rz * Ry * Rx` Euler rotation in degrees.
    pub fn try_rotated_xyz_degrees(
        &self,
        context: &MeshContext,
        x: Real,
        y: Real,
        z: Real,
    ) -> HypermeshResult<MeshOutcome<Self>> {
        let decisions = DecisionContext::new(context);
        let transformed = self.try_rotated_xyz_degrees_decision(&decisions, x, y, z)?;
        Ok(decisions.finish(transformed))
    }

    fn try_rotated_xyz_degrees_decision(
        &self,
        decisions: &DecisionContext,
        x: Real,
        y: Real,
        z: Real,
    ) -> HypermeshResult<Self> {
        let degrees = [x, y, z];
        let x = degrees[0].clone().to_radians();
        let y = degrees[1].clone().to_radians();
        let z = degrees[2].clone().to_radians();
        let (sin_x, cos_x) = (x.clone().sin(), x.cos());
        let (sin_y, cos_y) = (y.clone().sin(), y.cos());
        let (sin_z, cos_z) = (z.clone().sin(), z.cos());
        let cos_z_sin_y = cos_z.clone() * sin_y.clone();
        let sin_z_sin_y = sin_z.clone() * sin_y.clone();
        let zero = Real::zero();
        let one = Real::one();
        let matrix = Matrix4::from_row_major([
            cos_z.clone() * cos_y.clone(),
            cos_z_sin_y.clone() * sin_x.clone() - sin_z.clone() * cos_x.clone(),
            cos_z_sin_y * cos_x.clone() + sin_z.clone() * sin_x.clone(),
            zero.clone(),
            sin_z.clone() * cos_y.clone(),
            sin_z_sin_y.clone() * sin_x.clone() + cos_z.clone() * cos_x.clone(),
            sin_z_sin_y * cos_x.clone() - cos_z * sin_x.clone(),
            zero.clone(),
            -sin_y,
            cos_y.clone() * sin_x,
            cos_y * cos_x,
            zero.clone(),
            zero.clone(),
            zero.clone(),
            zero,
            one,
        ]);
        let transformed = self.try_transformed_decision(decisions, &matrix)?;
        if let Some(certainty) = self
            .geometry_facts()
            .and_then(|facts| facts.valid_pwn.certainty())
        {
            transformed.facts.valid_pwn.record(certainty);
        }
        Ok(transformed)
    }

    /// Uniformly subdivides every triangle while sharing edge midpoints.
    ///
    /// Each level replaces one triangle with four consistently oriented
    /// triangles. Midpoints are indexed once per undirected edge, so adjacent
    /// input triangles remain adjacent in the result.
    pub fn subdivide_triangles(&self, levels: NonZeroU32) -> HypermeshResult<Self> {
        let mut positions = self.positions.to_vec();
        let mut triangles = self.triangles.to_vec();
        let two = Real::from(2_u8);
        for _ in 0..levels.get() {
            let mut midpoints = HashMap::<(usize, usize), usize>::new();
            let refined_capacity =
                triangles
                    .len()
                    .checked_mul(4)
                    .ok_or(HypermeshError::CapacityOverflow {
                        operation: "triangle subdivision",
                    })?;
            let mut refined = Vec::with_capacity(refined_capacity);
            for triangle in triangles {
                let [a, b, c] = triangle.indices();
                if let Some(index) = [a, b, c]
                    .into_iter()
                    .find(|index| *index >= positions.len())
                {
                    return Err(HypermeshError::VertexIndexOutOfBounds {
                        index,
                        vertex_count: positions.len(),
                    });
                }
                let mut midpoint = |left: usize, right: usize| -> HypermeshResult<usize> {
                    let edge = if left < right {
                        (left, right)
                    } else {
                        (right, left)
                    };
                    if let Some(index) = midpoints.get(&edge) {
                        return Ok(*index);
                    }
                    let left = &positions[edge.0];
                    let right = &positions[edge.1];
                    let point = Point3::new(
                        ((&left.x + &right.x) / &two)
                            .map_err(|_| HypermeshError::UnknownClassification)?,
                        ((&left.y + &right.y) / &two)
                            .map_err(|_| HypermeshError::UnknownClassification)?,
                        ((&left.z + &right.z) / &two)
                            .map_err(|_| HypermeshError::UnknownClassification)?,
                    );
                    let index = positions.len();
                    positions.push(point);
                    midpoints.insert(edge, index);
                    Ok(index)
                };
                let ab = midpoint(a, b)?;
                let bc = midpoint(b, c)?;
                let ca = midpoint(c, a)?;
                refined.extend([
                    Triangle::new(a, ab, ca),
                    Triangle::new(ab, b, bc),
                    Triangle::new(ca, bc, c),
                    Triangle::new(ab, bc, ca),
                ]);
            }
            triangles = refined;
        }
        let mesh = Self::new(positions, triangles);
        if let Some(certainty) = self
            .geometry_facts()
            .and_then(|facts| facts.valid_pwn.certainty())
        {
            mesh.facts.valid_pwn.record(certainty);
        }
        Ok(mesh)
    }

    /// Returns exact ray/triangle intersections sorted by ray parameter.
    ///
    /// Coplanar ray/triangle overlap has no unique point and is therefore not
    /// emitted. Exact edge and vertex contacts are deduplicated by point
    /// identity after all triangle reports have been collected.
    pub fn ray_intersections(
        &self,
        context: &MeshContext,
        origin: &Point3,
        direction: &Vector3,
    ) -> HypermeshResult<MeshOutcome<Vec<(Point3, Real)>>> {
        let decisions = DecisionContext::new(context);
        let hits = self.ray_intersections_decision(&decisions, origin, direction)?;
        Ok(decisions.finish(hits))
    }

    pub(crate) fn ray_intersections_decision(
        &self,
        decisions: &DecisionContext,
        origin: &Point3,
        direction: &Vector3,
    ) -> HypermeshResult<Vec<(Point3, Real)>> {
        let origin_limit =
            hyperlimit::Point3::new(origin.x.clone(), origin.y.clone(), origin.z.clone());
        let direction_limit = hyperlimit::Point3::new(
            direction.0[0].clone(),
            direction.0[1].clone(),
            direction.0[2].clone(),
        );
        let mut hits = Vec::new();
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            let vertex = |index| {
                self.positions
                    .get(index)
                    .ok_or(HypermeshError::VertexIndexOutOfBounds {
                        index,
                        vertex_count: self.positions.len(),
                    })
            };
            let (a, b, c) = (vertex(a)?, vertex(b)?, vertex(c)?);
            let vertices = [a, b, c].map(|point| {
                hyperlimit::Point3::new(point.x.clone(), point.y.clone(), point.z.clone())
            });
            let report = decisions.decide(
                hyperlimit::classify_ray_triangle3_intersection_report(
                    &origin_limit,
                    &direction_limit,
                    &vertices[0],
                    &vertices[1],
                    &vertices[2],
                    decisions.policy(),
                ),
                "ray-triangle intersection",
            )?;
            if !matches!(
                report.relation,
                hyperlimit::RayTriangleIntersection::Proper
                    | hyperlimit::RayTriangleIntersection::BoundaryTouch
            ) {
                continue;
            }
            if let (Some(point), Some(parameter)) = (&report.point, &report.parameter) {
                hits.push((
                    Point3::new(point.x.clone(), point.y.clone(), point.z.clone()),
                    parameter.clone(),
                ));
            }
        }
        for index in 1..hits.len() {
            let mut current = index;
            while current > 0
                && compare_real_decision(decisions, &hits[current - 1].1, &hits[current].1)?.is_gt()
            {
                hits.swap(current - 1, current);
                current -= 1;
            }
        }
        let mut unique_hits: Vec<(Point3, Real)> = Vec::with_capacity(hits.len());
        for hit in hits {
            let duplicate = if let Some((last, _)) = unique_hits.last() {
                let left = hyperlimit::Point3::new(last.x.clone(), last.y.clone(), last.z.clone());
                let right =
                    hyperlimit::Point3::new(hit.0.x.clone(), hit.0.y.clone(), hit.0.z.clone());
                decisions.decide(
                    hyperlimit::point3_equal(&left, &right, decisions.policy()),
                    "ray-hit point equality",
                )?
            } else {
                false
            };
            if !duplicate {
                unique_hits.push(hit);
            }
        }
        Ok(unique_hits)
    }

    /// Tests strict interior of the regularized nonzero-winding solid.
    ///
    /// Oriented crossings retain winding multiplicity and cancellation. Points
    /// on the represented set's boundary are excluded; internal source faces,
    /// edges and vertices follow the represented set's interior. Certified
    /// supporting bounds exclude points that cannot be strictly inside. Other
    /// source-face queries reuse the native Boolean arrangement to establish
    /// that boundary.
    ///
    /// Canonical empty geometry (both buffers empty) returns `false`. Every
    /// other input must satisfy [`Self::validate_closed_pwn`], including queries
    /// outside its bounds or on a source face. Invalid geometry returns its
    /// typed error before a containment shortcut can answer. Validation facts
    /// contribute their certainty and obey the same policy and source identity
    /// rules as explicit validation.
    ///
    /// Off-surface winding uses at most `8n + 1` candidate directions for `n`
    /// triangles. Boundary regularization uses the native arrangement. These
    /// algorithms have no total-work, heap-byte or cancellation limit; the ray
    /// count does not bound scalar expression growth or arrangement work.
    pub fn contains_point(
        &self,
        context: &MeshContext,
        point: &Point3,
    ) -> HypermeshResult<MeshOutcome<bool>> {
        let decisions = DecisionContext::new(context);
        let contains = self.contains_point_decision(&decisions, point)?;
        Ok(decisions.finish(contains))
    }

    pub(crate) fn contains_point_decision(
        &self,
        decisions: &DecisionContext,
        point: &Point3,
    ) -> HypermeshResult<bool> {
        if self.positions.is_empty() && self.triangles.is_empty() {
            return Ok(false);
        }
        self.validate_closed_pwn_decision(decisions)?;
        let bounds = match self.exact_bounds_decision(decisions) {
            Ok(bounds) => bounds,
            Err(HypermeshError::PredicateUndecided { .. }) => None,
            Err(error) => return Err(error),
        };
        if let Some(bounds) = bounds {
            for (coordinate, minimum, maximum) in [
                (&point.x, &bounds.mins.x, &bounds.maxs.x),
                (&point.y, &bounds.mins.y, &bounds.maxs.y),
                (&point.z, &bounds.mins.z, &bounds.maxs.z),
            ] {
                // A validated finite solid has exterior points arbitrarily
                // close to a supporting plane, so that plane has no strict
                // interior. This shortcut needs certified validation, bounds
                // and equality; approximate equality is not that proof.
                let lower = compare_real_decision(decisions, coordinate, minimum)?;
                if lower.is_lt()
                    || (lower.is_eq() && decisions.certainty() == MeshCertainty::Certified)
                {
                    return Ok(false);
                }
                let upper = compare_real_decision(decisions, coordinate, maximum)?;
                if upper.is_gt()
                    || (upper.is_eq() && decisions.certainty() == MeshCertainty::Certified)
                {
                    return Ok(false);
                }
            }
        }
        if self.point_on_surface_decision(decisions, point)? {
            let regularized = crate::boolean(
                &MeshContext::new(decisions.policy()),
                &[self.as_ref()],
                crate::BooleanProgram::Operation(crate::BooleanOp::Union),
            )?;
            decisions.absorb(regularized.certainty);
            let normalized = regularized.value.into_triangle_meshes()?.pop().ok_or(
                HypermeshError::SurfaceArrangementFailed {
                    reason: "containment regularization produced no result",
                },
            )?;
            if normalized.point_on_surface_decision(decisions, point)? {
                return Ok(false);
            }
            return Ok(
                mesh_winding_number_decision(decisions, &normalized, point, || Ok(()))? != 0,
            );
        }
        Ok(mesh_winding_number_decision(decisions, self, point, || Ok(()))? != 0)
    }

    fn point_on_surface_decision(
        &self,
        decisions: &DecisionContext,
        point: &Point3,
    ) -> HypermeshResult<bool> {
        let query = hyperlimit::Point3::new(point.x.clone(), point.y.clone(), point.z.clone());
        for triangle in self.triangles.iter() {
            let [a, b, c] = triangle.indices();
            let vertex = |index| {
                self.positions
                    .get(index)
                    .ok_or(HypermeshError::VertexIndexOutOfBounds {
                        index,
                        vertex_count: self.positions.len(),
                    })
            };
            let (a, b, c) = (vertex(a)?, vertex(b)?, vertex(c)?);
            let vertices = [a, b, c].map(|vertex| {
                hyperlimit::Point3::new(vertex.x.clone(), vertex.y.clone(), vertex.z.clone())
            });
            let location = decisions.decide(
                hyperlimit::classify_point_triangle3(
                    &vertices[0],
                    &vertices[1],
                    &vertices[2],
                    &query,
                    decisions.policy(),
                ),
                "point-triangle classification",
            )?;
            if matches!(
                location,
                hyperlimit::Triangle3Location::Inside
                    | hyperlimit::Triangle3Location::OnEdge
                    | hyperlimit::Triangle3Location::OnVertex
            ) {
                return Ok(true);
            }
        }
        Ok(false)
    }

    /// Intersects consecutive polyline segments with native triangles and
    /// returns exact points in polyline order.
    pub fn polyline_intersections(
        &self,
        context: &MeshContext,
        polyline: &[Point3],
    ) -> HypermeshResult<MeshOutcome<Vec<Point3>>> {
        let decisions = DecisionContext::new(context);
        let intersections = self.polyline_intersections_decision(&decisions, polyline)?;
        Ok(decisions.finish(intersections))
    }

    pub(crate) fn polyline_intersections_decision(
        &self,
        decisions: &DecisionContext,
        polyline: &[Point3],
    ) -> HypermeshResult<Vec<Point3>> {
        let mut output: Vec<Point3> = Vec::new();
        for segment in polyline.windows(2) {
            let direction = &segment[1] - &segment[0];
            for (point, parameter) in
                self.ray_intersections_decision(decisions, &segment[0], &direction)?
            {
                if compare_real_decision(decisions, &parameter, &Real::zero())?.is_lt()
                    || compare_real_decision(decisions, &parameter, &Real::one())?.is_gt()
                {
                    continue;
                }
                let duplicate = if let Some(last) = output.last() {
                    let left =
                        hyperlimit::Point3::new(last.x.clone(), last.y.clone(), last.z.clone());
                    let right =
                        hyperlimit::Point3::new(point.x.clone(), point.y.clone(), point.z.clone());
                    decisions.decide(
                        hyperlimit::point3_equal(&left, &right, decisions.policy()),
                        "polyline-hit point equality",
                    )?
                } else {
                    false
                };
                if !duplicate {
                    output.push(point);
                }
            }
        }
        Ok(output)
    }

    /// Returns the angle in radians between two indexed triangle normals.
    pub fn dihedral_angle(
        &self,
        context: &MeshContext,
        first: Triangle,
        second: Triangle,
    ) -> HypermeshResult<MeshOutcome<Real>> {
        let decisions = DecisionContext::new(context);
        let normal = |triangle: Triangle| -> HypermeshResult<Vector3> {
            let [a, b, c] = triangle.indices();
            let point = |index| {
                self.positions
                    .get(index)
                    .ok_or(HypermeshError::VertexIndexOutOfBounds {
                        index,
                        vertex_count: self.positions.len(),
                    })
            };
            let normal = (point(b)? - point(a)?).cross(&(point(c)? - point(a)?));
            match crate::predicate::classify_real(&decisions, &normal.dot(&normal))? {
                Classification::Positive => normal
                    .normalize_checked()
                    .map_err(|_| HypermeshError::UnknownClassification),
                Classification::On => Err(HypermeshError::DegeneratePointSet),
                Classification::Negative => Err(HypermeshError::UnknownClassification),
            }
        };
        let angle = normal(first)?
            .angle_to(&normal(second)?)
            .map_err(|_| HypermeshError::UnknownClassification)?;
        Ok(decisions.finish(angle))
    }

    /// Applies exact Laplacian smoothing to native positions.
    ///
    /// Triangle indexing is retained. Boundary preservation is intentionally
    /// not inferred here; callers requiring constrained smoothing should
    /// supply an explicit constraint set in a higher-level algorithm.
    pub fn laplacian_smooth(&self, lambda: &Real, iterations: usize) -> HypermeshResult<Self> {
        let adjacency = self.adjacency()?;
        let mut positions = self.positions.to_vec();
        let mut scratch = Vec::with_capacity(positions.len());
        for _ in 0..iterations {
            smooth_positions_once(&positions, &mut scratch, &adjacency, lambda);
            std::mem::swap(&mut positions, &mut scratch);
        }
        Ok(Self::new(positions, self.triangles.to_vec()))
    }

    /// Applies alternating Laplacian shrink and inflation passes.
    ///
    /// Each iteration applies `lambda` followed by `mu`, retaining the native
    /// triangle indexing while reducing the volume loss of one-sided
    /// Laplacian smoothing.
    pub fn taubin_smooth(
        &self,
        lambda: &Real,
        mu: &Real,
        iterations: usize,
    ) -> HypermeshResult<Self> {
        let adjacency = self.adjacency()?;
        let mut positions = self.positions.to_vec();
        let mut scratch = Vec::with_capacity(positions.len());
        for _ in 0..iterations {
            smooth_positions_once(&positions, &mut scratch, &adjacency, lambda);
            std::mem::swap(&mut positions, &mut scratch);
            smooth_positions_once(&positions, &mut scratch, &adjacency, mu);
            std::mem::swap(&mut positions, &mut scratch);
        }
        Ok(Self::new(positions, self.triangles.to_vec()))
    }
}

fn smooth_positions_once(
    positions: &[Point3],
    output: &mut Vec<Point3>,
    adjacency: &[Vec<usize>],
    factor: &Real,
) {
    output.clear();
    for (index, neighbors) in adjacency.iter().enumerate() {
        if neighbors.is_empty() {
            output.push(positions[index].clone());
            continue;
        }
        let mut sum = hyperlattice::Vector3::zero();
        for &neighbor in neighbors {
            sum = sum + positions[neighbor].to_vector();
        }
        let count = Real::from(neighbors.len() as u64);
        let average = (sum / count).expect("a nonempty adjacency row has a nonzero divisor");
        let current = positions[index].to_vector();
        output.push(Point3::origin() + current.clone() + (average - current) * factor.clone());
    }
}

/// Borrowed triangle mesh view.
#[derive(Clone, Copy, Debug)]
pub struct TriangleMeshRef<'a> {
    /// Borrowed positions.
    pub positions: &'a [Point3],
    /// Borrowed triangles.
    pub triangles: &'a [Triangle],
    pub(crate) native: Option<&'a TriangleMesh>,
}

impl<'a> TriangleMeshRef<'a> {
    /// Borrows position and triangle slices without retained native facts.
    pub const fn new(positions: &'a [Point3], triangles: &'a [Triangle]) -> Self {
        Self {
            positions,
            triangles,
            native: None,
        }
    }

    fn position_owner(self) -> Option<&'a TriangleMesh> {
        self.native
            .filter(|native| std::ptr::eq(self.positions, native.positions.as_ref()))
    }

    fn geometry_facts(self) -> Option<&'a TriangleMeshFacts> {
        self.position_owner()
            .filter(|native| std::ptr::eq(self.triangles, native.triangles.as_ref()))
            .and_then(TriangleMesh::geometry_facts)
    }
}

/// Working polygon soup.
#[derive(Clone, Debug, PartialEq)]
pub struct PolygonSoup {
    /// Polygons produced from input triangles.
    pub polygons: Vec<ConvexPolygon>,
    /// Exact bounds across all source positions.
    pub bounds: Aabb,
    /// Number of input meshes.
    pub num_meshes: usize,
    /// Exact number of source vertex identities referenced by the soup.
    pub(crate) source_vertex_count: usize,
}

impl PolygonSoup {
    /// Recomputes exact bounds from polygon vertices.
    pub fn compute_bounds_from_vertices(
        &mut self,
        context: &MeshContext,
    ) -> HypermeshResult<MeshOutcome<()>> {
        let decisions = DecisionContext::new(context);
        self.compute_bounds_from_vertices_decision(&decisions)?;
        Ok(decisions.finish(()))
    }

    pub(crate) fn compute_bounds_from_vertices_decision(
        &mut self,
        decisions: &DecisionContext,
    ) -> HypermeshResult<()> {
        let mut vertices = Vec::new();
        for polygon in &self.polygons {
            vertices.extend(polygon.vertices_decision(decisions)?);
        }
        self.bounds = bounds_for_positions(decisions, vertices.iter())?;
        Ok(())
    }
}

/// Validates borrowed mesh views and returns their combined polygon soup.
pub fn polygon_soup(
    context: &MeshContext,
    meshes: &[TriangleMeshRef<'_>],
) -> HypermeshResult<MeshOutcome<PolygonSoup>> {
    let decisions = DecisionContext::new(context);
    let soup = build_polygon_soup_internal(&decisions, meshes)?;
    Ok(decisions.finish(soup))
}

/// Validates a closed PWN mesh and certifies that every vertex lies in every
/// outward-oriented face half-space.
///
/// Native mesh owners retain only the policy-qualified closed-PWN validation
/// fact discovered while preparing the source faces. Convexity itself is not
/// a trusted shortcut or reusable Boolean-engine selector.
pub fn certify_convex_mesh(
    context: &MeshContext,
    mesh: TriangleMeshRef<'_>,
) -> HypermeshResult<MeshOutcome<()>> {
    let decisions = DecisionContext::new(context);
    certify_convex_mesh_decision(&decisions, mesh)?;
    Ok(decisions.finish(()))
}

fn certify_convex_mesh_decision(
    decisions: &DecisionContext,
    mesh: TriangleMeshRef<'_>,
) -> HypermeshResult<()> {
    let soup = build_polygon_soup_internal(decisions, &[mesh])?;
    for polygon in &soup.polygons {
        for point in mesh.positions {
            if classify_point_decision(decisions, point, polygon.support_plane())?
                == Classification::Positive
            {
                return Err(HypermeshError::NonConvexInput);
            }
        }
    }
    Ok(())
}

pub(crate) fn build_polygon_soup_internal(
    decisions: &DecisionContext,
    meshes: &[TriangleMeshRef<'_>],
) -> HypermeshResult<PolygonSoup> {
    crate::trace_dispatch!("build-polygon-soup", "start");
    validate_non_empty_mesh_views(meshes)?;

    let bounds = bounds_for_positions(
        decisions,
        meshes.iter().flat_map(|mesh| mesh.positions.iter()),
    )?;
    crate::trace_dispatch!("build-polygon-soup", "bounds-computed");

    let polygon_capacity = meshes
        .iter()
        .try_fold(0usize, |total, mesh| {
            total.checked_add(mesh.triangles.len())
        })
        .ok_or(HypermeshError::UnknownClassification)?;
    let mut polygons: Vec<ConvexPolygon> = Vec::with_capacity(polygon_capacity);
    let mut source_vertex_count = 0_usize;
    for (mesh_index, mesh) in meshes.iter().enumerate() {
        let signed_mesh_index =
            isize::try_from(mesh_index).map_err(|_| HypermeshError::CapacityOverflow {
                operation: "source polygon mesh index",
            })?;
        let position_owner = mesh.position_owner();
        let geometry_facts = mesh.geometry_facts();
        let normalize_wide_dyadic = position_owner
            .and_then(TriangleMesh::position_facts)
            .map_or_else(
                || points_require_wide_dyadic_plane_normalization(mesh.positions),
                |facts| facts.normalizes_wide_dyadic_planes(mesh.positions),
            );
        let source_usage = validate_source_pwn(decisions, *mesh, mesh_index)?;
        source_vertex_count = source_vertex_count
            .checked_add(source_usage.referenced_count)
            .ok_or(HypermeshError::CapacityOverflow {
                operation: "source vertex identity count",
            })?;
        let source_positions = RetainedSourcePositions::shared_with_predicate_queries(
            position_owner.map_or_else(
                || Arc::<[Point3]>::from(mesh.positions),
                |native| Arc::clone(&native.positions),
            ),
            &source_usage.referenced,
        )?;
        drop(source_usage);
        let retained_compact = geometry_facts
            .and_then(|facts| facts.source_polygon_planes.get())
            .cloned();
        let compact = if retained_compact.is_some() {
            retained_compact
        } else if mesh.native.is_some() && decisions.certainty() == MeshCertainty::Certified {
            let compact =
                compact_source_polygons(&source_positions, mesh.triangles, normalize_wide_dyadic)
                    .map(Arc::new);
            if let Some(compact) = &compact
                && decisions.certainty() == MeshCertainty::Certified
                && let Some(facts) = geometry_facts
            {
                let _ = facts.source_polygon_planes.set(Arc::clone(compact));
            }
            compact
        } else {
            None
        };
        let source_planes =
            RetainedSourcePlanes::new(mesh.triangles.len(), compact, normalize_wide_dyadic)?;
        for (triangle_index, triangle) in mesh.triangles.iter().enumerate() {
            let polygon_index =
                isize::try_from(polygons.len()).map_err(|_| HypermeshError::CapacityOverflow {
                    operation: "source polygon index",
                })?;
            let vertices = triangle.indices().map(|vertex| {
                debug_assert!(u32::try_from(vertex).is_ok());
                vertex as u32
            });
            let polygon = ConvexPolygon::from_source_triangle(
                decisions,
                Arc::clone(&source_planes),
                Arc::clone(&source_positions),
                vertices,
                triangle_index,
                mesh_index,
                signed_mesh_index,
                polygon_index,
            )?;
            polygons.push(finish_source_polygon(polygon, mesh_index, meshes.len()));
        }
    }
    crate::trace_dispatch!("build-polygon-soup", "complete");
    Ok(PolygonSoup {
        polygons,
        bounds,
        num_meshes: meshes.len(),
        source_vertex_count,
    })
}

struct SourceVertexUsage {
    referenced: Vec<bool>,
    referenced_count: usize,
}

fn validate_source_pwn(
    decisions: &DecisionContext,
    mesh: TriangleMeshRef<'_>,
    mesh_index: usize,
) -> HypermeshResult<SourceVertexUsage> {
    let local = decisions.isolated();
    let geometry_facts = mesh.geometry_facts();
    let certified = geometry_facts.is_some_and(|facts| facts.valid_pwn.consume(&local));
    let result = (|| {
        let usage = validate_source_triangles(&local, mesh, mesh_index, !certified)?;
        if !certified {
            let edge_balance = classify_indexed_edge_balance(&local, &mesh)?;
            if edge_balance.boundary_edges != 0 {
                return Err(HypermeshError::OpenInput {
                    mesh_index,
                    boundary_edges: edge_balance.boundary_edges,
                });
            }
            if edge_balance.unbalanced_edges != 0 {
                return Err(HypermeshError::NonPwnInput {
                    mesh_index,
                    unbalanced_edges: edge_balance.unbalanced_edges,
                });
            }
            if let Some(facts) = geometry_facts {
                // The reusable claim depends on both nondegeneracy and edge
                // balance; retain the certainty of the complete validation.
                facts.valid_pwn.record(local.certainty());
            }
        }
        Ok(usage)
    })();
    decisions.absorb(local.certainty());
    result
}

fn validate_source_triangles(
    decisions: &DecisionContext,
    mesh: TriangleMeshRef<'_>,
    mesh_index: usize,
    validate_nondegenerate: bool,
) -> HypermeshResult<SourceVertexUsage> {
    // Source IDs index one dense position owner. Count their referenced subset
    // while validation already has every checked index, so corefinement can
    // size its final identity table without cloning and hashing all IDs first.
    let mut referenced = Vec::new();
    referenced
        .try_reserve_exact(mesh.positions.len())
        .map_err(|_| HypermeshError::CapacityOverflow {
            operation: "source vertex usage",
        })?;
    referenced.resize(mesh.positions.len(), false);
    let mut referenced_count = 0_usize;
    for (triangle_index, triangle) in mesh.triangles.iter().enumerate() {
        let indices = triangle.indices();
        let points = indices.map(|index| {
            mesh.positions
                .get(index)
                .ok_or(HypermeshError::VertexIndexOutOfBounds {
                    index,
                    vertex_count: mesh.positions.len(),
                })
        });
        let [first, second, third] = points;
        let [first, second, third] = [first?, second?, third?];
        if validate_nondegenerate
            && !Plane::decide_points_are_nondegenerate(decisions, first, second, third)?
        {
            return Err(HypermeshError::DegenerateTriangle {
                mesh_index,
                triangle_index,
            });
        }
        let vertices = indices.map(|index| {
            u32::try_from(index).map_err(|_| HypermeshError::CapacityOverflow {
                operation: "source triangle vertex ID",
            })
        });
        let [first, second, third] = vertices;
        let _ = [first?, second?, third?];
        for index in indices {
            if !referenced[index] {
                referenced[index] = true;
                referenced_count += 1;
            }
        }
    }
    Ok(SourceVertexUsage {
        referenced,
        referenced_count,
    })
}

fn compact_source_polygons(
    positions: &RetainedSourcePositions,
    triangles: &[Triangle],
    normalize_wide_dyadic: bool,
) -> Option<CompactSourcePolygons> {
    let rows = triangles
        .iter()
        .map(|triangle| {
            let points = triangle.indices().map(|vertex| positions.get(vertex));
            let [first, second, third] = points;
            let planes = source_triangle_planes([first?, second?, third?], normalize_wide_dyadic);
            CompactSourcePolygon::<f64>::from_planes(planes.each_ref())
        })
        .collect::<Option<Vec<_>>>()?;
    Some(CompactSourcePolygons::from_binary64_rows(rows))
}

fn finish_source_polygon(
    mut polygon: ConvexPolygon,
    mesh_index: usize,
    operand_count: usize,
) -> ConvexPolygon {
    polygon.delta_w = vec![0; operand_count];
    polygon.delta_w[mesh_index] = 1;
    polygon
}

fn canonical_position_indices(
    decisions: &DecisionContext,
    positions: &[Point3],
) -> HypermeshResult<Vec<usize>> {
    let exact_only = positions
        .iter()
        .all(PointCoordinates::has_exact_rational_coordinates);
    let mut interner = PointInterner::<()>::try_with_capacity(positions.len(), exact_only, false)?;
    let mut canonical_positions: Vec<&Point3> = Vec::with_capacity(positions.len());
    let mut canonical_indices = Vec::with_capacity(positions.len());
    for position in positions {
        canonical_indices.push(interner.intern_cloned(
            decisions,
            &mut canonical_positions,
            &position,
            None,
        )?);
    }
    Ok(canonical_indices)
}

fn classify_indexed_edge_balance(
    decisions: &DecisionContext,
    mesh: &TriangleMeshRef<'_>,
) -> HypermeshResult<EdgeBalance> {
    let canonical_indices = canonical_position_indices(decisions, mesh.positions)?;
    let mut edge_uses: StorageHashMap<[usize; 2], [usize; 2]> = StorageHashMap::default();
    for triangle in mesh.triangles {
        let [a, b, c] = triangle.indices().map(|index| canonical_indices[index]);
        for [start, end] in [[a, b], [b, c], [c, a]] {
            let (key, direction) = if start < end {
                ([start, end], 0)
            } else {
                ([end, start], 1)
            };
            edge_uses.entry(key).or_default()[direction] += 1;
        }
    }

    Ok(edge_uses
        .values()
        .fold(EdgeBalance::default(), |mut balance, uses| {
            if uses[0] + uses[1] == 1 {
                balance.boundary_edges += 1;
            }
            if uses[0] != uses[1] {
                balance.unbalanced_edges += 1;
            }
            balance
        }))
}

fn validate_non_empty_mesh_views(meshes: &[TriangleMeshRef<'_>]) -> HypermeshResult<()> {
    if meshes.is_empty() {
        return Err(HypermeshError::EmptyInput);
    }
    for (mesh_index, mesh) in meshes.iter().enumerate() {
        if mesh.positions.is_empty() || mesh.triangles.is_empty() {
            return Err(HypermeshError::EmptyMesh { mesh_index });
        }
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub(crate) struct EdgeBalance {
    pub(crate) boundary_edges: usize,
    pub(crate) unbalanced_edges: usize,
}

fn bounds_for_positions<'a>(
    decisions: &DecisionContext,
    positions: impl IntoIterator<Item = &'a Point3>,
) -> HypermeshResult<Aabb> {
    let mut positions = positions.into_iter();
    let first = positions.next().ok_or(HypermeshError::EmptyInput)?;
    let mut min = first.clone();
    let mut max = first.clone();
    let first_coordinates = [&first.x, &first.y, &first.z];
    let mut exact_dyadic_bounds = match first_coordinates.map(Real::to_f64_exact_dyadic) {
        [Some(x), Some(y), Some(z)] => Some(([x, y, z], [x, y, z])),
        _ => None,
    };

    for position in positions {
        if let Some((min_f64, max_f64)) = &mut exact_dyadic_bounds {
            let coordinates = [&position.x, &position.y, &position.z];
            if let [Some(x), Some(y), Some(z)] = coordinates.map(Real::to_f64_exact_dyadic) {
                for (axis, value) in [x, y, z].into_iter().enumerate() {
                    if value < min_f64[axis] {
                        min_f64[axis] = value;
                        *crate::geometry::axis_mut(&mut min, axis) =
                            axis_ref(position, axis).clone();
                    }
                    if value > max_f64[axis] {
                        max_f64[axis] = value;
                        *crate::geometry::axis_mut(&mut max, axis) =
                            axis_ref(position, axis).clone();
                    }
                }
                continue;
            }
            exact_dyadic_bounds = None;
        }
        for axis in 0..3 {
            if compare_real_decision(decisions, axis_ref(position, axis), axis_ref(&min, axis))?
                .is_lt()
            {
                *crate::geometry::axis_mut(&mut min, axis) = axis_ref(position, axis).clone();
            }
            if compare_real_decision(decisions, axis_ref(position, axis), axis_ref(&max, axis))?
                .is_gt()
            {
                *crate::geometry::axis_mut(&mut max, axis) = axis_ref(position, axis).clone();
            }
        }
    }

    Ok(Aabb::new(min, max))
}

#[cfg(test)]
mod fact_identity_tests;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn approximate_pwn_facts_obey_later_operation_policy() {
        let mesh = tetrahedron_with_independent_face_indices()
            .with_valid_pwn_certainty(MeshCertainty::Approximate512Consumed);

        let strict_context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let strict = DecisionContext::new(&strict_context);
        assert!(!mesh.facts.valid_pwn.consume(&strict));
        assert_eq!(strict.certainty(), MeshCertainty::Certified);

        let approximate_context = MeshContext::new(hyperlimit::PredicatePolicy::APPROXIMATE_512);
        let approximate = DecisionContext::new(&approximate_context);
        assert!(mesh.facts.valid_pwn.consume(&approximate));
        assert_eq!(
            approximate.certainty(),
            MeshCertainty::Approximate512Consumed
        );

        mesh.facts.valid_pwn.record(MeshCertainty::Certified);
        let upgraded_strict = DecisionContext::new(&strict_context);
        assert!(mesh.facts.valid_pwn.consume(&upgraded_strict));
        assert_eq!(upgraded_strict.certainty(), MeshCertainty::Certified);
    }

    #[test]
    fn strict_soup_validation_upgrades_an_approximate_cached_pwn_fact() {
        let mesh = tetrahedron_with_independent_face_indices();
        mesh.facts
            .valid_pwn
            .record(MeshCertainty::Approximate512Consumed);

        let strict_context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let strict = DecisionContext::new(&strict_context);
        build_polygon_soup_internal(&strict, &[mesh.as_ref()]).unwrap();

        assert_eq!(
            mesh.facts.valid_pwn.certainty(),
            Some(MeshCertainty::Certified)
        );
        assert_eq!(strict.certainty(), MeshCertainty::Certified);
    }

    #[test]
    fn native_mesh_retains_only_certified_source_polygon_geometry() {
        let mesh = tetrahedron_with_independent_face_indices();
        assert!(mesh.facts.source_polygon_planes.get().is_none());

        let approximate_context = MeshContext::new(hyperlimit::PredicatePolicy::APPROXIMATE_512);
        let approximate = DecisionContext::new(&approximate_context);
        approximate.absorb(MeshCertainty::Approximate512Consumed);
        build_polygon_soup_internal(&approximate, &[mesh.as_ref()]).unwrap();
        assert!(mesh.facts.source_polygon_planes.get().is_none());

        let strict_context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let strict = DecisionContext::new(&strict_context);
        let first = build_polygon_soup_internal(&strict, &[mesh.as_ref()]).unwrap();
        assert_eq!(
            first.polygons[0].source_plane_materialization_counts(),
            Some((true, mesh.triangles.len(), mesh.triangles.len()))
        );
        let cached = mesh
            .facts
            .source_polygon_planes
            .get()
            .expect("certified native geometry is retained");
        assert_eq!(cached.len(), mesh.triangles.len());

        let second = build_polygon_soup_internal(&strict, &[mesh.as_ref()]).unwrap();
        assert_eq!(first, second);
        assert!(matches!(
            cached.as_ref(),
            CompactSourcePolygons::Binary32(_)
        ));
        let cached_support = match cached.as_ref() {
            CompactSourcePolygons::Binary32(polygons) => polygons[0].planes[0].map(f64::from),
            CompactSourcePolygons::Binary64(polygons) => polygons[0].planes[0],
        };
        assert_eq!(
            cached_support,
            crate::polygon::exact_dyadic_plane_coefficients(second.polygons[0].support_plane(),)
                .unwrap()
        );

        let consumed = DecisionContext::new(&approximate_context);
        consumed.absorb(MeshCertainty::Approximate512Consumed);
        assert_eq!(
            build_polygon_soup_internal(&consumed, &[mesh.as_ref()]).unwrap(),
            first
        );
        assert_eq!(consumed.certainty(), MeshCertainty::Approximate512Consumed);
    }

    #[test]
    fn source_polygon_vertex_cycles_share_one_checked_position_owner() {
        use crate::polygon::RetainedVertexCycle;

        let mesh = tetrahedron_with_independent_face_indices();
        let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let native =
            build_polygon_soup_internal(&DecisionContext::new(&context), &[mesh.as_ref()]).unwrap();
        for (polygon, triangle) in native.polygons.iter().zip(mesh.triangles.iter()) {
            let Some(RetainedVertexCycle::SourceTriangle {
                positions,
                vertices,
                ..
            }) = &polygon.known_vertices
            else {
                panic!("native source face must retain an indexed vertex cycle");
            };
            assert!(Arc::ptr_eq(positions.owner(), &mesh.positions));
            assert_eq!(*vertices, triangle.indices().map(|index| index as u32));
            assert!(polygon.approx_bounds.is_none());
            let points = triangle.indices().map(|index| &mesh.positions[index]);
            let expected = crate::polygon::ApproxBounds::for_points(&context, &points)
                .unwrap()
                .value;
            assert_eq!(polygon.retained_bounds(), Some(expected.borrowed()));
        }

        let borrowed = TriangleMeshRef::new(&mesh.positions, &mesh.triangles);
        let borrowed =
            build_polygon_soup_internal(&DecisionContext::new(&context), &[borrowed]).unwrap();
        let Some(RetainedVertexCycle::SourceTriangle {
            positions: shared, ..
        }) = &borrowed.polygons[0].known_vertices
        else {
            panic!("borrowed source face must retain an indexed vertex cycle");
        };
        assert!(!Arc::ptr_eq(shared.owner(), &mesh.positions));
        for polygon in &borrowed.polygons[1..] {
            let Some(RetainedVertexCycle::SourceTriangle { positions, .. }) =
                &polygon.known_vertices
            else {
                panic!("borrowed source face must retain an indexed vertex cycle");
            };
            assert!(Arc::ptr_eq(positions, shared));
        }

        let inverted = native.polygons[0].inverted();
        assert_eq!(
            inverted.retained_bounds(),
            native.polygons[0].retained_bounds()
        );
        let Some(RetainedVertexCycle::SourceTriangle {
            positions,
            vertices,
            ..
        }) = inverted.known_vertices
        else {
            panic!("inversion must preserve an indexed source cycle");
        };
        assert!(Arc::ptr_eq(positions.owner(), &mesh.positions));
        let [first, second, third] = mesh.triangles[0].indices().map(|index| index as u32);
        assert_eq!(vertices, [third, second, first]);
    }

    #[test]
    fn source_polygon_plane_storage_uses_only_lossless_tiers() {
        fn translated_tetrahedron(offset: &Real) -> TriangleMesh {
            let mesh = tetrahedron_with_independent_face_indices();
            let positions = mesh
                .positions
                .iter()
                .map(|point| Point3::new(&point.x + offset, &point.y + offset, &point.z + offset))
                .collect();
            TriangleMesh::new(positions, mesh.triangles.to_vec())
        }

        let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let binary64 = translated_tetrahedron(&Real::try_from(1.0 + 2f64.powi(-30)).unwrap());
        let decisions = DecisionContext::new(&context);
        let first = build_polygon_soup_internal(&decisions, &[binary64.as_ref()]).unwrap();
        assert!(
            binary64
                .facts
                .source_polygon_planes
                .get()
                .is_some_and(|planes| matches!(
                    planes.as_ref(),
                    CompactSourcePolygons::Binary64(_)
                ))
        );
        let decisions = DecisionContext::new(&context);
        assert_eq!(
            build_polygon_soup_internal(&decisions, &[binary64.as_ref()]).unwrap(),
            first
        );

        let one_third = Real::new(Rational::fraction(1, 3).unwrap());
        let general = translated_tetrahedron(&one_third);
        let decisions = DecisionContext::new(&context);
        let first = build_polygon_soup_internal(&decisions, &[general.as_ref()]).unwrap();
        assert!(general.facts.source_polygon_planes.get().is_none());
        let decisions = DecisionContext::new(&context);
        assert_eq!(
            build_polygon_soup_internal(&decisions, &[general.as_ref()]).unwrap(),
            first
        );
        assert!(general.facts.source_polygon_planes.get().is_none());
    }

    #[test]
    fn borrowed_source_planes_materialize_only_on_exact_demand() {
        let mesh = tetrahedron_with_independent_face_indices();
        let borrowed = TriangleMeshRef::new(&mesh.positions, &mesh.triangles);
        let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let decisions = DecisionContext::new(&context);
        let soup = build_polygon_soup_internal(&decisions, &[borrowed]).unwrap();
        let polygon = &soup.polygons[0];
        assert_eq!(
            polygon.source_plane_materialization_counts(),
            Some((false, 0, 0))
        );

        let points = mesh.triangles[0]
            .indices()
            .map(|vertex| &mesh.positions[vertex]);
        let expected = source_triangle_planes(points, false);
        assert_eq!(polygon.support_plane(), &expected[0]);
        assert_eq!(
            polygon.source_plane_materialization_counts(),
            Some((false, 1, 0))
        );
        assert_eq!(polygon.edge_planes(), &expected[1..]);
        assert_eq!(
            polygon.source_plane_materialization_counts(),
            Some((false, 1, 1))
        );

        let mut projective = polygon.clone();
        projective.clear_known_vertices();
        assert_eq!(projective.support_plane(), &expected[0]);
        assert_eq!(projective.edge_planes(), &expected[1..]);
    }

    #[test]
    fn retained_source_planes_are_restamped_for_each_operand_position() {
        let cached = tetrahedron_with_independent_face_indices();
        let other = tetrahedron_with_independent_face_indices();
        let context = MeshContext::new(hyperlimit::PredicatePolicy::STRICT);
        let first = DecisionContext::new(&context);
        build_polygon_soup_internal(&first, &[cached.as_ref()]).unwrap();
        assert!(cached.facts.source_polygon_planes.get().is_some());

        let retained = DecisionContext::new(&context);
        let retained =
            build_polygon_soup_internal(&retained, &[other.as_ref(), cached.as_ref()]).unwrap();
        let borrowed = DecisionContext::new(&context);
        let borrowed = build_polygon_soup_internal(
            &borrowed,
            &[
                TriangleMeshRef::new(&other.positions, &other.triangles),
                TriangleMeshRef::new(&cached.positions, &cached.triangles),
            ],
        )
        .unwrap();
        assert_eq!(retained, borrowed);
        for (retained, borrowed) in retained.polygons.iter().zip(&borrowed.polygons) {
            assert_eq!(retained.known_identities, borrowed.known_identities);
        }
        for polygon in &retained.polygons[other.triangles.len()..] {
            assert_eq!(polygon.mesh_index, 1);
            assert_eq!(polygon.delta_w, [0, 1]);
        }
    }

    #[test]
    fn polygon_soup_counts_only_referenced_source_vertex_identities() {
        let first = tetrahedron_with_independent_face_indices();
        let mut positions = first.positions.to_vec();
        positions.push(Point3::new(
            Real::from(17_u8),
            Real::from(19_u8),
            Real::from(23_u8),
        ));
        let with_unused = TriangleMesh::new(positions, first.triangles.to_vec());
        let second = tetrahedron_with_independent_face_indices();
        let decisions = crate::test_support::approximate_decisions();
        let soup =
            build_polygon_soup_internal(&decisions, &[with_unused.as_ref(), second.as_ref()])
                .unwrap();

        // Each tetrahedron intentionally uses three separate source IDs per
        // face even though exact coordinates alias to four numeric points.
        assert_eq!(soup.source_vertex_count, 24);
        assert_eq!(soup.polygons.len(), 8);
        assert_eq!(decisions.certainty(), MeshCertainty::Certified);
    }

    #[test]
    fn borrowed_mesh_view_does_not_publish_source_polygon_geometry() {
        let mesh = tetrahedron_with_independent_face_indices();
        let borrowed = TriangleMeshRef::new(&mesh.positions, &mesh.triangles);
        build_polygon_soup_internal(&crate::test_support::approximate_decisions(), &[borrowed])
            .unwrap();
        assert!(mesh.facts.source_polygon_planes.get().is_none());
    }

    fn tetrahedron_with_independent_face_indices() -> TriangleMesh {
        let points = [
            Point3::new(Real::zero(), Real::zero(), Real::zero()),
            Point3::new(Real::one(), Real::zero(), Real::zero()),
            Point3::new(Real::zero(), Real::one(), Real::zero()),
            Point3::new(Real::zero(), Real::zero(), Real::one()),
        ];
        let faces = [[0, 2, 1], [0, 1, 3], [0, 3, 2], [1, 2, 3]];
        let mut positions = Vec::new();
        let mut triangles = Vec::new();
        for face in faces {
            let base = positions.len();
            positions.extend(face.map(|index| points[index].clone()));
            triangles.push(Triangle::new(base, base + 1, base + 2));
        }
        TriangleMesh::new(positions, triangles)
    }

    #[test]
    fn exact_triangle_quality_canonicalizes_positions_and_rejects_duplicate_faces() {
        let mesh = tetrahedron_with_independent_face_indices();
        assert!(
            mesh.has_unique_nondegenerate_triangles_decision(
                &crate::test_support::approximate_decisions()
            )
            .unwrap()
        );
        assert!(
            mesh.is_closed_manifold_geometry_decision(
                &crate::test_support::approximate_decisions()
            )
            .unwrap()
        );
        assert!(!mesh.is_closed_manifold());

        let mut triangles = mesh.triangles.to_vec();
        triangles.push(triangles[0]);
        let duplicate = TriangleMesh::new(mesh.positions.to_vec(), triangles);
        assert!(
            !duplicate
                .has_unique_nondegenerate_triangles_decision(
                    &crate::test_support::approximate_decisions()
                )
                .unwrap()
        );
        assert!(
            !duplicate
                .is_closed_manifold_geometry_decision(&crate::test_support::approximate_decisions())
                .unwrap()
        );
    }

    #[test]
    fn geometric_closure_uses_numeric_point_equality() {
        let mesh = tetrahedron_with_independent_face_indices();
        let left = Real::pi() + Real::e();
        let equivalent_left = Real::e() + Real::pi();
        assert_ne!(left, equivalent_left);
        let positions = mesh
            .positions
            .iter()
            .enumerate()
            .map(|(index, point)| {
                let offset = if index % 2 == 0 {
                    left.clone()
                } else {
                    equivalent_left.clone()
                };
                Point3::new(&point.x + offset, point.y.clone(), point.z.clone())
            })
            .collect();
        let mesh = TriangleMesh::new(positions, mesh.triangles.to_vec());

        assert!(
            mesh.has_unique_nondegenerate_triangles_decision(
                &crate::test_support::approximate_decisions()
            )
            .unwrap()
        );
        assert!(
            mesh.is_closed_manifold_geometry_decision(
                &crate::test_support::approximate_decisions()
            )
            .unwrap()
        );
    }

    #[test]
    fn reversed_winding_shares_positions_without_retaining_derived_indices() {
        let mesh = TriangleMesh::new(
            vec![
                Point3::new(Real::zero(), Real::zero(), Real::zero()),
                Point3::new(Real::one(), Real::zero(), Real::zero()),
                Point3::new(Real::zero(), Real::one(), Real::zero()),
            ],
            vec![Triangle::new(0, 1, 2)],
        );

        let reversed = mesh.reversed_winding();
        let retained = mesh.reversed_winding();
        assert!(Arc::ptr_eq(&mesh.positions, &reversed.positions));
        assert!(!Arc::ptr_eq(&reversed.triangles, &retained.triangles));
        assert_eq!(reversed, retained);
        assert_eq!(mesh.triangles[0], Triangle::new(0, 1, 2));
        assert_eq!(reversed.triangles[0], Triangle::new(2, 1, 0));
    }

    #[test]
    fn mesh_fact_header_stays_compact() {
        // Source identities are required for correctness with public buffer
        // edits. Keep the previous 80-byte budget for the remaining facts.
        let identities =
            std::mem::size_of::<Weak<[Point3]>>() + std::mem::size_of::<Weak<[Triangle]>>();
        assert!(
            std::mem::size_of::<TriangleMeshFacts>() <= 80 + identities,
            "cold mesh facts occupy {} bytes",
            std::mem::size_of::<TriangleMeshFacts>(),
        );
    }
    use hyperlattice::Rational;

    #[test]
    fn bounds_exact_dyadic_scan_falls_back_for_later_general_rational() {
        let one_third = Real::new(Rational::fraction(1, 3).unwrap());
        let points = [
            Point3::new(Real::from(4), Real::from(-2), Real::from(8)),
            Point3::new(Real::from(-3), Real::from(5), Real::from(1)),
            Point3::new(one_third.clone(), Real::from(-7), Real::from(9)),
        ];

        assert_eq!(
            bounds_for_positions(&crate::test_support::approximate_decisions(), &points).unwrap(),
            Aabb::new(
                Point3::new(Real::from(-3), Real::from(-7), Real::from(1)),
                Point3::new(Real::from(4), Real::from(5), Real::from(9)),
            ),
        );
    }

    #[test]
    fn indexed_edge_balance_canonicalizes_coincident_input_vertices() {
        let geometric = [
            Point3::new(Real::zero(), Real::zero(), Real::zero()),
            Point3::new(Real::one(), Real::zero(), Real::zero()),
            Point3::new(Real::zero(), Real::one(), Real::zero()),
            Point3::new(Real::zero(), Real::zero(), Real::one()),
        ];
        let faces = [[0, 2, 1], [0, 1, 3], [1, 2, 3], [2, 0, 3]];
        let mut positions = Vec::new();
        let mut triangles = Vec::new();
        for face in faces {
            let start = positions.len();
            positions.extend(face.map(|index| geometric[index].clone()));
            triangles.push(Triangle::new(start, start + 1, start + 2));
        }
        let mesh = TriangleMesh::new(positions, triangles);

        assert_eq!(
            classify_indexed_edge_balance(
                &crate::test_support::approximate_decisions(),
                &mesh.as_ref()
            ),
            Ok(EdgeBalance::default())
        );
        crate::test_support::approximate_polygon_soup(&[mesh.as_ref()])
            .expect("closed coincident-index tetrahedron");
    }

    #[test]
    fn exact_native_queries_reject_invalid_triangle_indices() {
        let mesh = TriangleMesh::new(
            vec![
                Point3::new(Real::zero(), Real::zero(), Real::zero()),
                Point3::new(Real::one(), Real::zero(), Real::zero()),
                Point3::new(Real::zero(), Real::one(), Real::zero()),
            ],
            vec![Triangle::new(0, 1, 3)],
        );
        let expected = HypermeshError::VertexIndexOutOfBounds {
            index: 3,
            vertex_count: 3,
        };

        assert_eq!(
            mesh.ray_intersections_decision(
                &crate::test_support::approximate_decisions(),
                &Point3::new(Real::zero(), Real::zero(), Real::one()),
                &Vector3::from_xyz(Real::zero(), Real::zero(), -Real::one()),
            ),
            Err(expected.clone()),
        );
        assert_eq!(
            mesh.contains_point_decision(
                &crate::test_support::approximate_decisions(),
                &Point3::new(
                    Real::from(Rational::fraction(1, 4).unwrap()),
                    Real::from(Rational::fraction(1, 4).unwrap()),
                    Real::zero(),
                )
            ),
            Err(expected),
        );
    }
}
