#[path = "support/selected_planar_images.rs"]
mod acceptance;

#[test]
fn selected_planar_points_keep_frame_and_source_correlation() {
    acceptance::selected_planar_points_keep_frame_and_source_correlation();
}
#[test]
fn selected_planar_points_replay_sources_and_affine_transforms() {
    acceptance::selected_planar_points_replay_sources_and_affine_transforms();
}
#[test]
fn selected_parallel_edge_splits_replay_the_whole_cap() {
    acceptance::selected_parallel_edge_splits_replay_the_whole_cap();
}
