use hyperbrep::*;
use hypercurve::{
    BezierParameter2, BezierParameterRange2, CubicBezier2, Curve2, Point2 as Uv, QuadraticBezier2,
};
use std::cmp::Ordering;

// Reuse the unchanged original full cap, including quadratic closing segments.
#[allow(dead_code)]
#[path = "parallel_profile_extrusion.rs"]
mod prior;

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn root(scale: i32) -> Parameter {
    let curve = Curve3::rational_bezier(
        [-1, -1, -1, 2 * scale * scale * scale - 1]
            .map(|x| Point3::new(x.into(), 0.into(), 0.into()))
            .to_vec(),
        vec![Real::one(); 4],
    )
    .unwrap();
    let CurveParameterLocation::Parameters(mut parameters) =
        curve.parameters_of(&Point3::origin()).unwrap()
    else {
        panic!("selected root")
    };
    assert_eq!(parameters.len(), 1);
    let parameter = parameters.remove(0);
    assert!(parameter.try_real().is_none());
    parameter
}

fn frame(source: Curve2) -> Curve3 {
    Curve3::planar_image(
        source,
        Point3::new(5.into(), (-2).into(), 7.into()),
        Vector3::new([2.into(), 1.into(), (-1).into()]),
        Vector3::new([1.into(), 3.into(), 2.into()]),
    )
    .unwrap()
}

fn polynomial() -> Curve2 {
    CubicBezier2::new(
        Uv::from_values(0, 0),
        Uv::new(q(1, 3), 0.into()),
        Uv::new(q(2, 3), 0.into()),
        Uv::from_values(1, 1),
    )
    .into()
}

fn parallel(a: i32, b: i32) -> Curve2 {
    let source = QuadraticBezier2::new(
        Uv::from_values(0, 0),
        Uv::from_values(2, 2),
        Uv::from_values(4, 0),
    )
    .parallel_left(Real::one())
    .unwrap();
    Curve2::try_analytic_parallel(
        source,
        BezierParameterRange2::try_new(
            BezierParameter2::Exact(a.into()),
            BezierParameter2::Exact(b.into()),
        )
        .unwrap(),
    )
    .unwrap()
}

fn reload(model: &Model) -> Model {
    let json = model.to_json().unwrap();
    let model = RawModel::from_json(&json, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(model.to_json().unwrap(), json);
    model
}

pub fn selected_planar_points_keep_frame_and_source_correlation() {
    let curve = frame(polynomial());
    let parameter = root(1);
    let point = curve.point_at(&parameter).unwrap();
    assert!(point.try_coordinates().is_none());
    let (source, retained) = point.curve_source().unwrap();
    assert_eq!(source.kind(), Curve3Kind::PlanarImage);
    assert_eq!(retained.compare(&parameter).unwrap(), Ordering::Equal);
    // For P=(t,t^3), 2t^3=1: X=11/2+2t, Z=8-t, so X+2Z=43/2.
    assert_eq!(
        point
            .compare_linear_form(&Vector3::new([1.into(), 0.into(), 2.into()]), &q(43, 2))
            .unwrap(),
        Ordering::Equal
    );
    assert_eq!(
        point
            .compare_linear_form(&Vector3::new([1.into(), (-1).into(), 1.into()]), &14.into())
            .unwrap(),
        Ordering::Equal
    );
    let native = Curve3::rational_bezier(
        [
            Point3::new(5.into(), (-2).into(), 7.into()),
            Point3::new(q(17, 3), q(-5, 3), q(20, 3)),
            Point3::new(q(19, 3), q(-4, 3), q(19, 3)),
            Point3::new(8.into(), 2.into(), 8.into()),
        ]
        .to_vec(),
        vec![Real::one(); 4],
    )
    .unwrap();
    assert!(
        point
            .coincides_with(&native.point_at(&root(1)).unwrap())
            .unwrap()
    );
    let lower = GeometricPoint3::from_coordinates(Point3::new(7.into(), 0.into(), 7.into()));
    let upper = GeometricPoint3::from_coordinates(Point3::new(q(29, 4), 1.into(), q(29, 4)));
    assert_eq!(
        point.compare_coordinate(&lower, Axis::X).unwrap(),
        Ordering::Greater
    );
    assert_eq!(
        point.compare_coordinate(&upper, Axis::X).unwrap(),
        Ordering::Less
    );
    point.bounds().unwrap();
    for (a, b) in [(0, 1), (1, 0), (-1, 2), (2, -1)] {
        let image = frame(parallel(a, b));
        let selected = image.point_at(&parameter).unwrap();
        assert!(selected.try_coordinates().is_none());
        assert_eq!(
            selected
                .compare_linear_form(&Vector3::new([1.into(), (-1).into(), 1.into()]), &14.into())
                .unwrap(),
            Ordering::Equal
        );
        selected.bounds().unwrap();
    }
}

pub fn selected_planar_points_replay_sources_and_affine_transforms() {
    let transform = Matrix4::from_row_major([
        (-2).into(),
        1.into(),
        0.into(),
        7.into(),
        0.into(),
        3.into(),
        1.into(),
        (-1).into(),
        0.into(),
        0.into(),
        2.into(),
        5.into(),
        0.into(),
        0.into(),
        0.into(),
        1.into(),
    ]);
    for source in [polynomial(), parallel(1, 0)] {
        let curve = frame(source);
        let point = curve.point_at(&root(1)).unwrap();
        for attached in [false, true] {
            let mut builder = ModelBuilder::new();
            builder.vertex(point.clone()).unwrap();
            if attached {
                builder.curve(curve.clone()).unwrap();
            }
            let model = builder.finish().unwrap();
            let cold = reload(&model);
            let restored = cold.vertices().next().unwrap().point();
            assert!(point.coincides_with(restored).unwrap());
            assert!(restored.try_coordinates().is_none());
            assert!(restored.curve_source().is_some());
            let mapped = point.transformed(&transform).unwrap();
            let transformed = reload(&cold.transformed(&transform).unwrap());
            assert!(
                mapped
                    .coincides_with(transformed.vertices().next().unwrap().point())
                    .unwrap()
            );
            mapped.bounds().unwrap();
        }
    }
}

fn check_cap(model: &Model) {
    let solid = model.solids().next().unwrap();
    for (point, expected) in [
        (
            Point3::new(2.into(), 0.into(), q(3, 2)),
            SolidPointLocation::Inside,
        ),
        (
            Point3::new(2.into(), 2.into(), q(3, 2)),
            SolidPointLocation::Boundary,
        ),
        (
            Point3::new(2.into(), 3.into(), q(3, 2)),
            SolidPointLocation::Outside,
        ),
    ] {
        assert_eq!(solid.classify_point(&point).unwrap(), expected);
    }
    for edge in model.edges() {
        assert_eq!(edge.uses().count(), 2);
    }
}

pub fn selected_parallel_edge_splits_replay_the_whole_cap() {
    let bodies =
        builder::extrude_curve_region(&prior::original_parallel_cap(), 0.into(), 3.into()).unwrap();
    let edge = bodies
        .model()
        .edges()
        .find(|e| e.curve().kind() == Curve3Kind::PlanarImage)
        .unwrap();
    let split = edge.split(root(1)).unwrap();
    assert!(split.details().vertex().point().try_coordinates().is_none());
    check_cap(split.model());
    let cold = reload(split.model());
    check_cap(&cold);
    let first = cold
        .edges()
        .find(|e| {
            e.curve().kind() == Curve3Kind::PlanarImage
                && e.domain().end().compare(&root(1)).unwrap() == Ordering::Equal
        })
        .unwrap();
    let second = first.split(root(2)).unwrap();
    check_cap(&reload(second.model()));
}
