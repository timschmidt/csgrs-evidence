#[path = "../../../../tests/support/selected_planar_images.rs"]
mod acceptance;
#[path = "../../../../../hypercurve/tests/support/point_affine_forms.rs"]
mod owner;
fn cases() -> [(&'static str, fn()); 14] {
    [
        ("selected_planar_points_keep_frame_and_source_correlation", acceptance::selected_planar_points_keep_frame_and_source_correlation),
        ("selected_planar_points_replay_sources_and_affine_transforms", acceptance::selected_planar_points_replay_sources_and_affine_transforms),
        ("selected_parallel_edge_splits_replay_the_whole_cap", acceptance::selected_parallel_edge_splits_replay_the_whole_cap),
        ("selected_parallel_splits_continue_through_boolean_sets", acceptance::selected_parallel_splits_continue_through_boolean_sets),
        ("selected_parallel_splits_transform_and_preserve_near_separation", acceptance::selected_parallel_splits_transform_and_preserve_near_separation),
        ("selected_planar_archives_reject_forged_sources_and_recover", acceptance::selected_planar_archives_reject_forged_sources_and_recover),
        ("selected_planar_policies_and_work_exhaustion_recover", acceptance::selected_planar_policies_and_work_exhaustion_recover),
        ("selected_planar_poles_remain_typed_failures", acceptance::selected_planar_poles_remain_typed_failures),
        ("authored_and_constant_forms_preserve_exact_values", owner::authored_and_constant_forms_preserve_exact_values),
        ("selected_forms_preserve_root_correlation_and_cancellation", owner::selected_forms_preserve_root_correlation_and_cancellation),
        ("selected_form_bounds_and_policy_reuse_keep_exact_meaning", owner::selected_form_bounds_and_policy_reuse_keep_exact_meaning),
        ("analytic_form_incidence_preserves_the_positive_normal_sheet", owner::analytic_form_incidence_preserves_the_positive_normal_sheet),
        ("symbolic_forms_keep_correlated_coefficients", owner::symbolic_forms_keep_correlated_coefficients),
        ("parallel_injectivity_requires_the_consumed_range", owner::parallel_injectivity_requires_the_consumed_range),
    ]
}
