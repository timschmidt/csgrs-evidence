use hyperbrep::{builder, ArchiveLimits, RawModel};
use hypercurve::{Curve2, CurvePath2, CurveRegion2, FillRule, LineSeg2, Point2, Real, RationalBezier2};
fn p(x:i32,y:i32)->Point2 { Point2::from_values(x,y) }
fn main() {
    let curve:Curve2=RationalBezier2::try_new(vec![p(0,0),p(1,-1),p(3,-1),p(4,0)],vec![1.into(),2.into(),3.into(),1.into()]).unwrap().into();
    let path=CurvePath2::try_new(vec![curve,
        LineSeg2::try_new(p(4,0),p(4,2)).unwrap().into(),
        LineSeg2::try_new(p(4,2),p(0,2)).unwrap().into(),
        LineSeg2::try_new(p(0,2),p(0,0)).unwrap().into(),
    ]).unwrap();
    println!("path area={:?}",path.boundary_loop().unwrap().signed_area());
    let region=CurveRegion2::try_from_boundary_paths(&[path],FillRule::EvenOdd).unwrap();
    println!("region area={:?}",region.signed_area());
    let body=builder::extrude_curve_region(&region,Real::zero(),Real::from(3));
    println!("extrusion={:?}",body.as_ref().map(|m|m.model().counts()));
    if let Ok(body)=body {
        println!("volume={:?}",body.model().solids().next().unwrap().volume());
        let archive=body.model().to_json().unwrap();
        println!("replay={:?}",RawModel::from_json(&archive,&ArchiveLimits::default()).unwrap().validate().map(|m|m.counts()));
    }
}
