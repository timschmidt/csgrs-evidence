#[path = "support/measurement_admission.rs"]
mod acceptance;

#[test]
fn rational_prism_validity_does_not_require_a_closed_form_measurement() {
    acceptance::rational_prism_validity_does_not_require_a_closed_form_measurement();
}
