"""Independent floating-point reader for native exact analytic exports.

OCP is optional test tooling, never the production or exact geometry authority.
The earlier step-faceted fetch_oracles.py pins the installed wheel and hashes.
"""
import hashlib
import json
import math
from pathlib import Path
import sys
sys.path.insert(0, '/tmp/hyperbrep-occt-oracle')
import OCP
from OCP.STEPControl import STEPControl_Reader
from OCP.IFSelect import IFSelect_RetDone
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.TopExp import TopExp
from OCP.TopTools import TopTools_IndexedMapOfShape
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_EDGE, TopAbs_VERTEX

out=Path(__file__).resolve().parents[1]
root=out.parents[4]
results=[]
for name,counts,volume,area in [
    ('native-cylinder',[1,6,12,8],175*math.pi*1e9,120*math.pi*1e6),
    ('closed-cylinder',[1,3,3,2],175*math.pi*1e9,120*math.pi*1e6),
    ('supplied-cylinder',[1,3,3,2],175*math.pi*1e9,120*math.pi*1e6),
    ('split-reflected-cylinder',[1,3,4,3],175*math.pi*1e9,120*math.pi*1e6),
    ('oblique-cylinder',[1,3,3,2],175*math.pi*1e9,120*math.pi*1e6),
    ('radical-cylinder',[1,3,3,2],175*math.sqrt(2)*math.pi*1e9,(50+70*math.sqrt(2))*math.pi*1e6),
    ('planar-hole',[1,10,24,16],20,66),
    ('scaled-mm-positive',[1,6,12,8],175*math.pi,120*math.pi),
    ('scaled-mm-reflected',[1,6,12,8],175*math.pi,120*math.pi),
    ('scaled-inch-positive',[1,6,12,8],175*math.pi*25.4**3,120*math.pi*25.4**2),
    ('scaled-inch-reflected',[1,6,12,8],175*math.pi*25.4**3,120*math.pi*25.4**2),
]:
    path=out/('scaled-exports' if name.startswith('scaled-') else 'exports')/f'{name}.step'
    reader=STEPControl_Reader()
    assert reader.ReadFile(str(path))==IFSelect_RetDone,name
    assert reader.NbRootsForTransfer()==1,name
    assert reader.TransferRoots()==1,name
    shape=reader.OneShape()
    assert BRepCheck_Analyzer(shape).IsValid(),name
    observed=[]
    for kind in [TopAbs_SOLID,TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX]:
        items=TopTools_IndexedMapOfShape();TopExp.MapShapes_s(shape,kind,items)
        observed.append(items.Extent())
    assert observed==counts,(name,observed,counts)
    mass,surface=GProp_GProps(),GProp_GProps()
    BRepGProp.VolumeProperties_s(shape,mass)
    BRepGProp.SurfaceProperties_s(shape,surface)
    assert math.isclose(mass.Mass(),volume,rel_tol=1e-12),(name,mass.Mass(),volume)
    assert math.isclose(surface.Mass(),area,rel_tol=1e-12),(name,surface.Mass(),area)
    results.append(dict(name=name,path=str(path.relative_to(root)),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size,
        roots=1,transferred=1,valid=True,solids=counts[0],faces=counts[1],edges=counts[2],vertices=counts[3],
        volume_default_mm3=mass.Mass(),expected_mm3=volume,area_default_mm2=surface.Mass(),expected_mm2=area))
print(json.dumps(dict(ocp_version=OCP.__version__,python=sys.version,fixtures=results,
    scope='Floating-point interoperability of eleven complete exact analytic/planar exports, including partial circles, shared seams, split/reflection, radical frame, through-hole and native millimetre/inch similarities. Not an exactness or full EXPRESS/AP proof.'),indent=2))
