use hyperbrep::*;
use hypercurve::{Curve2, CurvePath2, CurveRegion2, FillRule, LineSeg2, RationalBezier2};

fn p(x: i32, y: i32) -> hypercurve::Point2 {
    hypercurve::Point2::from_values(x, y)
}

fn profile() -> CurveRegion2 {
    let curve = RationalBezier2::try_new(
        vec![p(0, 0), p(1, -1), p(2, -1), p(3, -1), p(4, -1), p(5, 0)],
        vec![1.into(), 2.into(), 3.into(), 4.into(), 5.into(), 1.into()],
    )
    .unwrap();
    let path = CurvePath2::try_new(vec![
        curve.into(),
        Curve2::from(LineSeg2::try_new(p(5, 0), p(5, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(5, 2), p(0, 2)).unwrap()),
        Curve2::from(LineSeg2::try_new(p(0, 2), p(0, 0)).unwrap()),
    ])
    .unwrap();
    assert!(path.boundary_loop().unwrap().signed_area().unwrap().is_none());
    CurveRegion2::try_from_boundary_paths(&[path], FillRule::EvenOdd).unwrap()
}

pub fn rational_prism_validity_does_not_require_a_closed_form_measurement() {
    let region = profile();
    assert!(region.signed_area().unwrap().is_none());
    let bodies = builder::extrude_curve_region(&region, 0.into(), 3.into()).unwrap();
    assert_eq!(bodies.len(), 1);
    let model = bodies.model();
    for model in [
        model.clone(),
        RawModel::from_json(&model.to_json().unwrap(), &ArchiveLimits::default())
            .unwrap()
            .validate()
            .unwrap(),
    ] {
        let solid = model.solids().next().unwrap();
        assert_eq!(
            solid.volume(),
            Err(QueryError::Geometry(GeometryError::UnsupportedMeasurement))
        );
        for (x, y, expected) in [
            (2, 1, SolidPointLocation::Inside),
            (2, 2, SolidPointLocation::Boundary),
            (2, 3, SolidPointLocation::Outside),
        ] {
            assert_eq!(
                solid
                    .classify_point(&Point3::new(x.into(), y.into(), 1.into()))
                    .unwrap(),
                expected
            );
        }
    }
}
