use hyperbrep::*;
use hypercurve::{
    Curve2, CurveFamily2, CurvePath2, CurveRegion2, FillRule, LineSeg2, Point2 as CurvePoint2,
    QuadraticBezier2,
};

fn q(n: i32, d: i32) -> Real {
    (Real::from(n) / Real::from(d)).unwrap()
}

fn p(x: i32, y: i32) -> CurvePoint2 {
    CurvePoint2::from_values(x, y)
}

fn equal(actual: Real, expected: Real) {
    assert!(
        (actual - expected)
            .exact_rational_normal_form()
            .unwrap()
            .is_zero()
    );
}

fn parabola(offset: i32, reverse: bool) -> CurvePath2 {
    // x = -2 + 4t + offset, y = 4 - 16t + 16t²: y = (x-offset)².
    let path = CurvePath2::try_new(vec![
        QuadraticBezier2::new(p(offset - 2, 4), p(offset, -4), p(offset + 2, 4)).into(),
        LineSeg2::try_new(p(offset + 2, 4), p(offset - 2, 4))
            .unwrap()
            .into(),
    ])
    .unwrap();
    if reverse {
        path.reversed().unwrap()
    } else {
        path
    }
}

fn hole(reverse: bool) -> CurvePath2 {
    let points = [
        CurvePoint2::new(q(-1, 2), 1.into()),
        CurvePoint2::new(q(1, 2), 1.into()),
        CurvePoint2::new(q(1, 2), 2.into()),
        CurvePoint2::new(q(-1, 2), 2.into()),
    ];
    let path = CurvePath2::try_new(
        (0..4)
            .map(|i| {
                Curve2::from(
                    LineSeg2::try_new(points[i].clone(), points[(i + 1) % 4].clone()).unwrap(),
                )
            })
            .collect(),
    )
    .unwrap();
    if reverse {
        path.reversed().unwrap()
    } else {
        path
    }
}

fn profile(reverse: bool, components: bool, affine: bool) -> CurveRegion2 {
    let mut paths = vec![parabola(0, reverse)];
    if components {
        paths.extend([hole(reverse), parabola(8, reverse)]);
    }
    let region = CurveRegion2::try_from_boundary_paths(&paths, FillRule::EvenOdd).unwrap();
    assert!(region.boundary_loops().iter().any(|boundary| {
        boundary
            .curves()
            .iter()
            .any(|curve| curve.family() == CurveFamily2::Line && curve.geometry().is_none())
    }));
    if affine {
        region
            .transform_affine(
                &(-2).into(),
                &0.into(),
                &0.into(),
                &3.into(),
                &7.into(),
                &(-1).into(),
            )
            .unwrap()
    } else {
        region
    }
}

fn replay(model: &Model) -> Model {
    let text = model.to_json().unwrap();
    let cold = RawModel::from_json(&text, &ArchiveLimits::default())
        .unwrap()
        .validate()
        .unwrap();
    assert_eq!(cold.to_json().unwrap(), text);
    cold
}

fn verify(model: &Model, components: bool, affine: bool) {
    let scale = if affine { 6 } else { 1 };
    equal(
        model.solids().map(|solid| solid.volume().unwrap()).sum(),
        ((if components { 61 } else { 32 }) * scale).into(),
    );
    assert_eq!(model.solids().count(), if components { 2 } else { 1 });
    for edge in model.edges() {
        let uses = edge.uses().collect::<Vec<_>>();
        assert_eq!(uses.len(), 2);
        assert_ne!(uses[0].direction(), uses[1].direction());
    }
    let gap: Real = "1e-12".parse().unwrap();
    let mut cases = vec![
        (1.into(), 2.into(), SolidPointLocation::Inside),
        (1.into(), 1.into(), SolidPointLocation::Boundary),
        (1.into(), Real::one() + &gap, SolidPointLocation::Inside),
        (1.into(), Real::one() - &gap, SolidPointLocation::Outside),
        (0.into(), 4.into(), SolidPointLocation::Boundary),
        (0.into(), Real::from(4) - &gap, SolidPointLocation::Inside),
        (0.into(), Real::from(4) + &gap, SolidPointLocation::Outside),
        (4.into(), 2.into(), SolidPointLocation::Outside),
    ];
    if components {
        cases.extend([
            (0.into(), q(3, 2), SolidPointLocation::Outside),
            (q(1, 2), q(3, 2), SolidPointLocation::Boundary),
            (q(1, 2) + &gap, q(3, 2), SolidPointLocation::Inside),
            (q(1, 2) - &gap, q(3, 2), SolidPointLocation::Outside),
            (8.into(), 2.into(), SolidPointLocation::Inside),
        ]);
    }
    for (x, y, expected) in cases {
        let (x, y) = if affine {
            (
                Real::from(-2) * x + Real::from(7),
                Real::from(3) * y - Real::one(),
            )
        } else {
            (x, y)
        };
        let point = Point3::new(x, y, q(3, 2));
        let mut location = SolidPointLocation::Outside;
        for solid in model.solids() {
            match solid.classify_point(&point).unwrap() {
                SolidPointLocation::Inside => {
                    location = SolidPointLocation::Inside;
                    break;
                }
                SolidPointLocation::Boundary => location = SolidPointLocation::Boundary,
                SolidPointLocation::Outside => {}
            }
        }
        assert_eq!(location, expected, "{point:?}");
    }
}

use hyperbrep_io::step::*;

#[test]
fn retained_spline_profiles_complete_step_replay_and_repeated_cuts() {
    let context = OperationContext::strict(WorkBudget {
        refinements: 100_000,
        promotions: 10_000,
    });
    for reverse in [false, true] {
        for components in [false, true] {
            for affine in [false, true] {
                let region = profile(reverse, components, affine);
                let original = builder::extrude_curve_region(&region, 0.into(), 3.into()).unwrap();
                let bodies: Vec<_> = original
                    .bodies()
                    .map(|solid| StepBody {
                        solid,
                        name: "retained spline",
                    })
                    .collect();
                let options = StepWriteOptions::new("spline.step", "2026-10-18T00:00:00");
                let output = write_advanced(&bodies, &options, &context)
                    .result
                    .unwrap()
                    .unwrap();
                assert_eq!(
                    output.text(),
                    write_advanced(&bodies, &options, &context)
                        .result
                        .unwrap()
                        .unwrap()
                        .text()
                );
                let file =
                    StepFile::read(output.text().as_bytes(), &StepReadOptions::default()).unwrap();
                let imported = file
                    .import_representation(
                        output.representation(),
                        &ImportLimits::default(),
                        &context,
                    )
                    .result
                    .unwrap()
                    .unwrap();
                let mut joined = BodySet::empty();
                for imported in imported.bodies() {
                    let cold = replay(imported.model());
                    joined = boolean::union(
                        &joined,
                        &BodySet::from_solid(cold.solids().next().unwrap()),
                    )
                    .unwrap();
                }
                verify(joined.model(), components, affine);
                verify(&replay(joined.model()), components, affine);
                let cutter = builder::extrude_curve_region(&region, 1.into(), 2.into()).unwrap();
                let middle = boolean::intersection(&joined, &cutter).unwrap();
                let removed = boolean::difference(&joined, &cutter).unwrap();
                let volume =
                    Real::from((if components { 61 } else { 32 }) * if affine { 6 } else { 1 });
                equal(
                    middle.bodies().map(|s| s.volume().unwrap()).sum(),
                    (&volume / Real::from(3)).unwrap(),
                );
                equal(
                    removed.bodies().map(|s| s.volume().unwrap()).sum(),
                    (&volume * Real::from(2) / Real::from(3)).unwrap(),
                );
                let restored = boolean::union(&removed, &middle).unwrap();
                verify(restored.model(), components, affine);
                verify(&replay(restored.model()), components, affine);
                assert!(boolean::difference(&restored, &joined).unwrap().is_empty());
                assert!(boolean::difference(&joined, &restored).unwrap().is_empty());
            }
        }
    }
}
