use hyperbrep::*;
use hypercurve::{CurveParameterRange2,PolynomialCurveSet2,Similarity2};
use hypersolve::bivariate_topology::*;
fn q(n:i32,d:i32)->Real {(Real::from(n)/Real::from(d)).unwrap()}
fn curves()->PolynomialCurveSet2 {
 let topology=decompose_bivariate_curve(&hypersolve::BivariatePolynomial::new(vec![vec![q(7,16),(-1).into(),1.into()],vec![(-1).into()],vec![1.into()]]),&BivariateCurveDomain{first:[0.into(),1.into()],second:[0.into(),1.into()]},BivariateTopologyConfig{max_refinement_rounds:97,..Default::default()}).unwrap();
 PolynomialCurveSet2::from_topology(topology,hypersolve::AlgebraicFiberRootIsolationConfig{max_subdivision_depth:93,refinement_steps:9}).unwrap()
}
fn main() {
 let set=curves();
 if std::env::args().nth(1).as_deref()==Some("bounds") {
  let curve=set.curves()[0].restrict_source(CurveParameterRange2::try_new(q(3,8).into(),q(5,8).into()).unwrap()).unwrap();
  println!("restricted polynomial bounds: {:?}",curve.bounds());
  curve.bounds().expect("a subset must retain its source conservative bounds");return;
 }
 let map=Similarity2::try_from_real_affine(3.into(),(-4).into(),4.into(),3.into(),2.into(),(-1).into()).unwrap();
 let mut failure=false;
 for (side,source) in set.curves().iter().enumerate() {
  let (left,right)=source.split_at(q(1,2).into()).unwrap();
  for (part,curve) in [source.clone(),source.reversed().unwrap(),left,right].into_iter().enumerate() {
   let curve=curve.transform_similarity(&map).unwrap();let point=curve.point_at(&q(1,2).into()).unwrap();
   let expected:hypercurve::CurvePoint2=map.transform_point(&hypercurve::Point2::new(q(1,2),if side==0 {q(1,4)} else {q(3,4)})).into();
   let equality=point.coincides_with(&expected);
   println!("side={side} part={part} equality={equality:?} x={:?} y={:?}",point.compare_coordinate(&expected,hypercurve::Axis2::X),point.compare_coordinate(&expected,hypercurve::Axis2::Y));
   failure |= equality!=Ok(true);
  }
 }
 assert!(!failure,"every complete transformed restriction must retain exact endpoint equality");
}
