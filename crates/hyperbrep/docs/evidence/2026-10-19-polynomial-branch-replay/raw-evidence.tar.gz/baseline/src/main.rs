use hyperbrep::*;
use hypersolve::bivariate_topology::*;
fn q(n:i32,d:i32)->Real {(Real::from(n)/Real::from(d)).unwrap()}
fn main() {
 let topology=decompose_bivariate_curve(&hypersolve::BivariatePolynomial::new(vec![vec![q(7,16),(-1).into(),1.into()],vec![(-1).into()],vec![1.into()]]),&BivariateCurveDomain{first:[0.into(),1.into()],second:[0.into(),1.into()]},BivariateTopologyConfig::default()).unwrap();
 let set=hypercurve::PolynomialCurveSet2::from_topology(topology,Default::default()).unwrap();
 let mut builder=ModelBuilder::new();
 for source in set.curves() {
  let curve=Curve3::planar_image(source.clone(),Point3::origin(),Vector3::x(),Vector3::y()).unwrap();
  let a=builder.vertex(curve.point_at(curve.domain().start()).unwrap()).unwrap();
  let b=builder.vertex(curve.point_at(curve.domain().end()).unwrap()).unwrap();
  let domain=curve.domain().clone();let c=builder.curve(curve).unwrap();builder.edge(&a,&b,&c,domain).unwrap();
 }
 let model=builder.finish().unwrap();
 let archive=model.to_json().expect("whole branches must remain replayable after exact planar lift");
 let replay=RawModel::from_json(&archive,&ArchiveLimits::default()).unwrap().validate().unwrap();
 assert_eq!(replay.to_json().unwrap(),archive);
}
