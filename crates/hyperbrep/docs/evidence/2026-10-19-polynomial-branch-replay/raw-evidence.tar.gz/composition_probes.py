import run
for mode in ['circle','bounds']:
 run.run(dict(label='baseline-composition-'+mode,command=['cargo','run','--offline','--release','--manifest-path',str(run.OUT/'composition-blockers/Cargo.toml'),'--',mode],seconds=1200))
