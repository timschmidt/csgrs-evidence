import run
O=run.OUT
assert not any(k.startswith('HYPERBREP_') and 'ARTIFACT' in k for k in run.ENV)
(O/'costs').mkdir(exist_ok=True)
for repeat in range(3):
 for family in ['preserved','prior','surface']:
  for side in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
   name=family+'-'+side;label='cost-'+name+'-'+str(repeat)
   assert run.run(dict(label=label,source_scope='main baseline 74684ebae44a11a318865e921c2df712b44234bc' if side=='baseline' else 'qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','0',str(O/'bin'/name),'measure'],seconds=2400))==0
 label='cost-new-'+str(repeat)
 assert run.run(dict(label=label,source_scope='qualified candidate',command=['python3','-B',str(O/'measure.py'),str(O/'costs'/(label+'.json')),'taskset','-c','0',str(O/'bin/new'),'measure'],seconds=2400))==0
