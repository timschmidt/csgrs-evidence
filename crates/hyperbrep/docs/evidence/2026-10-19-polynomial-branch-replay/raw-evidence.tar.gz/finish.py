"""Record one qualified increment, preserving every other root-ledger byte."""
from pathlib import Path
import copy,hashlib,json,shutil,subprocess,tarfile
import run
R=run.ROOT;O=run.OUT;NAME='2026-10-19-polynomial-branch-replay'
D=R/'crates/hyperbrep/docs/evidence'/NAME
assert not D.exists(), 'Do not rerun after evidence has been copied'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
verification=json.loads((O/'verification.json').read_text())
source=json.loads((O/'candidate-source.json').read_text())
assert all(sha(R/p)==h for p,h in source['files'].items())
tests=json.loads((O/'test-summary.json').read_text());full=tests['final-brep-release-tests']
cost=json.loads((O/'cost-analysis.json').read_text());art=json.loads((O/'archive-comparison.json').read_text());sizes=json.loads((O/'binary-sizes.json').read_text())
ratios=[r['latency_ratio'] for r in cost['phase_medians']]
q=(f"All-feature release BRep/IO suites pass {full['passed']} tests in {full['batches']} batches, with no failures or ignored tests. Focused solver topology and curve polynomial/rational/selected-field/work-budget regressions pass; the eight polynomial owner groups also pass in debug mode. All-target/all-feature Clippy for the four affected crates, warning-denied rustdoc, BRep fuzz-target compilation and formatting pass. Five shared complete public recipes pass natively and as five actual zero-import Wasmtime exports. They cover both full circle branches, selected cubic restrictions, splits/reversals/similarities, affine spatial lifts, repeated cold replay, singular incidence, algebraic events, disconnected components, exact 1e-12 loops, independent coordinate/field/plane identities, subsequent translation sweeps, malformed sources/selectors/ranges/controls and predecode limits, strict/approximate/strict and budget refusal/recovery. "
 f"All {art['preserved_files']} previous archive payloads match after only the declared version-13 migration; {art['new_files']} new archive records retain {art['new_unique_payloads']} distinct payloads. Exact geometry, required model validation and deterministic bytes are checked separately. The original whole-branch export and two owner-composition probes fail on baseline and pass on candidate. The unchanged complete interior-loop surface-section success assertion still fails with UnsupportedIntersection on both revisions.")
growth={family:sizes[family+'-candidate']['bytes']-sizes[family+'-baseline']['bytes'] for family in ['preserved','prior','surface']}
adverse={(r['case'],r['phase']):r['latency_ratio'] for r in cost['phase_medians']}
p=(f"Three alternating CPU-0 pinned process pairs retain all twenty previously successful workflows (six modeling/branch, four plane/pcurve and ten rational-surface/affine recipes), with first and three repeated fresh-input calls. Three absolute processes run all five new branch-replay groups. All assertions, materialization, required validation and replay remain inside measured calls. The forty median paired latency ratios range {min(ratios):.6f} to {max(ratios):.6f}; {cost['increased_allocation_rows']} of 120 paired rows increase counted Rust allocation calls and {cost['increased_byte_rows']} increase requested bytes. The six affected workflows add 1–12 Rust allocation calls and 18–216 requested bytes per complete invocation; the other fourteen retain identical counters. Adverse profile_families first/repeated ratios are {adverse['profile_families','first_fresh_input']:.6f}/{adverse['profile_families','repeated_fresh_input']:.6f}, and polynomial_branches ratios are {adverse['polynomial_branches','first_fresh_input']:.6f}/{adverse['polynomial_branches','repeated_fresh_input']:.6f}. Maximum observed process RSS is {cost['maximum_rss_kib']} KiB. Matched executable byte changes are {growth}. All adverse rows, native/WASM sizes and hashes are retained. Shared-host timings establish no speedup; Rust requested allocation traffic is not live heap and excludes foreign allocator internals. New successful branch replay has no prior successful timing baseline. Source controls add retained configuration storage; reconstructed polynomial sources are shared per archive definition.")
limits=("Whole polynomial branch replay does not complete general surface sections, dual-surface correspondence, derivative/image proofs or trim arrangements. The original interior-loop target remains open. Selected angular surfaces, general retained procedural extrusion profiles and the prior native-conic affine cold-replay blocker remain separate limitations. Archive 13 rejects formats through 12 without a compatibility decoder. The new solver_steps admission limit bounds each declared refinement/depth control individually; it does not sum solver work or bound heap, stack or cancellation. Existing total-resource gaps remain disclosed with external time containment. Source-path native/WASM projects do not establish installed distributions or production bindings. Runtime fuzz/ASan/lexicase, formal proofs, measured coverage, MSRV, full release/workflow and push gates remain unqualified. All 28 work packages remain open/in-progress. The eaa0cae54 push exception is consumed; this increment is not pushed.")
report=dict(increment='polynomial-branch-replay-2026-10-19',baseline=source['baseline'],complete=False,retained=True,qualification=q,cost_evidence=p,limits=limits,archive_version=13,source_files=len(source['files']))
write(O/'report.json',report)
write(O/'ideas.json',[
 dict(idea='Shared polynomial source definitions with complete graph reconstruction',status='kept',evidence='Original whole-branch export now completes. Shared native/WASM recipes check branches, selected restrictions, source identity, transformations, topology and cold deterministic replay.'),
 dict(idea='Preserve construction and evaluation controls separately',status='kept',evidence='Hypersolve retains the decomposition config; Hypercurve exposes evaluation config. Archive metadata admits individual declared controls before scalar decode. Zero evaluation controls remain exhausted after replay; ordinary recovery succeeds.'),
 dict(idea='Use native polynomial restriction authority',status='kept',evidence='Baseline public source restriction loses bounds and reaches a native-only path. Candidate retains the polynomial branch, original chart, selected parameters, traversal and conservative bounds; debug and full downstream tests pass.'),
 dict(idea='Compare polynomial similarity coordinates in their retained joint field',status='kept',evidence='The unchanged baseline upper-circle fixture is undecided. Candidate resolves both branches, both operand orders, split/reverse endpoints and independent 1e-12 near-distinct controls without interval midpoint substitution.'),
 dict(idea='Serialize trusted events or independent scalar roots',status='architecture-inapplicable',evidence='The archive reconstructs source topology and checks selectors; precomputed connectivity and certainty fields are rejected. Independent scalar reconstruction would discard the joint source authority.'),
 dict(idea='Complete surface sections using archive closure alone',status='rejected',evidence='The original complete interior-loop target still returns UnsupportedIntersection on both revisions. Archive completion is a necessary composition dependency, not proof of section or trim-arrangement completion.'),
])
(O/'next-domains.md').write_text('''# Next implementation domains

Continue WP05a/WP05b/WP06 with complete selected surface-section carriers and both source charts. Whole polynomial branch persistence now reconstructs source graphs and preserves selectors, restrictions and images. Reuse the native branch/source and rational surface-point authority to derive a spatial branch and its second pcurve, without independent coordinate reconstruction or sampled topology. Prove complete domain images, event incidence and regular derivative/image queries before publishing a full section or feeding trim arrangements.

The current public blocker is `geometry.rs::intersect_plane_rational_bezier_surface`: after the supported linear-axis cases it falls through to the 2×2-only bilinear path. Derive the exact homogeneous plane pullback using Hypersolve's existing basis operations, decompose the complete parameter rectangle and account for every branch and isolated event. Construct the spatial curve and both `SurfaceIntersectionPcurve` images with the same source chart. General rational planar images belong in Hypercurve; spatial section ownership belongs in HyperBRep. Extend `geometry/pcurve.rs` queries and `topology/validation/tensor.rs` source-image agreement together with any new carrier, and require transform/restriction/replay before admitting it as complete. Vertical/repeated components and coincident patches need their existing typed distinctions until independently implemented; do not drop them from a purported complete result.

A regular UV branch can acquire singularities or self-intersections under a surface map. The next implementation must prove injectivity on its admitted domain or add image events before treating the UV graph as spatial topology. This requirement follows from the [surface-intersection topology study](https://arxiv.org/html/1203.0442#S4), not from the archive tests.

Keep the unchanged complete interior-loop assertion in `interior/src/main.rs`: baseline and candidate still return UnsupportedIntersection. Retain both original owner-composition probes alongside the complete circle/cubic replay fixtures. Preserve disconnected, singular, tiny and selected cases, source-sharing and resource controls, all existing exact workflows, every archive migration and every adverse cost sample.

Keep the rejected native-conic affine model fallback and its cold-replay failure separate. Broader angular/procedural surface evaluation, complete arrangements, installed distributions, bindings, MSRV, total-resource bounds, directed fuzz/ASan/lexicase, measured coverage/formal proofs and the full repository push matrix remain open. Respect concurrently developed upstream ownership; check updates at coherent checkpoints and freeze source during qualification.
''')
(O/'implementation-notes.md').write_text('''# Ownership and replay

Hypersolve retains the original `BivariateTopologyConfig` with each complete topology. Hypercurve exposes that source, its separate evaluation controls and branch traversal. Public polynomial restrictions use the existing checked branch restriction instead of the authored native-curve path. Similarity point coordinates pull their affine query into the original polynomial field; equality aggregates the existing coordinate evidence, including definitive separation in either axis.

HyperBRep owns `persistence/polynomial.rs`: untrusted source and branch records, deterministic source interning and checked replay. Source records have exact coefficients/domain and both control sets; branches have source/slab/root/range, traversal and an optional similarity. Decoder source tables reconstruct complete solver graphs before selected parameters and dependent curve sources. No trusted connectivity or proof bits are serialized. The new required collection is a deliberate archive-13 break, not an optional old-reader adapter.

Projection-slab and root ordering are part of the archive selector semantics. Future solver changes to event partitions or ordering must requalify saved branch selection against preserved semantic fixtures and declare a format migration if its meaning changes. A successful parse alone cannot establish that an old ordinal still selects the same branch.

The CGAL algebraic arrangement documentation retains the supporting curve and branch ordinal for algebraic segments and points. This supports the representation strategy, not a correctness or performance claim about this implementation. See `research.json` for the official primary-source links and the distinction between observation and inference. No external production kernel is introduced.
''')
(O/'README.md').write_text('# Whole polynomial branch replay\n\n'+q+'\n\n'+p+'\n\n'+limits+'''

`contract.md` records the pre-implementation domain, owners and properties. `candidate-source.json`, `verification.json`, `test-summary.json`, `archive-comparison.json`, `cost-analysis.json` and `binary-sizes.json` separate correctness, deterministic serialization and costs. `ideas.json` records retained and rejected approaches; `next-domains.md` preserves the full unfinished section target.

`raw-evidence.tar.gz` retains every command/log/source patch, early compiler and composition failures, original full fixtures, external consumer manifests and locks, archive outputs and raw cost/RSS samples. Executables and caches are excluded. Baseline probes link the clean main checkout; candidate probes link the isolated development checkout. Paths must be adjusted for reproduction in a new output directory. Never rerun the snapshot runner after copying its evidence into the repository.

The initial test compile rejected an integer-to-parameter shorthand; it was replaced by the ordinary exact Real constructor. A later debug owner-test compile required an explicit array element type. The next full branch tests exposed restricted polynomial bounds and transformed upper-circle equality failures. Both were independently reproduced before changing Hypercurve; the full original workflows and strict assertions remain. The final checks qualify these owner fixes and the archive extension together.
''')
sp=R/'crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json';status=json.loads(sp.read_text());before=copy.deepcopy(status)
status['increments'].append(dict(id=report['increment'],work_packages=['WP02','WP05a','WP05b','WP06','WP13','WP21'],properties=['P1','P4','P5','P8','P9','P15','P17','P18','P19','P20','P25','P26','P27','P35','P36','P37','P39'],change='Retain shared exact polynomial source graphs, selected branches and their images through archive 13; preserve public polynomial restrictions and exact similarity-coordinate comparisons in Hypercurve.',sources=['../src/persistence/polynomial.rs','../src/persistence/selection.rs','../src/persistence/admission/shapes.rs','../../hypersolve/src/bivariate_topology.rs','../../hypercurve/src/polynomial_curve.rs','../../hypercurve/src/curve_subdivision.rs','../../hypercurve/src/bezier_offset.rs','../../hypercurve/src/curve_point.rs','../tests/support/polynomial_replay.rs'],evidence='evidence/'+NAME+'/manifest.json',validation=q,cost_evidence=p,limits=limits))
status['next_actions'].insert(0,'Continue WP05a/WP05b/WP06 from evidence/'+NAME+'/next-domains.md. Whole polynomial branches now replay with shared source graphs and original controls. Complete dual-chart surface sections, domain-image/derivative evidence and event incidence before arrangements; preserve the unchanged complete interior-loop success target and every existing full fixture.')
assert status['increments'][:-1]==before['increments'] and status['work_packages']==before['work_packages'] and not status['complete'];write(sp,status)
lp=R/'docs/properties-status.json';text=lp.read_bytes().decode('utf-8');ledger=json.loads(text);entry=ledger['current_work']['hyperbrep']
evidence='crates/hyperbrep/docs/evidence/'+NAME
entry.update(latest_implementation=report['increment'],latest_feature_evidence=evidence+'/manifest.json',latest_evidence=evidence+'/manifest.json',qualification=q,performance_evidence=p,limits=limits,latest_update_check=evidence+'/upstream-check.json')
decoder=json.JSONDecoder()
def ws(s,p):
 while s[p].isspace():p+=1
 return p
def member(s,p,key):
 p=ws(s,p);assert s[p]=='{';p=ws(s,p+1)
 while s[p]!='}':
  name,p=decoder.raw_decode(s,p);p=ws(s,p);assert s[p]==':';a=ws(s,p+1);_,b=decoder.raw_decode(s,a)
  if name==key:return a,b
  p=ws(s,b)
  if s[p]==',':p=ws(s,p+1)
 raise KeyError(key)
a,_=member(text,0,'current_work');a,b=member(text,a,'hyperbrep')
line=text[text.rfind('\n',0,a)+1:a];indent=len(line)-len(line.lstrip());second=text[a:b].splitlines()[1];width=len(second)-len(second.lstrip())-indent
replacement=json.dumps(entry,indent=width,ensure_ascii=False).replace('\n','\n'+' '*indent)
updated=text[:a]+replacement+text[b:];assert json.loads(updated)==ledger;lp.write_text(updated)
write(O/'ledger-scope.json',dict(owner='current_work.hyperbrep',outside_bytes_preserved=True,prefix_sha256=hashlib.sha256(text[:a].encode()).hexdigest(),suffix_sha256=hashlib.sha256(text[b:].encode()).hexdigest()))
post=[]
for name,command in [('fmt',['cargo','fmt','--all','--','--check']),('fuzz-fmt',['cargo','fmt','--manifest-path','crates/hyperbrep/fuzz/Cargo.toml','--','--check']),('diff',['git','diff','--check'])]:
 result=subprocess.run(command,cwd=R,env=run.ENV,capture_output=True,text=True);(O/('post-doc-'+name+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0,(name,result.stdout,result.stderr);post.append(dict(name=name,command=command,exit_code=0))
assert all(sha(R/p)==h for p,h in source['files'].items());write(O/'post-documentation-checks.json',dict(checks=post,qualified_source_unchanged=True))
D.mkdir()
for name in ['README.md','contract.md','next-domains.md','report.json','ideas.json','candidate-source.json','baseline-source.json','verification.json','test-summary.json','archive-comparison.json','cost-analysis.json','binary-sizes.json','environment.json','upstream-check.json','consumer-source-scope.json','fixture-migration.json','source-migration-audit.json','ledger-scope.json','post-documentation-checks.json','implementation-notes.md','research.json']:
 shutil.copy(O/name,D/name)
with tarfile.open(D/'raw-evidence.tar.gz','w:gz') as tar:
 for p in sorted(O.rglob('*')):
  if p.is_file() and not p.is_symlink() and (p.suffix in {'.json','.log','.patch','.py','.rs','.toml','.md'} or p.name=='Cargo.lock'):
   tar.add(p,arcname=str(p.relative_to(O)),recursive=False)
write(D/'manifest.json',dict(increment=report['increment'],baseline=source['baseline'],source_files=len(source['files']),complete=False,retained=True,no_push=True,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(D.iterdir()) if p.is_file()}))
print(json.dumps(dict(evidence=str(D),increment_count=len(status['increments']),qualification=q,cost_evidence=report['cost_evidence']),indent=2))
