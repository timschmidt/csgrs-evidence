from pathlib import Path
import run,shutil
O=run.OUT
(O/'bin').mkdir(exist_ok=True)
for side in ['baseline','candidate']:
 for family in ['preserved','prior','surface']:
  pkg='hyperbrep-polynomial-'+family+'-'+side
  assert run.run(dict(label=side+'-'+family+'-build',command=['cargo','build','--offline','--release','--manifest-path',str(O/family/side/'Cargo.toml'),'--bin',pkg],seconds=2400))==0
  dest=O/'bin'/(family+'-'+side)
  shutil.copy(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,dest)
  if family=='preserved':env={'HYPERBREP_BRANCH_ARTIFACTS':str(O/'artifacts'/side),'HYPERBREP_FIBER_IMAGE_ARTIFACT_DIR':str(O/'artifacts'/('fibers-'+side))}
  elif family=='prior':env={'HYPERBREP_SURFACE_EVALUATION_ARTIFACT_DIR':str(O/'artifacts'/('prior-'+side))}
  else:env={'HYPERBREP_RATIONAL_SURFACE_ARTIFACT_DIR':str(O/'artifacts'/('surface-'+side))}
  assert run.run(dict(label=side+'-'+family+'-archives',command=[str(dest),'all'],env=env,seconds=2400))==0
pkg='hyperbrep-polynomial-replay-consumer'
assert run.run(dict(label='new-native-build',command=['cargo','build','--offline','--release','--manifest-path',str(O/'consumer/Cargo.toml'),'--bin',pkg],seconds=2400))==0
shutil.copy(Path(run.ENV['CARGO_TARGET_DIR'])/'release'/pkg,O/'bin/new')
assert run.run(dict(label='new-native-archives',command=[str(O/'bin/new'),'all'],env={'HYPERBREP_POLYNOMIAL_REPLAY_ARTIFACT_DIR':str(O/'artifacts/new')},seconds=2400))==0
assert run.run(dict(label='candidate-whole-branch-replay',command=['cargo','run','--offline','--release','--manifest-path',str(O/'candidate/Cargo.toml')],seconds=1200))==0
run.run(dict(label='candidate-original-interior-loop',command=['cargo','run','--offline','--release','--manifest-path',str(O/'interior/Cargo.toml')],seconds=1200))
