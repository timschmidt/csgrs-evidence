"""Independent final read-only audit; does not call the snapshot runner."""
from pathlib import Path
import hashlib,json,tarfile,subprocess
R=Path('/mnt/development/csgrs/target/hyperbrep-development')
B=Path('/mnt/development/csgrs')
D=R/'crates/hyperbrep/docs/evidence/2026-10-19-polynomial-branch-replay'
def sha(data):return hashlib.sha256(data).hexdigest()
m=json.loads((D/'manifest.json').read_text())
assert not m['complete'] and m['retained'] and m['no_push']
for name,record in m['files'].items():
 data=(D/name).read_bytes();assert len(data)==record['bytes'] and sha(data)==record['sha256'],name
source=json.loads((D/'candidate-source.json').read_text())
for name,h in source['files'].items():assert sha((R/name).read_bytes())==h,name
decoder=json.JSONDecoder()
def member(s,p,key):
 def ws(p):
  while s[p].isspace():p+=1
  return p
 p=ws(p);assert s[p]=='{';p=ws(p+1)
 while s[p]!='}':
  k,p=decoder.raw_decode(s,p);p=ws(p);assert s[p]==':'
  a=ws(p+1);_,b=decoder.raw_decode(s,a)
  if k==key:return a,b
  p=ws(b)
  if s[p]==',':p=ws(p+1)
 raise KeyError(key)
old=(B/'docs/properties-status.json').read_bytes().decode('utf-8');new=(R/'docs/properties-status.json').read_bytes().decode('utf-8')
def bounds(s):
 a,_=member(s,0,'current_work');return member(s,a,'hyperbrep')
a,b=bounds(old);c,d=bounds(new)
assert old[:a]==new[:c] and old[b:]==new[d:]
scope=json.loads((D/'ledger-scope.json').read_text())
assert sha(old[:a].encode())==scope['prefix_sha256'] and sha(old[b:].encode())==scope['suffix_sha256']
name='crates/hyperbrep/docs/IMPLEMENTATION_STATUS.json'
before=json.loads((B/name).read_text());after=json.loads((R/name).read_text())
assert after['increments'][:-1]==before['increments']
assert after['work_packages']==before['work_packages'] and not after['complete']
assert len(after['increments'])==76 and len(after['work_packages'])==28
with tarfile.open(D/'raw-evidence.tar.gz','r:gz') as archive:
 names=archive.getnames();assert len(names)==len(set(names))
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
 results=json.load(archive.extractfile('results.json'))
 for row in results:
  for field in ['log','source_patch']:
   p=Path(row[field]).name;assert p in names
   assert sha(archive.extractfile(p).read())==row[field+'_sha256'],p
 assert 'assert!(section.is_ok()' in archive.extractfile('interior/src/main.rs').read().decode()
 assert 'assert!(!failure' in archive.extractfile('composition-blockers/src/main.rs').read().decode()
 assert {'analyze.py','finish.py','freeze.py','audit.py'}<=set(names)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()==source['baseline']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=B,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
print(json.dumps(dict(manifest_files_verified=len(m['files']),raw_members_verified=len(names),frozen_source_files_verified=len(source['files']),raw_commands_verified=len(results),root_ledger_outside_owner_byte_identical=True,previous_increments_and_all_work_packages_preserved=True,main_baseline_clean=True,no_push=True)))
