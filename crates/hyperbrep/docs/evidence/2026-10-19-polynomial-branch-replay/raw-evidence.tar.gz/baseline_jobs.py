import run
O=run.OUT
run.run(dict(label='baseline-original-interior-loop',command=['cargo','run','--offline','--release','--manifest-path',str(O/'interior/Cargo.toml')],seconds=1200))
run.run(dict(label='baseline-whole-branch-replay',command=['cargo','run','--offline','--release','--manifest-path',str(O/'baseline/Cargo.toml')],seconds=1200))
