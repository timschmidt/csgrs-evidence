#[allow(dead_code)]
#[path = "support/rotated_reconstruction.rs"]
mod acceptance;

#[test]
fn rationally_rotated_torus_reconstruction_continues() {
    acceptance::workflow(false);
}

#[test]
fn swapped_rationally_rotated_torus_reconstruction_continues() {
    acceptance::workflow(true);
}
